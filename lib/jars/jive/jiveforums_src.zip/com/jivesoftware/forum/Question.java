/*     */ package com.jivesoftware.forum;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public abstract interface Question
/*     */ {
/*     */   public abstract User getUser();
/*     */ 
/*     */   public abstract ForumThread getForumThread();
/*     */ 
/*     */   public abstract State getState();
/*     */ 
/*     */   public abstract void setState(State paramState)
/*     */     throws UnauthorizedException;
/*     */ 
/*     */   public abstract Date getCreationDate();
/*     */ 
/*     */   public abstract Date getResolutionDate();
/*     */ 
/*     */   public abstract void addHelpfulAnswer(ForumMessage paramForumMessage)
/*     */     throws UnauthorizedException;
/*     */ 
/*     */   public abstract boolean isHelpfulAnswer(ForumMessage paramForumMessage);
/*     */ 
/*     */   public abstract Collection getHelpfulAnswers();
/*     */ 
/*     */   public abstract void setCorrectAnswer(ForumMessage paramForumMessage)
/*     */     throws UnauthorizedException;
/*     */ 
/*     */   public abstract boolean isCorrectAnswer(ForumMessage paramForumMessage);
/*     */ 
/*     */   public abstract ForumMessage getCorrectAnswer();
/*     */ 
/*     */   public abstract String getProperty(String paramString);
/*     */ 
/*     */   public abstract Collection getProperties(String paramString);
/*     */ 
/*     */   public abstract void setProperty(String paramString1, String paramString2)
/*     */     throws UnauthorizedException;
/*     */ 
/*     */   public abstract void deleteProperty(String paramString)
/*     */     throws UnauthorizedException;
/*     */ 
/*     */   public abstract Iterator getPropertyNames();
/*     */ 
/*     */   public static class State
/*     */     implements Comparable
/*     */   {
/* 253 */     public static final State open = new State("open", 0);
/*     */ 
/* 259 */     public static final State possibly_resolved = new State("possibly_resolved", 1);
/*     */ 
/* 268 */     public static final State assumed_resolved = new State("assumed_resolved", 2);
/*     */ 
/* 274 */     public static final State resolved = new State("resolved", 3);
/*     */     private String value;
/*     */     private int code;
/*     */ 
/*     */     private State(String value, int code)
/*     */     {
/* 286 */       this.value = value;
/* 287 */       this.code = code;
/*     */     }
/*     */ 
/*     */     public static State valueOf(String state)
/*     */     {
/* 297 */       if (state == null) {
/* 298 */         throw new NullPointerException("State cannot be null");
/*     */       }
/* 300 */       if (state.equals(open.toString())) {
/* 301 */         return open;
/*     */       }
/* 303 */       if (state.equals(possibly_resolved.toString())) {
/* 304 */         return possibly_resolved;
/*     */       }
/* 306 */       if (state.equals(resolved.toString())) {
/* 307 */         return resolved;
/*     */       }
/* 309 */       throw new IllegalArgumentException("Not a valid state: " + state);
/*     */     }
/*     */ 
/*     */     public static State valueOf(int code)
/*     */     {
/* 319 */       if (code == open.code) {
/* 320 */         return open;
/*     */       }
/* 322 */       if (code == possibly_resolved.code) {
/* 323 */         return possibly_resolved;
/*     */       }
/* 325 */       if (code == assumed_resolved.code) {
/* 326 */         return assumed_resolved;
/*     */       }
/* 328 */       if (code == resolved.code) {
/* 329 */         return resolved;
/*     */       }
/* 331 */       throw new IllegalArgumentException("Not a valid code: " + code);
/*     */     }
/*     */ 
/*     */     public int getCode()
/*     */     {
/* 341 */       return this.code;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 345 */       return this.value;
/*     */     }
/*     */ 
/*     */     public int compareTo(Object o) {
/* 349 */       if (o == null) {
/* 350 */         return 0;
/*     */       }
/* 352 */       if (!(o instanceof State)) {
/* 353 */         throw new ClassCastException("Not a State object");
/*     */       }
/* 355 */       State s = (State)o;
/* 356 */       return toString().compareTo(s.toString());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.Question
 * JD-Core Version:    0.6.2
 */
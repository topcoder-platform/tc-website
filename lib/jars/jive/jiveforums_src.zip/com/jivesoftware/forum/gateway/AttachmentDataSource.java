/*    */ package com.jivesoftware.forum.gateway;
/*    */ 
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.forum.Attachment;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.activation.DataSource;
/*    */ import javax.activation.MimetypesFileTypeMap;
/*    */ 
/*    */ public class AttachmentDataSource
/*    */   implements DataSource
/*    */ {
/*    */   private Attachment attachment;
/*    */ 
/*    */   public AttachmentDataSource(Attachment attachment)
/*    */     throws IOException
/*    */   {
/* 35 */     this.attachment = attachment;
/*    */   }
/*    */ 
/*    */   public OutputStream getOutputStream() throws IOException {
/* 39 */     throw new IOException("AttachmentDataSource does not support getOutputStream()");
/*    */   }
/*    */ 
/*    */   public InputStream getInputStream()
/*    */     throws IOException
/*    */   {
/* 49 */     return this.attachment.getData();
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 58 */     return this.attachment.getName();
/*    */   }
/*    */ 
/*    */   public String getContentType()
/*    */   {
/* 67 */     String contentType = this.attachment.getContentType();
/* 68 */     if (contentType.indexOf('/') != -1) {
/* 69 */       return this.attachment.getContentType();
/*    */     }
/*    */ 
/* 72 */     MimetypesFileTypeMap typeMap = new MimetypesFileTypeMap();
/* 73 */     String mimeType = typeMap.getContentType(this.attachment.getName());
/* 74 */     Log.error("Attempting autocorrection of attachment content type: " + contentType + ", setting content type to " + mimeType);
/*    */ 
/* 76 */     return mimeType;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.AttachmentDataSource
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.gateway;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ public class GatewayException extends Exception
/*    */ {
/* 22 */   private Throwable nestedThrowable = null;
/*    */ 
/*    */   public GatewayException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public GatewayException(String msg) {
/* 29 */     super(msg);
/*    */   }
/*    */ 
/*    */   public GatewayException(Throwable nestedThrowable) {
/* 33 */     this.nestedThrowable = nestedThrowable;
/*    */   }
/*    */ 
/*    */   public GatewayException(String msg, Throwable nestedThrowable) {
/* 37 */     super(msg);
/* 38 */     this.nestedThrowable = nestedThrowable;
/*    */   }
/*    */ 
/*    */   public void printStackTrace() {
/* 42 */     super.printStackTrace();
/* 43 */     if (this.nestedThrowable != null)
/* 44 */       this.nestedThrowable.printStackTrace();
/*    */   }
/*    */ 
/*    */   public void printStackTrace(PrintStream ps)
/*    */   {
/* 49 */     super.printStackTrace(ps);
/* 50 */     if (this.nestedThrowable != null)
/* 51 */       this.nestedThrowable.printStackTrace(ps);
/*    */   }
/*    */ 
/*    */   public void printStackTrace(PrintWriter pw)
/*    */   {
/* 56 */     super.printStackTrace(pw);
/* 57 */     if (this.nestedThrowable != null)
/* 58 */       this.nestedThrowable.printStackTrace(pw);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.GatewayException
 * JD-Core Version:    0.6.2
 */
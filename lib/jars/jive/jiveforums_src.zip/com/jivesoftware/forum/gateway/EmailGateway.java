/*    */ package com.jivesoftware.forum.gateway;
/*    */ 
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ 
/*    */ public class EmailGateway extends Gateway
/*    */ {
/*    */   public EmailGateway(ForumFactory factory, Forum forum)
/*    */   {
/* 20 */     super(new Pop3Importer(factory, forum), new SmtpExporter(factory, forum));
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.EmailGateway
 * JD-Core Version:    0.6.2
 */
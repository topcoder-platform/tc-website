package com.jivesoftware.forum.gateway;

import java.util.Date;

public abstract interface GatewayImporter
{
  public abstract void importData(Date paramDate)
    throws GatewayException;

  public abstract void stop()
    throws GatewayException;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.GatewayImporter
 * JD-Core Version:    0.6.2
 */
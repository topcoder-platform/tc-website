/*      */ package com.jivesoftware.forum.gateway;
/*      */ 
/*      */ import com.jivesoftware.base.AdvancedUserManager;
/*      */ import com.jivesoftware.base.JiveGlobals;
/*      */ import com.jivesoftware.base.Log;
/*      */ import com.jivesoftware.base.UnauthorizedException;
/*      */ import com.jivesoftware.base.User;
/*      */ import com.jivesoftware.base.UserManagerFactory;
/*      */ import com.jivesoftware.forum.AttachmentException;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumFactory;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*      */ import com.jivesoftware.forum.ForumNotFoundException;
/*      */ import com.jivesoftware.forum.ForumThread;
/*      */ import com.jivesoftware.forum.ResultFilter;
/*      */ import com.jivesoftware.forum.SearchManager;
/*      */ import com.jivesoftware.forum.TreeWalker;
/*      */ import com.jivesoftware.forum.database.DatabaseCacheManager;
/*      */ import com.jivesoftware.forum.database.DbForumFactory;
/*      */ import com.jivesoftware.forum.database.DbForumMessage;
/*      */ import com.jivesoftware.util.LocaleUtils;
/*      */ import com.jivesoftware.util.StringUtils;
/*      */ import com.sun.mail.util.BEncoderStream;
/*      */ import com.sun.mail.util.QEncoderStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Date;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.activation.MimetypesFileTypeMap;
/*      */ import javax.mail.Address;
/*      */ import javax.mail.Flags.Flag;
/*      */ import javax.mail.Folder;
/*      */ import javax.mail.Message;
/*      */ import javax.mail.Message.RecipientType;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.Multipart;
/*      */ import javax.mail.Part;
/*      */ import javax.mail.Session;
/*      */ import javax.mail.Store;
/*      */ import javax.mail.URLName;
/*      */ import javax.mail.internet.InternetAddress;
/*      */ import javax.mail.internet.MimeMessage;
/*      */ import javax.mail.internet.MimeUtility;
/*      */ import sun.io.MalformedInputException;
/*      */ 
/*      */ public abstract class JavaMailGateway
/*      */   implements GatewayImporter
/*      */ {
/*   45 */   protected String protocol = "";
/*      */ 
/*   50 */   protected String mailbox = "";
/*      */ 
/*   55 */   protected String host = "";
/*      */ 
/*   60 */   protected int port = -1;
/*      */ 
/*   65 */   protected String username = null;
/*      */ 
/*   70 */   protected String password = null;
/*      */ 
/*   76 */   protected boolean deleteEnabled = false;
/*      */ 
/*   82 */   protected boolean debugEnabled = false;
/*      */ 
/*   87 */   protected boolean attachmentsEnabled = false;
/*      */ 
/*   92 */   protected boolean stopFlag = false;
/*      */ 
/*   97 */   protected boolean emailToUserMappingEnabled = false;
/*      */ 
/*  102 */   protected boolean importHtmlEnabled = false;
/*      */ 
/*  108 */   protected String defaultCharacterSet = "ISO-8859-1";
/*      */   private SimpleDateFormat format1;
/*      */   private SimpleDateFormat format2;
/*      */   private SimpleDateFormat format3;
/*      */   private SimpleDateFormat format4;
/*      */   private SimpleDateFormat format5;
/*      */   private SimpleDateFormat format6;
/*  122 */   protected String gatewayMessageId = "Message-ID";
/*      */ 
/*  127 */   protected String gatewayParentId = "Parent-ID";
/*      */ 
/*  132 */   protected String[] replyPrefixes = { "re:", "aw:" };
/*      */ 
/*  137 */   protected boolean subjectParentageCheckEnabled = true;
/*      */ 
/*  142 */   protected String temporaryParentBody = " ";
/*      */ 
/*  148 */   protected String emptySubject = "[No Subject]";
/*      */ 
/*  153 */   protected Hashtable parentMessageIDs = new Hashtable();
/*      */ 
/*  158 */   protected List failedMessageIDs = new ArrayList();
/*      */   public static final String MESSAGE_DATE_HEADER = "Message-Original-Date";
/*      */   public static final String SUBJECT_EXTENDED_PROPERTY = "Subject-Hash";
/*      */   public static final String TO_EXTENDED_PROPERTY = "To-Address";
/*      */   public static final String USER_AGENT_PROPERTY = "User-Agent";
/*      */   public static final String DUMMY_PARENT_HEADER = "Jive-Created-Message";
/*      */   protected long forumID;
/*      */   protected ForumFactory factory;
/*      */   public static final int MODERATED = -123;
/*  199 */   public static final String[] AGENT_HEADER_NAMES = { "User-Agent", "X-Newsreader", "X-Mailer", "X-Posting-Agent", "X-Http-User-Agent" };
/*      */ 
/*      */   public JavaMailGateway(ForumFactory factory, Forum forum)
/*      */   {
/*  203 */     this.factory = factory;
/*  204 */     this.forumID = forum.getID();
/*  205 */     this.parentMessageIDs = new Hashtable();
/*      */   }
/*      */ 
/*      */   public synchronized void importData(Date afterDate) throws GatewayException {
/*  209 */     Log.debug("host was " + this.host + ", port was " + this.port + ", protocol was " + this.protocol + ", mailbox was " + this.mailbox);
/*      */ 
/*  213 */     if ((this.host.equals("")) || (this.port == -1) || (this.protocol.equals("")) || (this.mailbox.equals(""))) {
/*  214 */       throw new GatewayException("Required properties are not all set.");
/*      */     }
/*      */ 
/*  217 */     Store store = null;
/*  218 */     Folder folder = null;
/*      */     try
/*      */     {
/*  221 */       store = getStore(afterDate);
/*      */     }
/*      */     catch (MessagingException e)
/*      */     {
/*  225 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  229 */       folder = getFolder(store);
/*  230 */       retrieveMessages(store, folder, afterDate);
/*      */     }
/*      */     catch (MessagingException e) {
/*  233 */       throw new GatewayException(e);
/*      */     } finally {
/*      */       try {
/*  236 */         folder.close(this.deleteEnabled);
/*      */       } catch (Exception e) {
/*      */         try {
/*  239 */           Forum forum = this.factory.getForum(this.forumID);
/*  240 */           Log.error("Unable to close folder when importing into forum \"" + forum.getName() + "\", Reason: " + e.getMessage());
/*      */         }
/*      */         catch (ForumNotFoundException e1) {
/*  243 */           Log.error(e1); } catch (UnauthorizedException e1) {
/*  244 */           Log.error(e1);
/*      */         }
/*      */       }try { store.close();
/*      */       } catch (Exception e) {
/*      */         try {
/*  249 */           Forum forum = this.factory.getForum(this.forumID);
/*  250 */           Log.error("Unable to close store when importing into forum \"" + forum.getName() + "\", Reason: " + e.getMessage());
/*      */         }
/*      */         catch (ForumNotFoundException e1) {
/*  253 */           Log.error(e1); } catch (UnauthorizedException e1) {
/*  254 */           Log.error(e1);
/*      */         }
/*      */       }
/*      */     }
/*  258 */     cleanup();
/*  259 */     this.parentMessageIDs.clear();
/*  260 */     this.failedMessageIDs.clear();
/*      */   }
/*      */ 
/*      */   protected Store getStore(Date afterDate)
/*      */     throws MessagingException
/*      */   {
/*  271 */     Session session = Session.getInstance(System.getProperties(), null);
/*      */ 
/*  274 */     session.setDebug(this.debugEnabled);
/*      */ 
/*  277 */     URLName url = new URLName(this.protocol, this.host, this.port, this.mailbox, this.username, this.password);
/*  278 */     Store store = session.getStore(url);
/*      */     try
/*      */     {
/*  282 */       store.connect();
/*      */     }
/*      */     catch (MessagingException e) {
/*      */       try {
/*  286 */         Forum forum = this.factory.getForum(this.forumID);
/*  287 */         Log.error("Unable to open gateway in forum \"" + forum.getName() + "\", Reason: " + e.getMessage());
/*      */ 
/*  289 */         throw e;
/*      */       } catch (ForumNotFoundException e1) {
/*  291 */         Log.error(e1); } catch (UnauthorizedException e1) {
/*  292 */         Log.error(e1);
/*      */       }
/*      */     }
/*  295 */     return store;
/*      */   }
/*      */ 
/*      */   protected Folder getFolder(Store store)
/*      */     throws MessagingException
/*      */   {
/*  306 */     Folder folder = null;
/*      */     try
/*      */     {
/*  310 */       if ((folder = store.getFolder(this.mailbox)) == null) {
/*  311 */         throw new MessagingException("No folder found");
/*      */       }
/*      */ 
/*  315 */       if (this.deleteEnabled) {
/*  316 */         folder.open(2);
/*      */       }
/*      */       else {
/*  319 */         folder.open(1);
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (NullPointerException e)
/*      */     {
/*      */       try
/*      */       {
/*  331 */         Forum forum = this.factory.getForum(this.forumID);
/*  332 */         throw new MessagingException("Unable to open folder: " + this.mailbox + " because of a NullPointerException being thrown when" + " importing into forum " + forum.getName());
/*      */       }
/*      */       catch (ForumNotFoundException e1)
/*      */       {
/*      */       }
/*      */       catch (UnauthorizedException e1) {
/*      */       }
/*  339 */       throw new MessagingException("Unable to open folder: " + this.mailbox + " because of a NullPointerException being thrown");
/*      */     }
/*      */ 
/*  343 */     return folder;
/*      */   }
/*      */ 
/*      */   protected void retrieveMessages(Store store, Folder folder, Date afterDate)
/*      */     throws MessagingException, GatewayException
/*      */   {
/*  358 */     int totalMsgCount = folder.getMessageCount();
/*  359 */     List messages = new ArrayList(Math.min(50, totalMsgCount));
/*  360 */     List mimeMessages = new ArrayList(Math.min(50, totalMsgCount));
/*      */     try
/*      */     {
/*  363 */       for (int curMsgCount = 1; (curMsgCount <= totalMsgCount) && (!this.stopFlag); curMsgCount++)
/*      */       {
/*      */         try
/*      */         {
/*  368 */           if ((!folder.isOpen()) || (!store.isConnected())) {
/*  369 */             Log.warn("Javamail server has disconnected, reconnecting...");
/*      */             try {
/*  371 */               folder.close(false); } catch (Exception e) {
/*      */             }try {
/*  373 */               store.close();
/*      */             } catch (Exception e) {
/*      */             }
/*  376 */             int retry = 1;
/*  377 */             while ((!store.isConnected()) && (retry < 4)) {
/*  378 */               retry++;
/*  379 */               store = getStore(afterDate);
/*  380 */               folder = getFolder(store);
/*      */             }
/*      */ 
/*  384 */             if ((!store.isConnected()) && (retry > 3)) {
/*  385 */               throw new GatewayException("Unable to connect to the JavaMail store provider");
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  390 */           MimeMessage message = (MimeMessage)folder.getMessage(curMsgCount);
/*      */ 
/*  394 */           mimeMessages.add(message);
/*  395 */           ForumMessage forumMessage = parseMessage(message, afterDate);
/*      */ 
/*  397 */           if (forumMessage != null)
/*      */           {
/*  404 */             Forum forum = this.factory.getForum(this.forumID);
/*  405 */             String messageID = getMessageID(message);
/*  406 */             ForumMessage dbMessage = lookupMessageByID(forum, messageID, true);
/*      */ 
/*  408 */             if ((dbMessage == null) || ("true".equals(dbMessage.getUnfilteredProperty("Jive-Created-Message"))))
/*      */             {
/*  414 */               if (this.attachmentsEnabled)
/*      */               {
/*      */                 try
/*      */                 {
/*  418 */                   addAttachments(forumMessage, message);
/*      */                 }
/*      */                 catch (MessagingException e) {
/*  421 */                   Log.error(e);
/*      */                   try
/*      */                   {
/*  426 */                     int count = 3;
/*  427 */                     String importProp = forumMessage.getUnfilteredProperty("jive.gateway.importCount");
/*      */ 
/*  429 */                     if (importProp != null) {
/*      */                       try {
/*  431 */                         count = Integer.valueOf(importProp).intValue();
/*      */                       }
/*      */                       catch (NumberFormatException e1) {
/*  434 */                         Log.error(e1);
/*      */                       }
/*  436 */                       count--;
/*      */                     }
/*      */ 
/*  439 */                     forumMessage.setProperty("jive.gateway.importCount", "" + count);
/*  440 */                     if (count > 0) {
/*  441 */                       this.failedMessageIDs.add(getMessageID(message));
/*      */                     }
/*      */                     else {
/*  444 */                       Log.error("Reached maximum import attempts for message with ID " + messageID + "into forum " + forum.getName() + ". No more attempts will " + "be made.");
/*      */                     }
/*      */ 
/*      */                   }
/*      */                   catch (MessagingException e1)
/*      */                   {
/*  451 */                     Log.error(e1);
/*  452 */                     this.failedMessageIDs.add(null);
/*      */                   }
/*      */                 }
/*      */               }
/*      */ 
/*  457 */               messages.add(forumMessage);
/*      */ 
/*  460 */               if (curMsgCount % 100 == 0) {
/*  461 */                 processMessagesAndImport(messages);
/*  462 */                 mimeMessages.clear();
/*      */               }
/*      */             }
/*      */           }
/*      */         } catch (MessagingException e) {
/*      */           try { Forum forum = this.factory.getForum(this.forumID);
/*  468 */             Log.error("An unhandled error occurred importing messages into forum \"" + forum.getName() + "\", stack trace follows", e);
/*      */           } catch (ForumNotFoundException e1)
/*      */           {
/*  471 */             Log.error(e1); } catch (UnauthorizedException e1) {
/*  472 */             Log.error(e1);
/*      */           }
/*      */         }
/*      */       }
/*  476 */       processMessagesAndImport(messages);
/*  477 */       mimeMessages.clear();
/*      */     }
/*      */     catch (ForumNotFoundException e) {
/*  480 */       throw new GatewayException(e);
/*      */     }
/*      */     catch (UnauthorizedException e) {
/*  483 */       throw new GatewayException(e);
/*      */     }
/*      */     finally {
/*  486 */       if (!messages.isEmpty()) {
/*      */         try {
/*  488 */           Forum forum = this.factory.getForum(this.forumID);
/*  489 */           Log.error("Unable to import " + messages.size() + " messages into forum \"" + forum.getName() + "\" because of errors.");
/*      */         }
/*      */         catch (ForumNotFoundException e1) {
/*  492 */           Log.error(e1); } catch (UnauthorizedException e1) {
/*  493 */           Log.error(e1);
/*      */         }
/*      */ 
/*  496 */         for (int i = 0; i < mimeMessages.size(); i++) {
/*  497 */           MimeMessage mimeMessage = (MimeMessage)mimeMessages.get(i);
/*  498 */           mimeMessage.setFlag(Flags.Flag.DELETED, false);
/*      */           try {
/*  500 */             this.failedMessageIDs.add(mimeMessage.getMessageID());
/*      */           }
/*      */           catch (MessagingException e) {
/*  503 */             this.failedMessageIDs.add(null);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void processMessagesAndImport(List messages)
/*      */     throws ForumNotFoundException, UnauthorizedException
/*      */   {
/*  520 */     if (Log.isDebugEnabled()) {
/*  521 */       Log.debug("Processing messages and importing ...");
/*      */     }
/*      */ 
/*  524 */     if (messages.isEmpty()) {
/*  525 */       if (Log.isDebugEnabled()) {
/*  526 */         Log.debug("Cannot process and import message - Nothing to process.");
/*      */       }
/*  528 */       return;
/*      */     }
/*      */ 
/*  531 */     resolveParentage(messages);
/*  532 */     correctMessageDates(messages);
/*      */ 
/*  538 */     Collections.sort(messages, new Comparator() {
/*      */       public int compare(Object object1, Object object2) {
/*  540 */         ForumMessage msg1 = (ForumMessage)object1;
/*  541 */         ForumMessage msg2 = (ForumMessage)object2;
/*  542 */         return msg1.getCreationDate().compareTo(msg2.getCreationDate());
/*      */       }
/*      */     });
/*  546 */     importMessages(messages);
/*  547 */     messages.clear();
/*  548 */     this.parentMessageIDs.clear();
/*      */   }
/*      */ 
/*      */   protected void resolveParentage(List messages)
/*      */     throws ForumNotFoundException, UnauthorizedException
/*      */   {
/*  566 */     if (Log.isDebugEnabled()) {
/*  567 */       Log.debug("Resolving parentages ...");
/*      */     }
/*      */ 
/*  570 */     for (int i = 0; i < messages.size(); i++) {
/*  571 */       ForumMessage message = (ForumMessage)messages.get(i);
/*  572 */       String messageID = message.getUnfilteredProperty(this.gatewayMessageId);
/*  573 */       Forum forum = this.factory.getForum(this.forumID);
/*  574 */       boolean found = false;
/*  575 */       ForumMessage dbMessage = lookupMessageByID(forum, messageID, true);
/*      */ 
/*  577 */       if (Log.isDebugEnabled()) {
/*  578 */         Log.debug("Looking at message " + messageID);
/*      */       }
/*      */ 
/*  582 */       if (dbMessage != null) {
/*  583 */         if (Log.isDebugEnabled()) {
/*  584 */           Log.debug("Message was a jive created message, skipping parentage lookup");
/*      */         }
/*      */ 
/*      */       }
/*  590 */       else if ((message.getUnfilteredProperty(this.gatewayParentId) != null) && (message.getUnfilteredProperty(this.gatewayParentId).length() > 0))
/*      */       {
/*  593 */         if (Log.isDebugEnabled()) {
/*  594 */           Log.debug("Message has a parent - " + message.getUnfilteredProperty(this.gatewayParentId) + ", skipping parentage lookup");
/*      */         }
/*      */ 
/*      */       }
/*  601 */       else if (!this.subjectParentageCheckEnabled) {
/*  602 */         Log.debug("Subject parentage check disabled, skipping parentage check");
/*      */       }
/*      */       else
/*      */       {
/*  609 */         String messageSubject = message.getUnfilteredSubject();
/*  610 */         String[] parentSubjects = { "", "" };
/*      */ 
/*  612 */         Log.debug("Subject parentage check enabled, searching for parent with of message " + messageID + " with subject: " + messageSubject);
/*      */ 
/*  615 */         for (int j = 0; j < this.replyPrefixes.length; j++) {
/*  616 */           Log.debug("Checking subject for existance of prefix: " + this.replyPrefixes[j]);
/*  617 */           int replyIndex = messageSubject.trim().toLowerCase().indexOf(this.replyPrefixes[j]);
/*      */ 
/*  619 */           if (replyIndex == 0)
/*      */           {
/*  622 */             parentSubjects[0] = messageSubject.trim().substring(this.replyPrefixes[j].length()).trim();
/*  623 */             parentSubjects[1] = ("FW: " + parentSubjects[0]);
/*  624 */             break;
/*      */           }
/*      */         }
/*      */ 
/*  628 */         if ("".equals(parentSubjects[0])) {
/*  629 */           Log.debug("Message was not prefixed, skipping");
/*      */         }
/*      */         else
/*      */         {
/*  634 */           for (int j = 0; j < parentSubjects.length; j++) {
/*  635 */             String pSubject = parentSubjects[j];
/*      */ 
/*  637 */             Date min = new Date(message.getCreationDate().getTime() - 5184000000L);
/*  638 */             Date max = new Date(message.getCreationDate().getTime() - 1L);
/*  639 */             ResultFilter parentCheck = new ResultFilter();
/*      */ 
/*  641 */             Log.debug("searching for parent in db with subject \"" + pSubject + "\", date no earlier than " + min);
/*      */ 
/*  643 */             parentCheck.setModerationRangeMin(-999999);
/*  644 */             parentCheck.setCreationDateRangeMin(min);
/*  645 */             parentCheck.setCreationDateRangeMax(max);
/*  646 */             parentCheck.addProperty("Subject-Hash", StringUtils.hash(pSubject));
/*  647 */             shortTermQueryCacheHack(parentCheck);
/*      */ 
/*  649 */             if (forum.getMessageCount(parentCheck) > 0)
/*      */             {
/*  651 */               Iterator parentIterator = forum.getMessages(parentCheck);
/*  652 */               ForumMessage pMessage = (ForumMessage)parentIterator.next();
/*  653 */               String pMessageID = pMessage.getUnfilteredProperty(this.gatewayMessageId);
/*  654 */               Log.debug("parent message found in db, messageID " + pMessageID);
/*      */ 
/*  658 */               if ((pMessageID != null) && (!messageID.equals(pMessageID)))
/*      */               {
/*  663 */                 if (pMessage.getCreationDate().compareTo(message.getCreationDate()) < 0) {
/*  664 */                   found = true;
/*  665 */                   message.setProperty(this.gatewayParentId, pMessageID);
/*      */                 }
/*      */                 else {
/*  668 */                   Log.debug("Parent is the same message, skipping");
/*      */                 }
/*      */ 
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*  675 */             if (!found) {
/*  676 */               Log.debug("searching for parent in import list with subject \"" + pSubject + "\", date no earlier than " + min);
/*      */ 
/*  679 */               for (int k = 0; (k < messages.size()) && (!found); k++) {
/*  680 */                 ForumMessage pMessage = (ForumMessage)messages.get(k);
/*      */ 
/*  683 */                 if (pMessage.getUnfilteredSubject().trim().equals(pSubject))
/*      */                 {
/*  688 */                   String pMessageID = pMessage.getUnfilteredProperty(this.gatewayMessageId);
/*  689 */                   String pParentID = pMessage.getUnfilteredProperty(this.gatewayParentId);
/*      */ 
/*  691 */                   Log.debug("found possible parent with messageID " + pMessageID);
/*      */ 
/*  694 */                   if ((pMessageID == null) || (pMessageID.equals(messageID))) {
/*  695 */                     Log.debug("same message, skipping");
/*      */                   }
/*  701 */                   else if ((pParentID != null) && (pParentID.equals(messageID))) {
/*  702 */                     Log.debug("parentage loop, skipping");
/*      */                   }
/*  708 */                   else if (pMessage.getCreationDate().compareTo(message.getCreationDate()) >= 0) {
/*  709 */                     Log.debug("parent younger than child, skipping");
/*      */                   }
/*      */                   else
/*      */                   {
/*  713 */                     Log.debug("Confirmed parentage of message " + messageID);
/*  714 */                     message.setProperty(this.gatewayParentId, pMessageID);
/*  715 */                     found = true;
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*  719 */             if (found)
/*      */               break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void correctMessageDates(List messages)
/*      */     throws ForumNotFoundException, UnauthorizedException
/*      */   {
/*  747 */     if (Log.isDebugEnabled()) {
/*  748 */       Log.debug("Correcting message dates ...");
/*      */     }
/*      */ 
/*  751 */     boolean parentDateCheckComplete = false;
/*      */ 
/*  755 */     while (!parentDateCheckComplete) {
/*  756 */       Forum forum = this.factory.getForum(this.forumID);
/*  757 */       parentDateCheckComplete = true;
/*      */ 
/*  759 */       for (int i = 0; i < messages.size(); i++) {
/*  760 */         ForumMessage message = (ForumMessage)messages.get(i);
/*  761 */         String messageID = message.getUnfilteredProperty(this.gatewayMessageId);
/*  762 */         String pMessageID = message.getUnfilteredProperty(this.gatewayParentId);
/*      */ 
/*  764 */         if (Log.isDebugEnabled()) {
/*  765 */           Log.debug("Checking message " + messageID + " for incorrect date");
/*      */         }
/*      */ 
/*  771 */         if ((pMessageID == null) || (pMessageID.length() < 1))
/*      */         {
/*  774 */           ForumMessage cMessage = lookupMessageByID(forum, messageID, true);
/*      */ 
/*  776 */           if (cMessage == null) {
/*  777 */             if (Log.isDebugEnabled()) {
/*  778 */               Log.debug("Message " + messageID + " has no parents, skipping");
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/*  783 */             if (Log.isDebugEnabled()) {
/*  784 */               Log.debug("Message is a Jive created message");
/*      */             }
/*      */ 
/*  787 */             ForumMessage cMessage2 = null;
/*  788 */             ForumThread thread = cMessage.getForumThread();
/*  789 */             TreeWalker tw = thread.getTreeWalker();
/*  790 */             Iterator children = tw.getRecursiveChildren(cMessage);
/*      */ 
/*  793 */             while (children.hasNext()) {
/*  794 */               cMessage = (ForumMessage)children.next();
/*  795 */               if (cMessage2 == null) {
/*  796 */                 cMessage2 = cMessage;
/*      */               }
/*  798 */               else if (cMessage.getCreationDate().compareTo(cMessage2.getCreationDate()) < 0) {
/*  799 */                 cMessage2 = cMessage;
/*      */               }
/*      */             }
/*      */ 
/*  803 */             if (cMessage2 != null) {
/*  804 */               cMessage = cMessage2;
/*  805 */               cMessage2 = null;
/*      */             }
/*      */             else {
/*  808 */               Log.error("Search for child message of dummy parent failed!!");
/*  809 */               continue;
/*      */             }
/*      */ 
/*  813 */             for (int j = 0; j < messages.size(); j++) {
/*  814 */               cMessage2 = (ForumMessage)messages.get(j);
/*  815 */               String temp = cMessage2.getUnfilteredProperty(this.gatewayParentId);
/*      */ 
/*  817 */               if (messageID.equals(temp)) break;
/*  818 */               cMessage2 = null;
/*      */             }
/*      */ 
/*  826 */             if (cMessage2 != null) {
/*  827 */               Date d1 = cMessage.getCreationDate();
/*  828 */               Date d2 = cMessage2.getCreationDate();
/*  829 */               if (d2.compareTo(d1) < 0) {
/*  830 */                 cMessage = cMessage2;
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*  836 */             Date pDate = message.getCreationDate();
/*  837 */             Date cDate = cMessage.getCreationDate();
/*      */ 
/*  839 */             if (pDate.compareTo(cDate) >= 0) {
/*  840 */               long cTime = cDate.getTime();
/*  841 */               String sTime = String.valueOf(cTime);
/*      */ 
/*  843 */               if (Log.isDebugEnabled()) {
/*  844 */                 Log.debug("Message " + cMessage.getID() + " was older than it's parent " + "(" + cDate + " >= " + pDate + "), correcting");
/*      */               }
/*      */ 
/*  850 */               message.setProperty("Message-Original-Date", sTime);
/*  851 */               message.setCreationDate(new Date(cTime - 1L));
/*  852 */               parentDateCheckComplete = false;
/*      */             }
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  858 */           if (Log.isDebugEnabled()) {
/*  859 */             Log.debug("Message " + messageID + " has a parent");
/*      */           }
/*  861 */           ForumMessage pMessage = null;
/*      */ 
/*  864 */           for (int j = 0; j < messages.size(); j++) {
/*  865 */             pMessage = (ForumMessage)messages.get(j);
/*  866 */             String temp = pMessage.getUnfilteredProperty(this.gatewayMessageId);
/*      */ 
/*  868 */             if (pMessageID.equals(temp)) break;
/*  869 */             pMessage = null;
/*      */           }
/*      */ 
/*  877 */           if (pMessage == null) {
/*  878 */             pMessage = lookupMessageByID(forum, pMessageID, false);
/*      */           }
/*      */ 
/*  882 */           if (pMessage == null) {
/*  883 */             if (Log.isDebugEnabled()) {
/*  884 */               Log.debug("Couldn't find parent message - autocreating dummy parent message");
/*      */             }
/*      */ 
/*  888 */             ForumMessage dMessage = forum.createMessage();
/*  889 */             long time = message.getCreationDate().getTime();
/*  890 */             Date parentDate = new Date(time - 1L);
/*  891 */             String messageSubject = message.getUnfilteredSubject();
/*  892 */             String[] parentIDs = (String[])this.parentMessageIDs.get(messageID);
/*      */ 
/*  894 */             for (int k = 0; k < this.replyPrefixes.length; k++) {
/*  895 */               String prefix = this.replyPrefixes[k];
/*      */ 
/*  897 */               int replyIndex = messageSubject.toLowerCase().indexOf(prefix);
/*      */ 
/*  899 */               if ((replyIndex == 0) && (messageSubject.length() > prefix.length() + 1)) {
/*  900 */                 messageSubject = messageSubject.trim().substring(prefix.length()).trim();
/*      */ 
/*  902 */                 if (messageSubject.length() <= 255) break;
/*  903 */                 messageSubject = messageSubject.substring(0, 254);
/*  904 */                 break;
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*  911 */             dMessage.setSubject(messageSubject);
/*  912 */             dMessage.setProperty("Subject-Hash", StringUtils.hash(messageSubject));
/*      */ 
/*  914 */             dMessage.setCreationDate(parentDate);
/*  915 */             dMessage.setModificationDate(parentDate);
/*  916 */             dMessage.setProperty(this.gatewayMessageId, pMessageID);
/*  917 */             dMessage.setProperty("Jive-Created-Message", "true");
/*  918 */             if ((this.temporaryParentBody != null) && (!"".equals(this.temporaryParentBody))) {
/*  919 */               dMessage.setBody(this.temporaryParentBody);
/*      */             }
/*      */             else {
/*  922 */               dMessage.setBody(" ");
/*      */             }
/*      */ 
/*  927 */             if ((parentIDs != null) && (parentIDs.length > 1))
/*      */             {
/*  930 */               if (!pMessageID.equals(parentIDs[1])) {
/*  931 */                 dMessage.setProperty(this.gatewayParentId, parentIDs[1]);
/*  932 */                 dMessage.setSubject(message.getUnfilteredSubject());
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*  937 */             messages.add(messages.indexOf(message), dMessage);
/*  938 */             parentDateCheckComplete = false;
/*      */ 
/*  944 */             break;
/*      */           }
/*      */ 
/*  947 */           Date messageDate = message.getCreationDate();
/*  948 */           Date pMessageDate = pMessage.getCreationDate();
/*  949 */           long cTime = messageDate.getTime();
/*  950 */           long pTime = pMessageDate.getTime();
/*  951 */           String sTime = String.valueOf(cTime);
/*      */ 
/*  953 */           if (pTime >= cTime) {
/*  954 */             if (Log.isDebugEnabled()) {
/*  955 */               Log.debug("Message " + message.getID() + " was older than it's parent " + "(" + messageDate + " >= " + pMessageDate + "), correcting");
/*      */             }
/*      */ 
/*  961 */             message.setProperty("Message-Original-Date", sTime);
/*  962 */             message.setCreationDate(new Date(pTime + 1L));
/*  963 */             message.setModificationDate(new Date(pTime + 1L));
/*  964 */             parentDateCheckComplete = false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected ForumMessage parseMessage(Message message, Date afterDate)
/*      */   {
/*  980 */     if (Log.isDebugEnabled()) {
/*  981 */       Log.debug("Parsing message");
/*      */     }
/*      */ 
/*  984 */     Forum forum = null;
/*      */     try {
/*  986 */       forum = this.factory.getForum(this.forumID); } catch (Exception e) {
/*  987 */       Log.error(e);
/*      */     }
/*  989 */     ForumMessage forumMessage = null;
/*  990 */     String messageID = null;
/*  991 */     boolean moderated = false;
/*      */     try
/*      */     {
/*  995 */       messageID = getMessageID(message);
/*  996 */       if ("UNKNOWN".equals(messageID)) {
/*  997 */         moderated = true;
/*      */       }
/*      */ 
/* 1001 */       if (getDate(message).compareTo(afterDate) < 0) {
/* 1002 */         if (Log.isDebugEnabled()) {
/* 1003 */           Log.debug("Message " + messageID + " is too old, ignoring");
/*      */         }
/*      */ 
/* 1006 */         message.setFlag(Flags.Flag.DELETED, this.deleteEnabled);
/* 1007 */         return null;
/*      */       }
/*      */ 
/* 1011 */       String subject = getSubject(message);
/* 1012 */       if ((subject == null) || ("".equals(subject.trim()))) {
/* 1013 */         subject = this.emptySubject;
/*      */       }
/*      */ 
/* 1017 */       subject = StringUtils.replace(subject, "", "");
/*      */ 
/* 1019 */       if ((subject == null) || ("".equals(subject.trim()))) {
/* 1020 */         subject = this.emptySubject;
/*      */       }
/*      */ 
/* 1024 */       subject = subject.length() > 255 ? subject.substring(0, 254).trim() : subject.trim();
/*      */ 
/* 1026 */       if (Log.isDebugEnabled()) {
/* 1027 */         Log.debug("Message " + messageID + " had subject " + subject);
/*      */       }
/*      */ 
/* 1030 */       String[] fromHeader = message.getHeader("From");
/* 1031 */       String email = null;
/* 1032 */       String name = null;
/*      */ 
/* 1034 */       if (fromHeader != null) {
/* 1035 */         if (!"".equals(getFromEmail(fromHeader[0]))) {
/* 1036 */           email = getFromEmail(message.getHeader("From")[0]);
/*      */         }
/* 1038 */         if (!"".equals(getFromName(fromHeader[0]))) {
/* 1039 */           name = getFromName(message.getHeader("From")[0]);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1046 */       if ((this.emailToUserMappingEnabled) && (email != null) && ((UserManagerFactory.getInstance() instanceof AdvancedUserManager)))
/*      */       {
/* 1049 */         if (Log.isDebugEnabled()) {
/* 1050 */           Log.debug("Attempting to map email address to user for message " + messageID);
/*      */         }
/* 1052 */         User user = ((AdvancedUserManager)UserManagerFactory.getInstance()).getUserFromEmailAddress(email);
/*      */ 
/* 1055 */         if (user != null) {
/* 1056 */           if (Log.isDebugEnabled()) {
/* 1057 */             Log.debug("Found user " + user.getUsername() + ", creating message in that user's name");
/*      */           }
/* 1059 */           forumMessage = forum.createMessage(user);
/*      */         }
/*      */         else {
/* 1062 */           if (Log.isDebugEnabled()) {
/* 1063 */             Log.debug("Did not find user, creating guest message");
/*      */           }
/* 1065 */           forumMessage = forum.createMessage();
/* 1066 */           if (email != null) {
/* 1067 */             if (Log.isDebugEnabled()) {
/* 1068 */               Log.debug("Setting guest's email address to " + email);
/*      */             }
/* 1070 */             forumMessage.setProperty("email", email);
/*      */           }
/* 1072 */           if (name != null) {
/* 1073 */             if (Log.isDebugEnabled()) {
/* 1074 */               Log.debug("Setting guest's name address to " + name);
/*      */             }
/* 1076 */             forumMessage.setProperty("name", name);
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 1081 */         forumMessage = forum.createMessage();
/* 1082 */         if (email != null) {
/* 1083 */           forumMessage.setProperty("email", email);
/*      */         }
/* 1085 */         if (name != null) {
/* 1086 */           forumMessage.setProperty("name", name);
/*      */         }
/*      */       }
/*      */ 
/* 1090 */       forumMessage.setSubject(subject);
/* 1091 */       forumMessage.setProperty("Subject-Hash", StringUtils.hash(subject));
/*      */ 
/* 1093 */       String userAgent = getUserAgent(message);
/* 1094 */       if (userAgent != null) {
/* 1095 */         forumMessage.setProperty("User-Agent", userAgent);
/*      */       }
/*      */ 
/* 1098 */       if (JiveGlobals.getJiveBooleanProperty("restrictGateways", false)) {
/* 1099 */         String recipients = getRecipients(message);
/* 1100 */         forumMessage.setProperty("To-Address", recipients);
/* 1101 */         int gateways = forum.getGatewayManager().getGatewayCount();
/* 1102 */         for (int i = 0; i < gateways; i++) {
/* 1103 */           Gateway gateway = forum.getGatewayManager().getGateway(i);
/* 1104 */           GatewayExporter exporter = gateway.getGatewayExporter();
/* 1105 */           if ((exporter instanceof SmtpExporter)) {
/* 1106 */             SmtpExporter se = (SmtpExporter)exporter;
/* 1107 */             if (recipients.indexOf(se.getToAddress()) == -1)
/*      */             {
/* 1110 */               moderated = true;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1116 */       if (moderated) {
/* 1117 */         forumMessage.setModerationValue(-123, null);
/*      */       }
/*      */ 
/* 1120 */       Date date = getDate(message);
/* 1121 */       forumMessage.setCreationDate(date);
/* 1122 */       forumMessage.setModificationDate(date);
/* 1123 */       forumMessage.setProperty(this.gatewayMessageId, messageID);
/* 1124 */       StringBuffer body = new StringBuffer(4096);
/* 1125 */       getBody(body, message);
/* 1126 */       String bodyString = StringUtils.replace(body.toString(), "", "");
/*      */ 
/* 1128 */       if ((bodyString == null) || ("".equals(bodyString))) {
/* 1129 */         bodyString = " ";
/*      */       }
/*      */ 
/* 1132 */       forumMessage.setBody(bodyString);
/*      */ 
/* 1134 */       if (!getParentMessageID(message)[0].equals("")) {
/* 1135 */         forumMessage.setProperty(this.gatewayParentId, getParentMessageID(message)[0]);
/*      */       }
/*      */ 
/* 1141 */       this.parentMessageIDs.put(messageID, getParentMessageID(message));
/*      */ 
/* 1144 */       message.setFlag(Flags.Flag.DELETED, this.deleteEnabled);
/*      */     }
/*      */     catch (MessagingException me) {
/* 1147 */       if (Log.isDebugEnabled()) {
/* 1148 */         Log.debug("Unable to parse message with ID: " + messageID + " being imported into forum \"" + forum.getName() + "\"", me);
/*      */       }
/*      */ 
/* 1151 */       Log.error("Unable to parse message with ID: " + messageID + " being imported into forum \"" + forum.getName() + "\"", me);
/*      */ 
/* 1155 */       this.failedMessageIDs.add(messageID);
/* 1156 */       return null;
/*      */     }
/*      */     catch (NullPointerException npe) {
/* 1159 */       if (Log.isDebugEnabled()) {
/* 1160 */         Log.debug("Unable to parse message with ID: " + messageID + " being imported into forum \"" + forum.getName() + "\"", npe);
/*      */       }
/*      */ 
/* 1163 */       Log.error("Unable to parse message with ID: " + messageID + " being imported into forum \"" + forum.getName() + "\"", npe);
/*      */ 
/* 1167 */       this.failedMessageIDs.add(messageID);
/* 1168 */       return null;
/*      */     }
/*      */     catch (IOException ioe) {
/* 1171 */       if (Log.isDebugEnabled()) {
/* 1172 */         Log.debug("Unable to parse message with ID: " + messageID + " being imported into forum \"" + forum.getName() + "\"", ioe);
/*      */       }
/*      */ 
/* 1175 */       Log.error("Unable to parse message with ID: " + messageID + " being imported into forum \"" + forum.getName() + "\"", ioe);
/*      */ 
/* 1179 */       this.failedMessageIDs.add(messageID);
/* 1180 */       return null;
/*      */     }
/*      */     catch (UnauthorizedException uae) {
/* 1183 */       Log.error("Unable to parse message with ID: " + messageID + " being imported into forum \"" + forum.getName() + "\"", uae);
/*      */ 
/* 1187 */       this.failedMessageIDs.add(messageID);
/* 1188 */       return null;
/*      */     }
/*      */ 
/* 1191 */     return forumMessage;
/*      */   }
/*      */ 
/*      */   private String getUserAgent(Message message)
/*      */     throws MessagingException
/*      */   {
/* 1202 */     for (int i = 0; i < AGENT_HEADER_NAMES.length; i++) {
/* 1203 */       String[] userAgent = message.getHeader(AGENT_HEADER_NAMES[i]);
/* 1204 */       if ((userAgent != null) && (userAgent.length > 0) && (!userAgent[0].equals(""))) {
/* 1205 */         return userAgent[0];
/*      */       }
/*      */     }
/* 1208 */     return null;
/*      */   }
/*      */ 
/*      */   private String getRecipients(Message message) {
/* 1212 */     StringBuffer to = new StringBuffer();
/* 1213 */     getRecipients(message, to, Message.RecipientType.TO);
/* 1214 */     getRecipients(message, to, Message.RecipientType.CC);
/*      */ 
/* 1216 */     return to.toString();
/*      */   }
/*      */ 
/*      */   private void getRecipients(Message message, StringBuffer to, Message.RecipientType type) {
/*      */     try {
/* 1221 */       Address[] addrs = message.getRecipients(type);
/* 1222 */       if (addrs == null) {
/* 1223 */         return;
/*      */       }
/*      */ 
/* 1226 */       for (int i = 0; i < addrs.length; i++) {
/* 1227 */         InternetAddress addr = (InternetAddress)addrs[i];
/* 1228 */         to.append(addr.getAddress() + ";");
/*      */       }
/*      */     }
/*      */     catch (MessagingException e)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void importMessages(List messages)
/*      */     throws ForumNotFoundException, UnauthorizedException
/*      */   {
/* 1258 */     Log.debug("Importing messages into the database");
/* 1259 */     ArrayList insertCache = new ArrayList();
/*      */ 
/* 1262 */     for (int i = 0; i < messages.size(); i++) {
/* 1263 */       ForumMessage message = (ForumMessage)messages.get(i);
/* 1264 */       Forum forum = this.factory.getForum(this.forumID);
/*      */ 
/* 1267 */       if (message == null) {
/* 1268 */         Log.error("Unable to import empty message into forum \"" + forum.getName() + "\", skipping message.");
/*      */       }
/*      */       else
/*      */       {
/* 1273 */         String messageID = message.getUnfilteredProperty(this.gatewayMessageId);
/* 1274 */         DbForumMessage dbMessage = lookupMessageByID(forum, messageID, false);
/*      */ 
/* 1276 */         Log.debug("Importing message " + messageID);
/*      */ 
/* 1279 */         if (dbMessage == null) {
/* 1280 */           Log.debug("Message " + messageID + " is not in the database");
/*      */ 
/* 1283 */           String parentID = message.getUnfilteredProperty(this.gatewayParentId);
/*      */ 
/* 1286 */           if ((parentID != null) && (!parentID.equals("")))
/*      */           {
/* 1289 */             Log.debug("Message " + messageID + " has a parent message " + parentID);
/*      */             InsertCacheItem parentItem;
/* 1292 */             if ((parentItem = isMessageinInsertCache(insertCache, parentID)) != null) {
/* 1293 */               Log.debug("Found parent to message " + messageID + " in the insert cache");
/*      */ 
/* 1296 */               InsertCacheItem insertCacheItem = new InsertCacheItem(forum, null, null, message);
/*      */ 
/* 1298 */               insertCache.add(insertCacheItem);
/*      */ 
/* 1302 */               parentItem.addChild(insertCacheItem);
/*      */             }
/*      */             else
/*      */             {
/* 1306 */               ForumMessage parent = lookupMessageByID(forum, parentID, false);
/*      */ 
/* 1308 */               if (parent != null) {
/* 1309 */                 Log.debug("Found parent to message " + messageID + " in the database");
/* 1310 */                 ForumThread thread = parent.getForumThread();
/*      */ 
/* 1313 */                 InsertCacheItem insertCacheItem = new InsertCacheItem(forum, thread, parent, message);
/*      */ 
/* 1315 */                 insertCache.add(insertCacheItem);
/*      */               }
/*      */               else
/*      */               {
/* 1319 */                 Log.debug("Unable to find parent to message " + messageID + " in the insert cache or the database, importing with no parent");
/*      */ 
/* 1328 */                 InsertCacheItem insertCacheItem = new InsertCacheItem(forum, null, null, message);
/*      */ 
/* 1330 */                 insertCache.add(insertCacheItem);
/*      */               }
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 1336 */             Log.debug("Message " + messageID + " has no parent");
/*      */ 
/* 1338 */             InsertCacheItem insertCacheItem = new InsertCacheItem(forum, null, null, message);
/*      */ 
/* 1340 */             insertCache.add(insertCacheItem);
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1345 */           Log.debug("Message " + messageID + " already exists in db. Checking to see if " + "the db message is a dummy parent message");
/*      */ 
/* 1348 */           if ("true".equalsIgnoreCase(dbMessage.getUnfilteredProperty("Jive-Created-Message"))) {
/* 1349 */             Log.debug("Message " + messageID + " already exists in db as a dummy " + "parent message. Modifying the existing message.");
/*      */ 
/* 1353 */             dbMessage.setCreationDate(message.getCreationDate());
/* 1354 */             dbMessage.setSubject(message.getUnfilteredSubject());
/* 1355 */             dbMessage.setProperty("Subject-Hash", StringUtils.hash(message.getUnfilteredSubject()));
/*      */ 
/* 1357 */             dbMessage.setProperty(this.gatewayMessageId, message.getUnfilteredProperty(this.gatewayMessageId));
/*      */ 
/* 1359 */             if (message.getUnfilteredProperty(this.gatewayParentId) != null) {
/* 1360 */               dbMessage.setProperty(this.gatewayParentId, message.getUnfilteredProperty(this.gatewayParentId));
/*      */             }
/*      */ 
/* 1363 */             dbMessage.deleteProperty("Jive-Created-Message");
/*      */ 
/* 1367 */             if ((this.emailToUserMappingEnabled) && (message.getUnfilteredProperty("email") != null) && ((UserManagerFactory.getInstance() instanceof AdvancedUserManager)))
/*      */             {
/* 1370 */               User user = message.getUser();
/*      */ 
/* 1372 */               if (user != null) {
/* 1373 */                 dbMessage.setUser(user);
/*      */               }
/*      */               else {
/* 1376 */                 if (message.getUnfilteredProperty("name") != null) {
/* 1377 */                   dbMessage.setProperty("name", message.getUnfilteredProperty("name"));
/*      */                 }
/* 1379 */                 if (message.getUnfilteredProperty("email") != null)
/* 1380 */                   dbMessage.setProperty("email", message.getUnfilteredProperty("email"));
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/* 1385 */               if (message.getUnfilteredProperty("name") != null) {
/* 1386 */                 dbMessage.setProperty("name", message.getUnfilteredProperty("name"));
/*      */               }
/* 1388 */               if (message.getUnfilteredProperty("email") != null) {
/* 1389 */                 dbMessage.setProperty("email", message.getUnfilteredProperty("email"));
/*      */               }
/*      */             }
/*      */ 
/* 1393 */             if ((message.getUnfilteredBody() != null) && (!"".equals(message.getUnfilteredBody()))) {
/* 1394 */               dbMessage.setBody(message.getUnfilteredBody());
/*      */             }
/*      */             else {
/* 1397 */               dbMessage.setBody(" ");
/*      */             }
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/* 1403 */             Log.debug("Not reimporting already existing message with ID " + messageID);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1409 */     Iterator cacheIterator = insertCache.iterator();
/*      */ 
/* 1412 */     while (cacheIterator.hasNext()) {
/* 1413 */       InsertCacheItem cacheItem = (InsertCacheItem)cacheIterator.next();
/* 1414 */       cacheItem.insert();
/*      */     }
/*      */   }
/*      */ 
/*      */   protected InsertCacheItem isMessageinInsertCache(List cache, String messageID) {
/* 1419 */     Iterator iter = cache.iterator();
/*      */ 
/* 1421 */     while (iter.hasNext()) {
/* 1422 */       InsertCacheItem cacheItem = (InsertCacheItem)iter.next();
/* 1423 */       if (cacheItem.containsMessage(messageID)) {
/* 1424 */         return cacheItem;
/*      */       }
/*      */     }
/*      */ 
/* 1428 */     return null;
/*      */   }
/*      */ 
/*      */   protected DbForumMessage lookupMessageByID(Forum forum, String messageID, boolean checkDummy)
/*      */   {
/* 1440 */     if ((messageID == null) || (messageID.length() == 0)) {
/* 1441 */       return null;
/*      */     }
/*      */ 
/* 1444 */     ResultFilter existsCheck = new ResultFilter();
/* 1445 */     existsCheck.setModerationRangeMin(-1000000);
/* 1446 */     if (checkDummy) {
/* 1447 */       existsCheck.addProperty("Jive-Created-Message", "true");
/*      */     }
/* 1449 */     existsCheck.addProperty(this.gatewayMessageId, messageID);
/*      */ 
/* 1451 */     shortTermQueryCacheHack(existsCheck);
/* 1452 */     Iterator iter = forum.getMessages(existsCheck);
/*      */ 
/* 1454 */     if (!iter.hasNext()) {
/* 1455 */       return null;
/*      */     }
/*      */ 
/* 1458 */     ForumMessage message = (ForumMessage)iter.next();
/*      */     try {
/* 1460 */       return (DbForumMessage)DbForumFactory.getInstance().getMessage(message.getID());
/*      */     }
/*      */     catch (ForumMessageNotFoundException e) {
/*      */     }
/* 1464 */     return null;
/*      */   }
/*      */ 
/*      */   protected void shortTermQueryCacheHack(ResultFilter filter)
/*      */   {
/* 1476 */     if (DbForumFactory.getInstance().cacheManager.isShortTermQueryCacheEnabled())
/* 1477 */       filter.setCreationDateRangeMax(new Date());
/*      */   }
/*      */ 
/*      */   protected boolean isMessageWithAttachments(Message message)
/*      */     throws MessagingException
/*      */   {
/*      */     try
/*      */     {
/* 1492 */       if ((message.isMimeType("text/plain")) || (message.isMimeType("text"))) {
/* 1493 */         BufferedReader reader = getTextReader(message);
/*      */         try
/*      */         {
/*      */           String line;
/* 1496 */           while ((line = reader.readLine()) != null)
/* 1497 */             if ((line.indexOf("begin 666 ") == 0) || (line.indexOf("begin 664 ") == 0) || (line.indexOf("begin 660 ") == 0) || (line.indexOf("begin 644 ") == 0) || (line.indexOf("begin 640 ") == 0) || (line.indexOf("begin 600 ") == 0))
/*      */             {
/* 1504 */               return true;
/*      */             }
/*      */         }
/*      */         catch (MalformedInputException mie)
/*      */         {
/*      */           try {
/* 1510 */             Forum forum = this.factory.getForum(this.forumID);
/* 1511 */             Log.error("While importing into forum \"" + forum.getName() + "\" an error" + " occurred testing the message with ID: " + getMessageID(message) + " for embedded attachments. If possible, please email" + " support@jivesoftware.com with the full text including headers" + " for this message.", mie);
/*      */           }
/*      */           catch (ForumNotFoundException e1)
/*      */           {
/* 1517 */             Log.error(e1); } catch (UnauthorizedException e1) {
/* 1518 */             Log.error(e1);
/*      */           }
/*      */         } finally {
/*      */           try { reader.close();
/*      */           } catch (IOException ioe) {
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 1527 */         return true;
/*      */       }
/*      */     }
/*      */     catch (IOException e) {
/* 1531 */       throw new MessagingException("An error occurred testing a message for embedded attachments. This error was likely caused by a communication error with the remote server.", e);
/*      */     }
/*      */ 
/* 1535 */     return false;
/*      */   }
/*      */ 
/*      */   protected void addAttachments(ForumMessage forumMessage, Part part)
/*      */     throws MessagingException, UnauthorizedException
/*      */   {
/*      */     try
/*      */     {
/* 1554 */       if ((part.isMimeType("text/html")) && (!this.importHtmlEnabled)) {
/* 1555 */         String filename = part.getFileName();
/*      */ 
/* 1557 */         if (filename == null) {
/* 1558 */           filename = "att1.html";
/*      */         }
/* 1560 */         forumMessage.createAttachment(filename, "text/html", part.getInputStream());
/*      */       }
/* 1562 */       else if (part.isMimeType("text/html")) {
/* 1563 */         if ("attachment".equalsIgnoreCase(part.getDisposition())) {
/* 1564 */           String filename = part.getFileName();
/* 1565 */           if (filename == null) {
/* 1566 */             filename = "att1.html";
/*      */           }
/* 1568 */           forumMessage.createAttachment(filename, "text/html", part.getInputStream());
/*      */         }
/*      */ 
/*      */       }
/* 1574 */       else if ((part.isMimeType("text/plain")) || (part.isMimeType("text"))) {
/* 1575 */         if (part.getDisposition() == null) {
/* 1576 */           BufferedReader reader = getTextReader(part);
/*      */           try {
/* 1578 */             addUUencodedAttachments(forumMessage, reader);
/*      */           }
/*      */           catch (IOException ioe) {
/* 1581 */             Log.debug("There was a problem adding UUencoded attachments from message. This can be caused by a malformed message and does not necessarily mean that the message had attachments. There should be previous messages in the log indicating the reason for failure.", ioe);
/*      */           }
/*      */ 
/*      */         }
/* 1587 */         else if (part.getDisposition().equalsIgnoreCase("attachment")) {
/* 1588 */           String filename = part.getFileName();
/* 1589 */           String ct = part.getContentType();
/*      */ 
/* 1592 */           if ((ct != null) && (ct.indexOf(';') != -1)) {
/* 1593 */             ct = ct.substring(0, ct.indexOf(';')).trim().toLowerCase();
/*      */           }
/*      */ 
/* 1596 */           if ((ct == null) || (ct.length() > 50)) {
/* 1597 */             MimetypesFileTypeMap typeMap = new MimetypesFileTypeMap();
/* 1598 */             ct = typeMap.getContentType(filename);
/*      */           }
/*      */ 
/* 1601 */           forumMessage.createAttachment(filename, ct, part.getInputStream());
/*      */         }
/*      */         else {
/* 1604 */           BufferedReader reader = getTextReader(part);
/*      */           try {
/* 1606 */             addUUencodedAttachments(forumMessage, reader);
/*      */           }
/*      */           catch (IOException ioe) {
/* 1609 */             Log.debug("There was a problem adding UUencoded attachments from message. This can be caused by a malformed message and does not necessarily mean that the message had attachments. There should be previous messages in the log indicating the reason for failure.", ioe);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/* 1618 */       else if (part.isMimeType("multipart/*")) {
/*      */         try {
/* 1620 */           Multipart mp = (Multipart)part.getContent();
/* 1621 */           int cnt = mp.getCount();
/*      */ 
/* 1623 */           for (int j = 0; j < cnt; j++) {
/* 1624 */             Part p = mp.getBodyPart(j);
/* 1625 */             addAttachments(forumMessage, p);
/*      */           }
/*      */         }
/*      */         catch (IllegalArgumentException iae) {
/* 1629 */           throw new MessagingException("Character set not recognized", iae);
/*      */         }
/*      */ 
/*      */       }
/* 1633 */       else if (part.isMimeType("message/rfc822")) {
/* 1634 */         forumMessage.createAttachment("email.eml", "message/rfc822", part.getInputStream());
/*      */       }
/*      */       else
/*      */       {
/* 1639 */         String ct = part.getContentType();
/* 1640 */         String disposition = part.getDisposition();
/* 1641 */         String filename = part.getFileName();
/*      */ 
/* 1644 */         if ((ct != null) && (ct.indexOf(';') != -1)) {
/* 1645 */           ct = ct.substring(0, ct.indexOf(';')).trim().toLowerCase();
/*      */         }
/*      */ 
/* 1648 */         if ((ct == null) || (ct.length() > 50)) {
/* 1649 */           MimetypesFileTypeMap typeMap = new MimetypesFileTypeMap();
/* 1650 */           ct = typeMap.getContentType(filename);
/*      */         }
/*      */ 
/* 1653 */         if (disposition == null) {
/* 1654 */           if ((filename == null) || ("".equals(filename.trim()))) {
/* 1655 */             filename = "att1.dat";
/*      */           }
/* 1657 */           forumMessage.createAttachment(filename, ct, part.getInputStream());
/*      */         }
/* 1659 */         else if (disposition.equalsIgnoreCase("attachment")) {
/* 1660 */           if ((filename == null) || ("".equals(filename.trim()))) {
/* 1661 */             filename = "att1.dat";
/*      */           }
/* 1663 */           forumMessage.createAttachment(filename, ct, part.getInputStream());
/*      */         }
/* 1668 */         else if ((filename != null) && (!"".equals(filename.trim()))) {
/* 1669 */           forumMessage.createAttachment(filename, ct, part.getInputStream());
/*      */         }
/*      */         else {
/* 1672 */           BufferedReader reader = getTextReader(part);
/*      */           try {
/* 1674 */             addUUencodedAttachments(forumMessage, reader);
/*      */           }
/*      */           catch (IOException ioe) {
/* 1677 */             Log.debug("There was a problem adding UUencoded attachments from message. This can be caused by a malformed message and does not necessarily mean that the message had attachments. There should be previous messages in the log indicating the reason for failure.", ioe);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 1687 */       Log.error("IOException when adding attachments.", e);
/* 1688 */       throw new MessagingException("IOException thrown", e);
/*      */     }
/*      */     catch (IllegalStateException e)
/*      */     {
/* 1692 */       Log.error(e);
/*      */     }
/*      */     catch (AttachmentException e)
/*      */     {
/* 1697 */       String importProp = forumMessage.getUnfilteredProperty("jive.gateway.importCount");
/* 1698 */       if ((importProp == null) || ("3".equals(importProp)))
/* 1699 */         if (e.getErrorType() == 0) {
/* 1700 */           if (e.getAttachmentName() != null) {
/* 1701 */             List args = new ArrayList();
/* 1702 */             args.add(e.getAttachmentName());
/* 1703 */             Date modDate = forumMessage.getModificationDate();
/* 1704 */             String body = forumMessage.getUnfilteredBody();
/* 1705 */             body = body + "\n" + LocaleUtils.getLocalizedString("gatewayattacherror.error_too_large", args);
/*      */ 
/* 1707 */             forumMessage.setBody(body);
/* 1708 */             forumMessage.setModificationDate(modDate);
/*      */           }
/*      */         }
/* 1711 */         else if (e.getErrorType() == 1) {
/* 1712 */           if (e.getAttachmentName() != null) {
/* 1713 */             List args = new ArrayList();
/* 1714 */             args.add(e.getAttachmentName());
/* 1715 */             Date modDate = forumMessage.getModificationDate();
/* 1716 */             String body = forumMessage.getUnfilteredBody();
/* 1717 */             body = body + "\n" + LocaleUtils.getLocalizedString("gatewayattacherror.error_too_many", args);
/*      */ 
/* 1719 */             forumMessage.setBody(body);
/* 1720 */             forumMessage.setModificationDate(modDate);
/*      */           }
/*      */         }
/* 1723 */         else if (e.getErrorType() == 2) {
/* 1724 */           if (e.getAttachmentName() != null) {
/* 1725 */             List args = new ArrayList();
/* 1726 */             args.add(e.getAttachmentName());
/* 1727 */             Date modDate = forumMessage.getModificationDate();
/* 1728 */             String body = forumMessage.getUnfilteredBody();
/* 1729 */             body = body + "\n" + LocaleUtils.getLocalizedString("gatewayattacherror.error_content_type", args);
/*      */ 
/* 1731 */             forumMessage.setBody(body);
/* 1732 */             forumMessage.setModificationDate(modDate);
/*      */           }
/*      */         }
/*      */         else {
/* 1736 */           Log.error("General Attachment error " + e.getMessage(), e);
/* 1737 */           if (e.getAttachmentName() != null) {
/* 1738 */             List args = new ArrayList();
/* 1739 */             args.add(e.getAttachmentName());
/* 1740 */             Date modDate = forumMessage.getModificationDate();
/* 1741 */             String body = forumMessage.getUnfilteredBody();
/* 1742 */             body = body + "\n" + LocaleUtils.getLocalizedString("gatewayattacherror.error_general", args);
/*      */ 
/* 1744 */             forumMessage.setBody(body);
/* 1745 */             forumMessage.setModificationDate(modDate);
/*      */           }
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void addUUencodedAttachments(ForumMessage forumMessage, BufferedReader reader)
/*      */     throws IOException, IllegalStateException, AttachmentException, UnauthorizedException
/*      */   {
/* 1765 */     String line = ""; String bufline = ""; String filename = "";
/* 1766 */     boolean found = false;
/* 1767 */     StringBuffer sb = new StringBuffer(4096);
/*      */     try
/*      */     {
/* 1770 */       while ((line = reader.readLine()) != null)
/* 1771 */         if ((line.indexOf("begin 666 ") == 0) || (line.indexOf("begin 664 ") == 0) || (line.indexOf("begin 660 ") == 0) || (line.indexOf("begin 644 ") == 0) || (line.indexOf("begin 640 ") == 0) || (line.indexOf("begin 600 ") == 0))
/*      */         {
/* 1778 */           bufline = line;
/* 1779 */           filename = line.substring(9).trim();
/* 1780 */           if (filename.charAt(0) == '"') {
/* 1781 */             filename = filename.substring(1);
/*      */           }
/* 1783 */           if (filename.charAt(filename.length() - 1) == '"') {
/* 1784 */             filename = filename.substring(0, filename.length() - 1);
/*      */           }
/*      */ 
/* 1787 */           found = true;
/*      */         }
/* 1789 */         else if ((found) && (line.indexOf("end") == 0))
/*      */         {
/* 1793 */           sb.append(" \nend\n");
/* 1794 */           found = false;
/*      */ 
/* 1797 */           MimetypesFileTypeMap typeMap = new MimetypesFileTypeMap();
/* 1798 */           String mimeType = typeMap.getContentType(filename);
/* 1799 */           byte[] b = sb.toString().getBytes("ASCII");
/* 1800 */           ByteArrayInputStream bis = new ByteArrayInputStream(b);
/* 1801 */           InputStream is = MimeUtility.decode(bis, "uuencode");
/*      */           try
/*      */           {
/* 1804 */             forumMessage.createAttachment(filename, mimeType, is);
/*      */           } finally {
/*      */             try {
/* 1807 */               is.close(); } catch (IOException e) {
/*      */             }try { bis.close(); } catch (IOException e) {
/* 1809 */             }sb = new StringBuffer(4096);
/*      */           }
/*      */         }
/* 1812 */         else if (found) {
/* 1813 */           sb.append(bufline).append("\n");
/* 1814 */           bufline = line;
/*      */         }
/*      */     }
/*      */     catch (MessagingException e)
/*      */     {
/*      */       try {
/* 1820 */         Forum forum = this.factory.getForum(this.forumID);
/* 1821 */         Log.error("An error occurred while extracting an uuencoded attachment from the message with ID: " + forumMessage.getUnfilteredProperty(this.gatewayMessageId) + " being imported into forum \"" + forum.getName() + "\", Reason: " + e.getMessage());
/*      */       }
/*      */       catch (ForumNotFoundException e1)
/*      */       {
/* 1826 */         Log.error(e1); } catch (UnauthorizedException e1) {
/* 1827 */         Log.error(e1);
/*      */       }
/* 1829 */       throw new IOException();
/*      */     }
/*      */     catch (MalformedInputException mie) {
/*      */       try {
/* 1833 */         Forum forum = this.factory.getForum(this.forumID);
/* 1834 */         Log.error("An error occurred while extracting an uuencoded attachment from the message with ID: " + forumMessage.getUnfilteredProperty(this.gatewayMessageId) + " being imported into forum \"" + forum.getName() + "\", Reason: " + mie.getMessage(), mie);
/*      */       }
/*      */       catch (ForumNotFoundException e1)
/*      */       {
/* 1839 */         Log.error(e1); } catch (UnauthorizedException e1) {
/* 1840 */         Log.error(e1);
/*      */       }
/* 1842 */       throw new IOException(mie.getMessage());
/*      */     } finally {
/*      */       try {
/* 1845 */         reader.close();
/*      */       }
/*      */       catch (IOException ioe)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void removeUUencodedAttachments(StringBuffer sb, BufferedReader reader)
/*      */     throws IOException
/*      */   {
/* 1861 */     boolean ignore = false;
/*      */     try
/*      */     {
/*      */       String line;
/* 1865 */       while ((line = reader.readLine()) != null)
/* 1866 */         if ((line.indexOf("begin 666 ") == 0) || (line.indexOf("begin 664 ") == 0) || (line.indexOf("begin 660 ") == 0) || (line.indexOf("begin 644 ") == 0) || (line.indexOf("begin 640 ") == 0) || (line.indexOf("begin 600 ") == 0))
/*      */         {
/* 1873 */           if (!this.attachmentsEnabled) {
/* 1874 */             String filename = line.substring(9).trim();
/*      */ 
/* 1876 */             if ((filename.length() > 0) && (filename.charAt(0) == '"')) {
/* 1877 */               filename = filename.substring(1);
/*      */             }
/* 1879 */             if ((filename.length() > 0) && (filename.charAt(filename.length() - 1) == '"')) {
/* 1880 */               filename = filename.substring(0, filename.length() - 1);
/*      */             }
/* 1882 */             sb.append("[").append(filename).append("]\n");
/*      */           }
/* 1884 */           ignore = true;
/*      */         }
/* 1886 */         else if ((ignore) && (line.indexOf("end") == 0)) {
/* 1887 */           ignore = false;
/*      */         }
/* 1889 */         else if (!ignore) {
/* 1890 */           sb.append(line).append("\n");
/*      */         }
/*      */     }
/*      */     catch (MalformedInputException mie)
/*      */     {
/*      */       try {
/* 1896 */         Forum forum = this.factory.getForum(this.forumID);
/* 1897 */         Log.error("An error occurred while stripping a message being imported into forum \"" + forum.getName() + "\" of uuencoded attachments.", mie);
/*      */       }
/*      */       catch (ForumNotFoundException e1) {
/* 1900 */         Log.error(e1); } catch (UnauthorizedException e1) {
/* 1901 */         Log.error(e1);
/* 1902 */       }throw new IOException(mie.getMessage());
/*      */     } finally {
/*      */       try {
/* 1905 */         reader.close();
/*      */       }
/*      */       catch (IOException ioe)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected String getSubject(Message message)
/*      */   {
/*      */     try
/*      */     {
/* 1918 */       String[] subjects = message.getHeader("Subject");
/*      */ 
/* 1921 */       if ((subjects != null) && (subjects.length > 0)) {
/* 1922 */         String subject = subjects[0];
/* 1923 */         return getRFC2047DecodedString(subject);
/*      */       }
/*      */ 
/* 1926 */       String err = "Subject header is unavailable or its value is absent";
/* 1927 */       throw new MessagingException(err);
/*      */     }
/*      */     catch (MessagingException me)
/*      */     {
/*      */       try {
/* 1932 */         Forum forum = this.factory.getForum(this.forumID);
/* 1933 */         if (Log.isDebugEnabled()) {
/* 1934 */           Log.debug("Error retrieving subject from message with ID: " + getMessageID(message) + " being imported into forum \"" + forum.getName() + "\", Reason: " + me.getMessage());
/*      */         }
/*      */ 
/* 1938 */         Log.warn("Error retrieving subject from message with ID: " + getMessageID(message) + " being imported into forum \"" + forum.getName() + "\", Reason: " + me.getMessage());
/*      */       }
/*      */       catch (ForumNotFoundException e1)
/*      */       {
/* 1942 */         Log.error(e1); } catch (UnauthorizedException e1) {
/* 1943 */         Log.error(e1);
/*      */       } catch (MessagingException e) {
/* 1945 */         if (Log.isDebugEnabled()) {
/* 1946 */           Log.debug("Error retrieving subject from a message being imported. Reason: " + me.getMessage());
/*      */         }
/*      */ 
/* 1949 */         Log.warn("Error retrieving subject from a message being imported. Reason: " + me.getMessage());
/*      */       }
/*      */     }
/*      */ 
/* 1953 */     return null;
/*      */   }
/*      */ 
/*      */   protected static String getRFC2047DecodedString(String str)
/*      */     throws javax.mail.internet.ParseException
/*      */   {
/* 1965 */     String charset = "ISO-8859-1";
/*      */ 
/* 1967 */     if (str == null) {
/* 1968 */       return null;
/*      */     }
/*      */ 
/* 1971 */     if ((str.indexOf("=?") != -1) && (str.indexOf("?=") != -1)) {
/* 1972 */       StringBuffer temp = new StringBuffer(str.length());
/* 1973 */       String encodedWord = "";
/* 1974 */       int i = 0; int last = 0;
/*      */       try
/*      */       {
/* 1977 */         while ((str.indexOf("=?", i) != -1) && (i < str.length())) {
/* 1978 */           int first = str.indexOf("=?", i);
/*      */ 
/* 1980 */           if (first != i)
/*      */           {
/* 1983 */             for (int x = last; x < first; x++) {
/* 1984 */               if ((str.charAt(x) != ' ') || (i == 0)) {
/* 1985 */                 temp.append(str.substring(last, first));
/* 1986 */                 break;
/*      */               }
/*      */             }
/*      */           }
/* 1990 */           int c = 0;
/* 1991 */           i = first + 2;
/*      */ 
/* 1993 */           while ((c < 2) && (str.indexOf("?", i) != -1)) {
/* 1994 */             i = str.indexOf("?", i) + 1;
/* 1995 */             c++;
/*      */           }
/*      */ 
/* 1998 */           last = str.indexOf("?=", i);
/*      */ 
/* 2000 */           if ((last > 0) && (last <= str.length())) {
/* 2001 */             last += 2;
/* 2002 */             encodedWord = str.substring(first, last);
/*      */ 
/* 2005 */             int firstQ = encodedWord.indexOf('?');
/* 2006 */             int nextQ = encodedWord.indexOf('?', firstQ + 1);
/*      */ 
/* 2008 */             if ((firstQ >= 0) && (nextQ > firstQ)) {
/* 2009 */               charset = encodedWord.substring(firstQ + 1, nextQ);
/* 2010 */               if (charset.equalsIgnoreCase("hz-gb-2312")) {
/* 2011 */                 charset = "gb2312";
/* 2012 */                 encodedWord = "=?" + charset + encodedWord.substring(nextQ);
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/* 2020 */             if (encodedWord.indexOf(' ') != -1)
/*      */             {
/* 2022 */               String encoding = encodedWord.substring(firstQ, firstQ + 1);
/*      */               int index;
/* 2027 */               while ((index = encodedWord.indexOf(' ')) != -1) {
/* 2028 */                 String encodedChar = getEncodedSpace(charset, encoding.toUpperCase());
/* 2029 */                 encodedWord = encodedWord.substring(0, index) + encodedChar + (index < encodedWord.length() - 1 ? encodedWord.substring(index + 1) : "");
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*      */             try
/*      */             {
/* 2038 */               temp.append(MimeUtility.decodeWord(encodedWord));
/*      */             }
/*      */             catch (StringIndexOutOfBoundsException e) {
/* 2041 */               Log.error("Exception thrown decoding " + encodedWord);
/*      */             }
/*      */ 
/* 2044 */             i = last;
/*      */           }
/*      */           else
/*      */           {
/* 2048 */             throw new javax.mail.internet.ParseException();
/*      */           }
/*      */         }
/*      */ 
/* 2052 */         if (last < str.length()) {
/* 2053 */           temp.append(str.substring(last));
/*      */         }
/*      */ 
/* 2056 */         str = temp.toString();
/*      */       }
/*      */       catch (javax.mail.internet.ParseException e) {
/* 2059 */         Log.error("ParseException thrown, encodedWord was " + encodedWord + ", string was " + str);
/*      */       }
/*      */       catch (UnsupportedEncodingException e)
/*      */       {
/* 2063 */         Log.error("UnsupportedEncodingException thrown, encodedWord was " + encodedWord + ", encoding was " + charset);
/*      */ 
/* 2066 */         charset = "ISO-8859-1";
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2078 */     return str;
/*      */   }
/*      */ 
/*      */   protected static String getEncodedSpace(String charset, String encoding)
/*      */     throws UnsupportedEncodingException
/*      */   {
/* 2084 */     String encoded = "";
/* 2085 */     byte[] bytes = " ".getBytes(MimeUtility.javaCharset(charset));
/* 2086 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*      */     OutputStream os;
/*      */     OutputStream os;
/* 2089 */     if ("B".equals(encoding)) {
/* 2090 */       os = new BEncoderStream(baos);
/*      */     }
/*      */     else {
/* 2093 */       os = new QEncoderStream(baos, true);
/*      */     }
/*      */     try
/*      */     {
/* 2097 */       os.write(bytes);
/* 2098 */       os.close();
/*      */     }
/*      */     catch (IOException ioe) {
/*      */     }
/* 2102 */     byte[] encodedBytes = baos.toByteArray();
/* 2103 */     for (int i = 0; i < encodedBytes.length; i++) {
/* 2104 */       encoded = encoded + (char)encodedBytes[i];
/*      */     }
/*      */ 
/* 2107 */     return encoded;
/*      */   }
/*      */ 
/*      */   protected Date getDate(Message message)
/*      */     throws MessagingException
/*      */   {
/* 2124 */     if (Log.isDebugEnabled()) {
/* 2125 */       Log.debug("Retrieving date from message " + getMessageID(message));
/*      */     }
/* 2127 */     Date date = null;
/*      */     try
/*      */     {
/* 2131 */       date = message.getSentDate();
/*      */ 
/* 2133 */       if (date == null) {
/* 2134 */         date = message.getReceivedDate();
/*      */       }
/*      */     }
/*      */     catch (MessagingException me)
/*      */     {
/*      */     }
/*      */     catch (NullPointerException npe)
/*      */     {
/*      */     }
/* 2143 */     if (date == null) {
/* 2144 */       String[] headers = message.getHeader("Date");
/*      */ 
/* 2148 */       if ((headers == null) || (headers[0] == null)) {
/* 2149 */         return new Date();
/*      */       }
/*      */ 
/* 2152 */       String header = headers[0].trim();
/*      */       try
/*      */       {
/* 2155 */         if (this.format1 == null) {
/* 2156 */           this.format1 = new SimpleDateFormat("EEE MMM dd HH:mm:ss yyyy");
/* 2157 */           this.format1.setLenient(true);
/*      */         }
/* 2159 */         date = this.format1.parse(header);
/*      */       }
/*      */       catch (java.text.ParseException e1) {
/*      */       }
/* 2163 */       if (date == null)
/*      */         try {
/* 2165 */           if (this.format2 == null) {
/* 2166 */             this.format2 = new SimpleDateFormat("EEEE, MMMM dd, yyyy");
/* 2167 */             this.format2.setLenient(true);
/*      */           }
/* 2169 */           date = this.format2.parse(header);
/*      */         }
/*      */         catch (java.text.ParseException e2)
/*      */         {
/*      */         }
/* 2174 */       if (date == null)
/*      */         try {
/* 2176 */           if (this.format3 == null) {
/* 2177 */             this.format3 = new SimpleDateFormat("dd/MM/yy hh:mm a");
/* 2178 */             this.format3.setLenient(true);
/*      */           }
/* 2180 */           date = this.format3.parse(header);
/*      */         }
/*      */         catch (java.text.ParseException e3)
/*      */         {
/*      */         }
/* 2185 */       if (date == null)
/*      */         try {
/* 2187 */           if (this.format4 == null) {
/* 2188 */             this.format4 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 2189 */             this.format4.setLenient(true);
/*      */           }
/* 2191 */           date = this.format4.parse(header);
/*      */         }
/*      */         catch (java.text.ParseException e4)
/*      */         {
/*      */         }
/* 2196 */       if (date == null)
/*      */         try {
/* 2198 */           if (this.format5 == null) {
/* 2199 */             this.format5 = new SimpleDateFormat("EEE, dd MMM, yyyy HH:mm:ss");
/* 2200 */             this.format5.setLenient(true);
/*      */           }
/* 2202 */           date = this.format5.parse(header);
/*      */         }
/*      */         catch (java.text.ParseException e5)
/*      */         {
/*      */         }
/* 2207 */       if (date == null)
/*      */         try {
/* 2209 */           if (this.format6 == null) {
/* 2210 */             this.format6 = new SimpleDateFormat("MMMM dd, yyyy HH:mm a");
/* 2211 */             this.format6.setLenient(true);
/*      */           }
/* 2213 */           date = this.format6.parse(header);
/*      */         }
/*      */         catch (java.text.ParseException e6) {
/*      */         }
/*      */     }
/* 2218 */     if ((date == null) || (date.compareTo(new Date()) > 0)) {
/* 2219 */       if (Log.isDebugEnabled()) {
/* 2220 */         Log.debug("Unable to parse date header or header missing, setting date to " + new Date());
/*      */       }
/*      */ 
/* 2224 */       return new Date();
/*      */     }
/*      */ 
/* 2227 */     if (Log.isDebugEnabled()) {
/* 2228 */       Log.debug("Retrieved date of " + date + " from message " + getMessageID(message));
/*      */     }
/*      */ 
/* 2231 */     return date;
/*      */   }
/*      */ 
/*      */   protected String getMessageID(Message message)
/*      */     throws MessagingException
/*      */   {
/* 2243 */     String messageID = ((MimeMessage)message).getMessageID();
/*      */ 
/* 2245 */     if ((messageID != null) && (!messageID.equals(""))) {
/* 2246 */       return messageID;
/*      */     }
/*      */ 
/* 2249 */     Log.warn("Message-ID header is unavailable or its value is absent. Trying to gracefully continue. Subject is: " + message.getSubject());
/* 2250 */     return "UNKNOWN";
/*      */   }
/*      */ 
/*      */   protected String[] getParentMessageID(Message message)
/*      */     throws MessagingException
/*      */   {
/* 2270 */     String[] headers = { "In-Reply-To", "References" };
/* 2271 */     String[] parents = getParentMessageID(message, headers[0]);
/*      */ 
/* 2273 */     if (parents == null) {
/* 2274 */       parents = getParentMessageID(message, headers[1]);
/*      */     }
/*      */ 
/* 2277 */     if (parents == null) {
/* 2278 */       return new String[] { "" };
/*      */     }
/*      */ 
/* 2281 */     return parents;
/*      */   }
/*      */ 
/*      */   protected String[] getParentMessageID(Message message, String header)
/*      */     throws MessagingException
/*      */   {
/*      */     String[] temp;
/*      */     try
/*      */     {
/* 2298 */       temp = message.getHeader(header);
/*      */     }
/*      */     catch (NullPointerException e) {
/* 2301 */       return null;
/*      */     }
/*      */ 
/* 2305 */     if ((temp == null) || (temp[0] == null) || (temp[0].equals(""))) {
/* 2306 */       return null;
/*      */     }
/*      */ 
/* 2310 */     temp[0] = temp[0].replaceAll("\r|\t|\n", " ");
/*      */ 
/* 2314 */     StringTokenizer st = new StringTokenizer(temp[0], " ");
/* 2315 */     LinkedList pParents = new LinkedList();
/*      */ 
/* 2319 */     if (st.hasMoreTokens()) {
/* 2320 */       while (st.hasMoreTokens()) {
/* 2321 */         String t = st.nextToken();
/* 2322 */         if ((t.charAt(0) == '<') && (t.charAt(t.length() - 1) == '>')) {
/* 2323 */           pParents.addFirst(t);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2329 */     if ((temp[0].charAt(0) == '<') && (temp[0].charAt(temp[0].length() - 1) == '>')) {
/* 2330 */       pParents.addFirst(temp[0]);
/*      */     }
/*      */ 
/* 2334 */     if (!pParents.isEmpty()) {
/* 2335 */       return (String[])pParents.toArray(new String[pParents.size()]);
/*      */     }
/*      */ 
/* 2338 */     return null;
/*      */   }
/*      */ 
/*      */   public static String getFromName(String fromHeader)
/*      */   {
/* 2357 */     if (fromHeader != null)
/*      */     {
/*      */       String fromName;
/*      */       String fromName;
/* 2361 */       if (fromHeader.indexOf("<") != -1) {
/* 2362 */         int nameEnd = fromHeader.indexOf("<");
/* 2363 */         if (nameEnd > 0) {
/* 2364 */           String fromName = fromHeader.substring(0, nameEnd).trim();
/* 2365 */           fromName = StringUtils.replace(fromName, "\"", " ").trim();
/*      */         }
/*      */         else
/*      */         {
/* 2369 */           int emailEnd = fromHeader.indexOf(">", nameEnd);
/* 2370 */           if (emailEnd - nameEnd > 1) {
/* 2371 */             return fromHeader.substring(nameEnd + 1, emailEnd);
/*      */           }
/*      */ 
/* 2374 */           return fromHeader;
/*      */         }
/*      */ 
/*      */       }
/* 2379 */       else if (fromHeader.indexOf("(") != -1) {
/* 2380 */         int nameStart = fromHeader.indexOf("(");
/* 2381 */         String fromName = fromHeader.substring(nameStart + 1, fromHeader.length() - 1);
/*      */ 
/* 2384 */         if ((fromName.length() < 1) && (nameStart != 0)) {
/* 2385 */           fromName = fromHeader.substring(0, nameStart);
/*      */ 
/* 2387 */           if (fromName.length() < 1) {
/* 2388 */             fromName = fromHeader;
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 2394 */         fromName = fromHeader;
/*      */       }
/*      */       try
/*      */       {
/* 2398 */         String str = getRFC2047DecodedString(fromName);
/* 2399 */         if (str != null) {
/* 2400 */           return str;
/*      */         }
/*      */ 
/* 2403 */         return "";
/*      */       }
/*      */       catch (javax.mail.internet.ParseException pe) {
/* 2406 */         return fromName;
/*      */       }
/*      */     }
/*      */ 
/* 2410 */     return "";
/*      */   }
/*      */ 
/*      */   public static String getFromEmail(String fromHeader)
/*      */   {
/* 2426 */     int index = 0;
/*      */ 
/* 2428 */     if (fromHeader != null)
/*      */     {
/* 2432 */       if (fromHeader.indexOf("\"") != -1) {
/* 2433 */         index = fromHeader.lastIndexOf("\"");
/*      */       }
/*      */ 
/* 2436 */       if (fromHeader.indexOf("<", index) != -1) {
/* 2437 */         int nameEnd = fromHeader.indexOf("<");
/* 2438 */         int emailEnd = fromHeader.indexOf(">", nameEnd);
/* 2439 */         if (emailEnd - nameEnd > 1) {
/* 2440 */           return fromHeader.substring(nameEnd + 1, emailEnd);
/*      */         }
/*      */ 
/* 2443 */         return fromHeader;
/*      */       }
/*      */ 
/* 2447 */       if (fromHeader.indexOf("(") != -1) {
/* 2448 */         int nameStart = fromHeader.indexOf("(");
/* 2449 */         return fromHeader.substring(0, nameStart != 0 ? nameStart - 1 : nameStart).trim();
/*      */       }
/*      */ 
/* 2453 */       return fromHeader;
/*      */     }
/*      */ 
/* 2457 */     return "";
/*      */   }
/*      */ 
/*      */   protected void getBody(StringBuffer buf, Part part)
/*      */     throws MessagingException, IOException
/*      */   {
/* 2471 */     if ((part.isMimeType("text/html")) && (!this.importHtmlEnabled) && (!this.attachmentsEnabled)) {
/* 2472 */       buf.append("[att1.html]\n");
/*      */     }
/* 2475 */     else if ((part.isMimeType("text/html")) && (this.importHtmlEnabled)) {
/*      */       try {
/* 2477 */         BufferedReader reader = getTextReader(part);
/* 2478 */         StringBuffer text = new StringBuffer();
/* 2479 */         String line = "";
/* 2480 */         while ((line = reader.readLine()) != null) {
/* 2481 */           text.append(line).append("\n");
/*      */         }
/*      */ 
/* 2485 */         buf.append(cleanseHTMLForImport(text.toString()));
/*      */       }
/*      */       catch (IOException e) {
/* 2488 */         String text = (String)part.getContent();
/* 2489 */         text = new String(text.getBytes(getCharacterSet(part.getContentType())), getCharacterSet(part.getContentType()));
/*      */ 
/* 2493 */         buf.append(cleanseHTMLForImport(text.toString()));
/*      */       }
/*      */ 
/*      */     }
/* 2499 */     else if ((part.isMimeType("text/plain")) || (part.isMimeType("text"))) {
/* 2500 */       if (part.getDisposition() == null) {
/*      */         try {
/* 2502 */           BufferedReader reader = getTextReader(part);
/* 2503 */           StringBuffer temp = new StringBuffer();
/* 2504 */           removeUUencodedAttachments(temp, reader);
/* 2505 */           buf.append(temp);
/*      */         }
/*      */         catch (IOException e) {
/* 2508 */           String text = (String)part.getContent();
/* 2509 */           text = new String(text.getBytes(getCharacterSet(part.getContentType())), getCharacterSet(part.getContentType()));
/*      */ 
/* 2511 */           buf.append(text);
/*      */         }
/*      */       }
/* 2514 */       else if (part.getDisposition().equalsIgnoreCase("attachment")) {
/* 2515 */         String filename = part.getFileName();
/* 2516 */         if ((!this.attachmentsEnabled) && (filename != null)) {
/* 2517 */           buf.append("[" + filename + "]\n");
/*      */         }
/* 2519 */         else if ((!this.attachmentsEnabled) && (filename == null))
/* 2520 */           buf.append("[att1.dat]\n");
/*      */       }
/*      */       else
/*      */       {
/*      */         try {
/* 2525 */           BufferedReader reader = getTextReader(part);
/* 2526 */           StringBuffer temp = new StringBuffer();
/* 2527 */           removeUUencodedAttachments(temp, reader);
/* 2528 */           buf.append(temp);
/*      */         }
/*      */         catch (IOException e) {
/*      */           try {
/* 2532 */             String text = (String)part.getContent();
/* 2533 */             text = new String(text.getBytes(getCharacterSet(part.getContentType())), getCharacterSet(part.getContentType()));
/*      */ 
/* 2535 */             buf.append(text);
/*      */           }
/*      */           catch (ClassCastException e1) {
/* 2538 */             Log.error(e1);
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/* 2545 */     else if ((part.isMimeType("multipart/alternative")) && (this.importHtmlEnabled)) {
/*      */       try {
/* 2547 */         Multipart mp = (Multipart)part.getContent();
/* 2548 */         int cnt = mp.getCount();
/* 2549 */         boolean foundHtml = false;
/*      */ 
/* 2551 */         for (int j = 0; j < cnt; j++) {
/* 2552 */           Part p = mp.getBodyPart(j);
/* 2553 */           if (p.isMimeType("text/html")) {
/* 2554 */             getBody(buf, p);
/* 2555 */             foundHtml = true;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2560 */         if (!foundHtml)
/* 2561 */           for (int j = 0; j < cnt; j++) {
/* 2562 */             Part p = mp.getBodyPart(j);
/* 2563 */             getBody(buf, p);
/*      */           }
/*      */       }
/*      */       catch (IllegalArgumentException iae)
/*      */       {
/* 2568 */         throw new MessagingException("Character set not recognized", iae);
/*      */       }
/*      */ 
/*      */     }
/* 2573 */     else if (part.isMimeType("multipart/*")) {
/*      */       try {
/* 2575 */         Multipart mp = (Multipart)part.getContent();
/* 2576 */         int cnt = mp.getCount();
/*      */ 
/* 2578 */         for (int j = 0; j < cnt; j++) {
/* 2579 */           Part p = mp.getBodyPart(j);
/* 2580 */           getBody(buf, p);
/*      */         }
/*      */       }
/*      */       catch (IllegalArgumentException iae) {
/* 2584 */         throw new MessagingException("Character set not recognized", iae);
/*      */       }
/*      */ 
/*      */     }
/* 2588 */     else if (part.isMimeType("message/rfc822")) {
/* 2589 */       if (!this.attachmentsEnabled) {
/* 2590 */         buf.append("[email.eml]\n");
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 2596 */       String disposition = part.getDisposition();
/* 2597 */       String filename = part.getFileName();
/*      */ 
/* 2599 */       if (disposition == null) {
/* 2600 */         if ((!this.attachmentsEnabled) && (filename != null)) {
/* 2601 */           buf.append("[" + filename + "]\n");
/*      */         }
/* 2603 */         else if ((!this.attachmentsEnabled) && (filename == null)) {
/* 2604 */           buf.append("[att1.dat]\n");
/*      */         }
/*      */       }
/* 2607 */       else if (disposition.equalsIgnoreCase("attachment")) {
/* 2608 */         if ((!this.attachmentsEnabled) && (filename != null)) {
/* 2609 */           buf.append("[" + filename + "]\n");
/*      */         }
/* 2611 */         else if ((!this.attachmentsEnabled) && (filename == null)) {
/* 2612 */           buf.append("[att1.dat]\n");
/*      */         }
/*      */ 
/*      */       }
/* 2616 */       else if ((!this.attachmentsEnabled) && (filename != null)) {
/* 2617 */         buf.append("[" + filename + "]\n");
/*      */       }
/* 2619 */       else if (filename == null)
/*      */         try {
/* 2621 */           BufferedReader reader = getTextReader(part);
/* 2622 */           StringBuffer temp = new StringBuffer();
/* 2623 */           removeUUencodedAttachments(temp, reader);
/* 2624 */           buf.append(temp);
/*      */         }
/*      */         catch (IOException e) {
/*      */           try {
/* 2628 */             String text = (String)part.getContent();
/* 2629 */             text = new String(text.getBytes(getCharacterSet(part.getContentType())), getCharacterSet(part.getContentType()));
/*      */ 
/* 2631 */             buf.append(text);
/*      */           }
/*      */           catch (ClassCastException e1) {
/* 2634 */             Log.error(e1);
/*      */           }
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static String cleanseHTMLForImport(String html)
/*      */   {
/* 2651 */     if ((html == null) || ("".equals(html))) {
/* 2652 */       return html;
/*      */     }
/*      */ 
/* 2656 */     String lchtml = html.toLowerCase();
/* 2657 */     int bStart = lchtml.indexOf("<body");
/* 2658 */     int bStartEnd = lchtml.indexOf('>', bStart + 5);
/* 2659 */     int bEnd = lchtml.indexOf("</body>");
/*      */ 
/* 2661 */     StringBuffer content = new StringBuffer();
/* 2662 */     if ((bStart != -1) && (bEnd != -1) && (bStartEnd < bEnd)) {
/* 2663 */       content.append(html.substring(bStartEnd + 1, bEnd));
/*      */     }
/*      */     else {
/* 2666 */       content.append(html);
/*      */     }
/*      */ 
/* 2670 */     content.insert(0, "<div id=\"jive-html-wrapper-div\">\n");
/* 2671 */     content.append("\n</div>");
/*      */ 
/* 2674 */     int sStart = lchtml.indexOf("<style");
/* 2675 */     int sStartEnd = lchtml.indexOf('>', sStart + 6);
/* 2676 */     int sEnd = lchtml.indexOf("</style>");
/*      */ 
/* 2678 */     if ((sStart != -1) && (sStart < bStart) && (sEnd != -1) && (sEnd < bStart) && (sStartEnd + 1 < sEnd)) {
/* 2679 */       content.insert(0, "\n</style>\n");
/* 2680 */       content.insert(0, html.substring(sStartEnd + 1, sEnd));
/* 2681 */       content.insert(0, "<style type=\"text/css\">\n");
/*      */     }
/*      */ 
/* 2684 */     return content.toString();
/*      */   }
/*      */ 
/*      */   protected BufferedReader getTextReader(Part part)
/*      */     throws MessagingException
/*      */   {
/*      */     try
/*      */     {
/* 2697 */       InputStream is = part.getInputStream();
/* 2698 */       String charset = getCharacterSet(part.getContentType());
/* 2699 */       InputStreamReader reader = new InputStreamReader(is, charset);
/* 2700 */       return new BufferedReader(reader);
/*      */     }
/*      */     catch (UnsupportedEncodingException e)
/*      */     {
/* 2704 */       throw new MessagingException(e.toString());
/*      */     }
/*      */     catch (IOException ioe) {
/* 2707 */       throw new MessagingException(ioe.toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected String getCharacterSet(String contentType) {
/* 2712 */     String charset = this.defaultCharacterSet;
/* 2713 */     if ((contentType != null) && (contentType.indexOf("charset") != -1))
/*      */     {
/* 2715 */       contentType = StringUtils.replace(contentType, "\r", "");
/* 2716 */       contentType = StringUtils.replace(contentType, "\n", "");
/*      */ 
/* 2718 */       contentType = StringUtils.replace(contentType, "\"", "");
/*      */ 
/* 2720 */       contentType = StringUtils.replace(contentType, "=", "");
/*      */ 
/* 2722 */       charset = contentType.substring(contentType.indexOf("charset") + 7);
/*      */ 
/* 2725 */       charset = StringUtils.replace(charset, "\"", "");
/*      */ 
/* 2727 */       charset = StringUtils.replace(charset, "=", "");
/*      */ 
/* 2730 */       while ((charset.indexOf(" ") == 0) && (charset.length() > 1)) {
/* 2731 */         charset = charset.substring(1);
/*      */       }
/*      */ 
/* 2735 */       if (charset.indexOf(" ") != -1) {
/* 2736 */         charset = MimeUtility.javaCharset(charset.substring(0, charset.indexOf(" ")));
/*      */       }
/*      */ 
/* 2739 */       if (charset.indexOf(";") != -1) {
/* 2740 */         charset = MimeUtility.javaCharset(charset.substring(0, charset.indexOf(";")));
/*      */       }
/*      */ 
/* 2744 */       String test = new String();
/*      */       try {
/* 2746 */         test.getBytes(charset);
/*      */       }
/*      */       catch (UnsupportedEncodingException e)
/*      */       {
/* 2750 */         if (Log.isDebugEnabled()) {
/* 2751 */           Log.debug("Character set specified in message is invalid or unknown: " + charset + ", defaulting to " + this.defaultCharacterSet);
/*      */         }
/*      */ 
/* 2754 */         Log.warn("Character set specified in message is invalid or unknown: " + charset);
/* 2755 */         charset = this.defaultCharacterSet;
/*      */       }
/*      */     }
/*      */ 
/* 2759 */     return charset;
/*      */   }
/*      */ 
/*      */   protected void cleanup()
/*      */   {
/*      */   }
/*      */ 
/*      */   public String getProtocol()
/*      */   {
/* 2779 */     return this.protocol;
/*      */   }
/*      */ 
/*      */   public void setProtocol(String protocol)
/*      */   {
/* 2788 */     if ((protocol != null) && (!protocol.equals("")))
/* 2789 */       this.protocol = protocol;
/*      */   }
/*      */ 
/*      */   public int getPort()
/*      */   {
/* 2799 */     return this.port;
/*      */   }
/*      */ 
/*      */   public void setPort(int port)
/*      */   {
/* 2810 */     if ((port > 1) && (port < 65536))
/* 2811 */       this.port = port;
/*      */   }
/*      */ 
/*      */   public String getHost()
/*      */   {
/* 2821 */     return this.host;
/*      */   }
/*      */ 
/*      */   public void setHost(String host)
/*      */   {
/* 2830 */     if ((host != null) && (!host.equals("")))
/* 2831 */       this.host = host;
/*      */   }
/*      */ 
/*      */   public String getUsername()
/*      */   {
/* 2841 */     return this.username;
/*      */   }
/*      */ 
/*      */   public void setUsername(String username)
/*      */   {
/* 2850 */     this.username = username;
/*      */   }
/*      */ 
/*      */   public String getPassword()
/*      */   {
/* 2859 */     return this.password;
/*      */   }
/*      */ 
/*      */   public void setPassword(String password)
/*      */   {
/* 2868 */     this.password = password;
/*      */   }
/*      */ 
/*      */   public String getMailbox()
/*      */   {
/* 2877 */     return this.mailbox;
/*      */   }
/*      */ 
/*      */   public void setMailbox(String mailbox)
/*      */   {
/* 2886 */     this.mailbox = mailbox;
/*      */   }
/*      */ 
/*      */   public String getTemporaryParentBody()
/*      */   {
/* 2908 */     return this.temporaryParentBody;
/*      */   }
/*      */ 
/*      */   public void setTemporaryParentBody(String temporaryParentBody)
/*      */   {
/* 2930 */     if ((temporaryParentBody != null) && (!"".equals(temporaryParentBody)))
/* 2931 */       this.temporaryParentBody = temporaryParentBody;
/*      */   }
/*      */ 
/*      */   public boolean isDeleteEnabled()
/*      */   {
/* 2942 */     return this.deleteEnabled;
/*      */   }
/*      */ 
/*      */   public void setDeleteEnabled(boolean deleteEnabled)
/*      */   {
/* 2953 */     this.deleteEnabled = deleteEnabled;
/*      */   }
/*      */ 
/*      */   public boolean isDebugEnabled()
/*      */   {
/* 2962 */     return this.debugEnabled;
/*      */   }
/*      */ 
/*      */   public void setDebugEnabled(boolean debugEnabled)
/*      */   {
/* 2971 */     this.debugEnabled = debugEnabled;
/*      */   }
/*      */ 
/*      */   public boolean isAttachmentsEnabled()
/*      */   {
/* 2980 */     return this.attachmentsEnabled;
/*      */   }
/*      */ 
/*      */   public void setAttachmentsEnabled(boolean attachmentEnabled)
/*      */   {
/* 2989 */     this.attachmentsEnabled = attachmentEnabled;
/*      */   }
/*      */ 
/*      */   public boolean isEmailToUserMappingEnabled()
/*      */   {
/* 2998 */     return this.emailToUserMappingEnabled;
/*      */   }
/*      */ 
/*      */   public void setEmailToUserMappingEnabled(boolean emailToUserMappingEnabled)
/*      */   {
/* 3008 */     this.emailToUserMappingEnabled = emailToUserMappingEnabled;
/*      */   }
/*      */ 
/*      */   public boolean isImportHtmlEnabled()
/*      */   {
/* 3017 */     return this.importHtmlEnabled;
/*      */   }
/*      */ 
/*      */   public void setImportHtmlEnabled(boolean importHtmlEnabled)
/*      */   {
/* 3028 */     this.importHtmlEnabled = importHtmlEnabled;
/*      */   }
/*      */ 
/*      */   public String getDefaultCharacterSet()
/*      */   {
/* 3039 */     return this.defaultCharacterSet;
/*      */   }
/*      */ 
/*      */   public void setDefaultCharacterSet(String defaultCharacterSet)
/*      */   {
/* 3050 */     if ((defaultCharacterSet != null) && (!"".equals(defaultCharacterSet)))
/*      */       try
/*      */       {
/* 3053 */         "testing".getBytes(defaultCharacterSet);
/* 3054 */         this.defaultCharacterSet = defaultCharacterSet;
/*      */       }
/*      */       catch (UnsupportedEncodingException e) {
/* 3057 */         Log.error("Default character set " + defaultCharacterSet + " is not a valid " + "character set for this JDK");
/*      */       }
/*      */   }
/*      */ 
/*      */   public String getReplyPrefixes()
/*      */   {
/* 3072 */     String prefixes = "";
/* 3073 */     String delim = "";
/* 3074 */     for (int i = 0; i < this.replyPrefixes.length; i++) {
/* 3075 */       prefixes = prefixes + delim;
/* 3076 */       prefixes = prefixes + this.replyPrefixes[i];
/* 3077 */       delim = ",";
/*      */     }
/*      */ 
/* 3080 */     return prefixes;
/*      */   }
/*      */ 
/*      */   public void setReplyPrefixes(String replyPrefixes)
/*      */   {
/* 3091 */     if (replyPrefixes == null) {
/* 3092 */       return;
/*      */     }
/*      */ 
/* 3095 */     StringTokenizer st = new StringTokenizer(replyPrefixes, ",");
/* 3096 */     ArrayList prefixes = new ArrayList();
/* 3097 */     while (st.hasMoreElements()) {
/* 3098 */       String prefix = (String)st.nextElement();
/* 3099 */       prefixes.add(prefix);
/*      */     }
/*      */ 
/* 3102 */     this.replyPrefixes = ((String[])prefixes.toArray(new String[prefixes.size()]));
/*      */   }
/*      */ 
/*      */   public boolean isSubjectParentageCheckEnabled()
/*      */   {
/* 3111 */     return this.subjectParentageCheckEnabled;
/*      */   }
/*      */ 
/*      */   public void setSubjectParentageCheckEnabled(boolean subjectParentageCheckEnabled)
/*      */   {
/* 3121 */     this.subjectParentageCheckEnabled = subjectParentageCheckEnabled;
/*      */   }
/*      */ 
/*      */   public void stop()
/*      */   {
/* 3128 */     this.stopFlag = true;
/*      */   }
/*      */ 
/*      */   public String getEmptySubject()
/*      */   {
/* 3137 */     return this.emptySubject;
/*      */   }
/*      */ 
/*      */   public void setEmptySubject(String emptySubject)
/*      */   {
/* 3146 */     if (emptySubject != null)
/* 3147 */       this.emptySubject = emptySubject;
/*      */   }
/*      */ 
/*      */   protected class InsertCacheItem
/*      */   {
/* 3163 */     private ForumThread thread = null;
/* 3164 */     private ForumMessage parent = null;
/* 3165 */     private ForumMessage message = null;
/* 3166 */     private Forum forum = null;
/* 3167 */     private ArrayList children = new ArrayList();
/*      */ 
/*      */     public InsertCacheItem(Forum forum, ForumThread thread, ForumMessage parent, ForumMessage message)
/*      */     {
/* 3172 */       this.forum = forum;
/* 3173 */       this.thread = thread;
/* 3174 */       this.parent = parent;
/* 3175 */       this.message = message;
/*      */     }
/*      */ 
/*      */     public boolean containsMessage(String messageID) {
/* 3179 */       if ((this.message != null) && (this.message.getUnfilteredProperty(JavaMailGateway.this.gatewayMessageId).equals(messageID))) {
/* 3180 */         return true;
/*      */       }
/*      */ 
/* 3183 */       return false;
/*      */     }
/*      */ 
/*      */     public void insert()
/*      */     {
/*      */       try {
/* 3189 */         if ((this.thread != null) && (this.parent != null) && (this.message != null)) {
/* 3190 */           this.thread.addMessage(this.parent, this.message);
/*      */         }
/* 3192 */         else if ((this.thread == null) && (this.parent != null) && (this.message != null)) {
/* 3193 */           this.thread = this.forum.createThread(this.parent);
/* 3194 */           this.forum.addThread(this.thread);
/* 3195 */           this.thread.addMessage(this.parent, this.message);
/*      */         }
/* 3197 */         else if ((this.thread == null) && (this.parent == null) && (this.message != null)) {
/* 3198 */           this.thread = this.forum.createThread(this.message);
/* 3199 */           this.forum.addThread(this.thread);
/*      */         }
/*      */ 
/* 3202 */         Iterator kids = this.children.iterator();
/* 3203 */         while (kids.hasNext()) {
/* 3204 */           InsertCacheItem child = (InsertCacheItem)kids.next();
/* 3205 */           child.setThread(this.thread);
/* 3206 */           child.setParent(this.message);
/*      */         }
/*      */ 
/* 3212 */         SearchManager searchManager = JavaMailGateway.this.factory.getSearchManager();
/* 3213 */         Date lastIndexed = searchManager.getLastIndexedDate();
/*      */ 
/* 3215 */         if (this.message.getModificationDate().compareTo(lastIndexed) <= 0)
/* 3216 */           searchManager.addToIndex(this.message);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 3220 */         Log.error("Db exception thrown importing message into forum \"" + this.forum.getName() + "\"", e);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void setThread(ForumThread thread)
/*      */     {
/* 3226 */       this.thread = thread;
/*      */     }
/*      */ 
/*      */     public void setParent(ForumMessage parent) {
/* 3230 */       this.parent = parent;
/*      */     }
/*      */ 
/*      */     public void addChild(InsertCacheItem child) {
/* 3234 */       this.children.add(child);
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.JavaMailGateway
 * JD-Core Version:    0.6.2
 */
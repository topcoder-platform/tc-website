/*     */ package com.jivesoftware.forum.gateway;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.TreeWalker;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.forum.database.DbForumMessage;
/*     */ import dog.mail.nntp.NNTPTransport;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Multipart;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.URLName;
/*     */ import javax.mail.internet.AddressException;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import javax.mail.internet.MimeMessage.RecipientType;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ import javax.mail.internet.NewsAddress;
/*     */ 
/*     */ public class NewsgroupExporter
/*     */   implements GatewayExporter
/*     */ {
/*     */   private NNTPGateway gateway;
/*  36 */   private int lastMessageNumberSeen = -1;
/*  37 */   private String specialCharacterSet = null;
/*     */   public static final String GATEWAY_MESSAGE_ID = "NNTP-Message-ID";
/*     */   public static final String GATEWAY_PARENT_ID = "NNTP-Parent-ID";
/*     */ 
/*     */   public NewsgroupExporter(ForumFactory factory, Forum forum)
/*     */   {
/*  55 */     this.gateway = new NNTPGateway(factory, forum);
/*     */   }
/*     */ 
/*     */   public synchronized void exportData(ForumMessage forumMessage)
/*     */     throws GatewayException
/*     */   {
/*  72 */     this.gateway.exportData(forumMessage);
/*     */   }
/*     */ 
/*     */   public synchronized void exportData(ForumMessage[] forumMessages)
/*     */     throws GatewayException
/*     */   {
/*  88 */     this.gateway.exportData(forumMessages);
/*     */   }
/*     */ 
/*     */   public void stop() throws GatewayException {
/*  92 */     this.gateway.stopFlag = true;
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 103 */     return this.gateway.getUsername();
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 112 */     if ("".equals(username)) {
/* 113 */       username = null;
/*     */     }
/* 115 */     this.gateway.setUsername(username);
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 125 */     return this.gateway.getPassword();
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 134 */     if ("".equals(password)) {
/* 135 */       password = null;
/*     */     }
/* 137 */     this.gateway.setPassword(password);
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 147 */     return this.gateway.getPort();
/*     */   }
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 157 */     this.gateway.setPort(port);
/*     */ 
/* 160 */     this.gateway.session = null;
/*     */   }
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 170 */     return this.gateway.getHost();
/*     */   }
/*     */ 
/*     */   public void setHost(String host)
/*     */   {
/* 180 */     this.gateway.setHost(host);
/*     */ 
/* 183 */     this.gateway.session = null;
/*     */   }
/*     */ 
/*     */   public String getNewsgroup()
/*     */   {
/* 192 */     return this.gateway.getMailbox();
/*     */   }
/*     */ 
/*     */   public void setNewsgroup(String newsgroup)
/*     */   {
/* 201 */     this.gateway.setMailbox(newsgroup);
/*     */ 
/* 204 */     this.gateway.session = null;
/*     */   }
/*     */ 
/*     */   public boolean isDebugEnabled()
/*     */   {
/* 214 */     return this.gateway.isDebugEnabled();
/*     */   }
/*     */ 
/*     */   public void setDebugEnabled(boolean debugEnabled)
/*     */   {
/* 224 */     this.gateway.setDebugEnabled(debugEnabled);
/*     */ 
/* 227 */     this.gateway.session = null;
/*     */   }
/*     */ 
/*     */   public boolean isEmailPrefEnabled()
/*     */   {
/* 238 */     return this.gateway.isEmailPrefEnabled();
/*     */   }
/*     */ 
/*     */   public void setEmailPrefEnabled(boolean enabled)
/*     */   {
/* 249 */     this.gateway.setEmailPrefEnabled(enabled);
/*     */   }
/*     */ 
/*     */   public String getDefaultFromAddress()
/*     */   {
/* 259 */     return this.gateway.getDefaultFromAddress();
/*     */   }
/*     */ 
/*     */   public void setDefaultFromAddress(String address)
/*     */   {
/* 269 */     if ("".equals(address)) {
/* 270 */       address = null;
/*     */     }
/* 272 */     this.gateway.setDefaultFromAddress(address);
/*     */   }
/*     */ 
/*     */   public String getOrganization()
/*     */   {
/* 282 */     return this.gateway.getOrganization();
/*     */   }
/*     */ 
/*     */   public void setOrganization(String organization)
/*     */   {
/* 292 */     this.gateway.setOrganization(organization);
/*     */   }
/*     */ 
/*     */   public void setLastMessageNumberSeen(int messageNumber)
/*     */   {
/* 306 */     if (messageNumber > 0)
/* 307 */       this.lastMessageNumberSeen = messageNumber;
/*     */   }
/*     */ 
/*     */   public int getLastMessageNumberSeen()
/*     */   {
/* 323 */     return this.lastMessageNumberSeen;
/*     */   }
/*     */ 
/*     */   public boolean isUpdateMessageIDOnExport()
/*     */   {
/* 339 */     return this.gateway.isUpdateMessageID();
/*     */   }
/*     */ 
/*     */   public void setUpdateMessageIDOnExport(boolean updateMessageID)
/*     */   {
/* 355 */     this.gateway.setUpdateMessageID(updateMessageID);
/*     */   }
/*     */ 
/*     */   public boolean isAllowExportAgain()
/*     */   {
/* 365 */     return this.gateway.isExportIgnoreMessageID();
/*     */   }
/*     */ 
/*     */   public void setAllowExportAgain(boolean allowExportAgain)
/*     */   {
/* 383 */     this.gateway.setExportIgnoreMessageID(allowExportAgain);
/*     */   }
/*     */ 
/*     */   public boolean isAttachmentsEnabled()
/*     */   {
/* 392 */     return this.gateway.isAttachmentsEnabled();
/*     */   }
/*     */ 
/*     */   public void setAttachmentsEnabled(boolean attachmentsEnabled)
/*     */   {
/* 404 */     this.gateway.setAttachmentsEnabled(attachmentsEnabled);
/*     */   }
/*     */ 
/*     */   public String getSpecialCharacterSet()
/*     */   {
/* 413 */     return this.specialCharacterSet;
/*     */   }
/*     */ 
/*     */   public void setSpecialCharacterSet(String specialCharacterSet)
/*     */   {
/* 424 */     this.specialCharacterSet = specialCharacterSet;
/*     */   }
/*     */   private class NNTPGateway extends JavaMailGateway implements GatewayExporter {
/* 432 */     protected Session session = null;
/* 433 */     protected String organization = null;
/* 434 */     protected String defaultFromAddress = null;
/* 435 */     protected boolean emailPrefEnabled = true;
/* 436 */     protected boolean updateMessageID = true;
/* 437 */     protected boolean exportIgnoreMessageID = false;
/*     */     private NNTPTransport transport;
/*     */ 
/*     */     public String getOrganization() {
/* 442 */       return this.organization;
/*     */     }
/*     */ 
/*     */     public void setOrganization(String organization) {
/* 446 */       this.organization = organization;
/*     */     }
/*     */ 
/*     */     public String getDefaultFromAddress() {
/* 450 */       return this.defaultFromAddress;
/*     */     }
/*     */ 
/*     */     public void setDefaultFromAddress(String address) {
/* 454 */       this.defaultFromAddress = address;
/*     */     }
/*     */ 
/*     */     public boolean isEmailPrefEnabled() {
/* 458 */       return this.emailPrefEnabled;
/*     */     }
/*     */ 
/*     */     public void setEmailPrefEnabled(boolean enabled) {
/* 462 */       this.emailPrefEnabled = enabled;
/*     */     }
/*     */ 
/*     */     public boolean isUpdateMessageID() {
/* 466 */       return this.updateMessageID;
/*     */     }
/*     */ 
/*     */     public void setUpdateMessageID(boolean updateMessageID) {
/* 470 */       this.updateMessageID = updateMessageID;
/*     */     }
/*     */ 
/*     */     public boolean isExportIgnoreMessageID() {
/* 474 */       return this.exportIgnoreMessageID;
/*     */     }
/*     */ 
/*     */     public void setExportIgnoreMessageID(boolean exportIgnoreMessageID) {
/* 478 */       this.exportIgnoreMessageID = exportIgnoreMessageID;
/*     */     }
/*     */ 
/*     */     public NNTPGateway(ForumFactory factory, Forum forum) {
/* 482 */       super(forum);
/* 483 */       setPort(119);
/* 484 */       setProtocol("nntp");
/*     */ 
/* 486 */       this.gatewayMessageId = "NNTP-Message-ID";
/* 487 */       this.gatewayParentId = "NNTP-Parent-ID";
/*     */     }
/*     */ 
/*     */     public synchronized void exportData(ForumMessage forumMessage) throws GatewayException
/*     */     {
/* 492 */       if ((this.host == null) || (this.mailbox == null) || (this.defaultFromAddress == null)) {
/* 493 */         DbForumFactory factory = DbForumFactory.getInstance();
/* 494 */         Forum forum = null;
/*     */         try
/*     */         {
/* 497 */           forum = factory.getForum(this.forumID);
/* 498 */           Log.error("Error exporting message via NNTP gateway in forum " + forum.getName() + ", Reason: Required properties are not all set");
/*     */         }
/*     */         catch (ForumNotFoundException e1)
/*     */         {
/*     */         }
/* 503 */         throw new GatewayException("Required properties are not all set.");
/*     */       }
/*     */ 
/* 506 */       if (!isExportable(forumMessage)) {
/* 507 */         return;
/*     */       }
/*     */       try
/*     */       {
/* 511 */         connectToNNTPServer();
/* 512 */         exportMessage(forumMessage);
/*     */       }
/*     */       catch (MessagingException e) {
/* 515 */         DbForumFactory factory = DbForumFactory.getInstance();
/* 516 */         Forum forum = null;
/*     */         try
/*     */         {
/* 519 */           forum = factory.getForum(this.forumID);
/* 520 */           Log.error("Error exporting message via NNTP gateway in forum " + forum.getName() + ", Reason: " + e.getMessage());
/*     */         }
/*     */         catch (ForumNotFoundException e1)
/*     */         {
/*     */         }
/* 525 */         throw new GatewayException(e);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 529 */         if ((this.updateMessageID) && (!this.exportIgnoreMessageID)) {
/*     */           try
/*     */           {
/* 532 */             DbForumFactory factory = DbForumFactory.getInstance();
/* 533 */             DbForumMessage m = (DbForumMessage)factory.getMessage(forumMessage.getID());
/* 534 */             m.setProperty("jiveGatewayRetryExport", "true");
/*     */           }
/*     */           catch (Exception e2) {
/* 537 */             Log.error(e2);
/*     */           }
/*     */         }
/*     */ 
/* 541 */         if ((e instanceof GatewayException)) {
/* 542 */           throw ((GatewayException)e);
/*     */         }
/*     */ 
/* 545 */         throw new GatewayException(e);
/*     */       }
/*     */       finally
/*     */       {
/* 549 */         if (this.transport != null)
/*     */           try {
/* 551 */             disconnectFromNNTPServer();
/*     */           }
/*     */           catch (MessagingException e)
/*     */           {
/*     */           }
/* 556 */         this.transport = null;
/* 557 */         this.session = null;
/*     */       }
/*     */     }
/*     */ 
/*     */     public synchronized void exportData(ForumMessage[] forumMessage) throws GatewayException
/*     */     {
/* 563 */       if ((this.host == null) || (this.mailbox == null) || (this.defaultFromAddress == null)) {
/* 564 */         throw new GatewayException("Required properties are not all set.");
/*     */       }
/*     */ 
/* 567 */       int x = 0;
/*     */       try {
/* 569 */         connectToNNTPServer();
/*     */ 
/* 571 */         for (; x < forumMessage.length; x++)
/*     */         {
/* 573 */           if (this.stopFlag)
/*     */           {
/*     */             break;
/*     */           }
/* 577 */           if (isExportable(forumMessage[x]))
/*     */           {
/* 581 */             exportMessage(forumMessage[x]);
/*     */           }
/*     */         }
/*     */       } catch (MessagingException e) {
/* 585 */         DbForumFactory factory = DbForumFactory.getInstance();
/* 586 */         Forum forum = null;
/*     */         try
/*     */         {
/* 589 */           forum = factory.getForum(this.forumID);
/* 590 */           Log.error("Error exporting message via NNTP gateway in forum " + forum.getName() + ", Reason: " + e.getMessage());
/*     */         }
/*     */         catch (ForumNotFoundException e1)
/*     */         {
/*     */         }
/* 595 */         throw new GatewayException(e);
/*     */       }
/*     */       catch (Exception e) {
/* 598 */         if ((e instanceof GatewayException)) {
/* 599 */           throw ((GatewayException)e);
/*     */         }
/*     */ 
/* 602 */         throw new GatewayException(e);
/*     */       }
/*     */       finally
/*     */       {
/* 606 */         if (this.transport != null)
/*     */           try {
/* 608 */             disconnectFromNNTPServer();
/*     */           }
/*     */           catch (MessagingException e)
/*     */           {
/*     */           }
/* 613 */         this.transport = null;
/* 614 */         this.session = null;
/*     */       }
/*     */     }
/*     */ 
/*     */     private void retrieveSession()
/*     */     {
/* 620 */       if (this.session == null) {
/* 621 */         this.session = Session.getDefaultInstance(new Properties(), null);
/* 622 */         this.session.setDebug(this.debugEnabled);
/*     */       }
/*     */     }
/*     */ 
/*     */     private synchronized void connectToNNTPServer() throws MessagingException {
/* 627 */       retrieveSession();
/*     */       try
/*     */       {
/* 630 */         if (this.transport != null) this.transport.close(); 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/* 634 */       URLName url = new URLName(this.protocol, this.host, this.port, this.mailbox, this.username, this.password);
/* 635 */       this.transport = new NNTPTransport(this.session, url);
/* 636 */       this.transport.connect(this.host, this.port, this.username, this.password);
/*     */     }
/*     */ 
/*     */     private synchronized void disconnectFromNNTPServer() throws MessagingException {
/* 640 */       if (this.transport != null) {
/* 641 */         this.transport.close();
/* 642 */         this.transport = null;
/*     */       }
/*     */     }
/*     */ 
/*     */     public void exportMessage(ForumMessage forumMessage)
/*     */       throws MessagingException, GatewayException, UnauthorizedException
/*     */     {
/* 649 */       MimeMessage message = new MimeMessage(this.session);
/* 650 */       NewsAddress to = new NewsAddress(this.mailbox);
/* 651 */       String subject = !"".equals(forumMessage.getUnfilteredSubject()) ? forumMessage.getUnfilteredSubject() : " ";
/*     */ 
/* 654 */       message.setFrom(getFromAddress(forumMessage));
/* 655 */       message.setRecipient(MimeMessage.RecipientType.NEWSGROUPS, to);
/* 656 */       message.setSubject(subject, getMimeCharacterEncoding());
/*     */ 
/* 659 */       SimpleDateFormat format = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
/*     */ 
/* 661 */       format.setTimeZone(JiveGlobals.getTimeZone());
/* 662 */       message.setHeader("Date", format.format(forumMessage.getCreationDate()));
/*     */ 
/* 665 */       message.setHeader("Content-Transfer-Encoding", "8bit");
/*     */ 
/* 668 */       if (this.organization != null) {
/* 669 */         message.setHeader("Organization", this.organization);
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 676 */         ForumThread thread = forumMessage.getForumThread();
/* 677 */         TreeWalker tree = thread.getTreeWalker();
/* 678 */         ForumMessage parent = tree.getParent(forumMessage);
/* 679 */         String parentId = parent.getUnfilteredProperty("NNTP-Message-ID");
/* 680 */         if ((parentId != null) && (!parentId.equals(""))) {
/* 681 */           message.setHeader("References", parentId);
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (ForumMessageNotFoundException fmnfe)
/*     */       {
/*     */       }
/*     */ 
/* 689 */       addContent(forumMessage, message);
/*     */ 
/* 692 */       message.setHeader("Content-Transfer-Encoding", "8bit");
/*     */ 
/* 695 */       message.saveChanges();
/*     */ 
/* 697 */       if ((this.transport == null) || (!this.transport.isConnected())) {
/* 698 */         connectToNNTPServer();
/*     */       }
/* 700 */       this.transport.sendMessage(message, message.getRecipients(MimeMessage.RecipientType.NEWSGROUPS));
/*     */ 
/* 702 */       if ((this.updateMessageID) || (!this.exportIgnoreMessageID))
/*     */       {
/* 710 */         if (forumMessage.getForumThread() == null)
/*     */         {
/* 713 */           forumMessage.setProperty(this.gatewayMessageId, message.getMessageID());
/*     */         }
/*     */         else
/*     */         {
/* 717 */           DbForumFactory factory = DbForumFactory.getInstance();
/*     */           try {
/* 719 */             ForumMessage m = factory.getMessage(forumMessage.getID());
/*     */ 
/* 723 */             m.setProperty(this.gatewayMessageId, message.getMessageID());
/*     */           }
/*     */           catch (ForumMessageNotFoundException e) {
/* 726 */             Log.error(e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     private boolean isExportable(ForumMessage forumMessage)
/*     */     {
/* 739 */       if (((forumMessage.getUnfilteredProperty("NNTP-Message-ID") != null) && (!this.exportIgnoreMessageID)) || (forumMessage.getUnfilteredProperty("Jive-Created-Message") != null))
/*     */       {
/* 743 */         return false;
/*     */       }
/*     */ 
/* 746 */       return true;
/*     */     }
/*     */ 
/*     */     private String getMimeCharacterEncoding()
/*     */     {
/* 751 */       if (NewsgroupExporter.this.specialCharacterSet != null)
/*     */       {
/* 753 */         return MimeUtility.mimeCharset(NewsgroupExporter.this.specialCharacterSet);
/*     */       }
/*     */ 
/* 758 */       return MimeUtility.mimeCharset(JiveGlobals.getCharacterEncoding());
/*     */     }
/*     */ 
/*     */     private InternetAddress getFromAddress(ForumMessage forumMessage)
/*     */     {
/* 772 */       InternetAddress fromAddress = null;
/*     */       try
/*     */       {
/* 775 */         if (!forumMessage.isAnonymous()) {
/* 776 */           User user = forumMessage.getUser();
/* 777 */           String email = null;
/*     */           String name;
/*     */           String name;
/* 779 */           if (user.isNameVisible()) {
/* 780 */             name = user.getName();
/*     */           }
/*     */           else {
/* 783 */             name = user.getUsername();
/*     */           }
/*     */ 
/* 787 */           if ((!user.isEmailVisible()) && (this.emailPrefEnabled)) {
/* 788 */             email = this.defaultFromAddress;
/*     */           }
/*     */           else {
/* 791 */             email = user.getEmail();
/*     */           }
/* 793 */           fromAddress = new InternetAddress(email, name, getMimeCharacterEncoding());
/*     */         }
/* 797 */         else if ((forumMessage.getUnfilteredProperty("name") != null) && (forumMessage.getUnfilteredProperty("email") != null))
/*     */         {
/* 800 */           String name = forumMessage.getUnfilteredProperty("name");
/* 801 */           String email = forumMessage.getUnfilteredProperty("email");
/* 802 */           fromAddress = new InternetAddress(email, name, getMimeCharacterEncoding());
/*     */         }
/* 806 */         else if (forumMessage.getProperty("name") != null) {
/* 807 */           String name = forumMessage.getUnfilteredProperty("name");
/* 808 */           fromAddress = new InternetAddress(this.defaultFromAddress, name, getMimeCharacterEncoding());
/*     */         }
/* 813 */         else if (forumMessage.getUnfilteredProperty("email") != null) {
/* 814 */           String email = forumMessage.getUnfilteredProperty("email");
/* 815 */           fromAddress = new InternetAddress(email, getMimeCharacterEncoding());
/*     */         }
/*     */         else
/*     */         {
/* 819 */           fromAddress = new InternetAddress(this.defaultFromAddress);
/*     */         }
/*     */       }
/*     */       catch (UnsupportedEncodingException e) {
/* 823 */         fromAddress = null;
/*     */       }
/*     */       catch (AddressException e) {
/* 826 */         fromAddress = null;
/*     */       }
/*     */ 
/* 829 */       return fromAddress;
/*     */     }
/*     */ 
/*     */     private void addContent(ForumMessage forumMessage, MimeMessage message)
/*     */       throws GatewayException
/*     */     {
/*     */       try
/*     */       {
/* 843 */         StringBuffer body = new StringBuffer(forumMessage.getUnfilteredBody());
/* 844 */         Forum forum = NewsgroupExporter.this.gateway.factory.getForum(NewsgroupExporter.this.gateway.forumID);
/* 845 */         GatewayManager manager = forum.getGatewayManager();
/* 846 */         body.append(manager.getTranslatedFooter(forumMessage));
/*     */ 
/* 849 */         if ((this.attachmentsEnabled) && (forumMessage.getAttachmentCount() > 0))
/*     */         {
/* 851 */           Multipart multipart = new MimeMultipart();
/* 852 */           MimeBodyPart messageBodyPart = new MimeBodyPart();
/* 853 */           messageBodyPart.setText(body.toString(), getMimeCharacterEncoding());
/* 854 */           messageBodyPart.setDisposition("inline");
/* 855 */           multipart.addBodyPart(messageBodyPart);
/* 856 */           Iterator iter = forumMessage.getAttachments();
/*     */ 
/* 859 */           while (iter.hasNext()) {
/* 860 */             Attachment attachment = (Attachment)iter.next();
/* 861 */             AttachmentDataSource source = new AttachmentDataSource(attachment);
/* 862 */             messageBodyPart = new MimeBodyPart();
/*     */ 
/* 864 */             messageBodyPart.setDisposition("attachment");
/* 865 */             messageBodyPart.setFileName(attachment.getName());
/* 866 */             messageBodyPart.setDataHandler(new DataHandler(source));
/* 867 */             multipart.addBodyPart(messageBodyPart);
/*     */           }
/*     */ 
/* 871 */           message.setContent(multipart);
/*     */         }
/*     */         else {
/* 874 */           message.setText(body.toString(), getMimeCharacterEncoding());
/*     */         }
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 878 */         throw new GatewayException("ForumNotFoundException thrown", e);
/*     */       }
/*     */       catch (MessagingException e) {
/* 881 */         throw new GatewayException("MessagingException thrown", e);
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 884 */         throw new GatewayException("UnauthorizedException thrown", e);
/*     */       }
/*     */       catch (IOException e) {
/* 887 */         throw new GatewayException("IOException thrown", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.NewsgroupExporter
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.gateway;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.sun.net.ssl.internal.ssl.Provider;
/*     */ import java.security.Security;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Store;
/*     */ import javax.mail.URLName;
/*     */ 
/*     */ public class ImapImporter
/*     */   implements GatewayImporter
/*     */ {
/*     */   private imapGateway gateway;
/*     */   public static final String GATEWAY_MESSAGE_ID = "Email-Message-ID";
/*     */   public static final String GATEWAY_PARENT_ID = "Email-Parent-ID";
/*  59 */   private static Map forumLock = Collections.synchronizedMap(new HashMap());
/*     */ 
/*     */   public ImapImporter(ForumFactory factory, Forum forum)
/*     */   {
/*  66 */     this.gateway = new imapGateway(factory, forum);
/*  67 */     Log.debug("Creating new ImapImporter for forum " + forum.getName());
/*  68 */     synchronized (forumLock) {
/*  69 */       Log.debug("Locking forum " + forum.getName() + " for import");
/*  70 */       if (forumLock.get(new Long(this.gateway.forumID)) == null)
/*  71 */         forumLock.put(new Long(this.gateway.forumID), new Long(this.gateway.forumID));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void importData(Date afterDate)
/*     */     throws GatewayException
/*     */   {
/*  79 */     Log.debug("Importing via ImapGateway messages new than " + afterDate);
/*  80 */     synchronized (forumLock.get(new Long(this.gateway.forumID))) {
/*  81 */       this.gateway.importData(afterDate);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stop() throws GatewayException {
/*  86 */     this.gateway.stop();
/*     */   }
/*     */ 
/*     */   public String getHost()
/*     */   {
/*  98 */     return this.gateway.getHost();
/*     */   }
/*     */ 
/*     */   public void setHost(String host)
/*     */   {
/* 108 */     this.gateway.setHost(host);
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 118 */     return this.gateway.getPort();
/*     */   }
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 128 */     this.gateway.setPort(port);
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 138 */     return this.gateway.getUsername();
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 148 */     this.gateway.setUsername(username);
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 158 */     return this.gateway.getPassword();
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 168 */     this.gateway.setPassword(password);
/*     */   }
/*     */ 
/*     */   public String getFolder()
/*     */   {
/* 178 */     return this.gateway.getMailbox();
/*     */   }
/*     */ 
/*     */   public void setFolder(String folder)
/*     */   {
/* 189 */     if (folder != null) {
/* 190 */       this.gateway.setMailbox(folder);
/*     */     }
/*     */     else
/* 193 */       this.gateway.setMailbox("INBOX");
/*     */   }
/*     */ 
/*     */   public boolean isDeleteEnabled()
/*     */   {
/* 206 */     return this.gateway.isDeleteEnabled();
/*     */   }
/*     */ 
/*     */   public void setDeleteEnabled(boolean deleteEnabled)
/*     */   {
/* 218 */     this.gateway.setDeleteEnabled(deleteEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isDebugEnabled()
/*     */   {
/* 229 */     return this.gateway.isDebugEnabled();
/*     */   }
/*     */ 
/*     */   public void setDebugEnabled(boolean debugEnabled)
/*     */   {
/* 239 */     this.gateway.setDebugEnabled(debugEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isAttachmentsEnabled()
/*     */   {
/* 248 */     return this.gateway.isAttachmentsEnabled();
/*     */   }
/*     */ 
/*     */   public void setAttachmentsEnabled(boolean attachmentEnabled)
/*     */   {
/* 257 */     this.gateway.setAttachmentsEnabled(attachmentEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isEmailToUserMappingEnabled()
/*     */   {
/* 266 */     return this.gateway.isEmailToUserMappingEnabled();
/*     */   }
/*     */ 
/*     */   public void setEmailToUserMappingEnabled(boolean emailToUserMappingEnabled)
/*     */   {
/* 276 */     this.gateway.setEmailToUserMappingEnabled(emailToUserMappingEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isImportHtmlEnabled()
/*     */   {
/* 285 */     return this.gateway.isImportHtmlEnabled();
/*     */   }
/*     */ 
/*     */   public void setImportHtmlEnabled(boolean importHtmlEnabled)
/*     */   {
/* 296 */     this.gateway.setImportHtmlEnabled(importHtmlEnabled);
/*     */   }
/*     */ 
/*     */   public String getDefaultCharacterSet()
/*     */   {
/* 307 */     return this.gateway.defaultCharacterSet;
/*     */   }
/*     */ 
/*     */   public void setDefaultCharacterSet(String defaultCharacterSet)
/*     */   {
/* 318 */     if (defaultCharacterSet != null)
/* 319 */       this.gateway.setDefaultCharacterSet(defaultCharacterSet);
/*     */   }
/*     */ 
/*     */   public String getTemporaryParentBody()
/*     */   {
/* 342 */     return this.gateway.getTemporaryParentBody();
/*     */   }
/*     */ 
/*     */   public void setTemporaryParentBody(String temporaryParentBody)
/*     */   {
/* 364 */     this.gateway.setTemporaryParentBody(temporaryParentBody);
/*     */   }
/*     */ 
/*     */   public boolean isSSLEnabled()
/*     */   {
/* 375 */     return this.gateway.isSSLEnabled();
/*     */   }
/*     */ 
/*     */   public void setSSLEnabled(boolean enabled)
/*     */   {
/* 384 */     this.gateway.setSSLEnabled(enabled);
/*     */   }
/*     */ 
/*     */   public String getReplyPrefixes()
/*     */   {
/* 396 */     String prefixes = "";
/* 397 */     String delim = "";
/* 398 */     for (int i = 0; i < this.gateway.replyPrefixes.length; i++) {
/* 399 */       prefixes = prefixes + delim;
/* 400 */       prefixes = prefixes + this.gateway.replyPrefixes[i];
/* 401 */       delim = ",";
/*     */     }
/*     */ 
/* 404 */     return prefixes;
/*     */   }
/*     */ 
/*     */   public void setReplyPrefixes(String replyPrefixes)
/*     */   {
/* 415 */     if (replyPrefixes == null) {
/* 416 */       return;
/*     */     }
/*     */ 
/* 419 */     StringTokenizer st = new StringTokenizer(replyPrefixes, ",");
/* 420 */     ArrayList prefixes = new ArrayList();
/* 421 */     while (st.hasMoreElements()) {
/* 422 */       String prefix = (String)st.nextElement();
/* 423 */       prefixes.add(prefix);
/*     */     }
/*     */ 
/* 426 */     this.gateway.replyPrefixes = ((String[])prefixes.toArray(new String[prefixes.size()]));
/*     */   }
/*     */ 
/*     */   public boolean isSubjectParentageCheckEnabled()
/*     */   {
/* 435 */     return this.gateway.subjectParentageCheckEnabled;
/*     */   }
/*     */ 
/*     */   public void setSubjectParentageCheckEnabled(boolean subjectParentageCheckEnabled)
/*     */   {
/* 445 */     this.gateway.subjectParentageCheckEnabled = subjectParentageCheckEnabled;
/*     */   }
/*     */ 
/*     */   public String getEmptySubject()
/*     */   {
/* 454 */     return this.gateway.emptySubject;
/*     */   }
/*     */ 
/*     */   public void setEmptySubject(String emptySubject)
/*     */   {
/* 463 */     this.gateway.emptySubject = emptySubject;
/*     */   }
/*     */ 
/*     */   private class imapGateway extends JavaMailGateway
/*     */   {
/* 473 */     boolean SSLEnabled = false;
/* 474 */     Session session = null;
/*     */     private static final String SSL_FACTORY = "com.jivesoftware.util.ssl.DummySSLSocketFactory";
/*     */ 
/*     */     public imapGateway(ForumFactory factory, Forum forum)
/*     */     {
/* 479 */       super(forum);
/* 480 */       setPort(143);
/* 481 */       setProtocol("imap");
/* 482 */       setMailbox("INBOX");
/*     */ 
/* 484 */       this.gatewayMessageId = "Email-Message-ID";
/* 485 */       this.gatewayParentId = "Email-Parent-ID";
/*     */     }
/*     */ 
/*     */     public void exportData(ForumMessage message) throws GatewayException
/*     */     {
/* 490 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     protected Store getStore(Date afterDate)
/*     */       throws MessagingException
/*     */     {
/* 501 */       Log.debug("Retrieving the javamail store for the ImapImporter");
/* 502 */       getSession();
/*     */ 
/* 504 */       Log.debug("Enabling debug: " + this.debugEnabled);
/*     */ 
/* 507 */       this.session.setDebug(this.debugEnabled);
/*     */ 
/* 510 */       URLName url = new URLName(this.protocol, this.host, this.port, this.mailbox, this.username, this.password);
/* 511 */       Store store = this.session.getStore(url);
/*     */ 
/* 513 */       Log.debug("Store retrieved in the ImapImporter");
/*     */       try
/*     */       {
/* 516 */         Log.debug("Connecting to the IMAP server");
/* 517 */         store.connect();
/* 518 */         Log.debug("Connection successful");
/*     */       }
/*     */       catch (MessagingException e) {
/*     */         try {
/* 522 */           Forum forum = this.factory.getForum(this.forumID);
/* 523 */           Log.error("Unable to open IMAP gateway in forum " + forum.getName() + ", Reason: " + e.getMessage());
/*     */ 
/* 525 */           throw e;
/*     */         } catch (ForumNotFoundException e1) {
/*     */         }
/*     */         catch (UnauthorizedException e1) {
/*     */         }
/*     */       }
/* 531 */       return store;
/*     */     }
/*     */ 
/*     */     public boolean isSSLEnabled() {
/* 535 */       return this.SSLEnabled;
/*     */     }
/*     */ 
/*     */     public void setSSLEnabled(boolean enabled) {
/* 539 */       this.SSLEnabled = enabled;
/*     */ 
/* 543 */       this.session = null;
/*     */ 
/* 546 */       if (enabled) {
/* 547 */         Security.addProvider(new Provider());
/* 548 */         Security.setProperty("ssl.SocketFactory.provider", "com.jivesoftware.util.ssl.DummySSLSocketFactory");
/*     */       }
/*     */     }
/*     */ 
/*     */     private void getSession()
/*     */     {
/* 556 */       if ((this.session == null) && (this.SSLEnabled)) {
/* 557 */         Properties mailProps = new Properties();
/*     */ 
/* 560 */         mailProps.setProperty("mail.imap.socketFactory.class", "com.jivesoftware.util.ssl.DummySSLSocketFactory");
/* 561 */         mailProps.setProperty("mail.imap.socketFactory.fallback", "false");
/*     */ 
/* 563 */         this.session = Session.getInstance(mailProps, null);
/*     */       }
/* 565 */       else if (this.session == null) {
/* 566 */         this.session = Session.getInstance(System.getProperties(), null);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.ImapImporter
 * JD-Core Version:    0.6.2
 */
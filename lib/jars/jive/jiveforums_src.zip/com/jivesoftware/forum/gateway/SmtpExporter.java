/*     */ package com.jivesoftware.forum.gateway;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.TreeWalker;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.forum.database.DbForumMessage;
/*     */ import com.sun.mail.smtp.SMTPTransport;
/*     */ import com.sun.net.ssl.internal.ssl.Provider;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.security.Security;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.mail.Address;
/*     */ import javax.mail.Message.RecipientType;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Multipart;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Transport;
/*     */ import javax.mail.URLName;
/*     */ import javax.mail.internet.AddressException;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import javax.mail.internet.MimeMessage.RecipientType;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ 
/*     */ public class SmtpExporter
/*     */   implements GatewayExporter
/*     */ {
/*  33 */   private Session session = null;
/*  34 */   private String host = null;
/*  35 */   private int port = 25;
/*  36 */   private String username = null;
/*  37 */   private String password = null;
/*     */ 
/*  39 */   private String toAddress = null;
/*  40 */   private String organization = null;
/*  41 */   private String defaultFromAddress = null;
/*  42 */   private String replyToAddress = null;
/*  43 */   private String gatewayMessageId = "Email-Message-ID";
/*  44 */   private String dummyParentHeader = "Jive-Created-Message";
/*  45 */   private String specialCharacterSet = null;
/*     */ 
/*  47 */   private boolean SSLEnabled = false;
/*  48 */   private boolean emailPrefEnabled = true;
/*  49 */   private boolean fromAddressOnly = false;
/*  50 */   private boolean debugEnabled = false;
/*  51 */   private boolean updateMessageID = true;
/*  52 */   private boolean exportIgnoreMessageID = false;
/*  53 */   private boolean attachmentEnabled = false;
/*  54 */   private boolean stopFlag = false;
/*     */ 
/*  56 */   private ForumFactory factory = null;
/*  57 */   private long forumID = -1L;
/*     */   private static final String SSL_FACTORY = "com.jivesoftware.util.ssl.DummySSLSocketFactory";
/*     */ 
/*     */   public SmtpExporter(ForumFactory factory, Forum forum)
/*     */   {
/*  70 */     this.factory = factory;
/*  71 */     this.forumID = forum.getID();
/*     */   }
/*     */ 
/*     */   public synchronized void exportData(ForumMessage forumMessage)
/*     */     throws GatewayException
/*     */   {
/*  88 */     if ((this.host == null) || (this.toAddress == null) || (this.defaultFromAddress == null)) {
/*  89 */       throw new GatewayException("Required properties are not all set.");
/*     */     }
/*     */ 
/*  98 */     if (((forumMessage.getUnfilteredProperty(this.gatewayMessageId) != null) && (!this.exportIgnoreMessageID)) || (forumMessage.getUnfilteredProperty(this.dummyParentHeader) != null))
/*     */     {
/* 102 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 106 */       retrieveSession();
/* 107 */       MimeMessage message = createMessage(forumMessage);
/* 108 */       Transport transport = null;
/*     */       try
/*     */       {
/* 111 */         transport = connectToSmtpServer();
/* 112 */         transport.sendMessage(message, message.getRecipients(MimeMessage.RecipientType.TO));
/*     */ 
/* 114 */         if ((this.updateMessageID) || (!this.exportIgnoreMessageID))
/*     */         {
/* 123 */           if (forumMessage.getForumThread() == null)
/*     */           {
/* 126 */             forumMessage.setProperty(this.gatewayMessageId, message.getMessageID());
/*     */           }
/*     */           else
/*     */           {
/* 130 */             ForumMessage m = null;
/* 131 */             DbForumFactory factory = DbForumFactory.getInstance();
/* 132 */             ForumThread thread = forumMessage.getForumThread();
/* 133 */             Forum forum = factory.getForum(thread.getForum().getID());
/* 134 */             thread = forum.getThread(thread.getID());
/* 135 */             m = thread.getMessage(forumMessage.getID());
/*     */ 
/* 139 */             m.setProperty(this.gatewayMessageId, message.getMessageID());
/*     */           }
/*     */         }
/*     */       }
/*     */       finally {
/* 144 */         disconnectFromSmtpServer(transport);
/*     */       }
/*     */ 
/* 147 */       this.session = null;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 151 */       if ((this.updateMessageID) && (!this.exportIgnoreMessageID)) {
/*     */         try
/*     */         {
/* 154 */           DbForumFactory factory = DbForumFactory.getInstance();
/* 155 */           DbForumMessage m = (DbForumMessage)factory.getMessage(forumMessage.getID());
/* 156 */           m.setProperty("jiveGatewayRetryExport", "true");
/*     */         }
/*     */         catch (Exception e2) {
/* 159 */           Log.error(e2);
/*     */         }
/*     */       }
/* 162 */       throw new GatewayException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void exportData(ForumMessage[] forumMessage)
/*     */     throws GatewayException
/*     */   {
/* 179 */     retrieveSession();
/* 180 */     Transport transport = null;
/*     */     try
/*     */     {
/* 183 */       transport = connectToSmtpServer();
/*     */ 
/* 185 */       for (int x = 0; x < forumMessage.length; x++)
/*     */       {
/* 187 */         if (this.stopFlag)
/*     */         {
/*     */           break;
/*     */         }
/* 191 */         MimeMessage message = createMessage(forumMessage[x]);
/* 192 */         transport.sendMessage(message, message.getRecipients(MimeMessage.RecipientType.TO));
/*     */ 
/* 194 */         if ((this.updateMessageID) || (!this.exportIgnoreMessageID))
/*     */         {
/* 202 */           if (forumMessage[x].getForumThread() == null)
/*     */           {
/* 205 */             forumMessage[x].setProperty(this.gatewayMessageId, message.getMessageID());
/*     */           }
/*     */           else
/*     */           {
/* 209 */             DbForumFactory factory = DbForumFactory.getInstance();
/* 210 */             ForumMessage m = factory.getMessage(forumMessage[x].getID());
/*     */ 
/* 214 */             m.setProperty(this.gatewayMessageId, message.getMessageID());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 220 */       throw new GatewayException(e);
/*     */     }
/*     */     finally {
/* 223 */       if (transport != null)
/*     */         try {
/* 225 */           disconnectFromSmtpServer(transport);
/*     */         }
/*     */         catch (MessagingException e)
/*     */         {
/*     */         }
/* 230 */       this.session = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stop() throws GatewayException {
/* 235 */     this.stopFlag = true;
/*     */   }
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 245 */     return this.host;
/*     */   }
/*     */ 
/*     */   public void setHost(String host)
/*     */   {
/* 255 */     this.host = host;
/*     */ 
/* 258 */     this.session = null;
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 268 */     return this.port;
/*     */   }
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 278 */     this.port = port;
/*     */ 
/* 281 */     this.session = null;
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 291 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 301 */     this.username = username;
/*     */ 
/* 304 */     this.session = null;
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 314 */     return this.password;
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 324 */     this.password = password;
/*     */ 
/* 327 */     this.session = null;
/*     */   }
/*     */ 
/*     */   public boolean isDebugEnabled()
/*     */   {
/* 338 */     return this.debugEnabled;
/*     */   }
/*     */ 
/*     */   public void setDebugEnabled(boolean debugEnabled)
/*     */   {
/* 348 */     this.debugEnabled = debugEnabled;
/*     */ 
/* 351 */     this.session = null;
/*     */   }
/*     */ 
/*     */   public boolean isEmailPrefEnabled()
/*     */   {
/* 361 */     return this.emailPrefEnabled;
/*     */   }
/*     */ 
/*     */   public void setEmailPrefEnabled(boolean enabled)
/*     */   {
/* 372 */     this.emailPrefEnabled = enabled;
/*     */   }
/*     */ 
/*     */   public boolean isFromAddressOnly()
/*     */   {
/* 383 */     return this.fromAddressOnly;
/*     */   }
/*     */ 
/*     */   public void setFromAddressOnly(boolean enabled)
/*     */   {
/* 394 */     this.fromAddressOnly = enabled;
/*     */   }
/*     */ 
/*     */   public String getToAddress()
/*     */   {
/* 405 */     return this.toAddress;
/*     */   }
/*     */ 
/*     */   public void setToAddress(String address)
/*     */   {
/* 416 */     if ("".equals(address)) {
/* 417 */       address = null;
/*     */     }
/* 419 */     this.toAddress = address;
/*     */   }
/*     */ 
/*     */   public String getDefaultFromAddress()
/*     */   {
/* 429 */     return this.defaultFromAddress;
/*     */   }
/*     */ 
/*     */   public void setDefaultFromAddress(String address)
/*     */   {
/* 438 */     if ("".equals(address)) {
/* 439 */       address = null;
/*     */     }
/* 441 */     this.defaultFromAddress = address;
/*     */   }
/*     */ 
/*     */   public String getReplyToAddress()
/*     */   {
/* 450 */     return this.replyToAddress;
/*     */   }
/*     */ 
/*     */   public void setReplyToAddress(String address)
/*     */   {
/* 459 */     if ("".equals(address)) {
/* 460 */       address = null;
/*     */     }
/* 462 */     this.replyToAddress = address;
/*     */   }
/*     */ 
/*     */   public boolean isSSLEnabled()
/*     */   {
/* 472 */     return this.SSLEnabled;
/*     */   }
/*     */ 
/*     */   public void setSSLEnabled(boolean SSLEnabled)
/*     */   {
/* 482 */     this.SSLEnabled = SSLEnabled;
/*     */ 
/* 486 */     this.session = null;
/*     */   }
/*     */ 
/*     */   public String getOrganization()
/*     */   {
/* 496 */     return this.organization;
/*     */   }
/*     */ 
/*     */   public void setOrganization(String organization)
/*     */   {
/* 505 */     this.organization = organization;
/*     */   }
/*     */ 
/*     */   public boolean isUpdateMessageIDOnExport()
/*     */   {
/* 521 */     return this.updateMessageID;
/*     */   }
/*     */ 
/*     */   public void setUpdateMessageIDOnExport(boolean updateMessageID)
/*     */   {
/* 537 */     this.updateMessageID = updateMessageID;
/*     */   }
/*     */ 
/*     */   public boolean isAllowExportAgain()
/*     */   {
/* 547 */     return this.exportIgnoreMessageID;
/*     */   }
/*     */ 
/*     */   public void setAllowExportAgain(boolean allowExportAgain)
/*     */   {
/* 565 */     this.exportIgnoreMessageID = allowExportAgain;
/*     */   }
/*     */ 
/*     */   public boolean isAttachmentsEnabled() {
/* 569 */     return this.attachmentEnabled;
/*     */   }
/*     */ 
/*     */   public void setAttachmentsEnabled(boolean attachmentsEnabled) {
/* 573 */     this.attachmentEnabled = attachmentsEnabled;
/*     */   }
/*     */ 
/*     */   public String getSpecialCharacterSet()
/*     */   {
/* 582 */     return this.specialCharacterSet;
/*     */   }
/*     */ 
/*     */   public void setSpecialCharacterSet(String specialCharacterSet)
/*     */   {
/* 593 */     this.specialCharacterSet = specialCharacterSet;
/*     */   }
/*     */ 
/*     */   private void retrieveSession()
/*     */   {
/* 598 */     if (this.SSLEnabled) {
/* 599 */       Security.addProvider(new Provider());
/* 600 */       Security.setProperty("ssl.SocketFactory.provider", "com.jivesoftware.util.ssl.DummySSLSocketFactory");
/*     */     }
/*     */ 
/* 604 */     if (this.session == null) {
/* 605 */       Properties mailProps = new Properties();
/* 606 */       mailProps.setProperty("mail.smtp.host", this.host);
/* 607 */       mailProps.setProperty("mail.smtp.port", String.valueOf(this.port));
/* 608 */       mailProps.setProperty("mail.debug", String.valueOf(this.debugEnabled));
/*     */ 
/* 613 */       if (this.SSLEnabled) {
/* 614 */         mailProps.setProperty("mail.smtp.socketFactory.class", "com.jivesoftware.util.ssl.DummySSLSocketFactory");
/* 615 */         mailProps.setProperty("mail.smtp.socketFactory.fallback", "true");
/*     */       }
/*     */ 
/* 618 */       if (this.username != null) {
/* 619 */         mailProps.put("mail.smtp.auth", "true");
/*     */       }
/* 621 */       this.session = Session.getInstance(mailProps, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   private MimeMessage createMessage(ForumMessage forumMessage) throws GatewayException {
/*     */     try {
/* 627 */       MimeMessage message = new MimeMessage(this.session);
/* 628 */       InternetAddress to = new InternetAddress(this.toAddress);
/* 629 */       String subject = !"".equals(forumMessage.getUnfilteredSubject()) ? forumMessage.getUnfilteredSubject() : " ";
/*     */ 
/* 632 */       message.setFrom(getFromAddress(forumMessage));
/* 633 */       if (this.replyToAddress != null) {
/* 634 */         Address[] replyTo = { new InternetAddress(this.replyToAddress) };
/* 635 */         message.setReplyTo(replyTo);
/*     */       }
/* 637 */       message.setRecipient(Message.RecipientType.TO, to);
/* 638 */       message.setSubject(subject, getMimeCharacterEncoding());
/*     */ 
/* 642 */       SimpleDateFormat format = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
/*     */ 
/* 644 */       format.setTimeZone(JiveGlobals.getTimeZone());
/* 645 */       message.setHeader("Date", format.format(forumMessage.getCreationDate()));
/*     */ 
/* 648 */       message.setHeader("Content-Transfer-Encoding", "8bit");
/*     */ 
/* 650 */       if (this.organization != null) {
/* 651 */         message.setHeader("Organization", this.organization);
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 657 */         ForumThread thread = forumMessage.getForumThread();
/* 658 */         TreeWalker tree = thread.getTreeWalker();
/* 659 */         ForumMessage parent = tree.getParent(forumMessage);
/* 660 */         String parentID = parent.getUnfilteredProperty(this.gatewayMessageId);
/*     */ 
/* 662 */         if ((parentID != null) && (!parentID.equals(""))) {
/* 663 */           message.setHeader("In-Reply-To", parentID);
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (ForumMessageNotFoundException fmnfe)
/*     */       {
/*     */       }
/*     */ 
/* 671 */       addContent(forumMessage, message);
/*     */ 
/* 674 */       message.saveChanges();
/*     */ 
/* 676 */       return message;
/*     */     }
/*     */     catch (MessagingException e) {
/* 679 */       throw new GatewayException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getMimeCharacterEncoding()
/*     */   {
/* 685 */     if (this.specialCharacterSet != null)
/*     */     {
/* 687 */       return MimeUtility.mimeCharset(this.specialCharacterSet);
/*     */     }
/*     */ 
/* 692 */     return MimeUtility.mimeCharset(JiveGlobals.getCharacterEncoding());
/*     */   }
/*     */ 
/*     */   private Transport connectToSmtpServer() throws MessagingException {
/* 696 */     URLName url = new URLName("smtp", this.host, this.port, "", this.username, this.password);
/* 697 */     Transport trans = new SMTPTransport(this.session, url);
/*     */     try
/*     */     {
/* 700 */       trans.connect(this.host, this.port, this.username, this.password);
/*     */     }
/*     */     catch (MessagingException e) {
/* 703 */       DbForumFactory factory = DbForumFactory.getInstance();
/* 704 */       Forum forum = null;
/*     */       try
/*     */       {
/* 707 */         forum = factory.getForum(this.forumID);
/* 708 */         Log.error("Unable to connect to SMTP server in forum " + forum.getName() + ", Reason: " + e.getMessage());
/*     */       }
/*     */       catch (ForumNotFoundException e1)
/*     */       {
/*     */       }
/* 713 */       throw e;
/*     */     }
/*     */ 
/* 716 */     return trans;
/*     */   }
/*     */ 
/*     */   private void disconnectFromSmtpServer(Transport transport) throws MessagingException {
/* 720 */     if (transport != null) transport.close();
/*     */   }
/*     */ 
/*     */   private InternetAddress getFromAddress(ForumMessage forumMessage)
/*     */   {
/* 733 */     InternetAddress fromAddress = null;
/*     */     try
/*     */     {
/* 736 */       if (this.fromAddressOnly) {
/* 737 */         fromAddress = new InternetAddress(this.defaultFromAddress);
/*     */       }
/* 739 */       else if (!forumMessage.isAnonymous()) {
/* 740 */         User user = forumMessage.getUser();
/* 741 */         String email = null;
/*     */         String name;
/*     */         String name;
/* 743 */         if (user.isNameVisible()) {
/* 744 */           name = user.getName();
/*     */         }
/*     */         else {
/* 747 */           name = user.getUsername();
/*     */         }
/*     */ 
/* 751 */         if ((!user.isEmailVisible()) && (this.emailPrefEnabled)) {
/* 752 */           email = this.defaultFromAddress;
/*     */         }
/*     */         else {
/* 755 */           email = user.getEmail();
/*     */         }
/* 757 */         fromAddress = new InternetAddress(email, name, getMimeCharacterEncoding());
/*     */       }
/* 761 */       else if ((forumMessage.getUnfilteredProperty("name") != null) && (forumMessage.getUnfilteredProperty("email") != null))
/*     */       {
/* 764 */         String name = forumMessage.getUnfilteredProperty("name");
/* 765 */         String email = forumMessage.getUnfilteredProperty("email");
/* 766 */         fromAddress = new InternetAddress(email, name, getMimeCharacterEncoding());
/*     */       }
/* 770 */       else if (forumMessage.getUnfilteredProperty("name") != null) {
/* 771 */         String name = forumMessage.getUnfilteredProperty("name");
/* 772 */         fromAddress = new InternetAddress(this.defaultFromAddress, name, getMimeCharacterEncoding());
/*     */       }
/* 776 */       else if (forumMessage.getUnfilteredProperty("email") != null) {
/* 777 */         String email = forumMessage.getUnfilteredProperty("email");
/* 778 */         fromAddress = new InternetAddress(email, "", getMimeCharacterEncoding());
/*     */       }
/*     */       else
/*     */       {
/* 782 */         fromAddress = new InternetAddress(this.defaultFromAddress);
/*     */       }
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 786 */       fromAddress = null;
/*     */     }
/*     */     catch (AddressException e) {
/* 789 */       fromAddress = null;
/*     */     }
/*     */ 
/* 792 */     return fromAddress;
/*     */   }
/*     */ 
/*     */   private void addContent(ForumMessage forumMessage, MimeMessage message)
/*     */     throws GatewayException
/*     */   {
/*     */     try
/*     */     {
/* 804 */       StringBuffer body = new StringBuffer(forumMessage.getUnfilteredBody());
/* 805 */       Forum forum = this.factory.getForum(this.forumID);
/* 806 */       GatewayManager manager = forum.getGatewayManager();
/* 807 */       body.append(manager.getTranslatedFooter(forumMessage));
/*     */ 
/* 810 */       if ((this.attachmentEnabled) && (forumMessage.getAttachmentCount() > 0))
/*     */       {
/* 812 */         Multipart multipart = new MimeMultipart();
/* 813 */         MimeBodyPart messageBodyPart = new MimeBodyPart();
/* 814 */         messageBodyPart.setText(body.toString(), getMimeCharacterEncoding());
/* 815 */         messageBodyPart.setDisposition("inline");
/* 816 */         multipart.addBodyPart(messageBodyPart);
/* 817 */         Iterator iter = forumMessage.getAttachments();
/*     */ 
/* 820 */         while (iter.hasNext()) {
/* 821 */           Attachment attachment = (Attachment)iter.next();
/* 822 */           AttachmentDataSource source = new AttachmentDataSource(attachment);
/* 823 */           messageBodyPart = new MimeBodyPart();
/*     */ 
/* 825 */           messageBodyPart.setDisposition("attachment");
/* 826 */           messageBodyPart.setFileName(attachment.getName());
/* 827 */           messageBodyPart.setDataHandler(new DataHandler(source));
/* 828 */           multipart.addBodyPart(messageBodyPart);
/*     */         }
/*     */ 
/* 832 */         message.setContent(multipart);
/*     */       }
/*     */       else {
/* 835 */         message.setText(body.toString(), getMimeCharacterEncoding());
/*     */       }
/*     */     }
/*     */     catch (ForumNotFoundException e) {
/* 839 */       throw new GatewayException("ForumNotFoundException thrown", e);
/*     */     }
/*     */     catch (MessagingException e) {
/* 842 */       throw new GatewayException("MessagingException thrown", e);
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 845 */       throw new GatewayException("UnauthorizedException thrown", e);
/*     */     }
/*     */     catch (IOException e) {
/* 848 */       throw new GatewayException("IOException thrown", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.SmtpExporter
 * JD-Core Version:    0.6.2
 */
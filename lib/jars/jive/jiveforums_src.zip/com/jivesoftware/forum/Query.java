package com.jivesoftware.forum;

import com.jivesoftware.base.User;
import java.util.Date;
import java.util.Iterator;

public abstract interface Query
{
  public static final int RELEVANCE = 10001;
  public static final int RATING = 107;
  public static final int DATE = 9;
  public static final int SUBJECT = 6;
  public static final int DESCENDING = 0;
  public static final int ASCENDING = 1;

  public abstract long getID();

  public abstract int getObjectType();

  public abstract String getQueryString();

  public abstract void setQueryString(String paramString);

  public abstract Date getBeforeDate();

  public abstract void setBeforeDate(Date paramDate);

  public abstract Date getAfterDate();

  public abstract void setAfterDate(Date paramDate);

  public abstract long[] getForumIDs();

  public abstract User getUser();

  public abstract User getFilteredUser();

  public abstract void filterOnUser(User paramUser);

  public abstract ForumThread getFilteredThread();

  public abstract void filterOnThread(ForumThread paramForumThread);

  public abstract int getSortField();

  public abstract void setSortField(int paramInt);

  public abstract int getSortOrder();

  public abstract void setSortOrder(int paramInt);

  public abstract int getResultCount();

  public abstract Iterator getResults();

  public abstract Iterator getResults(int paramInt1, int paramInt2);

  public abstract Iterator getResultsByThread();

  public abstract Iterator getResultsByThread(int paramInt1, int paramInt2);

  public abstract int getResultByThreadCount();

  public abstract Iterator getResultForums();

  public abstract String[] highlightResult(QueryResult paramQueryResult, String paramString1, String paramString2);

  public abstract long logQuery(User paramUser);

  public abstract void logSearchClick(long paramLong1, long paramLong2);

  public abstract boolean equals(Query paramQuery);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.Query
 * JD-Core Version:    0.6.2
 */
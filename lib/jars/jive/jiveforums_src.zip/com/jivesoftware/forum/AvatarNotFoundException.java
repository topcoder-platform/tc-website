/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ public class AvatarNotFoundException extends Exception
/*    */ {
/*    */   public AvatarNotFoundException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AvatarNotFoundException(String s)
/*    */   {
/* 24 */     super(s);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.AvatarNotFoundException
 * JD-Core Version:    0.6.2
 */
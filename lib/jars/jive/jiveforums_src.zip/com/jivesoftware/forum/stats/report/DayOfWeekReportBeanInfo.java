/*    */ package com.jivesoftware.forum.stats.report;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class DayOfWeekReportBeanInfo extends JiveBeanInfo
/*    */ {
/*    */   public String[] getPropertyNames()
/*    */   {
/* 17 */     return new String[0];
/*    */   }
/*    */   public Class getBeanClass() {
/* 20 */     return DayOfWeekReport.class;
/*    */   }
/*    */   public String getName() {
/* 23 */     return "DayOfWeekReport";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.DayOfWeekReportBeanInfo
 * JD-Core Version:    0.6.2
 */
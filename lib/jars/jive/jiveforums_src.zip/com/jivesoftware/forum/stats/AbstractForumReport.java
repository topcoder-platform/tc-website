/*    */ package com.jivesoftware.forum.stats;
/*    */ 
/*    */ import com.jivesoftware.base.stats.AbstractReport;
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import com.jivesoftware.forum.ForumMessage;
/*    */ import com.jivesoftware.forum.ResultFilter;
/*    */ import java.util.Date;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public abstract class AbstractForumReport extends AbstractReport
/*    */ {
/*    */   protected Date calculateStartDate()
/*    */   {
/* 31 */     for (int i = 0; i < this.objects.size(); i++) {
/* 32 */       Forum forum = (Forum)this.objects.get(i);
/*    */ 
/* 35 */       ResultFilter filter = ResultFilter.createDefaultMessageFilter();
/* 36 */       filter.setNumResults(1);
/* 37 */       filter.setSortOrder(1);
/* 38 */       Iterator message = forum.getMessages(filter);
/*    */ 
/* 40 */       if (message.hasNext()) {
/* 41 */         ForumMessage m = (ForumMessage)message.next();
/* 42 */         if (m.getCreationDate().getTime() < forum.getCreationDate().getTime()) {
/* 43 */           this.startDate = m.getCreationDate();
/*    */         }
/*    */       }
/*    */ 
/* 47 */       if ((this.startDate == null) || (forum.getCreationDate().getTime() < this.startDate.getTime())) {
/* 48 */         this.startDate = forum.getCreationDate();
/*    */       }
/* 50 */       if (this.startDate == null) {
/* 51 */         this.startDate = new Date(0L);
/*    */       }
/*    */     }
/*    */ 
/* 55 */     return this.startDate;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.AbstractForumReport
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Element;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.Report.ExtraInfo;
/*     */ import com.jivesoftware.base.stats.bin.DateSequence;
/*     */ import com.jivesoftware.base.stats.element.DateElement;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.base.stats.util.DateFormatter;
/*     */ import com.jivesoftware.base.stats.util.DecimalFormatter;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class NewMessagesReport extends AbstractForumReport
/*     */ {
/*     */   private static final String NEW_MESSAGES_BY_DATE = "SELECT creationDate FROM jiveMessage WHERE creationDate >= ? AND creationDate < ?";
/*     */   private static final String NEW_MESSAGES_BY_FORUM_AND_DATE = "SELECT creationDate FROM jiveMessage WHERE forumID = ? AND creationDate >= ? AND creationDate < ?";
/*  43 */   private long stepSize = 24L;
/*     */ 
/*     */   public long getStepSize()
/*     */   {
/*  48 */     return this.stepSize;
/*     */   }
/*     */ 
/*     */   public void setStepSize(long stepSize) {
/*  52 */     this.stepSize = stepSize;
/*     */   }
/*     */ 
/*     */   public void execute() throws Exception {
/*  56 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  57 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  60 */     Histogram hist = new Histogram(new DateSequence(start, getStepSize() * 60L * 60L * 1000L));
/*  61 */     addHistogram(hist);
/*     */ 
/*  63 */     Connection con = null;
/*  64 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/*  70 */         con = ConnectionManager.getConnection();
/*  71 */         pstmt = con.prepareStatement("SELECT creationDate FROM jiveMessage WHERE creationDate >= ? AND creationDate < ?");
/*  72 */         pstmt.setLong(1, start.getTime());
/*  73 */         pstmt.setLong(2, end.getTime());
/*  74 */         ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  76 */         while (rs.next()) {
/*  77 */           hist.add(new DateElement(new Date(rs.getLong(1))));
/*     */         }
/*  79 */         rs.close();
/*  80 */         pstmt.close();
/*     */       }
/*     */       catch (SQLException sqle)
/*     */       {
/*     */       }
/*     */ 
/*  88 */       List forums = getObjects();
/*  89 */       for (iter = forums.iterator(); iter.hasNext(); ) {
/*  90 */         Forum forum = (Forum)iter.next();
/*  91 */         long forumID = forum.getID();
/*  92 */         hist = new Histogram(new DateSequence(start, getStepSize() * 60L * 60L * 1000L));
/*  93 */         addHistogram(hist);
/*     */         try {
/*  95 */           pstmt = con.prepareStatement("SELECT creationDate FROM jiveMessage WHERE forumID = ? AND creationDate >= ? AND creationDate < ?");
/*  96 */           pstmt.setLong(1, forumID);
/*  97 */           pstmt.setLong(2, start.getTime());
/*  98 */           pstmt.setLong(3, end.getTime());
/*  99 */           ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 101 */           while (rs.next()) {
/* 102 */             hist.add(new DateElement(new Date(rs.getLong(1))));
/*     */           }
/* 104 */           rs.close();
/* 105 */           pstmt.close();
/*     */         }
/*     */         catch (SQLException sqle)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       Iterator iter;
/* 113 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/* 118 */     Histogram[] histograms = getHistograms();
/* 119 */     if (histograms.length == 0) {
/* 120 */       return new DataTable[0];
/*     */     }
/* 122 */     List tables = new ArrayList(histograms.length);
/* 123 */     for (int i = 0; i < histograms.length; i++) {
/* 124 */       Histogram hist = histograms[i];
/* 125 */       DataTable data = new DataTable(getName());
/* 126 */       data.setColumns(new String[] { "Week", "Messages" });
/* 127 */       Bin[] bins = hist.getBins();
/* 128 */       for (int j = 0; j < bins.length; j++) {
/* 129 */         Bin bin = bins[j];
/* 130 */         String week = DateFormatter.format("M/dd/yyyy", new Date(bin.getBegin().toLong().longValue()));
/*     */ 
/* 132 */         long count = hist.getCount(bin);
/* 133 */         data.addRow(new Object[] { week, new Long(count) });
/*     */       }
/* 135 */       tables.add(data);
/*     */     }
/* 137 */     return (DataTable[])tables.toArray(new DataTable[0]);
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 141 */     Histogram[] histograms = getHistograms();
/* 142 */     Chart[] charts = new Chart[histograms.length];
/* 143 */     List forums = getObjects();
/* 144 */     for (int i = 0; i < histograms.length; i++) {
/* 145 */       Histogram hist = histograms[i];
/* 146 */       String name = getName();
/* 147 */       if (i == 0) {
/* 148 */         name = name + " - All forums";
/*     */       }
/*     */       else {
/* 151 */         name = name + " - " + forums.get(i - 1);
/*     */       }
/* 153 */       Chart chart = new Chart(name);
/* 154 */       chart.setXaxisLabel("Dates");
/* 155 */       chart.setYaxisLabel("New Messages");
/* 156 */       chart.setType(2);
/* 157 */       Bin[] bins = hist.getBins();
/* 158 */       String[] labels = new String[bins.length];
/* 159 */       for (int j = 0; j < bins.length; j++) {
/* 160 */         Bin bin = bins[j];
/* 161 */         Date begin = new Date(bin.getBegin().toLong().longValue());
/* 162 */         Date end = new Date(bin.getEnd().toLong().longValue());
/* 163 */         Date mid = new Date((begin.getTime() + end.getTime()) / 2L);
/* 164 */         labels[j] = DateFormatter.format("M/dd/yy", mid);
/*     */       }
/* 166 */       chart.setLabels(labels);
/* 167 */       charts[i] = chart;
/*     */     }
/* 169 */     return charts;
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 173 */     Histogram[] histograms = getHistograms();
/* 174 */     if (histograms.length == 0) {
/* 175 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/* 177 */     List lists = new ArrayList(histograms.length);
/* 178 */     for (int i = 0; i < histograms.length; i++) {
/* 179 */       List extraInfo = new ArrayList(4);
/* 180 */       Histogram hist = histograms[i];
/* 181 */       double meanElement = hist.getMeanCount();
/* 182 */       double sumCount = hist.getSumCount();
/*     */ 
/* 185 */       extraInfo.add(getDateRange());
/*     */ 
/* 187 */       extraInfo.add(new Report.ExtraInfo("Total Messages Posted", DecimalFormatter.format("#,##0", new Double(sumCount).doubleValue())));
/*     */ 
/* 190 */       extraInfo.add(new Report.ExtraInfo("Average Messages Posted Per Week", DecimalFormatter.format("#.0", new Double(meanElement).doubleValue())));
/*     */ 
/* 193 */       lists.add(extraInfo);
/*     */     }
/* 195 */     return (List[])lists.toArray(new List[0]);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.NewMessagesReport
 * JD-Core Version:    0.6.2
 */
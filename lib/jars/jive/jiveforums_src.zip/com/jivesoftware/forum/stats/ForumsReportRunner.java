/*    */ package com.jivesoftware.forum.stats;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.UserManager;
/*    */ import com.jivesoftware.base.stats.AbstractReportRunner;
/*    */ import com.jivesoftware.base.stats.ReportManager;
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import com.jivesoftware.forum.ForumCategory;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.Version;
/*    */ import com.jivesoftware.forum.Version.Edition;
/*    */ import com.jivesoftware.forum.database.DbForumFactory;
/*    */ import java.util.Collections;
/*    */ import java.util.Comparator;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ForumsReportRunner extends AbstractReportRunner
/*    */ {
/*    */   private ForumFactory factory;
/*    */ 
/*    */   public ForumsReportRunner()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ForumsReportRunner(AuthToken authToken)
/*    */   {
/* 38 */     super(authToken);
/*    */   }
/*    */ 
/*    */   protected void init() {
/* 42 */     super.init();
/* 43 */     if (this.authToken == null) {
/* 44 */       this.factory = DbForumFactory.getInstance();
/*    */     }
/*    */     else
/* 47 */       this.factory = ForumFactory.getInstance(this.authToken);
/*    */   }
/*    */ 
/*    */   public ReportManager getReportManager()
/*    */   {
/* 52 */     return ForumsReportManager.getInstance();
/*    */   }
/*    */ 
/*    */   protected void addReportInfoQueries(Map queries) {
/* 56 */     queries.put("numCats", "SELECT (count(*)-1) FROM jiveCategory");
/* 57 */     queries.put("numForums", "SELECT count(*) FROM jiveForum");
/* 58 */     queries.put("numThreads", "SELECT count(*) FROM jiveThread");
/* 59 */     queries.put("numMessages", "SELECT count(*) FROM jiveMessage");
/* 60 */     queries.put("numUsers", "SELECT count(*) FROM jiveUser");
/* 61 */     queries.put("numGroups", "SELECT count(*) FROM jiveGroup");
/*    */   }
/*    */ 
/*    */   protected void updateContext(Map context) {
/* 65 */     Map env = (Map)context.get("env");
/* 66 */     if (env != null)
/* 67 */       env.put("jfVersion", "Jive Forums " + Version.getEdition().toString() + " " + Version.getVersionNumber());
/*    */   }
/*    */ 
/*    */   protected UserManager getUserManager()
/*    */   {
/* 74 */     return this.factory.getUserManager();
/*    */   }
/*    */ 
/*    */   protected List getObjects()
/*    */   {
/* 79 */     ReportManager manager = ForumsReportManager.getInstance();
/* 80 */     List objects = new LinkedList();
/* 81 */     List excludedForums = manager.getExcludedObjectIDs();
/* 82 */     for (Iterator iter = this.factory.getRootForumCategory().getRecursiveForums(); iter.hasNext(); ) {
/* 83 */       Forum forum = (Forum)iter.next();
/* 84 */       if (!excludedForums.contains(new Long(forum.getID()))) {
/* 85 */         objects.add(forum);
/*    */       }
/*    */     }
/* 88 */     Collections.sort(objects, new Comparator() {
/*    */       public int compare(Object o1, Object o2) {
/* 90 */         Forum f1 = (Forum)o1;
/* 91 */         Forum f2 = (Forum)o2;
/* 92 */         return f1.getName().compareToIgnoreCase(f2.getName());
/*    */       }
/*    */     });
/* 95 */     return objects;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.ForumsReportRunner
 * JD-Core Version:    0.6.2
 */
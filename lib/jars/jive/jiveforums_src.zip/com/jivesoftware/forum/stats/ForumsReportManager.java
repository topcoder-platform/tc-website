/*    */ package com.jivesoftware.forum.stats;
/*    */ 
/*    */ import com.jivesoftware.base.stats.AbstractReportManager;
/*    */ import com.jivesoftware.forum.Version;
/*    */ import com.jivesoftware.forum.Version.Edition;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ForumsReportManager extends AbstractReportManager
/*    */ {
/* 26 */   private static ForumsReportManager instance = new ForumsReportManager();
/*    */ 
/*    */   public static ForumsReportManager getInstance() {
/* 29 */     return instance;
/*    */   }
/*    */ 
/*    */   protected String[] getPredefinedReportClasses()
/*    */   {
/* 37 */     List reportClasses = new ArrayList();
/*    */ 
/* 40 */     reportClasses.add("com.jivesoftware.forum.stats.report.DayOfWeekReport");
/* 41 */     reportClasses.add("com.jivesoftware.forum.stats.report.GroupPostReport");
/* 42 */     reportClasses.add("com.jivesoftware.forum.stats.report.HourOfDayReport");
/* 43 */     reportClasses.add("com.jivesoftware.forum.stats.report.MessageLengthReport");
/* 44 */     reportClasses.add("com.jivesoftware.forum.stats.report.NewMessagesReport");
/* 45 */     reportClasses.add("com.jivesoftware.forum.stats.report.RepliesPerThreadReport");
/* 46 */     reportClasses.add("com.jivesoftware.forum.stats.report.ThreadTTLReport");
/* 47 */     reportClasses.add("com.jivesoftware.forum.stats.report.TopForumsReport");
/* 48 */     reportClasses.add("com.jivesoftware.forum.stats.report.UserCreationReport");
/*    */ 
/* 51 */     if ((Version.getEdition() == Version.Edition.ENTERPRISE) || (Version.getEdition() == Version.Edition.EXPERT))
/*    */     {
/* 54 */       reportClasses.add("com.jivesoftware.forum.stats.report.HTTPPageViewsReport");
/* 55 */       reportClasses.add("com.jivesoftware.forum.stats.report.NNTPPageViewsReport");
/* 56 */       reportClasses.add("com.jivesoftware.forum.stats.report.SearchQueryReport");
/* 57 */       reportClasses.add("com.jivesoftware.forum.stats.report.SearchFailedReport");
/* 58 */       reportClasses.add("com.jivesoftware.forum.stats.report.SearchSuccessReport");
/* 59 */       reportClasses.add("com.jivesoftware.forum.stats.report.SearchQueryDayOfWeekReport");
/* 60 */       reportClasses.add("com.jivesoftware.forum.stats.report.SearchQueryHourOfDayReport");
/* 61 */       reportClasses.add("com.jivesoftware.forum.stats.report.SearchQuerySearchTimeFreqReport");
/* 62 */       reportClasses.add("com.jivesoftware.forum.stats.report.SearchQuerySearchTimeReport");
/* 63 */       reportClasses.add("com.jivesoftware.forum.stats.report.SearchTopClickThroughReport");
/* 64 */       reportClasses.add("com.jivesoftware.forum.stats.report.SearchTopQueryTermsReport");
/* 65 */       reportClasses.add("com.jivesoftware.forum.stats.report.UniqueHTTPVisitorsReport");
/* 66 */       reportClasses.add("com.jivesoftware.forum.stats.report.UniqueNNTPVisitorsReport");
/*    */     }
/*    */ 
/* 70 */     if (Version.getEdition() == Version.Edition.EXPERT) {
/* 71 */       reportClasses.add("com.jivesoftware.forum.stats.report.UserQuestionsReport");
/* 72 */       reportClasses.add("com.jivesoftware.forum.stats.report.QuestionResolutionTime");
/*    */     }
/*    */ 
/* 75 */     return (String[])reportClasses.toArray(new String[0]);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.ForumsReportManager
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.BinFormat;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.Report.ExtraInfo;
/*     */ import com.jivesoftware.base.stats.bin.DateSequence;
/*     */ import com.jivesoftware.base.stats.element.DateElement;
/*     */ import com.jivesoftware.base.stats.element.DateElementFormat;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.base.stats.util.DecimalFormatter;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ public class SearchFailedReport extends AbstractForumReport
/*     */ {
/*     */   private static final String EARLIEST_SEARCH_DATE = "SELECT min(searchDate) FROM jiveSearch WHERE searchType=19";
/*     */   private static final String SEARCH_QUERIES = "SELECT searchID, searchDate, numResults FROM jiveSearch WHERE searchDate >= ? AND searchDate <= ? AND searchType=19";
/*     */   private static final String SEARCH_CLICK_THROUGHS = "SELECT count(*) FROM jiveSearchClick where searchID=?";
/*  45 */   private BinFormat labelFormatter = new BinFormat(new DateElementFormat("M/d"), "$1");
/*     */ 
/*  47 */   private int count = 0;
/*     */ 
/*     */   public void execute()
/*     */   {
/*  52 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  53 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  55 */     if (end.compareTo(start) < 0)
/*     */     {
/*  57 */       start = end;
/*     */     }
/*     */ 
/*  62 */     if (end.getTime() - start.getTime() <= 86400000L) {
/*  63 */       start.setTime(start.getTime() - 604800000L);
/*     */     }
/*     */ 
/*  66 */     Histogram hist = new Histogram(new DateSequence(start, 86400000L), new DateElement(start), new DateElement(end));
/*     */ 
/*  68 */     addHistogram(hist);
/*     */ 
/*  70 */     Connection con = null;
/*  71 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/*  74 */       con = ConnectionManager.getConnection();
/*  75 */       pstmt = con.prepareStatement("SELECT searchID, searchDate, numResults FROM jiveSearch WHERE searchDate >= ? AND searchDate <= ? AND searchType=19");
/*  76 */       pstmt.setLong(1, start.getTime());
/*  77 */       pstmt.setLong(2, end.getTime());
/*  78 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  80 */       while (rs.next()) {
/*  81 */         long searchID = rs.getLong(1);
/*  82 */         Date searchDate = new Date(Long.parseLong(rs.getString(2).trim()));
/*  83 */         int numResults = rs.getInt(3);
/*     */ 
/*  85 */         if (numResults < 1) {
/*  86 */           hist.add(new DateElement(searchDate));
/*  87 */           this.count += 1;
/*     */         }
/*     */         else
/*     */         {
/*  91 */           Connection con2 = null;
/*  92 */           PreparedStatement pstmt2 = null;
/*     */           try
/*     */           {
/*  95 */             con2 = ConnectionManager.getConnection();
/*  96 */             pstmt2 = con2.prepareStatement("SELECT count(*) FROM jiveSearchClick where searchID=?");
/*  97 */             pstmt2.setLong(1, searchID);
/*  98 */             ResultSet rs2 = pstmt2.executeQuery();
/*  99 */             rs2.next();
/*     */ 
/* 101 */             if (rs2.getInt(1) < 1) {
/* 102 */               hist.add(new DateElement(searchDate));
/* 103 */               this.count += 1;
/*     */             }
/*     */ 
/* 106 */             rs2.close();
/*     */           } catch (SQLException e) {
/* 108 */             Log.error(e);
/*     */           }
/*     */           finally {
/*     */           }
/*     */         }
/*     */       }
/* 114 */       rs.close();
/*     */     } catch (SQLException e) {
/* 116 */       Log.error(e);
/*     */     } finally {
/* 118 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/* 123 */     Histogram[] histograms = getHistograms();
/* 124 */     if (histograms.length == 0) {
/* 125 */       return new DataTable[0];
/*     */     }
/* 127 */     DataTable data = new DataTable(getName());
/* 128 */     data.setColumns(new String[] { "Date", "Failed Searches per Day" });
/* 129 */     Histogram hist = histograms[0];
/* 130 */     Bin[] bins = hist.getBins();
/* 131 */     for (int i = 0; i < bins.length; i++) {
/* 132 */       Bin bin = bins[i];
/* 133 */       long count = hist.getCount(bin);
/* 134 */       data.addRow(new Object[] { this.labelFormatter.format(bin), new Long(count) });
/*     */     }
/* 136 */     return new DataTable[] { data };
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 140 */     Histogram[] histograms = getHistograms();
/* 141 */     if (histograms.length == 0) {
/* 142 */       return new Chart[0];
/*     */     }
/* 144 */     Chart chart = new Chart(getName());
/* 145 */     chart.setXaxisLabel("Date");
/* 146 */     chart.setYaxisLabel("Failed Searches per Day");
/* 147 */     chart.setType(2);
/* 148 */     Bin[] bins = histograms[0].getBins();
/* 149 */     String[] labels = new String[bins.length];
/* 150 */     for (int i = 0; i < bins.length; i++) {
/* 151 */       Bin bin = bins[i];
/* 152 */       labels[i] = this.labelFormatter.format(bin);
/*     */     }
/* 154 */     chart.setLabels(labels);
/*     */ 
/* 156 */     return new Chart[] { chart };
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 160 */     Histogram[] histograms = getHistograms();
/* 161 */     if (histograms.length == 0) {
/* 162 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/*     */ 
/* 165 */     List extraInfo = new ArrayList(4);
/* 166 */     extraInfo.add(new Report.ExtraInfo("Total Failed Searches", DecimalFormatter.format("#,##0", new Double(this.count).doubleValue())));
/*     */ 
/* 170 */     extraInfo.add(getDateRange());
/*     */ 
/* 172 */     return new List[] { extraInfo };
/*     */   }
/*     */ 
/*     */   protected Date calculateStartDate() {
/* 176 */     Connection con = null;
/* 177 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 180 */       con = ConnectionManager.getConnection();
/* 181 */       pstmt = con.prepareStatement("SELECT min(searchDate) FROM jiveSearch WHERE searchType=19");
/* 182 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 184 */       if (rs.next()) {
/* 185 */         return new Date(rs.getLong(1));
/*     */       }
/* 187 */       rs.close();
/*     */     } catch (SQLException e) {
/* 189 */       Log.error(e);
/*     */     } finally {
/* 191 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 194 */     return super.calculateStartDate();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.SearchFailedReport
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.stats.report;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class HTTPPageViewsReportBeanInfo extends JiveBeanInfo
/*    */ {
/*    */   public String[] getPropertyNames()
/*    */   {
/* 19 */     return new String[] { "stepSize" };
/*    */   }
/*    */   public Class getBeanClass() {
/* 22 */     return HTTPPageViewsReport.class;
/*    */   }
/*    */   public String getName() {
/* 25 */     return "HTTPPageViewsReport";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.HTTPPageViewsReportBeanInfo
 * JD-Core Version:    0.6.2
 */
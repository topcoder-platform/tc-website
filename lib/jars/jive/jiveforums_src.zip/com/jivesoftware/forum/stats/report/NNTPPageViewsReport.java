/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Element;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.Report.ExtraInfo;
/*     */ import com.jivesoftware.base.stats.bin.DateSequence;
/*     */ import com.jivesoftware.base.stats.element.DateElement;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.base.stats.util.DateFormatter;
/*     */ import com.jivesoftware.base.stats.util.DecimalFormatter;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class NNTPPageViewsReport extends AbstractForumReport
/*     */ {
/*     */   private static final String VIEWS_BY_DATE = "SELECT rs.creationDate FROM jiveReadStat rs, jiveNNTPReadStatSession nrs WHERE rs.sessionID=nrs.sessionID AND rs.creationDate >= ? AND rs.creationDate < ?";
/*     */   private static final String VIEWS_BY_DATE_AND_FORUM = "SELECT rs.creationDate FROM jiveReadStat rs, jiveNNTPReadStatSession nrs WHERE rs.sessionID=nrs.sessionID AND rs.creationDate >= ? AND rs.creationDate < ? AND rs.objectType = 0 AND rs.objectID = ?";
/*  50 */   private long stepSize = 24L;
/*     */ 
/*     */   public long getStepSize()
/*     */   {
/*  56 */     return this.stepSize;
/*     */   }
/*     */ 
/*     */   public void setStepSize(long stepSize) {
/*  60 */     this.stepSize = stepSize;
/*     */   }
/*     */ 
/*     */   public void execute() throws Exception {
/*  64 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  65 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  68 */     Histogram hist = new Histogram(new DateSequence(start, getStepSize() * 60L * 60L * 1000L));
/*  69 */     addHistogram(hist);
/*     */ 
/*  71 */     Connection con = null;
/*  72 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/*  77 */         con = ConnectionManager.getConnection();
/*  78 */         pstmt = con.prepareStatement("SELECT rs.creationDate FROM jiveReadStat rs, jiveNNTPReadStatSession nrs WHERE rs.sessionID=nrs.sessionID AND rs.creationDate >= ? AND rs.creationDate < ?");
/*  79 */         pstmt.setLong(1, start.getTime());
/*  80 */         pstmt.setLong(2, end.getTime());
/*  81 */         ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  83 */         while (rs.next()) {
/*  84 */           hist.add(new DateElement(new Date(rs.getLong(1))));
/*     */         }
/*  86 */         rs.close();
/*  87 */         pstmt.close();
/*     */       }
/*     */       catch (SQLException sqle)
/*     */       {
/*     */       }
/*     */ 
/*  95 */       List forums = getObjects();
/*  96 */       for (iter = forums.iterator(); iter.hasNext(); ) {
/*  97 */         Forum forum = (Forum)iter.next();
/*  98 */         long forumID = forum.getID();
/*  99 */         hist = new Histogram(new DateSequence(start, getStepSize() * 60L * 60L * 1000L));
/* 100 */         addHistogram(hist);
/*     */         try {
/* 102 */           pstmt = con.prepareStatement("SELECT rs.creationDate FROM jiveReadStat rs, jiveNNTPReadStatSession nrs WHERE rs.sessionID=nrs.sessionID AND rs.creationDate >= ? AND rs.creationDate < ? AND rs.objectType = 0 AND rs.objectID = ?");
/* 103 */           pstmt.setLong(1, start.getTime());
/* 104 */           pstmt.setLong(2, end.getTime());
/* 105 */           pstmt.setLong(3, forumID);
/* 106 */           ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 108 */           while (rs.next()) {
/* 109 */             hist.add(new DateElement(new Date(rs.getLong(1))));
/*     */           }
/* 111 */           rs.close();
/* 112 */           pstmt.close();
/*     */         }
/*     */         catch (SQLException sqle)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       Iterator iter;
/* 120 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/* 125 */     Histogram[] histograms = getHistograms();
/* 126 */     if (histograms.length == 0) {
/* 127 */       return new DataTable[0];
/*     */     }
/* 129 */     List tables = new ArrayList(histograms.length);
/* 130 */     for (int i = 0; i < histograms.length; i++) {
/* 131 */       Histogram hist = histograms[i];
/* 132 */       DataTable data = new DataTable(getName());
/* 133 */       data.setColumns(new String[] { "Day", "Views" });
/* 134 */       Bin[] bins = hist.getBins();
/* 135 */       for (int j = 0; j < bins.length; j++) {
/* 136 */         Bin bin = bins[j];
/* 137 */         String week = DateFormatter.format("M/dd/yyyy", new Date(bin.getBegin().toLong().longValue()));
/*     */ 
/* 139 */         long count = hist.getCount(bin);
/* 140 */         data.addRow(new Object[] { week, new Long(count) });
/*     */       }
/* 142 */       tables.add(data);
/*     */     }
/* 144 */     return (DataTable[])tables.toArray(new DataTable[0]);
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 148 */     Histogram[] histograms = getHistograms();
/* 149 */     Chart[] charts = new Chart[histograms.length];
/* 150 */     List forums = getObjects();
/* 151 */     for (int i = 0; i < histograms.length; i++) {
/* 152 */       Histogram hist = histograms[i];
/* 153 */       String name = getName();
/* 154 */       if (i == 0) {
/* 155 */         name = name + " - All forums";
/*     */       }
/*     */       else {
/* 158 */         name = name + " - " + forums.get(i - 1);
/*     */       }
/* 160 */       Chart chart = new Chart(name);
/* 161 */       chart.setXaxisLabel("Dates");
/* 162 */       chart.setYaxisLabel("New Users");
/* 163 */       chart.setType(2);
/* 164 */       Bin[] bins = hist.getBins();
/* 165 */       String[] labels = new String[bins.length];
/* 166 */       for (int j = 0; j < bins.length; j++) {
/* 167 */         Bin bin = bins[j];
/* 168 */         Date begin = new Date(bin.getBegin().toLong().longValue());
/* 169 */         Date end = new Date(bin.getEnd().toLong().longValue());
/* 170 */         Date mid = new Date((begin.getTime() + end.getTime()) / 2L);
/* 171 */         labels[j] = DateFormatter.format("M/dd/yy", mid);
/*     */       }
/* 173 */       chart.setLabels(labels);
/* 174 */       charts[i] = chart;
/*     */     }
/* 176 */     return charts;
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 180 */     Histogram[] histograms = getHistograms();
/* 181 */     if (histograms.length == 0) {
/* 182 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/* 184 */     List lists = new ArrayList(histograms.length);
/* 185 */     for (int i = 0; i < histograms.length; i++) {
/* 186 */       List extraInfo = new ArrayList(4);
/* 187 */       Histogram hist = histograms[i];
/* 188 */       double meanElement = hist.getMeanCount();
/* 189 */       double sumCount = hist.getSumCount();
/*     */ 
/* 192 */       extraInfo.add(getDateRange());
/*     */ 
/* 194 */       extraInfo.add(new Report.ExtraInfo("Total Page Views", DecimalFormatter.format("#,##0", new Double(sumCount).doubleValue())));
/*     */ 
/* 196 */       extraInfo.add(new Report.ExtraInfo("Average Views Per Day", DecimalFormatter.format("#.0", new Double(meanElement).doubleValue())));
/*     */ 
/* 198 */       lists.add(extraInfo);
/*     */     }
/* 200 */     return (List[])lists.toArray(new List[0]);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.NNTPPageViewsReport
 * JD-Core Version:    0.6.2
 */
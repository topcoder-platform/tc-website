/*     */ package com.jivesoftware.forum.stats;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.util.AbstractPollableRunnable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class QuickStats
/*     */ {
/*     */   private static final String HTTP_SESSION_COUNT = "SELECT COUNT(DISTINCT(r.sessionID)) FROM jiveReadStatSession rs, jiveHTTPReadStatSession hs, jiveReadStat r WHERE rs.sessionID=hs.sessionID AND rs.sessionID=r.sessionID AND rs.creationDate >= ? AND rs.creationDate < ?";
/*     */   private static final String HTTP_HIT_COUNT = "SELECT COUNT(*) FROM jiveReadStat r, jiveHTTPReadStatSession s WHERE r.sessionID=s.sessionID AND r.creationDate >= ? AND r.creationDate < ?";
/*     */   private static final String NNTP_SESSION_COUNT = "SELECT COUNT(DISTINCT(r.sessionID)) FROM jiveReadStatSession rs, jiveNNTPReadStatSession ns, jiveReadStat r WHERE rs.sessionID=ns.sessionID AND rs.sessionID=r.sessionID AND rs.creationDate >= ? AND rs.creationDate < ?";
/*     */   private static final String NNTP_HIT_COUNT = "SELECT COUNT(*) FROM jiveReadStat r, jiveNNTPReadStatSession s WHERE r.sessionID=s.sessionID AND r.creationDate >= ? AND r.creationDate < ?";
/*     */   private static final String TOTAL_HTTP_VIEWS = "SELECT COUNT(*) FROM jiveReadStat r, jiveHTTPReadStatSession h WHERE r.sessionID=h.sessionID AND r.creationDate >= ? AND r.creationDate < ?";
/*     */   private static final String TOTAL_NNTP_VIEWS = "SELECT COUNT(*) FROM jiveReadStat r, jiveNNTPReadStatSession n WHERE r.sessionID=n.sessionID AND r.creationDate >= ? AND r.creationDate < ?";
/*     */   private static final String UNIQUE_HTTP_VISITORS = "SELECT COUNT(DISTINCT(visitorID)) FROM jiveReadStatSession rs, jiveHTTPReadStatSession hs WHERE rs.sessionID=hs.sessionID AND creationDate >= ? AND creationDate < ?";
/*     */   private static final String UNIQUE_NNTP_VISITORS = "SELECT COUNT(DISTINCT(visitorID)) FROM jiveReadStatSession rs, jiveNNTPReadStatSession hs WHERE rs.sessionID=hs.sessionID AND creationDate >= ? AND creationDate < ?";
/*     */   private static final String UNIQUE_HTTP_GUESTS = "SELECT COUNT(DISTINCT(visitorID)) FROM jiveHTTPReadStatSession hrss, jiveReadStatSession rss, jiveReadStat rs WHERE hrss.sessionID=rss.sessionID AND rss.sessionID=rs.sessionID AND rs.userID IS NULL AND rss.creationDate >= ? AND rss.creationDate < ?";
/*     */   private static final String UNIQUE_NNTP_GUESTS = "SELECT COUNT(DISTINCT(visitorID)) FROM jiveNNTPReadStatSession hrss, jiveReadStatSession rss, jiveReadStat rs WHERE hrss.sessionID=rss.sessionID AND rss.sessionID=rs.sessionID AND rs.userID IS NULL AND rss.creationDate >= ? AND rss.creationDate < ?";
/*     */   private static final String UNIQUE_HTTP_USERS = "SELECT COUNT(DISTINCT(visitorID)) FROM jiveHTTPReadStatSession hrss, jiveReadStatSession rss, jiveReadStat rs WHERE hrss.sessionID=rss.sessionID AND rss.sessionID=rs.sessionID AND rs.userID IS NOT NULL AND rss.creationDate >= ? AND rss.creationDate < ?";
/*     */   private static final String UNIQUE_NNTP_USERS = "SELECT COUNT(DISTINCT(visitorID)) FROM jiveNNTPReadStatSession hrss, jiveReadStatSession rss, jiveReadStat rs WHERE hrss.sessionID=rss.sessionID AND rss.sessionID=rs.sessionID AND rs.userID IS NOT NULL AND rss.creationDate >= ? AND rss.creationDate < ?";
/*     */   private static final String POPULAR_HTTP_COUNTRIES = "SELECT h.country, COUNT(*) AS c FROM jiveHTTPReadStatSession h, jiveReadStatSession s WHERE h.country IS NOT NULL AND h.sessionID=s.sessionID AND s.creationDate >= ? AND s.creationDate < ? GROUP BY country ORDER BY c DESC";
/*     */   private static final String POPULAR_NNTP_COUNTRY = "SELECT n.country, COUNT(*) AS c FROM jiveNNTPReadStatSession n, jiveReadStatSession r WHERE n.sessionID=r.sessionID AND n.country IS NOT NULL AND r.creationDate >= ? AND r.creationDate < ? GROUP BY n.country ORDER BY c DESC";
/*     */   private static final String NEW_HTTP_TOPICS_COUNT = "SELECT COUNT(DISTINCT(threadID)) FROM jiveMessage m, jiveMessageProp mp WHERE m.messageID=mp.messageID AND mp.name <> 'source' AND m.creationDate >= ? AND m.creationDate < ?";
/*     */   private static final String NEW_NNTP_TOPICS_COUNT = "SELECT COUNT(DISTINCT(threadID)) FROM jiveMessage m, jiveMessageProp mp WHERE m.messageID=mp.messageID AND mp.name = 'source' AND mp.propValue='nntp' AND m.creationDate >= ? AND m.creationDate < ?";
/*     */   private static final String NEW_HTTP_MESSAGES_COUNT = "SELECT COUNT(DISTINCT(m.messageID)) FROM jiveMessage m, jiveMessageProp mp WHERE m.messageID=mp.messageID AND mp.name <> 'source' AND m.creationDate >= ? AND m.creationDate < ?";
/*     */   private static final String NEW_NNTP_MESSAGES_COUNT = "SELECT COUNT(DISTINCT(m.messageID)) FROM jiveMessage m, jiveMessageProp mp WHERE m.messageID=mp.messageID AND mp.name = 'source' AND mp.propValue='nntp' AND m.creationDate >= ? AND m.creationDate < ?";
/*     */   private static final String POPULAR_HTTP_FORUMS_BY_MSG = "SELECT m.forumID, COUNT(*) AS c FROM jiveMessage m WHERE m.creationDate >= ? AND m.creationDate < ? GROUP BY m.forumID ORDER BY c DESC";
/*     */   private static final String POPULAR_NNTP_FORUMS_BY_MSG = "SELECT m.forumID, COUNT(*) AS c FROM jiveMessage m, jiveMessageProp mp WHERE m.messageID=mp.messageID AND mp.name='source' AND mp.propValue='nntp' AND m.creationDate >= ? AND m.creationDate < ? GROUP BY m.forumID ORDER BY c DESC";
/*     */   private static final String POPULAR_HTTP_FORUMS_BY_VIEWS = "SELECT m.forumID, count(*) AS c FROM jiveReadStat r, jiveMessage m, jiveHTTPReadStatSession n WHERE r.sessionID = n.sessionID AND m.messageID = r.objectID AND m.creationDate >= ? AND m.creationDate < ? GROUP BY m.forumID";
/*     */   private static final String POPULAR_NNTP_FORUMS_BY_VIEWS = "SELECT m.forumID, count(*) AS c FROM jivereadstat r, jiveMessage m, jiveNNTPReadStatSession n WHERE r.sessionID = n.sessionID AND m.messageID = r.objectID AND m.creationDate >= ? AND m.creationDate < ? GROUP BY m.forumID";
/*     */   private static final String NEW_USER_COUNT = "SELECT COUNT(*) AS c FROM jiveUser WHERE creationDate >= ? AND creationDate < ?";
/* 144 */   public static Type HTTP_STAT = new Type("http");
/* 145 */   public static Type NNTP_STAT = new Type("nntp");
/*     */   private static Map results;
/* 148 */   private static Object quickStatsLock = new Object();
/*     */ 
/*     */   public static double[] getAvViewsPerSession(Date start, Date end, Type type)
/*     */   {
/* 172 */     verifyType(type);
/* 173 */     verifyDates(start, end);
/*     */ 
/* 175 */     int totalSessions = 0;
/* 176 */     int totalViews = 0;
/*     */ 
/* 178 */     String sessionQuery = null;
/* 179 */     String hitsQuery = null;
/* 180 */     if (type == HTTP_STAT) {
/* 181 */       sessionQuery = "SELECT COUNT(DISTINCT(r.sessionID)) FROM jiveReadStatSession rs, jiveHTTPReadStatSession hs, jiveReadStat r WHERE rs.sessionID=hs.sessionID AND rs.sessionID=r.sessionID AND rs.creationDate >= ? AND rs.creationDate < ?";
/* 182 */       hitsQuery = "SELECT COUNT(*) FROM jiveReadStat r, jiveHTTPReadStatSession s WHERE r.sessionID=s.sessionID AND r.creationDate >= ? AND r.creationDate < ?";
/*     */     }
/* 184 */     else if (type == NNTP_STAT) {
/* 185 */       sessionQuery = "SELECT COUNT(DISTINCT(r.sessionID)) FROM jiveReadStatSession rs, jiveNNTPReadStatSession ns, jiveReadStat r WHERE rs.sessionID=ns.sessionID AND rs.sessionID=r.sessionID AND rs.creationDate >= ? AND rs.creationDate < ?";
/* 186 */       hitsQuery = "SELECT COUNT(*) FROM jiveReadStat r, jiveNNTPReadStatSession s WHERE r.sessionID=s.sessionID AND r.creationDate >= ? AND r.creationDate < ?";
/*     */     }
/*     */ 
/* 189 */     Connection con = null;
/* 190 */     PreparedStatement pstmt = null;
/*     */     try {
/* 192 */       con = ConnectionManager.getConnection();
/* 193 */       pstmt = con.prepareStatement(sessionQuery);
/* 194 */       pstmt.setLong(1, start.getTime());
/* 195 */       pstmt.setLong(2, end.getTime());
/* 196 */       ResultSet rs = pstmt.executeQuery();
/* 197 */       if (rs.next()) {
/* 198 */         totalSessions = rs.getInt(1);
/*     */       }
/* 200 */       rs.close();
/*     */ 
/* 202 */       pstmt = con.prepareStatement(hitsQuery);
/* 203 */       pstmt.setLong(1, start.getTime());
/* 204 */       pstmt.setLong(2, end.getTime());
/* 205 */       rs = pstmt.executeQuery();
/* 206 */       if (rs.next()) {
/* 207 */         totalViews = rs.getInt(1);
/*     */       }
/* 209 */       rs.close();
/*     */     } catch (SQLException sqle) {
/* 211 */       Log.error(sqle);
/*     */     } finally {
/* 213 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 216 */     if (totalSessions <= 0) {
/* 217 */       return new double[] { 0.0D, 1.0D };
/*     */     }
/* 219 */     if (totalViews <= 0) {
/* 220 */       return new double[] { 0.0D, 1.0D };
/*     */     }
/*     */ 
/* 223 */     return new double[] { totalViews, totalSessions };
/*     */   }
/*     */ 
/*     */   public static int getTotalViews(Date start, Date end, Type type)
/*     */   {
/* 240 */     verifyType(type);
/* 241 */     verifyDates(start, end);
/*     */ 
/* 243 */     int count = 0;
/*     */ 
/* 245 */     String query = null;
/* 246 */     if (type == HTTP_STAT) {
/* 247 */       query = "SELECT COUNT(*) FROM jiveReadStat r, jiveHTTPReadStatSession h WHERE r.sessionID=h.sessionID AND r.creationDate >= ? AND r.creationDate < ?";
/*     */     }
/* 249 */     else if (type == NNTP_STAT) {
/* 250 */       query = "SELECT COUNT(*) FROM jiveReadStat r, jiveNNTPReadStatSession n WHERE r.sessionID=n.sessionID AND r.creationDate >= ? AND r.creationDate < ?";
/*     */     }
/*     */ 
/* 253 */     Connection con = null;
/* 254 */     PreparedStatement pstmt = null;
/*     */     try {
/* 256 */       con = ConnectionManager.getConnection();
/* 257 */       pstmt = con.prepareStatement(query);
/* 258 */       pstmt.setLong(1, start.getTime());
/* 259 */       pstmt.setLong(2, end.getTime());
/* 260 */       ResultSet rs = pstmt.executeQuery();
/* 261 */       if (rs.next()) {
/* 262 */         count = rs.getInt(1);
/*     */       }
/* 264 */       rs.close();
/*     */     } catch (SQLException sqle) {
/* 266 */       Log.error(sqle);
/*     */     } finally {
/* 268 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 270 */     return count;
/*     */   }
/*     */ 
/*     */   public static int getUniqueVisitorCount(Date start, Date end, Type type)
/*     */   {
/* 286 */     verifyType(type);
/* 287 */     verifyDates(start, end);
/*     */ 
/* 289 */     int count = 0;
/*     */ 
/* 291 */     String query = null;
/* 292 */     if (type == HTTP_STAT) {
/* 293 */       query = "SELECT COUNT(DISTINCT(visitorID)) FROM jiveReadStatSession rs, jiveHTTPReadStatSession hs WHERE rs.sessionID=hs.sessionID AND creationDate >= ? AND creationDate < ?";
/*     */     }
/* 295 */     else if (type == NNTP_STAT) {
/* 296 */       query = "SELECT COUNT(DISTINCT(visitorID)) FROM jiveReadStatSession rs, jiveNNTPReadStatSession hs WHERE rs.sessionID=hs.sessionID AND creationDate >= ? AND creationDate < ?";
/*     */     }
/*     */ 
/* 299 */     Connection con = null;
/* 300 */     PreparedStatement pstmt = null;
/*     */     try {
/* 302 */       con = ConnectionManager.getConnection();
/* 303 */       pstmt = con.prepareStatement(query);
/* 304 */       pstmt.setLong(1, start.getTime());
/* 305 */       pstmt.setLong(2, end.getTime());
/* 306 */       ResultSet rs = pstmt.executeQuery();
/* 307 */       if (rs.next()) {
/* 308 */         count = rs.getInt(1);
/*     */       }
/* 310 */       rs.close();
/*     */     } catch (SQLException sqle) {
/* 312 */       Log.error(sqle);
/*     */     } finally {
/* 314 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 316 */     return count;
/*     */   }
/*     */ 
/*     */   public static int getUniqueGuestCount(Date start, Date end, Type type)
/*     */   {
/* 331 */     verifyType(type);
/* 332 */     verifyDates(start, end);
/*     */ 
/* 334 */     int count = 0;
/*     */ 
/* 336 */     String query = null;
/* 337 */     if (type == HTTP_STAT) {
/* 338 */       query = "SELECT COUNT(DISTINCT(visitorID)) FROM jiveHTTPReadStatSession hrss, jiveReadStatSession rss, jiveReadStat rs WHERE hrss.sessionID=rss.sessionID AND rss.sessionID=rs.sessionID AND rs.userID IS NULL AND rss.creationDate >= ? AND rss.creationDate < ?";
/*     */     }
/* 340 */     else if (type == NNTP_STAT) {
/* 341 */       query = "SELECT COUNT(DISTINCT(visitorID)) FROM jiveNNTPReadStatSession hrss, jiveReadStatSession rss, jiveReadStat rs WHERE hrss.sessionID=rss.sessionID AND rss.sessionID=rs.sessionID AND rs.userID IS NULL AND rss.creationDate >= ? AND rss.creationDate < ?";
/*     */     }
/*     */ 
/* 344 */     Connection con = null;
/* 345 */     PreparedStatement pstmt = null;
/*     */     try {
/* 347 */       con = ConnectionManager.getConnection();
/* 348 */       pstmt = con.prepareStatement(query);
/* 349 */       pstmt.setLong(1, start.getTime());
/* 350 */       pstmt.setLong(2, end.getTime());
/* 351 */       ResultSet rs = pstmt.executeQuery();
/* 352 */       if (rs.next()) {
/* 353 */         count = rs.getInt(1);
/*     */       }
/* 355 */       rs.close();
/*     */     } catch (SQLException sqle) {
/* 357 */       Log.error(sqle);
/*     */     } finally {
/* 359 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 361 */     return count;
/*     */   }
/*     */ 
/*     */   public static int getUniqueUserCount(Date start, Date end, Type type)
/*     */   {
/* 376 */     verifyType(type);
/* 377 */     verifyDates(start, end);
/*     */ 
/* 379 */     int count = 0;
/*     */ 
/* 381 */     String query = null;
/* 382 */     if (type == HTTP_STAT) {
/* 383 */       query = "SELECT COUNT(DISTINCT(visitorID)) FROM jiveHTTPReadStatSession hrss, jiveReadStatSession rss, jiveReadStat rs WHERE hrss.sessionID=rss.sessionID AND rss.sessionID=rs.sessionID AND rs.userID IS NOT NULL AND rss.creationDate >= ? AND rss.creationDate < ?";
/*     */     }
/* 385 */     else if (type == NNTP_STAT) {
/* 386 */       query = "SELECT COUNT(DISTINCT(visitorID)) FROM jiveNNTPReadStatSession hrss, jiveReadStatSession rss, jiveReadStat rs WHERE hrss.sessionID=rss.sessionID AND rss.sessionID=rs.sessionID AND rs.userID IS NOT NULL AND rss.creationDate >= ? AND rss.creationDate < ?";
/*     */     }
/*     */ 
/* 389 */     Connection con = null;
/* 390 */     PreparedStatement pstmt = null;
/*     */     try {
/* 392 */       con = ConnectionManager.getConnection();
/* 393 */       pstmt = con.prepareStatement(query);
/* 394 */       pstmt.setLong(1, start.getTime());
/* 395 */       pstmt.setLong(2, end.getTime());
/* 396 */       ResultSet rs = pstmt.executeQuery();
/* 397 */       if (rs.next()) {
/* 398 */         count = rs.getInt(1);
/*     */       }
/* 400 */       rs.close();
/*     */     } catch (SQLException sqle) {
/* 402 */       Log.error(sqle);
/*     */     } finally {
/* 404 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 406 */     return count;
/*     */   }
/*     */ 
/*     */   public static Object[][] getPopularCountries(Date start, Date end, Type type, int num)
/*     */   {
/* 425 */     verifyType(type);
/* 426 */     verifyDates(start, end);
/*     */ 
/* 428 */     String query = null;
/* 429 */     if (type == HTTP_STAT) {
/* 430 */       query = "SELECT h.country, COUNT(*) AS c FROM jiveHTTPReadStatSession h, jiveReadStatSession s WHERE h.country IS NOT NULL AND h.sessionID=s.sessionID AND s.creationDate >= ? AND s.creationDate < ? GROUP BY country ORDER BY c DESC";
/*     */     }
/* 432 */     else if (type == NNTP_STAT) {
/* 433 */       query = "SELECT n.country, COUNT(*) AS c FROM jiveNNTPReadStatSession n, jiveReadStatSession r WHERE n.sessionID=r.sessionID AND n.country IS NOT NULL AND r.creationDate >= ? AND r.creationDate < ? GROUP BY n.country ORDER BY c DESC";
/*     */     }
/*     */ 
/* 436 */     Connection con = null;
/* 437 */     PreparedStatement pstmt = null;
/* 438 */     List CountryCodes = new ArrayList(num);
/*     */     try {
/* 440 */       con = ConnectionManager.getConnection();
/* 441 */       pstmt = con.prepareStatement(query);
/* 442 */       pstmt.setLong(1, start.getTime());
/* 443 */       pstmt.setLong(2, end.getTime());
/* 444 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 446 */       int i = num;
/* 447 */       while ((rs.next()) && (i-- > 0)) {
/* 448 */         CountryCodes.add(new Object[] { rs.getString(1), new Integer(rs.getInt(2)) });
/*     */       }
/* 450 */       rs.close();
/*     */     } catch (SQLException sqle) {
/* 452 */       Log.error(sqle);
/*     */     } finally {
/* 454 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 456 */     if (CountryCodes.size() == 0) {
/* 457 */       return new Object[0][0];
/*     */     }
/*     */ 
/* 460 */     return (Object[][])CountryCodes.toArray(new Object[][] { new Object[0] });
/*     */   }
/*     */ 
/*     */   public static int getNewTopicCount(Date start, Date end, Type type, List forumIDs)
/*     */   {
/* 478 */     verifyType(type);
/* 479 */     verifyDates(start, end);
/*     */ 
/* 481 */     String query = null;
/* 482 */     if (type == HTTP_STAT) {
/* 483 */       query = "SELECT COUNT(DISTINCT(threadID)) FROM jiveMessage m, jiveMessageProp mp WHERE m.messageID=mp.messageID AND mp.name <> 'source' AND m.creationDate >= ? AND m.creationDate < ?";
/*     */     }
/* 485 */     else if (type == NNTP_STAT) {
/* 486 */       query = "SELECT COUNT(DISTINCT(threadID)) FROM jiveMessage m, jiveMessageProp mp WHERE m.messageID=mp.messageID AND mp.name = 'source' AND mp.propValue='nntp' AND m.creationDate >= ? AND m.creationDate < ?";
/*     */     }
/*     */ 
/* 490 */     if ((forumIDs != null) && (forumIDs.size() > 0)) {
/* 491 */       StringBuffer extra = new StringBuffer(" AND (");
/* 492 */       int i = 0; for (int n = forumIDs.size(); i < n; i++) {
/* 493 */         extra.append("m.forumID=?");
/* 494 */         if (i + 1 < n) {
/* 495 */           extra.append(" OR ");
/*     */         }
/*     */       }
/* 498 */       extra.append(")");
/* 499 */       query = query + extra.toString();
/*     */     }
/*     */ 
/* 502 */     int count = 0;
/*     */ 
/* 504 */     Connection con = null;
/* 505 */     PreparedStatement pstmt = null;
/*     */     try {
/* 507 */       con = ConnectionManager.getConnection();
/* 508 */       pstmt = con.prepareStatement(query);
/* 509 */       pstmt.setLong(1, start.getTime());
/* 510 */       pstmt.setLong(2, end.getTime());
/*     */       int idx;
/*     */       Iterator iter;
/* 512 */       if ((forumIDs != null) && (forumIDs.size() > 0)) {
/* 513 */         idx = 3;
/* 514 */         for (iter = forumIDs.iterator(); iter.hasNext(); ) {
/* 515 */           Long id = (Long)iter.next();
/* 516 */           pstmt.setLong(idx++, id.longValue());
/*     */         }
/*     */       }
/* 519 */       ResultSet rs = pstmt.executeQuery();
/* 520 */       if (rs.next()) {
/* 521 */         count = rs.getInt(1);
/*     */       }
/* 523 */       rs.close();
/*     */     } catch (SQLException sqle) {
/* 525 */       Log.error(sqle);
/*     */     } finally {
/* 527 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 529 */     return count;
/*     */   }
/*     */ 
/*     */   public static int getNewMessageCount(Date start, Date end, Type type, List forumIDs)
/*     */   {
/* 546 */     verifyType(type);
/* 547 */     verifyDates(start, end);
/*     */ 
/* 549 */     String query = null;
/* 550 */     if (type == HTTP_STAT) {
/* 551 */       query = "SELECT COUNT(DISTINCT(m.messageID)) FROM jiveMessage m, jiveMessageProp mp WHERE m.messageID=mp.messageID AND mp.name <> 'source' AND m.creationDate >= ? AND m.creationDate < ?";
/*     */     }
/* 553 */     else if (type == NNTP_STAT) {
/* 554 */       query = "SELECT COUNT(DISTINCT(m.messageID)) FROM jiveMessage m, jiveMessageProp mp WHERE m.messageID=mp.messageID AND mp.name = 'source' AND mp.propValue='nntp' AND m.creationDate >= ? AND m.creationDate < ?";
/*     */     }
/*     */ 
/* 558 */     if ((forumIDs != null) && (forumIDs.size() > 0)) {
/* 559 */       StringBuffer extra = new StringBuffer(" AND (");
/* 560 */       int i = 0; for (int n = forumIDs.size(); i < n; i++) {
/* 561 */         extra.append("m.forumID=?");
/* 562 */         if (i + 1 < n) {
/* 563 */           extra.append(" OR ");
/*     */         }
/*     */       }
/* 566 */       extra.append(")");
/* 567 */       query = query + extra.toString();
/*     */     }
/*     */ 
/* 570 */     int count = 0;
/*     */ 
/* 572 */     Connection con = null;
/* 573 */     PreparedStatement pstmt = null;
/*     */     try {
/* 575 */       con = ConnectionManager.getConnection();
/* 576 */       pstmt = con.prepareStatement(query);
/* 577 */       pstmt.setLong(1, start.getTime());
/* 578 */       pstmt.setLong(2, end.getTime());
/*     */       int idx;
/*     */       Iterator iter;
/* 580 */       if ((forumIDs != null) && (forumIDs.size() > 0)) {
/* 581 */         idx = 3;
/* 582 */         for (iter = forumIDs.iterator(); iter.hasNext(); ) {
/* 583 */           Long id = (Long)iter.next();
/* 584 */           pstmt.setLong(idx++, id.longValue());
/*     */         }
/*     */       }
/* 587 */       ResultSet rs = pstmt.executeQuery();
/* 588 */       if (rs.next()) {
/* 589 */         count = rs.getInt(1);
/*     */       }
/* 591 */       rs.close();
/*     */     } catch (SQLException sqle) {
/* 593 */       Log.error(sqle);
/*     */     } finally {
/* 595 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 597 */     return count;
/*     */   }
/*     */ 
/*     */   public static Object[][] getPopularForumsByPost(Date start, Date end, Type type, int num)
/*     */   {
/* 616 */     verifyType(type);
/* 617 */     verifyDates(start, end);
/*     */ 
/* 619 */     String query = null;
/* 620 */     if (type == HTTP_STAT) {
/* 621 */       query = "SELECT m.forumID, COUNT(*) AS c FROM jiveMessage m WHERE m.creationDate >= ? AND m.creationDate < ? GROUP BY m.forumID ORDER BY c DESC";
/*     */     }
/* 623 */     else if (type == NNTP_STAT) {
/* 624 */       query = "SELECT m.forumID, COUNT(*) AS c FROM jiveMessage m, jiveMessageProp mp WHERE m.messageID=mp.messageID AND mp.name='source' AND mp.propValue='nntp' AND m.creationDate >= ? AND m.creationDate < ? GROUP BY m.forumID ORDER BY c DESC";
/*     */     }
/*     */ 
/* 627 */     Connection con = null;
/* 628 */     PreparedStatement pstmt = null;
/* 629 */     List results = new ArrayList(num);
/*     */     try {
/* 631 */       con = ConnectionManager.getConnection();
/* 632 */       pstmt = con.prepareStatement(query);
/* 633 */       pstmt.setLong(1, start.getTime());
/* 634 */       pstmt.setLong(2, end.getTime());
/* 635 */       ResultSet rs = pstmt.executeQuery();
/* 636 */       int i = num;
/* 637 */       while ((rs.next()) && (i-- > 0)) {
/* 638 */         results.add(new Object[] { new Long(rs.getLong(1)), new Integer(rs.getInt(2)) });
/*     */       }
/* 640 */       rs.close();
/*     */     } catch (SQLException sqle) {
/* 642 */       sqle.printStackTrace();
/*     */     } finally {
/* 644 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 646 */     if (results.size() == 0) {
/* 647 */       return new Object[0][0];
/*     */     }
/*     */ 
/* 650 */     return (Object[][])results.toArray(new Object[][] { new Object[0] });
/*     */   }
/*     */ 
/*     */   public static Object[][] getPopularForumsByViews(Date start, Date end, Type type, int num)
/*     */   {
/* 670 */     verifyType(type);
/* 671 */     verifyDates(start, end);
/*     */ 
/* 673 */     String query = null;
/* 674 */     if (type == HTTP_STAT) {
/* 675 */       query = "SELECT m.forumID, count(*) AS c FROM jiveReadStat r, jiveMessage m, jiveHTTPReadStatSession n WHERE r.sessionID = n.sessionID AND m.messageID = r.objectID AND m.creationDate >= ? AND m.creationDate < ? GROUP BY m.forumID";
/*     */     }
/* 677 */     else if (type == NNTP_STAT) {
/* 678 */       query = "SELECT m.forumID, count(*) AS c FROM jivereadstat r, jiveMessage m, jiveNNTPReadStatSession n WHERE r.sessionID = n.sessionID AND m.messageID = r.objectID AND m.creationDate >= ? AND m.creationDate < ? GROUP BY m.forumID";
/*     */     }
/*     */ 
/* 681 */     Connection con = null;
/* 682 */     PreparedStatement pstmt = null;
/* 683 */     List results = new ArrayList(num);
/*     */     try {
/* 685 */       con = ConnectionManager.getConnection();
/* 686 */       pstmt = con.prepareStatement(query);
/* 687 */       pstmt.setLong(1, start.getTime());
/* 688 */       pstmt.setLong(2, end.getTime());
/* 689 */       ResultSet rs = pstmt.executeQuery();
/* 690 */       int i = num;
/* 691 */       while ((rs.next()) && (i-- > 0)) {
/* 692 */         results.add(new Object[] { new Long(rs.getLong(1)), new Integer(rs.getInt(2)) });
/*     */       }
/* 694 */       rs.close();
/*     */     } catch (SQLException sqle) {
/* 696 */       sqle.printStackTrace();
/*     */     } finally {
/* 698 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 700 */     if (results.size() == 0) {
/* 701 */       return new Object[0][0];
/*     */     }
/*     */ 
/* 704 */     return (Object[][])results.toArray(new Object[][] { new Object[0] });
/*     */   }
/*     */ 
/*     */   public static int getNewUserCount(Date start, Date end)
/*     */   {
/* 718 */     int count = 0;
/* 719 */     Connection con = null;
/* 720 */     PreparedStatement pstmt = null;
/*     */     try {
/* 722 */       con = ConnectionManager.getConnection();
/* 723 */       pstmt = con.prepareStatement("SELECT COUNT(*) AS c FROM jiveUser WHERE creationDate >= ? AND creationDate < ?");
/* 724 */       pstmt.setLong(1, start.getTime());
/* 725 */       pstmt.setLong(2, end.getTime());
/* 726 */       ResultSet rs = pstmt.executeQuery();
/* 727 */       if (rs.next()) {
/* 728 */         count = rs.getInt(1);
/*     */       }
/* 730 */       rs.close();
/*     */     } catch (SQLException sqle) {
/* 732 */       Log.error(sqle);
/*     */     } finally {
/* 734 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 736 */     return count;
/*     */   }
/*     */ 
/*     */   public static void verifyDates(Date start, Date end)
/*     */   {
/* 743 */     if ((start == null) || (end == null)) {
/* 744 */       throw new IllegalArgumentException("Dates must not be null");
/*     */     }
/*     */ 
/* 747 */     if (start.getTime() > end.getTime())
/* 748 */       throw new IllegalArgumentException("Start date must be before end date");
/*     */   }
/*     */ 
/*     */   private static void verifyType(Type type)
/*     */   {
/* 757 */     if ((type == null) || ((type != HTTP_STAT) && (type != NNTP_STAT)))
/* 758 */       throw new IllegalArgumentException("Invalid type");
/*     */   }
/*     */ 
/*     */   public static Map getResults()
/*     */   {
/* 784 */     return results;
/*     */   }
/*     */ 
/*     */   public static class QuickStatsGenerator extends AbstractPollableRunnable
/*     */   {
/*     */     private Date fromDate;
/*     */     private Date toDate;
/*     */     private List fullForumIDs;
/* 797 */     private double taskValue = 0.0D;
/* 798 */     private double incr = 0.0D;
/*     */     private Map parameters;
/*     */ 
/*     */     public QuickStatsGenerator(Date fromDate, Date toDate, List fullForumIDs)
/*     */     {
/* 803 */       this.fromDate = fromDate;
/* 804 */       this.toDate = toDate;
/* 805 */       this.fullForumIDs = fullForumIDs;
/* 806 */       this.incr = 5.263157894736843D;
/*     */     }
/*     */ 
/*     */     public int getTaskValue() {
/* 810 */       return (int)Math.round(this.taskValue);
/*     */     }
/*     */ 
/*     */     public void setParameters(Map parameters) {
/* 814 */       this.parameters = parameters;
/*     */     }
/*     */ 
/*     */     public void doRun() {
/* 818 */       Map results = new HashMap();
/* 819 */       results.put("date", new Date());
/*     */ 
/* 821 */       long time = System.currentTimeMillis();
/*     */ 
/* 823 */       results.put("httpViewCount", new Integer(QuickStats.getTotalViews(this.fromDate, this.toDate, QuickStats.HTTP_STAT)));
/* 824 */       this.taskValue += this.incr;
/* 825 */       results.put("nntpViewCount", new Integer(QuickStats.getTotalViews(this.fromDate, this.toDate, QuickStats.NNTP_STAT)));
/* 826 */       this.taskValue += this.incr;
/* 827 */       results.put("popHTTPCountries", QuickStats.getPopularCountries(this.fromDate, this.toDate, QuickStats.HTTP_STAT, 5));
/* 828 */       this.taskValue += this.incr;
/* 829 */       results.put("popNNTPIPs", QuickStats.getPopularCountries(this.fromDate, this.toDate, QuickStats.NNTP_STAT, 5));
/* 830 */       this.taskValue += this.incr;
/* 831 */       results.put("httpViewsPerSession", QuickStats.getAvViewsPerSession(this.fromDate, this.toDate, QuickStats.HTTP_STAT));
/* 832 */       this.taskValue += this.incr;
/* 833 */       results.put("nntpViewsPerSession", QuickStats.getAvViewsPerSession(this.fromDate, this.toDate, QuickStats.NNTP_STAT));
/* 834 */       this.taskValue += this.incr;
/* 835 */       results.put("httpGuestCount", new Integer(QuickStats.getUniqueGuestCount(this.fromDate, this.toDate, QuickStats.HTTP_STAT)));
/* 836 */       this.taskValue += this.incr;
/* 837 */       results.put("httpUserCount", new Integer(QuickStats.getUniqueUserCount(this.fromDate, this.toDate, QuickStats.HTTP_STAT)));
/* 838 */       this.taskValue += this.incr;
/* 839 */       results.put("nntpGuestCount", new Integer(QuickStats.getUniqueGuestCount(this.fromDate, this.toDate, QuickStats.NNTP_STAT)));
/* 840 */       this.taskValue += this.incr;
/* 841 */       results.put("nntpUserCount", new Integer(QuickStats.getUniqueUserCount(this.fromDate, this.toDate, QuickStats.NNTP_STAT)));
/* 842 */       this.taskValue += this.incr;
/* 843 */       results.put("newUserCount", new Integer(QuickStats.getNewUserCount(this.fromDate, this.toDate)));
/* 844 */       this.taskValue += this.incr;
/* 845 */       results.put("httpNewTopics", new Integer(QuickStats.getNewTopicCount(this.fromDate, this.toDate, QuickStats.HTTP_STAT, this.fullForumIDs)));
/* 846 */       this.taskValue += this.incr;
/* 847 */       results.put("nntpNewTopics", new Integer(QuickStats.getNewTopicCount(this.fromDate, this.toDate, QuickStats.NNTP_STAT, this.fullForumIDs)));
/* 848 */       this.taskValue += this.incr;
/* 849 */       results.put("httpNewMsg", new Integer(QuickStats.getNewMessageCount(this.fromDate, this.toDate, QuickStats.HTTP_STAT, this.fullForumIDs)));
/* 850 */       this.taskValue += this.incr;
/* 851 */       results.put("nntpNewMsg", new Integer(QuickStats.getNewMessageCount(this.fromDate, this.toDate, QuickStats.NNTP_STAT, this.fullForumIDs)));
/* 852 */       this.taskValue += this.incr;
/* 853 */       results.put("popHttpForumsByPost", QuickStats.getPopularForumsByPost(this.fromDate, this.toDate, QuickStats.HTTP_STAT, 5));
/* 854 */       this.taskValue += this.incr;
/* 855 */       results.put("popNntpForumsByPost", QuickStats.getPopularForumsByPost(this.fromDate, this.toDate, QuickStats.NNTP_STAT, 5));
/* 856 */       this.taskValue += this.incr;
/* 857 */       results.put("popHttpForumsByView", QuickStats.getPopularForumsByViews(this.fromDate, this.toDate, QuickStats.HTTP_STAT, 5));
/* 858 */       this.taskValue += this.incr;
/* 859 */       results.put("popNNTPForumsByView", QuickStats.getPopularForumsByViews(this.fromDate, this.toDate, QuickStats.NNTP_STAT, 5));
/* 860 */       this.taskValue += this.incr;
/*     */ 
/* 862 */       time = System.currentTimeMillis() - time;
/* 863 */       results.put("time", new Long(time));
/*     */ 
/* 865 */       synchronized (QuickStats.quickStatsLock) {
/* 866 */         if (QuickStats.results == null) {
/* 867 */           QuickStats.access$102(new HashMap());
/*     */         }
/* 869 */         QuickStats.results.clear();
/* 870 */         QuickStats.results.putAll(results);
/* 871 */         if (this.parameters != null)
/* 872 */           QuickStats.results.put("parameters", this.parameters);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Type
/*     */   {
/*     */     private String name;
/*     */ 
/*     */     public Type(String name)
/*     */     {
/* 768 */       this.name = name;
/*     */     }
/*     */     public String getName() {
/* 771 */       return this.name;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.QuickStats
 * JD-Core Version:    0.6.2
 */
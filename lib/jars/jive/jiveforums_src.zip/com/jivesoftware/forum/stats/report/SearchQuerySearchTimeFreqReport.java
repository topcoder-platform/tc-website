/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.BinFormat;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.Report.ExtraInfo;
/*     */ import com.jivesoftware.base.stats.bin.VariableStepSequence;
/*     */ import com.jivesoftware.base.stats.element.LongElement;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.base.stats.util.DecimalFormatter;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ public class SearchQuerySearchTimeFreqReport extends AbstractForumReport
/*     */ {
/*     */   private static final String EARLIEST_SEARCH_DATE = "SELECT min(searchDate) FROM jiveSearch WHERE searchType=19";
/*     */   private static final String SEARCH_QUERIES = "SELECT searchDuration from jiveSearch WHERE searchDate >= ? AND searchDate <= ? AND searchType=19";
/*  43 */   private BinFormat labelFormatter = new BinFormat("$1");
/*     */ 
/*     */   public void execute()
/*     */   {
/*  53 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  54 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  56 */     if (end.compareTo(start) < 0)
/*     */     {
/*  58 */       start = end;
/*     */     }
/*     */ 
/*  61 */     long[] lowerLimit = { 0L, 1000L, 5000L, 10000L };
/*  62 */     long[] upperLimit = { 100L, 250L, 1000L, 5000L };
/*  63 */     VariableStepSequence sequence = new VariableStepSequence(lowerLimit, upperLimit);
/*  64 */     Histogram hist = new Histogram(sequence);
/*  65 */     addHistogram(hist);
/*     */ 
/*  67 */     Connection con = null;
/*  68 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/*  71 */       con = ConnectionManager.getConnection();
/*  72 */       pstmt = con.prepareStatement("SELECT searchDuration from jiveSearch WHERE searchDate >= ? AND searchDate <= ? AND searchType=19");
/*  73 */       pstmt.setLong(1, start.getTime());
/*  74 */       pstmt.setLong(2, end.getTime());
/*  75 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  77 */       while (rs.next()) {
/*  78 */         long searchDuration = rs.getLong(1);
/*     */ 
/*  80 */         searchDuration = (int)(searchDuration / 100L) * 100;
/*     */ 
/*  84 */         if (searchDuration > 60000L) {
/*  85 */           searchDuration = 60000L;
/*     */         }
/*     */ 
/*  88 */         hist.add(new LongElement(searchDuration), 1L);
/*     */       }
/*  90 */       rs.close();
/*     */     } catch (SQLException e) {
/*  92 */       Log.error(e);
/*     */     } finally {
/*  94 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/*  99 */     Histogram[] histograms = getHistograms();
/* 100 */     if (histograms.length == 0) {
/* 101 */       return new DataTable[0];
/*     */     }
/* 103 */     DataTable data = new DataTable(getName());
/* 104 */     data.setColumns(new String[] { "Time (ms)", "Searches" });
/* 105 */     Histogram hist = histograms[0];
/* 106 */     Bin[] bins = hist.getBins();
/* 107 */     for (int i = 0; i < bins.length; i++) {
/* 108 */       Bin bin = bins[i];
/* 109 */       long count = hist.getCount(bin);
/* 110 */       data.addRow(new Object[] { bin.getBegin(), new Long(count) });
/*     */     }
/* 112 */     return new DataTable[] { data };
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 116 */     Histogram hist = getHistograms()[0];
/* 117 */     String name = getName();
/*     */ 
/* 119 */     Chart chart = new Chart(name);
/* 120 */     chart.setXaxisLabel("Time (ms)");
/* 121 */     chart.setYaxisLabel("Searches");
/* 122 */     chart.setType(1);
/* 123 */     Bin[] bins = hist.getBins();
/* 124 */     String[] labels = new String[bins.length];
/* 125 */     for (int j = 0; j < bins.length; j++) {
/* 126 */       labels[j] = this.labelFormatter.format(bins[j]);
/*     */     }
/* 128 */     chart.setLabels(labels);
/*     */ 
/* 130 */     return new Chart[] { chart };
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 134 */     Histogram[] histograms = getHistograms();
/* 135 */     if (histograms.length == 0) {
/* 136 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/*     */ 
/* 139 */     List extraInfo = new ArrayList(4);
/* 140 */     Histogram hist = histograms[0];
/* 141 */     double sumCount = hist.getNElement();
/*     */ 
/* 143 */     extraInfo.add(new Report.ExtraInfo("Total Searches", DecimalFormatter.format("#,##0", new Double(sumCount).doubleValue())));
/*     */ 
/* 147 */     extraInfo.add(getDateRange());
/*     */ 
/* 149 */     return new List[] { extraInfo };
/*     */   }
/*     */ 
/*     */   protected Date calculateStartDate() {
/* 153 */     Connection con = null;
/* 154 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 157 */       con = ConnectionManager.getConnection();
/* 158 */       pstmt = con.prepareStatement("SELECT min(searchDate) FROM jiveSearch WHERE searchType=19");
/* 159 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 161 */       if (rs.next()) {
/* 162 */         return new Date(rs.getLong(1));
/*     */       }
/* 164 */       rs.close();
/*     */     } catch (SQLException e) {
/* 166 */       Log.error(e);
/*     */     } finally {
/* 168 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 171 */     return super.calculateStartDate();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.SearchQuerySearchTimeFreqReport
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.BinFormat;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.Report.ExtraInfo;
/*     */ import com.jivesoftware.base.stats.bin.CyclicSequence;
/*     */ import com.jivesoftware.base.stats.element.CyclicElement;
/*     */ import com.jivesoftware.base.stats.element.HourOfDayElementFormat;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class HourOfDayReport extends AbstractForumReport
/*     */ {
/*     */   private static final String NEW_MESSAGES_BY_DATE = "SELECT creationDate FROM jiveMessage WHERE creationDate >= ? AND creationDate < ?";
/*     */   private static final String NEW_MESSAGES_BY_FORUM_AND_DATE = "SELECT creationDate FROM jiveMessage WHERE forumID = ? AND creationDate >= ? AND creationDate < ?";
/*  42 */   private BinFormat labelFormatter = new BinFormat(new HourOfDayElementFormat("ha"), "$1");
/*     */ 
/*     */   public void execute()
/*     */     throws Exception
/*     */   {
/*  47 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  48 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  51 */     Histogram hist = new Histogram(new CyclicSequence(24L), new CyclicElement(24L, 0L, 0L), new CyclicElement(24L, 23L, 0L));
/*     */ 
/*  54 */     addHistogram(hist);
/*     */ 
/*  56 */     Connection con = null;
/*  57 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/*  61 */       cal = Calendar.getInstance(JiveGlobals.getTimeZone(), JiveGlobals.getLocale());
/*     */       try
/*     */       {
/*  65 */         con = ConnectionManager.getConnection();
/*  66 */         pstmt = con.prepareStatement("SELECT creationDate FROM jiveMessage WHERE creationDate >= ? AND creationDate < ?");
/*  67 */         pstmt.setLong(1, start.getTime());
/*  68 */         pstmt.setLong(2, end.getTime());
/*  69 */         ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  71 */         while (rs.next()) {
/*  72 */           cal.setTime(new Date(rs.getLong(1)));
/*  73 */           hist.add(new CyclicElement(24L, 0L, cal.get(11)));
/*     */         }
/*  75 */         rs.close();
/*  76 */         pstmt.close();
/*     */       }
/*     */       catch (SQLException sqle)
/*     */       {
/*     */       }
/*     */ 
/*  84 */       List forums = getObjects();
/*  85 */       for (iter = forums.iterator(); iter.hasNext(); ) {
/*  86 */         Forum forum = (Forum)iter.next();
/*  87 */         long forumID = forum.getID();
/*  88 */         hist = new Histogram(new CyclicSequence(24L), new CyclicElement(24L, 0L, 0L), new CyclicElement(24L, 23L, 0L));
/*     */ 
/*  91 */         addHistogram(hist);
/*     */         try {
/*  93 */           pstmt = con.prepareStatement("SELECT creationDate FROM jiveMessage WHERE forumID = ? AND creationDate >= ? AND creationDate < ?");
/*  94 */           pstmt.setLong(1, forumID);
/*  95 */           pstmt.setLong(2, start.getTime());
/*  96 */           pstmt.setLong(3, end.getTime());
/*  97 */           ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  99 */           while (rs.next()) {
/* 100 */             cal.setTime(new Date(rs.getLong(1)));
/* 101 */             hist.add(new CyclicElement(24L, 0L, cal.get(11)));
/*     */           }
/* 103 */           rs.close();
/* 104 */           pstmt.close();
/*     */         }
/*     */         catch (SQLException sqle)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       Calendar cal;
/*     */       Iterator iter;
/* 112 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/* 117 */     Histogram[] histograms = getHistograms();
/* 118 */     if (histograms.length == 0) {
/* 119 */       return new DataTable[0];
/*     */     }
/* 121 */     List tables = new ArrayList(histograms.length);
/* 122 */     for (int i = 0; i < histograms.length; i++) {
/* 123 */       Histogram hist = histograms[i];
/* 124 */       DataTable data = new DataTable(getName());
/* 125 */       data.setColumns(new String[] { "Hour of the Day", "Messages" });
/* 126 */       Bin[] bins = hist.getBins();
/* 127 */       for (int j = 0; j < bins.length; j++) {
/* 128 */         Bin bin = bins[j];
/* 129 */         long count = hist.getCount(bin);
/* 130 */         data.addRow(new Object[] { this.labelFormatter.format(bin), new Long(count) });
/*     */       }
/* 132 */       tables.add(data);
/*     */     }
/* 134 */     return (DataTable[])tables.toArray(new DataTable[0]);
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 138 */     Histogram[] histograms = getHistograms();
/* 139 */     if (histograms.length == 0) {
/* 140 */       return new Chart[0];
/*     */     }
/* 142 */     List charts = new ArrayList(histograms.length);
/* 143 */     for (int i = 0; i < histograms.length; i++) {
/* 144 */       Histogram hist = histograms[i];
/* 145 */       String name = getName();
/* 146 */       if (i == 0) {
/* 147 */         name = name + " - All forums";
/*     */       }
/*     */       else {
/* 150 */         name = name + " - " + getObjects().get(i - 1);
/*     */       }
/* 152 */       Chart chart = new Chart(name);
/* 153 */       chart.setXaxisLabel("Hour of the Day");
/* 154 */       chart.setXaxisLabel("Messages");
/* 155 */       chart.setType(2);
/* 156 */       Bin[] bins = hist.getBins();
/* 157 */       String[] labels = new String[bins.length];
/* 158 */       for (int j = 0; j < bins.length; j++) {
/* 159 */         Bin bin = bins[j];
/* 160 */         labels[j] = this.labelFormatter.format(bin);
/*     */       }
/* 162 */       chart.setLabels(labels);
/* 163 */       charts.add(chart);
/*     */     }
/* 165 */     return (Chart[])charts.toArray(new Chart[0]);
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 169 */     Histogram[] histograms = getHistograms();
/* 170 */     if (histograms.length == 0) {
/* 171 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/* 173 */     List lists = new ArrayList(histograms.length);
/* 174 */     for (int i = 0; i < histograms.length; i++) {
/* 175 */       List extraInfo = new ArrayList(4);
/* 176 */       Histogram hist = histograms[i];
/* 177 */       if (hist.getNElement() > 0L)
/*     */       {
/* 179 */         extraInfo.add(new Report.ExtraInfo("Median messages/hour", new Long(hist.getMedianCount())));
/*     */ 
/* 181 */         extraInfo.add(new Report.ExtraInfo("Peak Hour", hist.getMaxCountBin()));
/*     */       }
/*     */ 
/* 185 */       extraInfo.add(getDateRange());
/*     */ 
/* 187 */       lists.add(extraInfo);
/*     */     }
/* 189 */     return (List[])lists.toArray(new List[0]);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.HourOfDayReport
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Element;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.Report.ExtraInfo;
/*     */ import com.jivesoftware.base.stats.bin.DateSequence;
/*     */ import com.jivesoftware.base.stats.element.DateElement;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.base.stats.util.DateFormatter;
/*     */ import com.jivesoftware.base.stats.util.DecimalFormatter;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ public class SearchQueryReport extends AbstractForumReport
/*     */ {
/*     */   private static final String EARLIEST_SEARCH_DATE = "SELECT min(searchDate) FROM jiveSearch WHERE searchType=19";
/*     */   private static final String SEARCH_QUERIES = "SELECT searchDate from jiveSearch WHERE searchDate >= ? AND searchDate <= ? AND searchType=19";
/*  44 */   private int count = 0;
/*  45 */   private Bin[] bins = null;
/*     */ 
/*     */   public void execute()
/*     */   {
/*  50 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  51 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  53 */     if (end.compareTo(start) < 0)
/*     */     {
/*  55 */       start = end;
/*     */     }
/*     */ 
/*  58 */     Histogram hist = null;
/*     */ 
/*  61 */     if (end.getTime() - start.getTime() <= 90000000L) {
/*  62 */       hist = new Histogram(new DateSequence(start, 3600000L), new DateElement(start), new DateElement(end));
/*     */     }
/*  65 */     else if (end.getTime() - start.getTime() <= 2678400000L) {
/*  66 */       hist = new Histogram(new DateSequence(start, 86400000L), new DateElement(start), new DateElement(end));
/*     */     }
/*     */     else
/*     */     {
/*  70 */       hist = new Histogram(new DateSequence(start, 604800000L), new DateElement(start), new DateElement(end));
/*     */     }
/*     */ 
/*  73 */     addHistogram(hist);
/*     */ 
/*  75 */     Connection con = null;
/*  76 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/*  79 */       con = ConnectionManager.getConnection();
/*  80 */       pstmt = con.prepareStatement("SELECT searchDate from jiveSearch WHERE searchDate >= ? AND searchDate <= ? AND searchType=19");
/*  81 */       pstmt.setLong(1, start.getTime());
/*  82 */       pstmt.setLong(2, end.getTime());
/*  83 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  85 */       while (rs.next()) {
/*  86 */         hist.add(new DateElement(new Date(rs.getLong(1))));
/*  87 */         this.count += 1;
/*     */       }
/*  89 */       rs.close();
/*     */     } catch (SQLException e) {
/*  91 */       Log.error(e);
/*     */     } finally {
/*  93 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/*  98 */     Histogram[] histograms = getHistograms();
/*  99 */     if (histograms.length == 0) {
/* 100 */       return new DataTable[0];
/*     */     }
/* 102 */     DataTable data = new DataTable(getName());
/* 103 */     data.setColumns(new String[] { "Week", "Searches" });
/* 104 */     Histogram hist = histograms[0];
/* 105 */     Bin[] bins = getBins();
/* 106 */     for (int i = 0; i < bins.length; i++) {
/* 107 */       Bin bin = bins[i];
/* 108 */       String week = DateFormatter.format("M/dd/yyyy", new Date(bin.getBegin().toLong().longValue()));
/*     */ 
/* 110 */       long count = hist.getCount(bin);
/* 111 */       data.addRow(new Object[] { week, new Long(count) });
/*     */     }
/* 113 */     return new DataTable[] { data };
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 117 */     String name = getName();
/* 118 */     Chart chart = new Chart(name);
/* 119 */     chart.setXaxisLabel("Date");
/* 120 */     chart.setYaxisLabel("Searches");
/* 121 */     chart.setType(2);
/* 122 */     Bin[] bins = getBins();
/* 123 */     String[] labels = new String[bins.length];
/* 124 */     for (int j = 0; j < bins.length; j++) {
/* 125 */       Bin bin = bins[j];
/* 126 */       Date begin = new Date(bin.getBegin().toLong().longValue());
/* 127 */       Date end = new Date(bin.getEnd().toLong().longValue());
/* 128 */       Date mid = new Date((begin.getTime() + end.getTime()) / 2L);
/* 129 */       labels[j] = DateFormatter.format("M/dd/yy", mid);
/*     */     }
/* 131 */     chart.setLabels(labels);
/* 132 */     return new Chart[] { chart };
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 136 */     Histogram[] histograms = getHistograms();
/* 137 */     if (histograms.length == 0) {
/* 138 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/*     */ 
/* 141 */     List extraInfo = new ArrayList(4);
/* 142 */     Histogram hist = histograms[0];
/* 143 */     double meanElement = hist.getMeanCount();
/* 144 */     Bin peak = hist.getMaxCountBin();
/*     */ 
/* 146 */     extraInfo.add(new Report.ExtraInfo("Total Searches", DecimalFormatter.format("#,##0", new Double(this.count).doubleValue())));
/*     */ 
/* 150 */     extraInfo.add(getDateRange());
/*     */ 
/* 152 */     extraInfo.add(new Report.ExtraInfo("Average Searches Per Week", DecimalFormatter.format("#.0", new Double(meanElement).doubleValue())));
/*     */ 
/* 155 */     if (peak != null) {
/* 156 */       extraInfo.add(new Report.ExtraInfo("Peak Week", hist.getCount(peak) + ", Week of " + DateFormatter.format("EEEE, MMM d, yyyy", new Date(peak.getBegin().toLong().longValue()))));
/*     */     }
/*     */ 
/* 161 */     return new List[] { extraInfo };
/*     */   }
/*     */ 
/*     */   protected Date calculateStartDate() {
/* 165 */     Connection con = null;
/* 166 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 169 */       con = ConnectionManager.getConnection();
/* 170 */       pstmt = con.prepareStatement("SELECT min(searchDate) FROM jiveSearch WHERE searchType=19");
/* 171 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 173 */       if (rs.next()) {
/* 174 */         return new Date(rs.getLong(1));
/*     */       }
/* 176 */       rs.close();
/*     */     } catch (SQLException e) {
/* 178 */       Log.error(e);
/*     */     } finally {
/* 180 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 183 */     return super.calculateStartDate();
/*     */   }
/*     */ 
/*     */   private Bin[] getBins()
/*     */   {
/* 191 */     if (this.bins != null) {
/* 192 */       return this.bins;
/*     */     }
/*     */ 
/* 195 */     long interval = ((DateSequence)getHistograms()[0].getBinSequence()).getStep().toLong().longValue();
/* 196 */     Histogram hist = getHistograms()[0];
/* 197 */     this.bins = hist.getBins();
/* 198 */     for (int i = 0; i < this.bins.length; i++) {
/* 199 */       if (interval == 3600000L) {
/* 200 */         hist.setCount(this.bins[i], hist.getCount(this.bins[i]) * 24L);
/*     */       }
/* 202 */       else if ((interval == 604800000L) && 
/* 203 */         (hist.getCount(this.bins[i]) > 0L)) {
/* 204 */         hist.setCount(this.bins[i], hist.getCount(this.bins[i]) / 7L);
/*     */       }
/*     */     }
/*     */ 
/* 208 */     return this.bins;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.SearchQueryReport
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.BinFormat;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.Report.ExtraInfo;
/*     */ import com.jivesoftware.base.stats.bin.SigFigSequence;
/*     */ import com.jivesoftware.base.stats.element.LongElement;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class RepliesPerThreadReport extends AbstractForumReport
/*     */ {
/*     */   private static final String REPLIES_PER_TOPIC_BY_DATE = "SELECT (count(messageID)-1) FROM jiveMessage jm, jiveThread jt WHERE jm.threadID = jt.threadID AND jt.creationDate >= ? AND jt.creationDate < ? GROUP BY jm.threadID";
/*     */   private static final String REPLIES_PER_TOPIC_BY_FORUM_AND_DATE = "SELECT (count(messageID)-1) FROM jiveMessage jm, jiveThread jt WHERE jm.forumID = ? AND jm.threadID = jt.threadID AND jt.creationDate >= ? AND jt.creationDate < ? GROUP BY jm.threadID";
/*  45 */   private BinFormat labelFormatter = new BinFormat("$1-$2 replies", "$1 replies");
/*     */ 
/*     */   public void execute()
/*     */   {
/*  51 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  52 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  54 */     SigFigSequence sigFigSeq = new SigFigSequence(1, 2L);
/*  55 */     Histogram hist = new Histogram(sigFigSeq);
/*  56 */     addHistogram(hist);
/*     */ 
/*  58 */     Connection con = null;
/*  59 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/*  64 */         con = ConnectionManager.getConnection();
/*  65 */         pstmt = con.prepareStatement("SELECT (count(messageID)-1) FROM jiveMessage jm, jiveThread jt WHERE jm.threadID = jt.threadID AND jt.creationDate >= ? AND jt.creationDate < ? GROUP BY jm.threadID");
/*  66 */         pstmt.setLong(1, start.getTime());
/*  67 */         pstmt.setLong(2, end.getTime());
/*  68 */         ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  70 */         while (rs.next()) {
/*  71 */           hist.add(new LongElement(rs.getLong(1)));
/*     */         }
/*  73 */         rs.close();
/*  74 */         pstmt.close();
/*     */       }
/*     */       catch (SQLException sqle)
/*     */       {
/*     */       }
/*     */ 
/*  82 */       List forums = getObjects();
/*  83 */       for (iter = forums.iterator(); iter.hasNext(); ) {
/*  84 */         Forum forum = (Forum)iter.next();
/*  85 */         long forumID = forum.getID();
/*  86 */         sigFigSeq = new SigFigSequence(1, 2L);
/*  87 */         hist = new Histogram(sigFigSeq);
/*  88 */         addHistogram(hist);
/*     */         try {
/*  90 */           pstmt = con.prepareStatement("SELECT (count(messageID)-1) FROM jiveMessage jm, jiveThread jt WHERE jm.forumID = ? AND jm.threadID = jt.threadID AND jt.creationDate >= ? AND jt.creationDate < ? GROUP BY jm.threadID");
/*  91 */           pstmt.setLong(1, forumID);
/*  92 */           pstmt.setLong(2, start.getTime());
/*  93 */           pstmt.setLong(3, end.getTime());
/*  94 */           ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  96 */           while (rs.next()) {
/*  97 */             hist.add(new LongElement(rs.getLong(1)));
/*     */           }
/*  99 */           rs.close();
/* 100 */           pstmt.close();
/*     */         }
/*     */         catch (SQLException sqle)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       Iterator iter;
/* 108 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/* 113 */     Histogram[] histograms = getHistograms();
/* 114 */     if (histograms.length == 0) {
/* 115 */       return new DataTable[0];
/*     */     }
/* 117 */     List tables = new ArrayList(histograms.length);
/* 118 */     for (int i = 0; i < histograms.length; i++) {
/* 119 */       Histogram hist = histograms[i];
/* 120 */       DataTable data = new DataTable(getName());
/* 121 */       data.setColumns(new String[] { "Replies", "Topics" });
/* 122 */       Bin[] bins = hist.getBins();
/* 123 */       for (int j = 0; j < bins.length; j++) {
/* 124 */         Bin bin = bins[j];
/* 125 */         long count = hist.getCount(bin);
/* 126 */         data.addRow(new Object[] { this.labelFormatter.format(bin), new Long(count) });
/*     */       }
/* 128 */       tables.add(data);
/*     */     }
/* 130 */     return (DataTable[])tables.toArray(new DataTable[0]);
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 134 */     Histogram[] histograms = getHistograms();
/* 135 */     if (histograms.length == 0) {
/* 136 */       return new Chart[0];
/*     */     }
/* 138 */     List charts = new ArrayList(histograms.length);
/* 139 */     for (int i = 0; i < histograms.length; i++) {
/* 140 */       Histogram hist = histograms[i];
/* 141 */       String name = getName();
/* 142 */       if (i == 0) {
/* 143 */         name = name + " - All forums";
/*     */       }
/*     */       else {
/* 146 */         name = name + " - " + getObjects().get(i - 1);
/*     */       }
/* 148 */       Chart chart = new Chart(name);
/* 149 */       chart.setXaxisLabel("Replies");
/* 150 */       chart.setYaxisLabel("Topics");
/* 151 */       chart.setType(3);
/* 152 */       Bin[] bins = hist.getBins();
/* 153 */       String[] labels = new String[bins.length];
/* 154 */       for (int j = 0; j < bins.length; j++) {
/* 155 */         Bin bin = bins[j];
/* 156 */         labels[j] = this.labelFormatter.format(bin);
/*     */       }
/* 158 */       chart.setLabels(labels);
/* 159 */       charts.add(chart);
/*     */     }
/* 161 */     return (Chart[])charts.toArray(new Chart[0]);
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 165 */     Histogram[] histograms = getHistograms();
/* 166 */     if (histograms.length == 0) {
/* 167 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/*     */ 
/* 170 */     List lists = new ArrayList(histograms.length);
/* 171 */     for (int i = 0; i < histograms.length; i++) {
/* 172 */       List extraInfo = new LinkedList();
/* 173 */       if (getHistograms()[i].getNElement() > 0L)
/*     */       {
/* 175 */         DecimalFormat df = (DecimalFormat)DecimalFormat.getInstance(JiveGlobals.getLocale());
/* 176 */         df.applyPattern("#,##0.0");
/* 177 */         extraInfo.add(new Report.ExtraInfo("Median Messages Per Topic", df.format(getHistograms()[i].getMeanElement())));
/*     */       }
/*     */ 
/* 182 */       extraInfo.add(getDateRange());
/*     */ 
/* 184 */       lists.add(extraInfo);
/*     */     }
/*     */ 
/* 187 */     return (List[])lists.toArray(new List[0]);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.RepliesPerThreadReport
 * JD-Core Version:    0.6.2
 */
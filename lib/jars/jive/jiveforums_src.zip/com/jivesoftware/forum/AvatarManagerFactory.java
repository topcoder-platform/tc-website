/*     */ package com.jivesoftware.forum;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.JiveManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.database.DbAvatarManager;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.ClassUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public final class AvatarManagerFactory
/*     */   implements JiveManager
/*     */ {
/*     */   public static final String AVATAR_ENABLE_PROPERTY = "avatars.enabled";
/*     */   public static Cache avatarCache;
/*     */   public static Cache activeAvatarCache;
/*     */   public static Cache reverseActiveAvatarCache;
/*  39 */   private static boolean initialized = false;
/*     */   private static AvatarManager avatarManager;
/*     */ 
/*     */   public static AvatarManager getInstance()
/*     */   {
/*  51 */     return avatarManager;
/*     */   }
/*     */ 
/*     */   public synchronized void initialize()
/*     */   {
/*  57 */     doInitialize();
/*     */   }
/*     */ 
/*     */   public static synchronized void doInitialize() {
/*  61 */     if (!initialized)
/*     */     {
/*  63 */       String className = JiveGlobals.getJiveProperty("AvatarManager.className");
/*  64 */       if (className != null) {
/*  65 */         Log.debug("Loading custom AvatarManager from class: " + className);
/*     */         try {
/*  67 */           Class c = ClassUtils.forName(className);
/*  68 */           avatarManager = (AvatarManager)c.newInstance();
/*  69 */           Log.debug("Custom AvatarManager '" + className + "' loaded successfully!");
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*  73 */           Log.fatal("Error loading custom AvatarManager " + className, e);
/*     */         }
/*     */       }
/*     */       else {
/*  77 */         avatarManager = new DbAvatarManager();
/*     */       }
/*     */ 
/*  81 */       avatarCache = CacheFactory.createCache("Avatar ID Cache", "avatarCache", 65536, 43200000L);
/*     */ 
/*  85 */       activeAvatarCache = CacheFactory.createCache("Active Avatar Cache", "activeAvatarCache", 65536, 43200000L);
/*     */ 
/*  89 */       reverseActiveAvatarCache = CacheFactory.createCache("Reverse Active Avatar Cache", "reverseActiveAvatarCache", 65536, 43200000L);
/*     */ 
/*  92 */       initialized = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void setAvatarsEnabled(boolean enabled) {
/*  97 */     JiveGlobals.setJiveProperty("avatars.enabled", String.valueOf(enabled));
/*     */   }
/*     */ 
/*     */   public static boolean isAvatarsEnabled()
/*     */   {
/* 102 */     return JiveGlobals.getJiveBooleanProperty("avatars.enabled");
/*     */   }
/*     */ 
/*     */   public static void addActiveAvatarToCache(Avatar avatar, User user)
/*     */   {
/* 113 */     Long avatarID = new Long(avatar.getID());
/*     */ 
/* 115 */     activeAvatarCache.put(new Long(user.getID()), avatarID);
/*     */ 
/* 117 */     ArrayList userIDList = (ArrayList)reverseActiveAvatarCache.get(avatarID);
/*     */ 
/* 119 */     if (userIDList == null) {
/* 120 */       userIDList = new ArrayList();
/* 121 */       reverseActiveAvatarCache.put(avatarID, userIDList);
/*     */     }
/*     */ 
/* 124 */     userIDList.add(new Long(user.getID()));
/*     */   }
/*     */ 
/*     */   public static void clearAvatarFromCache(Avatar avatar)
/*     */   {
/* 135 */     Long avatarID = new Long(avatar.getID());
/*     */ 
/* 138 */     avatarCache.remove(avatarID);
/*     */ 
/* 142 */     Collection userIDs = (Collection)reverseActiveAvatarCache.get(avatarID);
/*     */     Iterator i;
/* 143 */     if (userIDs != null)
/*     */     {
/* 145 */       for (i = userIDs.iterator(); i.hasNext(); ) {
/* 146 */         Long userID = (Long)i.next();
/*     */ 
/* 148 */         activeAvatarCache.remove(userID);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.AvatarManagerFactory
 * JD-Core Version:    0.6.2
 */
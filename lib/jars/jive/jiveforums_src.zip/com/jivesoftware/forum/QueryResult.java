/*     */ package com.jivesoftware.forum;
/*     */ 
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class QueryResult
/*     */ {
/*  28 */   private ForumMessage message = null;
/*  29 */   private String subject = null;
/*  30 */   private long messageID = -1L;
/*  31 */   private long threadID = -1L;
/*  32 */   private long forumID = -1L;
/*  33 */   private Date creationDate = null;
/*  34 */   private Date modificationDate = null;
/*     */   private float relevance;
/*     */ 
/*     */   public QueryResult(ForumMessage message, float relevance)
/*     */   {
/*  44 */     this.message = message;
/*  45 */     this.subject = message.getSubject();
/*  46 */     this.messageID = message.getID();
/*  47 */     this.threadID = message.getForumThread().getID();
/*  48 */     this.forumID = message.getForumThread().getForum().getID();
/*  49 */     this.creationDate = message.getCreationDate();
/*  50 */     this.modificationDate = message.getModificationDate();
/*  51 */     this.relevance = (Math.round(relevance * 1000.0F) / 1000.0F);
/*     */   }
/*     */ 
/*     */   public QueryResult(long messageID, long threadID, long forumID, String subject, Date creationDate, Date modificationDate, float relevance)
/*     */   {
/*  68 */     this.messageID = messageID;
/*  69 */     this.threadID = threadID;
/*  70 */     this.forumID = forumID;
/*  71 */     this.subject = subject;
/*  72 */     this.creationDate = creationDate;
/*  73 */     this.modificationDate = modificationDate;
/*  74 */     this.relevance = (Math.round(relevance * 1000.0F) / 1000.0F);
/*     */   }
/*     */ 
/*     */   public long getMessageID()
/*     */   {
/*  83 */     return this.messageID;
/*     */   }
/*     */ 
/*     */   public long getThreadID()
/*     */   {
/*  93 */     return this.threadID;
/*     */   }
/*     */ 
/*     */   public long getForumID()
/*     */   {
/* 103 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public Date getCreationDate()
/*     */   {
/* 113 */     return this.creationDate;
/*     */   }
/*     */ 
/*     */   public Date getModificationDate()
/*     */   {
/* 125 */     return this.modificationDate;
/*     */   }
/*     */ 
/*     */   public String getSubject()
/*     */   {
/* 137 */     return this.subject;
/*     */   }
/*     */ 
/*     */   public ForumMessage getMessage()
/*     */     throws ForumMessageNotFoundException
/*     */   {
/* 146 */     if (this.message != null) {
/* 147 */       return this.message;
/*     */     }
/*     */ 
/* 150 */     this.message = DbForumFactory.getInstance().getMessage(this.messageID);
/* 151 */     return this.message;
/*     */   }
/*     */ 
/*     */   public float getRelevance()
/*     */   {
/* 161 */     return this.relevance;
/*     */   }
/*     */ 
/*     */   public void setMessage(ForumMessage message)
/*     */   {
/* 171 */     this.message = message;
/* 172 */     this.messageID = message.getID();
/*     */   }
/*     */ 
/*     */   protected void setRelevance(float relevance)
/*     */   {
/* 182 */     this.relevance = (Math.round(relevance * 1000.0F) / 1000.0F);
/*     */   }
/*     */ 
/*     */   public String getRelevanceAsPercentage(Locale locale)
/*     */   {
/* 193 */     NumberFormat format = DecimalFormat.getPercentInstance(locale);
/* 194 */     format.setMaximumFractionDigits(0);
/* 195 */     return format.format(this.relevance);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj) {
/* 199 */     if (((obj instanceof QueryResult)) && 
/* 200 */       (((QueryResult)obj).getMessageID() == this.messageID)) {
/* 201 */       return true;
/*     */     }
/*     */ 
/* 205 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.QueryResult
 * JD-Core Version:    0.6.2
 */
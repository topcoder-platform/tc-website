package com.jivesoftware.forum;

import com.jivesoftware.base.UnauthorizedException;

public abstract interface InterceptorManager
{
  public abstract int getInterceptorCount();

  public abstract MessageInterceptor getInterceptor(int paramInt);

  public abstract void addInterceptor(int paramInt, MessageInterceptor paramMessageInterceptor);

  public abstract void removeInterceptor(int paramInt);

  public abstract void saveInterceptors();

  public abstract MessageInterceptor[] getAvailableInterceptors();

  public abstract void addInterceptorClass(String paramString)
    throws UnauthorizedException, ClassNotFoundException, IllegalArgumentException;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.InterceptorManager
 * JD-Core Version:    0.6.2
 */
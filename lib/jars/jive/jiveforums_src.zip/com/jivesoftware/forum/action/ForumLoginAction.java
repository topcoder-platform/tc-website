/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.User;
/*    */ import com.jivesoftware.base.UserManager;
/*    */ import com.jivesoftware.base.UserNotFoundException;
/*    */ import com.jivesoftware.base.action.LoginAction;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ 
/*    */ public class ForumLoginAction extends LoginAction
/*    */ {
/*    */   public User getPageUser()
/*    */   {
/* 28 */     AuthToken authToken = getAuthToken();
/* 29 */     if ((this.pageUser == null) && (!authToken.isAnonymous()))
/*    */       try {
/* 31 */         ForumFactory forumFactory = ForumFactory.getInstance(authToken);
/* 32 */         setPageUser(forumFactory.getUserManager().getUser(authToken.getUserID()));
/*    */       }
/*    */       catch (UserNotFoundException e) {
/*    */       }
/* 36 */     return this.pageUser;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.ForumLoginAction
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public class GuestSettingsAction extends ForumActionSupport
/*     */   implements Validateable
/*     */ {
/*     */   public static final String USERSETTINGS = "usersettings";
/*  29 */   private int threadsPerPage = -1;
/*  30 */   private int messagesPerPage = -1;
/*     */   private String guestLocale;
/*     */   private String timezone;
/*  36 */   private boolean usersChooseLocale = JiveGlobals.getJiveBooleanProperty("skin.default.usersChooseLocale", true);
/*     */ 
/*  38 */   private int defaultThreadsPerPage = JiveGlobals.getJiveIntProperty("skin.default.defaultThreadsPerPage", 15);
/*     */ 
/*  40 */   private int defaultMessagesPerPage = JiveGlobals.getJiveIntProperty("skin.default.defaultMessagesPerPage", 15);
/*     */ 
/*  42 */   private int maxThreadsPerPage = JiveGlobals.getJiveIntProperty("skin.default.maxThreadsPerPage", 100);
/*     */ 
/*  44 */   private int maxMessagesPerPage = JiveGlobals.getJiveIntProperty("skin.default.maxMessagesPerPage", 100);
/*     */ 
/*     */   public int getThreadsPerPage()
/*     */   {
/*  48 */     return this.threadsPerPage;
/*     */   }
/*     */ 
/*     */   public void setThreadsPerPage(int threadsPerPage) {
/*  52 */     this.threadsPerPage = threadsPerPage;
/*     */   }
/*     */ 
/*     */   public int getMessagesPerPage() {
/*  56 */     return this.messagesPerPage;
/*     */   }
/*     */ 
/*     */   public void setMessagesPerPage(int messagesPerPage) {
/*  60 */     this.messagesPerPage = messagesPerPage;
/*     */   }
/*     */ 
/*     */   public String getGuestLocale() {
/*  64 */     return this.guestLocale;
/*     */   }
/*     */ 
/*     */   public void setGuestLocale(String guestLocale) {
/*  68 */     this.guestLocale = guestLocale;
/*     */   }
/*     */ 
/*     */   public String getTimezone() {
/*  72 */     return this.timezone;
/*     */   }
/*     */ 
/*     */   public void setTimezone(String timezone) {
/*  76 */     this.timezone = timezone;
/*     */   }
/*     */ 
/*     */   public boolean isUsersChooseLocale()
/*     */   {
/*  82 */     return this.usersChooseLocale;
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/*  88 */     if (this.threadsPerPage == -1) {
/*  89 */       addFieldError("threadsPerPage", "");
/*     */     }
/*  91 */     if (this.messagesPerPage == -1) {
/*  92 */       addFieldError("messagesPerPage", "");
/*     */     }
/*  94 */     if ((this.usersChooseLocale) && (this.guestLocale == null)) {
/*  95 */       addFieldError("guestLocale", "");
/*     */     }
/*  97 */     if (this.timezone == null)
/*  98 */       addFieldError("timezone", "");
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/* 106 */     if (!isGuest()) {
/* 107 */       return "usersettings";
/*     */     }
/* 109 */     if (hasFieldErrors()) {
/* 110 */       return "error";
/*     */     }
/*     */ 
/* 113 */     int threads = this.defaultThreadsPerPage;
/*     */     try {
/* 115 */       threads = Integer.parseInt(getGuestProperty("jiveThreadRange")); } catch (NumberFormatException ignored) {
/*     */     }
/* 117 */     setThreadsPerPage(threads);
/*     */ 
/* 119 */     int messages = this.defaultMessagesPerPage;
/*     */     try {
/* 121 */       messages = Integer.parseInt(getGuestProperty("jiveMessageRange")); } catch (NumberFormatException ignored) {
/*     */     }
/* 123 */     setMessagesPerPage(messages);
/*     */ 
/* 125 */     if (this.usersChooseLocale) {
/* 126 */       setGuestLocale(getGuestProperty("jiveLocale"));
/* 127 */       if (getGuestLocale() == null) {
/* 128 */         setGuestLocale(JiveGlobals.getLocale().toString());
/*     */       }
/*     */     }
/*     */ 
/* 132 */     setTimezone(getGuestProperty("jiveTimeZoneID"));
/* 133 */     if (getTimezone() == null) {
/* 134 */       setTimezone(JiveGlobals.getTimeZone().getID());
/*     */     }
/*     */ 
/* 137 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 142 */     int thrPerPage = getThreadsPerPage();
/* 143 */     if (thrPerPage > -1) {
/* 144 */       if (thrPerPage > this.maxThreadsPerPage) {
/* 145 */         thrPerPage = this.maxThreadsPerPage;
/*     */       }
/* 147 */       setGuestProperty("jiveThreadRange", String.valueOf(thrPerPage));
/*     */     }
/* 149 */     int msgPerPage = getMessagesPerPage();
/* 150 */     if (msgPerPage > -1) {
/* 151 */       if (msgPerPage > this.maxMessagesPerPage) {
/* 152 */         msgPerPage = this.maxMessagesPerPage;
/*     */       }
/* 154 */       setGuestProperty("jiveMessageRange", String.valueOf(msgPerPage));
/*     */     }
/* 156 */     if ((this.usersChooseLocale) && 
/* 157 */       (getGuestLocale() != null)) {
/* 158 */       setGuestProperty("jiveLocale", getGuestLocale());
/*     */     }
/*     */ 
/* 161 */     if (getTimezone() != null) {
/* 162 */       setGuestProperty("jiveTimeZoneID", getTimezone());
/*     */     }
/*     */ 
/* 165 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.GuestSettingsAction
 * JD-Core Version:    0.6.2
 */
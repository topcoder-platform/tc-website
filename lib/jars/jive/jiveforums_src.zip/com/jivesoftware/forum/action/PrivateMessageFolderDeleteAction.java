/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.PrivateMessageFolder;
/*    */ import com.jivesoftware.forum.PrivateMessageFolderNotFoundException;
/*    */ import com.jivesoftware.forum.PrivateMessageManager;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ 
/*    */ public class PrivateMessageFolderDeleteAction extends ForumActionSupport
/*    */ {
/*    */   private int folderID;
/*    */   private PrivateMessageFolder folder;
/*    */   private Collection folders;
/*    */   private String cancel;
/*    */ 
/*    */   public int getFolderID()
/*    */   {
/* 29 */     return this.folderID;
/*    */   }
/*    */ 
/*    */   public void setFolderID(int folderID) {
/* 33 */     this.folderID = folderID;
/*    */   }
/*    */ 
/*    */   public PrivateMessageFolder getFolder() {
/* 37 */     return this.folder;
/*    */   }
/*    */ 
/*    */   public Collection getFolders() {
/* 41 */     return this.folders;
/*    */   }
/*    */ 
/*    */   public String getCancel() {
/* 45 */     return this.cancel;
/*    */   }
/*    */ 
/*    */   public void setCancel(String cancel) {
/* 49 */     this.cancel = cancel;
/*    */   }
/*    */ 
/*    */   public String doDefault() {
/* 53 */     if (!getForumFactory().getPrivateMessageManager().isPrivateMessagesEnabled()) {
/* 54 */       return "disabled";
/*    */     }
/*    */ 
/* 57 */     PrivateMessageManager manager = getForumFactory().getPrivateMessageManager();
/*    */     try {
/* 59 */       this.folder = manager.getFolder(getPageUser(), getFolderID());
/* 60 */       this.folders = new LinkedList();
/* 61 */       for (Iterator iter = manager.getFolders(getPageUser()); iter.hasNext(); ) {
/* 62 */         this.folders.add(iter.next());
/*    */       }
/* 64 */       return "input";
/*    */     }
/*    */     catch (PrivateMessageFolderNotFoundException e) {
/* 67 */       addFieldError("folderID", "");
/* 68 */       return "error";
/*    */     }
/*    */     catch (UnauthorizedException e) {
/* 71 */       addFieldError("unauthorized", "");
/* 72 */     }return "error";
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */   {
/* 77 */     if (getCancel() != null) {
/* 78 */       return "cancel";
/*    */     }
/*    */ 
/* 81 */     PrivateMessageManager manager = getForumFactory().getPrivateMessageManager();
/* 82 */     if (!manager.isPrivateMessagesEnabled()) {
/* 83 */       return "disabled";
/*    */     }
/*    */     try
/*    */     {
/* 87 */       this.folder = manager.getFolder(getPageUser(), getFolderID());
/* 88 */       manager.deleteFolder(this.folder);
/* 89 */       return "success";
/*    */     }
/*    */     catch (UnauthorizedException e) {
/* 92 */       addFieldError("unauthorized", "");
/* 93 */       return "error";
/*    */     }
/*    */     catch (PrivateMessageFolderNotFoundException e) {
/* 96 */       addFieldError("folderID", "");
/* 97 */     }return "error";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PrivateMessageFolderDeleteAction
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action.util;
/*    */ 
/*    */ import com.jivesoftware.forum.PrivateMessageFolder;
/*    */ import com.jivesoftware.forum.action.ForumActionSupport;
/*    */ import com.jivesoftware.forum.util.ForumUtils;
/*    */ 
/*    */ public class PrivateMessageUtils
/*    */ {
/*    */   public static String getDisplayName(PrivateMessageFolder folder, ForumActionSupport action)
/*    */   {
/* 21 */     String name = folder.getName();
/* 22 */     if (ForumUtils.getI18nKeyName(folder) != null) {
/* 23 */       name = action.getText(ForumUtils.getI18nKeyName(folder));
/*    */     }
/* 25 */     return name;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.util.PrivateMessageUtils
 * JD-Core Version:    0.6.2
 */
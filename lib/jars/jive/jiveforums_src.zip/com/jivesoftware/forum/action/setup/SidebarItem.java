/*     */ package com.jivesoftware.forum.action.setup;
/*     */ 
/*     */ class SidebarItem
/*     */ {
/*     */   private String name;
/*     */   private String URL;
/*     */   private boolean showItem;
/*     */   private boolean linkToItem;
/*     */   private boolean isCurrent;
/*     */ 
/*     */   public SidebarItem(String name, String URL, boolean showItem, boolean linkToItem)
/*     */   {
/* 218 */     this.name = name;
/* 219 */     this.URL = URL;
/* 220 */     this.showItem = showItem;
/* 221 */     this.linkToItem = linkToItem;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 225 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 229 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getURL() {
/* 233 */     return this.URL;
/*     */   }
/*     */ 
/*     */   public void setURL(String URL) {
/* 237 */     this.URL = URL;
/*     */   }
/*     */ 
/*     */   public boolean isShowItem() {
/* 241 */     return this.showItem;
/*     */   }
/*     */ 
/*     */   public void setShowItem(boolean showItem) {
/* 245 */     this.showItem = showItem;
/*     */   }
/*     */ 
/*     */   public boolean isLinkToItem() {
/* 249 */     return this.linkToItem;
/*     */   }
/*     */ 
/*     */   public void setLinkToItem(boolean linkToItem) {
/* 253 */     this.linkToItem = linkToItem;
/*     */   }
/*     */ 
/*     */   public boolean isCurrent() {
/* 257 */     return this.isCurrent;
/*     */   }
/*     */ 
/*     */   public void setCurrent(boolean current) {
/* 261 */     this.isCurrent = current;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.SidebarItem
 * JD-Core Version:    0.6.2
 */
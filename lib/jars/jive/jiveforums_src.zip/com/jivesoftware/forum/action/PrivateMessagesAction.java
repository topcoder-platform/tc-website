/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.PrivateMessageFolder;
/*     */ import com.jivesoftware.forum.PrivateMessageFolderNotFoundException;
/*     */ import com.jivesoftware.forum.PrivateMessageManager;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.action.util.Pageable;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ public class PrivateMessagesAction extends ForumActionSupport
/*     */   implements Pageable
/*     */ {
/*  27 */   private int folderID = 1;
/*  28 */   private int start = 0;
/*  29 */   private int range = 15;
/*     */   private PrivateMessageFolder folder;
/*     */   private Collection folders;
/*     */ 
/*     */   public int getFolderID()
/*     */   {
/*  34 */     return this.folderID;
/*     */   }
/*     */ 
/*     */   public void setFolderID(int folderID) {
/*  38 */     this.folderID = folderID;
/*     */   }
/*     */ 
/*     */   public int getStart() {
/*  42 */     return this.start;
/*     */   }
/*     */ 
/*     */   public void setStart(int start) {
/*  46 */     this.start = start;
/*     */   }
/*     */ 
/*     */   public int getRange() {
/*  50 */     return this.range;
/*     */   }
/*     */ 
/*     */   public void setRange(int range) {
/*  54 */     this.range = range;
/*     */   }
/*     */ 
/*     */   public PrivateMessageFolder getFolder() {
/*  58 */     return this.folder;
/*     */   }
/*     */ 
/*     */   public int getTotalItemCount() {
/*  62 */     PrivateMessageFolder f = getFolder();
/*  63 */     if (f == null) {
/*  64 */       return 0;
/*     */     }
/*     */ 
/*  67 */     return f.getMessageCount();
/*     */   }
/*     */ 
/*     */   public ResultFilter getResultFilter()
/*     */   {
/*  72 */     ResultFilter filter = new ResultFilter();
/*  73 */     filter.setStartIndex(getStart());
/*  74 */     filter.setNumResults(getRange());
/*  75 */     return filter;
/*     */   }
/*     */ 
/*     */   public Iterator getMessages() {
/*  79 */     PrivateMessageFolder f = getFolder();
/*  80 */     return f.getMessages(getStart(), getRange(), 1000, true);
/*     */   }
/*     */ 
/*     */   public Collection getFolders() {
/*  84 */     return this.folders;
/*     */   }
/*     */ 
/*     */   public String execute() {
/*  88 */     if (getAuthToken().isAnonymous()) {
/*  89 */       return "login";
/*     */     }
/*  91 */     if (!getForumFactory().getPrivateMessageManager().isPrivateMessagesEnabled()) {
/*  92 */       return "disabled";
/*     */     }
/*     */ 
/*  96 */     if (!getForumFactory().isAuthorized(32L)) {
/*  97 */       return "unauthorized";
/*     */     }
/*     */     try
/*     */     {
/* 101 */       this.folder = getForumFactory().getPrivateMessageManager().getFolder(getPageUser(), getFolderID());
/*     */ 
/* 103 */       this.folders = new LinkedList();
/* 104 */       Iterator iter = getForumFactory().getPrivateMessageManager().getFolders(getPageUser());
/* 105 */       while (iter.hasNext())
/* 106 */         this.folders.add(iter.next());
/*     */     }
/*     */     catch (PrivateMessageFolderNotFoundException e)
/*     */     {
/* 110 */       addFieldError("folderID", "");
/* 111 */       return "error";
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 114 */       addFieldError("unauthorized", "");
/* 115 */       return "error";
/*     */     }
/*     */ 
/* 118 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PrivateMessagesAction
 * JD-Core Version:    0.6.2
 */
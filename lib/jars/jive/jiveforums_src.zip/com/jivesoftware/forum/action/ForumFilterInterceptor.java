/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.opensymphony.xwork.ActionContext;
/*    */ import com.opensymphony.xwork.ActionInvocation;
/*    */ import com.opensymphony.xwork.interceptor.Interceptor;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ForumFilterInterceptor
/*    */   implements Interceptor
/*    */ {
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void init()
/*    */   {
/*    */   }
/*    */ 
/*    */   public String intercept(ActionInvocation in)
/*    */     throws Exception
/*    */   {
/* 32 */     Map session = in.getInvocationContext().getSession();
/* 33 */     long forumID = ((ForumAction)in.getAction()).getForumID();
/* 34 */     String filter = (String)session.get("jive.filter.forum." + forumID);
/*    */ 
/* 36 */     if (filter != null) {
/* 37 */       return "filter";
/*    */     }
/*    */ 
/* 40 */     return in.invoke();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.ForumFilterInterceptor
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.ForumThread;
/*    */ 
/*    */ public class UnlockThreadAction extends ForumThreadAction
/*    */ {
/*    */   private String doCancel;
/*    */ 
/*    */   public String getDoCancel()
/*    */   {
/* 27 */     return this.doCancel;
/*    */   }
/*    */ 
/*    */   public void setDoCancel(String doCancel) {
/* 31 */     this.doCancel = "true";
/*    */   }
/*    */ 
/*    */   public String doDefault()
/*    */   {
/*    */     try
/*    */     {
/* 38 */       if (!loadJiveObjects())
/* 39 */         return "error";
/*    */     }
/*    */     catch (UnauthorizedException e)
/*    */     {
/* 43 */       setLoginAttributes();
/* 44 */       addActionError(getText("unlock.error_unauth"));
/* 45 */       return "login";
/*    */     }
/* 47 */     return "input";
/*    */   }
/*    */ 
/*    */   public String execute() {
/*    */     try {
/* 52 */       if (!loadJiveObjects())
/* 53 */         return "error";
/*    */     }
/*    */     catch (UnauthorizedException e)
/*    */     {
/* 57 */       setLoginAttributes();
/* 58 */       addActionError(getText("unlock.error_unauth"));
/* 59 */       return "login";
/*    */     }
/* 61 */     if ((!isSystemAdmin()) && (!isModerator(getForum()))) {
/* 62 */       setLoginAttributes();
/* 63 */       addActionError(getText("unlock.error_unauth"));
/* 64 */       return "login";
/*    */     }
/*    */ 
/* 67 */     if ("true".equals(getDoCancel())) {
/* 68 */       return "cancel";
/*    */     }
/*    */     try
/*    */     {
/* 72 */       getThread().deleteProperty("jive.locked");
/*    */     }
/*    */     catch (UnauthorizedException ue) {
/* 75 */       setLoginAttributes();
/* 76 */       addActionError(ue.getMessage());
/* 77 */       return "login";
/*    */     }
/*    */ 
/* 80 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.UnlockThreadAction
 * JD-Core Version:    0.6.2
 */
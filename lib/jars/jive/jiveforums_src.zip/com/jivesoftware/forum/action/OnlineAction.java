/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.Presence;
/*     */ import com.jivesoftware.base.PresenceManager;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.action.util.Pageable;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class OnlineAction extends ForumActionSupport
/*     */   implements Pageable
/*     */ {
/*     */   public static final int RANGE = 20;
/*     */   public static final String SORT_USERNAME = "username";
/*     */   public static final String SORT_ONLINE_TIME = "online";
/*  41 */   private int start = 0;
/*  42 */   private int range = 20;
/*  43 */   private String sort = "username";
/*     */ 
/*     */   public int getStart()
/*     */   {
/*  48 */     return this.start;
/*     */   }
/*     */ 
/*     */   public void setStart(int start) {
/*  52 */     this.start = start;
/*     */   }
/*     */ 
/*     */   public int getRange() {
/*  56 */     return this.range;
/*     */   }
/*     */ 
/*     */   public void setRange(int range) {
/*  60 */     this.range = range;
/*     */   }
/*     */ 
/*     */   public String getSort() {
/*  64 */     return this.sort;
/*     */   }
/*     */ 
/*     */   public void setSort(String sort) {
/*  68 */     this.sort = sort;
/*     */   }
/*     */ 
/*     */   public int getTotalItemCount()
/*     */   {
/*  74 */     return getPresenceManager().getOnlineUserCount();
/*     */   }
/*     */ 
/*     */   public ResultFilter getResultFilter() {
/*  78 */     ResultFilter filter = new ResultFilter();
/*  79 */     filter.setStartIndex(getStart());
/*  80 */     filter.setNumResults(getRange());
/*  81 */     return filter;
/*     */   }
/*     */ 
/*     */   public PresenceManager getPresenceManager()
/*     */   {
/*  91 */     return getForumFactory().getPresenceManager();
/*     */   }
/*     */ 
/*     */   public Iterator getOnlineUsers()
/*     */   {
/* 104 */     PresenceManager manager = getPresenceManager();
/* 105 */     int sortField = 0;
/* 106 */     boolean ascending = false;
/* 107 */     if ("username".equals(getSort())) {
/* 108 */       sortField = 0;
/* 109 */       ascending = true;
/*     */     }
/* 111 */     else if ("online".equals(getSort())) {
/* 112 */       sortField = 1;
/* 113 */       ascending = false;
/*     */     }
/* 115 */     Iterator users = manager.getOnlineUsers(ascending, sortField);
/* 116 */     List userlist = new LinkedList();
/* 117 */     int startIndex = getStart();
/* 118 */     int numUsers = getRange();
/* 119 */     while (users.hasNext()) {
/* 120 */       userlist.add(users.next());
/*     */     }
/* 122 */     if ((this.start == 0) && (userlist.size() <= numUsers)) {
/* 123 */       return userlist.iterator();
/*     */     }
/*     */ 
/* 126 */     int end = startIndex + numUsers;
/* 127 */     if (end > userlist.size()) {
/* 128 */       end = userlist.size();
/*     */     }
/* 130 */     if (startIndex >= end)
/*     */     {
/* 132 */       startIndex = end - 15;
/* 133 */       if (startIndex < 0)
/*     */       {
/* 135 */         startIndex = 0;
/*     */       }
/*     */     }
/* 138 */     return userlist.subList(startIndex, end).iterator();
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 148 */     return "success";
/*     */   }
/*     */ 
/*     */   public static long computeIdleTime(Presence presence)
/*     */   {
/* 160 */     return CacheFactory.currentTime - presence.getLastUpdateTime().getTime();
/*     */   }
/*     */ 
/*     */   public static long computeOnlineTime(Presence presence)
/*     */   {
/* 170 */     return CacheFactory.currentTime - presence.getLoginTime().getTime();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.OnlineAction
 * JD-Core Version:    0.6.2
 */
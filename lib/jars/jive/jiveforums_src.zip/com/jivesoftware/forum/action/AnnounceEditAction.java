/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.action.util.DateUtils;
/*     */ import com.jivesoftware.forum.Announcement;
/*     */ import com.jivesoftware.forum.AnnouncementManager;
/*     */ import com.jivesoftware.forum.AnnouncementNotFoundException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class AnnounceEditAction extends PostAnnounceAction
/*     */ {
/*     */   private long annID;
/*     */   private Announcement ann;
/*     */   private ForumCategory category;
/*     */   private Forum forum;
/*     */ 
/*     */   public long getAnnID()
/*     */   {
/*  37 */     return this.annID;
/*     */   }
/*     */ 
/*     */   public void setAnnID(long annID) {
/*  41 */     this.annID = annID;
/*     */   }
/*     */ 
/*     */   public Announcement getAnnouncement() {
/*  45 */     return this.ann;
/*     */   }
/*     */ 
/*     */   public Forum getForum() {
/*  49 */     return this.forum;
/*     */   }
/*     */ 
/*     */   public ForumCategory getCategory() {
/*  53 */     return this.category;
/*     */   }
/*     */ 
/*     */   public String doDefault() {
/*  57 */     setSubject(this.ann.getUnfilteredSubject());
/*  58 */     setBody(this.ann.getUnfilteredBody());
/*  59 */     Date now = new Date();
/*  60 */     if ((this.ann.getStartDate() != null) && (this.ann.getStartDate().before(now))) {
/*  61 */       setActiveMode("activenow");
/*     */     }
/*     */     else {
/*  64 */       setActiveMode("activelater");
/*     */     }
/*  66 */     setExpiresMode("expiresnever");
/*  67 */     if (this.ann.getEndDate() != null) {
/*  68 */       SimpleDateFormat formatter = new SimpleDateFormat(DateUtils.getDatePattern());
/*  69 */       setExpiresDate(formatter.format(this.ann.getEndDate()));
/*  70 */       setExpiresMode("expireslater");
/*     */     }
/*  72 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute() {
/*  76 */     return super.execute();
/*     */   }
/*     */ 
/*     */   protected Announcement loadAnnouncement() throws UnauthorizedException {
/*  80 */     return this.ann;
/*     */   }
/*     */ 
/*     */   protected void saveAnnouncement() throws UnauthorizedException
/*     */   {
/*     */   }
/*     */ 
/*     */   public String loadObjects() throws Exception
/*     */   {
/*  89 */     String result = super.loadObjects();
/*  90 */     if (!"success".equals(result)) {
/*  91 */       return result;
/*     */     }
/*     */ 
/*  94 */     AnnouncementManager manager = getForumFactory().getAnnouncementManager();
/*     */     try {
/*  96 */       this.ann = manager.getAnnouncement(this.annID);
/*  97 */       switch (this.ann.getContainerObjectType()) {
/*     */       case 0:
/*  99 */         this.forum = getForumFactory().getForum(this.ann.getContainerObjectID());
/* 100 */         break;
/*     */       case 14:
/* 102 */         this.category = getForumFactory().getForumCategory(this.ann.getContainerObjectID());
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (AnnouncementNotFoundException e)
/*     */     {
/* 109 */       addFieldError("annID", String.valueOf(this.annID));
/* 110 */       return "notfound";
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 113 */       return "unauthorized";
/*     */     }
/* 115 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AnnounceEditAction
 * JD-Core Version:    0.6.2
 */
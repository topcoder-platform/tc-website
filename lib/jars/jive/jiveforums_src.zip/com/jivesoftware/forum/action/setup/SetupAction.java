/*     */ package com.jivesoftware.forum.action.setup;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.LicenseException;
/*     */ import com.jivesoftware.base.LicenseManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.database.DefaultConnectionProvider;
/*     */ import com.jivesoftware.base.event.LogEvent;
/*     */ import com.jivesoftware.base.event.LogListenerAdapter;
/*     */ import com.jivesoftware.forum.Version;
/*     */ import com.jivesoftware.forum.Version.Edition;
/*     */ import com.jivesoftware.util.ClassUtils;
/*     */ import com.opensymphony.webwork.ServletActionContext;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class SetupAction extends SetupActionSupport
/*     */   implements Validateable
/*     */ {
/*     */   public static final String DATABASE_CONNECTION = "db_connection";
/*     */   public static final String JIVE_HOME = "jive_home";
/*     */   public static final String JIVE_LICENSE = "jive_license_file";
/*     */   public static final String JIVE_LICENSE_TEXT = "jive_license_text";
/*     */   public static final String JIVE_DEPENDENCY = "jive_dependency";
/*     */   public static final String JIVE_SETUP_FILE = "jive_setup_file";
/*     */   private String licenseText;
/*     */   private String jiveHomePath;
/*     */ 
/*     */   public String getLicenseText()
/*     */   {
/*  46 */     return this.licenseText;
/*     */   }
/*     */ 
/*     */   public void setLicenseText(String licenseText) {
/*  50 */     this.licenseText = licenseText;
/*  51 */     if ((this.licenseText == null) || ("".equals(this.licenseText.trim()))) {
/*  52 */       addError("jive_license_text", getText("setup.error.license_text_invalid"));
/*     */     }
/*     */     else {
/*  55 */       this.licenseText = licenseText;
/*     */ 
/*  57 */       File f = new File(getJiveHome(), "jive.license");
/*  58 */       if ((f.exists()) && (!f.canWrite())) {
/*  59 */         addError("jive_license_text", getText("setup.error.license_file_not_writeable"));
/*     */       }
/*  61 */       else if ((!f.exists()) || (f.canWrite()))
/*     */         try {
/*  63 */           BufferedWriter licenseOut = new BufferedWriter(new FileWriter(f));
/*  64 */           licenseOut.write(licenseText);
/*  65 */           licenseOut.close();
/*  66 */           LicenseManager.reloadLicenses();
/*     */         }
/*     */         catch (Exception e) {
/*  69 */           Log.error(e);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setJiveHomePath(String jiveHomePath)
/*     */   {
/*  76 */     this.jiveHomePath = jiveHomePath;
/*     */   }
/*     */ 
/*     */   public void addError(String key, String message)
/*     */   {
/*  82 */     addFieldError(key, message);
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/*  90 */     if ((this.jiveHomePath != null) && (getJiveHome() == null)) {
/*  91 */       File jiveHome = new File(this.jiveHomePath);
/*  92 */       if (jiveHome.exists()) {
/*  93 */         File f = getInitXmlFile();
/*  94 */         if (f == null) {
/*  95 */           addError("jive_home", getText("setup.error.jive_init_not_writeable"));
/*     */         }
/*     */         else {
/*  98 */           StringBuffer sb = new StringBuffer();
/*  99 */           sb.append("<?xml version=\"1.0\"?>\n");
/* 100 */           sb.append("<!--\n");
/* 101 */           sb.append(" * Specifies the full path to your jiveHome directory.\n");
/* 102 */           sb.append("* This file must be in the classpath of your application\n");
/* 103 */           sb.append("* server. Normally, the easiest way to do this is to\n");
/* 104 */           sb.append(" * put it into the [jive]/WEB-INF/classes directory,\n");
/* 105 */           sb.append(" * where [jive] is the name of your Jive Forums web\n");
/* 106 */           sb.append(" * application.\n");
/* 107 */           sb.append(" *\n");
/* 108 */           sb.append(" * For unix this might be:\n");
/* 109 */           sb.append(" * <jiveHome>/var/web/jiveHome</jiveHome>\n");
/* 110 */           sb.append(" *\n");
/* 111 */           sb.append(" * For Windows this might be:\n");
/* 112 */           sb.append(" * <jiveHome>c:\\web\\jiveHome</jiveHome>\n");
/* 113 */           sb.append("-->\n");
/* 114 */           sb.append("<jiveHome>" + this.jiveHomePath + "</jiveHome>");
/*     */           try
/*     */           {
/* 117 */             FileWriter fw = new FileWriter(f);
/* 118 */             fw.write(sb.toString());
/* 119 */             fw.close();
/*     */ 
/* 121 */             File startupFile = new File(jiveHome, "jive_startup.xml");
/* 122 */             if (!startupFile.exists()) {
/* 123 */               createJiveStartupXmlFile(startupFile);
/*     */             }
/*     */ 
/* 127 */             JiveGlobals.setJiveHome(this.jiveHomePath);
/*     */ 
/* 130 */             Log.initLog();
/*     */ 
/* 133 */             String conProvider = JiveGlobals.getLocalProperty("connectionProvider.className");
/* 134 */             if (("com.jivesoftware.base.database.DefaultConnectionProvider".equals(conProvider)) && (JiveGlobals.getLocalProperty("database.defaultProvider.serverURL") != null))
/*     */             {
/* 137 */               ConnectionManager.setConnectionProvider(new DefaultConnectionProvider());
/*     */ 
/* 139 */               testConnection();
/*     */             }
/*     */           }
/*     */           catch (IOException e) {
/* 143 */             addError("jive_home", getText("setup.error.jive_init_not_writeable"));
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 150 */     File jiveHome = getJiveHome();
/* 151 */     if ((jiveHome == null) || (!jiveHome.exists())) {
/* 152 */       addError("jive_home", getText("setup.error.jive_home_not_set"));
/*     */     }
/*     */     else
/*     */     {
/* 156 */       if (!jiveHome.canRead()) {
/* 157 */         addError("jive_home", getText("setup.error.jive_home_not_readable"));
/*     */       }
/*     */ 
/* 160 */       if (!jiveHome.canWrite()) {
/* 161 */         addError("jive_home", getText("setup.error.jive_home_not_writeable"));
/*     */       }
/* 163 */       else if (!new File(jiveHome, "jive_startup.xml").exists()) {
/*     */         try {
/* 165 */           createJiveStartupXmlFile(new File(jiveHome, "jive_startup.xml"));
/*     */         }
/*     */         catch (IOException e) {
/* 168 */           addError("jive_home", getText("setup.error.jive_startup_not_writeable"));
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 174 */     File licenseFile = getJiveFile("jive.license");
/* 175 */     if ((licenseFile == null) || (!licenseFile.exists())) {
/* 176 */       addError("jive_license_file", getText("setup.error.jive_license_does_not_exist"));
/*     */     }
/* 180 */     else if (!licenseFile.canRead()) {
/* 181 */       addError("jive_license_file", getText("setup.error.jive_license_not_readable"));
/*     */     }
/*     */     else {
/*     */       try
/*     */       {
/* 186 */         LicenseManager.validateLicense("Jive Forums " + Version.getEdition().getName(), "4.2");
/*     */       }
/*     */       catch (LicenseException le) {
/* 189 */         addError("jive_license_file", getText("setup.error.jive_license_does_not_validate"));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 195 */     SortedMap dependencyJars = new TreeMap();
/* 196 */     dependencyJars.put("activation.jar", "javax.activation.DataSource");
/* 197 */     dependencyJars.put("commons-collections.jar", "org.apache.commons.collections.CollectionUtils");
/* 198 */     dependencyJars.put("commons-fileupload.jar", "org.apache.commons.fileupload.DiskFileUpload");
/* 199 */     dependencyJars.put("commons-logging.jar", "org.apache.commons.logging.Log");
/* 200 */     dependencyJars.put("commons-pool.jar", "org.apache.commons.pool.ObjectPool");
/* 201 */     dependencyJars.put("htmllexer.jar", "org.htmlparser.lexer.Lexer");
/* 202 */     dependencyJars.put("htmlparser.jar", "org.htmlparser.Parser");
/* 203 */     dependencyJars.put("mail.jar", "javax.mail.Message");
/* 204 */     dependencyJars.put("ognl.jar", "ognl.ClassResolver");
/* 205 */     dependencyJars.put("oscore.jar", "com.opensymphony.util.BeanUtils");
/* 206 */     dependencyJars.put("velocity-dep.jar", "org.apache.velocity.Template");
/* 207 */     dependencyJars.put("velocity-tools.jar", "org.apache.velocity.tools.generic.DateTool");
/* 208 */     dependencyJars.put("webwork.jar", "com.opensymphony.webwork.WebWorkStatics");
/* 209 */     dependencyJars.put("xwork.jar", "com.opensymphony.xwork.Action");
/*     */ 
/* 211 */     if ((Version.getEdition() == Version.Edition.ENTERPRISE) || (Version.getEdition() == Version.Edition.EXPERT))
/*     */     {
/* 213 */       dependencyJars.put("ldap.jar", "com.sun.jndi.ldap.LdapName");
/* 214 */       dependencyJars.put("providerutil.jar", "com.sun.jndi.toolkit.dir.DirSearch");
/*     */     }
/*     */ 
/* 217 */     for (Iterator iter = dependencyJars.keySet().iterator(); iter.hasNext(); ) {
/* 218 */       String key = (String)iter.next();
/* 219 */       String classname = (String)dependencyJars.get(key);
/*     */       try {
/* 221 */         ClassUtils.forName(classname);
/*     */       }
/*     */       catch (NoClassDefFoundError ncdfe) {
/* 224 */         addError("jive_dependency", key);
/*     */       }
/*     */       catch (ClassNotFoundException cnfe) {
/* 227 */         addError("jive_dependency", key);
/*     */       }
/*     */       catch (SecurityException se) {
/* 230 */         addError("jive_dependency", key);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 235 */     if ((jiveHome != null) && (jiveHome.exists())) {
/* 236 */       String[] filenames = { "attachments", "data", "database", "logs", "search", "spelling", "stats" };
/* 237 */       for (int i = 0; i < filenames.length; i++) {
/* 238 */         File file = new File(jiveHome, filenames[i]);
/* 239 */         if (!file.exists())
/*     */         {
/* 241 */           if (!file.mkdir()) {
/* 242 */             addError("jive_setup_file", "Failed to create '" + file.getName() + "' directory " + "in your jiveHome directory. Please create this directory then " + "re-run this tool.");
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 250 */       File attachmentDir = new File(jiveHome, "attachments");
/* 251 */       File imageDir = new File(attachmentDir, "images");
/* 252 */       File cacheDir = new File(attachmentDir, "cache");
/* 253 */       if ((!imageDir.exists()) && 
/* 254 */         (!imageDir.mkdir())) {
/* 255 */         addError("jive_setup_file", "Failed to create '" + imageDir.getName() + "' directory " + "in your jiveHome directory. Please create this directory then " + "re-run this tool.");
/*     */       }
/*     */ 
/* 260 */       if ((!cacheDir.exists()) && 
/* 261 */         (!cacheDir.mkdir())) {
/* 262 */         addError("jive_setup_file", "Failed to create '" + cacheDir.getName() + "' directory " + "in your jiveHome directory. Please create this directory then " + "re-run this tool.");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 270 */     if ((hasErrors()) || (!getFieldErrors().isEmpty())) {
/* 271 */       addActionError(getText("setup.error.main.general"));
/*     */ 
/* 273 */       ServletActionContext.getRequest().setAttribute("doSetup", "true");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void createJiveStartupXmlFile(File startupFile) throws IOException
/*     */   {
/* 279 */     FileWriter jhWriter = new FileWriter(startupFile);
/* 280 */     jhWriter.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
/* 281 */     jhWriter.write("<!--\n");
/* 282 */     jhWriter.write("This file stores all properties need by Jive Forum's startup process. Property names must be in the\n");
/* 283 */     jhWriter.write("format: \"example.prop.is=value\"\n");
/* 284 */     jhWriter.write("That will be stored as:\n");
/* 285 */     jhWriter.write("<example>\n");
/* 286 */     jhWriter.write("   <prop>\n");
/* 287 */     jhWriter.write("       <is>value</is>\n");
/* 288 */     jhWriter.write("    </prop>\n");
/* 289 */     jhWriter.write("</example>\n");
/* 290 */     jhWriter.write("\n");
/* 291 */     jhWriter.write("All properties must be under the \"jive\" element.\n");
/* 292 */     jhWriter.write("This file should live in your jiveHome directory. The path to that directory\n");
/* 293 */     jhWriter.write("should be specified in your jive_init.xml file or by one of the other\n");
/* 294 */     jhWriter.write("supported mechanisms.\n");
/* 295 */     jhWriter.write("\n");
/* 296 */     jhWriter.write("-->\n");
/* 297 */     jhWriter.write("<!-- root element, all properties must be under this element -->\n");
/* 298 */     jhWriter.write("<jive>\n");
/* 299 */     jhWriter.write("    <!-- When setup is false, you can access the setup tool. -->\n");
/* 300 */     jhWriter.write("    <setup>false</setup>\n");
/* 301 */     jhWriter.write("    <!-- Database settings -->\n");
/* 302 */     jhWriter.write("    <database>\n");
/* 303 */     jhWriter.write("    <!-- Uncomment to enable Unicode support when using MySQL -->\n");
/* 304 */     jhWriter.write("    <!-- <mysql><useUnicode>true</useUnicode></mysql> -->\n");
/* 305 */     jhWriter.write("\n");
/* 306 */     jhWriter.write("    <!-- Uncomment to enable Statement caching when using Oracle JDBC -->\n");
/* 307 */     jhWriter.write("    <!-- <oracle><useStatementCache>true</useStatementCache></oracle> -->\n");
/* 308 */     jhWriter.write("    </database>\n");
/* 309 */     jhWriter.write("</jive>\n");
/* 310 */     jhWriter.close();
/*     */   }
/*     */ 
/*     */   private File getInitXmlFile() {
/* 314 */     String initFile = "jive_init.xml";
/* 315 */     URL u = getClass().getResource(initFile);
/* 316 */     if (u != null) {
/* 317 */       return new File(u.getFile());
/*     */     }
/*     */     Enumeration e;
/*     */     try
/*     */     {
/* 322 */       e = Thread.currentThread().getContextClassLoader().getResources(initFile);
/* 323 */       if (e == null)
/* 324 */         e = getClass().getClassLoader().getResources(initFile);
/*     */     }
/*     */     catch (IOException e1)
/*     */     {
/* 328 */       Log.error(e1);
/* 329 */       return null;
/*     */     }
/*     */ 
/* 332 */     if (e == null) {
/* 333 */       return null;
/*     */     }
/*     */ 
/* 336 */     while (e.hasMoreElements()) {
/* 337 */       URL url = (URL)e.nextElement();
/* 338 */       String path = url.getFile();
/*     */ 
/* 340 */       if ((path != null) && (path.indexOf("classes") != -1))
/*     */       {
/*     */         URI fileURI;
/*     */         try
/*     */         {
/* 345 */           fileURI = new URI(path);
/*     */         }
/*     */         catch (URISyntaxException urie) {
/* 348 */           return null;
/*     */         }
/*     */ 
/* 351 */         return new File(fileURI.getPath());
/*     */       }
/*     */     }
/*     */ 
/* 355 */     return null;
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 362 */     if (ActionContext.getContext().getSession().get("setup.initialcheck.ok") == null) {
/* 363 */       return "incomplete";
/*     */     }
/*     */ 
/* 366 */     if ("true".equals(getDoContinue())) {
/* 367 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/* 368 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "in_progress");
/*     */ 
/* 370 */       return "next";
/*     */     }
/*     */ 
/* 373 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "in_progress");
/* 374 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "incomplete");
/* 375 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "incomplete");
/* 376 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "incomplete");
/* 377 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "incomplete");
/* 378 */     return "success";
/*     */   }
/*     */ 
/*     */   private void testConnection()
/*     */   {
/* 383 */     Connection con = null;
/*     */     try {
/* 385 */       con = ConnectionManager.getConnection();
/* 386 */       if (con == null) {
/* 387 */         addError("db_connection", getText("setup.error.datasource.connect_failed"));
/*     */       }
/*     */       else
/*     */         try
/*     */         {
/* 392 */           Statement stmt = con.createStatement();
/*     */ 
/* 394 */           stmt.executeQuery("SELECT * FROM jiveID");
/* 395 */           stmt.close();
/*     */         }
/*     */         catch (SQLException sqle) {
/* 398 */           addError("db_connection", getText("setup.error.datasource.not_installed"));
/*     */         }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 403 */       addError("db_connection", getText("setup.error.datasource.connect_failed"));
/*     */     }
/*     */     finally {
/* 406 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   class ErrorListener extends LogListenerAdapter {
/* 411 */     boolean error = false;
/*     */ 
/*     */     ErrorListener() {  } 
/* 414 */     public void handleErrorEvent(LogEvent event) { this.error = true; }
/*     */ 
/*     */     public boolean isError()
/*     */     {
/* 418 */       return this.error;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.SetupAction
 * JD-Core Version:    0.6.2
 */
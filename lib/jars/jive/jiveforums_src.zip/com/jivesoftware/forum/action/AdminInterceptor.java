package com.jivesoftware.forum.action;

public class AdminInterceptor
{
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AdminInterceptor
 * JD-Core Version:    0.6.2
 */
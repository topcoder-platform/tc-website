/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.IntrospectiveUser;
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.WatchManager;
/*     */ import com.jivesoftware.util.CronTimer;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.text.ParseException;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public class UserSettingsAction extends ForumActionSupport
/*     */   implements Validateable
/*     */ {
/*     */   public static final int FREQUENCY_IMMEDIATELY = 0;
/*     */   public static final int FREQUENCY_ONCE_A_DAY = 1;
/*     */   public static final int FREQUENCY_EVERY_OTHER_DAY = 2;
/*     */   public static final int FREQUENCY_ONCE_A_WEEK = 3;
/*     */   private String name;
/*     */   private boolean showName;
/*     */   private String email;
/*     */   private boolean showEmail;
/*     */   private String location;
/*     */   private String occupation;
/*     */   private String homepage;
/*     */   private String biography;
/*     */   private String signature;
/*     */   private boolean showSignature;
/*     */   private String newPassword;
/*     */   private String confirmNewPassword;
/*  54 */   private int threadsPerPage = -1;
/*  55 */   private int messagesPerPage = -1;
/*     */   private String threadMode;
/*     */   private String userLocale;
/*     */   private String timezone;
/*     */   private boolean alwaysWatchNewTopics;
/*     */   private boolean alwaysWatchReplies;
/*  61 */   private int watchFrequency = 0;
/*     */   private IntrospectiveUser iUser;
/*  66 */   private boolean usersChooseLocale = JiveGlobals.getJiveBooleanProperty("skin.default.usersChooseLocale", false);
/*     */ 
/*  68 */   private boolean usersChooseThreadMode = JiveGlobals.getJiveBooleanProperty("skin.default.usersChooseThreadMode", false);
/*     */ 
/*  70 */   private String defaultThreadMode = JiveGlobals.getJiveProperty("skin.default.defaultThreadMode", "flat");
/*     */ 
/*  72 */   private int defaultThreadsPerPage = JiveGlobals.getJiveIntProperty("skin.default.defaultThreadsPerPage", 15);
/*     */ 
/*  74 */   private int defaultMessagesPerPage = JiveGlobals.getJiveIntProperty("skin.default.defaultMessagesPerPage", 15);
/*     */ 
/*  76 */   private int maxThreadsPerPage = JiveGlobals.getJiveIntProperty("skin.default.maxThreadsPerPage", 100);
/*     */ 
/*  78 */   private int maxMessagesPerPage = JiveGlobals.getJiveIntProperty("skin.default.maxMessagesPerPage", 100);
/*     */ 
/*  80 */   private boolean defaultAutoWatchTopics = JiveGlobals.getJiveBooleanProperty("skin.default.defaultAutoWatchTopics", false);
/*     */ 
/*  82 */   private boolean defaultAutoWatchReplies = JiveGlobals.getJiveBooleanProperty("skin.default.defaultAutoWatchReplies", false);
/*     */ 
/*  84 */   private int defaultBiographyLength = JiveGlobals.getJiveIntProperty("skin.default.defaultBiographyLength", 500);
/*     */ 
/*  86 */   private int defaultSignatureLength = JiveGlobals.getJiveIntProperty("skin.default.defaultSignatureLength", 500);
/*     */ 
/*  88 */   private int defaultLocationLength = JiveGlobals.getJiveIntProperty("skin.default.defaultLocationLength", 150);
/*     */ 
/*  90 */   private int defaultOccupationLength = JiveGlobals.getJiveIntProperty("skin.default.defaultOccupationLength", 150);
/*     */ 
/*  92 */   private int defaultHomepageLength = JiveGlobals.getJiveIntProperty("skin.default.defaultHomepageLength", 100);
/*     */ 
/*  94 */   private int defaultMinPasswordLength = JiveGlobals.getJiveIntProperty("skin.default.defaultMinPasswordLength", 6);
/*     */ 
/*     */   public String getName()
/*     */   {
/* 100 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 104 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public boolean isShowName() {
/* 108 */     return this.showName;
/*     */   }
/*     */ 
/*     */   public void setShowName(boolean showName) {
/* 112 */     this.showName = showName;
/*     */   }
/*     */ 
/*     */   public String getEmail() {
/* 116 */     return this.email;
/*     */   }
/*     */ 
/*     */   public void setEmail(String email) {
/* 120 */     this.email = email;
/*     */   }
/*     */ 
/*     */   public boolean isShowEmail() {
/* 124 */     return this.showEmail;
/*     */   }
/*     */ 
/*     */   public void setShowEmail(boolean showEmail) {
/* 128 */     this.showEmail = showEmail;
/*     */   }
/*     */ 
/*     */   public String getLocation() {
/* 132 */     return this.location;
/*     */   }
/*     */ 
/*     */   public void setLocation(String location) {
/* 136 */     this.location = location;
/*     */   }
/*     */ 
/*     */   public String getOccupation() {
/* 140 */     return this.occupation;
/*     */   }
/*     */ 
/*     */   public void setOccupation(String occupation) {
/* 144 */     this.occupation = occupation;
/*     */   }
/*     */ 
/*     */   public String getHomepage() {
/* 148 */     return this.homepage;
/*     */   }
/*     */ 
/*     */   public void setHomepage(String homepage) {
/* 152 */     this.homepage = homepage;
/*     */   }
/*     */ 
/*     */   public String getBiography() {
/* 156 */     return this.biography;
/*     */   }
/*     */ 
/*     */   public void setBiography(String biography) {
/* 160 */     this.biography = biography;
/*     */   }
/*     */ 
/*     */   public String getSignature() {
/* 164 */     return this.signature;
/*     */   }
/*     */ 
/*     */   public void setSignature(String signature) {
/* 168 */     this.signature = signature;
/*     */   }
/*     */ 
/*     */   public String getNewPassword() {
/* 172 */     return this.newPassword;
/*     */   }
/*     */ 
/*     */   public boolean isShowSignature() {
/* 176 */     return this.showSignature;
/*     */   }
/*     */ 
/*     */   public void setShowSignature(boolean showSignature) {
/* 180 */     this.showSignature = showSignature;
/*     */   }
/*     */ 
/*     */   public void setNewPassword(String newPassword) {
/* 184 */     this.newPassword = newPassword;
/*     */   }
/*     */ 
/*     */   public String getConfirmNewPassword() {
/* 188 */     return this.confirmNewPassword;
/*     */   }
/*     */ 
/*     */   public void setConfirmNewPassword(String confirmNewPassword) {
/* 192 */     this.confirmNewPassword = confirmNewPassword;
/*     */   }
/*     */ 
/*     */   public int getThreadsPerPage() {
/* 196 */     return this.threadsPerPage;
/*     */   }
/*     */ 
/*     */   public void setThreadsPerPage(int threadsPerPage) {
/* 200 */     this.threadsPerPage = threadsPerPage;
/*     */   }
/*     */ 
/*     */   public int getMessagesPerPage() {
/* 204 */     return this.messagesPerPage;
/*     */   }
/*     */ 
/*     */   public void setMessagesPerPage(int messagesPerPage) {
/* 208 */     this.messagesPerPage = messagesPerPage;
/*     */   }
/*     */ 
/*     */   public String getThreadMode() {
/* 212 */     return this.threadMode;
/*     */   }
/*     */ 
/*     */   public void setThreadMode(String threadMode) {
/* 216 */     this.threadMode = threadMode;
/*     */   }
/*     */ 
/*     */   public String getUserLocale() {
/* 220 */     return this.userLocale;
/*     */   }
/*     */ 
/*     */   public void setUserLocale(String userLocale) {
/* 224 */     this.userLocale = userLocale;
/*     */   }
/*     */ 
/*     */   public String getTimezone() {
/* 228 */     return this.timezone;
/*     */   }
/*     */ 
/*     */   public void setTimezone(String timezone) {
/* 232 */     this.timezone = timezone;
/*     */   }
/*     */ 
/*     */   public boolean isAlwaysWatchNewTopics() {
/* 236 */     return this.alwaysWatchNewTopics;
/*     */   }
/*     */ 
/*     */   public void setAlwaysWatchNewTopics(boolean alwaysWatchNewTopics) {
/* 240 */     this.alwaysWatchNewTopics = alwaysWatchNewTopics;
/*     */   }
/*     */ 
/*     */   public boolean isAlwaysWatchReplies() {
/* 244 */     return this.alwaysWatchReplies;
/*     */   }
/*     */ 
/*     */   public void setAlwaysWatchReplies(boolean alwaysWatchReplies) {
/* 248 */     this.alwaysWatchReplies = alwaysWatchReplies;
/*     */   }
/*     */ 
/*     */   public int getWatchFrequency() {
/* 252 */     return this.watchFrequency;
/*     */   }
/*     */ 
/*     */   public void setWatchFrequency(int watchFrequency) {
/* 256 */     this.watchFrequency = watchFrequency;
/*     */   }
/*     */ 
/*     */   public boolean isUsersChooseLocale()
/*     */   {
/* 262 */     return this.usersChooseLocale;
/*     */   }
/*     */ 
/*     */   public boolean isUsersChooseThreadMode() {
/* 266 */     return this.usersChooseThreadMode;
/*     */   }
/*     */ 
/*     */   public int getMaxBiographyLength() {
/* 270 */     return this.defaultBiographyLength;
/*     */   }
/*     */ 
/*     */   public int getMaxSignatureLength() {
/* 274 */     return this.defaultSignatureLength;
/*     */   }
/*     */ 
/*     */   public int getMaxLocationLength() {
/* 278 */     return this.defaultLocationLength;
/*     */   }
/*     */ 
/*     */   public int getMaxOccupationLength() {
/* 282 */     return this.defaultOccupationLength;
/*     */   }
/*     */ 
/*     */   public int getMaxHomepageLength() {
/* 286 */     return this.defaultHomepageLength;
/*     */   }
/*     */ 
/*     */   public int getMinPasswordLength() {
/* 290 */     return this.defaultMinPasswordLength;
/*     */   }
/*     */ 
/*     */   public String[][] getThreadModes() {
/* 294 */     return new String[][] { { "flat", getText("thread.flat") }, { "threaded", getText("thread.threaded") }, { "tree", getText("thread.tree") } };
/*     */   }
/*     */ 
/*     */   public IntrospectiveUser getIntrospectiveUser()
/*     */   {
/* 302 */     if (this.iUser == null) {
/* 303 */       User user = getPageUser();
/* 304 */       if ((user instanceof IntrospectiveUser)) {
/* 305 */         this.iUser = ((IntrospectiveUser)user);
/*     */       }
/*     */     }
/* 308 */     return this.iUser;
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/* 314 */     IntrospectiveUser iUser = getIntrospectiveUser();
/*     */ 
/* 316 */     if ((iUser != null) && (iUser.isSetNameSupported()) && 
/* 317 */       (this.name == null)) {
/* 318 */       addFieldError("name", "");
/*     */     }
/*     */ 
/* 321 */     if ((iUser != null) && (iUser.isSetEmailSupported()) && (JiveGlobals.getJiveBooleanProperty("skin.default.changeEmailEnabled", true)))
/*     */     {
/* 323 */       if (this.email == null) {
/* 324 */         addFieldError("email", "");
/*     */       }
/*     */     }
/* 327 */     if (this.threadsPerPage == -1) {
/* 328 */       addFieldError("threadsPerPage", "");
/*     */     }
/* 330 */     if (this.messagesPerPage == -1) {
/* 331 */       addFieldError("messagesPerPage", "");
/*     */     }
/* 333 */     if ((this.usersChooseThreadMode) && (this.threadMode == null)) {
/* 334 */       addFieldError("topicMode", "");
/*     */     }
/* 336 */     if ((this.usersChooseLocale) && (this.userLocale == null)) {
/* 337 */       addFieldError("userLocale", "");
/*     */     }
/* 339 */     if (this.timezone == null) {
/* 340 */       addFieldError("timezone", "");
/*     */     }
/* 342 */     if ((this.biography != null) && (this.biography.length() > this.defaultBiographyLength)) {
/* 343 */       addFieldError("biography", "");
/*     */     }
/* 345 */     if ((this.signature != null) && (this.signature.length() > this.defaultSignatureLength)) {
/* 346 */       addFieldError("signature", "");
/*     */     }
/* 348 */     if ((this.location != null) && (this.location.length() > this.defaultLocationLength)) {
/* 349 */       addFieldError("location", "");
/*     */     }
/* 351 */     if ((this.occupation != null) && (this.occupation.length() > this.defaultOccupationLength)) {
/* 352 */       addFieldError("occupation", "");
/*     */     }
/* 354 */     if ((this.homepage != null) && (this.homepage.length() > this.defaultHomepageLength)) {
/* 355 */       addFieldError("homepage", "");
/*     */     }
/* 357 */     if ((iUser != null) && (iUser.isSetPasswordSupported()) && (JiveGlobals.getJiveBooleanProperty("skin.default.changePasswordEnabled", true)))
/*     */     {
/* 360 */       if ((this.newPassword != null) && (this.confirmNewPassword == null)) {
/* 361 */         addFieldError("confirmNewPassword", "");
/*     */       }
/*     */ 
/* 364 */       if ((this.newPassword != null) && (this.confirmNewPassword != null))
/* 365 */         if (this.newPassword.length() < this.defaultMinPasswordLength) {
/* 366 */           addFieldError("passwordLength", "");
/*     */         }
/* 368 */         else if (!this.newPassword.equals(this.confirmNewPassword))
/* 369 */           addFieldError("passwordMatch", "");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/* 379 */     if (isGuest()) {
/* 380 */       return "unauthorized";
/*     */     }
/* 382 */     if (hasFieldErrors()) {
/* 383 */       return "error";
/*     */     }
/* 385 */     User user = getPageUser();
/* 386 */     setName(user.getName());
/* 387 */     setShowName(user.isNameVisible());
/* 388 */     setEmail(user.getEmail());
/* 389 */     setShowEmail(user.isEmailVisible());
/* 390 */     setLocation(user.getProperty("jiveLocation"));
/* 391 */     setOccupation(user.getProperty("jiveOccupation"));
/* 392 */     setHomepage(user.getProperty("jiveHomepage"));
/* 393 */     setBiography(user.getProperty("jiveBiography"));
/* 394 */     setSignature(user.getProperty("jiveSignature"));
/* 395 */     setShowSignature(!"false".equals(user.getProperty("jiveSignatureVisible")));
/*     */ 
/* 397 */     int threads = this.defaultThreadsPerPage;
/*     */     try {
/* 399 */       threads = Integer.parseInt(user.getProperty("jiveThreadRange"));
/*     */     } catch (NumberFormatException ignored) {
/*     */     }
/* 402 */     setThreadsPerPage(threads);
/*     */ 
/* 404 */     int messages = this.defaultMessagesPerPage;
/*     */     try {
/* 406 */       messages = Integer.parseInt(user.getProperty("jiveMessageRange"));
/*     */     } catch (NumberFormatException ignored) {
/*     */     }
/* 409 */     setMessagesPerPage(messages);
/*     */ 
/* 411 */     if (this.usersChooseThreadMode) {
/* 412 */       setThreadMode(user.getProperty("jiveThreadMode"));
/* 413 */       if (getThreadMode() == null) {
/* 414 */         setThreadMode(this.defaultThreadMode);
/*     */       }
/*     */     }
/*     */ 
/* 418 */     if (this.usersChooseLocale) {
/* 419 */       setUserLocale(user.getProperty("jiveLocale"));
/* 420 */       if (getUserLocale() == null) {
/* 421 */         setUserLocale(JiveGlobals.getLocale().toString());
/*     */       }
/*     */     }
/*     */ 
/* 425 */     setTimezone(user.getProperty("jiveTimeZoneID"));
/* 426 */     if (getTimezone() == null) {
/* 427 */       setTimezone(JiveGlobals.getTimeZone().getID());
/*     */     }
/*     */ 
/* 431 */     boolean watchTopics = this.defaultAutoWatchTopics;
/* 432 */     String watchTopicsProp = user.getProperty("jiveAutoWatchNewTopics");
/* 433 */     if ("true".equals(watchTopicsProp)) {
/* 434 */       watchTopics = true;
/*     */     }
/* 436 */     else if ("false".equals(watchTopicsProp)) {
/* 437 */       watchTopics = false;
/*     */     }
/* 439 */     setAlwaysWatchNewTopics(watchTopics);
/*     */ 
/* 441 */     boolean watchReplies = this.defaultAutoWatchReplies;
/* 442 */     String watchRepliesProp = user.getProperty("jiveAutoWatchReplies");
/* 443 */     if ("true".equals(watchRepliesProp)) {
/* 444 */       watchReplies = true;
/*     */     }
/* 446 */     else if ("false".equals(watchRepliesProp)) {
/* 447 */       watchReplies = false;
/*     */     }
/* 449 */     setAlwaysWatchReplies(watchReplies);
/*     */ 
/* 452 */     setWatchFrequency(0);
/*     */     try {
/* 454 */       CronTimer timer = getForumFactory().getWatchManager().getBatchTimer(getPageUser());
/* 455 */       if (timer != null)
/* 456 */         setWatchFrequency(determineWatchFrequency(timer));
/*     */     }
/*     */     catch (UnauthorizedException ignored) {
/*     */     }
/* 460 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 467 */     User user = getPageUser();
/* 468 */     IntrospectiveUser iUser = getIntrospectiveUser();
/*     */     try {
/* 470 */       if ((iUser != null) && (iUser.isSetNameSupported()) && 
/* 471 */         (!getName().equals(user.getName()))) {
/* 472 */         user.setName(getName());
/*     */       }
/*     */ 
/* 475 */       if ((iUser != null) && (iUser.isSetEmailSupported()) && (JiveGlobals.getJiveBooleanProperty("skin.default.changeEmailEnabled", true)))
/*     */       {
/* 477 */         if (!getEmail().equals(user.getEmail())) {
/* 478 */           user.setEmail(getEmail());
/*     */         }
/*     */       }
/* 481 */       if ((iUser != null) && (iUser.isSetNameVisibleSupported())) {
/* 482 */         user.setNameVisible(isShowName());
/*     */       }
/* 484 */       if ((iUser != null) && (iUser.isSetEmailVisibleSupported())) {
/* 485 */         user.setEmailVisible(isShowEmail());
/*     */       }
/*     */ 
/* 488 */       if ((iUser != null) && (iUser.isSetPasswordSupported()) && 
/* 489 */         (getNewPassword() != null)) {
/* 490 */         user.setPassword(getNewPassword());
/*     */       }
/*     */ 
/* 494 */       if (getLocation() == null) {
/* 495 */         user.deleteProperty("jiveLocation");
/*     */       }
/*     */       else {
/* 498 */         user.setProperty("jiveLocation", getLocation());
/*     */       }
/* 500 */       if (getOccupation() == null) {
/* 501 */         user.deleteProperty("jiveOccupation");
/*     */       }
/*     */       else {
/* 504 */         user.setProperty("jiveOccupation", getOccupation());
/*     */       }
/* 506 */       if (getHomepage() == null) {
/* 507 */         user.deleteProperty("jiveHomepage");
/*     */       }
/*     */       else {
/* 510 */         user.setProperty("jiveHomepage", getHomepage());
/*     */       }
/* 512 */       if (getBiography() == null) {
/* 513 */         user.deleteProperty("jiveBiography");
/*     */       }
/*     */       else {
/* 516 */         user.setProperty("jiveBiography", getBiography());
/*     */       }
/* 518 */       if (getSignature() == null) {
/* 519 */         user.deleteProperty("jiveSignature");
/*     */       }
/*     */       else {
/* 522 */         user.setProperty("jiveSignature", getSignature());
/*     */       }
/* 524 */       user.setProperty("jiveSignatureVisible", String.valueOf(isShowSignature()));
/*     */ 
/* 526 */       if (getThreadsPerPage() > -1) {
/* 527 */         int numThreads = getThreadsPerPage();
/* 528 */         if (numThreads > this.maxThreadsPerPage) {
/* 529 */           numThreads = this.maxThreadsPerPage;
/*     */         }
/* 531 */         user.setProperty("jiveThreadRange", String.valueOf(numThreads));
/*     */       }
/* 533 */       if (getMessagesPerPage() > -1) {
/* 534 */         int numMessages = getMessagesPerPage();
/* 535 */         if (numMessages > this.maxMessagesPerPage) {
/* 536 */           numMessages = this.maxThreadsPerPage;
/*     */         }
/* 538 */         user.setProperty("jiveMessageRange", String.valueOf(numMessages));
/*     */       }
/* 540 */       if ((getThreadMode() != null) && (isUsersChooseThreadMode())) {
/* 541 */         user.setProperty("jiveThreadMode", getThreadMode());
/*     */       }
/* 543 */       if ((getUserLocale() != null) && (isUsersChooseLocale())) {
/* 544 */         user.setProperty("jiveLocale", getUserLocale());
/*     */       }
/* 546 */       if (getTimezone() != null) {
/* 547 */         user.setProperty("jiveTimeZoneID", getTimezone());
/*     */       }
/* 549 */       user.setProperty("jiveAutoWatchNewTopics", String.valueOf(isAlwaysWatchNewTopics()));
/* 550 */       user.setProperty("jiveAutoWatchReplies", String.valueOf(isAlwaysWatchReplies()));
/*     */ 
/* 552 */       CronTimer current = getForumFactory().getWatchManager().getBatchTimer(getPageUser());
/* 553 */       if ((current == null) && (this.watchFrequency != 0))
/*     */       {
/* 555 */         current = createCronTimer();
/*     */ 
/* 557 */         getForumFactory().getWatchManager().setBatchTimer(getPageUser(), current);
/*     */       }
/* 559 */       else if (determineWatchFrequency(current) != this.watchFrequency) {
/* 560 */         CronTimer newTimer = null;
/*     */ 
/* 562 */         if (this.watchFrequency != 0) {
/* 563 */           newTimer = createCronTimer();
/*     */         }
/*     */ 
/* 567 */         getForumFactory().getWatchManager().setBatchTimer(getPageUser(), newTimer);
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 571 */       return "unauthorized";
/*     */     }
/* 573 */     return "success";
/*     */   }
/*     */ 
/*     */   private int determineWatchFrequency(CronTimer timer)
/*     */   {
/* 578 */     if (timer == null) {
/* 579 */       return 0;
/*     */     }
/* 581 */     if (timer.getNextFireTimeAfter(timer.getNextFireTime()).getTime() - timer.getNextFireTime().getTime() == 86400000L)
/*     */     {
/* 583 */       return 1;
/*     */     }
/* 585 */     if (timer.getNextFireTimeAfter(timer.getNextFireTime()).getTime() - timer.getNextFireTime().getTime() == 172800000L)
/*     */     {
/* 587 */       return 2;
/*     */     }
/* 589 */     if (timer.getNextFireTimeAfter(timer.getNextFireTime()).getTime() - timer.getNextFireTime().getTime() == 604800000L)
/*     */     {
/* 591 */       return 3;
/*     */     }
/*     */ 
/* 595 */     Log.warn("Unknown watch frequency for user " + getPageUser().getUsername() + ": " + timer.getCronExpression());
/*     */ 
/* 597 */     return 0;
/*     */   }
/*     */ 
/*     */   private CronTimer createCronTimer()
/*     */   {
/*     */     try {
/* 603 */       int minute = (int)(Math.random() * 60.0D);
/*     */ 
/* 605 */       int hour = JiveGlobals.getJiveProperty("watches.email.digest.time") == null ? 3 : Integer.parseInt(JiveGlobals.getJiveProperty("watches.email.digest.time"));
/*     */ 
/* 608 */       String day = JiveGlobals.getJiveProperty("watches.email.digest.day") == null ? "SUN" : JiveGlobals.getJiveProperty("watches.email.digest.day");
/*     */ 
/* 612 */       if (this.watchFrequency == 1) {
/* 613 */         return new CronTimer("0 " + minute + " " + hour + " ? * *");
/*     */       }
/* 615 */       if (this.watchFrequency == 2) {
/* 616 */         return new CronTimer("0 " + minute + " " + hour + " */2 * ?");
/*     */       }
/* 618 */       if (this.watchFrequency == 3)
/* 619 */         return new CronTimer("0 " + minute + " " + hour + " ? * " + day);
/*     */     }
/*     */     catch (ParseException e)
/*     */     {
/* 623 */       Log.error(e);
/*     */     }
/* 625 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.UserSettingsAction
 * JD-Core Version:    0.6.2
 */
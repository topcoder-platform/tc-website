/*     */ package com.jivesoftware.forum.action.setup;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.PermissionType;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.database.DbPermissionsManager;
/*     */ import com.jivesoftware.base.ldap.LdapManager;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import javax.naming.directory.Attributes;
/*     */ import javax.naming.directory.BasicAttributes;
/*     */ import javax.naming.directory.DirContext;
/*     */ 
/*     */ public class LdapAdminSetupAction extends SetupActionSupport
/*     */   implements Validateable
/*     */ {
/*  31 */   private String ldapMode = "ldapOnly";
/*     */   private String username;
/*     */ 
/*     */   public String getLdapMode()
/*     */   {
/*  37 */     return this.ldapMode;
/*     */   }
/*     */ 
/*     */   public void setLdapMode(String ldapMode) {
/*  41 */     this.ldapMode = ldapMode;
/*     */   }
/*     */ 
/*     */   public String getUsername() {
/*  45 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username) {
/*  49 */     this.username = username;
/*     */   }
/*     */ 
/*     */   public boolean isLdapUserManager()
/*     */   {
/*  55 */     String userProp = JiveGlobals.getJiveProperty("UserManager.className");
/*  56 */     if ((userProp != null) && (userProp.equals("com.jivesoftware.base.ldap.LdapUserManager"))) {
/*  57 */       return true;
/*     */     }
/*     */ 
/*  60 */     return false;
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/*  67 */     if ((!"ldapAndJive".equals(this.ldapMode)) && (!"ldapOnly".equals(this.ldapMode)))
/*  68 */       addFieldError("ldapMode", getText("setup.error.ldapadminsetup.admin_mode"));
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*  73 */     if (isLdapUserManager()) {
/*  74 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/*  75 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/*  76 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "done");
/*  77 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "done");
/*  78 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "in_progress");
/*  79 */       return "input";
/*     */     }
/*     */ 
/*  82 */     return "admin";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/*  87 */     if ("true".equals(getDoContinue())) {
/*  88 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/*  89 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/*  90 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "done");
/*  91 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "done");
/*  92 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "done");
/*  93 */       return "next";
/*     */     }
/*     */ 
/*  96 */     LdapManager ldapManager = LdapManager.getInstance();
/*     */ 
/*  98 */     if ("ldapOnly".equals(this.ldapMode)) {
/*  99 */       ldapManager.setMode(0);
/*     */     }
/*     */     else {
/* 102 */       ldapManager.setMode(1);
/*     */     }
/*     */ 
/* 105 */     boolean success = false;
/* 106 */     DirContext context = null;
/*     */ 
/* 108 */     if (ldapManager.getMode() == 0)
/*     */       try {
/* 110 */         context = ldapManager.getContext();
/* 111 */         String userDN = ldapManager.findUserDN(this.username);
/* 112 */         Date now = new Date();
/* 113 */         Attributes attrs = new BasicAttributes();
/* 114 */         attrs.put("jiveUserID", new Long(1L).toString());
/* 115 */         attrs.put("jiveNameVisible", "true");
/* 116 */         attrs.put("jiveEmailVisible", "true");
/* 117 */         attrs.put("jiveCDate", Long.toString(now.getTime()));
/* 118 */         attrs.put("jiveMDate", Long.toString(now.getTime()));
/* 119 */         context.modifyAttributes(userDN, 2, attrs);
/*     */ 
/* 121 */         tryUser(this.username);
/*     */ 
/* 123 */         success = true;
/*     */       }
/*     */       catch (Exception e) {
/* 126 */         addActionError(getText("setup.error.ldapadminsetup.general_error"));
/* 127 */         Log.error(e);
/*     */       } finally {
/*     */         try {
/* 130 */           if (context != null) context.close(); 
/*     */         } catch (Exception e) { Log.error(e); }
/*     */ 
/*     */       }
/* 134 */     else if (ldapManager.getMode() == 1) {
/*     */       try
/*     */       {
/* 137 */         tryUser(this.username);
/*     */ 
/* 139 */         success = true;
/*     */       }
/*     */       catch (Exception e) {
/* 142 */         addActionError(getText("setup.error.ldapadminsetup.general_error"));
/* 143 */         Log.error(e);
/*     */       }
/*     */     }
/*     */ 
/* 147 */     if (!success) {
/* 148 */       return "error";
/*     */     }
/*     */ 
/* 151 */     JiveGlobals.setJiveProperty("setup", "true");
/* 152 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/* 153 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/* 154 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "done");
/* 155 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "done");
/* 156 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "done");
/* 157 */     return "next";
/*     */   }
/*     */ 
/*     */   private static void tryUser(String username)
/*     */     throws Exception
/*     */   {
/* 168 */     DbForumFactory forumFactory = DbForumFactory.getInstance();
/* 169 */     User user = forumFactory.getUserManager().getUser(username);
/* 170 */     DbPermissionsManager permManager = (DbPermissionsManager)forumFactory.getPermissionsManager();
/*     */ 
/* 174 */     permManager.addUserPermission(17, -1L, user, PermissionType.ADDITIVE, 576460752303423488L);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.LdapAdminSetupAction
 * JD-Core Version:    0.6.2
 */
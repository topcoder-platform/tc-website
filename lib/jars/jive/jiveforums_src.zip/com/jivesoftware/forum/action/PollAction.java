/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.Poll;
/*     */ import com.jivesoftware.base.PollException;
/*     */ import com.jivesoftware.base.PollManager;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.action.JiveObjectLoader;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.opensymphony.webwork.ServletActionContext;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class PollAction extends ForumThreadAction
/*     */   implements JiveObjectLoader
/*     */ {
/*     */   public static final String EXPIRED = "expired";
/*     */   public static final String VOTED = "voted";
/*  26 */   private long pollID = -1L;
/*  27 */   private long categoryID = 1L;
/*  28 */   private int[] option = null;
/*     */ 
/*  30 */   private Poll poll = null;
/*  31 */   private ForumCategory category = null;
/*     */ 
/*     */   public long getPollID()
/*     */   {
/*  35 */     return this.pollID;
/*     */   }
/*     */ 
/*     */   public void setPollID(long pollID) {
/*  39 */     this.pollID = pollID;
/*     */   }
/*     */ 
/*     */   public ForumCategory getCategory() {
/*  43 */     return this.category;
/*     */   }
/*     */ 
/*     */   public long getCategoryID() {
/*  47 */     return this.categoryID;
/*     */   }
/*     */ 
/*     */   public void setCategoryID(long categoryID) {
/*  51 */     this.categoryID = categoryID;
/*     */   }
/*     */ 
/*     */   public int[] getOption() {
/*  55 */     return this.option;
/*     */   }
/*     */ 
/*     */   public void setOption(int[] option) {
/*  59 */     this.option = option;
/*     */   }
/*     */ 
/*     */   public boolean hasVoted()
/*     */   {
/*  64 */     if ((!getAuthToken().isAnonymous()) && (this.poll.hasUserVoted(getPageUser()))) {
/*  65 */       return true;
/*     */     }
/*     */ 
/*  68 */     if ((getAuthToken().isAnonymous()) && (this.poll.hasAnonymousVoted(ServletActionContext.getRequest().getRemoteHost())))
/*     */     {
/*  71 */       return true;
/*     */     }
/*     */ 
/*  74 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isAllowedToVote() {
/*  78 */     if (this.poll == null) {
/*  79 */       return false;
/*     */     }
/*     */ 
/*  83 */     if (!this.poll.isAuthorized(1024L)) {
/*  84 */       return false;
/*     */     }
/*     */ 
/*  87 */     if ((!getAuthToken().isAnonymous()) && (this.poll.hasUserVoted(getPageUser())) && (!this.poll.isModeEnabled(16L)))
/*     */     {
/*  90 */       return false;
/*     */     }
/*     */ 
/*  93 */     if ((getAuthToken().isAnonymous()) && (this.poll.hasAnonymousVoted(ServletActionContext.getRequest().getRemoteHost())) && (!this.poll.isModeEnabled(32L)))
/*     */     {
/*  97 */       return false;
/*     */     }
/*     */ 
/* 100 */     if (!isPollActive()) {
/* 101 */       return false;
/*     */     }
/*     */ 
/* 104 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isPollActive() {
/* 108 */     if (this.poll == null) {
/* 109 */       return false;
/*     */     }
/*     */ 
/* 112 */     Date now = new Date();
/*     */ 
/* 115 */     if (this.poll.getStartDate().compareTo(now) > 0) {
/* 116 */       return false;
/*     */     }
/*     */ 
/* 119 */     if (this.poll.getEndDate().compareTo(now) < 0) {
/* 120 */       return false;
/*     */     }
/*     */ 
/* 123 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isPollExpired()
/*     */   {
/* 128 */     if (this.poll == null) {
/* 129 */       return true;
/*     */     }
/*     */ 
/* 133 */     if (this.poll.getExpirationDate().compareTo(new Date()) < 0) {
/* 134 */       return true;
/*     */     }
/*     */ 
/* 137 */     return false;
/*     */   }
/*     */ 
/*     */   public Poll getPoll()
/*     */   {
/* 142 */     return this.poll;
/*     */   }
/*     */ 
/*     */   public String doDefault() throws Exception {
/*     */     try {
/* 147 */       if (!loadJiveObjects()) {
/* 148 */         addActionError("Unknown poll");
/* 149 */         return "fatal";
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 153 */       setLoginAttributes();
/* 154 */       return "login";
/*     */     }
/*     */ 
/* 157 */     if (isPollExpired()) {
/* 158 */       return "expired";
/*     */     }
/* 160 */     if ((isPollActive()) && (isAllowedToVote())) {
/* 161 */       return "input";
/*     */     }
/*     */ 
/* 164 */     return "success";
/*     */   }
/*     */ 
/*     */   public String execute() throws Exception
/*     */   {
/*     */     try {
/* 170 */       if (!loadJiveObjects()) {
/* 171 */         addActionError("Unknown poll");
/* 172 */         return "fatal";
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 176 */       setLoginAttributes();
/* 177 */       return "login";
/*     */     }
/*     */ 
/* 181 */     if (isPollExpired()) {
/* 182 */       return "expired";
/*     */     }
/*     */ 
/* 185 */     if (!isPollActive()) {
/* 186 */       return "success";
/*     */     }
/*     */ 
/* 189 */     if ((this.option == null) && (isPollActive())) {
/* 190 */       return "success";
/*     */     }
/*     */ 
/* 193 */     if ((isPollActive()) && (!isAllowedToVote())) {
/* 194 */       return "success";
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 199 */       if ((getAuthToken().isAnonymous()) && (getPoll().hasAnonymousVoted(ServletActionContext.getRequest().getRemoteHost())) && (this.poll.isModeEnabled(32L)))
/*     */       {
/* 203 */         List votes = getPoll().getAnonymousVotes(ServletActionContext.getRequest().getRemoteHost());
/*     */ 
/* 205 */         if ((this.option.length == 1) && (votes.size() == 1)) {
/* 206 */           int prevVote = ((Integer)votes.get(0)).intValue();
/* 207 */           this.poll.changeAnonymousVote(prevVote, this.option[0], ServletActionContext.getRequest().getRemoteHost());
/*     */         }
/*     */ 
/* 214 */         return "voted";
/*     */       }
/* 216 */       if ((!getAuthToken().isAnonymous()) && (this.poll.hasUserVoted(getPageUser())) && (this.poll.isModeEnabled(16L)))
/*     */       {
/* 219 */         List votes = getPoll().getUserVotes(getPageUser());
/*     */ 
/* 221 */         if ((this.option.length == 1) && (votes.size() == 1)) {
/* 222 */           int prevVote = ((Integer)votes.get(0)).intValue();
/* 223 */           this.poll.changeUserVote(prevVote, this.option[0], getPageUser());
/*     */         }
/*     */ 
/* 229 */         return "voted";
/*     */       }
/*     */ 
/* 232 */       for (int i = 0; i < this.option.length; i++) {
/* 233 */         int optionIndex = this.option[i];
/* 234 */         if (getAuthToken().isAnonymous()) {
/* 235 */           this.poll.addAnonymousVote(optionIndex, ServletActionContext.getRequest().getRemoteHost());
/*     */         }
/*     */         else
/*     */         {
/* 239 */           this.poll.addUserVote(optionIndex, getPageUser());
/*     */         }
/*     */       }
/*     */ 
/* 243 */       return "voted";
/*     */     }
/*     */     catch (PollException e)
/*     */     {
/* 247 */       Log.error(e);
/* 248 */       return "error";
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 251 */       Log.error(e);
/* 252 */     }return "error";
/*     */   }
/*     */ 
/*     */   public String loadObjects()
/*     */     throws Exception
/*     */   {
/* 262 */     if (this.pollID <= -1L) {
/* 263 */       addFieldError("pollID", String.valueOf(this.pollID));
/* 264 */       return "notfound";
/*     */     }
/*     */     try
/*     */     {
/* 268 */       this.poll = getForumFactory().getPollManager().getPoll(this.pollID);
/* 269 */       int objectType = this.poll.getObjectType();
/* 270 */       long objectID = this.poll.getObjectID();
/*     */ 
/* 272 */       switch (objectType) {
/*     */       case 1:
/* 274 */         setThreadID(objectID);
/* 275 */         setThread(getForumFactory().getForumThread(getThreadID()));
/* 276 */         setForum(getThread().getForum());
/* 277 */         break;
/*     */       case 0:
/* 279 */         setForumID(objectID);
/* 280 */         setForum(getForumFactory().getForum(getForumID()));
/* 281 */         break;
/*     */       case 14:
/* 283 */         setCategoryID(objectID);
/* 284 */         this.category = getForumFactory().getForumCategory(getCategoryID());
/* 285 */         break;
/*     */       }
/*     */ 
/* 291 */       if ((getThreadID() > 0L) && (getThread() == null)) {
/* 292 */         setThread(getForumFactory().getForumThread(getThreadID()));
/*     */       }
/* 294 */       if ((getForumID() > 0L) && (getForum() == null)) {
/* 295 */         setForum(getForumFactory().getForum(getForumID()));
/*     */       }
/* 297 */       if ((getCategoryID() > 0L) && (getCategory() == null)) {
/* 298 */         this.category = getForumFactory().getForumCategory(getCategoryID());
/*     */       }
/*     */ 
/* 301 */       return "success";
/*     */     }
/*     */     catch (ForumThreadNotFoundException e) {
/* 304 */       addActionError(e.getMessage());
/*     */     }
/*     */     catch (ForumNotFoundException e) {
/* 307 */       addActionError(e.getMessage());
/*     */     }
/*     */     catch (ForumCategoryNotFoundException e) {
/* 310 */       addActionError(e.getMessage());
/*     */     }
/*     */     catch (NotFoundException e) {
/* 313 */       addActionError(e.getMessage());
/*     */     }
/* 315 */     return "error";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PollAction
 * JD-Core Version:    0.6.2
 */
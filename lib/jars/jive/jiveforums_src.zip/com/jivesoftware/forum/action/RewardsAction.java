/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.RewardException;
/*     */ import com.jivesoftware.forum.RewardManager;
/*     */ import com.opensymphony.webwork.ServletActionContext;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class RewardsAction extends ForumActionSupport
/*     */   implements Validateable
/*     */ {
/*     */   public static final String ASSIGN = "assign";
/*     */   public static final String UNASSIGN = "unassign";
/*     */   public static final String TRANSFER = "transfer";
/*     */   public static final String TRANSFER_SUCCESS = "transfer_success";
/*     */   public static final String ASSIGN_SUCCESS = "assign_success";
/*     */   public static final String UNASSIGN_SUCCESS = "unassign_success";
/*  42 */   private long forumID = -1L;
/*  43 */   private long threadID = -1L;
/*  44 */   private long messageID = -1L;
/*     */   private String mode;
/*  46 */   private int points = -1;
/*     */   private String cancel;
/*     */   private Forum forum;
/*     */   private ForumThread thread;
/*     */   private ForumMessage message;
/*     */   private RewardManager rewardManager;
/*     */ 
/*     */   public long getForumID()
/*     */   {
/*  58 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID) {
/*  62 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public long getThreadID() {
/*  66 */     return this.threadID;
/*     */   }
/*     */ 
/*     */   public void setThreadID(long threadID) {
/*  70 */     this.threadID = threadID;
/*     */   }
/*     */ 
/*     */   public long getMessageID() {
/*  74 */     return this.messageID;
/*     */   }
/*     */ 
/*     */   public void setMessageID(long messageID) {
/*  78 */     this.messageID = messageID;
/*     */   }
/*     */ 
/*     */   public String getMode() {
/*  82 */     return this.mode;
/*     */   }
/*     */ 
/*     */   public void setMode(String mode) {
/*  86 */     this.mode = mode;
/*     */   }
/*     */ 
/*     */   public int getPoints() {
/*  90 */     return this.points;
/*     */   }
/*     */ 
/*     */   public void setPoints(int points) {
/*  94 */     this.points = points;
/*     */   }
/*     */ 
/*     */   public Forum getForum()
/*     */   {
/* 100 */     return this.forum;
/*     */   }
/*     */ 
/*     */   protected void setForum(Forum forum) {
/* 104 */     this.forum = forum;
/*     */   }
/*     */ 
/*     */   public ForumThread getThread() {
/* 108 */     return this.thread;
/*     */   }
/*     */ 
/*     */   protected void setThread(ForumThread thread) {
/* 112 */     this.thread = thread;
/*     */   }
/*     */ 
/*     */   public ForumMessage getMessage() {
/* 116 */     return this.message;
/*     */   }
/*     */ 
/*     */   protected void setMessage(ForumMessage message) {
/* 120 */     this.message = message;
/*     */   }
/*     */ 
/*     */   public String getCancel() {
/* 124 */     return this.cancel;
/*     */   }
/*     */ 
/*     */   public void setCancel(String cancel) {
/* 128 */     this.cancel = cancel;
/*     */   }
/*     */ 
/*     */   public RewardManager getRewardManager() {
/* 132 */     return this.rewardManager;
/*     */   }
/*     */ 
/*     */   public int getMaxAssignablePoints()
/*     */   {
/* 139 */     int maxThreadPoints = getRewardManager().getMaxThreadPoints();
/* 140 */     if (maxThreadPoints == -1)
/*     */     {
/* 142 */       maxThreadPoints = 10;
/*     */     }
/* 144 */     return maxThreadPoints;
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/* 151 */     if ((!"true".equals(getCancel())) && (this.points < 0))
/*     */     {
/* 153 */       addFieldError("points", getText("rewards.error_invalid_num"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public String doDefault() {
/*     */     try {
/* 159 */       if (!loadJiveObjects())
/* 160 */         return "fatal";
/*     */     }
/*     */     catch (UnauthorizedException ue)
/*     */     {
/* 164 */       setLoginAttributes();
/* 165 */       ServletActionContext.getRequest().setAttribute("jive.login.successURL", getPageURL());
/* 166 */       return "login";
/*     */     }
/* 168 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute() {
/*     */     try {
/* 173 */       if (!loadJiveObjects())
/* 174 */         return "fatal";
/*     */     }
/*     */     catch (UnauthorizedException ue)
/*     */     {
/* 178 */       setLoginAttributes();
/* 179 */       ServletActionContext.getRequest().setAttribute("jive.login.successURL", getPageURL());
/* 180 */       return "login";
/*     */     }
/*     */ 
/* 183 */     ServletActionContext.getRequest().setAttribute("forumID", "" + this.forumID);
/* 184 */     ServletActionContext.getRequest().setAttribute("threadID", "" + this.threadID);
/*     */ 
/* 187 */     if ("true".equals(getCancel())) {
/* 188 */       return "cancel";
/*     */     }
/*     */ 
/* 192 */     if ("transfer".equals(this.mode)) {
/*     */       try
/*     */       {
/* 195 */         this.rewardManager.rewardPoints(this.message, this.points);
/* 196 */         return "transfer_success";
/*     */       }
/*     */       catch (RewardException re)
/*     */       {
/* 200 */         addActionError(getText("rewards.error_general"));
/* 201 */         return "error";
/*     */       }
/*     */       catch (UnauthorizedException ue)
/*     */       {
/* 205 */         addActionError(getText("rewards.error_no_permission_message"));
/* 206 */         return "error";
/*     */       }
/*     */     }
/* 209 */     if ("assign".equals(this.mode))
/*     */     {
/*     */       try
/*     */       {
/* 213 */         this.rewardManager.transferPoints(this.thread, this.points);
/* 214 */         return "assign_success";
/*     */       }
/*     */       catch (RewardException re)
/*     */       {
/* 218 */         addActionError(getText("rewards.error_can_not_assing_more_than_max"));
/* 219 */         return "error";
/*     */       }
/*     */       catch (UnauthorizedException ue)
/*     */       {
/* 223 */         addActionError(getText("rewards.error_no_permission_topic"));
/* 224 */         return "error";
/*     */       }
/*     */     }
/* 227 */     if ("unassign".equals(this.mode)) {
/*     */       try
/*     */       {
/* 230 */         this.rewardManager.transferPoints(this.thread, -this.points);
/* 231 */         return "unassign_success";
/*     */       }
/*     */       catch (RewardException re)
/*     */       {
/* 235 */         addActionError(getText("rewards.error_unassign_failed"));
/* 236 */         return "error";
/*     */       }
/*     */       catch (UnauthorizedException ue)
/*     */       {
/* 240 */         addActionError(getText("rewards.error_no_permission_unassign_topic"));
/* 241 */         return "error";
/*     */       }
/*     */     }
/*     */ 
/* 245 */     return "input";
/*     */   }
/*     */ 
/*     */   protected boolean loadJiveObjects()
/*     */     throws UnauthorizedException
/*     */   {
/* 252 */     boolean success = false;
/*     */     try {
/* 254 */       if (this.messageID != -1L) {
/* 255 */         setMessage(getForumFactory().getMessage(this.messageID));
/* 256 */         setThreadID(getMessage().getForumThread().getID());
/*     */       }
/* 258 */       setThread(getForumFactory().getForumThread(this.threadID));
/* 259 */       setForum(getThread().getForum());
/* 260 */       setForumID(getForum().getID());
/*     */ 
/* 262 */       if ((this.messageID == -1L) && (this.thread != null)) {
/* 263 */         setMessage(this.thread.getRootMessage());
/*     */       }
/* 265 */       success = true;
/*     */     }
/*     */     catch (ForumThreadNotFoundException ftnfe) {
/* 268 */       addActionError(ftnfe.getMessage());
/*     */     }
/*     */     catch (ForumMessageNotFoundException fmnfe) {
/* 271 */       addActionError(fmnfe.getMessage());
/*     */     }
/*     */ 
/* 275 */     if (!isAuthor(this.thread.getRootMessage()))
/*     */     {
/* 277 */       throw new UnauthorizedException(getText("rewards.error_unauth_only_authors_can_assign"));
/*     */     }
/*     */ 
/* 280 */     this.rewardManager = getForumFactory().getRewardManager();
/*     */ 
/* 282 */     if ((this.mode == null) || ((!this.mode.equals("assign")) && (!this.mode.equals("unassign")) && (!this.mode.equals("transfer"))))
/*     */     {
/* 285 */       addActionError("Invalid mode");
/* 286 */       success = false;
/*     */     }
/*     */ 
/* 289 */     return success;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.RewardsAction
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.PresenceManager;
/*    */ import com.jivesoftware.base.Roster;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ 
/*    */ public class AddressBookAction extends ForumActionSupport
/*    */ {
/*    */   public Roster getRoster()
/*    */     throws UnauthorizedException
/*    */   {
/* 22 */     return getForumFactory().getPresenceManager().getRoster(getPageUser());
/*    */   }
/*    */ 
/*    */   public String execute() {
/* 26 */     if (getAuthToken().isAnonymous())
/* 27 */       return "login";
/*    */     try
/*    */     {
/* 30 */       getRoster();
/*    */     }
/*    */     catch (UnauthorizedException ue) {
/* 33 */       return "login";
/*    */     }
/*    */ 
/* 36 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AddressBookAction
 * JD-Core Version:    0.6.2
 */
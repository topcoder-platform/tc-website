/*    */ package com.jivesoftware.forum.action.util;
/*    */ 
/*    */ import com.jivesoftware.base.JiveGlobals;
/*    */ import com.jivesoftware.forum.ForumMessage;
/*    */ import com.jivesoftware.util.LocaleUtils;
/*    */ 
/*    */ public class Guest
/*    */ {
/*    */   private ForumMessage message;
/*    */ 
/*    */   public String getName()
/*    */   {
/* 33 */     if (this.message != null) {
/* 34 */       return this.message.getProperty("name");
/*    */     }
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */   public String getEmail()
/*    */   {
/* 43 */     if ((this.message != null) && 
/* 44 */       (!JiveGlobals.getJiveBooleanProperty("skin.default.alwaysHideGuestEmailAddresses"))) {
/* 45 */       return this.message.getProperty("email");
/*    */     }
/*    */ 
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */   public String getDisplay()
/*    */   {
/* 58 */     if (getName() != null) {
/* 59 */       return getName();
/*    */     }
/* 61 */     if (getEmail() != null) {
/* 62 */       return getEmail();
/*    */     }
/*    */ 
/* 65 */     return LocaleUtils.getLocalizedString("global.guest", JiveGlobals.getLocale());
/*    */   }
/*    */ 
/*    */   public ForumMessage getMessage()
/*    */   {
/* 74 */     return this.message;
/*    */   }
/*    */ 
/*    */   public void setMessage(ForumMessage message)
/*    */   {
/* 83 */     this.message = message;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.util.Guest
 * JD-Core Version:    0.6.2
 */
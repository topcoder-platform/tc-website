/*     */ package com.jivesoftware.forum.action.setup;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.ldap.LdapManager;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import com.opensymphony.xwork.ModelDriven;
/*     */ import com.opensymphony.xwork.Preparable;
/*     */ import java.util.Map;
/*     */ import javax.naming.AuthenticationException;
/*     */ import javax.naming.CommunicationException;
/*     */ import javax.naming.InvalidNameException;
/*     */ import javax.naming.directory.DirContext;
/*     */ 
/*     */ public class LdapUserSystemSetupAction extends SetupActionSupport
/*     */   implements ModelDriven, Preparable
/*     */ {
/*     */   private Parameters params;
/*     */ 
/*     */   public LdapUserSystemSetupAction()
/*     */   {
/*  25 */     this.params = new Parameters();
/*     */   }
/*     */ 
/*     */   public Object getModel()
/*     */   {
/*  30 */     return this.params;
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */   {
/*  36 */     LdapManager ldapManager = LdapManager.getInstance();
/*  37 */     this.params.ldapHost = ldapManager.getHost();
/*  38 */     this.params.ldapPort = ldapManager.getPort();
/*  39 */     this.params.usernameField = ldapManager.getUsernameField();
/*  40 */     this.params.nameField = ldapManager.getNameField();
/*  41 */     this.params.emailField = ldapManager.getEmailField();
/*  42 */     this.params.baseDN = ldapManager.getBaseDN();
/*  43 */     this.params.alternateBaseDN = ldapManager.getAlternateBaseDN();
/*  44 */     this.params.adminDN = ldapManager.getAdminDN();
/*  45 */     this.params.adminPassword = ldapManager.getAdminPassword();
/*  46 */     this.params.sslEnabled = ldapManager.isSslEnabled();
/*     */   }
/*     */ 
/*     */   public String doDefault() {
/*  50 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute() {
/*  54 */     DirContext context = null;
/*     */ 
/*  56 */     LdapManager ldapManager = LdapManager.getInstance();
/*     */     try
/*     */     {
/*  60 */       ldapManager.setHost(this.params.ldapHost);
/*  61 */       ldapManager.setPort(this.params.ldapPort);
/*  62 */       ldapManager.setUsernameField(this.params.usernameField);
/*  63 */       ldapManager.setNameField(this.params.nameField);
/*  64 */       ldapManager.setEmailField(this.params.emailField);
/*  65 */       ldapManager.setBaseDN(this.params.baseDN);
/*  66 */       ldapManager.setAlternateBaseDN(this.params.alternateBaseDN);
/*  67 */       ldapManager.setAdminDN(this.params.adminDN);
/*  68 */       ldapManager.setAdminPassword(this.params.adminPassword);
/*  69 */       ldapManager.setSslEnabled(this.params.sslEnabled);
/*     */ 
/*  73 */       for (int i = 0; i < 3; i++) {
/*  74 */         context = ldapManager.getContext();
/*  75 */         if (context != null) {
/*     */           break;
/*     */         }
/*     */         try
/*     */         {
/*  80 */           Log.error("Attempt " + (i + 1) + " to connect to the LDAP server failed.");
/*  81 */           Thread.sleep(500L);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*     */         }
/*     */       }
/*  87 */       if (context == null)
/*  88 */         throw new CommunicationException("Can't contact LDAP host");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  92 */       Log.error(e);
/*  93 */       if ((e instanceof CommunicationException)) {
/*  94 */         addActionError(getText("setup.error.ldap.communication"));
/*     */       }
/*  96 */       else if ((e instanceof InvalidNameException)) {
/*  97 */         addFieldError("baseDN", getText("setup.error.ldap.basedn_invalid"));
/*  98 */         addActionError(getText("setup.error.ldap.basedn_invalid_description"));
/*     */       }
/* 100 */       else if ((e instanceof AuthenticationException)) {
/* 101 */         addFieldError("password", getText("setup.error.ldap.password_error"));
/* 102 */         addActionError(getText("setup.error.ldap.password_error_description", e.getMessage()));
/*     */       }
/*     */       else {
/* 105 */         addActionError(getText("setup.error.ldap.password_error_general", e.getMessage()));
/*     */       }
/*     */     } finally {
/*     */       try {
/* 109 */         if (context != null) context.close(); 
/*     */       } catch (Exception e) { Log.error(e); }
/*     */ 
/*     */     }
/*     */ 
/* 114 */     if ((this.params.getAlternateBaseDN() != null) && (!hasErrors())) {
/*     */       try {
/* 116 */         context = ldapManager.getContext(this.params.alternateBaseDN);
/*     */       }
/*     */       catch (Exception e) {
/* 119 */         if ((e instanceof InvalidNameException)) {
/* 120 */           addFieldError("alternateBaseDN", getText("setup.error.ldap.alternatedn_invalid"));
/* 121 */           addActionError(getText("setup.error.ldap.alternatedn_invalid_description"));
/*     */         }
/*     */         else {
/* 124 */           addFieldError("alternateBaseDN", getText("setup.error.ldap.alternatedn_invalid"));
/* 125 */           addActionError(getText("setup.error.ldap.alternatedn_binding", e.getMessage()));
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 131 */     if (!hasErrors()) {
/* 132 */       JiveGlobals.setJiveProperty("UserManager.className", "com.jivesoftware.base.ldap.LdapUserManager");
/* 133 */       JiveGlobals.setJiveProperty("AuthFactory.className", "com.jivesoftware.base.ldap.LdapAuthFactory");
/*     */ 
/* 136 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/* 137 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/* 138 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "done");
/* 139 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "in_progress");
/* 140 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "incomplete");
/* 141 */       return "next";
/*     */     }
/*     */ 
/* 144 */     return "error"; } 
/*     */   class Parameters { private String ldapHost;
/* 149 */     private int ldapPort = 389;
/*     */     private String baseDN;
/*     */     private String alternateBaseDN;
/*     */     private String adminDN;
/*     */     private String adminPassword;
/* 154 */     private String usernameField = "uid";
/* 155 */     private String nameField = "cn";
/* 156 */     private String emailField = "mail";
/*     */     private boolean sslEnabled;
/*     */ 
/*     */     Parameters() {  } 
/* 160 */     public String getLdapHost() { return this.ldapHost; }
/*     */ 
/*     */     public void setLdapHost(String ldapHost)
/*     */     {
/* 164 */       this.ldapHost = ldapHost;
/*     */     }
/*     */ 
/*     */     public int getLdapPort() {
/* 168 */       return this.ldapPort;
/*     */     }
/*     */ 
/*     */     public void setLdapPort(int ldapPort) {
/* 172 */       this.ldapPort = ldapPort;
/*     */     }
/*     */ 
/*     */     public String getBaseDN() {
/* 176 */       return this.baseDN;
/*     */     }
/*     */ 
/*     */     public void setBaseDN(String baseDN) {
/* 180 */       this.baseDN = baseDN;
/*     */     }
/*     */ 
/*     */     public String getAlternateBaseDN() {
/* 184 */       return this.alternateBaseDN;
/*     */     }
/*     */ 
/*     */     public void setAlternateBaseDN(String alternateBaseDN) {
/* 188 */       this.alternateBaseDN = alternateBaseDN;
/*     */     }
/*     */ 
/*     */     public String getAdminDN() {
/* 192 */       return this.adminDN;
/*     */     }
/*     */ 
/*     */     public void setAdminDN(String adminDN) {
/* 196 */       this.adminDN = adminDN;
/*     */     }
/*     */ 
/*     */     public String getAdminPassword() {
/* 200 */       return this.adminPassword;
/*     */     }
/*     */ 
/*     */     public void setAdminPassword(String adminPassword) {
/* 204 */       this.adminPassword = adminPassword;
/*     */     }
/*     */ 
/*     */     public String getUsernameField() {
/* 208 */       return this.usernameField;
/*     */     }
/*     */ 
/*     */     public void setUsernameField(String usernameField) {
/* 212 */       this.usernameField = usernameField;
/*     */     }
/*     */ 
/*     */     public String getNameField() {
/* 216 */       return this.nameField;
/*     */     }
/*     */ 
/*     */     public void setNameField(String nameField) {
/* 220 */       this.nameField = nameField;
/*     */     }
/*     */ 
/*     */     public String getEmailField() {
/* 224 */       return this.emailField;
/*     */     }
/*     */ 
/*     */     public void setEmailField(String emailField) {
/* 228 */       this.emailField = emailField;
/*     */     }
/*     */ 
/*     */     public boolean isSslEnabled() {
/* 232 */       return this.sslEnabled;
/*     */     }
/*     */ 
/*     */     public void setSslEnabled(boolean sslEnabled) {
/* 236 */       this.sslEnabled = sslEnabled;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.LdapUserSystemSetupAction
 * JD-Core Version:    0.6.2
 */
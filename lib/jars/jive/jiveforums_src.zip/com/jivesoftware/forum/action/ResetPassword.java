/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ 
/*     */ public class ResetPassword extends ForumActionSupport
/*     */   implements Validateable
/*     */ {
/*     */   private String token;
/*     */   private long userid;
/*     */   private String newPassword;
/*     */   private String confirmNewPassword;
/*     */   private static final String JIVE_PASSWORDRESET_TOKEN = "jive.passwordreset.token";
/*     */   private static final String JIVE_PASSWORDRESET_TIMESTAMP = "jive.passwordreset.timestamp";
/*     */   private static final String JIVE_PASSWORDRESET_LAST_SENT = "jive.passwordreset.last_sent";
/*     */ 
/*     */   public String getToken()
/*     */   {
/*  50 */     return this.token;
/*     */   }
/*     */ 
/*     */   public void setToken(String token)
/*     */   {
/*  57 */     if ("".equals(token)) {
/*  58 */       token = null;
/*     */     }
/*  60 */     this.token = token;
/*     */   }
/*     */ 
/*     */   public long getUserid()
/*     */   {
/*  67 */     return this.userid;
/*     */   }
/*     */ 
/*     */   public void setUserid(long userid)
/*     */   {
/*  74 */     this.userid = userid;
/*     */   }
/*     */ 
/*     */   public String getNewPassword()
/*     */   {
/*  81 */     return this.newPassword;
/*     */   }
/*     */ 
/*     */   public void setNewPassword(String newPassword)
/*     */   {
/*  88 */     if (newPassword != null) {
/*  89 */       this.newPassword = newPassword.trim();
/*     */     }
/*     */     else
/*  92 */       this.newPassword = newPassword;
/*     */   }
/*     */ 
/*     */   public String getConfirmNewPassword()
/*     */   {
/* 100 */     return this.confirmNewPassword;
/*     */   }
/*     */ 
/*     */   public void setConfirmNewPassword(String confirmNewPassword)
/*     */   {
/* 107 */     if (confirmNewPassword != null) {
/* 108 */       this.confirmNewPassword = confirmNewPassword.trim();
/*     */     }
/*     */     else
/* 111 */       this.confirmNewPassword = confirmNewPassword;
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/* 129 */     int minPasswordSize = 4;
/*     */ 
/* 131 */     if (JiveGlobals.getJiveProperty("skin.default.minpasswordlength") != null) {
/*     */       try {
/* 133 */         minPasswordSize = Integer.parseInt(JiveGlobals.getJiveProperty("skin.default.minpasswordlength"));
/*     */       }
/*     */       catch (Exception ignored)
/*     */       {
/* 137 */         JiveGlobals.deleteJiveProperty("skin.default.minpasswordlength");
/*     */       }
/*     */     }
/*     */ 
/* 141 */     boolean errorPassword = false;
/* 142 */     boolean errorConfirmPassword = false;
/*     */ 
/* 144 */     if (this.userid < 2L) {
/* 145 */       addActionError(getText("resetpassword.error_message"));
/* 146 */       addFieldError("userid", getText("resetpassword.error_userid"));
/* 147 */       return;
/*     */     }
/* 149 */     if (this.token == null) {
/* 150 */       addFieldError("token", getText("resetpassword.error_token"));
/* 151 */       return;
/*     */     }
/*     */ 
/* 154 */     if ((this.newPassword == null) || (this.newPassword.length() < minPasswordSize)) {
/* 155 */       addActionError(getText("resetpassword.error_message"));
/* 156 */       addFieldError("newPassword", getText("resetpassword.error_password"));
/* 157 */       errorPassword = true;
/*     */     }
/* 159 */     if ((!errorPassword) && ((this.confirmNewPassword == null) || (this.confirmNewPassword.length() < minPasswordSize)))
/*     */     {
/* 162 */       addActionError(getText("resetpassword.error_message"));
/* 163 */       addFieldError("confirmNewPassword", getText("resetpassword.error_password"));
/* 164 */       errorConfirmPassword = true;
/*     */     }
/*     */ 
/* 167 */     if ((!errorPassword) && (!errorConfirmPassword) && 
/* 168 */       (!this.newPassword.equals(this.confirmNewPassword)))
/* 169 */       addActionError(getText("resetpassword.error_password_match"));
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 186 */     if (!isValidPasswordToken()) {
/* 187 */       addActionError(getText("resetpassword.error_token_message"));
/* 188 */       addFieldError("token", getText("resetpassword.error_token"));
/* 189 */       return "error";
/*     */     }
/*     */ 
/* 192 */     DbForumFactory dbfactory = null;
/* 193 */     UserManager userManager = null;
/* 194 */     User user = null;
/*     */     try
/*     */     {
/* 197 */       dbfactory = DbForumFactory.getInstance();
/* 198 */       userManager = dbfactory.getUserManager();
/* 199 */       user = userManager.getUser(this.userid);
/* 200 */       user.setPassword(this.newPassword);
/* 201 */       user.deleteProperty("jive.passwordreset.token");
/* 202 */       user.deleteProperty("jive.passwordreset.timestamp");
/* 203 */       user.deleteProperty("jive.passwordreset.last_sent");
/*     */     }
/*     */     catch (UserNotFoundException e) {
/* 206 */       addActionError(getText("resetpassword.error_token"));
/* 207 */       return "error";
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 210 */       Log.warn("Unable to reset user password, UnauthorizedException thrown");
/* 211 */       addActionError(getText("error.permission"));
/* 212 */       return "error";
/*     */     }
/*     */ 
/* 215 */     return "success";
/*     */   }
/*     */ 
/*     */   public String doDefault() {
/* 219 */     return "input";
/*     */   }
/*     */ 
/*     */   private boolean isValidPasswordToken()
/*     */   {
/* 232 */     String dbToken = null;
/* 233 */     String dbTimeStamp = null;
/* 234 */     DbForumFactory dbfactory = null;
/* 235 */     UserManager userManager = null;
/* 236 */     User user = null;
/* 237 */     long now = System.currentTimeMillis();
/* 238 */     long timeStamp = -1L;
/*     */     try
/*     */     {
/* 241 */       dbfactory = DbForumFactory.getInstance();
/* 242 */       userManager = dbfactory.getUserManager();
/* 243 */       user = userManager.getUser(this.userid);
/* 244 */       dbToken = user.getProperty("jive.passwordreset.token");
/* 245 */       dbTimeStamp = user.getProperty("jive.passwordreset.timestamp");
/*     */ 
/* 248 */       if ((dbToken == null) || (dbTimeStamp == null)) {
/* 249 */         return false;
/*     */       }
/*     */ 
/* 252 */       timeStamp = Long.valueOf(dbTimeStamp).longValue();
/*     */     }
/*     */     catch (UserNotFoundException e) {
/* 255 */       return false;
/*     */     }
/*     */ 
/* 259 */     if (now - timeStamp > 259200000L) {
/*     */       try {
/* 261 */         user.deleteProperty("jive.passwordreset.token");
/* 262 */         user.deleteProperty("jive.passwordreset.timestamp");
/* 263 */         user.deleteProperty("jive.passwordreset.last_sent");
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 266 */         Log.error("Unable to delete user password reset properties");
/*     */       }
/* 268 */       return false;
/*     */     }
/* 270 */     if (!dbToken.equals(this.token)) {
/* 271 */       return false;
/*     */     }
/* 273 */     if (user.getID() == 1L) {
/* 274 */       return false;
/*     */     }
/*     */ 
/* 277 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.ResetPassword
 * JD-Core Version:    0.6.2
 */
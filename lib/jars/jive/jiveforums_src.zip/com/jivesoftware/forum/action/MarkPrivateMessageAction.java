/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.PrivateMessage;
/*    */ import com.jivesoftware.forum.PrivateMessageManager;
/*    */ import com.jivesoftware.forum.PrivateMessageNotFoundException;
/*    */ 
/*    */ public class MarkPrivateMessageAction extends ForumActionSupport
/*    */ {
/*    */   public static final String READ = "read";
/*    */   public static final String UNREAD = "unread";
/* 25 */   private int folderID = 1;
/*    */   private String mark;
/*    */   private long[] messageID;
/*    */ 
/*    */   public String getMark()
/*    */   {
/* 30 */     return this.mark;
/*    */   }
/*    */ 
/*    */   public void setMark(String mark) {
/* 34 */     this.mark = mark;
/*    */   }
/*    */ 
/*    */   public int getFolderID() {
/* 38 */     return this.folderID;
/*    */   }
/*    */ 
/*    */   public void setFolderID(int folderID) {
/* 42 */     this.folderID = folderID;
/*    */   }
/*    */ 
/*    */   public long[] getMessageID() {
/* 46 */     return this.messageID;
/*    */   }
/*    */ 
/*    */   public void setMessageID(long[] messageID) {
/* 50 */     this.messageID = messageID;
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */   {
/* 56 */     if ((this.messageID == null) || (this.messageID.length == 0)) {
/* 57 */       addFieldError("messageID", "");
/* 58 */       return "error";
/*    */     }
/*    */ 
/* 62 */     PrivateMessageManager manager = getForumFactory().getPrivateMessageManager();
/*    */     try {
/* 64 */       for (int i = 0; i < this.messageID.length; i++) {
/*    */         try {
/* 66 */           PrivateMessage message = manager.getMessage(this.messageID[i]);
/* 67 */           if ("read".equals(getMark())) {
/* 68 */             message.setRead(true);
/*    */           }
/* 70 */           else if ("unread".equals(getMark()))
/* 71 */             message.setRead(false);
/*    */         }
/*    */         catch (PrivateMessageNotFoundException e)
/*    */         {
/* 75 */           e.printStackTrace();
/*    */         }
/*    */       }
/* 78 */       return "success";
/*    */     }
/*    */     catch (UnauthorizedException e) {
/* 81 */       addFieldError("unauthorized", "");
/* 82 */     }return "error";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.MarkPrivateMessageAction
 * JD-Core Version:    0.6.2
 */
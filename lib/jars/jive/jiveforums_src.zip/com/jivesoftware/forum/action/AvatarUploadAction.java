/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.AvatarException;
/*     */ import com.jivesoftware.forum.AvatarManager;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.image.AffineTransformOp;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.imageio.ImageIO;
/*     */ 
/*     */ public class AvatarUploadAction extends ForumActionSupport
/*     */   implements Validateable
/*     */ {
/*     */   private String imageName;
/*     */   private File image;
/*     */   private User user;
/*     */ 
/*     */   public void setImage(File image)
/*     */   {
/*  46 */     this.image = image;
/*     */   }
/*     */ 
/*     */   public void setImageFileName(String imageName)
/*     */   {
/*  55 */     this.imageName = imageName;
/*     */   }
/*     */ 
/*     */   protected void setUser(User user) {
/*  59 */     this.user = user;
/*     */   }
/*     */ 
/*     */   protected User getUser() {
/*  63 */     return this.user;
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/*  68 */     if (this.image == null)
/*     */     {
/*  70 */       addFieldError("image", getText("avatar.imagepath.error"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */     throws Exception
/*     */   {
/*  78 */     ForumFactory forumFactory = getForumFactory();
/*     */ 
/*  80 */     AvatarManager avatarManager = forumFactory.getAvatarManager();
/*  81 */     int maxAllowableHeight = avatarManager.getMaxAllowableHeight();
/*  82 */     int maxAllowableWidth = avatarManager.getMaxAllowableWidth();
/*  83 */     boolean isAllowImageResize = avatarManager.isAllowImageResize();
/*     */ 
/*  85 */     BufferedImage bufferedImage = ImageIO.read(this.image);
/*  86 */     int height = bufferedImage.getHeight();
/*  87 */     int width = bufferedImage.getWidth();
/*     */     AffineTransformOp op;
/*  91 */     if (!isAllowImageResize) {
/*  92 */       if ((height > maxAllowableHeight) && (width > maxAllowableWidth)) {
/*  93 */         List args = new ArrayList(2);
/*  94 */         args.add(new Integer(maxAllowableWidth));
/*  95 */         args.add(new Integer(maxAllowableHeight));
/*  96 */         addFieldError("image", getText("avatar.upload.error.dimensions", args));
/*  97 */         return "error";
/*     */       }
/*     */ 
/*     */     }
/* 102 */     else if ((width > maxAllowableWidth) || (height > maxAllowableHeight))
/*     */     {
/* 104 */       float wScale = maxAllowableWidth / width;
/* 105 */       float hScale = maxAllowableHeight / height;
/*     */ 
/* 108 */       float scale = Math.min(wScale, hScale);
/*     */ 
/* 110 */       if (scale > 1.0D) {
/* 111 */         scale = 1.0F;
/*     */       }
/* 113 */       wScale = scale;
/* 114 */       hScale = scale;
/*     */ 
/* 118 */       op = new AffineTransformOp(AffineTransform.getScaleInstance(wScale, hScale), 2);
/*     */       BufferedImage resizedImage;
/*     */       BufferedImage resizedImage;
/* 124 */       if ((bufferedImage.getColorModel() instanceof IndexColorModel)) {
/* 125 */         resizedImage = new BufferedImage((int)(bufferedImage.getWidth() * wScale), (int)(bufferedImage.getHeight() * hScale), bufferedImage.getType(), (IndexColorModel)bufferedImage.getColorModel());
/*     */       }
/*     */       else
/*     */       {
/* 130 */         resizedImage = new BufferedImage((int)(bufferedImage.getWidth() * wScale), (int)(bufferedImage.getHeight() * hScale), bufferedImage.getType());
/*     */       }
/*     */ 
/* 135 */       bufferedImage = op.filter(bufferedImage, resizedImage);
/*     */     }
/*     */ 
/* 141 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*     */     try {
/* 143 */       ImageIO.write(bufferedImage, "png", out);
/*     */     }
/*     */     finally {
/* 146 */       out.close();
/*     */     }
/*     */ 
/* 151 */     this.imageName = this.imageName.replaceAll("\\.[A-Za-z]*$", "\\.png");
/*     */ 
/* 154 */     InputStream in = new ByteArrayInputStream(out.toByteArray());
/*     */     try {
/*     */       try {
/* 157 */         avatarManager.createAvatar(this.user, this.imageName, "image/png", in);
/*     */       }
/*     */       catch (AvatarException e) {
/* 160 */         if (e.getType() == 1) {
/* 161 */           addFieldError("image", e.getCause().getMessage());
/* 162 */           return "error";
/*     */         }
/* 164 */         throw e;
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 169 */       in.close();
/*     */     }
/*     */ 
/* 173 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AvatarUploadAction
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.ForumMessage;
/*    */ import com.jivesoftware.forum.ForumThread;
/*    */ import com.jivesoftware.forum.Rating;
/*    */ import com.jivesoftware.forum.RatingManager;
/*    */ import com.jivesoftware.forum.RatingManagerFactory;
/*    */ 
/*    */ public class RatingAddAction extends ForumActionSupport
/*    */ {
/* 22 */   private long objectID = 0L;
/* 23 */   private int objectType = -1;
/*    */ 
/*    */   public long getObjectID() {
/* 26 */     return this.objectID;
/*    */   }
/*    */ 
/*    */   public void setObjectID(long objectID) {
/* 30 */     this.objectID = objectID;
/*    */   }
/*    */ 
/*    */   public int getObjectType() {
/* 34 */     return this.objectType;
/*    */   }
/*    */ 
/*    */   public void setObjectType(int objectType) {
/* 38 */     this.objectType = objectType;
/*    */   }
/*    */ 
/*    */   public String execute() throws Exception {
/* 42 */     RatingManager ratingManager = RatingManagerFactory.getInstance(getAuthToken());
/* 43 */     Rating rating = ratingManager.getRatingFromScore(1);
/* 44 */     if (this.objectType == 2) {
/* 45 */       ForumMessage message = getForumFactory().getMessage(this.objectID);
/* 46 */       if (!ratingManager.hasRated(getPageUser(), message))
/*    */       {
/* 50 */         ratingManager.addRating(getPageUser(), message, rating);
/*    */       }
/*    */     }
/* 53 */     else if (this.objectType == 1) {
/* 54 */       ForumThread thread = getForumFactory().getForumThread(this.objectID);
/* 55 */       if (!ratingManager.hasRated(getPageUser(), thread))
/*    */       {
/* 59 */         ratingManager.addRating(getPageUser(), thread, rating);
/*    */       }
/*    */     }
/* 62 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.RatingAddAction
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.Announcement;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class AnnounceExpireAction extends AnnounceAction
/*    */ {
/*    */   private boolean cancel;
/*    */ 
/*    */   public String isCancel()
/*    */   {
/* 19 */     return String.valueOf(this.cancel);
/*    */   }
/*    */ 
/*    */   public void setCancel(String cancel)
/*    */   {
/* 26 */     this.cancel = true;
/*    */   }
/*    */ 
/*    */   public String doDefault()
/*    */   {
/* 33 */     return "input";
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */   {
/* 44 */     if (this.cancel) {
/* 45 */       return "cancel";
/*    */     }
/*    */ 
/* 48 */     Announcement ann = getAnnouncement();
/*    */     try {
/* 50 */       ann.setEndDate(new Date());
/*    */     }
/*    */     catch (UnauthorizedException e) {
/* 53 */       return "unauthorized";
/*    */     }
/* 55 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AnnounceExpireAction
 * JD-Core Version:    0.6.2
 */
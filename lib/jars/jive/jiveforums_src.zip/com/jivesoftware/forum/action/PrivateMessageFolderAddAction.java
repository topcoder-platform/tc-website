/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.PrivateMessageManager;
/*    */ import com.opensymphony.xwork.Validateable;
/*    */ 
/*    */ public class PrivateMessageFolderAddAction extends ForumActionSupport
/*    */   implements Validateable
/*    */ {
/*    */   private String name;
/*    */ 
/*    */   public String getName()
/*    */   {
/* 21 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 25 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String doDefault() {
/* 29 */     if (!getForumFactory().getPrivateMessageManager().isPrivateMessagesEnabled()) {
/* 30 */       return "disabled";
/*    */     }
/* 32 */     return "input";
/*    */   }
/*    */ 
/*    */   public void validate() {
/* 36 */     if ((this.name == null) || ("".equals(this.name.trim())))
/* 37 */       addFieldError("name", "");
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */   {
/* 45 */     PrivateMessageManager manager = getForumFactory().getPrivateMessageManager();
/* 46 */     if (!manager.isPrivateMessagesEnabled()) {
/* 47 */       return "disabled";
/*    */     }
/*    */     try
/*    */     {
/* 51 */       manager.createFolder(getPageUser(), this.name);
/* 52 */       return "success";
/*    */     }
/*    */     catch (UnauthorizedException e) {
/* 55 */       addFieldError("unauthorized", "");
/* 56 */     }return "error";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PrivateMessageFolderAddAction
 * JD-Core Version:    0.6.2
 */
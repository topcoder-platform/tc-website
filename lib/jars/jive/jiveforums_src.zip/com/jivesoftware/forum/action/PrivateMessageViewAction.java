/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.PrivateMessage;
/*    */ import com.jivesoftware.forum.PrivateMessageFolder;
/*    */ import com.jivesoftware.forum.PrivateMessageManager;
/*    */ import com.jivesoftware.forum.PrivateMessageNotFoundException;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ 
/*    */ public class PrivateMessageViewAction extends ForumActionSupport
/*    */ {
/*    */   private long pmID;
/*    */   private PrivateMessage message;
/*    */   private PrivateMessage prevMessage;
/*    */   private PrivateMessage nextMessage;
/* 31 */   private boolean nextPrevLoaded = false;
/*    */   private Collection folders;
/*    */ 
/*    */   public long getPmID()
/*    */   {
/* 35 */     return this.pmID;
/*    */   }
/*    */ 
/*    */   public void setPmID(long pmID) {
/* 39 */     this.pmID = pmID;
/*    */   }
/*    */ 
/*    */   public PrivateMessage getMessage() {
/* 43 */     return this.message;
/*    */   }
/*    */ 
/*    */   public PrivateMessage getPreviousMessage() {
/* 47 */     loadNextPrevious();
/* 48 */     return this.prevMessage;
/*    */   }
/*    */ 
/*    */   public PrivateMessage getNextMessage() {
/* 52 */     loadNextPrevious();
/* 53 */     return this.nextMessage;
/*    */   }
/*    */ 
/*    */   public Collection getFolders() {
/* 57 */     return this.folders;
/*    */   }
/*    */ 
/*    */   public String execute() {
/* 61 */     if (getAuthToken().isAnonymous()) {
/* 62 */       return "login";
/*    */     }
/* 64 */     if (!getForumFactory().getPrivateMessageManager().isPrivateMessagesEnabled()) {
/* 65 */       return "disabled";
/*    */     }
/*    */ 
/*    */     try
/*    */     {
/* 70 */       this.message = getForumFactory().getPrivateMessageManager().getMessage(getPmID());
/*    */ 
/* 72 */       this.message.setRead(true);
/*    */ 
/* 74 */       this.folders = new LinkedList();
/* 75 */       Iterator iter = getForumFactory().getPrivateMessageManager().getFolders(getPageUser());
/* 76 */       while (iter.hasNext())
/* 77 */         this.folders.add(iter.next());
/*    */     }
/*    */     catch (UnauthorizedException e)
/*    */     {
/* 81 */       addFieldError("unauthorized", "");
/* 82 */       return "error";
/*    */     }
/*    */     catch (PrivateMessageNotFoundException e) {
/* 85 */       addFieldError("notfound", "");
/* 86 */       return "error";
/*    */     }
/* 88 */     return "success";
/*    */   }
/*    */ 
/*    */   private void loadNextPrevious()
/*    */   {
/* 93 */     if (!this.nextPrevLoaded)
/*    */     {
/* 96 */       PrivateMessage msg = getMessage();
/* 97 */       PrivateMessage prev = null;
/* 98 */       PrivateMessage next = null;
/* 99 */       Iterator messages = msg.getFolder().getMessages(0, 2147483647, 1000, true);
/*    */ 
/* 101 */       boolean prevSet = false;
/* 102 */       boolean nextSet = true;
/*    */ 
/* 104 */       while (messages.hasNext()) {
/* 105 */         PrivateMessage curr = (PrivateMessage)messages.next();
/*    */ 
/* 108 */         if ((msg.getID() != curr.getID()) && (!prevSet)) {
/* 109 */           prev = curr;
/*    */         }
/*    */ 
/* 113 */         if (!nextSet) {
/* 114 */           next = curr;
/* 115 */           nextSet = true;
/*    */         }
/*    */ 
/* 118 */         if (msg.getID() == curr.getID()) {
/* 119 */           prevSet = true;
/* 120 */           nextSet = false;
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 126 */       this.prevMessage = prev;
/* 127 */       this.nextMessage = next;
/* 128 */       this.nextPrevLoaded = true;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PrivateMessageViewAction
 * JD-Core Version:    0.6.2
 */
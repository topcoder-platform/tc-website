/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.PresenceManager;
/*     */ import com.jivesoftware.base.Roster;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class RosterAction extends ForumActionSupport
/*     */ {
/*     */   private String usernameToAdd;
/*     */   private String doAddUser;
/*     */   private String doDeleteUser;
/*     */ 
/*     */   public String getUsernameToAdd()
/*     */   {
/*  30 */     return this.usernameToAdd;
/*     */   }
/*     */ 
/*     */   public void setUsernameToAdd(String usernameToAdd) {
/*  34 */     this.usernameToAdd = usernameToAdd;
/*     */   }
/*     */ 
/*     */   public String getDoAddUser() {
/*  38 */     return this.doAddUser;
/*     */   }
/*     */ 
/*     */   public void setDoAddUser(String doAddUser) {
/*  42 */     if ((doAddUser != null) && (!"".equals(doAddUser)))
/*  43 */       this.doAddUser = doAddUser;
/*     */   }
/*     */ 
/*     */   public String getDoDeleteUser()
/*     */   {
/*  48 */     return this.doDeleteUser;
/*     */   }
/*     */ 
/*     */   public void setDoDeleteUser(String doDeleteUser) {
/*  52 */     if ((doDeleteUser != null) && (!"".equals(doDeleteUser)))
/*  53 */       this.doDeleteUser = doDeleteUser;
/*     */   }
/*     */ 
/*     */   public Roster getRoster()
/*     */   {
/*  60 */     if (getPageUser() != null) {
/*     */       try {
/*  62 */         return getForumFactory().getPresenceManager().getRoster(getPageUser());
/*     */       }
/*     */       catch (UnauthorizedException ue) {
/*  65 */         Log.error(ue);
/*     */       }
/*     */     }
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean getHasUsersInRoster() {
/*  72 */     Roster roster = getRoster();
/*     */     try {
/*  74 */       return (roster != null) && (roster.getUsers().hasNext());
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/*  77 */       Log.error(ue);
/*  78 */     }return false;
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*  91 */     ActionContext.getContext().getSession().put("jive.current.tab", "roster");
/*     */ 
/*  93 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 100 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.RosterAction
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ 
/*     */ public class EditAction extends PostAction
/*     */ {
/*     */   private boolean addComment;
/*     */   private String comment;
/*     */ 
/*     */   public boolean isAddComment()
/*     */   {
/*  29 */     return this.addComment;
/*     */   }
/*     */ 
/*     */   public void setAddComment(boolean addComment) {
/*  33 */     this.addComment = addComment;
/*     */   }
/*     */ 
/*     */   public String getComment() {
/*  37 */     return this.comment;
/*     */   }
/*     */ 
/*     */   public void setComment(String comment) {
/*  41 */     this.comment = comment;
/*     */   }
/*     */ 
/*     */   protected boolean isEdit()
/*     */   {
/*  50 */     return true;
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*     */     try
/*     */     {
/*  60 */       if (!loadJiveObjects())
/*  61 */         return "notfound";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/*  65 */       setLoginAttributes();
/*  66 */       addActionError(getText("edit.error_unauth"));
/*  67 */       return "login";
/*     */     }
/*     */ 
/*  70 */     if (!getCanEdit(getMessage())) {
/*  71 */       addActionError("You are not allowed to edit this message.");
/*  72 */       return "error";
/*     */     }
/*  74 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/*     */     try
/*     */     {
/*  83 */       if (!loadJiveObjects())
/*  84 */         return "notfound";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/*  88 */       setLoginAttributes();
/*  89 */       addActionError(getText("edit.error_unauth"));
/*  90 */       return "login";
/*     */     }
/*     */ 
/*  93 */     if ((getSubject() == null) || (getBody() == null)) {
/*  94 */       if (getSubject() == null) {
/*  95 */         addFieldError("subject", getText("post.error_subject"));
/*     */       }
/*  97 */       if (getBody() == null) {
/*  98 */         addFieldError("body", getText("post.error_body"));
/*     */       }
/*     */     }
/* 101 */     if (hasFieldErrors()) {
/* 102 */       return "error";
/*     */     }
/*     */ 
/* 106 */     if (!getCanEdit(getMessage())) {
/* 107 */       addActionError(getText("edit.not_allowed"));
/* 108 */       return "error";
/*     */     }
/*     */ 
/* 111 */     if ("true".equals(getDoCancel())) {
/* 112 */       return "cancel";
/*     */     }
/*     */     try
/*     */     {
/* 116 */       getMessage().setSubject(getSubject());
/*     */ 
/* 119 */       String msgBody = getBody();
/* 120 */       if (isAddComment()) {
/* 121 */         msgBody = msgBody + "\n\n" + getComment();
/*     */       }
/* 123 */       getMessage().setBody(msgBody);
/*     */ 
/* 126 */       if ((getMessageID() == -1L) && (getThread() != null)) {
/* 127 */         setMessageID(getThread().getRootMessage().getID());
/*     */       }
/* 129 */       return "success";
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 132 */       setLoginAttributes();
/* 133 */       addActionError(ue.getMessage());
/* 134 */     }return "login";
/*     */   }
/*     */ 
/*     */   protected boolean loadJiveObjects() throws UnauthorizedException
/*     */   {
/* 139 */     boolean success = true;
/*     */     try
/*     */     {
/* 143 */       setMessage(getForumFactory().getMessage(getMessageID()));
/* 144 */       setThread(getMessage().getForumThread());
/* 145 */       setForum(getThread().getForum());
/*     */ 
/* 147 */       setThreadID(getThread().getID());
/* 148 */       setForumID(getForum().getID());
/*     */     }
/*     */     catch (ForumMessageNotFoundException fmnfe) {
/* 151 */       success = false;
/* 152 */       addActionError(fmnfe.getMessage());
/*     */     }
/* 154 */     return success;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.EditAction
 * JD-Core Version:    0.6.2
 */
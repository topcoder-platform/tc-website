/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ProfileAction extends ForumActionSupport
/*     */ {
/*  27 */   private long userID = -1L;
/*     */   private String username;
/*     */   private User user;
/*     */ 
/*     */   public long getUserID()
/*     */   {
/*  42 */     return this.userID;
/*     */   }
/*     */ 
/*     */   public void setUserID(long userID)
/*     */   {
/*  51 */     this.userID = userID;
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/*  59 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/*  67 */     this.username = username;
/*     */   }
/*     */ 
/*     */   public User getUser()
/*     */   {
/*  78 */     return this.user;
/*     */   }
/*     */ 
/*     */   public Iterator getRecentMessages(int number)
/*     */   {
/*  88 */     if (number < 0) {
/*  89 */       throw new IllegalArgumentException("Number of recent messages must be greater than 0.");
/*     */     }
/*  91 */     ResultFilter resultFilter = ResultFilter.createDefaultUserMessagesFilter();
/*  92 */     resultFilter.setStartIndex(0);
/*  93 */     resultFilter.setNumResults(number);
/*  94 */     return getForumFactory().getUserMessages(getUser(), resultFilter);
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 105 */     if (!loadJiveObjects()) {
/* 106 */       return "error";
/*     */     }
/* 108 */     return "success";
/*     */   }
/*     */ 
/*     */   private boolean loadJiveObjects()
/*     */   {
/* 114 */     boolean success = false;
/*     */ 
/* 116 */     if (this.userID != -1L) {
/*     */       try {
/* 118 */         this.user = getForumFactory().getUserManager().getUser(this.userID);
/* 119 */         success = true;
/*     */       }
/*     */       catch (UserNotFoundException unfe) {
/* 122 */         List args = new ArrayList();
/* 123 */         args.add(new Long(this.userID));
/* 124 */         addActionError(getText("profile.error_userid", args));
/*     */       }
/*     */     }
/*     */ 
/* 128 */     if ((this.user == null) && (this.username != null)) {
/*     */       try {
/* 130 */         this.user = getForumFactory().getUserManager().getUser(this.username);
/* 131 */         success = true;
/*     */       }
/*     */       catch (UserNotFoundException unfe) {
/* 134 */         List args = new ArrayList();
/* 135 */         args.add(new Long(this.userID));
/* 136 */         addActionError(getText("profile.error_username", args));
/*     */       }
/*     */     }
/*     */ 
/* 140 */     if (this.user == null) {
/* 141 */       addActionError(getText("profile.error_user"));
/*     */     }
/* 143 */     return success;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.ProfileAction
 * JD-Core Version:    0.6.2
 */
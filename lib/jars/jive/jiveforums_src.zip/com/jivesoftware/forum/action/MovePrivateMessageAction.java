/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.PrivateMessage;
/*    */ import com.jivesoftware.forum.PrivateMessageFolder;
/*    */ import com.jivesoftware.forum.PrivateMessageFolderNotFoundException;
/*    */ import com.jivesoftware.forum.PrivateMessageManager;
/*    */ import com.jivesoftware.forum.PrivateMessageNotFoundException;
/*    */ 
/*    */ public class MovePrivateMessageAction extends ForumActionSupport
/*    */ {
/* 21 */   private int folderID = 1;
/*    */   private long[] messageID;
/*    */ 
/*    */   public int getFolderID()
/*    */   {
/* 25 */     return this.folderID;
/*    */   }
/*    */ 
/*    */   public void setFolderID(int folderID) {
/* 29 */     this.folderID = folderID;
/*    */   }
/*    */ 
/*    */   public long[] getMessageID() {
/* 33 */     return this.messageID;
/*    */   }
/*    */ 
/*    */   public void setMessageID(long[] messageID) {
/* 37 */     this.messageID = messageID;
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */   {
/* 42 */     if ((this.messageID == null) || (this.messageID.length == 0)) {
/* 43 */       addFieldError("messageID", "");
/* 44 */       return "error";
/*    */     }
/* 46 */     if (getPageUser() == null) {
/* 47 */       return "login";
/*    */     }
/*    */ 
/* 50 */     PrivateMessageManager manager = getForumFactory().getPrivateMessageManager();
/*    */     try
/*    */     {
/* 53 */       PrivateMessageFolder destFolder = manager.getFolder(getPageUser(), getFolderID());
/*    */ 
/* 56 */       if (destFolder.getID() == 4)
/*    */       {
/* 58 */         return "delete";
/*    */       }
/* 60 */       PrivateMessageFolder originFolder = null;
/* 61 */       for (int i = 0; i < this.messageID.length; i++) {
/*    */         try {
/* 63 */           PrivateMessage message = manager.getMessage(this.messageID[i]);
/* 64 */           originFolder = message.getFolder();
/* 65 */           originFolder.moveMessage(message, destFolder);
/*    */         }
/*    */         catch (PrivateMessageNotFoundException e)
/*    */         {
/* 69 */           e.printStackTrace();
/*    */         }
/*    */       }
/* 72 */       if (originFolder != null) {
/* 73 */         setFolderID(originFolder.getID());
/*    */       }
/*    */       else {
/* 76 */         setFolderID(this.folderID);
/*    */       }
/* 78 */       return "success";
/*    */     }
/*    */     catch (PrivateMessageFolderNotFoundException e) {
/* 81 */       addFieldError("folderID", "");
/* 82 */       return "error";
/*    */     }
/*    */     catch (UnauthorizedException e) {
/* 85 */       addFieldError("unauthorized", "");
/* 86 */     }return "error";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.MovePrivateMessageAction
 * JD-Core Version:    0.6.2
 */
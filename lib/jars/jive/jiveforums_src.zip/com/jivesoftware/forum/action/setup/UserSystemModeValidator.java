/*    */ package com.jivesoftware.forum.action.setup;
/*    */ 
/*    */ import com.jivesoftware.forum.Version;
/*    */ import com.jivesoftware.forum.Version.Edition;
/*    */ import com.opensymphony.xwork.validator.ValidationException;
/*    */ import com.opensymphony.xwork.validator.ValidatorContext;
/*    */ import com.opensymphony.xwork.validator.validators.FieldValidatorSupport;
/*    */ 
/*    */ public class UserSystemModeValidator extends FieldValidatorSupport
/*    */ {
/*    */   public void validate(Object object)
/*    */     throws ValidationException
/*    */   {
/* 25 */     String fieldName = getFieldName();
/* 26 */     ValidatorContext context = getValidatorContext();
/* 27 */     String mode = (String)getFieldValue(fieldName, object);
/*    */ 
/* 29 */     if ((!"standard".equals(mode)) && (!"custom".equals(mode)) && (!"ldap".equals(mode)))
/*    */     {
/* 33 */       context.addFieldError(fieldName, context.getText("setup.error.usersystem.invalid_mode"));
/*    */     }
/* 35 */     else if (("ldap".equals(mode)) && (Version.getEdition() != Version.Edition.ENTERPRISE) && (Version.getEdition() != Version.Edition.EXPERT))
/*    */     {
/* 38 */       context.addFieldError(fieldName, context.getText("setup.error.usersystem.not_enterprise"));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.UserSystemModeValidator
 * JD-Core Version:    0.6.2
 */
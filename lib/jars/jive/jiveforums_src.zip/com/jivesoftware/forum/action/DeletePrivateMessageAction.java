/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.PrivateMessage;
/*    */ import com.jivesoftware.forum.PrivateMessageFolder;
/*    */ import com.jivesoftware.forum.PrivateMessageManager;
/*    */ import com.jivesoftware.forum.PrivateMessageNotFoundException;
/*    */ 
/*    */ public class DeletePrivateMessageAction extends ForumActionSupport
/*    */ {
/* 24 */   private int folderID = 1;
/*    */   private long[] messageID;
/*    */ 
/*    */   public int getFolderID()
/*    */   {
/* 28 */     return this.folderID;
/*    */   }
/*    */ 
/*    */   public void setFolderID(int folderID) {
/* 32 */     this.folderID = folderID;
/*    */   }
/*    */ 
/*    */   public long[] getMessageID() {
/* 36 */     return this.messageID;
/*    */   }
/*    */ 
/*    */   public void setMessageID(long[] messageID) {
/* 40 */     this.messageID = messageID;
/*    */   }
/*    */ 
/*    */   public String execute() {
/* 44 */     if (getPageUser() == null) {
/* 45 */       return "login";
/*    */     }
/*    */ 
/* 48 */     if ((this.messageID == null) || (this.messageID.length == 0)) {
/* 49 */       addFieldError("messageID", "");
/* 50 */       return "error";
/*    */     }
/*    */ 
/* 53 */     PrivateMessageManager manager = getForumFactory().getPrivateMessageManager();
/*    */     try {
/* 55 */       for (int i = 0; i < this.messageID.length; i++) {
/*    */         try {
/* 57 */           PrivateMessage message = manager.getMessage(this.messageID[i]);
/*    */ 
/* 59 */           setFolderID(message.getFolder().getID());
/*    */ 
/* 61 */           message.getFolder().deleteMessage(message);
/*    */         }
/*    */         catch (PrivateMessageNotFoundException e)
/*    */         {
/* 65 */           e.printStackTrace();
/*    */         }
/*    */       }
/* 68 */       return "success";
/*    */     }
/*    */     catch (UnauthorizedException e) {
/* 71 */       addFieldError("unauthorized", "");
/* 72 */     }return "error";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.DeletePrivateMessageAction
 * JD-Core Version:    0.6.2
 */
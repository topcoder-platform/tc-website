/*      */ package com.jivesoftware.forum.action;
/*      */ 
/*      */ import com.jivesoftware.base.JiveGlobals;
/*      */ import com.jivesoftware.base.UnauthorizedException;
/*      */ import com.jivesoftware.base.User;
/*      */ import com.jivesoftware.forum.Attachment;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumFactory;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*      */ import com.jivesoftware.forum.ForumNotFoundException;
/*      */ import com.jivesoftware.forum.ForumThread;
/*      */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*      */ import com.jivesoftware.forum.MessageRejectedException;
/*      */ import com.jivesoftware.forum.WatchManager;
/*      */ import com.jivesoftware.forum.database.DatabaseCacheManager;
/*      */ import com.jivesoftware.forum.database.DbForumFactory;
/*      */ import com.jivesoftware.forum.util.SkinUtils;
/*      */ import com.jivesoftware.util.StringUtils;
/*      */ import com.opensymphony.webwork.ServletActionContext;
/*      */ import com.opensymphony.webwork.interceptor.SessionAware;
/*      */ import com.opensymphony.xwork.ActionContext;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ 
/*      */ public class PostAction extends ForumActionSupport
/*      */   implements SessionAware
/*      */ {
/*   37 */   private static long tempIDSequence = 1L;
/*      */   public static final String PREVIEW = "preview";
/*      */   public static final String ATTACH = "attach";
/*      */   public static final String SPELLCHECK = "spellcheck";
/*      */   public static final String REJECTED = "rejected";
/*      */   private static final String SESSION_MESSAGE_KEY = "jive.post.message";
/*      */   private Map session;
/*   60 */   private long forumID = -1L;
/*   61 */   private long threadID = -1L;
/*   62 */   private long messageID = -1L;
/*   63 */   private long tempAttachmentID = -1L;
/*      */   private String name;
/*      */   private String email;
/*      */   private String subject;
/*      */   private String body;
/*      */   private boolean reply;
/*      */   private boolean quote;
/*      */   private String from;
/*   71 */   private boolean markAsQuestion = false;
/*      */   private String resolution;
/*      */   private String assignPoints;
/*      */   private String tid;
/*      */   private Forum forum;
/*      */   private ForumThread thread;
/*      */   private ForumMessage message;
/*      */   private ForumMessage newMessage;
/*      */   private String doCancel;
/*      */   private String doAttach;
/*      */   private String doSpellCheck;
/*      */   private String doQuoteOriq;
/*      */   private String doPreview;
/*      */   private String doPost;
/*      */   private String doGoBack;
/* 1020 */   private boolean isNewMessageModerated = false;
/*      */ 
/*      */   public long getForumID()
/*      */   {
/*  101 */     return this.forumID;
/*      */   }
/*      */ 
/*      */   public void setForumID(long forumID)
/*      */   {
/*  110 */     this.forumID = forumID;
/*      */   }
/*      */ 
/*      */   public long getThreadID()
/*      */   {
/*  119 */     return this.threadID;
/*      */   }
/*      */ 
/*      */   public void setThreadID(long threadID)
/*      */   {
/*  128 */     this.threadID = threadID;
/*      */   }
/*      */ 
/*      */   public long getMessageID()
/*      */   {
/*  137 */     return this.messageID;
/*      */   }
/*      */ 
/*      */   public void setMessageID(long messageID)
/*      */   {
/*  146 */     this.messageID = messageID;
/*      */   }
/*      */ 
/*      */   public long getTempAttachmentID() {
/*  150 */     return this.tempAttachmentID;
/*      */   }
/*      */ 
/*      */   public void setTempAttachmentID(long tempAttachmentID) {
/*  154 */     this.tempAttachmentID = tempAttachmentID;
/*      */   }
/*      */ 
/*      */   public String getName()
/*      */   {
/*  164 */     return this.name;
/*      */   }
/*      */ 
/*      */   public void setName(String name)
/*      */   {
/*  173 */     if ((name != null) && (name.length() <= 75))
/*  174 */       this.name = name;
/*      */   }
/*      */ 
/*      */   public String getEmail()
/*      */   {
/*  185 */     return this.email;
/*      */   }
/*      */ 
/*      */   public void setEmail(String email)
/*      */   {
/*  194 */     this.email = email;
/*      */   }
/*      */ 
/*      */   public String getSubject()
/*      */   {
/*  203 */     return this.subject;
/*      */   }
/*      */ 
/*      */   public void setSubject(String subject)
/*      */   {
/*  213 */     if (subject != null) {
/*  214 */       subject = subject.trim();
/*  215 */       if ((!"".equals(subject)) && (subject.length() <= 255))
/*  216 */         this.subject = subject;
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getBody()
/*      */   {
/*  227 */     return this.body;
/*      */   }
/*      */ 
/*      */   public void setBody(String body)
/*      */   {
/*  236 */     if (body != null) {
/*  237 */       body = body.trim();
/*  238 */       if (!"".equals(body))
/*  239 */         this.body = body;
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getFrom()
/*      */   {
/*  250 */     return this.from;
/*      */   }
/*      */ 
/*      */   public void setFrom(String from)
/*      */   {
/*  259 */     if ((from != null) && (!"".equals(from.trim())))
/*  260 */       this.from = from;
/*      */   }
/*      */ 
/*      */   public boolean isMarkAsQuestion()
/*      */   {
/*  270 */     return this.markAsQuestion;
/*      */   }
/*      */ 
/*      */   public void setMarkAsQuestion(boolean markAsQuestion)
/*      */   {
/*  279 */     this.markAsQuestion = markAsQuestion;
/*      */   }
/*      */ 
/*      */   public String getResolution()
/*      */   {
/*  288 */     if (this.resolution == null)
/*      */     {
/*  290 */       return "unanswered";
/*      */     }
/*  292 */     return this.resolution;
/*      */   }
/*      */ 
/*      */   public void setResolution(String resolution)
/*      */   {
/*  301 */     if ((resolution != null) && (!"".equals(resolution)))
/*  302 */       this.resolution = resolution;
/*      */   }
/*      */ 
/*      */   public String getAssignPoints()
/*      */   {
/*  307 */     return this.assignPoints;
/*      */   }
/*      */ 
/*      */   public void setAssignPoints(String assignPoints) {
/*      */   }
/*      */ 
/*      */   public String getTid() {
/*  314 */     if (this.tid == null)
/*      */     {
/*  316 */       this.tid = ((String)ServletActionContext.getRequest().getAttribute("tid"));
/*  317 */       if (this.tid == null) {
/*  318 */         this.tid = String.valueOf(tempIDSequence++);
/*      */       }
/*      */     }
/*  321 */     return this.tid;
/*      */   }
/*      */ 
/*      */   public void setTid(String tid) {
/*  325 */     this.tid = tid;
/*      */   }
/*      */ 
/*      */   public boolean isReply()
/*      */   {
/*  337 */     return this.reply;
/*      */   }
/*      */ 
/*      */   public void setReply(boolean reply)
/*      */   {
/*  346 */     this.reply = reply;
/*      */   }
/*      */ 
/*      */   public boolean isQuote() {
/*  350 */     return this.quote;
/*      */   }
/*      */ 
/*      */   public void setQuote(boolean quote)
/*      */   {
/*  355 */     this.quote = quote;
/*      */   }
/*      */ 
/*      */   protected boolean isEdit()
/*      */   {
/*  365 */     return false;
/*      */   }
/*      */ 
/*      */   public Forum getForum()
/*      */   {
/*  376 */     return this.forum;
/*      */   }
/*      */ 
/*      */   public void setForum(Forum forum) {
/*  380 */     this.forum = forum;
/*      */   }
/*      */ 
/*      */   public ForumThread getThread()
/*      */   {
/*  390 */     return this.thread;
/*      */   }
/*      */ 
/*      */   protected void setThread(ForumThread thread) {
/*  394 */     this.thread = thread;
/*      */   }
/*      */ 
/*      */   public ForumMessage getMessage()
/*      */   {
/*  403 */     return this.message;
/*      */   }
/*      */ 
/*      */   public void setMessage(ForumMessage message)
/*      */   {
/*  412 */     this.message = message;
/*      */   }
/*      */ 
/*      */   public ForumMessage getNewMessage()
/*      */   {
/*  423 */     return this.newMessage;
/*      */   }
/*      */ 
/*      */   protected void setNewMessage(ForumMessage newMessage) {
/*  427 */     this.newMessage = newMessage;
/*  428 */     if ((this.assignPoints != null) && ("true".equals(this.assignPoints)))
/*  429 */       this.assignPoints = "true";
/*      */   }
/*      */ 
/*      */   public Iterator getAttachments()
/*      */   {
/*  439 */     return getAttachmentList().iterator();
/*      */   }
/*      */ 
/*      */   public int getAttachmentCount()
/*      */   {
/*  448 */     ForumMessage tempMessage = retrieveFromSession();
/*  449 */     int count = 0;
/*  450 */     if (tempMessage != null) {
/*  451 */       count = tempMessage.getAttachmentCount();
/*      */     }
/*  453 */     return count;
/*      */   }
/*      */ 
/*      */   private List getAttachmentList()
/*      */   {
/*  458 */     ForumMessage tempMessage = retrieveFromSession();
/*      */ 
/*  460 */     List attachments = new LinkedList();
/*  461 */     if (tempMessage != null)
/*      */     {
/*  463 */       for (Iterator iter = tempMessage.getAttachments(); iter.hasNext(); ) {
/*  464 */         attachments.add(iter.next());
/*      */       }
/*      */ 
/*  467 */       Collections.sort(attachments, new Comparator() {
/*      */         public int compare(Object obj1, Object obj2) {
/*  469 */           Attachment a1 = (Attachment)obj1;
/*  470 */           Attachment a2 = (Attachment)obj2;
/*  471 */           return a1.getName().toLowerCase().compareTo(a2.getName().toLowerCase());
/*      */         }
/*      */       });
/*      */     }
/*  475 */     return attachments;
/*      */   }
/*      */ 
/*      */   public ForumMessage getPreviewedMessage()
/*      */   {
/*  488 */     return retrieveFromSession();
/*      */   }
/*      */ 
/*      */   public String getReplySubject()
/*      */   {
/*  495 */     String replySubject = this.message.getUnfilteredSubject();
/*  496 */     if (!replySubject.startsWith("Re:")) {
/*  497 */       replySubject = "Re: " + replySubject;
/*      */     }
/*  499 */     replySubject = StringUtils.replace(replySubject, "\"", "&quot;");
/*  500 */     return replySubject;
/*      */   }
/*      */ 
/*      */   public String getDoCancel()
/*      */   {
/*  512 */     return this.doCancel;
/*      */   }
/*      */ 
/*      */   public void setDoCancel(String doCancel)
/*      */   {
/*  523 */     if ((doCancel != null) && (!"".equals(doCancel.trim())))
/*  524 */       this.doCancel = "true";
/*      */   }
/*      */ 
/*      */   protected String getDoAttach()
/*      */   {
/*  535 */     return this.doAttach;
/*      */   }
/*      */ 
/*      */   public void setDoAttach(String doAttach)
/*      */   {
/*  546 */     if ((doAttach != null) && (!"".equals(doAttach.trim())))
/*  547 */       this.doAttach = "true";
/*      */   }
/*      */ 
/*      */   protected String getDoSpellCheck()
/*      */   {
/*  558 */     return this.doSpellCheck;
/*      */   }
/*      */ 
/*      */   public void setDoSpellCheck(String doSpellCheck)
/*      */   {
/*  569 */     if ((doSpellCheck != null) && (!"".equals(doSpellCheck)))
/*  570 */       this.doSpellCheck = "true";
/*      */   }
/*      */ 
/*      */   public String getDoQuoteOriq()
/*      */   {
/*  575 */     return this.doQuoteOriq;
/*      */   }
/*      */ 
/*      */   public void setDoQuoteOriq(String doQuoteOriq)
/*      */   {
/*  582 */     if ((doQuoteOriq != null) && (!"".equals(doQuoteOriq.trim())))
/*  583 */       this.doQuoteOriq = "true";
/*      */   }
/*      */ 
/*      */   protected String getDoPreview()
/*      */   {
/*  594 */     return this.doPreview;
/*      */   }
/*      */ 
/*      */   public void setDoPreview(String doPreview)
/*      */   {
/*  605 */     if ((doPreview != null) && (!"".equals(doPreview.trim())))
/*  606 */       this.doPreview = "true";
/*      */   }
/*      */ 
/*      */   protected String getDoPost()
/*      */   {
/*  617 */     return this.doPost;
/*      */   }
/*      */ 
/*      */   public void setDoPost(String doPost)
/*      */   {
/*  628 */     if ((doPost != null) && (!"".equals(doPost.trim())))
/*  629 */       this.doPost = "true";
/*      */   }
/*      */ 
/*      */   public String getDoGoBack()
/*      */   {
/*  640 */     return this.doGoBack;
/*      */   }
/*      */ 
/*      */   public void setDoGoBack(String doGoBack)
/*      */   {
/*  649 */     if ((doGoBack != null) && (!"".equals(doGoBack.trim())))
/*  650 */       this.doGoBack = "true";
/*      */   }
/*      */ 
/*      */   public String doPost()
/*      */   {
/*  664 */     setDoPost("true");
/*      */ 
/*  666 */     return execute();
/*      */   }
/*      */ 
/*      */   public String doReply()
/*      */   {
/*  678 */     setReply(true);
/*      */ 
/*  680 */     return doDefault();
/*      */   }
/*      */ 
/*      */   public String doRemoveAttach() {
/*  684 */     ForumMessage tempMessage = retrieveFromSession();
/*  685 */     if (tempMessage != null) {
/*  686 */       Attachment removeable = null;
/*  687 */       for (Iterator attachments = tempMessage.getAttachments(); attachments.hasNext(); ) {
/*  688 */         Attachment a = (Attachment)attachments.next();
/*  689 */         if (a.getID() == this.tempAttachmentID) {
/*  690 */           removeable = a;
/*  691 */           break;
/*      */         }
/*      */       }
/*      */       try {
/*  695 */         tempMessage.deleteAttachment(removeable);
/*      */       }
/*      */       catch (Exception e) {
/*  698 */         return "error";
/*      */       }
/*      */     }
/*  701 */     ServletActionContext.getRequest().setAttribute("tid", getTid());
/*  702 */     ServletActionContext.getRequest().setAttribute("forumID", String.valueOf(getForumID()));
/*  703 */     ServletActionContext.getRequest().setAttribute("threadID", String.valueOf(getThreadID()));
/*  704 */     ServletActionContext.getRequest().setAttribute("messageID", String.valueOf(getMessageID()));
/*  705 */     ServletActionContext.getRequest().setAttribute("reply", String.valueOf(isReply()));
/*  706 */     loadToSession(tempMessage);
/*  707 */     if (isReply()) {
/*  708 */       return doReply();
/*      */     }
/*      */ 
/*  711 */     return doDefault();
/*      */   }
/*      */ 
/*      */   public boolean isShortTermQueryCacheEnabled()
/*      */   {
/*  721 */     return DbForumFactory.getInstance().getCacheManager().isShortTermQueryCacheEnabled();
/*      */   }
/*      */ 
/*      */   protected void validate()
/*      */   {
/*  733 */     if (!"true".equals(getDoAttach())) {
/*  734 */       if (this.subject == null) {
/*  735 */         addFieldError("subject", getText("post.error_subject"));
/*      */       }
/*  737 */       if (this.body == null) {
/*  738 */         addFieldError("body", getText("post.error_body"));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  743 */     if (hasErrors())
/*  744 */       addActionError(getText("post.error_general"));
/*      */   }
/*      */ 
/*      */   public String doDefault()
/*      */   {
/*      */     try
/*      */     {
/*  760 */       if (!loadJiveObjects())
/*  761 */         return "notfound";
/*      */     }
/*      */     catch (UnauthorizedException e)
/*      */     {
/*  765 */       setLoginAttributes();
/*  766 */       addActionError(getText("error.no_perm_to_post"));
/*  767 */       return "login";
/*      */     }
/*  769 */     if (!hasPostPermission()) {
/*  770 */       setLoginAttributes();
/*  771 */       addActionError(getText("error.no_perm_to_post"));
/*  772 */       return "login";
/*      */     }
/*      */ 
/*  775 */     if (isReply()) {
/*  776 */       if (isMessageModerationOn(this.forum)) {
/*  777 */         addActionMessage(getText("post.reply_moderate"));
/*      */       }
/*      */ 
/*      */     }
/*  781 */     else if (isThreadModerationOn(this.forum)) {
/*  782 */       addActionMessage(getText("post.reply_moderate"));
/*      */     }
/*      */ 
/*  786 */     boolean quoteAllowed = true;
/*  787 */     if (getFrom() != null) {
/*  788 */       ForumMessage tempMessage = retrieveFromSession();
/*  789 */       setName(tempMessage.getProperty("name"));
/*  790 */       setEmail(tempMessage.getProperty("email"));
/*  791 */       setSubject(tempMessage.getUnfilteredSubject());
/*  792 */       setBody(tempMessage.getUnfilteredBody());
/*  793 */       quoteAllowed = false;
/*      */     }
/*      */ 
/*  796 */     if ("true".equals(getDoPost())) {
/*  797 */       return execute();
/*      */     }
/*  799 */     if ((quoteAllowed) && (isQuote()) && (isReply()))
/*      */     {
/*  801 */       String pBody = this.message.getUnfilteredBody();
/*  802 */       if (pBody != null) {
/*  803 */         this.body = SkinUtils.quoteOriginal(pBody, "&gt; ", 54);
/*  804 */         this.body += "\n";
/*      */       }
/*      */     }
/*  807 */     return "input";
/*      */   }
/*      */ 
/*      */   public String execute()
/*      */   {
/*      */     try
/*      */     {
/*  825 */       if (!loadJiveObjects())
/*  826 */         return "notfound";
/*      */     }
/*      */     catch (UnauthorizedException e)
/*      */     {
/*  830 */       setLoginAttributes();
/*  831 */       addActionError(getText("error.no_perm_to_post"));
/*  832 */       return "login";
/*      */     }
/*  834 */     if (!hasPostPermission()) {
/*  835 */       setLoginAttributes();
/*  836 */       addActionError(getText("error.no_perm_to_post"));
/*  837 */       return "login";
/*      */     }
/*      */ 
/*  840 */     if (this.thread != null) {
/*  841 */       if ("true".equals(this.thread.getProperty("jive.archived"))) {
/*  842 */         addActionError(getText("thread.topic_archived_description"));
/*  843 */         return "error";
/*      */       }
/*  845 */       if ("true".equals(this.thread.getProperty("jive.locked"))) {
/*  846 */         addActionError(getText("thread.topic_locked_description"));
/*  847 */         return "error";
/*      */       }
/*      */     }
/*      */ 
/*  851 */     if ("true".equals(getDoCancel())) {
/*  852 */       cleanSession();
/*  853 */       return "cancel";
/*      */     }
/*      */ 
/*  856 */     if ("true".equals(getDoQuoteOriq())) {
/*  857 */       String pBody = this.message.getUnfilteredBody();
/*  858 */       if (pBody != null) {
/*  859 */         String tbody = SkinUtils.quoteOriginal(pBody, "&gt; ", 54);
/*  860 */         tbody = tbody + "\n";
/*  861 */         this.body = (tbody + (this.body != null ? this.body : ""));
/*      */       }
/*  863 */       return "input";
/*      */     }
/*      */ 
/*  866 */     if (getFrom() != null) {
/*  867 */       ForumMessage tempMessage = retrieveFromSession();
/*  868 */       if (tempMessage != null) {
/*  869 */         setName(tempMessage.getProperty("name"));
/*  870 */         setEmail(tempMessage.getProperty("email"));
/*  871 */         setSubject(tempMessage.getUnfilteredSubject());
/*  872 */         setBody(tempMessage.getUnfilteredBody());
/*      */       }
/*  874 */       if ((("preview".equals(getFrom())) || ("attach".equals(getFrom()))) && (!"true".equals(getDoPost())))
/*      */       {
/*  876 */         return "input";
/*      */       }
/*      */     }
/*      */ 
/*  880 */     validate();
/*  881 */     if (hasErrors()) {
/*  882 */       return "error";
/*      */     }
/*      */ 
/*  887 */     if (("true".equals(getDoPreview())) || ("true".equals(getDoAttach())) || ("true".equals(getDoSpellCheck()))) {
/*      */       try
/*      */       {
/*  890 */         ForumMessage tempMessage = retrieveFromSession();
/*  891 */         if (tempMessage == null) {
/*  892 */           if (getPageUser() != null) {
/*  893 */             tempMessage = getForum().createMessage(getPageUser());
/*      */           }
/*      */           else {
/*  896 */             tempMessage = getForum().createMessage();
/*      */           }
/*      */         }
/*  899 */         if ((getName() != null) && (!"".equals(getName()))) {
/*  900 */           tempMessage.setProperty("name", getName());
/*      */         }
/*  902 */         if ((getEmail() != null) && (!"".equals(getEmail()))) {
/*  903 */           tempMessage.setProperty("email", getEmail());
/*      */         }
/*  905 */         if (getSubject() != null) {
/*  906 */           tempMessage.setSubject(getSubject());
/*      */         }
/*  908 */         if (getBody() != null) {
/*  909 */           tempMessage.setBody(getBody());
/*      */         }
/*  911 */         loadToSession(tempMessage);
/*      */ 
/*  913 */         ServletActionContext.getRequest().setAttribute("tid", getTid());
/*  914 */         ServletActionContext.getRequest().setAttribute("forumID", String.valueOf(getForumID()));
/*      */ 
/*  916 */         if ("true".equals(getDoPreview())) {
/*  917 */           return "preview";
/*      */         }
/*  919 */         if ("true".equals(getDoAttach())) {
/*  920 */           if (getThreadID() == -1L) {
/*  921 */             ServletActionContext.getRequest().setAttribute("threadID", String.valueOf(-1L));
/*      */           }
/*      */ 
/*  924 */           if (getMessageID() == -1L) {
/*  925 */             ServletActionContext.getRequest().setAttribute("messageID", String.valueOf(-1L));
/*      */           }
/*      */ 
/*  928 */           ServletActionContext.getRequest().setAttribute("reply", String.valueOf(isReply()));
/*      */ 
/*  930 */           return "attach";
/*      */         }
/*      */ 
/*  934 */         return "spellcheck";
/*      */       }
/*      */       catch (UnauthorizedException ue)
/*      */       {
/*  938 */         setLoginAttributes();
/*  939 */         addActionError(ue.getMessage());
/*  940 */         return "login";
/*      */       }
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  946 */       createMessage();
/*      */     }
/*      */     catch (MessageRejectedException mje) {
/*  949 */       addActionError(mje.getMessage());
/*  950 */       return "rejected";
/*      */     }
/*      */     catch (UnauthorizedException ue) {
/*  953 */       setLoginAttributes();
/*  954 */       addActionError(ue.getMessage());
/*  955 */       return "login";
/*      */     }
/*      */ 
/*  959 */     if (hasErrors()) {
/*  960 */       return "error";
/*      */     }
/*      */ 
/*  964 */     cleanSession();
/*      */ 
/*  966 */     newMessageModerated(getNewMessage());
/*      */ 
/*  968 */     if (getNewMessageIsModerated()) {
/*  969 */       return "success-moderation";
/*      */     }
/*      */ 
/*  972 */     setThreadID(getNewMessage().getForumThread().getID());
/*      */ 
/*  974 */     if (isReply()) {
/*  975 */       setMessageID(getNewMessage().getID());
/*      */ 
/*  977 */       int numMessages = getNewMessage().getForumThread().getMessageCount();
/*  978 */       int messageRange = JiveGlobals.getJiveIntProperty("skin.default.defaultMessagesPerPage", 15);
/*  979 */       if (getPageUser() == null)
/*      */         try {
/*  981 */           messageRange = Integer.parseInt(getGuestProperty("jiveMessageRange"));
/*      */         }
/*      */         catch (Exception ignored)
/*      */         {
/*      */         }
/*      */       else
/*      */         try {
/*  988 */           messageRange = Integer.parseInt(getPageUser().getProperty("jiveMessageRange"));
/*      */         }
/*      */         catch (Exception ignored)
/*      */         {
/*      */         }
/*  993 */       if (numMessages <= messageRange) {
/*  994 */         ServletActionContext.getRequest().setAttribute("start", String.valueOf(0));
/*      */       }
/*      */       else
/*      */       {
/*  998 */         int start = (int)Math.floor(numMessages / messageRange);
/*      */ 
/* 1000 */         ServletActionContext.getRequest().setAttribute("start", String.valueOf(start * messageRange));
/*      */       }
/*      */ 
/* 1003 */       if (isShortTermQueryCacheEnabled()) {
/* 1004 */         return "success-new-message-stqc";
/*      */       }
/*      */ 
/* 1007 */       return "success-new-message";
/*      */     }
/*      */ 
/* 1011 */     return "success-new-topic";
/*      */   }
/*      */ 
/*      */   public boolean getNewMessageIsModerated()
/*      */   {
/* 1023 */     return this.isNewMessageModerated;
/*      */   }
/*      */ 
/*      */   private boolean newMessageModerated(ForumMessage msg) {
/* 1027 */     boolean isRoot = msg.getID() == msg.getForumThread().getRootMessage().getID();
/* 1028 */     if (isRoot) {
/* 1029 */       if (msg.getModerationValue() <= 0) {
/* 1030 */         this.isNewMessageModerated = true;
/*      */       }
/*      */ 
/*      */     }
/* 1034 */     else if (msg.getModerationValue() <= 0) {
/* 1035 */       this.isNewMessageModerated = true;
/*      */     }
/*      */ 
/* 1038 */     return this.isNewMessageModerated;
/*      */   }
/*      */ 
/*      */   protected void createMessage()
/*      */     throws UnauthorizedException, MessageRejectedException
/*      */   {
/* 1050 */     ForumMessage tempMessage = retrieveFromSession();
/* 1051 */     if (tempMessage == null) {
/* 1052 */       if (getPageUser() != null) {
/* 1053 */         tempMessage = getForum().createMessage(getPageUser());
/*      */       }
/*      */       else {
/* 1056 */         tempMessage = getForum().createMessage();
/*      */       }
/*      */     }
/* 1059 */     if ((getName() != null) && (!"".equals(getName()))) {
/* 1060 */       tempMessage.setProperty("name", getName());
/*      */     }
/* 1062 */     if ((getEmail() != null) && (!"".equals(getEmail()))) {
/* 1063 */       tempMessage.setProperty("email", getEmail());
/*      */     }
/* 1065 */     tempMessage.setSubject(getSubject());
/* 1066 */     tempMessage.setBody(getBody());
/*      */ 
/* 1069 */     if (JiveGlobals.getJiveBooleanProperty("skin.default.guiEditorEnabled", false)) {
/* 1070 */       tempMessage.setProperty("jive.contentType", "text/html");
/*      */     }
/*      */ 
/* 1074 */     if (!"false".equals(JiveGlobals.getJiveProperty("skin.default.trackIP"))) {
/* 1075 */       String ipAddress = ServletActionContext.getRequest().getRemoteAddr();
/* 1076 */       if (ipAddress != null) {
/* 1077 */         tempMessage.setProperty("IP", ipAddress);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1082 */     if (isReply()) {
/* 1083 */       getThread().addMessage(getMessage(), tempMessage);
/*      */     }
/*      */     else {
/* 1086 */       setThread(getForum().createThread(tempMessage));
/* 1087 */       getForum().addThread(getThread());
/*      */ 
/* 1090 */       tempMessage = getThread().getRootMessage();
/*      */     }
/*      */ 
/* 1093 */     setNewMessage(tempMessage);
/*      */ 
/* 1095 */     if (getPageUser() != null)
/*      */     {
/* 1097 */       User user = getPageUser();
/* 1098 */       boolean watchNewTopics = "true".equals(user.getProperty("jiveAutoWatchNewTopics"));
/* 1099 */       boolean watchReplies = "true".equals(user.getProperty("jiveAutoWatchReplies"));
/* 1100 */       WatchManager manager = getForumFactory().getWatchManager();
/* 1101 */       if (isReply()) {
/* 1102 */         if ((watchReplies) && (!manager.isWatched(user, getThread()))) {
/* 1103 */           manager.createWatch(user, getThread());
/*      */         }
/*      */ 
/*      */       }
/* 1107 */       else if ((watchNewTopics) && (!manager.isWatched(user, getThread())))
/* 1108 */         manager.createWatch(user, getThread());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected boolean loadJiveObjects()
/*      */     throws UnauthorizedException
/*      */   {
/* 1119 */     boolean success = true;
/*      */ 
/* 1121 */     if ((!isReply()) && (!isEdit())) {
/*      */       try {
/* 1123 */         this.forum = getForumFactory().getForum(this.forumID);
/*      */       }
/*      */       catch (ForumNotFoundException fnfe) {
/* 1126 */         success = false;
/* 1127 */         addActionError(fnfe.getMessage());
/*      */       }
/*      */     }
/*      */     else {
/* 1131 */       if (this.messageID != -1L) {
/*      */         try {
/* 1133 */           this.message = getForumFactory().getMessage(this.messageID);
/* 1134 */           this.thread = this.message.getForumThread();
/* 1135 */           this.threadID = this.thread.getID();
/*      */         }
/*      */         catch (ForumMessageNotFoundException ignored) {
/* 1138 */           success = false;
/*      */         }
/*      */       }
/* 1141 */       if (this.threadID != -1L) {
/*      */         try {
/* 1143 */           this.thread = getForumFactory().getForumThread(this.threadID);
/* 1144 */           this.threadID = this.thread.getID();
/* 1145 */           if (this.messageID == -1L) {
/* 1146 */             this.message = this.thread.getRootMessage();
/* 1147 */             this.messageID = this.message.getID();
/*      */           }
/*      */           else {
/*      */             try {
/* 1151 */               this.message = getForumFactory().getMessage(this.messageID);
/*      */ 
/* 1153 */               if (this.message.getForumThread().getID() != this.thread.getID()) {
/* 1154 */                 success = false;
/* 1155 */                 addActionError(getText("post.error_invalid_thread"));
/*      */               }
/*      */             }
/*      */             catch (ForumMessageNotFoundException fmnfe) {
/* 1159 */               success = false;
/* 1160 */               addActionError(fmnfe.getMessage());
/*      */             }
/*      */           }
/*      */         }
/*      */         catch (ForumThreadNotFoundException ftnfe) {
/* 1165 */           success = false;
/* 1166 */           addActionError(getText("post.error_invalid_thread"));
/*      */         }
/*      */       }
/*      */ 
/* 1170 */       if (this.thread != null) {
/* 1171 */         this.forum = this.thread.getForum();
/* 1172 */         this.forumID = this.forum.getID();
/* 1173 */         success = true;
/*      */       }
/*      */     }
/* 1176 */     return success;
/*      */   }
/*      */ 
/*      */   private boolean hasPostPermission()
/*      */   {
/* 1183 */     boolean hasPermission = false;
/*      */ 
/* 1185 */     if (this.forum.isAuthorized(576460752303424256L))
/*      */     {
/* 1188 */       hasPermission = true;
/*      */     }
/* 1190 */     else if (this.forum.isAuthorized(128L)) {
/* 1191 */       hasPermission = true;
/*      */     }
/* 1195 */     else if (isReply()) {
/* 1196 */       if (this.forum.isAuthorized(2L)) {
/* 1197 */         hasPermission = true;
/*      */       }
/*      */ 
/*      */     }
/* 1201 */     else if (this.forum.isAuthorized(4L)) {
/* 1202 */       hasPermission = true;
/*      */     }
/*      */ 
/* 1206 */     return hasPermission;
/*      */   }
/*      */ 
/*      */   protected void loadToSession(ForumMessage message)
/*      */   {
/* 1215 */     String key = "jive.post.message" + getSessionSuffix();
/*      */ 
/* 1218 */     this.session.put(key, message);
/*      */   }
/*      */ 
/*      */   protected ForumMessage retrieveFromSession()
/*      */   {
/* 1226 */     String key = "jive.post.message" + getSessionSuffix();
/*      */ 
/* 1229 */     ForumMessage message = (ForumMessage)this.session.get(key);
/* 1230 */     return message;
/*      */   }
/*      */ 
/*      */   protected void removeFromSession()
/*      */   {
/* 1238 */     String key = "jive.post.message" + getSessionSuffix();
/*      */ 
/* 1240 */     ActionContext.getContext().getSession().remove(key);
/*      */   }
/*      */ 
/*      */   protected void cleanSession() {
/* 1244 */     ArrayList removeables = new ArrayList();
/* 1245 */     Set keys = ActionContext.getContext().getSession().keySet();
/* 1246 */     for (Iterator iterator = keys.iterator(); iterator.hasNext(); ) {
/* 1247 */       String key = (String)iterator.next();
/* 1248 */       if (key.startsWith("jive.post.")) {
/* 1249 */         removeables.add(key);
/*      */       }
/*      */     }
/* 1252 */     for (int i = 0; i < removeables.size(); i++) {
/* 1253 */       String name = (String)removeables.get(i);
/* 1254 */       ActionContext.getContext().getSession().remove(name);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected String getSessionSuffix()
/*      */   {
/* 1260 */     StringBuffer suffixKey = new StringBuffer();
/* 1261 */     suffixKey.append(".").append(getForumID()).append(".").append(getThreadID()).append(".").append(getMessageID());
/*      */ 
/* 1263 */     suffixKey.append(".").append(getTid());
/* 1264 */     return suffixKey.toString();
/*      */   }
/*      */ 
/*      */   public String getToHex(String input, String encoding)
/*      */     throws UnsupportedEncodingException
/*      */   {
/* 1271 */     return StringUtils.encodeHex(input.getBytes(encoding));
/*      */   }
/*      */ 
/*      */   protected String getPartialURL() {
/* 1275 */     StringBuffer buf = new StringBuffer();
/* 1276 */     buf.append("forumID=").append(getForumID());
/* 1277 */     if (getThreadID() != -1L) {
/* 1278 */       buf.append("&threadID=").append(getThreadID());
/*      */     }
/* 1280 */     if (getMessageID() != -1L) {
/* 1281 */       buf.append("&messageID=").append(getMessageID());
/*      */     }
/* 1283 */     buf.append("&reply=").append(isReply());
/* 1284 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   public void setSession(Map session) {
/* 1288 */     this.session = session;
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PostAction
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.action.setup;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.opensymphony.webwork.interceptor.ServletRequestAware;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import com.opensymphony.xwork.ModelDriven;
/*     */ import com.opensymphony.xwork.Preparable;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class EmailSetupAction extends SetupActionSupport
/*     */   implements ModelDriven, Preparable, ServletRequestAware
/*     */ {
/*     */   private Parameters params;
/*     */   private HttpServletRequest request;
/*     */ 
/*     */   public EmailSetupAction()
/*     */   {
/*  26 */     this.params = new Parameters();
/*     */   }
/*     */ 
/*     */   public Object getModel()
/*     */   {
/*  32 */     return this.params;
/*     */   }
/*     */ 
/*     */   public void setServletRequest(HttpServletRequest request) {
/*  36 */     this.request = request;
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */   {
/*  42 */     if (JiveGlobals.getJiveProperty("mail.smtp.host") != null) {
/*  43 */       this.params.host = JiveGlobals.getJiveProperty("mail.smtp.host");
/*     */     }
/*  45 */     if (JiveGlobals.getJiveProperty("mail.smtp.port") != null) {
/*  46 */       String portProp = JiveGlobals.getJiveProperty("mail.smtp.port");
/*  47 */       if (portProp != null)
/*     */         try {
/*  49 */           this.params.port = Integer.parseInt(portProp);
/*     */         }
/*     */         catch (Exception ignored)
/*     */         {
/*     */         }
/*     */     }
/*  55 */     if (JiveGlobals.getJiveProperty("jiveURL") != null) {
/*  56 */       this.params.jiveURL = JiveGlobals.getJiveProperty("jiveURL");
/*     */     }
/*     */     else
/*     */     {
/*  60 */       String host = this.request.getServerName();
/*  61 */       int port = this.request.getServerPort();
/*  62 */       String path = this.request.getContextPath();
/*  63 */       StringBuffer buf = new StringBuffer("http://");
/*  64 */       buf.append(host);
/*  65 */       if (port != 80) {
/*  66 */         buf.append(":").append(port);
/*     */       }
/*  68 */       buf.append(path);
/*  69 */       this.params.jiveURL = buf.toString();
/*     */     }
/*     */ 
/*  72 */     if (JiveGlobals.getJiveProperty("skin.default.communityName") != null) {
/*  73 */       this.params.communityName = JiveGlobals.getJiveProperty("skin.default.communityName");
/*     */     }
/*     */     else
/*  76 */       this.params.communityName = "Support Forums";
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*  81 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/*  82 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/*  83 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "done");
/*  84 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "in_progress");
/*  85 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "incomplete");
/*  86 */     return "success";
/*     */   }
/*     */ 
/*     */   public String execute() {
/*  90 */     if ("true".equals(getDoContinue())) {
/*  91 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/*  92 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/*  93 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "done");
/*  94 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "done");
/*  95 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "in_progress");
/*  96 */       return "next";
/*     */     }
/*     */ 
/*  99 */     if (this.params.host != null) {
/* 100 */       JiveGlobals.setJiveProperty("mail.smtp.host", this.params.host);
/* 101 */       JiveGlobals.setJiveProperty("mail.smtp.port", "" + this.params.port);
/*     */     }
/*     */ 
/* 105 */     if (this.params.jiveURL.charAt(this.params.jiveURL.length() - 1) == '/') {
/* 106 */       this.params.jiveURL = this.params.jiveURL.substring(0, this.params.getJiveURL().length() - 1);
/*     */     }
/* 108 */     JiveGlobals.setJiveProperty("jiveURL", this.params.getJiveURL());
/* 109 */     JiveGlobals.setJiveProperty("skin.default.communityName", this.params.communityName);
/*     */ 
/* 111 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/* 112 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/* 113 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "done");
/* 114 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "done");
/* 115 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "in_progress");
/* 116 */     return "next"; } 
/*     */   class Parameters { private String host;
/* 121 */     private int port = 25;
/*     */     private String username;
/*     */     private String password;
/*     */     private String jiveURL;
/*     */     private String communityName;
/*     */ 
/*     */     Parameters() {  } 
/* 128 */     public String getHost() { return this.host; }
/*     */ 
/*     */     public void setHost(String host)
/*     */     {
/* 132 */       this.host = host;
/*     */     }
/*     */ 
/*     */     public int getPort() {
/* 136 */       return this.port;
/*     */     }
/*     */ 
/*     */     public void setPort(int port) {
/* 140 */       this.port = port;
/*     */     }
/*     */ 
/*     */     public String getUsername() {
/* 144 */       return this.username;
/*     */     }
/*     */ 
/*     */     public void setUsername(String username) {
/* 148 */       this.username = username;
/*     */     }
/*     */ 
/*     */     public String getPassword() {
/* 152 */       return this.password;
/*     */     }
/*     */ 
/*     */     public void setPassword(String password) {
/* 156 */       this.password = password;
/*     */     }
/*     */ 
/*     */     public String getJiveURL() {
/* 160 */       return this.jiveURL;
/*     */     }
/*     */ 
/*     */     public void setJiveURL(String jiveURL) {
/* 164 */       this.jiveURL = jiveURL;
/*     */     }
/*     */ 
/*     */     public String getCommunityName() {
/* 168 */       return this.communityName;
/*     */     }
/*     */ 
/*     */     public void setCommunityName(String communityName) {
/* 172 */       this.communityName = communityName;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.EmailSetupAction
 * JD-Core Version:    0.6.2
 */
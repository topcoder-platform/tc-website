/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.PrivateMessageFolder;
/*     */ import com.jivesoftware.forum.PrivateMessageFolderNotFoundException;
/*     */ import com.jivesoftware.forum.PrivateMessageManager;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ 
/*     */ public class PrivateMessageFolderEditAction extends ForumActionSupport
/*     */   implements Validateable
/*     */ {
/*     */   private int folderID;
/*     */   private String name;
/*     */   private String cancel;
/*     */   private PrivateMessageFolder folder;
/*     */ 
/*     */   public int getFolderID()
/*     */   {
/*  26 */     return this.folderID;
/*     */   }
/*     */ 
/*     */   public void setFolderID(int folderID) {
/*  30 */     this.folderID = folderID;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  34 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  38 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getCancel() {
/*  42 */     return this.cancel;
/*     */   }
/*     */ 
/*     */   public void setCancel(String cancel) {
/*  46 */     this.cancel = "true";
/*     */   }
/*     */ 
/*     */   public PrivateMessageFolder getFolder() {
/*  50 */     return this.folder;
/*     */   }
/*     */ 
/*     */   public String doDefault() {
/*  54 */     if ("true".equals(getCancel())) {
/*  55 */       return "cancel";
/*     */     }
/*  57 */     if (!getForumFactory().getPrivateMessageManager().isPrivateMessagesEnabled())
/*  58 */       return "disabled";
/*     */     try
/*     */     {
/*  61 */       this.folder = getForumFactory().getPrivateMessageManager().getFolder(getPageUser(), getFolderID());
/*     */     }
/*     */     catch (PrivateMessageFolderNotFoundException e)
/*     */     {
/*  65 */       addFieldError("folderID", "");
/*  66 */       return "error";
/*     */     }
/*     */     catch (UnauthorizedException e) {
/*  69 */       addFieldError("unauthorized", "");
/*  70 */       return "error";
/*     */     }
/*  72 */     return "input";
/*     */   }
/*     */ 
/*     */   public void validate() {
/*  76 */     if ((!"true".equals(getCancel())) && (
/*  77 */       (this.name == null) || ("".equals(this.name.trim()))))
/*  78 */       addFieldError("name", "");
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/*  87 */     if ("true".equals(getCancel())) {
/*  88 */       return "cancel";
/*     */     }
/*  90 */     PrivateMessageManager manager = getForumFactory().getPrivateMessageManager();
/*     */     try {
/*  92 */       this.folder = manager.getFolder(getPageUser(), getFolderID());
/*  93 */       this.folder.setName(getName());
/*  94 */       return "success";
/*     */     }
/*     */     catch (PrivateMessageFolderNotFoundException e) {
/*  97 */       addFieldError("folderID", "");
/*  98 */       return "error";
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 101 */       addFieldError("unauthorized", "");
/* 102 */     }return "error";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PrivateMessageFolderEditAction
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.JiveGlobals;
/*    */ 
/*    */ public class HelpAction extends ForumActionSupport
/*    */ {
/*    */   public static final String CUSTOM_HELP = "custom";
/*    */   private String helpURL;
/*    */ 
/*    */   public String getHelpURL()
/*    */   {
/* 31 */     return this.helpURL;
/*    */   }
/*    */ 
/*    */   public void setHelpURL(String helpURL) {
/* 35 */     this.helpURL = helpURL;
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */   {
/* 48 */     if ((this.helpURL == null) && (JiveGlobals.getJiveProperty("helpURL") != null)) {
/* 49 */       setHelpURL(JiveGlobals.getJiveProperty("helpURL"));
/* 50 */       return "custom";
/*    */     }
/* 52 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.HelpAction
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.PrivateMessage;
/*     */ import com.jivesoftware.forum.PrivateMessageManager;
/*     */ import com.jivesoftware.forum.PrivateMessageNotFoundException;
/*     */ import com.jivesoftware.forum.PrivateMessageRejectedException;
/*     */ import com.jivesoftware.forum.util.SkinUtils;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PrivateMessagePostAction extends ForumActionSupport
/*     */   implements Validateable
/*     */ {
/*     */   public static final String DRAFT = "draft";
/*     */   private long[] userID;
/*     */   private String to;
/*     */   private String subject;
/*     */   private String body;
/*     */   private String from;
/*     */   private boolean copyToSent;
/*     */   private boolean reply;
/*     */   private boolean forward;
/*  39 */   private long pmID = 0L;
/*     */   private String doCancel;
/*     */   private String doPost;
/*     */   private String doAttach;
/*     */   private String doSpell;
/*     */   private String doPreview;
/*     */   private String doDraft;
/*     */   private PrivateMessage parentMessage;
/*     */ 
/*     */   public long[] getUserID()
/*     */   {
/*  51 */     return this.userID;
/*     */   }
/*     */ 
/*     */   public void setUserID(long[] userID) {
/*  55 */     this.userID = userID;
/*     */   }
/*     */ 
/*     */   public String getTo() {
/*  59 */     return this.to;
/*     */   }
/*     */ 
/*     */   public void setTo(String to) {
/*  63 */     this.to = to;
/*     */   }
/*     */ 
/*     */   public String getSubject() {
/*  67 */     return this.subject;
/*     */   }
/*     */ 
/*     */   public void setSubject(String subject) {
/*  71 */     this.subject = subject;
/*     */   }
/*     */ 
/*     */   public String getBody() {
/*  75 */     return this.body;
/*     */   }
/*     */ 
/*     */   public void setBody(String body) {
/*  79 */     this.body = body;
/*     */   }
/*     */ 
/*     */   public String getFrom() {
/*  83 */     return this.from;
/*     */   }
/*     */ 
/*     */   public void setFrom(String from) {
/*  87 */     this.from = from;
/*     */   }
/*     */ 
/*     */   public boolean isCopyToSent() {
/*  91 */     return this.copyToSent;
/*     */   }
/*     */ 
/*     */   public void setCopyToSent(boolean copyToSent) {
/*  95 */     this.copyToSent = copyToSent;
/*     */   }
/*     */ 
/*     */   public boolean isReply() {
/*  99 */     return this.reply;
/*     */   }
/*     */ 
/*     */   public void setReply(boolean reply) {
/* 103 */     this.reply = reply;
/*     */   }
/*     */ 
/*     */   public boolean isForward() {
/* 107 */     return this.forward;
/*     */   }
/*     */ 
/*     */   public void setForward(boolean forward) {
/* 111 */     this.forward = forward;
/*     */   }
/*     */ 
/*     */   public long getPmID() {
/* 115 */     return this.pmID;
/*     */   }
/*     */ 
/*     */   public void setPmID(long pmID) {
/* 119 */     this.pmID = pmID;
/*     */   }
/*     */ 
/*     */   public String getDoCancel() {
/* 123 */     return this.doCancel;
/*     */   }
/*     */ 
/*     */   public void setDoCancel(String doCancel) {
/* 127 */     this.doCancel = "true";
/*     */   }
/*     */ 
/*     */   public String getDoPost() {
/* 131 */     return this.doPost;
/*     */   }
/*     */ 
/*     */   public void setDoPost(String doPost) {
/* 135 */     this.doPost = "true";
/*     */   }
/*     */ 
/*     */   public String getDoAttach() {
/* 139 */     return this.doAttach;
/*     */   }
/*     */ 
/*     */   public void setDoAttach(String doAttach) {
/* 143 */     this.doAttach = "true";
/*     */   }
/*     */ 
/*     */   public String getDoSpell() {
/* 147 */     return this.doSpell;
/*     */   }
/*     */ 
/*     */   public void setDoSpell(String doSpell) {
/* 151 */     this.doSpell = "true";
/*     */   }
/*     */ 
/*     */   public String getDoPreview() {
/* 155 */     return this.doPreview;
/*     */   }
/*     */ 
/*     */   public void setDoPreview(String doPreview) {
/* 159 */     this.doPreview = "true";
/*     */   }
/*     */ 
/*     */   public String getDoDraft() {
/* 163 */     return this.doDraft;
/*     */   }
/*     */ 
/*     */   public void setDoDraft(String doDraft) {
/* 167 */     this.doDraft = "true";
/*     */   }
/*     */ 
/*     */   public PrivateMessage getParentMessage() {
/* 171 */     return this.parentMessage;
/*     */   }
/*     */ 
/*     */   public String doDefault() {
/* 175 */     this.copyToSent = true;
/*     */ 
/* 177 */     if (getAuthToken().isAnonymous()) {
/* 178 */       return "login";
/*     */     }
/* 180 */     if (!getForumFactory().getPrivateMessageManager().isPrivateMessagesEnabled()) {
/* 181 */       return "disabled";
/*     */     }
/*     */ 
/* 185 */     long[] userIDs = getUserID();
/* 186 */     if ((userIDs != null) && (userIDs.length > 0)) {
/* 187 */       String toField = "";
/* 188 */       String sep = "";
/* 189 */       UserManager userManager = getForumFactory().getUserManager();
/* 190 */       for (int i = 0; i < userIDs.length; i++)
/*     */         try {
/* 192 */           User user = userManager.getUser(userIDs[i]);
/* 193 */           toField = toField + sep + user.getUsername();
/* 194 */           sep = ", ";
/*     */         }
/*     */         catch (Exception ignored) {
/*     */         }
/* 198 */       if (toField.length() > 0) {
/* 199 */         setTo(toField);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 204 */     if (getPmID() > 0L) {
/*     */       try
/*     */       {
/* 207 */         this.parentMessage = getForumFactory().getPrivateMessageManager().getMessage(getPmID());
/*     */ 
/* 210 */         if ("draft".equals(getFrom())) {
/* 211 */           setTo(this.parentMessage.getProperty("draft.to"));
/* 212 */           setSubject(this.parentMessage.getUnfilteredSubject());
/* 213 */           setBody(this.parentMessage.getUnfilteredBody());
/*     */         }
/*     */         else
/*     */         {
/* 218 */           if (getSubject() == null) {
/* 219 */             String prefix = "";
/* 220 */             String parentSubj = this.parentMessage.getUnfilteredSubject();
/* 221 */             if ((isReply()) && (!parentSubj.startsWith("Re: "))) {
/* 222 */               prefix = "Re: ";
/*     */             }
/* 224 */             else if ((isForward()) && (!parentSubj.startsWith("Fwd: "))) {
/* 225 */               prefix = "Fwd: ";
/*     */             }
/* 227 */             setSubject(prefix + this.parentMessage.getUnfilteredSubject());
/*     */           }
/*     */ 
/* 231 */           if ((getTo() == null) && (isReply())) {
/* 232 */             setTo(this.parentMessage.getSender().getUsername());
/*     */           }
/*     */ 
/* 235 */           if (getBody() == null) {
/* 236 */             String quotedBody = this.parentMessage.getUnfilteredBody();
/* 237 */             quotedBody = SkinUtils.quoteOriginal(quotedBody, "> ", 54);
/* 238 */             quotedBody = "\n\n\n" + quotedBody;
/* 239 */             setBody(quotedBody);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 244 */         addFieldError("unauthorized", "");
/* 245 */         return "error";
/*     */       }
/*     */       catch (PrivateMessageNotFoundException e) {
/* 248 */         addFieldError("notfound", "");
/* 249 */         return "error";
/*     */       }
/*     */     }
/* 252 */     return "input";
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/* 257 */     if ("true".equals(getDoCancel())) {
/* 258 */       return;
/*     */     }
/*     */ 
/* 261 */     if ((this.to == null) || ("".equals(this.to.trim()))) {
/* 262 */       addFieldError("to", "");
/*     */     }
/*     */     else
/*     */     {
/* 266 */       List usernames = new ArrayList();
/* 267 */       String[] unames = getTo().split(",");
/* 268 */       for (int i = 0; i < unames.length; i++) {
/* 269 */         String username = unames[i].trim();
/* 270 */         if (!usernames.contains(username)) {
/* 271 */           usernames.add(username);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 276 */       Collections.sort(usernames, new Comparator() {
/*     */         public int compare(Object o1, Object o2) {
/* 278 */           return ((String)o1).toLowerCase().compareTo(((String)o2).toLowerCase());
/*     */         }
/*     */       });
/* 283 */       List invalidUsernames = new ArrayList();
/* 284 */       UserManager manager = getForumFactory().getUserManager();
/* 285 */       for (int i = 0; i < usernames.size(); i++) {
/* 286 */         String username = (String)usernames.get(i);
/*     */         try {
/* 288 */           manager.getUser(username);
/*     */         }
/*     */         catch (UserNotFoundException e) {
/* 291 */           invalidUsernames.add(username);
/*     */         }
/*     */       }
/* 294 */       if (invalidUsernames.size() > 0) {
/* 295 */         StringBuffer display = new StringBuffer();
/* 296 */         String sep = "";
/* 297 */         for (int i = 0; i < invalidUsernames.size(); i++) {
/* 298 */           String username = (String)invalidUsernames.get(i);
/* 299 */           display.append(sep).append(username);
/* 300 */           sep = ", ";
/*     */         }
/* 302 */         addFieldError("to", display.toString());
/*     */       }
/*     */ 
/* 306 */       StringBuffer newTo = new StringBuffer();
/* 307 */       String sep = "";
/* 308 */       for (int i = 0; i < usernames.size(); i++) {
/* 309 */         newTo.append(sep).append(usernames.get(i));
/* 310 */         sep = ", ";
/*     */       }
/* 312 */       setTo(newTo.toString());
/*     */     }
/* 314 */     if ((this.subject == null) || ("".equals(this.subject.trim()))) {
/* 315 */       addFieldError("subject", "");
/*     */     }
/* 317 */     if ((this.body == null) || ("".equals(this.body.trim())))
/* 318 */       addFieldError("body", "");
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 323 */     if (getAuthToken().isAnonymous()) {
/* 324 */       return "login";
/*     */     }
/* 326 */     if (!getForumFactory().getPrivateMessageManager().isPrivateMessagesEnabled()) {
/* 327 */       return "disabled";
/*     */     }
/*     */ 
/* 330 */     if ("true".equals(getDoCancel())) {
/* 331 */       return "cancel";
/*     */     }
/*     */ 
/* 335 */     UserManager userManager = getForumFactory().getUserManager();
/*     */ 
/* 337 */     User sender = getPageUser();
/*     */     try
/*     */     {
/* 341 */       PrivateMessageManager manager = getForumFactory().getPrivateMessageManager();
/*     */ 
/* 343 */       if ("true".equals(getDoDraft())) {
/* 344 */         PrivateMessage message = null;
/* 345 */         if ("draft".equals(getFrom())) {
/*     */           try {
/* 347 */             message = manager.getMessage(getPmID());
/*     */           }
/*     */           catch (PrivateMessageNotFoundException e) {
/* 350 */             addFieldError("draftNotFound", "");
/* 351 */             return "error";
/*     */           }
/*     */         }
/*     */         else {
/* 355 */           message = manager.createMessage(sender);
/*     */         }
/* 357 */         message.setSubject(getSubject());
/* 358 */         message.setBody(getBody());
/* 359 */         message.setProperty("draft.to", getTo());
/*     */         try {
/* 361 */           manager.saveMessageAsDraft(message);
/*     */         }
/*     */         catch (PrivateMessageRejectedException pmre) {
/* 364 */           int type = pmre.getRejectionType();
/* 365 */           addFieldError("messageRejected", String.valueOf(type));
/* 366 */           return "error";
/*     */         }
/* 368 */         return "success-saveasdraft";
/*     */       }
/*     */ 
/* 372 */       List invalidUsernames = new ArrayList();
/* 373 */       String[] usernames = getTo().split(", ");
/* 374 */       for (int i = 0; i < usernames.length; i++) {
/* 375 */         String username = usernames[i];
/*     */         try {
/* 377 */           PrivateMessage message = null;
/* 378 */           if ("draft".equals(getFrom())) {
/*     */             try {
/* 380 */               message = manager.getMessage(getPmID());
/*     */             }
/*     */             catch (PrivateMessageNotFoundException e) {
/* 383 */               addFieldError("draftNotFound", "");
/* 384 */               return "error";
/*     */             }
/*     */           }
/*     */           else {
/* 388 */             message = manager.createMessage(sender);
/*     */           }
/* 390 */           message.setSubject(getSubject());
/* 391 */           message.setBody(getBody());
/* 392 */           User recipient = userManager.getUser(username);
/*     */           try {
/* 394 */             manager.sendMessage(message, recipient, isCopyToSent());
/*     */           }
/*     */           catch (UnauthorizedException e) {
/* 397 */             addFieldError("unauthorized", "");
/* 398 */             return "error";
/*     */           }
/*     */           catch (PrivateMessageRejectedException e) {
/* 401 */             int type = e.getRejectionType();
/* 402 */             addFieldError("messageRejected", String.valueOf(type));
/* 403 */             return "error";
/*     */           }
/*     */         }
/*     */         catch (UserNotFoundException e) {
/* 407 */           invalidUsernames.add(username);
/*     */         }
/*     */       }
/* 410 */       if ((usernames.length > 0) && (invalidUsernames.size() == 0)) {
/* 411 */         return "success";
/*     */       }
/*     */ 
/* 415 */       if (invalidUsernames.size() > 0) {
/* 416 */         StringBuffer usernameList = new StringBuffer();
/* 417 */         String sep = "";
/* 418 */         for (int i = 0; i < invalidUsernames.size(); i++) {
/* 419 */           usernameList.append(sep).append(invalidUsernames.get(i));
/* 420 */           sep = ", ";
/*     */         }
/* 422 */         addFieldError("invalidUsernames", usernameList.toString());
/*     */       }
/* 424 */       return "success";
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 427 */       addFieldError("unauthorized", "");
/* 428 */     }return "error";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PrivateMessagePostAction
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.action.JiveObjectLoader;
/*     */ import com.jivesoftware.base.action.util.RedirectAction;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadIterator;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.action.util.Pageable;
/*     */ import com.opensymphony.webwork.ServletActionContext;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class ForumThreadAction extends ForumAction
/*     */   implements Pageable, JiveObjectLoader
/*     */ {
/*     */   public static final String THREAD_THREADED = "success-threaded";
/*     */   public static final String THREAD_FLAT = "success-flat";
/*     */   public static final String THREAD_TREE = "success-tree";
/*     */   public static final String DEFAULT_THREAD_MODE = "success-flat";
/*  54 */   private long threadID = 0L;
/*  55 */   private long messageID = 0L;
/*     */   private Integer start;
/*     */   private Integer tstart;
/*     */   private ForumThread thread;
/*     */   private ForumMessage message;
/*     */   private ForumThread previousThread;
/*     */   private ForumThread nextThread;
/*     */   private ResultFilter resultFilter;
/*     */   private ResultFilter nextPrevFilter;
/*  67 */   private boolean nextPrevThreadsLoaded = false;
/*     */   private String threadMode;
/*  69 */   private boolean stqc = false;
/*     */ 
/*     */   public long getThreadID()
/*     */   {
/*  79 */     return this.threadID;
/*     */   }
/*     */ 
/*     */   public void setThreadID(long threadID)
/*     */   {
/*  88 */     this.threadID = threadID;
/*     */   }
/*     */ 
/*     */   public long getMessageID()
/*     */   {
/*  97 */     return this.messageID;
/*     */   }
/*     */ 
/*     */   public void setMessageID(long messageID)
/*     */   {
/* 106 */     this.messageID = messageID;
/*     */   }
/*     */ 
/*     */   public int getStart()
/*     */   {
/* 116 */     if (this.start == null) {
/* 117 */       this.start = new Integer(0);
/*     */     }
/* 119 */     return this.start.intValue();
/*     */   }
/*     */ 
/*     */   public void setStart(int start)
/*     */   {
/* 128 */     this.start = new Integer(start);
/*     */   }
/*     */ 
/*     */   public int getTstart()
/*     */   {
/* 137 */     if (this.tstart == null) {
/* 138 */       return 0;
/*     */     }
/*     */ 
/* 141 */     return this.tstart.intValue();
/*     */   }
/*     */ 
/*     */   public void setTstart(int tstart)
/*     */   {
/* 151 */     this.tstart = new Integer(tstart);
/*     */   }
/*     */ 
/*     */   public int getNextTstart()
/*     */   {
/* 160 */     return getTstart() + 1;
/*     */   }
/*     */ 
/*     */   public int getPrevTstart()
/*     */   {
/* 168 */     return getTstart() - 1;
/*     */   }
/*     */ 
/*     */   public int getTotalItemCount()
/*     */   {
/* 178 */     return this.thread.getMessageCount(getResultFilter());
/*     */   }
/*     */ 
/*     */   public ForumThread getThread()
/*     */   {
/* 189 */     return this.thread;
/*     */   }
/*     */ 
/*     */   protected void setThread(ForumThread thread)
/*     */   {
/* 198 */     this.thread = thread;
/*     */   }
/*     */ 
/*     */   public ForumMessage getMessage()
/*     */   {
/* 209 */     return this.message;
/*     */   }
/*     */ 
/*     */   public void setMessage(ForumMessage message)
/*     */   {
/* 218 */     this.message = message;
/*     */   }
/*     */ 
/*     */   public Iterator getMessages()
/*     */   {
/* 231 */     return getThread().getMessages(getResultFilter());
/*     */   }
/*     */ 
/*     */   public ResultFilter getResultFilter()
/*     */   {
/* 248 */     if (this.resultFilter == null) {
/* 249 */       this.resultFilter = getMessageResultFilter();
/*     */     }
/* 251 */     return this.resultFilter;
/*     */   }
/*     */ 
/*     */   public void setResultFilter(ResultFilter filter)
/*     */   {
/* 265 */     this.resultFilter = filter;
/* 266 */     setMessageResultFilter(this.resultFilter);
/*     */   }
/*     */ 
/*     */   public boolean hasPreviousThread()
/*     */   {
/* 276 */     return getPreviousThread() != null;
/*     */   }
/*     */ 
/*     */   public ForumThread getPreviousThread()
/*     */   {
/* 287 */     if (this.previousThread == null) {
/* 288 */       loadNextPrevThreads();
/*     */     }
/* 290 */     return this.previousThread;
/*     */   }
/*     */ 
/*     */   public boolean hasNextThread()
/*     */   {
/* 301 */     return getNextThread() != null;
/*     */   }
/*     */ 
/*     */   public ForumThread getNextThread()
/*     */   {
/* 312 */     if (this.nextThread == null) {
/* 313 */       loadNextPrevThreads();
/*     */     }
/* 315 */     return this.nextThread;
/*     */   }
/*     */ 
/*     */   public boolean isArchived()
/*     */   {
/* 324 */     return "true".equals(this.thread.getProperty("jive.archived"));
/*     */   }
/*     */ 
/*     */   public boolean isLocked()
/*     */   {
/* 333 */     return "true".equals(this.thread.getProperty("jive.locked"));
/*     */   }
/*     */ 
/*     */   public boolean isRootMessage(ForumMessage msg)
/*     */   {
/* 345 */     return this.thread.getRootMessage().getID() == msg.getID();
/*     */   }
/*     */ 
/*     */   public String getThreadMode()
/*     */   {
/* 356 */     if (this.threadMode == null) {
/* 357 */       String threadModeProp = JiveGlobals.getJiveProperty("skin.default.threadMode", "success-flat");
/*     */ 
/* 360 */       User user = getPageUser();
/* 361 */       if ((user != null) && (JiveGlobals.getJiveBooleanProperty("skin.default.usersChooseThreadMode", false)))
/*     */       {
/* 364 */         if (user.getProperty("jiveThreadMode") != null) {
/* 365 */           threadModeProp = user.getProperty("jiveThreadMode");
/*     */         }
/*     */       }
/* 368 */       if ("threaded".equals(threadModeProp)) {
/* 369 */         this.threadMode = "success-threaded";
/*     */       }
/* 371 */       else if ("tree".equals(threadModeProp)) {
/* 372 */         this.threadMode = "success-tree";
/*     */       }
/*     */       else {
/* 375 */         this.threadMode = "success-flat";
/*     */       }
/*     */     }
/* 378 */     return this.threadMode;
/*     */   }
/*     */ 
/*     */   public boolean isStqc() {
/* 382 */     return this.stqc;
/*     */   }
/*     */ 
/*     */   public void setStqc(boolean stqc) {
/* 386 */     this.stqc = stqc;
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */     throws Exception
/*     */   {
/* 398 */     RedirectAction.pushPreviousURL(ServletActionContext.getRequest());
/*     */ 
/* 401 */     return getThreadMode();
/*     */   }
/*     */ 
/*     */   public String loadObjects()
/*     */     throws Exception
/*     */   {
/* 409 */     if ((this.threadID <= 0L) && (this.messageID <= 0L)) {
/* 410 */       addFieldError("threadID", String.valueOf(this.threadID));
/* 411 */       return "notfound";
/*     */     }
/*     */ 
/* 415 */     if (this.messageID > 0L) {
/*     */       try {
/* 417 */         this.message = getForumFactory().getMessage(this.messageID);
/* 418 */         this.thread = this.message.getForumThread();
/* 419 */         this.threadID = this.thread.getID();
/*     */       }
/*     */       catch (ForumMessageNotFoundException e) {
/* 422 */         addFieldError("messageID", String.valueOf(this.messageID));
/* 423 */         return "notfound";
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 426 */         addFieldError("messageID", String.valueOf(this.messageID));
/* 427 */         return "unauthorized";
/*     */       }
/*     */     }
/* 430 */     if ((this.thread == null) && (this.threadID > 0L)) {
/*     */       try {
/* 432 */         this.thread = getForumFactory().getForumThread(this.threadID);
/*     */ 
/* 434 */         this.message = this.thread.getRootMessage();
/* 435 */         this.messageID = this.message.getID();
/*     */       }
/*     */       catch (ForumThreadNotFoundException e) {
/* 438 */         addFieldError("threadID", String.valueOf(this.threadID));
/* 439 */         return "notfound";
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 442 */         addFieldError("threadID", String.valueOf(this.threadID));
/* 443 */         return "unauthorized";
/*     */       }
/*     */     }
/*     */ 
/* 447 */     setForum(this.thread.getForum());
/* 448 */     setForumID(getForum().getID());
/*     */ 
/* 454 */     if ((this.start == null) && (!JiveGlobals.getJiveBooleanProperty("skin.default.disableMessageScan", false)))
/*     */     {
/* 458 */       if (this.message.getID() == this.thread.getRootMessage().getID()) {
/* 459 */         setStart(0);
/*     */       }
/*     */       else {
/* 462 */         boolean foundMessage = false;
/* 463 */         int index = 0;
/* 464 */         int messageRange = JiveGlobals.getJiveIntProperty("skin.default.defaultMessagesPerPage", 15);
/*     */ 
/* 466 */         if (getPageUser() == null)
/*     */           try {
/* 468 */             messageRange = Integer.parseInt(getGuestProperty("jiveMessageRange"));
/*     */           }
/*     */           catch (Exception ignored) {
/*     */           }
/*     */         else try {
/* 473 */             messageRange = Integer.parseInt(getPageUser().getProperty("jiveMessageRange"));
/*     */           }
/*     */           catch (Exception ignored)
/*     */           {
/*     */           }
/*     */ 
/*     */ 
/* 483 */         ResultFilter filter = getResultFilter();
/* 484 */         filter.setNumResults(2147483524);
/* 485 */         Iterator messages = this.thread.getMessages(filter);
/* 486 */         while (messages.hasNext()) {
/* 487 */           ForumMessage msg = (ForumMessage)messages.next();
/* 488 */           if (msg.getID() != this.messageID) {
/* 489 */             index++;
/*     */           }
/*     */           else {
/* 492 */             foundMessage = true;
/* 493 */             break;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 498 */         if (foundMessage) {
/* 499 */           setStart(index / messageRange * messageRange);
/* 500 */           setResultFilter(null);
/*     */         }
/*     */       }
/*     */     }
/* 504 */     return "success";
/*     */   }
/*     */ 
/*     */   private ResultFilter getNextPrevResultFilter()
/*     */   {
/* 516 */     if (this.nextPrevFilter == null) {
/* 517 */       this.nextPrevFilter = super.getResultFilter();
/*     */ 
/* 519 */       int filterStartIndex = -1;
/* 520 */       if (this.tstart != null) {
/* 521 */         filterStartIndex = this.tstart.intValue() - 1;
/* 522 */         if (filterStartIndex < 0) {
/* 523 */           filterStartIndex = 0;
/*     */         }
/* 525 */         this.nextPrevFilter.setStartIndex(filterStartIndex);
/* 526 */         this.nextPrevFilter.setNumResults(this.nextPrevFilter.getNumResults() + 1);
/*     */       }
/*     */       else {
/* 529 */         return null;
/*     */       }
/*     */     }
/* 532 */     return this.nextPrevFilter;
/*     */   }
/*     */ 
/*     */   private void loadNextPrevThreads()
/*     */   {
/* 541 */     if (!this.nextPrevThreadsLoaded)
/*     */       try {
/* 543 */         ResultFilter npFilter = getNextPrevResultFilter();
/* 544 */         if (npFilter != null) {
/* 545 */           ForumThreadIterator threadIterator = getForum().getThreads(npFilter);
/* 546 */           threadIterator.setIndex(this.thread);
/* 547 */           if (threadIterator.hasNext()) {
/* 548 */             this.nextThread = ((ForumThread)threadIterator.next());
/*     */           }
/* 550 */           threadIterator.setIndex(this.thread);
/* 551 */           if (threadIterator.hasPrevious()) {
/* 552 */             this.previousThread = ((ForumThread)threadIterator.previous());
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 558 */         Log.debug(e);
/*     */       }
/*     */       finally {
/* 561 */         this.nextPrevThreadsLoaded = true;
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.ForumThreadAction
 * JD-Core Version:    0.6.2
 */
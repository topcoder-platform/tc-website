/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.action.JiveObjectLoader;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.MessageRejectedException;
/*     */ import com.jivesoftware.forum.Question;
/*     */ import com.jivesoftware.forum.Question.State;
/*     */ import com.jivesoftware.forum.QuestionManager;
/*     */ 
/*     */ public class QuestionResolutionAction extends ForumActionSupport
/*     */   implements JiveObjectLoader
/*     */ {
/*  26 */   private long threadID = 0L;
/*  27 */   private int resolution = -1;
/*     */   private String body;
/*     */   private String cancel;
/*     */   private ForumThread thread;
/*     */   private Question question;
/*     */ 
/*     */   public long getThreadID()
/*     */   {
/*  36 */     return this.threadID;
/*     */   }
/*     */ 
/*     */   public void setThreadID(long threadID) {
/*  40 */     this.threadID = threadID;
/*     */   }
/*     */ 
/*     */   public int getResolution() {
/*  44 */     return this.resolution;
/*     */   }
/*     */ 
/*     */   public void setResolution(int resolution) {
/*  48 */     this.resolution = resolution;
/*     */   }
/*     */ 
/*     */   public String getBody() {
/*  52 */     return this.body;
/*     */   }
/*     */ 
/*     */   public void setBody(String body) {
/*  56 */     this.body = body;
/*     */   }
/*     */ 
/*     */   public String getCancel() {
/*  60 */     return this.cancel;
/*     */   }
/*     */ 
/*     */   public void setCancel(String cancel) {
/*  64 */     this.cancel = "true";
/*     */   }
/*     */ 
/*     */   public ForumThread getThread() {
/*  68 */     return this.thread;
/*     */   }
/*     */ 
/*     */   public Question getQuestion() {
/*  72 */     return this.question;
/*     */   }
/*     */ 
/*     */   public Question.State getState()
/*     */   {
/*  80 */     return Question.State.valueOf(getResolution());
/*     */   }
/*     */ 
/*     */   public boolean isMarkAsAnswered()
/*     */   {
/*  90 */     return Question.State.resolved == getState();
/*     */   }
/*     */ 
/*     */   public boolean isMarkAsUnanswered()
/*     */   {
/* 100 */     return Question.State.open == getState();
/*     */   }
/*     */ 
/*     */   public boolean isMarkAsAssumedAns()
/*     */   {
/* 110 */     return Question.State.assumed_resolved == getState();
/*     */   }
/*     */ 
/*     */   public boolean isForceResponse()
/*     */   {
/* 120 */     if ((isMarkAsUnanswered()) && (getQuestion().getState() == Question.State.resolved)) {
/* 121 */       return true;
/*     */     }
/* 123 */     if ((isMarkAsUnanswered()) && (getQuestion().getState() == Question.State.assumed_resolved)) {
/* 124 */       return true;
/*     */     }
/* 126 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isModerator()
/*     */   {
/* 135 */     return isModerator(this.thread.getForum());
/*     */   }
/*     */ 
/*     */   public String doDefault() {
/* 139 */     if (!canResolveQuestion()) {
/* 140 */       return "unauthorized";
/*     */     }
/* 142 */     if (!checkResolution()) {
/* 143 */       return "error";
/*     */     }
/* 145 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute() {
/* 149 */     if (!canResolveQuestion()) {
/* 150 */       return "unauthorized";
/*     */     }
/* 152 */     if ("true".equals(getCancel())) {
/* 153 */       return "cancel";
/*     */     }
/* 155 */     if (!checkResolution()) {
/* 156 */       return "error";
/*     */     }
/*     */ 
/* 159 */     if ((isForceResponse()) && 
/* 160 */       (getBody() == null)) {
/* 161 */       addFieldError("body", "");
/* 162 */       return "error";
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 169 */       if (this.body != null) {
/* 170 */         ForumMessage message = this.thread.getForum().createMessage(getPageUser());
/* 171 */         message.setSubject("Re: " + this.thread.getRootMessage().getUnfilteredSubject());
/* 172 */         message.setBody(this.body);
/*     */         try {
/* 174 */           this.thread.addMessage(this.thread.getRootMessage(), message);
/*     */         }
/*     */         catch (MessageRejectedException mre) {
/* 177 */           String msg = mre.getMessage();
/* 178 */           addFieldError("messageRejected", msg == null ? "" : msg);
/* 179 */           return "error";
/*     */         }
/*     */       }
/* 182 */       this.question.setState(Question.State.valueOf(getResolution()));
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 185 */       return "unauthorized";
/*     */     }
/* 187 */     return "success";
/*     */   }
/*     */ 
/*     */   public String loadObjects() throws Exception {
/*     */     try {
/* 192 */       this.thread = getForumFactory().getForumThread(this.threadID);
/* 193 */       QuestionManager qman = getForumFactory().getQuestionManager();
/*     */       try {
/* 195 */         this.question = qman.getQuestion(this.thread);
/*     */       }
/*     */       catch (NotFoundException nfe) {
/* 198 */         addFieldError("threadID", String.valueOf(this.threadID));
/* 199 */         return "notfound";
/*     */       }
/*     */     }
/*     */     catch (ForumThreadNotFoundException fnfe) {
/* 203 */       addFieldError("threadID", String.valueOf(this.threadID));
/* 204 */       return "notfound";
/*     */     }
/* 206 */     return "success";
/*     */   }
/*     */ 
/*     */   private boolean checkResolution()
/*     */   {
/* 216 */     int res = getResolution();
/* 217 */     boolean isModerator = isModerator(this.thread.getForum());
/* 218 */     if ((isModerator) && (res == Question.State.assumed_resolved.getCode())) {
/* 219 */       return true;
/*     */     }
/* 221 */     if ((res != Question.State.open.getCode()) && (res != Question.State.resolved.getCode())) {
/* 222 */       addFieldError("resolution", String.valueOf(res));
/* 223 */       return false;
/*     */     }
/* 225 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean canResolveQuestion()
/*     */   {
/* 235 */     User user = getPageUser();
/* 236 */     ForumThread thread = getThread();
/* 237 */     User threadUser = thread.getRootMessage().getUser();
/* 238 */     if (((threadUser != null) && (user.getID() == threadUser.getID())) || (isModerator(thread.getForum())))
/*     */     {
/* 241 */       return true;
/*     */     }
/* 243 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.QuestionResolutionAction
 * JD-Core Version:    0.6.2
 */
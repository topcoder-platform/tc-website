/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.AuthFactory;
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.util.EmailTask;
/*     */ import com.jivesoftware.util.StringUtils;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import com.opensymphony.webwork.ServletActionContext;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class EmailResetPasswordToken extends ForumActionSupport
/*     */   implements Validateable
/*     */ {
/*     */   public static final String DEFAULT_SUBJECT = "Password reset request.";
/*     */   public static final String DEFAULT_BODY = "{name},\n\nWe have received a request from {requestIP} to reset your password.\nIf you have requested to reset your password, please follow the\ninstructions below. If you do not wish to reset your password,\nplease simply disregard this message.\n\nTo reset your Jive password you can either:\n\n- Click the following url:\n{jiveURL}/resetPassword!default.jspa?userid={userID}&token={token}\n\n- Goto\n{jiveURL}/resetPassword!default.jspa\nand enter the following information into the fields provided:\n\nUserID: {userID}\nToken: {token}";
/*     */   private String username;
/*     */   private String doCancel;
/*     */   private static final String JIVE_PASSWORDRESET_TOKEN = "jive.passwordreset.token";
/*     */   private static final String JIVE_PASSWORDRESET_TIMESTAMP = "jive.passwordreset.timestamp";
/*     */   private static final String JIVE_PASSWORDRESET_LAST_SENT = "jive.passwordreset.last_sent";
/*     */ 
/*     */   public String getUsername()
/*     */   {
/*  69 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/*  76 */     this.username = username;
/*     */   }
/*     */ 
/*     */   public String getDoCancel() {
/*  80 */     return this.doCancel;
/*     */   }
/*     */ 
/*     */   public void setDoCancel(String doCancel) {
/*  84 */     this.doCancel = "true";
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/*  92 */     if (!"true".equals(getDoCancel()))
/*  93 */       if (this.username == null)
/*  94 */         addActionError(getText("resetpassword.error_username"));
/*     */       else
/*     */         try
/*     */         {
/*  98 */           getForumFactory().getUserManager().getUser(this.username);
/*     */         }
/*     */         catch (UserNotFoundException e) {
/* 101 */           addActionError(getText("resetpassword.error_username_not_found"));
/*     */         }
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/* 113 */     if (!JiveGlobals.getJiveBooleanProperty("passwordReset.enabled", true)) {
/* 114 */       return "disabled";
/*     */     }
/*     */ 
/* 117 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 165 */     if (!JiveGlobals.getJiveBooleanProperty("passwordReset.enabled", true)) {
/* 166 */       return "disabled";
/*     */     }
/* 168 */     if ("true".equals(getDoCancel())) {
/* 169 */       return "cancel";
/*     */     }
/*     */ 
/* 172 */     String token = null;
/* 173 */     DbForumFactory dbfactory = null;
/* 174 */     UserManager userManager = null;
/* 175 */     User user = null;
/* 176 */     long now = System.currentTimeMillis();
/*     */     try
/*     */     {
/* 179 */       dbfactory = DbForumFactory.getInstance();
/* 180 */       userManager = dbfactory.getUserManager();
/* 181 */       user = userManager.getUser(this.username);
/* 182 */       token = user.getProperty("jive.passwordreset.token");
/*     */ 
/* 185 */       if (user.getID() == 1L) {
/* 186 */         addActionError(getText("resetpassword.error_email"));
/* 187 */         return "error";
/*     */       }
/*     */     }
/*     */     catch (UserNotFoundException e) {
/* 191 */       addActionError(getText("resetpassword.error_email"));
/* 192 */       return "error";
/*     */     }
/*     */ 
/* 196 */     if (token != null) {
/* 197 */       String tStamp = user.getProperty("jive.passwordreset.timestamp");
/* 198 */       String lSent = user.getProperty("jive.passwordreset.last_sent");
/* 199 */       long timeStamp = 0L;
/* 200 */       long lastSent = 0L;
/*     */       try
/*     */       {
/* 203 */         timeStamp = Long.valueOf(tStamp).longValue();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 207 */         Log.error("Timestamp wasn't stored in db properly, using current time");
/* 208 */         timeStamp = now - 259200000L - 1L;
/*     */       }
/*     */       try
/*     */       {
/* 212 */         lastSent = Long.valueOf(lSent).longValue();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 216 */         Log.error("Last sent time wasn't stored in db properly, using current time");
/* 217 */         lastSent = now - 86400000L - 1L;
/*     */       }
/*     */ 
/* 221 */       if (now - timeStamp > 259200000L) {
/* 222 */         token = StringUtils.randomString(8);
/*     */         try
/*     */         {
/* 225 */           user.setProperty("jive.passwordreset.token", token);
/* 226 */           user.setProperty("jive.passwordreset.timestamp", String.valueOf(now));
/*     */         }
/*     */         catch (UnauthorizedException e) {
/* 229 */           Log.error("Unable to update user password reset properties");
/* 230 */           addActionError(getText("error.permission"));
/* 231 */           return "error";
/*     */         }
/*     */ 
/*     */       }
/* 235 */       else if (now - lastSent < 86400000L) {
/* 236 */         addActionError(getText("resetpassword.error_email"));
/* 237 */         return "error";
/*     */       }
/*     */     }
/*     */     else {
/* 241 */       token = StringUtils.randomString(8);
/*     */       try
/*     */       {
/* 244 */         user.setProperty("jive.passwordreset.token", token);
/* 245 */         user.setProperty("jive.passwordreset.timestamp", String.valueOf(now));
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 248 */         Log.error("Unable to update user password reset properties");
/* 249 */         addActionError(getText("error.permission"));
/* 250 */         return "error";
/*     */       }
/*     */     }
/*     */ 
/* 254 */     String toName = user.getName();
/* 255 */     String toEmail = user.getEmail();
/* 256 */     String fromEmail = getFromEmail();
/* 257 */     String fromName = getFromName();
/* 258 */     String subject = JiveGlobals.getJiveProperty("passwordReset.email.subject");
/* 259 */     String body = JiveGlobals.getJiveProperty("passwordReset.email.body");
/*     */ 
/* 262 */     if (subject == null) {
/* 263 */       subject = "Password reset request.";
/*     */     }
/* 265 */     if (body == null) {
/* 266 */       body = "{name},\n\nWe have received a request from {requestIP} to reset your password.\nIf you have requested to reset your password, please follow the\ninstructions below. If you do not wish to reset your password,\nplease simply disregard this message.\n\nTo reset your Jive password you can either:\n\n- Click the following url:\n{jiveURL}/resetPassword!default.jspa?userid={userID}&token={token}\n\n- Goto\n{jiveURL}/resetPassword!default.jspa\nand enter the following information into the fields provided:\n\nUserID: {userID}\nToken: {token}";
/*     */     }
/*     */ 
/* 270 */     if ((fromEmail == null) || (fromName == null) || (subject == null) || (body == null)) {
/* 271 */       Log.error("WARNING: Not all password reset jive properties set, password resetting may fail.");
/*     */ 
/* 273 */       addActionError(getText("error.general"));
/* 274 */       return "error";
/*     */     }
/*     */ 
/* 277 */     Map args = new HashMap();
/* 278 */     args.put("token", token);
/* 279 */     args.put("request", ServletActionContext.getRequest());
/*     */ 
/* 281 */     subject = replaceTokens(subject, args, user);
/* 282 */     body = replaceTokens(body, args, user);
/*     */ 
/* 284 */     EmailTask emailTask = new EmailTask();
/* 285 */     emailTask.addMessage(toName, toEmail, fromName, fromEmail, subject, body, null);
/* 286 */     TaskEngine.addTask(emailTask);
/*     */     try
/*     */     {
/* 290 */       user.setProperty("jive.passwordreset.last_sent", String.valueOf(now));
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 293 */       Log.error("Unable to update user password reset properties");
/* 294 */       addActionError(getText("error.permission"));
/* 295 */       return "error";
/*     */     }
/*     */ 
/* 298 */     return "success";
/*     */   }
/*     */ 
/*     */   private String getFromEmail()
/*     */   {
/* 307 */     String fromEmail = JiveGlobals.getJiveProperty("passwordReset.email.fromEmail");
/*     */ 
/* 309 */     if (fromEmail == null) {
/*     */       try
/*     */       {
/* 312 */         AuthToken anonAuthToken = AuthFactory.getAnonymousAuthToken();
/* 313 */         User user = ForumFactory.getInstance(anonAuthToken).getUserManager().getUser("admin");
/* 314 */         if (user.getEmail() != null)
/* 315 */           return user.getEmail();
/*     */       }
/*     */       catch (UserNotFoundException e)
/*     */       {
/* 319 */         Log.error(e);
/*     */       }
/*     */     }
/*     */ 
/* 323 */     return fromEmail;
/*     */   }
/*     */ 
/*     */   private String getFromName()
/*     */   {
/* 332 */     String fromName = JiveGlobals.getJiveProperty("passwordReset.email.fromName");
/* 333 */     if (fromName == null) {
/*     */       try
/*     */       {
/* 336 */         AuthToken anonAuthToken = AuthFactory.getAnonymousAuthToken();
/* 337 */         User user = ForumFactory.getInstance(anonAuthToken).getUserManager().getUser("admin");
/* 338 */         if (user.getName() != null)
/* 339 */           return user.getName();
/*     */       }
/*     */       catch (UserNotFoundException e)
/*     */       {
/* 343 */         Log.error(e);
/*     */       }
/*     */     }
/*     */ 
/* 347 */     return fromName;
/*     */   }
/*     */ 
/*     */   private String replaceTokens(String string, Map args, User user)
/*     */   {
/* 354 */     if ((string == null) || (user == null)) {
/* 355 */       return "";
/*     */     }
/*     */ 
/* 358 */     String name = user.getName() == null ? user.getUsername() : user.getName();
/* 359 */     String requestIP = ServletActionContext.getRequest().getRemoteHost();
/* 360 */     String token = (String)args.get("token");
/* 361 */     String jiveURL = JiveGlobals.getJiveProperty("jiveURL");
/*     */ 
/* 363 */     if ((jiveURL != null) && (jiveURL.charAt(jiveURL.length() - 1) == '/')) {
/* 364 */       jiveURL = jiveURL.substring(0, jiveURL.length() - 1);
/*     */     }
/*     */ 
/* 367 */     string = StringUtils.replace(string, "{userID}", Long.toString(user.getID()));
/* 368 */     string = StringUtils.replace(string, "{username}", user.getUsername());
/* 369 */     string = StringUtils.replace(string, "{name}", name);
/* 370 */     string = StringUtils.replace(string, "{email}", user.getEmail());
/* 371 */     string = StringUtils.replace(string, "{token}", token);
/* 372 */     string = StringUtils.replace(string, "{requestIP}", requestIP);
/* 373 */     if (jiveURL != null) {
/* 374 */       string = StringUtils.replace(string, "{jiveURL}", jiveURL);
/*     */     }
/*     */ 
/* 377 */     return string;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.EmailResetPasswordToken
 * JD-Core Version:    0.6.2
 */
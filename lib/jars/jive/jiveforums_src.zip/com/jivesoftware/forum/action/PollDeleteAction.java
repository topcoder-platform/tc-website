/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.Poll;
/*    */ import com.jivesoftware.base.PollManager;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ 
/*    */ public class PollDeleteAction extends PollAction
/*    */ {
/*    */   private boolean cancel;
/*    */ 
/*    */   public String isCancel()
/*    */   {
/* 30 */     return String.valueOf(this.cancel);
/*    */   }
/*    */ 
/*    */   public void setCancel(String cancel)
/*    */   {
/* 37 */     this.cancel = true;
/*    */   }
/*    */ 
/*    */   public String doDefault() throws Exception {
/* 41 */     return "input";
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */     throws Exception
/*    */   {
/* 47 */     if (this.cancel) {
/* 48 */       return "cancel";
/*    */     }
/*    */ 
/* 51 */     Poll poll = getPoll();
/* 52 */     PollManager manager = getForumFactory().getPollManager();
/*    */     try {
/* 54 */       manager.deletePoll(poll);
/*    */     }
/*    */     catch (UnauthorizedException e) {
/* 57 */       return "unauthorized";
/*    */     }
/* 59 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PollDeleteAction
 * JD-Core Version:    0.6.2
 */
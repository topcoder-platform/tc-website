/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.opensymphony.xwork.ActionContext;
/*    */ import com.opensymphony.xwork.ActionInvocation;
/*    */ import com.opensymphony.xwork.interceptor.Interceptor;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class AdminSecurityInterceptor
/*    */   implements Interceptor
/*    */ {
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void init()
/*    */   {
/*    */   }
/*    */ 
/*    */   public String intercept(ActionInvocation in)
/*    */     throws Exception
/*    */   {
/* 39 */     Map session = in.getInvocationContext().getSession();
/*    */ 
/* 42 */     AuthToken authToken = (AuthToken)session.get("jive.admin.authToken");
/* 43 */     if (authToken == null) {
/* 44 */       return "login";
/*    */     }
/* 46 */     if (authToken.isAnonymous())
/*    */     {
/* 48 */       return "login";
/*    */     }
/*    */ 
/* 51 */     boolean[] adminRoles = (boolean[])session.get("jive.admin.roles");
/*    */ 
/* 53 */     if (adminRoles == null) {
/* 54 */       throw new UnauthorizedException("could not find session attribute jive.admin.authtoken");
/*    */     }
/*    */ 
/* 58 */     if (adminRoles[0] == 0) {
/* 59 */       throw new UnauthorizedException("requires SYSTEM_ADMIN access");
/*    */     }
/*    */ 
/* 63 */     return in.invoke();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AdminSecurityInterceptor
 * JD-Core Version:    0.6.2
 */
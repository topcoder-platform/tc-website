/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.ForumThread;
/*    */ 
/*    */ public class LockThreadAction extends ForumThreadAction
/*    */ {
/*    */   private String doCancel;
/*    */ 
/*    */   public String getDoCancel()
/*    */   {
/* 27 */     return this.doCancel;
/*    */   }
/*    */ 
/*    */   public void setDoCancel(String doCancel) {
/* 31 */     this.doCancel = "true";
/*    */   }
/*    */ 
/*    */   public String doDefault()
/*    */   {
/*    */     try
/*    */     {
/* 38 */       if (!loadJiveObjects())
/* 39 */         return "error";
/*    */     }
/*    */     catch (UnauthorizedException e)
/*    */     {
/* 43 */       setLoginAttributes();
/* 44 */       addActionError(getText("edit.error_unauth"));
/* 45 */       return "login";
/*    */     }
/* 47 */     return "input";
/*    */   }
/*    */ 
/*    */   public String execute() {
/*    */     try {
/* 52 */       if (!loadJiveObjects())
/* 53 */         return "error";
/*    */     }
/*    */     catch (UnauthorizedException e)
/*    */     {
/* 57 */       setLoginAttributes();
/* 58 */       addActionError(getText("lock.error_unauth"));
/* 59 */       return "login";
/*    */     }
/*    */ 
/* 62 */     if ((!isSystemAdmin()) && (!isModerator(getForum()))) {
/* 63 */       setLoginAttributes();
/* 64 */       addActionError(getText("lock.error_unauth"));
/* 65 */       return "login";
/*    */     }
/*    */ 
/* 68 */     if ("true".equals(getDoCancel())) {
/* 69 */       return "cancel";
/*    */     }
/*    */     try
/*    */     {
/* 73 */       getThread().setProperty("jive.locked", "true");
/*    */     }
/*    */     catch (UnauthorizedException ue) {
/* 76 */       setLoginAttributes();
/* 77 */       addActionError(ue.getMessage());
/* 78 */       return "login";
/*    */     }
/*    */ 
/* 81 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.LockThreadAction
 * JD-Core Version:    0.6.2
 */
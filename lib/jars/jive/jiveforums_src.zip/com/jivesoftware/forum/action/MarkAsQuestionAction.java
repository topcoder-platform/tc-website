/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.action.JiveObjectLoader;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.Question;
/*     */ import com.jivesoftware.forum.QuestionManager;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class MarkAsQuestionAction extends ForumActionSupport
/*     */   implements JiveObjectLoader
/*     */ {
/*  49 */   public static final int TIME_LIMIT = time;
/*     */   private long threadID;
/*     */   private String cancel;
/*     */   private ForumThread thread;
/*     */   private Question question;
/*     */ 
/*     */   public long getThreadID()
/*     */   {
/*  59 */     return this.threadID;
/*     */   }
/*     */ 
/*     */   public void setThreadID(long threadID) {
/*  63 */     this.threadID = threadID;
/*     */   }
/*     */ 
/*     */   public String getCancel() {
/*  67 */     return this.cancel;
/*     */   }
/*     */ 
/*     */   public void setCancel(String cancel) {
/*  71 */     this.cancel = "true";
/*     */   }
/*     */ 
/*     */   public ForumThread getThread() {
/*  75 */     return this.thread;
/*     */   }
/*     */ 
/*     */   public Question getQuestion() {
/*  79 */     return this.question;
/*     */   }
/*     */ 
/*     */   public static boolean canMarkAsQuestion(ForumThread thread, User user) {
/*  83 */     if ((user == null) || (user.getID() == -1L)) {
/*  84 */       return false;
/*     */     }
/*  86 */     boolean isAuthor = false;
/*  87 */     ForumMessage root = thread.getRootMessage();
/*  88 */     if ((root.isAnonymous()) || (root.getUser() == null)) {
/*  89 */       return false;
/*     */     }
/*     */ 
/*  92 */     isAuthor = root.getUser().getID() == user.getID();
/*     */ 
/*  94 */     if (isAuthor)
/*     */     {
/*  96 */       int time = getTimeLeft(thread, TIME_LIMIT);
/*  97 */       if ((time > 0) && (!hasOtherReplies(thread))) {
/*  98 */         return true;
/*     */       }
/*     */ 
/* 101 */       return false;
/*     */     }
/*     */ 
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean canUnmarkAsQuestion(QuestionManager manager, ForumThread thread, User user)
/*     */   {
/* 109 */     if ((user == null) || (user.getID() == -1L)) {
/* 110 */       return false;
/*     */     }
/* 112 */     if (!manager.hasQuestion(thread)) {
/* 113 */       return false;
/*     */     }
/* 115 */     boolean isAuthor = false;
/* 116 */     ForumMessage root = thread.getRootMessage();
/* 117 */     if ((root.isAnonymous()) || (root.getUser() == null)) {
/* 118 */       return false;
/*     */     }
/*     */ 
/* 121 */     isAuthor = root.getUser().getID() == user.getID();
/*     */ 
/* 123 */     if (isAuthor)
/*     */     {
/* 125 */       int time = getTimeLeft(thread, TIME_LIMIT);
/* 126 */       if ((time > 0) && (!hasOtherReplies(thread))) {
/* 127 */         return true;
/*     */       }
/*     */ 
/* 130 */       return false;
/*     */     }
/*     */ 
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */   public int getTimeLimit() {
/* 137 */     return TIME_LIMIT;
/*     */   }
/*     */ 
/*     */   public int getTimeLeft() {
/* 141 */     return getTimeLeft(getThread(), getTimeLimit());
/*     */   }
/*     */ 
/*     */   private static int getTimeLeft(ForumThread thread, int timeLimit)
/*     */   {
/* 146 */     long diff = System.currentTimeMillis() - thread.getCreationDate().getTime();
/* 147 */     int delta = timeLimit - (int)(diff / 1000L / 60L);
/* 148 */     if (delta > 0) {
/* 149 */       return delta;
/*     */     }
/*     */ 
/* 152 */     return 0;
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/* 157 */     if ("true".equals(getCancel())) {
/* 158 */       return "cancel";
/*     */     }
/* 160 */     if (!isAuthor(getThread().getRootMessage())) {
/* 161 */       return "unauthorized";
/*     */     }
/*     */ 
/* 164 */     int time = getTimeLeft();
/* 165 */     if (time == 0) {
/* 166 */       addFieldError("time", String.valueOf(time));
/* 167 */       return "error";
/*     */     }
/*     */ 
/* 170 */     if (hasOtherReplies(getThread())) {
/* 171 */       addFieldError("replyCount", "true");
/*     */     }
/* 173 */     return "input";
/*     */   }
/*     */ 
/*     */   private static boolean hasOtherReplies(ForumThread thread) {
/* 177 */     long id = thread.getRootMessage().getUser().getID();
/* 178 */     Iterator messages = thread.getMessages();
/* 179 */     while (messages.hasNext()) {
/* 180 */       ForumMessage msg = (ForumMessage)messages.next();
/* 181 */       User user = msg.getUser();
/* 182 */       long userID = -1L;
/* 183 */       if (user != null) {
/* 184 */         userID = user.getID();
/*     */       }
/* 186 */       if (userID != id) {
/* 187 */         return true;
/*     */       }
/*     */     }
/* 190 */     return false;
/*     */   }
/*     */ 
/*     */   public String execute() {
/* 194 */     if ("true".equals(getCancel())) {
/* 195 */       return "cancel";
/*     */     }
/* 197 */     if (!isAuthor(getThread().getRootMessage())) {
/* 198 */       addFieldError("userID", String.valueOf(getPageUser().getID()));
/* 199 */       return "unauthorized";
/*     */     }
/* 201 */     int time = getTimeLeft();
/* 202 */     if (time == 0) {
/* 203 */       addFieldError("time", String.valueOf(time));
/* 204 */       return "error";
/*     */     }
/* 206 */     QuestionManager qman = getForumFactory().getQuestionManager();
/*     */     try {
/* 208 */       this.question = qman.createQuestion(this.thread);
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 211 */       return "unauthorized";
/*     */     }
/* 213 */     return "success";
/*     */   }
/*     */ 
/*     */   public String doUnmark() {
/* 217 */     if ("true".equals(getCancel())) {
/* 218 */       return "cancel";
/*     */     }
/* 220 */     if (!isAuthor(getThread().getRootMessage())) {
/* 221 */       addFieldError("userID", String.valueOf(getPageUser().getID()));
/* 222 */       return "unauthorized";
/*     */     }
/* 224 */     int time = getTimeLeft();
/* 225 */     if (time == 0) {
/* 226 */       addFieldError("time", String.valueOf(time));
/* 227 */       return "error";
/*     */     }
/* 229 */     QuestionManager qman = getForumFactory().getQuestionManager();
/*     */     try {
/* 231 */       qman.deleteQuestion(qman.getQuestion(this.thread));
/*     */     }
/*     */     catch (NotFoundException e)
/*     */     {
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 237 */       return "unauthorized";
/*     */     }
/* 239 */     return "success";
/*     */   }
/*     */ 
/*     */   public String loadObjects() throws Exception {
/*     */     try {
/* 244 */       this.thread = getForumFactory().getForumThread(this.threadID);
/*     */     }
/*     */     catch (ForumThreadNotFoundException fnfe) {
/* 247 */       addFieldError("threadID", String.valueOf(this.threadID));
/* 248 */       return "notfound";
/*     */     }
/* 250 */     return "success";
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  45 */     int time = JiveGlobals.getJiveIntProperty("questions.markAsQuestionTimeWindow", 15);
/*  46 */     if (time < 0)
/*  47 */       time = 0;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.MarkAsQuestionAction
 * JD-Core Version:    0.6.2
 */
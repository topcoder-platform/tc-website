/*    */ package com.jivesoftware.forum.action.setup;
/*    */ 
/*    */ import com.jivesoftware.base.JiveGlobals;
/*    */ import com.opensymphony.xwork.ActionContext;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class UserSystemSetupAction extends SetupActionSupport
/*    */ {
/*    */   public static final String STANDARD_MODE = "standard";
/*    */   public static final String CUSTOM_MODE = "custom";
/*    */   public static final String LDAP_MODE = "ldap";
/* 27 */   String mode = "standard";
/*    */ 
/*    */   public String getMode()
/*    */   {
/* 32 */     return this.mode;
/*    */   }
/*    */ 
/*    */   public void setMode(String mode) {
/* 36 */     this.mode = mode;
/*    */   }
/*    */ 
/*    */   public String doDefault()
/*    */   {
/* 42 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/* 43 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/* 44 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "in_progress");
/* 45 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "incomplete");
/* 46 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "incomplete");
/* 47 */     return "input";
/*    */   }
/*    */ 
/*    */   public String execute() {
/* 51 */     if ("standard".equals(this.mode))
/*    */     {
/* 55 */       JiveGlobals.deleteJiveProperty("UserManager.className");
/* 56 */       JiveGlobals.deleteJiveProperty("GroupManager.className");
/* 57 */       JiveGlobals.deleteJiveProperty("AuthorizationFactory.className");
/*    */ 
/* 60 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/* 61 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/* 62 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "done");
/* 63 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "in_progress");
/* 64 */       ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "incomplete");
/* 65 */       return "next";
/*    */     }
/* 67 */     if ("custom".equals(this.mode)) {
/* 68 */       return "custom";
/*    */     }
/* 70 */     if ("ldap".equals(this.mode)) {
/* 71 */       return "ldap";
/*    */     }
/*    */ 
/* 74 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.UserSystemSetupAction
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.MessageRejectedException;
/*     */ 
/*     */ public class BranchAction extends ForumThreadAction
/*     */ {
/*     */   private String doCancel;
/*     */   private String subject;
/*     */ 
/*     */   public String getDoCancel()
/*     */   {
/*  30 */     return this.doCancel;
/*     */   }
/*     */ 
/*     */   public void setDoCancel(String doCancel) {
/*  34 */     this.doCancel = "true";
/*     */   }
/*     */ 
/*     */   public String getSubject() {
/*  38 */     return this.subject;
/*     */   }
/*     */ 
/*     */   public void setSubject(String subject) {
/*  42 */     if ((subject != null) && (!"".equals(subject.trim())))
/*  43 */       this.subject = subject;
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*     */     try
/*     */     {
/*  51 */       if (!loadJiveObjects())
/*  52 */         return "error";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/*  56 */       setLoginAttributes();
/*  57 */       addActionError(getText("branch.error_unauth"));
/*  58 */       return "login";
/*     */     }
/*  60 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute() {
/*     */     try {
/*  65 */       if (!loadJiveObjects())
/*  66 */         return "error";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/*  70 */       setLoginAttributes();
/*  71 */       addActionError(getText("branch.error_unauth"));
/*  72 */       return "login";
/*     */     }
/*  74 */     if ((!isSystemAdmin()) && (!isModerator(getForum()))) {
/*  75 */       setLoginAttributes();
/*  76 */       addActionError(getText("branch.error_unauth"));
/*  77 */       return "login";
/*     */     }
/*     */ 
/*  80 */     if ("true".equals(getDoCancel())) {
/*  81 */       return "cancel";
/*     */     }
/*     */ 
/*  84 */     if (getSubject() == null) {
/*  85 */       addActionError(getText("branch.error_invalid_subject"));
/*  86 */       return "input";
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  91 */       getMessage().setSubject(this.subject);
/*     */ 
/*  93 */       ForumThread newThread = getForum().createThread(getMessage());
/*     */ 
/*  95 */       getForum().addThread(newThread);
/*     */ 
/*  98 */       return "success";
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 101 */       setLoginAttributes();
/* 102 */       addActionError(ue.getMessage());
/* 103 */       return "login";
/*     */     }
/*     */     catch (MessageRejectedException mje) {
/* 106 */       addActionError(mje.getMessage());
/* 107 */     }return "error";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.BranchAction
 * JD-Core Version:    0.6.2
 */
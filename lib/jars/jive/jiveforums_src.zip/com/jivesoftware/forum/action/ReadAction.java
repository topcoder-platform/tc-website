/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ReadTracker;
/*     */ 
/*     */ public class ReadAction extends ForumActionSupport
/*     */ {
/*  25 */   private long forumID = -1L;
/*  26 */   private long categoryID = -1L;
/*     */   private Forum forum;
/*     */   private ForumCategory category;
/*     */ 
/*     */   public long getForumID()
/*     */   {
/*  36 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID) {
/*  40 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public long getCategoryID() {
/*  44 */     return this.categoryID;
/*     */   }
/*     */ 
/*     */   public void setCategoryID(long categoryID) {
/*  48 */     this.categoryID = categoryID;
/*     */   }
/*     */ 
/*     */   public Forum getForum()
/*     */   {
/*  57 */     return this.forum;
/*     */   }
/*     */ 
/*     */   protected void setForum(Forum forum)
/*     */   {
/*  65 */     this.forum = forum;
/*     */   }
/*     */ 
/*     */   public ForumCategory getCategory()
/*     */   {
/*  72 */     return this.category;
/*     */   }
/*     */ 
/*     */   protected void setCategory(ForumCategory category)
/*     */   {
/*  80 */     this.category = category;
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/*     */     try
/*     */     {
/*  94 */       if (!loadJiveObjects())
/*  95 */         return "error";
/*     */     }
/*     */     catch (UnauthorizedException ue)
/*     */     {
/*  99 */       setLoginAttributes();
/* 100 */       addActionError(getText("forum.error_unauth"));
/* 101 */       return "login";
/*     */     }
/*     */ 
/* 104 */     ReadTracker readTracker = getForumFactory().getReadTracker();
/* 105 */     if (readTracker.isReadTrackingEnabled()) {
/* 106 */       User user = getPageUser();
/* 107 */       if (getForum() != null) {
/* 108 */         readTracker.markRead(user, getForum());
/* 109 */         return "success-forum";
/*     */       }
/* 111 */       if (getCategory() != null) {
/* 112 */         readTracker.markRead(user, getCategory());
/* 113 */         return "success-category";
/*     */       }
/*     */     }
/*     */ 
/* 117 */     return "none";
/*     */   }
/*     */ 
/*     */   protected boolean loadJiveObjects()
/*     */     throws UnauthorizedException
/*     */   {
/* 126 */     boolean success = true;
/* 127 */     if ((getForum() == null) && (getForumID() > -1L)) {
/*     */       try {
/* 129 */         setForum(getForumFactory().getForum(getForumID()));
/*     */       }
/*     */       catch (ForumNotFoundException fnfe) {
/* 132 */         addActionError(fnfe.getMessage());
/* 133 */         success = false;
/*     */       }
/*     */     }
/* 136 */     if ((getCategory() == null) && (getCategoryID() > -1L)) {
/*     */       try {
/* 138 */         setCategory(getForumFactory().getForumCategory(getCategoryID()));
/*     */       }
/*     */       catch (ForumCategoryNotFoundException fcnfe) {
/* 141 */         addActionError(fcnfe.getMessage());
/* 142 */         success = false;
/*     */       }
/*     */     }
/* 145 */     return success;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.ReadAction
 * JD-Core Version:    0.6.2
 */
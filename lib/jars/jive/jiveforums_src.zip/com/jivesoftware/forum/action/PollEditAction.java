/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.Poll;
/*     */ import com.jivesoftware.base.PollManager;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.action.util.DateUtils;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PollEditAction extends PollPostAction
/*     */ {
/*  30 */   private long pollID = 0L;
/*     */   private Poll poll;
/*     */ 
/*     */   public long getPollID()
/*     */   {
/*  38 */     return this.pollID;
/*     */   }
/*     */ 
/*     */   public void setPollID(long pollID)
/*     */   {
/*  45 */     this.pollID = pollID;
/*     */   }
/*     */ 
/*     */   public Poll getPoll()
/*     */   {
/*  52 */     return this.poll;
/*     */   }
/*     */ 
/*     */   public String doDefault() throws Exception
/*     */   {
/*  57 */     switch (this.poll.getObjectType()) {
/*     */     case 0:
/*  59 */       setForumID(this.poll.getObjectID());
/*  60 */       break;
/*     */     case 14:
/*  62 */       setCategoryID(this.poll.getObjectID());
/*  63 */       break;
/*     */     }
/*     */ 
/*  69 */     setName(this.poll.getName());
/*  70 */     setDescription(this.poll.getDescription());
/*  71 */     List options = new ArrayList();
/*  72 */     int i = 0; for (int n = this.poll.getOptionCount(); i < n; i++) {
/*  73 */       String option = this.poll.getOption(i);
/*  74 */       options.add(new PollOption(option));
/*     */     }
/*  76 */     setOptions(options);
/*     */ 
/*  78 */     Date now = new Date();
/*  79 */     if ((this.poll.getStartDate() != null) && (this.poll.getStartDate().before(now))) {
/*  80 */       setActiveMode("activenow");
/*     */     }
/*     */     else {
/*  83 */       setActiveMode("activelater");
/*     */     }
/*  85 */     setExpiresMode("expiresnever");
/*  86 */     if ((this.poll.getEndDate() != null) && (!this.poll.getEndDate().equals(DateUtils.getMaxDate()))) {
/*  87 */       SimpleDateFormat formatter = new SimpleDateFormat(DateUtils.getDatePattern());
/*  88 */       setExpiresDate(formatter.format(this.poll.getEndDate()));
/*  89 */       setExpiresMode("expireslater");
/*     */     }
/*     */ 
/*  92 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */     throws Exception
/*     */   {
/* 108 */     if ("true".equals(isCancel())) {
/* 109 */       if (this.poll.getObjectType() == 14) {
/* 110 */         return "cancel-category";
/*     */       }
/* 112 */       if (this.poll.getObjectType() == 0) {
/* 113 */         return "cancel-forum";
/*     */       }
/*     */ 
/* 116 */       return "cancel";
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 121 */       if (getName() != null) {
/* 122 */         this.poll.setName(getName());
/*     */       }
/*     */ 
/* 125 */       if (getDescription() != null) {
/* 126 */         this.poll.setDescription(getDescription());
/*     */       }
/*     */       else {
/* 129 */         this.poll.setDescription("");
/*     */       }
/*     */ 
/* 133 */       List deletables = new ArrayList();
/* 134 */       int i = 0;
/* 135 */       for (int n = this.poll.getOptionCount(); i < n; i++) {
/* 136 */         String option = this.poll.getOption(i);
/* 137 */         PollOption newOption = null;
/*     */         try {
/* 139 */           newOption = (PollOption)getOptions().get(i);
/* 140 */           if ((newOption == null) || ("".equals(newOption))) {
/* 141 */             deletables.add(new Integer(i));
/*     */           }
/*     */           else
/* 144 */             this.poll.setOption(i, newOption.getOption());
/*     */         }
/*     */         catch (Exception ignored)
/*     */         {
/* 148 */           deletables.add(new Integer(i));
/*     */         }
/*     */       }
/*     */ 
/* 152 */       for (int n = getOptions().size(); i < n; i++) {
/* 153 */         PollOption newOption = (PollOption)getOptions().get(i);
/* 154 */         if ((newOption != null) && (newOption.validate())) {
/* 155 */           this.poll.addOption(newOption.getOption());
/*     */         }
/*     */       }
/*     */ 
/* 159 */       for (i = deletables.size() - 1; i >= 0; i--) {
/* 160 */         int optionIndex = ((Integer)deletables.get(i)).intValue();
/* 161 */         this.poll.deleteOption(optionIndex);
/*     */       }
/*     */ 
/* 165 */       if ("activelater".equals(getActiveMode())) {
/* 166 */         SimpleDateFormat formatter = new SimpleDateFormat(DateUtils.getDatePattern());
/*     */         try {
/* 168 */           Date date = formatter.parse(getActiveDate());
/* 169 */           this.poll.setStartDate(date);
/*     */         } catch (Exception ignored) {
/*     */         }
/*     */       }
/* 173 */       if ("expiresrelative".equals(getExpiresMode())) {
/* 174 */         Calendar cal = Calendar.getInstance();
/* 175 */         cal.add(6, getExpiresDays());
/* 176 */         this.poll.setEndDate(cal.getTime());
/*     */       }
/* 178 */       else if (("expireslater".equals(getExpiresMode())) && (getExpiresDate() != null)) {
/*     */         try {
/* 180 */           SimpleDateFormat formatter = new SimpleDateFormat(DateUtils.getDatePattern());
/* 181 */           Date date = formatter.parse(getExpiresDate());
/* 182 */           this.poll.setEndDate(date);
/*     */         } catch (Exception ignored) {
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 188 */       return "unauthorized";
/*     */     }
/* 190 */     return "success";
/*     */   }
/*     */ 
/*     */   public String loadObjects()
/*     */   {
/* 195 */     String result = super.loadObjects();
/* 196 */     if (!"success".equals(result)) {
/* 197 */       return result;
/*     */     }
/*     */ 
/* 201 */     PollManager manager = getForumFactory().getPollManager();
/*     */     try {
/* 203 */       this.poll = manager.getPoll(this.pollID);
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 206 */       return "unauthorized";
/*     */     }
/*     */     catch (NotFoundException e) {
/* 209 */       addFieldError("pollID", String.valueOf(this.pollID));
/* 210 */       return "notfound";
/*     */     }
/*     */ 
/* 213 */     ForumCategory category = null;
/* 214 */     Forum forum = null;
/* 215 */     switch (this.poll.getObjectType()) {
/*     */     case 14:
/*     */       try {
/* 218 */         category = getForumFactory().getForumCategory(this.poll.getObjectID());
/* 219 */         if (!getCanCreatePoll(category))
/* 220 */           return "unauthorized";
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e)
/*     */       {
/* 224 */         addFieldError("categoryID", String.valueOf(this.poll.getObjectID()));
/*     */       }
/*     */     case 0:
/*     */       try
/*     */       {
/* 229 */         forum = getForumFactory().getForum(this.poll.getObjectID());
/* 230 */         if (!getCanCreatePoll(forum))
/* 231 */           return "unauthorized";
/*     */       }
/*     */       catch (ForumNotFoundException e)
/*     */       {
/* 235 */         addFieldError("forumID", String.valueOf(this.poll.getObjectID()));
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 238 */         return "unauthorized";
/*     */       }
/*     */ 
/*     */     default:
/* 242 */       if ((!isSystemAdmin()) && (!getForumFactory().isAuthorized(16L))) {
/* 243 */         return "unauthorized";
/*     */       }
/*     */       break;
/*     */     }
/*     */ 
/* 248 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PollEditAction
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.PresenceManager;
/*    */ import com.jivesoftware.base.Roster;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ 
/*    */ public class AddressBookViewAction extends ForumActionSupport
/*    */ {
/*    */   private Roster roster;
/*    */ 
/*    */   public Roster getRoster()
/*    */   {
/* 24 */     return this.roster;
/*    */   }
/*    */ 
/*    */   public String execute() {
/* 28 */     if (getAuthToken().isAnonymous())
/* 29 */       return "login";
/*    */     try
/*    */     {
/* 32 */       this.roster = getForumFactory().getPresenceManager().getRoster(getPageUser());
/*    */     }
/*    */     catch (UnauthorizedException ue) {
/* 35 */       return "login";
/*    */     }
/*    */ 
/* 38 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AddressBookViewAction
 * JD-Core Version:    0.6.2
 */
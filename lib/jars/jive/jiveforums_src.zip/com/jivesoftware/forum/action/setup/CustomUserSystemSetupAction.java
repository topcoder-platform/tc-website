/*     */ package com.jivesoftware.forum.action.setup;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.util.ClassUtils;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import com.opensymphony.xwork.ModelDriven;
/*     */ import com.opensymphony.xwork.Preparable;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class CustomUserSystemSetupAction extends SetupActionSupport
/*     */   implements ModelDriven, Preparable
/*     */ {
/*     */   private Parameters params;
/*     */ 
/*     */   public CustomUserSystemSetupAction()
/*     */   {
/*  24 */     this.params = new Parameters();
/*     */   }
/*     */ 
/*     */   public Object getModel()
/*     */   {
/*  29 */     return this.params;
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */     throws Exception
/*     */   {
/*  35 */     if (JiveGlobals.getJiveProperty("UserManager.className") != null) {
/*  36 */       this.params.userClassname = JiveGlobals.getJiveProperty("UserManager.className");
/*     */     }
/*  38 */     if (JiveGlobals.getJiveProperty("GroupManager.className") != null) {
/*  39 */       this.params.groupClassname = JiveGlobals.getJiveProperty("GroupManager.className");
/*     */     }
/*  41 */     if (JiveGlobals.getJiveProperty("AuthFactory.className") != null)
/*  42 */       this.params.authClassname = JiveGlobals.getJiveProperty("AuthFactory.className");
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*  47 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/*  48 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/*  49 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "in_progress");
/*  50 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "incomplete");
/*  51 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "incomplete");
/*  52 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/*  57 */     if (this.params.userClassname != null) {
/*     */       try {
/*  59 */         ClassUtils.forName(this.params.userClassname);
/*  60 */         JiveGlobals.setJiveProperty("UserManager.className", this.params.userClassname);
/*     */       }
/*     */       catch (Exception e) {
/*  63 */         addFieldError("userClassname", getText("setup.error.usersystem.failed_loading_class"));
/*     */       }
/*     */     }
/*     */     else {
/*  67 */       JiveGlobals.deleteJiveProperty("UserManager.className");
/*     */     }
/*     */ 
/*  70 */     if (this.params.groupClassname != null) {
/*     */       try {
/*  72 */         ClassUtils.forName(this.params.groupClassname);
/*  73 */         JiveGlobals.setJiveProperty("GroupManager.className", this.params.groupClassname);
/*     */       }
/*     */       catch (Exception e) {
/*  76 */         addFieldError("groupClassname", getText("setup.error.usersystem.failed_loading_class"));
/*     */       }
/*     */     }
/*     */     else {
/*  80 */       JiveGlobals.deleteJiveProperty("GroupManager.className");
/*     */     }
/*     */ 
/*  83 */     if (this.params.authClassname != null) {
/*     */       try {
/*  85 */         ClassUtils.forName(this.params.authClassname);
/*  86 */         JiveGlobals.setJiveProperty("AuthFactory.className", this.params.authClassname);
/*     */       }
/*     */       catch (Exception e) {
/*  89 */         addFieldError("authClassname", getText("setup.error.usersystem.failed_loading_class"));
/*     */       }
/*     */     }
/*     */     else {
/*  93 */       JiveGlobals.deleteJiveProperty("AuthFactory.className");
/*     */     }
/*     */ 
/*  96 */     if (hasErrors()) {
/*  97 */       return "error";
/*     */     }
/*     */ 
/* 101 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/* 102 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/* 103 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "done");
/* 104 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "in_progress");
/* 105 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "incomplete");
/* 106 */     return "next";
/*     */   }
/*     */   class Parameters { private String userClassname;
/*     */     private String groupClassname;
/*     */     private String authClassname;
/*     */ 
/*     */     Parameters() {  } 
/* 115 */     public String getUserClassname() { return this.userClassname; }
/*     */ 
/*     */     public void setUserClassname(String userClassname)
/*     */     {
/* 119 */       if ((userClassname == null) || ("".equals(userClassname.trim()))) {
/* 120 */         this.userClassname = null;
/*     */       }
/*     */       else
/* 123 */         this.userClassname = userClassname;
/*     */     }
/*     */ 
/*     */     public String getGroupClassname()
/*     */     {
/* 128 */       return this.groupClassname;
/*     */     }
/*     */ 
/*     */     public void setGroupClassname(String groupClassname) {
/* 132 */       if ((groupClassname == null) || ("".equals(groupClassname.trim()))) {
/* 133 */         this.groupClassname = null;
/*     */       }
/*     */       else
/* 136 */         this.groupClassname = groupClassname;
/*     */     }
/*     */ 
/*     */     public String getAuthClassname()
/*     */     {
/* 141 */       return this.authClassname;
/*     */     }
/*     */ 
/*     */     public void setAuthClassname(String authClassname) {
/* 145 */       if ((authClassname == null) || ("".equals(authClassname.trim()))) {
/* 146 */         this.authClassname = null;
/*     */       }
/*     */       else
/* 149 */         this.authClassname = authClassname;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.CustomUserSystemSetupAction
 * JD-Core Version:    0.6.2
 */
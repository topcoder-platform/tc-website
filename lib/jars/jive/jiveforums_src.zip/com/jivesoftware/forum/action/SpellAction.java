/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.util.SpellChecker;
/*     */ import com.jivesoftware.util.SpellSession;
/*     */ import com.jivesoftware.util.StringUtils;
/*     */ import com.opensymphony.webwork.ServletActionContext;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class SpellAction extends PostAction
/*     */   implements Validateable
/*     */ {
/*     */   public static final String GOBACK = "goback";
/*     */   public static final String POST = "post";
/*     */   private String doChange;
/*     */   private String doChangeAll;
/*     */   private String doIgnore;
/*     */   private String doIgnoreAll;
/*     */   private String doAdd;
/*     */   private String doDelete;
/*     */   private String doEdit;
/*     */   private String doPostNow;
/*     */   private String newWord;
/*     */   private String doDeleteSecond;
/*     */   private Boolean ansQuestion;
/*     */   private SpellSession spellSession;
/*     */   private String[] suggestions;
/*     */   private String body;
/*     */   private boolean misspelledWords;
/*     */   private boolean doubleWords;
/*     */ 
/*     */   public String getDoChange()
/*     */   {
/*  58 */     return this.doChange;
/*     */   }
/*     */ 
/*     */   public void setDoChange(String doChange) {
/*  62 */     if ((doChange != null) && (!"".equals(doChange.trim())))
/*  63 */       this.doChange = "true";
/*     */   }
/*     */ 
/*     */   public String getDoChangeAll()
/*     */   {
/*  68 */     return this.doChangeAll;
/*     */   }
/*     */ 
/*     */   public void setDoChangeAll(String doChangeAll) {
/*  72 */     if ((doChangeAll != null) && (!"".equals(doChangeAll.trim())))
/*  73 */       this.doChangeAll = "true";
/*     */   }
/*     */ 
/*     */   public String getDoIgnore()
/*     */   {
/*  78 */     return this.doIgnore;
/*     */   }
/*     */ 
/*     */   public void setDoIgnore(String doIgnore) {
/*  82 */     if ((doIgnore != null) && (!"".equals(doIgnore.trim())))
/*  83 */       this.doIgnore = "true";
/*     */   }
/*     */ 
/*     */   public String getDoIgnoreAll()
/*     */   {
/*  88 */     return this.doIgnoreAll;
/*     */   }
/*     */ 
/*     */   public void setDoIgnoreAll(String doIgnoreAll) {
/*  92 */     if ((doIgnoreAll != null) && (!"".equals(doIgnoreAll.trim())))
/*  93 */       this.doIgnoreAll = "true";
/*     */   }
/*     */ 
/*     */   public String getDoAdd()
/*     */   {
/*  98 */     return this.doAdd;
/*     */   }
/*     */ 
/*     */   public void setDoAdd(String doAdd) {
/* 102 */     if ((doAdd != null) && (!"".equals(doAdd.trim())))
/* 103 */       this.doAdd = "true";
/*     */   }
/*     */ 
/*     */   public String getDoDelete()
/*     */   {
/* 108 */     return this.doDelete;
/*     */   }
/*     */ 
/*     */   public void setDoDelete(String doDelete) {
/* 112 */     if ((doDelete != null) && (!"".equals(doDelete.trim())))
/* 113 */       this.doDelete = "true";
/*     */   }
/*     */ 
/*     */   public String getDoEdit()
/*     */   {
/* 118 */     return this.doEdit;
/*     */   }
/*     */ 
/*     */   public void setDoEdit(String doEdit) {
/* 122 */     if ((doEdit != null) && (!"".equals(doEdit.trim())))
/* 123 */       this.doEdit = "true";
/*     */   }
/*     */ 
/*     */   public String getDoPostNow()
/*     */   {
/* 128 */     return this.doPostNow;
/*     */   }
/*     */ 
/*     */   public void setDoPostNow(String doPostNow) {
/* 132 */     if ((doPostNow != null) && (!"".equals(doPostNow.trim())))
/* 133 */       this.doPostNow = "true";
/*     */   }
/*     */ 
/*     */   public String getNewWord()
/*     */   {
/* 138 */     return this.newWord;
/*     */   }
/*     */ 
/*     */   public void setNewWord(String newWord) {
/* 142 */     if ((newWord != null) && (!"".equals(newWord)))
/* 143 */       this.newWord = newWord;
/*     */   }
/*     */ 
/*     */   public String getDoDeleteSecond()
/*     */   {
/* 148 */     return this.doDeleteSecond;
/*     */   }
/*     */ 
/*     */   public void setDoDeleteSecond(String doDeleteSecond) {
/* 152 */     if ((doDeleteSecond != null) && (!"".equals(doDeleteSecond.trim())))
/* 153 */       this.doDeleteSecond = "true";
/*     */   }
/*     */ 
/*     */   public String[] getSuggestions()
/*     */   {
/* 158 */     if (this.suggestions == null) {
/* 159 */       this.suggestions = this.spellSession.getSuggestions();
/* 160 */       if (this.suggestions == null) {
/* 161 */         this.suggestions = new String[0];
/*     */       }
/*     */     }
/* 164 */     return this.suggestions;
/*     */   }
/*     */ 
/*     */   public boolean hasSuggestions() {
/* 168 */     return getSuggestions().length > 0;
/*     */   }
/*     */ 
/*     */   public String getSubject()
/*     */   {
/* 175 */     ForumMessage tempMessage = retrieveFromSession();
/* 176 */     return tempMessage.getSubject();
/*     */   }
/*     */ 
/*     */   public String getBody()
/*     */   {
/* 182 */     String highlighted = this.spellSession.getHighlightedText();
/*     */ 
/* 185 */     highlighted = StringUtils.replace(highlighted, "<spellfirst>", "[[span class='jive-spell-error-current']]");
/*     */ 
/* 187 */     highlighted = StringUtils.replace(highlighted, "</spellfirst>", "[[/span]]");
/* 188 */     highlighted = StringUtils.replace(highlighted, "<spell>", "[[span class='jive-spell-error']]");
/*     */ 
/* 190 */     highlighted = StringUtils.replace(highlighted, "</spell>", "[[/span]]");
/*     */ 
/* 192 */     highlighted = StringUtils.escapeHTMLTags(highlighted);
/*     */ 
/* 194 */     highlighted = StringUtils.replace(highlighted, "\n", "<br>");
/*     */ 
/* 196 */     highlighted = StringUtils.replace(highlighted, "[[span class='jive-spell-error-current']]", "<span class=\"jive-spell-error-current\">");
/*     */ 
/* 198 */     highlighted = StringUtils.replace(highlighted, "[[span class='jive-spell-error']]", "<span class=\"jive-spell-error\">");
/*     */ 
/* 200 */     highlighted = StringUtils.replace(highlighted, "[[/span]]", "</span>");
/*     */ 
/* 202 */     return highlighted;
/*     */   }
/*     */ 
/*     */   public void setBody(String body) {
/* 206 */     this.body = body;
/*     */   }
/*     */ 
/*     */   public boolean isMisspelledWords() {
/* 210 */     return this.misspelledWords;
/*     */   }
/*     */ 
/*     */   public void setMisspelledWords(boolean misspelledWords) {
/* 214 */     this.misspelledWords = misspelledWords;
/*     */   }
/*     */ 
/*     */   public boolean isDoubleWords() {
/* 218 */     return this.doubleWords;
/*     */   }
/*     */ 
/*     */   public void setDoubleWords(boolean doubleWords) {
/* 222 */     this.doubleWords = doubleWords;
/*     */   }
/*     */ 
/*     */   public boolean hasSpellingErrors() {
/* 226 */     return (isMisspelledWords()) || (isDoubleWords());
/*     */   }
/*     */ 
/*     */   public Boolean getAnsQuestion() {
/* 230 */     return this.ansQuestion;
/*     */   }
/*     */ 
/*     */   public void setAnsQuestion(Boolean ansQuestion) {
/* 234 */     this.ansQuestion = ansQuestion;
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/* 240 */     if (getDoDeleteSecond() != null) {
/* 241 */       return;
/*     */     }
/* 243 */     if (getDoIgnore() != null) {
/* 244 */       return;
/*     */     }
/*     */ 
/* 247 */     if ((getNewWord() == null) && (!"true".equals(getDoEdit())) && (!"true".equals(getDoPostNow())))
/* 248 */       addFieldError("newWord", getText("spell.error_new_word"));
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/* 254 */     this.spellSession = SpellChecker.createSession(this.body);
/* 255 */     int result = this.spellSession.next();
/* 256 */     if (result == 16) {
/* 257 */       this.misspelledWords = true;
/*     */     }
/* 259 */     else if (result == 4) {
/* 260 */       this.doubleWords = true;
/*     */     }
/* 262 */     String key = getSpellSessionKey();
/* 263 */     if (Log.isDebugEnabled()) {
/* 264 */       Log.debug("setting spell session user key " + key);
/* 265 */       Log.debug("SpellSession object: " + this.spellSession);
/*     */     }
/* 267 */     ActionContext.getContext().getSession().put(key, this.spellSession);
/*     */ 
/* 269 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 276 */     String key = getSpellSessionKey();
/* 277 */     Object o = ActionContext.getContext().getSession().get(key);
/* 278 */     if ((o != null) && (!(o instanceof SpellSession))) {
/* 279 */       Log.error("Session key " + key + " should return a SpellSession object not (see next line).");
/* 280 */       Log.error("Bad class name: " + o.getClass().getName());
/* 281 */       Log.error("Bad object: " + o);
/*     */     }
/*     */ 
/* 285 */     if (o == null) {
/* 286 */       addActionError(getText("spell.error_spell_session_expired"));
/* 287 */       return "error";
/*     */     }
/*     */ 
/* 290 */     if (Log.isDebugEnabled()) {
/* 291 */       Log.debug("Found SpellSession key --> " + key + " value --> " + o);
/*     */     }
/*     */ 
/* 295 */     this.spellSession = ((SpellSession)o);
/*     */ 
/* 300 */     if ("true".equals(getDoChange())) {
/* 301 */       this.spellSession.replace(getNewWord());
/*     */     }
/* 305 */     else if ("true".equals(getDoChangeAll())) {
/* 306 */       this.spellSession.replaceAll(getNewWord());
/*     */     }
/* 310 */     else if ("true".equals(getDoDeleteSecond())) {
/* 311 */       this.spellSession.delete();
/*     */     }
/* 315 */     else if ("true".equals(getDoIgnore())) {
/* 316 */       this.spellSession.ignore();
/*     */     }
/* 320 */     else if ("true".equals(getDoIgnoreAll())) {
/* 321 */       this.spellSession.ignoreAll();
/*     */     }
/*     */     else
/*     */     {
/* 325 */       if ("true".equals(getDoEdit()))
/*     */       {
/* 328 */         ActionContext.getContext().getSession().remove(getSpellSessionKey());
/*     */ 
/* 330 */         ForumMessage tempMessage = retrieveFromSession();
/*     */         try {
/* 332 */           tempMessage.setBody(this.spellSession.getText());
/*     */         }
/*     */         catch (UnauthorizedException ue) {
/* 335 */           return "error";
/*     */         }
/* 337 */         loadToSession(tempMessage);
/* 338 */         return "goback";
/*     */       }
/*     */ 
/* 342 */       if ("true".equals(getDoPostNow()))
/*     */       {
/* 344 */         ActionContext.getContext().getSession().remove(getSpellSessionKey());
/*     */ 
/* 346 */         ForumMessage tempMessage = retrieveFromSession();
/*     */         try {
/* 348 */           tempMessage.setBody(this.spellSession.getText());
/*     */         }
/*     */         catch (UnauthorizedException ue) {
/* 351 */           return "error";
/*     */         }
/* 353 */         loadToSession(tempMessage);
/*     */ 
/* 355 */         ServletActionContext.getRequest().setAttribute("partialURL", getPartialURL());
/* 356 */         return "post";
/*     */       }
/*     */     }
/*     */ 
/* 360 */     int result = this.spellSession.next();
/* 361 */     if (result == 16) {
/* 362 */       this.misspelledWords = true;
/*     */     }
/* 364 */     else if (result == 4) {
/* 365 */       this.doubleWords = true;
/*     */     }
/*     */ 
/* 368 */     ActionContext.getContext().getSession().put(getSpellSessionKey(), this.spellSession);
/*     */ 
/* 370 */     return "input";
/*     */   }
/*     */ 
/*     */   protected SpellSession getSpellSession() {
/* 374 */     return this.spellSession;
/*     */   }
/*     */ 
/*     */   private String getSpellSessionKey()
/*     */   {
/* 379 */     StringBuffer buf = new StringBuffer("jive.forums.spell-session");
/* 380 */     buf.append(getSessionSuffix());
/* 381 */     return buf.toString();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.SpellAction
 * JD-Core Version:    0.6.2
 */
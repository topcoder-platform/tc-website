/*     */ package com.jivesoftware.forum.action.setup;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.database.JNDIDataSourceProvider;
/*     */ import com.jivesoftware.util.JiveProperties;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import com.opensymphony.xwork.Preparable;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class JndiDatasourceSetupAction extends DatasourceSetupAction
/*     */   implements Preparable, Validateable
/*     */ {
/*     */   private String jndiName;
/*     */   private String jndiNameMode;
/*     */ 
/*     */   public String getJndiName()
/*     */   {
/*  33 */     return this.jndiName;
/*     */   }
/*     */ 
/*     */   public void setJndiName(String jndiName) {
/*  37 */     this.jndiName = jndiName;
/*     */   }
/*     */ 
/*     */   public String getJndiNameMode() {
/*  41 */     return this.jndiNameMode;
/*     */   }
/*     */ 
/*     */   public void setJndiNameMode(String jndiNameMode) {
/*  45 */     this.jndiNameMode = jndiNameMode;
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */     throws Exception
/*     */   {
/*  51 */     this.jndiName = JiveGlobals.getJiveProperty("database.JNDIProvider.name");
/*     */   }
/*     */ 
/*     */   public String doDefault() {
/*  55 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/*  56 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "in_progress");
/*  57 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "incomplete");
/*  58 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "incomplete");
/*  59 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "incomplete");
/*  60 */     return "input";
/*     */   }
/*     */ 
/*     */   public void validate() {
/*  64 */     if ((this.jndiNameMode == null) && (this.jndiName == null)) {
/*  65 */       addActionError(getText("setup.error.jndidatasource.valid_name"));
/*     */     }
/*  67 */     else if (("custom".equals(this.jndiNameMode)) && (this.jndiName == null))
/*  68 */       addActionError(getText("setup.error.jndidatasource.valid_name"));
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/*  73 */     String lookupName = null;
/*  74 */     if (((this.jndiNameMode == null) || ("custom".equals(this.jndiNameMode))) && (this.jndiName != null)) {
/*  75 */       lookupName = this.jndiName;
/*     */     }
/*     */     else {
/*  78 */       lookupName = this.jndiNameMode;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  83 */       JiveGlobals.setLocalProperty("connectionProvider.className", "com.jivesoftware.base.database.JNDIDataSourceProvider");
/*     */ 
/*  88 */       JiveGlobals.setLocalProperty("database.JNDIProvider.name", lookupName);
/*     */ 
/*  91 */       JNDIDataSourceProvider conProvider = new JNDIDataSourceProvider();
/*  92 */       conProvider.setProperty("name", lookupName);
/*     */ 
/*  95 */       ConnectionManager.setConnectionProvider(conProvider);
/*     */ 
/*  98 */       if ((hasErrors()) || (!testConnection())) {
/*  99 */         return "error";
/*     */       }
/*     */ 
/* 104 */       JiveProperties.getInstance().init();
/*     */     }
/*     */     catch (Exception e) {
/* 107 */       Log.error(e);
/* 108 */       addActionError(e.getMessage());
/* 109 */       return "error";
/*     */     }
/* 111 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/* 112 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/* 113 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "in_progress");
/* 114 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "incomplete");
/* 115 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "incomplete");
/* 116 */     return "next";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.JndiDatasourceSetupAction
 * JD-Core Version:    0.6.2
 */
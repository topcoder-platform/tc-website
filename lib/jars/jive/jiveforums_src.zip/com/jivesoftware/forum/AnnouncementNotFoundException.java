/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ public class AnnouncementNotFoundException extends Exception
/*    */ {
/*    */   public AnnouncementNotFoundException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AnnouncementNotFoundException(String msg)
/*    */   {
/* 27 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.AnnouncementNotFoundException
 * JD-Core Version:    0.6.2
 */
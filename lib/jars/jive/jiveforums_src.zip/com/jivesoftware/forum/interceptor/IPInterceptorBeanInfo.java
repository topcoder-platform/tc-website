/*    */ package com.jivesoftware.forum.interceptor;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class IPInterceptorBeanInfo extends JiveBeanInfo
/*    */ {
/* 22 */   public static final String[] PROPERTY_NAMES = { "banList", "emailAddress", "emailBody", "emailList", "emailName", "emailNotifyList", "emailSubject", "moderationList" };
/*    */ 
/*    */   public String[] getPropertyNames()
/*    */   {
/* 32 */     return PROPERTY_NAMES;
/*    */   }
/*    */ 
/*    */   public Class getBeanClass() {
/* 36 */     return IPInterceptor.class;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 40 */     return "IPInterceptor";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.IPInterceptorBeanInfo
 * JD-Core Version:    0.6.2
 */
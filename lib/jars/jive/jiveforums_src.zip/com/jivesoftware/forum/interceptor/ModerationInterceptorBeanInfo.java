/*    */ package com.jivesoftware.forum.interceptor;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class ModerationInterceptorBeanInfo extends JiveBeanInfo
/*    */ {
/* 23 */   public static final String[] PROPERTY_NAMES = { "alwaysModeratedUsers", "alwaysModeratedGroups", "neverModeratedUsers", "neverModeratedGroups" };
/*    */ 
/*    */   public Class getBeanClass()
/*    */   {
/* 32 */     return ModerationInterceptor.class;
/*    */   }
/*    */ 
/*    */   public String[] getPropertyNames() {
/* 36 */     return PROPERTY_NAMES;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 40 */     return "ModerationInterceptor";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.ModerationInterceptorBeanInfo
 * JD-Core Version:    0.6.2
 */
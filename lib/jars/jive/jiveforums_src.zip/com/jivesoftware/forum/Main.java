/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class Main extends com.jivesoftware.base.Main
/*    */ {
/*    */   public String getInfo()
/*    */   {
/* 22 */     return "Jive Forums " + Version.getEdition() + " " + Version.getVersionNumber();
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/* 26 */     Main main = new Main();
/* 27 */     System.out.println(main.getInfo());
/*    */     try {
/* 29 */       main.renderInfo();
/*    */     }
/*    */     catch (Exception e) {
/* 32 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.Main
 * JD-Core Version:    0.6.2
 */
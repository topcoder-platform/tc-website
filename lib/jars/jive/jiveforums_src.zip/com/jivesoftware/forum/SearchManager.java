package com.jivesoftware.forum;

import com.jivesoftware.base.util.TextExtractor;
import java.util.Date;

public abstract interface SearchManager
{
  public abstract boolean isSearchEnabled();

  public abstract void setSearchEnabled(boolean paramBoolean);

  public abstract boolean isAttachmentSearchEnabled();

  public abstract void setAttachmentSearchEnabled(boolean paramBoolean);

  public abstract TextExtractor[] getTextExtractors();

  public abstract void addTextExtractor(String paramString)
    throws ClassNotFoundException;

  public abstract void removeTextExtractor(String paramString)
    throws ClassNotFoundException;

  public abstract boolean isBusy();

  public abstract int getPercentComplete();

  public abstract int getTotalCount();

  public abstract int getCurrentCount();

  public abstract boolean isWildcardIgnored();

  public abstract void setWildcardIgnored(boolean paramBoolean);

  public abstract boolean isAutoIndexEnabled();

  public abstract void setAutoIndexEnabled(boolean paramBoolean);

  public abstract int getAutoIndexInterval();

  public abstract void setAutoIndexInterval(int paramInt);

  public abstract Date getLastIndexedDate();

  public abstract void addToIndex(ForumMessage paramForumMessage);

  public abstract void removeFromIndex(ForumMessage paramForumMessage);

  public abstract void removeFromIndex(ForumThread paramForumThread);

  public abstract void removeFromIndex(Forum paramForum);

  public abstract void updateIndex();

  public abstract void rebuildIndex();

  public abstract void optimize();

  public abstract boolean isFilterHTMLEnabled();

  public abstract void setFilterHTMLEnabled(boolean paramBoolean);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.SearchManager
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum;

import com.jivesoftware.base.FilterManager;
import com.jivesoftware.base.UnauthorizedException;
import com.jivesoftware.base.User;
import java.util.Iterator;

public abstract interface PrivateMessageManager
{
  public abstract boolean isPrivateMessagesEnabled();

  public abstract void setPrivateMessagesEnabled(boolean paramBoolean)
    throws UnauthorizedException;

  public abstract FilterManager getFilterManager();

  public abstract int getMaxMessagesPerUser();

  public abstract void setMaxMessagesPerUser(int paramInt)
    throws UnauthorizedException;

  public abstract int getMessageCount(User paramUser)
    throws UnauthorizedException;

  public abstract int getUnreadMessageCount(User paramUser)
    throws UnauthorizedException;

  public abstract int getFolderCount(User paramUser)
    throws UnauthorizedException;

  public abstract Iterator getFolders(User paramUser)
    throws UnauthorizedException;

  public abstract PrivateMessageFolder getFolder(User paramUser, int paramInt)
    throws PrivateMessageFolderNotFoundException, UnauthorizedException;

  public abstract PrivateMessageFolder createFolder(User paramUser, String paramString)
    throws UnauthorizedException;

  public abstract void deleteFolder(PrivateMessageFolder paramPrivateMessageFolder)
    throws UnauthorizedException;

  public abstract PrivateMessage getMessage(long paramLong)
    throws UnauthorizedException, PrivateMessageNotFoundException;

  public abstract PrivateMessage createMessage(User paramUser)
    throws UnauthorizedException;

  public abstract void saveMessageAsDraft(PrivateMessage paramPrivateMessage)
    throws UnauthorizedException, PrivateMessageRejectedException;

  public abstract void sendMessage(PrivateMessage paramPrivateMessage, User paramUser, boolean paramBoolean)
    throws UnauthorizedException, PrivateMessageRejectedException;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.PrivateMessageManager
 * JD-Core Version:    0.6.2
 */
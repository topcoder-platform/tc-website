package com.jivesoftware.forum;

import com.jivesoftware.base.AuthToken;
import com.jivesoftware.base.FilterManager;
import com.jivesoftware.base.Permissions;
import com.jivesoftware.base.PermissionsManager;
import com.jivesoftware.base.UnauthorizedException;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

public abstract interface ForumCategory
{
  public abstract long getID();

  public abstract String getName();

  public abstract void setName(String paramString)
    throws UnauthorizedException;

  public abstract String getDescription();

  public abstract void setDescription(String paramString)
    throws UnauthorizedException;

  public abstract Date getCreationDate();

  public abstract void setCreationDate(Date paramDate)
    throws UnauthorizedException;

  public abstract Date getModificationDate();

  public abstract void setModificationDate(Date paramDate)
    throws UnauthorizedException;

  public abstract String getProperty(String paramString);

  public abstract Collection getProperties(String paramString);

  public abstract void setProperty(String paramString1, String paramString2)
    throws UnauthorizedException;

  public abstract void deleteProperty(String paramString)
    throws UnauthorizedException;

  public abstract Iterator getPropertyNames();

  public abstract int getForumCount();

  public abstract int getForumCount(ResultFilter paramResultFilter);

  public abstract int getRecursiveForumCount();

  public abstract int getRecursiveForumCount(ResultFilter paramResultFilter);

  public abstract Iterator getForums();

  public abstract Iterator getForums(ResultFilter paramResultFilter);

  public abstract Iterator getRecursiveForums();

  public abstract Iterator getRecursiveForums(ResultFilter paramResultFilter);

  public abstract void setForumIndex(Forum paramForum, int paramInt)
    throws UnauthorizedException;

  public abstract void moveForum(Forum paramForum, ForumCategory paramForumCategory)
    throws UnauthorizedException;

  public abstract Iterator getPopularThreads();

  public abstract Iterator getThreads();

  public abstract Iterator getThreads(ResultFilter paramResultFilter);

  public abstract int getThreadCount();

  public abstract int getThreadCount(ResultFilter paramResultFilter);

  public abstract int getMessageCount();

  public abstract int getMessageCount(ResultFilter paramResultFilter);

  public abstract Iterator getMessages();

  public abstract Iterator getMessages(ResultFilter paramResultFilter);

  public abstract ForumMessage getLatestMessage();

  public abstract ForumCategory getParentCategory();

  public abstract int getCategoryCount();

  public abstract Iterator getCategories();

  public abstract Iterator getCategories(int paramInt1, int paramInt2);

  public abstract int getRecursiveCategoryCount();

  public abstract Iterator getRecursiveCategories();

  public abstract int getCategoryDepth();

  public abstract void setCategoryIndex(ForumCategory paramForumCategory, int paramInt)
    throws UnauthorizedException;

  public abstract void moveCategory(ForumCategory paramForumCategory1, ForumCategory paramForumCategory2)
    throws UnauthorizedException;

  public abstract ForumCategory createCategory(String paramString1, String paramString2)
    throws UnauthorizedException;

  public abstract void deleteCategory(ForumCategory paramForumCategory)
    throws UnauthorizedException;

  public abstract void deleteForum(Forum paramForum)
    throws UnauthorizedException;

  public abstract PermissionsManager getPermissionsManager()
    throws UnauthorizedException;

  public abstract FilterManager getFilterManager();

  public abstract InterceptorManager getInterceptorManager()
    throws UnauthorizedException;

  public abstract Permissions getPermissions(AuthToken paramAuthToken);

  public abstract boolean isAuthorized(long paramLong);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.ForumCategory
 * JD-Core Version:    0.6.2
 */
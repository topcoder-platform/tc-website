package com.jivesoftware.forum;

import com.jivesoftware.base.UnauthorizedException;
import com.jivesoftware.base.User;
import java.util.Date;
import java.util.Iterator;

public abstract interface Announcement
{
  public abstract long getID();

  public abstract int getContainerObjectType();

  public abstract long getContainerObjectID();

  public abstract User getUser();

  public abstract Date getStartDate();

  public abstract void setStartDate(Date paramDate)
    throws UnauthorizedException;

  public abstract Date getEndDate();

  public abstract void setEndDate(Date paramDate)
    throws UnauthorizedException;

  public abstract String getSubject();

  public abstract void setSubject(String paramString)
    throws UnauthorizedException;

  public abstract String getUnfilteredSubject();

  public abstract String getBody();

  public abstract void setBody(String paramString)
    throws UnauthorizedException;

  public abstract String getUnfilteredBody();

  public abstract int getAttachmentCount();

  public abstract void deleteAttachment(Attachment paramAttachment)
    throws AttachmentException, UnauthorizedException;

  public abstract Iterator getAttachments();

  public abstract String getProperty(String paramString);

  public abstract String getUnfilteredProperty(String paramString);

  public abstract void setProperty(String paramString1, String paramString2)
    throws UnauthorizedException;

  public abstract void deleteProperty(String paramString)
    throws UnauthorizedException;

  public abstract Iterator getPropertyNames();
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.Announcement
 * JD-Core Version:    0.6.2
 */
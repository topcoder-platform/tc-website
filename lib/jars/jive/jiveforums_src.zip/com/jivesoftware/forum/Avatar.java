package com.jivesoftware.forum;

import com.jivesoftware.base.UnauthorizedException;
import com.jivesoftware.base.User;
import java.util.Iterator;

public abstract interface Avatar
{
  public abstract long getID();

  public abstract int getModValue();

  public abstract Attachment getAttachment()
    throws AttachmentNotFoundException;

  public abstract String getProperty(String paramString);

  public abstract void setProperty(String paramString1, String paramString2)
    throws UnauthorizedException;

  public abstract void deleteProperty(String paramString)
    throws UnauthorizedException;

  public abstract Iterator getPropertyNames();

  public abstract User getOwner();

  public abstract void setModValue(int paramInt)
    throws UnauthorizedException;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.Avatar
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ public class PrivateMessageFolderNotFoundException extends Exception
/*    */ {
/*    */   public PrivateMessageFolderNotFoundException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PrivateMessageFolderNotFoundException(String msg)
/*    */   {
/* 23 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.PrivateMessageFolderNotFoundException
 * JD-Core Version:    0.6.2
 */
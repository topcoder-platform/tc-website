package com.jivesoftware.forum;

import com.jivesoftware.base.AuthToken;
import com.jivesoftware.base.UnauthorizedException;
import com.jivesoftware.base.User;
import java.io.InputStream;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

public abstract interface ForumMessage
{
  public abstract long getID();

  public abstract int getForumIndex();

  public abstract Date getCreationDate();

  public abstract void setCreationDate(Date paramDate)
    throws UnauthorizedException;

  public abstract Date getModificationDate();

  public abstract void setModificationDate(Date paramDate)
    throws UnauthorizedException;

  public abstract String getSubject();

  public abstract String getUnfilteredSubject();

  public abstract void setSubject(String paramString)
    throws UnauthorizedException;

  public abstract String getBody();

  public abstract String getUnfilteredBody();

  public abstract void setBody(String paramString)
    throws UnauthorizedException;

  public abstract User getUser();

  public abstract ForumMessage getParentMessage();

  public abstract Attachment createAttachment(String paramString1, String paramString2, InputStream paramInputStream)
    throws AttachmentException, UnauthorizedException;

  public abstract int getAttachmentCount();

  public abstract void deleteAttachment(Attachment paramAttachment)
    throws AttachmentException, UnauthorizedException;

  public abstract Iterator getAttachments();

  public abstract int getModerationValue();

  public abstract void setModerationValue(int paramInt, AuthToken paramAuthToken)
    throws UnauthorizedException;

  public abstract String getProperty(String paramString);

  public abstract Collection getProperties(String paramString);

  public abstract String getUnfilteredProperty(String paramString);

  public abstract void setProperty(String paramString1, String paramString2)
    throws UnauthorizedException;

  public abstract void deleteProperty(String paramString)
    throws UnauthorizedException;

  public abstract Iterator getPropertyNames();

  public abstract boolean isAnonymous();

  public abstract ForumThread getForumThread();

  public abstract Forum getForum();

  public abstract boolean isAuthorized(long paramLong);

  public abstract boolean isHtml();
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.ForumMessage
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ public class QuestionFilter
/*     */ {
/*     */   public static final int DESCENDING = 0;
/*     */   public static final int ASCENDING = 1;
/*     */   public static final int NULL_INT = 2147483524;
/*  42 */   private SortField sortField = SortField.creation_date;
/*  43 */   private int sortOrder = 0;
/*  44 */   private String sortPropertyName = null;
/*     */ 
/*  49 */   private int startIndex = 0;
/*     */ 
/*  55 */   private int numResults = 2147483524;
/*     */ 
/*  57 */   private long userID = 2147483524L;
/*     */   private Set resolutionStates;
/*  60 */   private List propertyNames = new ArrayList();
/*  61 */   private List propertyValues = new ArrayList();
/*  62 */   private Date creationDateRangeMin = null;
/*  63 */   private Date creationDateRangeMax = null;
/*  64 */   private Date resolutionDateRangeMin = null;
/*  65 */   private Date resolutionnDateRangeMax = null;
/*  66 */   private boolean groupByForum = false;
/*     */ 
/*     */   public QuestionFilter()
/*     */   {
/*  72 */     this.resolutionStates = new TreeSet();
/*  73 */     this.resolutionStates.add(Question.State.open);
/*  74 */     this.resolutionStates.add(Question.State.possibly_resolved);
/*  75 */     this.resolutionStates.add(Question.State.assumed_resolved);
/*  76 */     this.resolutionStates.add(Question.State.resolved);
/*     */   }
/*     */ 
/*     */   public Set getResolutionStates()
/*     */   {
/*  87 */     return this.resolutionStates;
/*     */   }
/*     */ 
/*     */   public void addResolutionState(Question.State resolutionState)
/*     */   {
/*  97 */     this.resolutionStates.add(resolutionState);
/*     */   }
/*     */ 
/*     */   public void removeResolutionState(Question.State resolutionState)
/*     */   {
/* 107 */     this.resolutionStates.remove(resolutionState);
/*     */   }
/*     */ 
/*     */   public void clearResolutionStates()
/*     */   {
/* 115 */     this.resolutionStates.clear();
/*     */   }
/*     */ 
/*     */   public long getUserID()
/*     */   {
/* 126 */     return this.userID;
/*     */   }
/*     */ 
/*     */   public void setUserID(long userID)
/*     */   {
/* 136 */     this.userID = userID;
/*     */   }
/*     */ 
/*     */   public void addProperty(String name, String value)
/*     */   {
/* 159 */     if (this.propertyNames.contains(name)) {
/* 160 */       int index = this.propertyNames.indexOf(name);
/* 161 */       this.propertyNames.remove(index);
/* 162 */       this.propertyValues.remove(index);
/*     */     }
/* 164 */     this.propertyNames.add(name);
/* 165 */     this.propertyValues.add(value);
/*     */   }
/*     */ 
/*     */   public int getPropertyCount()
/*     */   {
/* 174 */     return this.propertyNames.size();
/*     */   }
/*     */ 
/*     */   public String getPropertyName(int index)
/*     */   {
/* 186 */     if ((index >= 0) && (index < this.propertyNames.size())) {
/* 187 */       return (String)this.propertyNames.get(index);
/*     */     }
/*     */ 
/* 190 */     return null;
/*     */   }
/*     */ 
/*     */   public String getPropertyValue(int index)
/*     */   {
/* 203 */     if ((index >= 0) && (index < this.propertyValues.size())) {
/* 204 */       return (String)this.propertyValues.get(index);
/*     */     }
/*     */ 
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */   public Date getCreationDateRangeMin()
/*     */   {
/* 220 */     return this.creationDateRangeMin;
/*     */   }
/*     */ 
/*     */   public void setCreationDateRangeMin(Date creationDateRangeMin)
/*     */   {
/* 239 */     this.creationDateRangeMin = creationDateRangeMin;
/*     */   }
/*     */ 
/*     */   public Date getCreationDateRangeMax()
/*     */   {
/* 251 */     return this.creationDateRangeMax;
/*     */   }
/*     */ 
/*     */   public void setCreationDateRangeMax(Date creationDateRangeMax)
/*     */   {
/* 270 */     this.creationDateRangeMax = creationDateRangeMax;
/*     */   }
/*     */ 
/*     */   public Date getResolutionDateRangeMin()
/*     */   {
/* 283 */     return this.resolutionDateRangeMin;
/*     */   }
/*     */ 
/*     */   public void setResolutionDateRangeMin(Date resolutionDateRangeMin)
/*     */   {
/* 302 */     this.resolutionDateRangeMin = resolutionDateRangeMin;
/*     */   }
/*     */ 
/*     */   public Date getResolutionDateRangeMax()
/*     */   {
/* 315 */     return this.resolutionnDateRangeMax;
/*     */   }
/*     */ 
/*     */   public void setResolutionDateRangeMax(Date resolutionnDateRangeMax)
/*     */   {
/* 334 */     this.resolutionnDateRangeMax = resolutionnDateRangeMax;
/*     */   }
/*     */ 
/*     */   public SortField getSortField()
/*     */   {
/* 346 */     return this.sortField;
/*     */   }
/*     */ 
/*     */   public void setSortField(SortField sortField)
/*     */   {
/* 358 */     this.sortField = sortField;
/*     */   }
/*     */ 
/*     */   public String getSortPropertyName()
/*     */   {
/* 368 */     return this.sortPropertyName;
/*     */   }
/*     */ 
/*     */   public void setSortPropertyName(String sortPropertyName)
/*     */   {
/* 379 */     this.sortPropertyName = sortPropertyName;
/*     */   }
/*     */ 
/*     */   public int getSortOrder()
/*     */   {
/* 390 */     return this.sortOrder;
/*     */   }
/*     */ 
/*     */   public void setSortOrder(int sortOrder)
/*     */   {
/* 401 */     if ((sortOrder != 1) && (sortOrder != 0)) {
/* 402 */       throw new IllegalArgumentException();
/*     */     }
/* 404 */     this.sortOrder = sortOrder;
/*     */   }
/*     */ 
/*     */   public boolean isGroupByForum()
/*     */   {
/* 413 */     return this.groupByForum;
/*     */   }
/*     */ 
/*     */   public void setGroupByForum(boolean groupByForum)
/*     */   {
/* 422 */     this.groupByForum = groupByForum;
/*     */   }
/*     */ 
/*     */   public int getNumResults()
/*     */   {
/* 435 */     return this.numResults;
/*     */   }
/*     */ 
/*     */   public void setNumResults(int numResults)
/*     */   {
/* 444 */     if ((numResults != 2147483524) && (numResults < 0)) {
/* 445 */       throw new IllegalArgumentException("numResults cannot be less than 0.");
/*     */     }
/* 447 */     this.numResults = numResults;
/*     */   }
/*     */ 
/*     */   public int getStartIndex()
/*     */   {
/* 456 */     return this.startIndex;
/*     */   }
/*     */ 
/*     */   public void setStartIndex(int startIndex)
/*     */   {
/* 468 */     if (startIndex < 0) {
/* 469 */       throw new IllegalArgumentException("A start index less than 0 is not valid.");
/*     */     }
/* 471 */     this.startIndex = startIndex;
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 478 */     QuestionFilter clonedFilter = new QuestionFilter();
/* 479 */     clonedFilter.setCreationDateRangeMax(new Date(getCreationDateRangeMax().getTime()));
/* 480 */     clonedFilter.setCreationDateRangeMin(new Date(getCreationDateRangeMin().getTime()));
/* 481 */     clonedFilter.setResolutionDateRangeMax(getResolutionDateRangeMax());
/* 482 */     clonedFilter.setResolutionDateRangeMin(getResolutionDateRangeMin());
/* 483 */     clonedFilter.setNumResults(getNumResults());
/* 484 */     clonedFilter.setSortField(getSortField());
/* 485 */     clonedFilter.setSortOrder(getSortOrder());
/* 486 */     clonedFilter.setSortPropertyName(getSortPropertyName());
/* 487 */     clonedFilter.setStartIndex(getStartIndex());
/* 488 */     clonedFilter.setUserID(getUserID());
/*     */ 
/* 490 */     clonedFilter.removeResolutionState(Question.State.open);
/* 491 */     clonedFilter.removeResolutionState(Question.State.possibly_resolved);
/* 492 */     clonedFilter.removeResolutionState(Question.State.assumed_resolved);
/* 493 */     clonedFilter.removeResolutionState(Question.State.resolved);
/*     */ 
/* 495 */     for (Iterator i = getResolutionStates().iterator(); i.hasNext(); ) {
/* 496 */       clonedFilter.addResolutionState((Question.State)i.next());
/*     */     }
/* 498 */     return clonedFilter;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object) {
/* 502 */     if (this == object) {
/* 503 */       return true;
/*     */     }
/* 505 */     if ((object != null) && ((object instanceof ResultFilter))) {
/* 506 */       QuestionFilter o = (QuestionFilter)object;
/* 507 */       return (this.sortField == o.sortField) && (this.sortOrder == o.sortOrder) && (((this.sortPropertyName == null) && (o.sortPropertyName == null)) || ((this.sortPropertyName.equals(o.sortPropertyName)) && (this.userID == o.userID) && (this.propertyNames.equals(o.propertyNames)) && (this.propertyValues.equals(o.propertyValues)) && (((this.creationDateRangeMin == null) && (o.creationDateRangeMin == null)) || ((this.creationDateRangeMin.equals(o.creationDateRangeMin)) && (((this.creationDateRangeMax == null) && (o.creationDateRangeMax == null)) || ((this.creationDateRangeMax.equals(o.creationDateRangeMax)) && (((this.resolutionDateRangeMin == null) && (o.resolutionDateRangeMin == null)) || ((this.resolutionDateRangeMin.equals(o.resolutionDateRangeMin)) && (((this.resolutionnDateRangeMax == null) && (o.resolutionnDateRangeMax == null)) || ((this.resolutionnDateRangeMax.equals(o.resolutionnDateRangeMax)) && (this.resolutionStates == o.resolutionStates)))))))))));
/*     */     }
/*     */ 
/* 526 */     return false;
/*     */   }
/*     */ 
/*     */   public static class SortField
/*     */   {
/* 535 */     public static final SortField creation_date = new SortField("creation_date");
/* 536 */     public static final SortField resolution_date = new SortField("resolution_date");
/* 537 */     public static final SortField resolution_state = new SortField("resolution_state");
/* 538 */     public static final SortField extended_property = new SortField("extended_property");
/*     */     private String value;
/*     */ 
/*     */     private SortField(String value)
/*     */     {
/* 543 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 547 */       return this.value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.QuestionFilter
 * JD-Core Version:    0.6.2
 */
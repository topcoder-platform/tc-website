/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ public class PrivateMessageNotFoundException extends Exception
/*    */ {
/*    */   public PrivateMessageNotFoundException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PrivateMessageNotFoundException(String msg)
/*    */   {
/* 28 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.PrivateMessageNotFoundException
 * JD-Core Version:    0.6.2
 */
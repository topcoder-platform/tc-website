package com.jivesoftware.forum;

import com.jivesoftware.base.UnauthorizedException;
import com.jivesoftware.base.User;
import java.io.InputStream;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

public abstract interface PrivateMessage
{
  public abstract long getID();

  public abstract Date getDate();

  public abstract PrivateMessageFolder getFolder();

  public abstract String getSubject();

  public abstract String getUnfilteredSubject();

  public abstract void setSubject(String paramString)
    throws UnauthorizedException;

  public abstract String getBody();

  public abstract String getUnfilteredBody();

  public abstract void setBody(String paramString)
    throws UnauthorizedException;

  public abstract User getSender();

  public abstract User getRecipient();

  public abstract boolean isRead();

  public abstract void setRead(boolean paramBoolean);

  public abstract Attachment createAttachment(String paramString1, String paramString2, InputStream paramInputStream)
    throws IllegalStateException, AttachmentException, UnauthorizedException;

  public abstract int getAttachmentCount();

  public abstract Iterator getAttachments();

  public abstract void deleteAttachment(Attachment paramAttachment)
    throws AttachmentException, UnauthorizedException;

  public abstract String getProperty(String paramString);

  public abstract Collection getProperties(String paramString);

  public abstract String getUnfilteredProperty(String paramString);

  public abstract void setProperty(String paramString1, String paramString2)
    throws UnauthorizedException;

  public abstract void deleteProperty(String paramString)
    throws UnauthorizedException;

  public abstract Iterator getPropertyNames();

  public abstract boolean isAuthorized(long paramLong);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.PrivateMessage
 * JD-Core Version:    0.6.2
 */
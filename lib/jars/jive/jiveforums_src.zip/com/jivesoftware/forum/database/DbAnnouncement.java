/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.FilterManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.database.sequence.SequenceManager;
/*     */ import com.jivesoftware.forum.Announcement;
/*     */ import com.jivesoftware.forum.AnnouncementNotFoundException;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.AttachmentException;
/*     */ import com.jivesoftware.forum.AttachmentNotFoundException;
/*     */ import com.jivesoftware.forum.event.AnnouncementEvent;
/*     */ import com.jivesoftware.forum.event.AnnouncementEventDispatcher;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.Cacheable;
/*     */ import com.jivesoftware.util.ExtendedPropertyUtils;
/*     */ import com.jivesoftware.util.ExternalizableLiteUtil;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import com.tangosol.io.ExternalizableLite;
/*     */ import com.tangosol.util.ExternalizableHelper;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DbAnnouncement
/*     */   implements Announcement, Cacheable, ExternalizableLite
/*     */ {
/*     */   private static final String LOAD_ANNOUNCEMENT = "SELECT announcementID, objectType, objectID, userID, subject, body, startDate, endDate FROM jiveAnnounce WHERE announcementID=?";
/*     */   private static final String SAVE_ANNOUNCEMENT = "UPDATE jiveAnnounce SET subject=?, body=?, startDate=?, endDate=? WHERE announcementID=?";
/*     */   private static final String INSERT_ANNOUNCEMENT = "INSERT INTO jiveAnnounce(announcementID, objectType, objectID, userID, subject, body, startDate, endDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
/*     */   private static final String LOAD_PROPERTIES = "SELECT name, propValue FROM jiveAnnounceProp WHERE announcementID=?";
/*     */   private static final String INSERT_PROPERTY = "INSERT INTO jiveAnnounceProp (announcementID,name,propValue) VALUES (?,?,?)";
/*     */   private static final String UPDATE_PROPERTY = "UPDATE jiveAnnounceProp SET propValue=? WHERE name=? AND announcementID=?";
/*     */   private static final String DELETE_PROPERTY = "DELETE FROM jiveAnnounceProp WHERE announcementID=? AND name=?";
/*     */   private static final String LOAD_ATTACHMENTS = "SELECT attachmentID FROM jiveAttachment WHERE objectType=22 AND objectID=?";
/*     */   private static final long serialVersionUID = 1L;
/*  64 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */ 
/*  66 */   private long id = -1L;
/*     */   private int objectType;
/*     */   private long objectID;
/*     */   private long userID;
/*  70 */   private String subject = "";
/*  71 */   private String body = "";
/*     */   private Date startDate;
/*     */   private Date endDate;
/*  75 */   private Map properties = null;
/*     */   private LongList attachments;
/*  80 */   private String filteredSubject = null;
/*  81 */   private String filteredBody = null;
/*  82 */   private Map filteredProperties = null;
/*     */ 
/*  89 */   private boolean readyToSave = false;
/*     */ 
/*     */   public DbAnnouncement(long announcementID)
/*     */     throws AnnouncementNotFoundException
/*     */   {
/*  97 */     this.id = announcementID;
/*  98 */     loadFromDb();
/*  99 */     this.readyToSave = true;
/*     */   }
/*     */ 
/*     */   public DbAnnouncement(int objectType, long objectID, long userID) {
/* 103 */     this.objectType = objectType;
/* 104 */     this.objectID = objectID;
/* 105 */     this.userID = userID;
/* 106 */     this.startDate = new Date(CacheFactory.currentTime);
/* 107 */     this.endDate = null;
/* 108 */     this.properties = new Hashtable();
/* 109 */     this.attachments = new LongList();
/*     */   }
/*     */ 
/*     */   public DbAnnouncement()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void readExternal(DataInput in) throws IOException
/*     */   {
/* 118 */     this.id = ExternalizableHelper.readLong(in);
/* 119 */     this.objectType = ExternalizableHelper.readInt(in);
/* 120 */     this.objectID = ExternalizableHelper.readLong(in);
/* 121 */     this.userID = ExternalizableHelper.readLong(in);
/* 122 */     this.subject = ExternalizableHelper.readSafeUTF(in);
/* 123 */     this.body = ExternalizableHelper.readSafeUTF(in);
/* 124 */     boolean isNull = in.readBoolean();
/* 125 */     if (!isNull) {
/* 126 */       this.startDate = new Date(in.readLong());
/*     */     }
/* 128 */     isNull = in.readBoolean();
/* 129 */     if (!isNull) {
/* 130 */       this.endDate = new Date(in.readLong());
/*     */     }
/*     */ 
/* 133 */     this.properties = ExternalizableLiteUtil.readStringMap(in);
/* 134 */     this.attachments = ExternalizableLiteUtil.readLongList(in);
/* 135 */     this.filteredSubject = ExternalizableHelper.readSafeUTF(in);
/* 136 */     this.filteredBody = ExternalizableHelper.readSafeUTF(in);
/* 137 */     this.filteredProperties = ExternalizableLiteUtil.readStringMap(in);
/* 138 */     this.readyToSave = in.readBoolean();
/*     */   }
/*     */ 
/*     */   public void writeExternal(DataOutput out) throws IOException {
/* 142 */     ExternalizableHelper.writeLong(out, this.id);
/* 143 */     ExternalizableHelper.writeInt(out, this.objectType);
/* 144 */     ExternalizableHelper.writeLong(out, this.objectID);
/* 145 */     ExternalizableHelper.writeLong(out, this.userID);
/* 146 */     ExternalizableHelper.writeSafeUTF(out, this.subject);
/* 147 */     ExternalizableHelper.writeSafeUTF(out, this.body);
/* 148 */     out.writeBoolean(this.startDate == null);
/* 149 */     if (this.startDate != null) {
/* 150 */       out.writeLong(this.startDate.getTime());
/*     */     }
/* 152 */     out.writeBoolean(this.endDate == null);
/* 153 */     if (this.endDate != null) {
/* 154 */       out.writeLong(this.endDate.getTime());
/*     */     }
/* 156 */     ExternalizableLiteUtil.writeStringMap(out, this.properties);
/* 157 */     ExternalizableLiteUtil.writeLongList(out, this.attachments);
/* 158 */     ExternalizableHelper.writeSafeUTF(out, this.filteredSubject);
/* 159 */     ExternalizableHelper.writeSafeUTF(out, this.filteredBody);
/* 160 */     ExternalizableLiteUtil.writeStringMap(out, this.filteredProperties);
/* 161 */     out.writeBoolean(this.readyToSave);
/*     */   }
/*     */ 
/*     */   public long getID() {
/* 165 */     return this.id;
/*     */   }
/*     */ 
/*     */   public int getContainerObjectType() {
/* 169 */     return this.objectType;
/*     */   }
/*     */ 
/*     */   public long getContainerObjectID() {
/* 173 */     return this.objectID;
/*     */   }
/*     */ 
/*     */   public User getUser() {
/* 177 */     if (this.userID == -1L) {
/* 178 */       return null;
/*     */     }
/* 180 */     User user = null;
/*     */     try {
/* 182 */       user = FACTORY.getUserManager().getUser(this.userID);
/*     */     }
/*     */     catch (UserNotFoundException unfe) {
/* 185 */       Log.error(unfe);
/*     */     }
/* 187 */     return user;
/*     */   }
/*     */ 
/*     */   public Date getStartDate() {
/* 191 */     return this.startDate;
/*     */   }
/*     */ 
/*     */   public void setStartDate(Date startDate) {
/* 195 */     if (startDate == null) {
/* 196 */       throw new NullPointerException("Start date cannot be null");
/*     */     }
/* 198 */     if (this.startDate == startDate) {
/* 199 */       return;
/*     */     }
/* 201 */     if ((this.endDate != null) && (startDate.after(this.endDate))) {
/* 202 */       throw new IllegalArgumentException("Cannot set start date of " + startDate + " to after end date of " + this.endDate);
/*     */     }
/*     */ 
/* 205 */     Date now = new Date();
/* 206 */     if (now.getTime() > startDate.getTime()) {
/* 207 */       startDate = now;
/*     */     }
/* 209 */     this.startDate = startDate;
/* 210 */     if (!this.readyToSave) {
/* 211 */       return;
/*     */     }
/* 213 */     saveToDb();
/*     */ 
/* 216 */     String key = this.objectType + "-" + this.objectID;
/* 217 */     FACTORY.cacheManager.announcementRemove(key);
/*     */   }
/*     */ 
/*     */   public Date getEndDate() {
/* 221 */     return this.endDate;
/*     */   }
/*     */ 
/*     */   public void setEndDate(Date endDate) throws UnauthorizedException {
/* 225 */     if (this.endDate == endDate) {
/* 226 */       return;
/*     */     }
/* 228 */     if ((endDate != null) && (endDate.before(this.startDate))) {
/* 229 */       throw new IllegalArgumentException("Cannot set end date of " + endDate + " to before start date of " + this.startDate);
/*     */     }
/*     */ 
/* 232 */     this.endDate = endDate;
/* 233 */     if (!this.readyToSave) {
/* 234 */       return;
/*     */     }
/* 236 */     saveToDb();
/*     */ 
/* 239 */     String key = this.objectType + "-" + this.objectID;
/* 240 */     FACTORY.cacheManager.announcementRemove(key);
/*     */   }
/*     */ 
/*     */   public String getSubject() {
/* 244 */     if (this.filteredSubject == null) {
/* 245 */       FilterManager filterManager = FACTORY.getFilterManager();
/* 246 */       this.filteredSubject = filterManager.applyFilters(this, 8L, this.subject);
/*     */     }
/* 248 */     return this.filteredSubject;
/*     */   }
/*     */ 
/*     */   public void setSubject(String subject) throws UnauthorizedException
/*     */   {
/* 253 */     if (subject == null) {
/* 254 */       throw new IllegalArgumentException("Subject cannot be null");
/*     */     }
/*     */ 
/* 258 */     if (this.subject.equals(subject)) {
/* 259 */       return;
/*     */     }
/*     */ 
/* 262 */     this.subject = subject;
/*     */ 
/* 264 */     this.filteredSubject = null;
/*     */ 
/* 266 */     if (!this.readyToSave) {
/* 267 */       return;
/*     */     }
/*     */ 
/* 271 */     saveToDb();
/*     */ 
/* 274 */     FACTORY.cacheManager.announcementPut(this.id, this);
/*     */ 
/* 277 */     AnnouncementEvent event = new AnnouncementEvent(152, this, Collections.EMPTY_MAP);
/*     */ 
/* 279 */     AnnouncementEventDispatcher.getInstance().dispatchEvent(event);
/*     */   }
/*     */ 
/*     */   public String getUnfilteredSubject() {
/* 283 */     return this.subject;
/*     */   }
/*     */ 
/*     */   public String getBody()
/*     */   {
/* 288 */     if (this.filteredBody == null) {
/* 289 */       this.filteredBody = FACTORY.getFilterManager().applyFilters(this, 16L, this.body);
/*     */     }
/*     */ 
/* 292 */     return this.filteredBody;
/*     */   }
/*     */ 
/*     */   public String getUnfilteredBody() {
/* 296 */     return this.body;
/*     */   }
/*     */ 
/*     */   public void setBody(String body) throws UnauthorizedException
/*     */   {
/* 301 */     if (body == null) {
/* 302 */       throw new IllegalArgumentException("Body cannot be null");
/*     */     }
/*     */ 
/* 306 */     if (body.equals(this.body)) {
/* 307 */       return;
/*     */     }
/*     */ 
/* 311 */     this.body = body;
/*     */ 
/* 313 */     this.filteredBody = null;
/*     */ 
/* 315 */     if (!this.readyToSave) {
/* 316 */       return;
/*     */     }
/*     */ 
/* 320 */     saveToDb();
/*     */ 
/* 323 */     FACTORY.cacheManager.announcementPut(this.id, this);
/*     */ 
/* 326 */     AnnouncementEvent event = new AnnouncementEvent(152, this, Collections.EMPTY_MAP);
/*     */ 
/* 328 */     AnnouncementEventDispatcher.getInstance().dispatchEvent(event);
/*     */   }
/*     */ 
/*     */   public int getAttachmentCount() {
/* 332 */     if (this.attachments == null) {
/* 333 */       getAttachments();
/*     */     }
/* 335 */     synchronized (this.attachments) {
/* 336 */       return this.attachments.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteAttachment(Attachment attachment) throws AttachmentException
/*     */   {
/* 342 */     if (!this.readyToSave) {
/* 343 */       if (this.attachments == null) {
/* 344 */         getAttachments();
/*     */       }
/* 346 */       synchronized (this.attachments) {
/* 347 */         int index = this.attachments.indexOf(attachment.getID());
/* 348 */         if (index >= 0) {
/* 349 */           this.attachments.remove(index);
/*     */         }
/*     */         else
/*     */         {
/* 353 */           throw new IllegalArgumentException("Attachment does not belong to message");
/*     */         }
/* 355 */         return;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 360 */     DbAttachment dbAttachment = null;
/* 361 */     if ((attachment instanceof DbAttachment))
/* 362 */       dbAttachment = (DbAttachment)attachment;
/*     */     else {
/*     */       try
/*     */       {
/* 366 */         dbAttachment = FACTORY.cacheManager.getAttachment(attachment.getID());
/*     */       }
/*     */       catch (AttachmentNotFoundException anfe) {
/* 369 */         throw new AttachmentException(3, anfe, attachment.getName());
/*     */       }
/*     */     }
/*     */ 
/* 373 */     if (dbAttachment.getObjectID() != this.id) {
/* 374 */       throw new IllegalArgumentException("Attachment does not belong to message.");
/*     */     }
/* 376 */     Connection con = null;
/*     */     try {
/* 378 */       con = ConnectionManager.getConnection();
/* 379 */       dbAttachment.delete(con);
/* 380 */       this.attachments = null;
/*     */ 
/* 382 */       FACTORY.cacheManager.announcementPut(this.id, this);
/*     */     }
/*     */     catch (Exception e) {
/* 385 */       throw new AttachmentException(3, e, attachment.getName());
/*     */     }
/*     */     finally {
/* 388 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Iterator getAttachments() {
/* 393 */     if (this.attachments == null) {
/* 394 */       LongList attachmentList = new LongList();
/* 395 */       Connection con = null;
/* 396 */       PreparedStatement pstmt = null;
/*     */       try {
/* 398 */         con = ConnectionManager.getConnection();
/* 399 */         pstmt = con.prepareStatement("SELECT attachmentID FROM jiveAttachment WHERE objectType=22 AND objectID=?");
/* 400 */         pstmt.setLong(1, this.id);
/* 401 */         ResultSet rs = pstmt.executeQuery();
/* 402 */         while (rs.next()) {
/* 403 */           attachmentList.add(rs.getLong(1));
/*     */         }
/* 405 */         rs.close();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 408 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 411 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/* 413 */       this.attachments = attachmentList;
/*     */     }
/* 415 */     return new DatabaseObjectIterator(13, this.attachments.toArray(), FACTORY);
/*     */   }
/*     */ 
/*     */   public String getProperty(String name) {
/* 419 */     if (this.properties == null) {
/* 420 */       loadPropertiesFromDb();
/*     */     }
/*     */ 
/* 423 */     if (this.filteredProperties == null) {
/* 424 */       Hashtable props = new Hashtable();
/* 425 */       FilterManager filterManager = FACTORY.getFilterManager();
/* 426 */       for (Iterator i = getPropertyNames(); i.hasNext(); ) {
/* 427 */         String propName = (String)i.next();
/* 428 */         String filteredValue = filterManager.applyFilters(this, 4L, (String)this.properties.get(propName));
/*     */ 
/* 430 */         props.put(propName, filteredValue);
/*     */       }
/* 432 */       this.filteredProperties = props;
/*     */     }
/*     */ 
/* 435 */     return (String)this.filteredProperties.get(name);
/*     */   }
/*     */ 
/*     */   public String getUnfilteredProperty(String name) {
/* 439 */     if (this.properties == null) {
/* 440 */       loadPropertiesFromDb();
/*     */     }
/* 442 */     return (String)this.properties.get(name);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value) {
/* 446 */     if (this.properties == null) {
/* 447 */       loadPropertiesFromDb();
/*     */     }
/*     */ 
/* 450 */     value = ExtendedPropertyUtils.validateExtendedProperty(name, value);
/*     */ 
/* 452 */     if (this.properties.containsKey(name))
/*     */     {
/* 455 */       if (!value.equals(this.properties.get(name))) {
/* 456 */         this.properties.put(name, value);
/* 457 */         updatePropertyInDb(name, value);
/*     */ 
/* 459 */         this.filteredProperties = null;
/*     */ 
/* 461 */         FACTORY.cacheManager.announcementPut(this.id, this);
/*     */ 
/* 464 */         AnnouncementEvent event = new AnnouncementEvent(152, this, Collections.EMPTY_MAP);
/*     */ 
/* 466 */         AnnouncementEventDispatcher.getInstance().dispatchEvent(event);
/*     */       }
/*     */     } else {
/* 469 */       this.properties.put(name, value);
/* 470 */       Connection con = null;
/*     */       try {
/* 472 */         con = ConnectionManager.getConnection();
/* 473 */         insertPropertyIntoDb(name, value, con);
/*     */       }
/*     */       catch (SQLException sqle) {
/* 476 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 479 */         ConnectionManager.closeConnection(con);
/*     */       }
/*     */ 
/* 482 */       this.filteredProperties = null;
/*     */ 
/* 484 */       FACTORY.cacheManager.announcementPut(this.id, this);
/*     */ 
/* 487 */       AnnouncementEvent event = new AnnouncementEvent(152, this, Collections.EMPTY_MAP);
/*     */ 
/* 489 */       AnnouncementEventDispatcher.getInstance().dispatchEvent(event);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) {
/* 494 */     if (this.properties == null) {
/* 495 */       loadPropertiesFromDb();
/*     */     }
/*     */ 
/* 498 */     if (this.properties.containsKey(name)) {
/* 499 */       this.properties.remove(name);
/*     */ 
/* 501 */       deletePropertyFromDb(name);
/*     */ 
/* 503 */       this.filteredProperties = null;
/* 504 */       FACTORY.cacheManager.announcementPut(this.id, this);
/*     */ 
/* 507 */       AnnouncementEvent event = new AnnouncementEvent(152, this, Collections.EMPTY_MAP);
/*     */ 
/* 509 */       AnnouncementEventDispatcher.getInstance().dispatchEvent(event);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames() {
/* 514 */     if (this.properties == null) {
/* 515 */       loadPropertiesFromDb();
/*     */     }
/* 517 */     return Collections.unmodifiableSet(this.properties.keySet()).iterator();
/*     */   }
/*     */ 
/*     */   public int getCachedSize() {
/* 521 */     return 0;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 525 */     return "[" + this.id + "] " + this.subject;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 529 */     return (int)this.id;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object) {
/* 533 */     if (this == object) {
/* 534 */       return true;
/*     */     }
/* 536 */     if ((object != null) && ((object instanceof ExternalizableLite))) {
/* 537 */       return this.id == ((ExternalizableLite)object).getID();
/*     */     }
/*     */ 
/* 540 */     return false;
/*     */   }
/*     */ 
/*     */   private void loadFromDb()
/*     */     throws AnnouncementNotFoundException
/*     */   {
/* 549 */     Connection con = null;
/* 550 */     PreparedStatement pstmt = null;
/*     */     try {
/* 552 */       con = ConnectionManager.getConnection();
/* 553 */       pstmt = con.prepareStatement("SELECT announcementID, objectType, objectID, userID, subject, body, startDate, endDate FROM jiveAnnounce WHERE announcementID=?");
/* 554 */       pstmt.setLong(1, this.id);
/*     */ 
/* 556 */       ResultSet rs = pstmt.executeQuery();
/* 557 */       if (!rs.next()) {
/* 558 */         throw new AnnouncementNotFoundException("Announcement " + this.id + " could not be loaded from the database.");
/*     */       }
/*     */ 
/* 561 */       this.id = rs.getLong(1);
/* 562 */       this.objectType = rs.getInt(2);
/* 563 */       this.objectID = rs.getLong(3);
/* 564 */       if (rs.wasNull()) {
/* 565 */         this.objectID = -1L;
/*     */       }
/* 567 */       this.userID = rs.getLong(4);
/* 568 */       this.subject = rs.getString(5);
/* 569 */       if (rs.wasNull()) {
/* 570 */         this.subject = "";
/*     */       }
/*     */ 
/* 573 */       this.body = ConnectionManager.getLargeTextField(rs, 6);
/* 574 */       if (rs.wasNull()) {
/* 575 */         this.body = "";
/*     */       }
/* 577 */       this.startDate = new Date(rs.getLong(7));
/*     */ 
/* 579 */       long eDate = rs.getLong(8);
/* 580 */       if (eDate != 0L) {
/* 581 */         this.endDate = new Date(eDate);
/*     */       }
/* 583 */       rs.close();
/* 584 */       pstmt.close();
/*     */ 
/* 587 */       LongList attachmentList = new LongList();
/* 588 */       pstmt = con.prepareStatement("SELECT attachmentID FROM jiveAttachment WHERE objectType=22 AND objectID=?");
/* 589 */       pstmt.setLong(1, this.id);
/* 590 */       rs = pstmt.executeQuery();
/* 591 */       while (rs.next()) {
/* 592 */         attachmentList.add(rs.getLong(1));
/*     */       }
/* 594 */       rs.close();
/* 595 */       this.attachments = attachmentList;
/*     */ 
/* 598 */       pstmt.close();
/* 599 */       this.properties = new Hashtable();
/* 600 */       pstmt = con.prepareStatement("SELECT name, propValue FROM jiveAnnounceProp WHERE announcementID=?");
/* 601 */       pstmt.setLong(1, this.id);
/* 602 */       rs = pstmt.executeQuery();
/* 603 */       while (rs.next())
/*     */       {
/* 605 */         this.properties.put(rs.getString(1), rs.getString(2));
/*     */       }
/* 607 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 610 */       throw new AnnouncementNotFoundException("Announcement with id " + this.id + " could not be loaded from the database.");
/*     */     }
/*     */     catch (NumberFormatException nfe)
/*     */     {
/* 615 */       Log.warn("WARNING: In DbAnnouncement.loadFromDb() -- there was an error parsing the dates returned from the database. Ensure that they're being stored correctly.");
/*     */ 
/* 618 */       throw new AnnouncementNotFoundException("Announcement with id " + this.id + " could not be loaded from the database.");
/*     */     }
/*     */     finally
/*     */     {
/* 623 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void saveToDb()
/*     */   {
/* 631 */     boolean abortTransaction = false;
/* 632 */     Connection con = null;
/* 633 */     PreparedStatement pstmt = null;
/*     */     try {
/* 635 */       con = ConnectionManager.getTransactionConnection();
/* 636 */       pstmt = con.prepareStatement("UPDATE jiveAnnounce SET subject=?, body=?, startDate=?, endDate=? WHERE announcementID=?");
/* 637 */       pstmt.setString(1, this.subject);
/*     */ 
/* 639 */       ConnectionManager.setLargeTextField(pstmt, 2, this.body);
/* 640 */       pstmt.setLong(3, this.startDate.getTime());
/* 641 */       if (this.endDate != null) {
/* 642 */         pstmt.setLong(4, this.endDate.getTime());
/*     */       }
/*     */       else {
/* 645 */         pstmt.setNull(4, 4);
/*     */       }
/* 647 */       pstmt.setLong(5, this.id);
/* 648 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (Exception e) {
/* 651 */       Log.error(e);
/* 652 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 655 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void insertIntoDb() {
/* 660 */     this.id = SequenceManager.nextID(22);
/* 661 */     Connection con = null;
/* 662 */     PreparedStatement pstmt = null;
/* 663 */     boolean abortTransaction = false;
/*     */     try {
/* 665 */       con = ConnectionManager.getTransactionConnection();
/* 666 */       pstmt = con.prepareStatement("INSERT INTO jiveAnnounce(announcementID, objectType, objectID, userID, subject, body, startDate, endDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
/* 667 */       pstmt.setLong(1, this.id);
/* 668 */       pstmt.setInt(2, this.objectType);
/* 669 */       if (this.objectID == -1L) {
/* 670 */         pstmt.setNull(3, 2);
/*     */       }
/*     */       else {
/* 673 */         pstmt.setLong(3, this.objectID);
/*     */       }
/* 675 */       pstmt.setLong(4, this.userID);
/* 676 */       pstmt.setString(5, this.subject);
/*     */ 
/* 678 */       ConnectionManager.setLargeTextField(pstmt, 6, this.body);
/* 679 */       pstmt.setLong(7, this.startDate.getTime());
/* 680 */       if (this.endDate != null) {
/* 681 */         pstmt.setLong(8, this.endDate.getTime());
/*     */       }
/*     */       else {
/* 684 */         pstmt.setNull(8, 4);
/*     */       }
/* 686 */       pstmt.execute();
/* 687 */       pstmt.close();
/*     */ 
/* 690 */       for (Iterator i = this.properties.keySet().iterator(); i.hasNext(); ) {
/* 691 */         String name = (String)i.next();
/* 692 */         String value = (String)this.properties.get(name);
/* 693 */         insertPropertyIntoDb(name, value, con);
/*     */       }
/*     */ 
/* 698 */       synchronized (this.attachments) {
/* 699 */         for (int i = 0; i < this.attachments.size(); i++)
/* 700 */           DbAttachment.setObjectID(this.attachments.get(i), this.id, con);
/*     */       }
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 705 */       abortTransaction = true;
/* 706 */       Log.error(e);
/*     */     }
/*     */     finally {
/* 709 */       ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*     */     }
/*     */ 
/* 714 */     this.readyToSave = true;
/*     */   }
/*     */ 
/*     */   private synchronized void loadPropertiesFromDb()
/*     */   {
/* 721 */     this.properties = new Hashtable();
/* 722 */     Connection con = null;
/* 723 */     PreparedStatement pstmt = null;
/*     */     try {
/* 725 */       con = ConnectionManager.getConnection();
/* 726 */       pstmt = con.prepareStatement("SELECT name, propValue FROM jiveAnnounceProp WHERE announcementID=?");
/* 727 */       pstmt.setLong(1, this.id);
/* 728 */       ResultSet rs = pstmt.executeQuery();
/* 729 */       while (rs.next()) {
/* 730 */         this.properties.put(rs.getString(1), rs.getString(2));
/*     */       }
/* 732 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 735 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 738 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void insertPropertyIntoDb(String name, String value, Connection con)
/*     */     throws SQLException
/*     */   {
/* 746 */     PreparedStatement pstmt = null;
/*     */     try {
/* 748 */       pstmt = con.prepareStatement("INSERT INTO jiveAnnounceProp (announcementID,name,propValue) VALUES (?,?,?)");
/* 749 */       pstmt.setLong(1, this.id);
/* 750 */       pstmt.setString(2, name);
/* 751 */       pstmt.setString(3, value);
/* 752 */       pstmt.executeUpdate();
/*     */     }
/*     */     finally {
/* 755 */       ConnectionManager.closePreparedStatement(pstmt);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updatePropertyInDb(String name, String value)
/*     */   {
/* 763 */     Connection con = null;
/* 764 */     PreparedStatement pstmt = null;
/* 765 */     boolean abortTransaction = false;
/*     */     try {
/* 767 */       con = ConnectionManager.getTransactionConnection();
/* 768 */       pstmt = con.prepareStatement("UPDATE jiveAnnounceProp SET propValue=? WHERE name=? AND announcementID=?");
/* 769 */       pstmt.setString(1, value);
/* 770 */       pstmt.setString(2, name);
/* 771 */       pstmt.setLong(3, this.id);
/* 772 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 775 */       Log.error(sqle);
/* 776 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 779 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void deletePropertyFromDb(String name)
/*     */   {
/* 787 */     Connection con = null;
/* 788 */     PreparedStatement pstmt = null;
/* 789 */     boolean abortTransaction = false;
/*     */     try {
/* 791 */       con = ConnectionManager.getTransactionConnection();
/* 792 */       pstmt = con.prepareStatement("DELETE FROM jiveAnnounceProp WHERE announcementID=? AND name=?");
/* 793 */       pstmt.setLong(1, this.id);
/* 794 */       pstmt.setString(2, name);
/* 795 */       pstmt.execute();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 798 */       Log.error(sqle);
/* 799 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 802 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbAnnouncement
 * JD-Core Version:    0.6.2
 */
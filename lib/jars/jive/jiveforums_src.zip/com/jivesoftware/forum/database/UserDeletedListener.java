/*    */ package com.jivesoftware.forum.database;
/*    */ 
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.base.User;
/*    */ import com.jivesoftware.base.database.ConnectionManager;
/*    */ import com.jivesoftware.base.event.UserEvent;
/*    */ import com.jivesoftware.base.event.UserListenerAdapter;
/*    */ import com.jivesoftware.util.LongList;
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class UserDeletedListener extends UserListenerAdapter
/*    */ {
/*    */   private static final String ALL_USER_MESSAGES = "SELECT messageID FROM jiveMessage WHERE userID=? ORDER BY modificationDate DESC";
/*    */   private static final String DELETE_USER_MESSAGES = "UPDATE jiveMessage SET userID=NULL WHERE userID=?";
/*    */   private static final String DELETE_USER_PERMS = "DELETE FROM jiveUserPerm WHERE userID=?";
/*    */ 
/*    */   public void userDeleted(UserEvent event)
/*    */   {
/* 39 */     long userID = event.getUser().getID();
/*    */ 
/* 42 */     LongList messages = new LongList();
/* 43 */     Connection con = null;
/* 44 */     PreparedStatement pstmt = null;
/*    */     try
/*    */     {
/* 47 */       con = ConnectionManager.getConnection();
/* 48 */       pstmt = con.prepareStatement("SELECT messageID FROM jiveMessage WHERE userID=? ORDER BY modificationDate DESC");
/* 49 */       pstmt.setLong(1, userID);
/* 50 */       ResultSet rs = pstmt.executeQuery();
/* 51 */       while (rs.next()) {
/* 52 */         messages.add(rs.getLong(1));
/*    */       }
/* 54 */       rs.close();
/*    */     }
/*    */     catch (SQLException e) {
/* 57 */       Log.error(e);
/* 58 */       event.setFailureException(e);
/*    */     }
/*    */     finally {
/* 61 */       ConnectionManager.closeConnection(pstmt, con);
/*    */     }
/*    */ 
/* 64 */     con = null;
/* 65 */     pstmt = null;
/* 66 */     boolean abortTransaction = false;
/*    */     try
/*    */     {
/* 69 */       con = ConnectionManager.getTransactionConnection();
/*    */ 
/* 71 */       pstmt = con.prepareStatement("UPDATE jiveMessage SET userID=NULL WHERE userID=?");
/* 72 */       pstmt.setLong(1, userID);
/* 73 */       pstmt.execute();
/* 74 */       pstmt.close();
/*    */ 
/* 76 */       pstmt = con.prepareStatement("DELETE FROM jiveUserPerm WHERE userID=?");
/* 77 */       pstmt.setLong(1, userID);
/* 78 */       pstmt.execute();
/*    */     }
/*    */     catch (Exception e) {
/* 81 */       Log.error(e);
/* 82 */       abortTransaction = true;
/* 83 */       event.setFailureException(e);
/*    */     }
/*    */     finally {
/* 86 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*    */     }
/*    */ 
/* 89 */     DbForumFactory factory = DbForumFactory.getInstance();
/*    */ 
/* 92 */     long[] messagesArray = messages.toArray();
/* 93 */     for (int i = 0; i < messagesArray.length; i++)
/* 94 */       factory.cacheManager.messageRemove(messagesArray[i]);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.UserDeletedListener
 * JD-Core Version:    0.6.2
 */
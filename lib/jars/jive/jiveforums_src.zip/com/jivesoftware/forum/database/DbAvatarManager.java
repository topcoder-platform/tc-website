/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.forum.Avatar;
/*     */ import com.jivesoftware.forum.AvatarException;
/*     */ import com.jivesoftware.forum.AvatarManager;
/*     */ import com.jivesoftware.forum.AvatarManagerFactory;
/*     */ import com.jivesoftware.forum.AvatarNotFoundException;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import java.io.InputStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class DbAvatarManager
/*     */   implements AvatarManager
/*     */ {
/*     */   public static final String PROPERTY_ALLOW_IMAGE_RESIZE = "avatars.allowImageResize";
/*     */   public static final String PROPERTY_MAX_ALLOWABLE_HEIGHT = "avatars.maxAllowableHeight";
/*     */   public static final String PROPERTY_MAX_ALLOWABLE_WIDTH = "avatars.maxAllowableWidth";
/*     */   public static final String PROPERTY_MAX_USER_AVATARS = "avatars.maxUserAvatars";
/*     */   public static final String PROPERTY_MOD_USER_AVATARS = "avatars.modUserAvatars";
/*     */   public static final int DEFAULT_HEIGHT = 50;
/*     */   public static final int DEFAULT_WIDTH = 50;
/*     */   private static final String ACTIVE_AVATAR = "SELECT avatarID FROM jiveAvatarUser WHERE userID = ?";
/*     */   private static final String USER_AVATARS = "SELECT avatarID FROM jiveAvatar WHERE ownerID = ?";
/*     */   private static final String USER_AVATAR_COUNT = "SELECT count(*) FROM jiveAvatar WHERE ownerID = ?";
/*     */   private static final String DELETE_FROM_AVATAR_USER = "DELETE FROM jiveAvatarUser WHERE avatarID = ?";
/*     */   private static final String DELETE_FROM_AVATAR_PROP = "DELETE FROM jiveAvatarProp WHERE avatarID = ?";
/*     */   private static final String DELETE_FROM_AVATAR = "DELETE FROM jiveAvatar WHERE avatarID = ?";
/*     */   private static final String GLOBAL_AVATARS = "SELECT avatarID FROM jiveAvatar WHERE ownerID IS NULL";
/*     */   private static final String SET_ACTIVE_AVATAR = "INSERT INTO jiveAvatarUser (userID, avatarID) VALUES (?, ?)";
/*     */   private static final String DELETE_SPECIFIC_AVATAR_USER = "DELETE FROM jiveAvatarUser WHERE userID = ?";
/*     */   private static final String MODERATION_AVATARS = "SELECT avatarID from jiveAvatar WHERE modValue < ? AND ownerID IS NOT NULL ORDER BY ownerID";
/*     */   private static final String MODERATION_AVATAR_COUNT = "SELECT COUNT(*) from jiveAvatar WHERE modValue < ? AND ownerID IS NOT NULL";
/*     */ 
/*     */   public Avatar createAvatar(User owner, String name, String contentType, InputStream in)
/*     */     throws UnauthorizedException, AvatarException
/*     */   {
/*  80 */     Avatar avatar = new DbAvatar(owner, name, contentType, in);
/*  81 */     AvatarManagerFactory.avatarCache.put(new Long(avatar.getID()), avatar);
/*     */ 
/*  83 */     LongList globals = (LongList)AvatarManagerFactory.avatarCache.get("_globals");
/*     */ 
/*  86 */     if ((globals != null) && (avatar.getOwner() == null)) {
/*  87 */       globals.add(avatar.getID());
/*  88 */       AvatarManagerFactory.avatarCache.put("_globals", globals);
/*     */     }
/*     */ 
/*  92 */     return avatar;
/*     */   }
/*     */ 
/*     */   public void setActiveAvatar(User user, Avatar avatar) throws UnauthorizedException {
/*  96 */     Connection con = null;
/*  97 */     PreparedStatement pstmt = null;
/*     */ 
/*  99 */     boolean abortTransaction = false;
/*     */     try {
/* 101 */       con = ConnectionManager.getTransactionConnection();
/*     */ 
/* 103 */       pstmt = con.prepareStatement("DELETE FROM jiveAvatarUser WHERE userID = ?");
/* 104 */       pstmt.setLong(1, user.getID());
/* 105 */       pstmt.executeUpdate();
/* 106 */       pstmt.close();
/*     */ 
/* 108 */       if (avatar != null) {
/* 109 */         pstmt = con.prepareStatement("INSERT INTO jiveAvatarUser (userID, avatarID) VALUES (?, ?)");
/* 110 */         pstmt.setLong(1, user.getID());
/* 111 */         pstmt.setLong(2, avatar.getID());
/* 112 */         pstmt.executeUpdate();
/*     */       }
/*     */     }
/*     */     catch (SQLException sqle) {
/* 116 */       Log.error(sqle);
/* 117 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 120 */       ConnectionManager.closePreparedStatement(pstmt);
/*     */       try
/*     */       {
/* 123 */         if (con != null)
/* 124 */           ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*     */       }
/*     */       catch (Exception e) {
/* 127 */         Log.error(e);
/*     */       }
/*     */     }
/* 130 */     if (avatar != null) {
/* 131 */       AvatarManagerFactory.addActiveAvatarToCache(avatar, user);
/*     */     }
/*     */     else
/*     */     {
/* 136 */       AvatarManagerFactory.activeAvatarCache.remove(new Long(user.getID()));
/*     */     }
/*     */   }
/*     */ 
/*     */   public Avatar getAvatar(long id) throws AvatarNotFoundException {
/* 141 */     Avatar avatar = (Avatar)AvatarManagerFactory.avatarCache.get(new Long(id));
/*     */ 
/* 143 */     if (avatar == null) {
/* 144 */       avatar = new DbAvatar(id);
/* 145 */       AvatarManagerFactory.avatarCache.put(new Long(id), avatar);
/*     */     }
/*     */ 
/* 148 */     return avatar;
/*     */   }
/*     */ 
/*     */   public Iterator getAvatars(User user) {
/* 152 */     Connection con = null;
/* 153 */     PreparedStatement pstmt = null;
/* 154 */     ResultSet rs = null;
/* 155 */     LongList longList = new LongList();
/*     */     try
/*     */     {
/* 158 */       con = ConnectionManager.getConnection();
/* 159 */       pstmt = con.prepareStatement("SELECT avatarID FROM jiveAvatar WHERE ownerID = ?");
/* 160 */       pstmt.setLong(1, user.getID());
/*     */ 
/* 162 */       rs = pstmt.executeQuery();
/* 163 */       while (rs.next())
/*     */         try {
/* 165 */           longList.add(rs.getLong(1));
/*     */         }
/*     */         catch (Exception e) {
/* 168 */           Log.error(e);
/*     */         }
/*     */     }
/*     */     catch (SQLException sqle)
/*     */     {
/* 173 */       Log.error(sqle);
/*     */     } finally {
/*     */       try {
/* 176 */         if (rs != null) rs.close(); 
/*     */       } catch (Exception e) { Log.error(e); }
/*     */ 
/* 179 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 183 */     return new AvatarIterator(longList.toArray());
/*     */   }
/*     */ 
/*     */   public int getAvatarCount(User user) {
/* 187 */     Connection con = null;
/* 188 */     PreparedStatement pstmt = null;
/* 189 */     ResultSet rs = null;
/* 190 */     int count = 0;
/*     */     try
/*     */     {
/* 193 */       con = ConnectionManager.getConnection();
/* 194 */       pstmt = con.prepareStatement("SELECT count(*) FROM jiveAvatar WHERE ownerID = ?");
/* 195 */       pstmt.setLong(1, user.getID());
/* 196 */       rs = pstmt.executeQuery();
/* 197 */       while (rs.next())
/* 198 */         count = rs.getInt(1);
/*     */     }
/*     */     catch (SQLException sqle)
/*     */     {
/* 202 */       Log.error(sqle);
/*     */     } finally {
/*     */       try {
/* 205 */         if (rs != null) rs.close(); 
/*     */       } catch (Exception e) { Log.error(e); }
/*     */ 
/* 208 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 212 */     return count;
/*     */   }
/*     */ 
/*     */   public Avatar getActiveAvatar(User user) {
/* 216 */     Avatar avatar = null;
/*     */ 
/* 219 */     Long avatarID = (Long)AvatarManagerFactory.activeAvatarCache.get(new Long(user.getID()));
/* 220 */     if (avatarID != null)
/*     */     {
/* 222 */       if (avatarID.longValue() == -2L) {
/* 223 */         return null;
/*     */       }
/*     */       try
/*     */       {
/* 227 */         avatar = getAvatar(avatarID.longValue());
/*     */       }
/*     */       catch (AvatarNotFoundException e) {
/* 230 */         Log.error(e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 235 */     if (avatar == null) {
/* 236 */       long id = -1L;
/*     */ 
/* 238 */       Connection con = null;
/* 239 */       PreparedStatement pstmt = null;
/* 240 */       ResultSet rs = null;
/*     */       try
/*     */       {
/* 243 */         con = ConnectionManager.getConnection();
/* 244 */         pstmt = con.prepareStatement("SELECT avatarID FROM jiveAvatarUser WHERE userID = ?");
/* 245 */         pstmt.setLong(1, user.getID());
/* 246 */         rs = pstmt.executeQuery();
/* 247 */         if (rs.next())
/*     */           try {
/* 249 */             id = rs.getLong(1);
/*     */           }
/*     */           catch (Exception e) {
/* 252 */             Log.error(e);
/*     */           }
/*     */       }
/*     */       catch (SQLException sqle)
/*     */       {
/* 257 */         Log.error(sqle);
/*     */       } finally {
/*     */         try {
/* 260 */           if (rs != null) rs.close(); 
/*     */         } catch (Exception e) { Log.error(e); }
/*     */ 
/* 263 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 268 */         if (id > 0L)
/* 269 */           avatar = getAvatar(id);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 273 */         Log.error(e);
/*     */       }
/*     */ 
/* 277 */       if (avatar != null) {
/* 278 */         AvatarManagerFactory.addActiveAvatarToCache(avatar, user);
/*     */       }
/*     */       else
/*     */       {
/* 282 */         AvatarManagerFactory.activeAvatarCache.put(new Long(user.getID()), new Long(-2L));
/*     */       }
/*     */     }
/*     */ 
/* 286 */     return avatar;
/*     */   }
/*     */ 
/*     */   public Iterator getGlobalAvatars() {
/* 290 */     LongList globals = (LongList)AvatarManagerFactory.avatarCache.get("_globals");
/*     */ 
/* 292 */     if (globals != null) {
/* 293 */       return new AvatarIterator(globals.toArray());
/*     */     }
/*     */ 
/* 297 */     globals = new LongList();
/*     */ 
/* 299 */     Connection con = null;
/* 300 */     PreparedStatement pstmt = null;
/* 301 */     ResultSet rs = null;
/*     */     try
/*     */     {
/* 304 */       con = ConnectionManager.getConnection();
/* 305 */       pstmt = con.prepareStatement("SELECT avatarID FROM jiveAvatar WHERE ownerID IS NULL");
/* 306 */       rs = pstmt.executeQuery();
/* 307 */       while (rs.next())
/*     */         try {
/* 309 */           globals.add(rs.getLong(1));
/*     */         }
/*     */         catch (Exception e) {
/* 312 */           Log.error(e);
/*     */         }
/*     */     }
/*     */     catch (SQLException sqle)
/*     */     {
/* 317 */       Log.error(sqle);
/*     */     } finally {
/*     */       try {
/* 320 */         if (rs != null) rs.close(); 
/*     */       } catch (Exception e) { Log.error(e); }
/*     */ 
/* 323 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 327 */     AvatarManagerFactory.avatarCache.put("_globals", globals);
/*     */ 
/* 329 */     return new AvatarIterator(globals.toArray());
/*     */   }
/*     */ 
/*     */   public void deleteAvatar(Avatar avatar) throws UnauthorizedException {
/* 333 */     Connection con = null;
/* 334 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 337 */       con = ConnectionManager.getConnection();
/* 338 */       pstmt = con.prepareStatement("DELETE FROM jiveAvatarProp WHERE avatarID = ?");
/* 339 */       pstmt.setLong(1, avatar.getID());
/* 340 */       pstmt.executeUpdate();
/*     */ 
/* 342 */       pstmt.close();
/*     */ 
/* 344 */       pstmt = con.prepareStatement("DELETE FROM jiveAvatarUser WHERE avatarID = ?");
/* 345 */       pstmt.setLong(1, avatar.getID());
/* 346 */       pstmt.executeUpdate();
/*     */ 
/* 348 */       pstmt.close();
/*     */ 
/* 350 */       pstmt = con.prepareStatement("DELETE FROM jiveAvatar WHERE avatarID = ?");
/* 351 */       pstmt.setLong(1, avatar.getID());
/* 352 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle)
/*     */     {
/* 356 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 359 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 363 */     AvatarManagerFactory.clearAvatarFromCache(avatar);
/*     */ 
/* 366 */     LongList globals = (LongList)AvatarManagerFactory.avatarCache.get("_globals");
/* 367 */     if ((globals != null) && (avatar.getOwner() == null))
/*     */     {
/* 369 */       int index = globals.indexOf(avatar.getID());
/*     */ 
/* 371 */       if ((index >= 0) && (index < globals.size())) {
/* 372 */         globals.remove(index);
/* 373 */         AvatarManagerFactory.avatarCache.put("_globals", globals);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setAvatarsEnabled(boolean enabled)
/*     */     throws UnauthorizedException
/*     */   {
/* 381 */     AvatarManagerFactory.setAvatarsEnabled(enabled);
/*     */   }
/*     */ 
/*     */   public boolean isAvatarsEnabled() {
/* 385 */     return AvatarManagerFactory.isAvatarsEnabled();
/*     */   }
/*     */ 
/*     */   public int getMaxAllowableHeight() {
/* 389 */     return JiveGlobals.getJiveIntProperty("avatars.maxAllowableHeight", 50);
/*     */   }
/*     */ 
/*     */   public void setMaxAllowableHeight(int height) throws UnauthorizedException {
/* 393 */     JiveGlobals.setJiveProperty("avatars.maxAllowableHeight", "" + height);
/*     */   }
/*     */ 
/*     */   public int getMaxAllowableWidth() {
/* 397 */     return JiveGlobals.getJiveIntProperty("avatars.maxAllowableWidth", 50);
/*     */   }
/*     */ 
/*     */   public void setMaxAllowableWidth(int width) throws UnauthorizedException {
/* 401 */     JiveGlobals.setJiveProperty("avatars.maxAllowableWidth", "" + width);
/*     */   }
/*     */ 
/*     */   public boolean isAllowImageResize() {
/* 405 */     return JiveGlobals.getJiveBooleanProperty("avatars.allowImageResize", true);
/*     */   }
/*     */ 
/*     */   public void setAllowImageResize(boolean isAllowImageResize) throws UnauthorizedException {
/* 409 */     JiveGlobals.setJiveProperty("avatars.allowImageResize", "" + isAllowImageResize);
/*     */   }
/*     */ 
/*     */   public int getMaxUserAvatars() {
/* 413 */     return JiveGlobals.getJiveIntProperty("avatars.maxUserAvatars", 0);
/*     */   }
/*     */ 
/*     */   public void setMaxUserAvatars(int max) throws UnauthorizedException {
/* 417 */     JiveGlobals.setJiveProperty("avatars.maxUserAvatars", String.valueOf(max));
/*     */   }
/*     */ 
/*     */   public boolean isModerateUserAvatars() {
/* 421 */     return JiveGlobals.getJiveBooleanProperty("avatars.modUserAvatars", true);
/*     */   }
/*     */ 
/*     */   public void setModerateUserAvatars(boolean moderateUserAvatars) throws UnauthorizedException {
/* 425 */     JiveGlobals.setJiveProperty("avatars.modUserAvatars", String.valueOf(moderateUserAvatars));
/*     */   }
/*     */ 
/*     */   public Iterator getModerationAvatars() {
/* 429 */     LongList modAvatars = new LongList();
/*     */ 
/* 431 */     Connection con = null;
/* 432 */     PreparedStatement pstmt = null;
/* 433 */     ResultSet rs = null;
/*     */     try
/*     */     {
/* 436 */       con = ConnectionManager.getConnection();
/* 437 */       pstmt = con.prepareStatement("SELECT avatarID from jiveAvatar WHERE modValue < ? AND ownerID IS NOT NULL ORDER BY ownerID");
/* 438 */       pstmt.setInt(1, 1);
/* 439 */       rs = pstmt.executeQuery();
/* 440 */       while (rs.next())
/*     */         try {
/* 442 */           modAvatars.add(rs.getLong(1));
/*     */         }
/*     */         catch (Exception e) {
/* 445 */           Log.error(e);
/*     */         }
/*     */     }
/*     */     catch (SQLException sqle)
/*     */     {
/* 450 */       Log.error(sqle);
/*     */     } finally {
/*     */       try {
/* 453 */         if (rs != null) rs.close(); 
/*     */       } catch (Exception e) { Log.error(e); }
/*     */ 
/* 456 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 460 */     return new AvatarIterator(modAvatars.toArray());
/*     */   }
/*     */ 
/*     */   public int getModerationAvatarCount() {
/* 464 */     int count = 0;
/* 465 */     Connection con = null;
/* 466 */     PreparedStatement pstmt = null;
/* 467 */     ResultSet rs = null;
/*     */     try
/*     */     {
/* 470 */       con = ConnectionManager.getConnection();
/* 471 */       pstmt = con.prepareStatement("SELECT COUNT(*) from jiveAvatar WHERE modValue < ? AND ownerID IS NOT NULL");
/* 472 */       pstmt.setInt(1, 1);
/* 473 */       rs = pstmt.executeQuery();
/* 474 */       if (rs.next())
/* 475 */         count = rs.getInt(1);
/*     */     }
/*     */     catch (SQLException sqle)
/*     */     {
/* 479 */       Log.error(sqle);
/*     */     } finally {
/*     */       try {
/* 482 */         if (rs != null) rs.close(); 
/*     */       } catch (Exception e) { Log.error(e); }
/*     */ 
/* 485 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 488 */     return count;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbAvatarManager
 * JD-Core Version:    0.6.2
 */
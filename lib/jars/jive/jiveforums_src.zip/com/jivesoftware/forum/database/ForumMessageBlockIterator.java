/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.database.CachedPreparedStatement;
/*     */ import com.jivesoftware.forum.ForumMessageIterator;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class ForumMessageBlockIterator extends ForumMessageIterator
/*     */ {
/*  24 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */   private long[] block;
/*     */   private int blockID;
/*     */   private int blockStart;
/*     */   private CachedPreparedStatement query;
/*     */   private int startIndex;
/*     */   private int currentIndex;
/*     */   private int endIndex;
/*     */   private int objectType;
/*     */   private long objectID;
/*  40 */   private Object previousElement = null;
/*  41 */   private Object nextElement = null;
/*     */ 
/*  43 */   private int previousElementIndex = -1;
/*  44 */   private int nextElementIndex = -1;
/*     */ 
/*     */   protected ForumMessageBlockIterator(long[] block, CachedPreparedStatement query, int startIndex, int endIndex, int objectType, long objectID)
/*     */   {
/*  61 */     this.block = block;
/*  62 */     this.blockID = (startIndex / 400);
/*  63 */     this.blockStart = (this.blockID * 400);
/*  64 */     this.query = query;
/*  65 */     this.currentIndex = (startIndex - 1);
/*  66 */     this.startIndex = startIndex;
/*  67 */     this.endIndex = endIndex;
/*  68 */     this.objectType = objectType;
/*  69 */     this.objectID = objectID;
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/*  74 */     if (this.currentIndex == this.endIndex) {
/*  75 */       return false;
/*     */     }
/*     */ 
/*  80 */     if (this.nextElement == null) {
/*  81 */       Object element = null;
/*  82 */       int index = this.currentIndex;
/*  83 */       while ((index + 1 < this.endIndex) && (element == null)) {
/*  84 */         index++;
/*  85 */         element = getElement(index);
/*     */       }
/*     */ 
/*  88 */       if (element == null) {
/*  89 */         return false;
/*     */       }
/*     */ 
/*  92 */       this.nextElement = element;
/*  93 */       this.nextElementIndex = index;
/*     */     }
/*     */ 
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean hasPrevious()
/*     */   {
/* 101 */     if (this.currentIndex == this.startIndex) {
/* 102 */       return false;
/*     */     }
/*     */ 
/* 106 */     if (this.previousElement == null) {
/* 107 */       Object element = null;
/* 108 */       int index = this.currentIndex;
/* 109 */       while ((index >= this.startIndex) && (element == null)) {
/* 110 */         index--;
/* 111 */         element = getElement(index);
/*     */       }
/*     */ 
/* 115 */       if (element == null) {
/* 116 */         return false;
/*     */       }
/*     */ 
/* 119 */       this.previousElement = element;
/* 120 */       this.previousElementIndex = index;
/*     */     }
/*     */ 
/* 123 */     return true;
/*     */   }
/*     */ 
/*     */   public Object next() throws NoSuchElementException {
/* 127 */     Object element = null;
/* 128 */     if ((this.nextElement != null) && (this.nextElementIndex != -1)) {
/* 129 */       element = this.nextElement;
/* 130 */       this.currentIndex = this.nextElementIndex;
/* 131 */       this.nextElement = null;
/* 132 */       this.nextElementIndex = -1;
/*     */     }
/*     */     else {
/* 135 */       element = getNextElement();
/* 136 */       if (element == null) {
/* 137 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/* 140 */     return element;
/*     */   }
/*     */ 
/*     */   public Object previous() {
/* 144 */     Object element = null;
/* 145 */     if ((this.previousElement != null) && (this.previousElementIndex != -1)) {
/* 146 */       element = this.previousElement;
/* 147 */       this.currentIndex = this.previousElementIndex;
/* 148 */       this.previousElement = null;
/* 149 */       this.previousElementIndex = -1;
/*     */     }
/*     */     else {
/* 152 */       element = getPreviousElement();
/* 153 */       if (element == null) {
/* 154 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/* 157 */     return element;
/*     */   }
/*     */ 
/*     */   public void setIndex(long messageID)
/*     */   {
/* 163 */     this.nextElement = null;
/* 164 */     this.previousElement = null;
/* 165 */     this.nextElementIndex = -1;
/* 166 */     this.previousElementIndex = -1;
/*     */     int i;
/*     */     try {
/* 172 */       for (i = this.startIndex; i < this.endIndex; ) {
/* 173 */         long[] currentBlock = getBlock(i);
/* 174 */         if (currentBlock.length == 0) {
/* 175 */           throw new NoSuchElementException("Message with id " + messageID + " is not a valid index in the iteration.");
/*     */         }
/*     */ 
/* 178 */         int blockID = i / 400;
/* 179 */         int blockEnd = blockID * 400 + 400;
/*     */ 
/* 181 */         if (this.startIndex < blockEnd)
/*     */         {
/* 184 */           for (int j = this.startIndex % 400; j < currentBlock.length; i++)
/*     */           {
/* 186 */             if (currentBlock[j] == messageID) {
/* 187 */               this.currentIndex = i;
/*     */               return;
/*     */             }
/* 184 */             j++;
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 194 */           for (int j = 0; j < currentBlock.length; i++) {
/* 195 */             if (currentBlock[j] == messageID) {
/* 196 */               this.currentIndex = i;
/*     */               return;
/*     */             }
/* 194 */             j++;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */ 
/* 206 */     throw new NoSuchElementException("Message with id " + messageID + " is not a valid index in the iteration.");
/*     */   }
/*     */ 
/*     */   private long[] getBlock(int startIndex)
/*     */     throws Exception
/*     */   {
/* 212 */     return QueryCache.getBlock(this.query, this.objectType, this.objectID, startIndex, true);
/*     */   }
/*     */ 
/*     */   private Object getNextElement()
/*     */   {
/* 222 */     this.previousElement = null;
/* 223 */     this.previousElementIndex = -1;
/*     */ 
/* 225 */     Object element = null;
/* 226 */     while ((this.currentIndex + 1 < this.endIndex) && (element == null)) {
/* 227 */       this.currentIndex += 1;
/* 228 */       element = getElement(this.currentIndex);
/*     */     }
/*     */ 
/* 231 */     return element;
/*     */   }
/*     */ 
/*     */   private Object getPreviousElement()
/*     */   {
/* 241 */     this.nextElement = null;
/* 242 */     this.nextElementIndex = -1;
/*     */ 
/* 244 */     Object element = null;
/* 245 */     while ((this.currentIndex >= this.startIndex) && (element == null)) {
/* 246 */       this.currentIndex -= 1;
/* 247 */       element = getElement(this.currentIndex);
/*     */     }
/* 249 */     return element;
/*     */   }
/*     */ 
/*     */   private Object getElement(int index) {
/* 253 */     if (index < 0) {
/* 254 */       return null;
/*     */     }
/*     */ 
/* 257 */     if ((index < this.blockStart) || (index >= this.blockStart + 400))
/*     */     {
/*     */       try
/*     */       {
/* 262 */         this.block = QueryCache.getBlock(this.query, this.objectType, this.objectID, index, true);
/* 263 */         this.blockID = (index / 400);
/* 264 */         this.blockStart = (this.blockID * 400);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 268 */         return null;
/*     */       }
/*     */     }
/* 271 */     Object element = null;
/*     */ 
/* 274 */     int relativeIndex = index % 400;
/*     */ 
/* 276 */     if (relativeIndex < this.block.length)
/*     */       try {
/* 278 */         element = FACTORY.getMessage(this.block[relativeIndex]);
/*     */       }
/*     */       catch (ForumMessageNotFoundException tnfe) {
/*     */       }
/* 282 */     return element;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.ForumMessageBlockIterator
 * JD-Core Version:    0.6.2
 */
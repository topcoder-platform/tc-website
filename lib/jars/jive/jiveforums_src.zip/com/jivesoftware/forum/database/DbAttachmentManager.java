/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.database.ConnectionManager.DatabaseType;
/*     */ import com.jivesoftware.base.util.AttachmentUtils;
/*     */ import com.jivesoftware.forum.AttachmentManager;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.ClassUtils;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class DbAttachmentManager
/*     */   implements AttachmentManager
/*     */ {
/*     */   private static final String SELECT_TEMP_ATTACHMENTS = "SELECT attachmentID FROM jiveAttachment WHERE objectID IS NULL AND creationDate < ?";
/*     */   private static final String SELECT_ALL_ATTACHMENTS = "SELECT attachmentID FROM jiveAttachment";
/*     */   private static final String DELETE_ATTACHMENT_DATA = "DELETE from jiveAttachData";
/*  48 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*  49 */   private static File attachmentDir = null;
/*  50 */   private static final DbAttachmentManager instance = new DbAttachmentManager();
/*     */   private int maxAttachmentSize;
/*     */   private int maxAttachmentsPerMessage;
/*     */   private List allowedList;
/*     */   private List disallowedList;
/*     */   boolean allowAllByDefault;
/*     */   private boolean databaseModeEnabled;
/*     */   private long maxAttachmentCacheSize;
/*  59 */   private long attachmentDirSize = 0L;
/*  60 */   private boolean attachmentDirSizeComputed = false;
/*     */   boolean imagePreviewEnabled;
/*     */   int imagePreviewMaxSize;
/*  64 */   boolean imagePreviewRatioEnabled = true;
/*     */ 
/*     */   public static DbAttachmentManager getInstance() {
/*  67 */     return instance;
/*     */   }
/*     */ 
/*     */   private DbAttachmentManager() {
/*  71 */     loadSettings();
/*     */ 
/*  75 */     Runnable calculateDirSize = new Runnable() {
/*     */       public void run() {
/*  77 */         File attachmentDir = DbAttachmentManager.getAttachmentDir();
/*  78 */         File[] files = attachmentDir.listFiles();
/*  79 */         for (int i = 0; i < files.length; i++) {
/*  80 */           DbAttachmentManager.this.addToAttachDirSize(files[i].length());
/*     */         }
/*     */ 
/*  83 */         DbAttachmentManager.this.attachmentDirSizeComputed = true;
/*     */       }
/*     */     };
/*  86 */     TaskEngine.addTask(calculateDirSize);
/*     */ 
/*  89 */     Runnable deleteTask = new Runnable()
/*     */     {
/*     */       public void run() {
/*  92 */         if (DbAttachmentManager.this.isDatabaseModeEnabled()) {
/*  93 */           File attachmentDir = DbAttachmentManager.getAttachmentDir();
/*  94 */           File[] files = attachmentDir.listFiles(new FileFilter() {
/*  95 */             long minDate = System.currentTimeMillis() - 2592000000L;
/*     */ 
/*  97 */             public boolean accept(File file) { return (!file.isDirectory()) && (file.lastModified() < this.minDate); }
/*     */ 
/*     */           });
/* 100 */           for (int i = 0; i < files.length; i++) {
/*     */             try
/*     */             {
/* 103 */               DbAttachmentManager.this.addToAttachDirSize(-files[i].length());
/*     */ 
/* 105 */               files[i].delete();
/*     */             }
/*     */             catch (Exception e)
/*     */             {
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 113 */         if (!CacheFactory.isSeniorClusterMember()) {
/* 114 */           return;
/*     */         }
/*     */ 
/* 118 */         LongList attachments = new LongList();
/* 119 */         Connection con = null;
/* 120 */         PreparedStatement pstmt = null;
/*     */         try {
/* 122 */           Date deleteDate = new Date(CacheFactory.currentTime - 86400000L);
/* 123 */           con = ConnectionManager.getConnection();
/* 124 */           pstmt = con.prepareStatement("SELECT attachmentID FROM jiveAttachment WHERE objectID IS NULL AND creationDate < ?");
/* 125 */           pstmt.setLong(1, deleteDate.getTime());
/* 126 */           ResultSet rs = pstmt.executeQuery();
/* 127 */           while (rs.next()) {
/* 128 */             attachments.add(rs.getLong(1));
/*     */           }
/* 130 */           rs.close();
/*     */         }
/*     */         catch (SQLException sqle) {
/* 133 */           Log.error(sqle);
/*     */         }
/*     */         finally {
/* 136 */           ConnectionManager.closeConnection(pstmt, con);
/*     */         }
/* 138 */         for (int i = 0; i < attachments.size(); i++)
/*     */           try {
/* 140 */             DbAttachment attachment = DbAttachmentManager.FACTORY.cacheManager.getAttachment(attachments.get(i));
/*     */ 
/* 142 */             con = ConnectionManager.getConnection();
/* 143 */             attachment.delete(con);
/*     */           }
/*     */           catch (Exception e) {
/* 146 */             Log.error(e);
/*     */           }
/*     */           finally {
/* 149 */             ConnectionManager.closeConnection(con);
/*     */           }
/*     */       }
/*     */     };
/* 154 */     TaskEngine.scheduleTask(deleteTask, 43200000L, 43200000L);
/*     */   }
/*     */ 
/*     */   public boolean isDatabaseModeEnabled() {
/* 158 */     return this.databaseModeEnabled;
/*     */   }
/*     */ 
/*     */   public void setDatabaseModeEnabled(boolean enabled) {
/* 162 */     if (enabled == this.databaseModeEnabled) {
/* 163 */       return;
/*     */     }
/* 165 */     this.databaseModeEnabled = enabled;
/* 166 */     JiveGlobals.setJiveProperty("attachments.databaseModeEnabled", Boolean.toString(enabled));
/* 167 */     CacheFactory.doClusterTask(new AttachmentSettingsTask(false));
/*     */ 
/* 169 */     Runnable updateTask = new Runnable() {
/*     */       public void run() {
/* 171 */         DbAttachmentManager.changeAttachmentMode(DbAttachmentManager.this.databaseModeEnabled);
/*     */       }
/*     */     };
/* 174 */     TaskEngine.addTask(2, updateTask);
/*     */   }
/*     */ 
/*     */   public void setDatabaseModeEnabled(boolean enabled, boolean synchronous)
/*     */   {
/* 194 */     if (!synchronous) {
/* 195 */       setDatabaseModeEnabled(enabled);
/*     */     }
/* 197 */     if (enabled == this.databaseModeEnabled) {
/* 198 */       return;
/*     */     }
/* 200 */     this.databaseModeEnabled = enabled;
/* 201 */     JiveGlobals.setJiveProperty("attachments.databaseModeEnabled", Boolean.toString(enabled));
/* 202 */     CacheFactory.doClusterTask(new AttachmentSettingsTask(false));
/* 203 */     changeAttachmentMode(this.databaseModeEnabled);
/*     */   }
/*     */ 
/*     */   public long getAttachmentDirectorySize() throws UnauthorizedException {
/* 207 */     if (this.attachmentDirSizeComputed) {
/* 208 */       return this.attachmentDirSize;
/*     */     }
/*     */ 
/* 211 */     return -1L;
/*     */   }
/*     */ 
/*     */   public long getMaxFilesystemCacheSize() throws UnauthorizedException
/*     */   {
/* 216 */     return this.maxAttachmentCacheSize;
/*     */   }
/*     */ 
/*     */   public void setMaxFilesystemCacheSize(long maxSize) throws UnauthorizedException {
/* 220 */     if (maxSize == this.maxAttachmentCacheSize) {
/* 221 */       return;
/*     */     }
/* 223 */     this.maxAttachmentCacheSize = maxSize;
/* 224 */     JiveGlobals.setJiveProperty("attachments.maxFilesystemCacheSize", Long.toString(this.maxAttachmentCacheSize));
/*     */ 
/* 227 */     if ((this.databaseModeEnabled) && (this.attachmentDirSize >= this.maxAttachmentCacheSize))
/* 228 */       TaskEngine.addTask(new CachePurgeTask(null));
/*     */   }
/*     */ 
/*     */   public int getMaxAttachmentSize()
/*     */   {
/* 233 */     return this.maxAttachmentSize;
/*     */   }
/*     */ 
/*     */   public void setMaxAttachmentSize(int maxAttachmentSize) {
/* 237 */     this.maxAttachmentSize = maxAttachmentSize;
/* 238 */     JiveGlobals.setJiveProperty("attachments.maxAttachmentSize", Integer.toString(maxAttachmentSize));
/*     */ 
/* 240 */     CacheFactory.doClusterTask(new AttachmentSettingsTask(false));
/*     */   }
/*     */ 
/*     */   public int getMaxAttachmentsPerMessage() {
/* 244 */     return this.maxAttachmentsPerMessage;
/*     */   }
/*     */ 
/*     */   public void setMaxAttachmentsPerMessage(int maxAttachmentsPerMessage) {
/* 248 */     this.maxAttachmentsPerMessage = maxAttachmentsPerMessage;
/* 249 */     JiveGlobals.setJiveProperty("attachments.maxAttachmentsPerMessage", Integer.toString(maxAttachmentsPerMessage));
/*     */ 
/* 251 */     CacheFactory.doClusterTask(new AttachmentSettingsTask(false));
/*     */   }
/*     */ 
/*     */   public boolean isValidType(String contentType) {
/* 255 */     if (this.allowAllByDefault) {
/* 256 */       return !this.disallowedList.contains(contentType);
/*     */     }
/*     */ 
/* 259 */     return this.allowedList.contains(contentType);
/*     */   }
/*     */ 
/*     */   public void addAllowedType(String contentType)
/*     */   {
/* 264 */     if (!this.allowedList.contains(contentType)) {
/* 265 */       this.allowedList.add(contentType);
/*     */     }
/* 267 */     String propValue = listToString(this.allowedList);
/* 268 */     if ((propValue == null) || ("".equals(propValue.trim()))) {
/* 269 */       JiveGlobals.deleteJiveProperty("attachments.allowedTypes");
/*     */     }
/*     */     else {
/* 272 */       JiveGlobals.setJiveProperty("attachments.allowedTypes", propValue);
/*     */     }
/* 274 */     CacheFactory.doClusterTask(new AttachmentSettingsTask(false));
/*     */   }
/*     */ 
/*     */   public void removeAllowedType(String contentType) {
/* 278 */     this.allowedList.remove(contentType);
/* 279 */     String propValue = listToString(this.allowedList);
/* 280 */     if ((propValue == null) || ("".equals(propValue.trim()))) {
/* 281 */       JiveGlobals.deleteJiveProperty("attachments.allowedTypes");
/*     */     }
/*     */     else {
/* 284 */       JiveGlobals.setJiveProperty("attachments.allowedTypes", propValue);
/*     */     }
/* 286 */     CacheFactory.doClusterTask(new AttachmentSettingsTask(false));
/*     */   }
/*     */ 
/*     */   public Iterator allowedTypes() {
/* 290 */     return Collections.unmodifiableList(this.allowedList).iterator();
/*     */   }
/*     */ 
/*     */   public void addDisallowedType(String contentType) {
/* 294 */     if (!this.disallowedList.contains(contentType)) {
/* 295 */       this.disallowedList.add(contentType);
/*     */     }
/* 297 */     String propValue = listToString(this.disallowedList);
/* 298 */     if ((propValue == null) || ("".equals(propValue.trim()))) {
/* 299 */       JiveGlobals.deleteJiveProperty("attachments.disallowedTypes");
/*     */     }
/*     */     else {
/* 302 */       JiveGlobals.setJiveProperty("attachments.disallowedTypes", propValue);
/*     */     }
/* 304 */     CacheFactory.doClusterTask(new AttachmentSettingsTask(false));
/*     */   }
/*     */ 
/*     */   public void removeDisallowedType(String contentType) {
/* 308 */     this.disallowedList.remove(contentType);
/* 309 */     String propValue = listToString(this.disallowedList);
/* 310 */     if ((propValue == null) || ("".equals(propValue.trim()))) {
/* 311 */       JiveGlobals.deleteJiveProperty("attachments.disallowedTypes");
/*     */     }
/*     */     else {
/* 314 */       JiveGlobals.setJiveProperty("attachments.disallowedTypes", propValue);
/*     */     }
/* 316 */     CacheFactory.doClusterTask(new AttachmentSettingsTask(false));
/*     */   }
/*     */ 
/*     */   public Iterator disallowedTypes() {
/* 320 */     return Collections.unmodifiableList(this.disallowedList).iterator();
/*     */   }
/*     */ 
/*     */   public boolean getAllowAllByDefault() {
/* 324 */     return this.allowAllByDefault;
/*     */   }
/*     */ 
/*     */   public void setAllowAllByDefault(boolean allowAllByDefault) {
/* 328 */     this.allowAllByDefault = allowAllByDefault;
/* 329 */     JiveGlobals.setJiveProperty("attachments.allowAllByDefault", String.valueOf(allowAllByDefault));
/*     */ 
/* 331 */     CacheFactory.doClusterTask(new AttachmentSettingsTask(false));
/*     */   }
/*     */ 
/*     */   public boolean isImagePreviewEnabled() {
/* 335 */     return this.imagePreviewEnabled;
/*     */   }
/*     */ 
/*     */   public void setImagePreviewEnabled(boolean imagePreviewEnabled) {
/* 339 */     this.imagePreviewEnabled = imagePreviewEnabled;
/* 340 */     JiveGlobals.setJiveProperty("attachments.imagePreview.enabled", String.valueOf(imagePreviewEnabled));
/*     */ 
/* 342 */     CacheFactory.doClusterTask(new AttachmentSettingsTask(false));
/*     */   }
/*     */ 
/*     */   public int getImagePreviewMaxSize() {
/* 346 */     return this.imagePreviewMaxSize;
/*     */   }
/*     */ 
/*     */   public void setImagePreviewMaxSize(int imagePreviewMaxSize) {
/* 350 */     this.imagePreviewMaxSize = imagePreviewMaxSize;
/* 351 */     JiveGlobals.setJiveProperty("attachments.imagePreview.maxSize", Integer.toString(imagePreviewMaxSize));
/*     */ 
/* 353 */     clearImagePreviewCache();
/* 354 */     CacheFactory.doClusterTask(new AttachmentSettingsTask(true));
/*     */   }
/*     */ 
/*     */   public boolean isImagePreviewRatioEnabled() {
/* 358 */     return this.imagePreviewRatioEnabled;
/*     */   }
/*     */ 
/*     */   public void setImagePreviewRatioEnabled(boolean imagePreviewRatioEnabled) {
/* 362 */     this.imagePreviewRatioEnabled = imagePreviewRatioEnabled;
/* 363 */     JiveGlobals.setJiveProperty("attachments.imagePreview.preserveAspectRatio", String.valueOf(this.imagePreviewEnabled));
/*     */ 
/* 365 */     clearImagePreviewCache();
/* 366 */     CacheFactory.doClusterTask(new AttachmentSettingsTask(true));
/*     */   }
/*     */ 
/*     */   public static String getThumbnailImage(String contentType)
/*     */   {
/* 377 */     if (contentType == null) {
/* 378 */       return "attachment.gif";
/*     */     }
/*     */ 
/* 381 */     if (contentType.equals("application/msword")) {
/* 382 */       return "msword.gif";
/*     */     }
/* 384 */     if (contentType.equals("application/vnd.ms-excel")) {
/* 385 */       return "msexcel.gif";
/*     */     }
/* 387 */     if (contentType.equals("application/vnd.ms-powerpoint")) {
/* 388 */       return "mspowerpoint.gif";
/*     */     }
/* 390 */     if (contentType.equals("application/pdf")) {
/* 391 */       return "pdf.gif";
/*     */     }
/*     */ 
/* 394 */     if ((contentType.startsWith("application/")) && (contentType.indexOf("zip") > 0)) {
/* 395 */       return "zip.gif";
/*     */     }
/*     */ 
/* 398 */     if (contentType.startsWith("image/")) {
/* 399 */       return "image.gif";
/*     */     }
/*     */ 
/* 402 */     if (contentType.startsWith("audio/")) {
/* 403 */       return "audio.gif";
/*     */     }
/*     */ 
/* 406 */     if ((contentType.equals("text/richtext")) || (contentType.equals("text/rtf"))) {
/* 407 */       return "rtf.gif";
/*     */     }
/* 409 */     if (contentType.startsWith("text/")) {
/* 410 */       return "txt.gif";
/*     */     }
/*     */ 
/* 413 */     return "attachment.gif";
/*     */   }
/*     */ 
/*     */   public static synchronized File getAttachmentDir()
/*     */   {
/* 420 */     if (attachmentDir == null)
/*     */     {
/* 423 */       String dir = JiveGlobals.getLocalProperty("attachments.directory");
/* 424 */       if (dir != null) {
/* 425 */         attachmentDir = new File(dir);
/*     */       }
/*     */       else {
/* 428 */         if (JiveGlobals.getJiveHome() == null) {
/* 429 */           return null;
/*     */         }
/* 431 */         attachmentDir = new File(JiveGlobals.getJiveHome() + File.separator + "attachments");
/*     */       }
/*     */     }
/*     */ 
/* 435 */     return attachmentDir;
/*     */   }
/*     */ 
/*     */   protected void addToAttachDirSize(long size)
/*     */   {
/* 461 */     this.attachmentDirSize += size;
/*     */ 
/* 464 */     if ((this.databaseModeEnabled) && (this.attachmentDirSize >= this.maxAttachmentCacheSize))
/* 465 */       TaskEngine.addTask(new CachePurgeTask(null));
/*     */   }
/*     */ 
/*     */   private void loadSettings()
/*     */   {
/* 494 */     this.maxAttachmentSize = JiveGlobals.getJiveIntProperty("attachments.maxAttachmentSize", 1024);
/* 495 */     this.maxAttachmentsPerMessage = JiveGlobals.getJiveIntProperty("attachments.maxAttachmentsPerMessage", 5);
/*     */ 
/* 497 */     this.allowedList = stringToList(JiveGlobals.getJiveProperty("attachments.allowedTypes"));
/* 498 */     this.disallowedList = stringToList(JiveGlobals.getJiveProperty("attachments.disallowedTypes"));
/* 499 */     this.allowAllByDefault = JiveGlobals.getJiveBooleanProperty("attachments.allowAllByDefault", true);
/* 500 */     this.databaseModeEnabled = JiveGlobals.getJiveBooleanProperty("attachments.databaseModeEnabled");
/*     */ 
/* 502 */     this.maxAttachmentCacheSize = 536870912L;
/* 503 */     String maxCacheSize = JiveGlobals.getJiveProperty("attachments.maxFilesystemCacheSize");
/* 504 */     if (maxCacheSize != null) {
/*     */       try {
/* 506 */         this.maxAttachmentCacheSize = Long.parseLong(maxCacheSize);
/*     */       }
/*     */       catch (NumberFormatException ne)
/*     */       {
/*     */       }
/*     */     }
/* 512 */     this.imagePreviewEnabled = JiveGlobals.getJiveBooleanProperty("attachments.imagePreview.enabled", true);
/*     */ 
/* 514 */     this.imagePreviewMaxSize = JiveGlobals.getJiveIntProperty("attachments.imagePreview.maxSize", 25);
/* 515 */     this.imagePreviewRatioEnabled = JiveGlobals.getJiveBooleanProperty("attachments.imagePreview.preserveAspectRatio", true);
/*     */   }
/*     */ 
/*     */   private static synchronized void clearImagePreviewCache()
/*     */   {
/*     */     try
/*     */     {
/* 524 */       File dir = new File(getAttachmentDir(), "cache");
/* 525 */       if (dir.exists()) {
/* 526 */         File[] files = dir.listFiles();
/* 527 */         for (int i = 0; i < files.length; i++)
/* 528 */           files[i].delete();
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 533 */       Log.error(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String listToString(List list)
/*     */   {
/* 541 */     StringBuffer buf = new StringBuffer();
/* 542 */     for (Iterator iter = list.iterator(); iter.hasNext(); ) {
/* 543 */       String element = (String)iter.next();
/* 544 */       buf.append(element).append(",");
/*     */     }
/* 546 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   private static List stringToList(String string)
/*     */   {
/* 553 */     List list = new Vector();
/* 554 */     if (string != null) {
/* 555 */       StringTokenizer tokens = new StringTokenizer(string, ",");
/* 556 */       while (tokens.hasMoreTokens()) {
/* 557 */         list.add(tokens.nextToken());
/*     */       }
/*     */     }
/* 560 */     return list;
/*     */   }
/*     */ 
/*     */   private static synchronized void changeAttachmentMode(boolean databaseModeEnabled) {
/* 564 */     Log.info("Switching database attachment mode to " + (databaseModeEnabled ? "enabled" : "disabled"));
/*     */ 
/* 567 */     if (databaseModeEnabled)
/*     */     {
/* 569 */       File attachmentDir = getAttachmentDir();
/* 570 */       File[] files = attachmentDir.listFiles(new FileFilter() {
/*     */         public boolean accept(File file) {
/* 572 */           return file.getName().endsWith(".bin");
/*     */         }
/*     */       });
/* 575 */       for (int i = 0; i < files.length; i++) {
/*     */         try {
/* 577 */           File file = files[i];
/* 578 */           long attachmentID = Long.parseLong(file.getName().substring(0, file.getName().length() - 4));
/*     */ 
/* 580 */           Connection con = null;
/* 581 */           PreparedStatement pstmt = null;
/* 582 */           boolean abortTransaction = false;
/*     */           try {
/* 584 */             con = ConnectionManager.getTransactionConnection();
/*     */ 
/* 586 */             boolean isOracle = ConnectionManager.getDatabaseType() == ConnectionManager.DatabaseType.ORACLE;
/*     */ 
/* 588 */             if (isOracle) {
/*     */               try
/*     */               {
/* 591 */                 ClassUtils.forName("oracle.sql.BLOB");
/*     */               }
/*     */               catch (ClassNotFoundException cnfe)
/*     */               {
/* 595 */                 isOracle = false;
/*     */               }
/*     */             }
/*     */ 
/* 599 */             if (isOracle) {
/* 600 */               pstmt = con.prepareStatement("INSERT INTO jiveAttachData (attachmentID, attachmentData) VALUES (?, EMPTY_BLOB())");
/* 601 */               pstmt.setLong(1, attachmentID);
/* 602 */               pstmt.execute();
/* 603 */               pstmt.close();
/* 604 */               pstmt = con.prepareStatement("SELECT attachmentData FROM jiveAttachData WHERE attachmentID=?");
/* 605 */               pstmt.setLong(1, attachmentID);
/* 606 */               ResultSet rs = pstmt.executeQuery();
/* 607 */               rs.next();
/* 608 */               Object blobObject = rs.getBlob(1);
/* 609 */               InputStream in = null;
/* 610 */               OutputStream out = null;
/*     */               try {
/* 612 */                 int bufSize = 0;
/*     */                 try
/*     */                 {
/* 615 */                   Class blobClass = ClassUtils.forName("oracle.sql.BLOB");
/*     */ 
/* 617 */                   out = (OutputStream)blobClass.getMethod("getBinaryOutputStream", (Class[])null).invoke(blobObject, (Object[])null);
/*     */ 
/* 620 */                   bufSize = ((Integer)blobClass.getMethod("getBufferSize", (Class[])null).invoke(blobObject, (Object[])null)).intValue();
/*     */                 }
/*     */                 catch (Exception e)
/*     */                 {
/* 624 */                   Log.error("Failed to load Oracle JDK 1.4 JDBC drivers.", e);
/*     */                 }
/*     */ 
/* 627 */                 byte[] buf = new byte[bufSize];
/* 628 */                 in = new BufferedInputStream(new FileInputStream(file));
/*     */ 
/* 630 */                 int len = 0;
/* 631 */                 while ((len = in.read(buf)) >= 0) {
/* 632 */                   out.write(buf, 0, len);
/*     */                 }
/* 634 */                 rs.close();
/*     */               }
/*     */               finally {
/* 637 */                 if (in != null) try { in.close(); } catch (Exception e) {
/*     */                   } if (out != null) try { out.close(); } catch (Exception e) {
/*     */                   } 
/*     */               }
/*     */             }
/*     */             else {
/* 643 */               InputStream in = null;
/*     */               try {
/* 645 */                 in = new BufferedInputStream(new FileInputStream(file));
/*     */ 
/* 647 */                 pstmt = con.prepareStatement("INSERT INTO jiveAttachData (attachmentID, attachmentData) VALUES (?, ?)");
/* 648 */                 pstmt.setLong(1, attachmentID);
/* 649 */                 pstmt.setBinaryStream(2, in, (int)file.length());
/* 650 */                 pstmt.execute();
/*     */               }
/*     */               finally {
/* 653 */                 if (in != null) try { in.close(); } catch (Exception e)
/*     */                   {
/*     */                   } 
/*     */               }
/*     */             }
/* 658 */             if (!JiveGlobals.getJiveBooleanProperty("attachments.fileSystemCacheEnabled", true))
/* 659 */               file.delete();
/*     */           }
/*     */           catch (SQLException sqle)
/*     */           {
/* 663 */             abortTransaction = true;
/* 664 */             Log.error(sqle);
/*     */           }
/*     */           finally {
/* 667 */             ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */           }
/*     */         }
/*     */         catch (Exception e) {
/* 671 */           Log.error(e);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 678 */       LongList attachments = new LongList();
/* 679 */       Connection con = null;
/* 680 */       PreparedStatement pstmt = null;
/*     */       try {
/* 682 */         con = ConnectionManager.getConnection();
/* 683 */         pstmt = con.prepareStatement("SELECT attachmentID FROM jiveAttachment");
/* 684 */         ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 686 */         while (rs.next()) {
/* 687 */           attachments.add(rs.getLong(1));
/*     */         }
/* 689 */         rs.close();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 692 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 695 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/* 697 */       for (int i = 0; i < attachments.size(); i++) {
/*     */         try
/*     */         {
/* 700 */           long id = attachments.get(i);
/* 701 */           File output = new File(getAttachmentDir(), id + ".bin");
/*     */ 
/* 703 */           if (!output.exists())
/*     */           {
/* 705 */             AttachmentUtils.saveObjectToFile(id, "SELECT attachmentData FROM jiveAttachData WHERE attachmentID=?", output);
/*     */           }
/*     */         }
/*     */         catch (Exception e) {
/* 709 */           Log.error(e);
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 714 */         con = ConnectionManager.getConnection();
/* 715 */         pstmt = con.prepareStatement("DELETE from jiveAttachData");
/* 716 */         pstmt.execute();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 719 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 722 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */     }
/* 725 */     Log.info("Finished switching database attachment mode to " + (databaseModeEnabled ? "enabled" : "disabled"));
/*     */   }
/*     */ 
/*     */   private class CachePurgeTask
/*     */     implements Runnable
/*     */   {
/*     */     private CachePurgeTask()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 471 */       if ((!DbAttachmentManager.this.databaseModeEnabled) || (DbAttachmentManager.this.attachmentDirSize <= DbAttachmentManager.this.maxAttachmentCacheSize)) {
/* 472 */         return;
/*     */       }
/* 474 */       File attachmentDir = DbAttachmentManager.getAttachmentDir();
/* 475 */       File[] files = attachmentDir.listFiles();
/*     */ 
/* 477 */       Arrays.sort(files, new Comparator() {
/*     */         public int compare(Object file1, Object file2) {
/* 479 */           return ((File)file1).lastModified() < ((File)file2).lastModified() ? -1 : 1;
/*     */         }
/*     */       });
/* 482 */       long desiredSize = ()(DbAttachmentManager.this.maxAttachmentCacheSize * 0.9D);
/* 483 */       int i = 0;
/* 484 */       while ((DbAttachmentManager.this.attachmentDirSize >= desiredSize) && (i < files.length)) {
/* 485 */         DbAttachmentManager.this.addToAttachDirSize(-files[i].length());
/* 486 */         files[i].delete();
/* 487 */         i++;
/*     */       }
/*     */     }
/*     */ 
/*     */     CachePurgeTask(DbAttachmentManager.1 x1)
/*     */     {
/* 469 */       this();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class AttachmentSettingsTask
/*     */     implements Runnable, Serializable
/*     */   {
/*     */     private boolean clearImagePreviewCache;
/*     */ 
/*     */     public AttachmentSettingsTask(boolean clearImagePreviewCache)
/*     */     {
/* 443 */       this.clearImagePreviewCache = clearImagePreviewCache;
/*     */     }
/*     */ 
/*     */     public void run() {
/* 447 */       DbAttachmentManager.getInstance().loadSettings();
/* 448 */       if (this.clearImagePreviewCache)
/* 449 */         DbAttachmentManager.access$600();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbAttachmentManager
 * JD-Core Version:    0.6.2
 */
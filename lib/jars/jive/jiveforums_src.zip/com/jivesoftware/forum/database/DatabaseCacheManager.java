/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.GroupManagerFactory;
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.PollManagerFactory;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManagerFactory;
/*     */ import com.jivesoftware.base.database.DbPermissionsManager;
/*     */ import com.jivesoftware.forum.AnnouncementNotFoundException;
/*     */ import com.jivesoftware.forum.AttachmentNotFoundException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.event.ForumEvent;
/*     */ import com.jivesoftware.forum.event.ForumEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ForumListener;
/*     */ import com.jivesoftware.forum.event.MessageEvent;
/*     */ import com.jivesoftware.forum.event.MessageEventDispatcher;
/*     */ import com.jivesoftware.forum.event.MessageListener;
/*     */ import com.jivesoftware.forum.event.ThreadEvent;
/*     */ import com.jivesoftware.forum.event.ThreadEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ThreadListener;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.profile.Profiler;
/*     */ import java.sql.Connection;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DatabaseCacheManager
/*     */ {
/*     */   public Cache categoryCache;
/*     */   public Cache forumCache;
/*     */   public Cache forumNNTPNameCache;
/*     */   public Cache threadCache;
/*     */   public Cache treeWalkerCache;
/*     */   public Cache messageCache;
/*     */   public Cache privateMessageCache;
/*     */   public Cache privateMessageFolderCache;
/*     */   public Cache forumIndexCache;
/*     */   public QueryCache queryCache;
/*     */   public Cache shortTermQueryCache;
/*     */   public Cache watchCache;
/*     */   public Cache userMessageCountCache;
/*     */   public Cache attachmentCache;
/*     */   public Cache rewardCache;
/*     */   public Cache readTrackerCache;
/*     */   public Cache announcementCache;
/*     */   public Cache questionCache;
/* 174 */   private boolean shortTermQueryCacheEnabled = false;
/*     */ 
/*     */   public DatabaseCacheManager()
/*     */   {
/* 180 */     initCaches();
/*     */ 
/* 182 */     UserPostCountListener listener = new UserPostCountListener(null);
/* 183 */     ForumEventDispatcher.getInstance().addListener(listener);
/* 184 */     ThreadEventDispatcher.getInstance().addListener(listener);
/* 185 */     MessageEventDispatcher.getInstance().addListener(listener);
/*     */   }
/*     */ 
/*     */   private void initCaches()
/*     */   {
/* 195 */     if (this.queryCache != null) this.queryCache.clear();
/* 196 */     if (this.shortTermQueryCache != null) this.shortTermQueryCache.clear();
/*     */ 
/* 200 */     long DEFAULT_EXPR = 43200000L;
/*     */ 
/* 202 */     this.categoryCache = CacheFactory.createCache("Category", "categoryCache", 262144, 43200000L);
/* 203 */     this.forumCache = CacheFactory.createCache("Forum", "forumCache", 524288, 43200000L);
/* 204 */     this.forumNNTPNameCache = CacheFactory.createCache("Forum NNTP Name", "nntpNameCache", 32768, 43200000L);
/* 205 */     this.threadCache = CacheFactory.createCache("Thread", "threadCache", 524288, 43200000L);
/* 206 */     this.treeWalkerCache = CacheFactory.createCache("TreeWalker", "treeWalkerCache", 262144, 43200000L);
/* 207 */     this.messageCache = CacheFactory.createCache("Message", "messageCache", 1048576, 43200000L);
/* 208 */     this.privateMessageCache = CacheFactory.createCache("Private Message", "privateMessageCache", 524288, 43200000L);
/* 209 */     this.privateMessageFolderCache = CacheFactory.createCache("Private Message Folder", "privateMessageFolderCache", 131072, 43200000L);
/*     */ 
/* 211 */     this.forumIndexCache = CacheFactory.createCache("Forum Message Index", "forumIndexCache", 524288, -1L);
/* 212 */     this.userMessageCountCache = CacheFactory.createCache("User's Message Count", "userMsgCountCache", 65536, 43200000L);
/* 213 */     this.watchCache = CacheFactory.createCache("Watches", "watchCache", 131072, 43200000L);
/* 214 */     this.attachmentCache = CacheFactory.createCache("Attachment", "attachmentCache", 65536, -1L);
/* 215 */     this.rewardCache = CacheFactory.createCache("Reward", "rewardCache", 131072, 43200000L);
/* 216 */     this.readTrackerCache = CacheFactory.createCache("Read Tracking", "readTrackerCache", 262144, 43200000L);
/* 217 */     this.announcementCache = CacheFactory.createCache("Announcement", "announcementCache", 262144, 43200000L);
/* 218 */     this.questionCache = CacheFactory.createCache("Question", "questionCache", 262144, 43200000L);
/* 219 */     this.queryCache = new QueryCache(CacheFactory.createCache("Query", "queryCache", -1, 43200000L));
/*     */ 
/* 222 */     initShortTermQueryCache();
/*     */   }
/*     */ 
/*     */   private void initShortTermQueryCache()
/*     */   {
/* 230 */     String cacheTime = null;
/* 231 */     String cacheSize = null;
/*     */ 
/* 233 */     int shortTermQueryCacheSize = 131072;
/* 234 */     long shortTermQueryCacheTime = 0L;
/*     */ 
/* 236 */     cacheSize = JiveGlobals.getLocalProperty("cache.shortTermQueryCache.size");
/* 237 */     if (cacheSize != null) try {
/* 238 */         shortTermQueryCacheSize = Integer.parseInt(cacheSize);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       } cacheTime = JiveGlobals.getLocalProperty("cache.shortTermQueryCache.time");
/* 243 */     if (cacheTime != null) try {
/* 244 */         shortTermQueryCacheTime = Long.parseLong(cacheTime);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*     */ 
/* 250 */     if (shortTermQueryCacheTime > 0L) {
/* 251 */       this.shortTermQueryCache = CacheFactory.createCache("Short-term Query", shortTermQueryCacheSize, shortTermQueryCacheTime);
/*     */ 
/* 253 */       this.shortTermQueryCacheEnabled = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveCacheSettings()
/*     */   {
/* 262 */     saveCache(this.categoryCache, "categoryCache");
/* 263 */     saveCache(this.forumCache, "forumCache");
/* 264 */     saveCache(this.forumNNTPNameCache, "nntpNameCache");
/* 265 */     saveCache(this.threadCache, "threadCache");
/* 266 */     saveCache(this.treeWalkerCache, "treeWalkerCache");
/* 267 */     saveCache(this.messageCache, "messageCache");
/* 268 */     saveCache(this.privateMessageCache, "privateMessageCache");
/* 269 */     saveCache(this.privateMessageFolderCache, "privateMessageFolderCache");
/* 270 */     saveCache(this.forumIndexCache, "forumIndexCache");
/* 271 */     saveCache(this.watchCache, "watchCache");
/* 272 */     saveCache(this.userMessageCountCache, "userMessageCountCache");
/* 273 */     saveCache(this.queryCache, "queryCache");
/*     */ 
/* 275 */     if (this.shortTermQueryCacheEnabled) {
/* 276 */       saveCache(this.shortTermQueryCache, "shortTermQueryCache");
/*     */     }
/*     */ 
/* 279 */     saveCache(this.attachmentCache, "attachmentCache");
/* 280 */     saveCache(this.rewardCache, "rewardCache");
/* 281 */     saveCache(this.readTrackerCache, "readTrackerCache");
/* 282 */     saveCache(this.announcementCache, "announcementCache");
/*     */ 
/* 285 */     saveCache(PollManagerFactory.pollCache, "pollCache");
/* 286 */     saveCache(PollManagerFactory.pollQueryCache, "pollQueryCache");
/* 287 */     saveCache(PollManagerFactory.voteCache, "voteCache");
/*     */ 
/* 290 */     saveCache(UserManagerFactory.userIDCache, "userIDCache");
/* 291 */     saveCache(UserManagerFactory.userCache, "userCache");
/* 292 */     saveCache(this.userMessageCountCache, "userMsgCountCache");
/* 293 */     saveCache(GroupManagerFactory.groupCache, "groupCache");
/* 294 */     saveCache(GroupManagerFactory.groupIDCache, "groupIDCache");
/* 295 */     saveCache(GroupManagerFactory.groupMemberCache, "groupMemberCache");
/*     */ 
/* 298 */     saveCache(DbPermissionsManager.userPermsCache, "userPermsCache");
/*     */ 
/* 301 */     saveCache(this.questionCache, "questionCache");
/*     */   }
/*     */ 
/*     */   private static void saveCache(Cache cache, String cacheName) {
/* 305 */     JiveGlobals.setLocalProperty("cache." + cacheName + ".size", String.valueOf(cache.getMaxCacheSize()));
/*     */ 
/* 308 */     JiveGlobals.setLocalProperty("cache." + cacheName + ".maxLifetime", String.valueOf(cache.getMaxLifetime()));
/*     */   }
/*     */ 
/*     */   public boolean isShortTermQueryCacheEnabled()
/*     */   {
/* 320 */     return this.shortTermQueryCacheEnabled;
/*     */   }
/*     */ 
/*     */   public void setShortTermQueryCacheEnabled(boolean shortTermQueryCacheEnabled)
/*     */   {
/* 331 */     if (shortTermQueryCacheEnabled)
/*     */     {
/* 335 */       JiveGlobals.setLocalProperty("cache.shortTermQueryCache.time", "5000");
/* 336 */       initShortTermQueryCache();
/*     */     }
/*     */     else
/*     */     {
/* 340 */       this.shortTermQueryCacheEnabled = false;
/* 341 */       JiveGlobals.deleteLocalProperty("cache.shortTermQueryCache.time");
/* 342 */       if (this.shortTermQueryCache != null)
/* 343 */         this.shortTermQueryCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   DbForumCategory getForumCategory(long categoryID) throws ForumCategoryNotFoundException
/*     */   {
/* 349 */     DbForumCategory category = (DbForumCategory)this.categoryCache.get(new Long(categoryID));
/* 350 */     if (category == null) {
/* 351 */       synchronized (("c" + Long.toString(categoryID)).intern()) {
/* 352 */         category = (DbForumCategory)this.categoryCache.get(new Long(categoryID));
/* 353 */         if (category == null) {
/* 354 */           category = new DbForumCategory(categoryID);
/* 355 */           this.categoryCache.put(new Long(categoryID), category);
/*     */         }
/*     */       }
/*     */     }
/* 359 */     return category;
/*     */   }
/*     */ 
/*     */   DbForumCategory getForumCategory(long categoryID, Connection con) throws ForumCategoryNotFoundException {
/* 363 */     DbForumCategory category = (DbForumCategory)this.categoryCache.get(new Long(categoryID));
/* 364 */     if (category == null) {
/* 365 */       synchronized (("c" + Long.toString(categoryID)).intern()) {
/* 366 */         category = (DbForumCategory)this.categoryCache.get(new Long(categoryID));
/* 367 */         if (category == null) {
/* 368 */           category = new DbForumCategory(categoryID, con);
/* 369 */           this.categoryCache.put(new Long(categoryID), category);
/*     */         }
/*     */       }
/*     */     }
/* 373 */     return category;
/*     */   }
/*     */ 
/*     */   DbForum getForum(long forumID) throws ForumNotFoundException {
/* 377 */     DbForum forum = (DbForum)this.forumCache.get(new Long(forumID));
/* 378 */     if (forum == null) {
/* 379 */       synchronized (("f" + Long.toString(forumID)).intern()) {
/* 380 */         forum = (DbForum)this.forumCache.get(new Long(forumID));
/* 381 */         if (forum == null) {
/* 382 */           forum = new DbForum(forumID);
/* 383 */           this.forumCache.put(new Long(forumID), forum);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 389 */     return forum;
/*     */   }
/*     */ 
/*     */   DbForum getForum(String nntpName) throws ForumNotFoundException {
/* 393 */     Long forumID = (Long)this.forumNNTPNameCache.get(nntpName);
/* 394 */     if (forumID == null) {
/* 395 */       synchronized (("nntp-" + nntpName).intern()) {
/* 396 */         forumID = (Long)this.forumNNTPNameCache.get(nntpName);
/* 397 */         if (forumID == null) {
/* 398 */           DbForum forum = new DbForum(nntpName);
/* 399 */           forumID = new Long(forum.getID());
/* 400 */           this.forumNNTPNameCache.put(nntpName, forumID);
/*     */ 
/* 402 */           if (!this.forumCache.containsKey(forumID)) {
/* 403 */             this.forumCache.put(forumID, forum);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 408 */     return getForum(forumID.longValue());
/*     */   }
/*     */ 
/*     */   DbForumThread getForumThread(long threadID) throws ForumThreadNotFoundException {
/* 412 */     DbForumThread thread = (DbForumThread)this.threadCache.get(new Long(threadID));
/* 413 */     if (thread == null) {
/* 414 */       synchronized (("t" + Long.toString(threadID)).intern()) {
/* 415 */         thread = (DbForumThread)this.threadCache.get(new Long(threadID));
/* 416 */         if (thread == null) {
/* 417 */           thread = new DbForumThread(threadID);
/* 418 */           threadPut(threadID, thread);
/*     */         }
/*     */       }
/*     */     }
/* 422 */     return thread;
/*     */   }
/*     */ 
/*     */   DbForumMessage getMessage(long messageID) throws ForumMessageNotFoundException {
/* 426 */     DbForumMessage message = (DbForumMessage)this.messageCache.get(new Long(messageID));
/* 427 */     if (message == null) {
/* 428 */       synchronized (("m" + Long.toString(messageID)).intern()) {
/* 429 */         message = (DbForumMessage)this.messageCache.get(new Long(messageID));
/* 430 */         if (message == null) {
/* 431 */           message = new DbForumMessage(messageID);
/* 432 */           messagePut(messageID, message);
/*     */ 
/* 434 */           String key = message.forumID + '-' + message.getForumIndex();
/*     */ 
/* 436 */           forumIndexPut(key, messageID);
/*     */         }
/*     */       }
/*     */     }
/* 440 */     return message;
/*     */   }
/*     */ 
/*     */   long getMessageID(long forumID, int forumIndex)
/*     */   {
/* 454 */     if (forumIndex < 0) {
/* 455 */       throw new IllegalArgumentException("Forum index values less than 0 are invalid: " + forumIndex);
/*     */     }
/*     */ 
/* 459 */     String key = (forumID + '-' + forumIndex).intern();
/*     */ 
/* 461 */     Long messageID = (Long)this.forumIndexCache.get(key);
/* 462 */     if (messageID == null) {
/* 463 */       synchronized (key) {
/* 464 */         messageID = (Long)this.forumIndexCache.get(key);
/* 465 */         if (messageID == null)
/*     */         {
/* 473 */           int BLOCK_SIZE = 250;
/* 474 */           Forum forum = null;
/*     */           try {
/* 476 */             forum = getForum(forumID);
/*     */           }
/*     */           catch (ForumNotFoundException fe) {
/* 479 */             throw new IllegalArgumentException("Forum with ID: " + forumID + " not found");
/*     */           }
/*     */ 
/* 482 */           int minIndex = forum.getMinForumIndex();
/* 483 */           int maxIndex = forum.getMaxForumIndex();
/*     */ 
/* 486 */           if ((forumIndex < minIndex) || (forumIndex > maxIndex)) {
/* 487 */             throw new IllegalArgumentException("Message with index " + forumIndex + " in forum " + forumID + " is outside the valid range (" + minIndex + "-" + maxIndex + ").");
/*     */           }
/*     */ 
/* 490 */           int blockStart = forumIndex / 250 * 250;
/*     */ 
/* 494 */           int blockEnd = blockStart + 250 < maxIndex ? blockStart + 250 : maxIndex + 1;
/*     */ 
/* 498 */           if (blockStart < minIndex) {
/* 499 */             blockStart = minIndex;
/*     */           }
/*     */ 
/* 506 */           String blockStartKey = (forumID + '-' + blockStart).intern();
/*     */ 
/* 508 */           if (!this.forumIndexCache.containsKey(blockStartKey)) {
/* 509 */             DbForumMessage.loadBulkFromDb(forumID, blockStart, blockEnd);
/*     */ 
/* 512 */             messageID = (Long)this.forumIndexCache.get(key);
/*     */           }
/*     */           else
/*     */           {
/*     */             try {
/* 517 */               DbForumMessage message = new DbForumMessage(forumID, forumIndex);
/* 518 */               messageID = new Long(message.getID());
/* 519 */               forumIndexPut(key, message.getID());
/*     */ 
/* 522 */               if (!this.messageCache.containsKey(messageID)) {
/* 523 */                 messagePut(message.getID(), message);
/*     */               }
/*     */ 
/*     */             }
/*     */             catch (ForumMessageNotFoundException fe)
/*     */             {
/* 533 */               messageID = new Long(-1L);
/* 534 */               forumIndexPut(key, -1L);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 540 */     return messageID.longValue();
/*     */   }
/*     */ 
/*     */   public DbAttachment getAttachment(long attachmentID) throws AttachmentNotFoundException {
/* 544 */     DbAttachment attachment = (DbAttachment)this.attachmentCache.get(new Long(attachmentID));
/* 545 */     if (attachment == null) {
/* 546 */       synchronized (("a" + Long.toString(attachmentID)).intern()) {
/* 547 */         attachment = (DbAttachment)this.attachmentCache.get(new Long(attachmentID));
/* 548 */         if (attachment == null) {
/* 549 */           attachment = new DbAttachment(attachmentID);
/* 550 */           this.attachmentCache.put(new Long(attachmentID), attachment);
/*     */         }
/*     */       }
/*     */     }
/* 554 */     return attachment;
/*     */   }
/*     */ 
/*     */   DbAnnouncement getAnnouncement(long announcementID) throws AnnouncementNotFoundException {
/* 558 */     DbAnnouncement announcement = (DbAnnouncement)this.announcementCache.get(new Long(announcementID));
/* 559 */     if (announcement == null) {
/* 560 */       synchronized (("ann" + Long.toString(announcementID)).intern()) {
/* 561 */         announcement = (DbAnnouncement)this.announcementCache.get(new Long(announcementID));
/* 562 */         if (announcement == null) {
/* 563 */           announcement = new DbAnnouncement(announcementID);
/* 564 */           announcementPut(announcementID, announcement);
/*     */         }
/*     */       }
/*     */     }
/* 568 */     return announcement;
/*     */   }
/*     */ 
/*     */   public void threadPut(long id, ForumThread thread) {
/* 572 */     Profiler.begin("threadPut");
/* 573 */     this.threadCache.put(new Long(id), thread);
/* 574 */     Profiler.end("threadPut");
/*     */   }
/*     */ 
/*     */   public void messagePut(long id, ForumMessage message) {
/* 578 */     Profiler.begin("messagePut");
/* 579 */     this.messageCache.put(new Long(id), message);
/* 580 */     Profiler.end("messagePut");
/*     */   }
/*     */ 
/*     */   public void threadRemove(long id) {
/* 584 */     Profiler.begin("threadRemove");
/* 585 */     this.threadCache.remove(new Long(id));
/* 586 */     Profiler.end("threadRemove");
/*     */   }
/*     */ 
/*     */   public void queryRemove(int objectType, long objectID) {
/* 590 */     Profiler.begin("queryRemove");
/* 591 */     this.queryCache.remove(objectType, objectID);
/* 592 */     Profiler.end("queryRemove");
/*     */   }
/*     */ 
/*     */   public void queryPut(QueryCacheKey countKey, Object value) {
/* 596 */     Profiler.begin("queryPut");
/* 597 */     this.queryCache.put(countKey, value);
/* 598 */     Profiler.end("queryPut");
/*     */   }
/*     */ 
/*     */   public void forumIndexPut(String key, long messageID) {
/* 602 */     Profiler.begin("forumIndexPut");
/* 603 */     this.forumIndexCache.put(key, new Long(messageID));
/* 604 */     Profiler.end("forumIndexPut");
/*     */   }
/*     */ 
/*     */   public void forumIndexRemove(String key) {
/* 608 */     Profiler.begin("forumIndexRemove");
/* 609 */     this.forumIndexCache.remove(key);
/* 610 */     Profiler.end("forumIndexRemove");
/*     */   }
/*     */ 
/*     */   public void messageRemove(long id) {
/* 614 */     Profiler.begin("messageRemove");
/* 615 */     this.messageCache.remove(new Long(id));
/* 616 */     Profiler.end("messageRemove");
/*     */   }
/*     */ 
/*     */   public Object queryGet(QueryCacheKey key) {
/*     */     try {
/* 621 */       Profiler.begin("queryGet");
/* 622 */       return this.queryCache.get(key);
/*     */     } finally {
/* 624 */       Profiler.end("queryGet");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void announcementPut(long announcementID, DbAnnouncement announcement) {
/* 629 */     Profiler.begin("announcementPut");
/* 630 */     this.announcementCache.put(new Long(announcementID), announcement);
/* 631 */     Profiler.end("announcementPut");
/*     */   }
/*     */ 
/*     */   public void announcementRemove(long announcementID) {
/* 635 */     Profiler.begin("announcementRemove");
/* 636 */     this.announcementCache.remove(new Long(announcementID));
/* 637 */     Profiler.end("announcementRemove");
/*     */   }
/*     */ 
/*     */   public void announcementPut(String key, long[] announcement) {
/* 641 */     Profiler.begin("announcementPutKey");
/* 642 */     this.announcementCache.put(key, announcement);
/* 643 */     Profiler.end("announcementPutKey");
/*     */   }
/*     */ 
/*     */   public void announcementRemove(String key) {
/* 647 */     Profiler.begin("announcementRemoveKey");
/* 648 */     this.announcementCache.remove(key);
/* 649 */     Profiler.end("announcementRemoveKey");
/*     */   }
/*     */ 
/*     */   private class UserPostCountListener implements ForumListener, ThreadListener, MessageListener
/*     */   {
/*     */     private UserPostCountListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void forumAdded(ForumEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void forumDeleted(ForumEvent event)
/*     */     {
/* 664 */       DatabaseCacheManager.this.userMessageCountCache.clear();
/*     */ 
/* 669 */       for (int i = 0; i < 3; i++)
/*     */       {
/*     */         Iterator iter;
/*     */         try {
/* 673 */           QueryCache.BackingCache backingCache = (QueryCache.BackingCache)QueryCache.getBackingInstance();
/*     */ 
/* 675 */           Map idMap = new HashMap(backingCache.idMap);
/*     */ 
/* 677 */           for (iter = idMap.keySet().iterator(); iter.hasNext(); ) {
/* 678 */             String[] idKey = ((String)iter.next()).split(",");
/* 679 */             int objectType = Integer.parseInt(idKey[0]);
/* 680 */             if (objectType == 3) {
/* 681 */               long objectID = Long.parseLong(idKey[1]);
/*     */ 
/* 683 */               DatabaseCacheManager.this.queryRemove(objectType, objectID);
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (ConcurrentModificationException cme)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public void forumMoved(ForumEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void forumMerged(ForumEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void threadAdded(ThreadEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void threadDeleted(ThreadEvent event)
/*     */     {
/* 707 */       ForumThread thread = event.getThread();
/*     */       Map users;
/*     */       Iterator i;
/* 710 */       if (thread.getMessageCount() < 500)
/*     */       {
/* 712 */         users = new HashMap();
/* 713 */         for (Iterator i = thread.getMessages(); i.hasNext(); ) {
/* 714 */           ForumMessage message = (ForumMessage)i.next();
/*     */ 
/* 716 */           if ((!message.isAnonymous()) && (message.getModerationValue() >= 1))
/*     */           {
/* 719 */             Long userID = new Long(message.getUser().getID());
/* 720 */             if (users.containsKey(userID))
/*     */             {
/* 722 */               int count = ((Integer)users.get(userID)).intValue() + 1;
/* 723 */               users.put(userID, new Integer(count));
/*     */             }
/*     */             else {
/* 726 */               users.put(userID, new Integer(1));
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 731 */         for (i = users.keySet().iterator(); i.hasNext(); ) {
/* 732 */           Long userID = (Long)i.next();
/*     */           Integer msgCount;
/* 735 */           if ((msgCount = (Integer)DatabaseCacheManager.this.userMessageCountCache.get(userID)) != null) {
/* 736 */             int removeCount = ((Integer)users.get(userID)).intValue();
/* 737 */             msgCount = new Integer(msgCount.intValue() - removeCount);
/* 738 */             DatabaseCacheManager.this.userMessageCountCache.put(userID, msgCount);
/*     */           }
/* 740 */           DatabaseCacheManager.this.queryRemove(3, userID.longValue());
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 747 */         DatabaseCacheManager.this.userMessageCountCache.clear();
/*     */ 
/* 752 */         for (int i = 0; i < 3; i++)
/*     */         {
/*     */           Iterator iter;
/*     */           try {
/* 756 */             QueryCache.BackingCache backingCache = (QueryCache.BackingCache)QueryCache.getBackingInstance();
/*     */ 
/* 758 */             Map idMap = new HashMap(backingCache.idMap);
/*     */ 
/* 760 */             for (iter = idMap.keySet().iterator(); iter.hasNext(); ) {
/* 761 */               String[] idKey = ((String)iter.next()).split(",");
/* 762 */               int objectType = Integer.parseInt(idKey[0]);
/* 763 */               if (objectType == 3) {
/* 764 */                 long objectID = Long.parseLong(idKey[1]);
/*     */ 
/* 766 */                 DatabaseCacheManager.this.queryRemove(objectType, objectID);
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (ConcurrentModificationException cme)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public void threadMoved(ThreadEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void threadModerationModified(ThreadEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void threadRated(ThreadEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void messageAdded(MessageEvent event)
/*     */     {
/* 791 */       ForumMessage message = event.getMessage();
/*     */ 
/* 796 */       if (!message.isAnonymous()) {
/* 797 */         if (message.getModerationValue() >= 1) {
/* 798 */           Long userID = new Long(message.getUser().getID());
/*     */           Integer msgCount;
/* 801 */           if ((msgCount = (Integer)DatabaseCacheManager.this.userMessageCountCache.get(userID)) != null) {
/* 802 */             msgCount = new Integer(msgCount.intValue() + 1);
/* 803 */             DatabaseCacheManager.this.userMessageCountCache.put(userID, msgCount);
/*     */           }
/*     */         }
/* 806 */         DatabaseCacheManager.this.queryRemove(3, message.getUser().getID());
/*     */       }
/*     */     }
/*     */ 
/*     */     public void messageDeleted(MessageEvent event) {
/* 811 */       ForumMessage message = event.getMessage();
/*     */ 
/* 816 */       if (!message.isAnonymous()) {
/* 817 */         if (message.getModerationValue() >= 1) {
/* 818 */           Long userID = new Long(message.getUser().getID());
/*     */           Integer msgCount;
/* 821 */           if ((msgCount = (Integer)DatabaseCacheManager.this.userMessageCountCache.get(userID)) != null) {
/* 822 */             msgCount = new Integer(msgCount.intValue() - 1);
/* 823 */             DatabaseCacheManager.this.userMessageCountCache.put(userID, msgCount);
/*     */           }
/*     */         }
/* 826 */         DatabaseCacheManager.this.queryRemove(3, message.getUser().getID());
/*     */       }
/*     */     }
/*     */ 
/*     */     public void messageMoved(MessageEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void messageModified(MessageEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void messageModerationModified(MessageEvent event) {
/* 839 */       ForumMessage message = event.getMessage();
/* 840 */       if (message.isAnonymous()) {
/* 841 */         return;
/*     */       }
/*     */ 
/* 845 */       int oldValue = ((Integer)event.getParams().get("oldModerationValue")).intValue();
/* 846 */       int newValue = message.getModerationValue();
/*     */ 
/* 848 */       if ((oldValue <= 0) && (newValue >= 1))
/*     */       {
/* 851 */         Long userID = new Long(message.getUser().getID());
/*     */         Integer msgCount;
/* 854 */         if ((msgCount = (Integer)DatabaseCacheManager.this.userMessageCountCache.get(userID)) != null) {
/* 855 */           msgCount = new Integer(msgCount.intValue() + 1);
/* 856 */           DatabaseCacheManager.this.userMessageCountCache.put(userID, msgCount);
/*     */         }
/*     */ 
/*     */       }
/* 860 */       else if ((oldValue >= 0) && (newValue <= 1))
/*     */       {
/* 863 */         Long userID = new Long(message.getUser().getID());
/*     */         Integer msgCount;
/* 866 */         if ((msgCount = (Integer)DatabaseCacheManager.this.userMessageCountCache.get(userID)) != null) {
/* 867 */           msgCount = new Integer(msgCount.intValue() - 1);
/* 868 */           DatabaseCacheManager.this.userMessageCountCache.put(userID, msgCount);
/*     */         }
/*     */       }
/* 871 */       DatabaseCacheManager.this.queryRemove(3, message.getUser().getID());
/*     */     }
/*     */ 
/*     */     public void messageRated(MessageEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     UserPostCountListener(DatabaseCacheManager.1 x1)
/*     */     {
/* 655 */       this();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DatabaseCacheManager
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.database;
/*    */ 
/*    */ import com.jivesoftware.base.User;
/*    */ import com.jivesoftware.forum.ForumThread;
/*    */ import com.jivesoftware.forum.Query;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class SessionQuery
/*    */   implements Serializable
/*    */ {
/* 19 */   private String queryString = null;
/* 20 */   private long searchID = -1L;
/* 21 */   private String searchHash = null;
/*    */ 
/*    */   public SessionQuery(Query query) {
/* 24 */     this.queryString = query.getQueryString();
/* 25 */     this.searchID = query.getID();
/* 26 */     this.searchHash = getHashKey(query);
/*    */   }
/*    */ 
/*    */   public String getQueryString() {
/* 30 */     return this.queryString;
/*    */   }
/*    */ 
/*    */   public long getSearchID() {
/* 34 */     return this.searchID;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj) {
/* 38 */     if ((obj instanceof Query)) {
/* 39 */       return this.searchHash.equals(getHashKey((Query)obj));
/*    */     }
/* 41 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean equals(Query query) {
/* 45 */     return this.searchHash.equals(getHashKey(query));
/*    */   }
/*    */ 
/*    */   private String getHashKey(Query q)
/*    */   {
/* 52 */     StringBuffer hashKey = new StringBuffer();
/* 53 */     if (q.getFilteredUser() != null) {
/* 54 */       hashKey.append(q.getFilteredUser().getID());
/*    */     }
/* 56 */     hashKey.append("-");
/* 57 */     if (q.getFilteredThread() != null) {
/* 58 */       hashKey.append(q.getFilteredThread().getID());
/*    */     }
/* 60 */     hashKey.append("-");
/* 61 */     if (q.getBeforeDate() != null) {
/* 62 */       hashKey.append(q.getBeforeDate());
/*    */     }
/* 64 */     hashKey.append("-");
/* 65 */     if (q.getAfterDate() != null) {
/* 66 */       hashKey.append(q.getAfterDate());
/*    */     }
/* 68 */     hashKey.append("-");
/* 69 */     if ((q.getForumIDs() != null) && (q.getForumIDs().length > 0)) {
/* 70 */       String delim = "";
/* 71 */       for (int i = 0; i < q.getForumIDs().length; i++) {
/* 72 */         long id = q.getForumIDs()[i];
/* 73 */         hashKey.append(delim);
/* 74 */         hashKey.append(id);
/* 75 */         delim = ",";
/*    */       }
/*    */     }
/* 78 */     hashKey.append("-");
/* 79 */     if (q.getQueryString() != null) {
/* 80 */       hashKey.append(q.getQueryString());
/*    */     }
/*    */ 
/* 83 */     return hashKey.toString();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.SessionQuery
 * JD-Core Version:    0.6.2
 */
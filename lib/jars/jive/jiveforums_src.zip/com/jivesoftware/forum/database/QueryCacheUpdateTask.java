/*    */ package com.jivesoftware.forum.database;
/*    */ 
/*    */ import com.jivesoftware.base.database.CachedPreparedStatement;
/*    */ import com.jivesoftware.base.database.ConnectionManager;
/*    */ import com.jivesoftware.util.Cache;
/*    */ import com.jivesoftware.util.LongList;
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class QueryCacheUpdateTask
/*    */   implements Runnable
/*    */ {
/* 27 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*    */   private QueryCacheKey key;
/*    */ 
/*    */   public QueryCacheUpdateTask(QueryCacheKey key)
/*    */   {
/* 37 */     this.key = key;
/*    */   }
/*    */ 
/*    */   public void run() {
/*    */     try {
/* 42 */       int blockID = this.key.getBlockID();
/*    */ 
/* 44 */       Object value = null;
/* 45 */       Connection con = null;
/* 46 */       PreparedStatement pstmt = null;
/*    */       try {
/* 48 */         con = ConnectionManager.getConnection();
/* 49 */         pstmt = con.prepareStatement(this.key.getSQL().getSQL());
/* 50 */         this.key.getSQL().setParams(pstmt);
/*    */ 
/* 52 */         if (this.key.blockID != -1) {
/* 53 */           LongList objectList = new LongList(400);
/*    */ 
/* 56 */           ConnectionManager.setMaxRows(pstmt, 400 * (blockID + 1));
/* 57 */           ResultSet rs = pstmt.executeQuery();
/*    */ 
/* 59 */           ConnectionManager.setFetchSize(rs, 400);
/*    */ 
/* 61 */           int blockStart = 400 * blockID;
/* 62 */           ConnectionManager.scrollResultSet(rs, blockStart);
/*    */ 
/* 65 */           int count = 0;
/* 66 */           while ((rs.next()) && (count < 400)) {
/* 67 */             objectList.add(rs.getLong(1));
/* 68 */             count++;
/*    */           }
/* 70 */           rs.close();
/* 71 */           value = objectList.toArray();
/*    */         }
/*    */         else
/*    */         {
/* 75 */           ResultSet rs = pstmt.executeQuery();
/* 76 */           rs.next();
/* 77 */           value = new Integer(rs.getInt(1));
/* 78 */           rs.close();
/*    */         }
/*    */       }
/*    */       catch (SQLException sqle) {
/* 82 */         sqle.printStackTrace();
/*    */       }
/*    */       finally {
/* 85 */         ConnectionManager.closeConnection(pstmt, con);
/*    */       }
/*    */ 
/* 88 */       if (value != null)
/*    */       {
/* 90 */         FACTORY.cacheManager.queryPut(this.key, value);
/*    */       }
/*    */     }
/*    */     finally
/*    */     {
/* 95 */       FACTORY.cacheManager.shortTermQueryCache.remove(this.key);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.QueryCacheUpdateTask
 * JD-Core Version:    0.6.2
 */
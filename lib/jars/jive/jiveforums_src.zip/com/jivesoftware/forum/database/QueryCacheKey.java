/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.database.CachedPreparedStatement;
/*     */ import com.jivesoftware.util.CacheSizes;
/*     */ import com.jivesoftware.util.Cacheable;
/*     */ import com.tangosol.io.ExternalizableLite;
/*     */ import com.tangosol.util.ExternalizableHelper;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class QueryCacheKey
/*     */   implements Serializable, Cacheable, ExternalizableLite
/*     */ {
/*     */   int objectType;
/*     */   long objectID;
/*     */   CachedPreparedStatement sql;
/*     */   int blockID;
/*     */ 
/*     */   public QueryCacheKey(int objectType, long objectID, CachedPreparedStatement sql, int blockID)
/*     */   {
/*  46 */     this.objectType = objectType;
/*  47 */     this.objectID = objectID;
/*  48 */     this.sql = sql;
/*  49 */     this.blockID = blockID;
/*     */   }
/*     */ 
/*     */   public QueryCacheKey()
/*     */   {
/*     */   }
/*     */ 
/*     */   public int getObjectType()
/*     */   {
/*  66 */     return this.objectType;
/*     */   }
/*     */ 
/*     */   public long getObjectID()
/*     */   {
/*  75 */     return this.objectID;
/*     */   }
/*     */ 
/*     */   public CachedPreparedStatement getSQL()
/*     */   {
/*  84 */     return this.sql;
/*     */   }
/*     */ 
/*     */   public int getBlockID()
/*     */   {
/*  93 */     return this.blockID;
/*     */   }
/*     */ 
/*     */   public void readExternal(DataInput in) throws IOException {
/*  97 */     this.objectType = ExternalizableHelper.readInt(in);
/*  98 */     this.objectID = ExternalizableHelper.readLong(in);
/*  99 */     this.sql = ((CachedPreparedStatement)ExternalizableHelper.readExternalizableLite(in));
/* 100 */     this.blockID = ExternalizableHelper.readInt(in);
/*     */   }
/*     */ 
/*     */   public void writeExternal(DataOutput out) throws IOException {
/* 104 */     ExternalizableHelper.writeInt(out, this.objectType);
/* 105 */     ExternalizableHelper.writeLong(out, this.objectID);
/* 106 */     ExternalizableHelper.writeExternalizableLite(out, this.sql);
/* 107 */     ExternalizableHelper.writeInt(out, this.blockID);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj) {
/* 111 */     if (this == obj) {
/* 112 */       return true;
/*     */     }
/*     */ 
/* 115 */     QueryCacheKey otherKey = (QueryCacheKey)obj;
/* 116 */     return (this.objectType == otherKey.objectType) && (this.objectID == otherKey.objectID) && (this.blockID == otherKey.blockID) && (this.sql.equals(otherKey.sql));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 124 */     return this.objectType + (int)this.objectID + this.sql.hashCode() + this.blockID;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 128 */     StringBuffer result = new StringBuffer();
/* 129 */     switch (this.objectType) {
/*     */     case 14:
/* 131 */       result.append("Category ");
/* 132 */       break;
/*     */     case 0:
/* 134 */       result.append("Forum ");
/* 135 */       break;
/*     */     case 1:
/* 137 */       result.append("Thread ");
/*     */     }
/* 139 */     result.append(this.objectID).append(": ");
/* 140 */     result.append(this.sql);
/* 141 */     if (this.blockID != -1) {
/* 142 */       result.append(", ").append(this.blockID);
/*     */     }
/* 144 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public int getCachedSize() {
/* 148 */     int size = 0;
/* 149 */     size += CacheSizes.sizeOfObject();
/* 150 */     size += CacheSizes.sizeOfInt();
/* 151 */     size += CacheSizes.sizeOfLong();
/* 152 */     size += this.sql.getCachedSize();
/* 153 */     size += CacheSizes.sizeOfInt();
/* 154 */     return size;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.QueryCacheKey
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.database;
/*    */ 
/*    */ import com.jivesoftware.forum.Rating;
/*    */ import com.jivesoftware.util.CacheSizes;
/*    */ import com.jivesoftware.util.Cacheable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class RatingCacheObject
/*    */   implements Cacheable
/*    */ {
/*    */   private Map userRatings;
/*    */   private List guestRatings;
/* 22 */   private double meanRating = -1.0D;
/*    */ 
/*    */   public RatingCacheObject(Map userRatings, List guestRatings) {
/* 25 */     this.userRatings = userRatings;
/* 26 */     this.guestRatings = guestRatings;
/*    */   }
/*    */ 
/*    */   public Map getUserRatings() {
/* 30 */     return this.userRatings;
/*    */   }
/*    */ 
/*    */   public List getGuestRatings() {
/* 34 */     return this.guestRatings;
/*    */   }
/*    */ 
/*    */   public int getCachedSize()
/*    */   {
/* 39 */     int sizeOfMap = 36 + this.userRatings.size() * 20 + this.userRatings.size() * 40;
/*    */ 
/* 41 */     int sizeOfList = 36 + this.guestRatings.size() * 40;
/*    */ 
/* 43 */     return CacheSizes.sizeOfObject() + sizeOfList + sizeOfMap + CacheSizes.sizeOfDouble();
/*    */   }
/*    */ 
/*    */   public double getMeanRating() {
/* 47 */     if (this.meanRating >= 0.0D) {
/* 48 */       return this.meanRating;
/*    */     }
/*    */ 
/* 51 */     if ((this.userRatings.size() == 0) && (this.guestRatings.size() == 0)) {
/* 52 */       this.meanRating = 0.0D;
/* 53 */       return this.meanRating;
/*    */     }
/*    */ 
/* 56 */     return calculateMeanRating();
/*    */   }
/*    */ 
/*    */   public double calculateMeanRating() {
/* 60 */     ArrayList temp = new ArrayList(this.guestRatings.size() + this.userRatings.size());
/* 61 */     for (int i = 0; i < this.guestRatings.size(); i++) {
/* 62 */       temp.add(this.guestRatings.get(i));
/*    */     }
/*    */ 
/* 65 */     temp.addAll(this.userRatings.values());
/*    */ 
/* 67 */     Iterator ratingValues = temp.iterator();
/* 68 */     double sumLog = 0.0D;
/*    */ 
/* 70 */     while (ratingValues.hasNext()) {
/* 71 */       Rating r = (Rating)ratingValues.next();
/* 72 */       sumLog += Math.log(r.getScore());
/*    */     }
/*    */ 
/* 75 */     this.meanRating = Math.exp(sumLog / temp.size());
/*    */ 
/* 77 */     return this.meanRating;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.RatingCacheObject
 * JD-Core Version:    0.6.2
 */
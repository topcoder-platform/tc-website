/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.Rating;
/*     */ import com.jivesoftware.forum.RatingManager;
/*     */ import com.jivesoftware.forum.RatingManagerFactory;
/*     */ import com.jivesoftware.forum.event.MessageEvent;
/*     */ import com.jivesoftware.forum.event.MessageEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ThreadEvent;
/*     */ import com.jivesoftware.forum.event.ThreadEventDispatcher;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class DbRatingManager
/*     */   implements RatingManager
/*     */ {
/*     */   private static final String LOAD_RATINGS = "SELECT score, description FROM jiveRatingType ORDER BY score ASC";
/*     */   private static final String ADD_RATING = "INSERT INTO jiveRatingType (score, description) VALUES (?, ?)";
/*     */   private static final String REMOVE_RATING = "DELETE FROM jiveRatingType WHERE score=?";
/*     */   private static final String REMOVE_RATINGS = "DELETE FROM jiveRating WHERE score=?";
/*     */   private static final String LOAD_OBJECT_RATINGS = "SELECT r.score, t.description, r.userID FROM jiveRating r, jiveRatingType t WHERE r.objectID=? AND r.objectType=? AND r.score = t.score ORDER BY r.score DESC";
/*     */   private static final String ADD_USER_RATING = "INSERT INTO jiveRating (objectID, objectType, userID, score) VALUES (?, ?, ?, ?)";
/*     */   private static final String UPDATE_USER_RATING = "UPDATE jiveRating set score=? WHERE objectID=? AND objectType=? AND userID=?";
/*  42 */   protected ArrayList availableRatings = new ArrayList();
/*     */ 
/*  48 */   private boolean ratingsEnabled = false;
/*     */ 
/*  50 */   private static DbRatingManager manager = new DbRatingManager();
/*     */ 
/*     */   private DbRatingManager()
/*     */   {
/*  54 */     loadAvailableRatings();
/*     */ 
/*  57 */     this.ratingsEnabled = JiveGlobals.getJiveBooleanProperty("ratings.enabled", true);
/*     */   }
/*     */ 
/*     */   public static DbRatingManager getInstance() {
/*  61 */     return manager;
/*     */   }
/*     */ 
/*     */   public boolean isRatingsEnabled() {
/*  65 */     return this.ratingsEnabled;
/*     */   }
/*     */ 
/*     */   public void setRatingsEnabled(boolean ratingsEnabled) throws UnauthorizedException {
/*  69 */     this.ratingsEnabled = ratingsEnabled;
/*  70 */     JiveGlobals.setJiveProperty("ratings.enabled", String.valueOf(ratingsEnabled));
/*     */   }
/*     */ 
/*     */   public Iterator getAvailableRatings() {
/*  74 */     return this.availableRatings.iterator();
/*     */   }
/*     */ 
/*     */   public int getAvailableRatingCount() {
/*  78 */     return this.availableRatings.size();
/*     */   }
/*     */ 
/*     */   public Rating getRatingFromScore(int score) {
/*  82 */     for (int i = 0; i < this.availableRatings.size(); i++) {
/*  83 */       Rating r = (Rating)this.availableRatings.get(i);
/*  84 */       if (r.getScore() == score) {
/*  85 */         return r;
/*     */       }
/*     */     }
/*     */ 
/*  89 */     return null;
/*     */   }
/*     */ 
/*     */   public Rating createRating(int score, String description) {
/*  93 */     if (!this.ratingsEnabled) {
/*  94 */       return null;
/*     */     }
/*     */ 
/*  97 */     if (score < 1) {
/*  98 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/* 102 */     for (int i = 0; i < this.availableRatings.size(); i++) {
/* 103 */       Rating rating = (Rating)this.availableRatings.get(i);
/* 104 */       if (rating.getScore() == score) {
/* 105 */         throw new IllegalArgumentException("Rating score is already in use: " + score);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 110 */     Connection con = null;
/* 111 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 114 */       con = ConnectionManager.getConnection();
/* 115 */       pstmt = con.prepareStatement("INSERT INTO jiveRatingType (score, description) VALUES (?, ?)");
/* 116 */       pstmt.setInt(1, score);
/* 117 */       pstmt.setString(2, description);
/* 118 */       pstmt.execute();
/*     */ 
/* 120 */       Rating rating = new DbRating(score, description);
/* 121 */       this.availableRatings.add(rating);
/*     */ 
/* 124 */       sortRatings();
/*     */ 
/* 126 */       return rating;
/*     */     } catch (SQLException e) {
/* 128 */       Log.error(e);
/*     */     } finally {
/* 130 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   public synchronized void removeRating(Rating rating) {
/* 137 */     if (!this.ratingsEnabled) {
/* 138 */       return;
/*     */     }
/*     */ 
/* 141 */     int index = this.availableRatings.indexOf(rating);
/*     */ 
/* 143 */     if (index < 0) {
/* 144 */       return;
/*     */     }
/*     */ 
/* 148 */     Connection con = null;
/* 149 */     PreparedStatement pstmt = null;
/* 150 */     boolean abortTransaction = false;
/*     */     try
/*     */     {
/* 153 */       con = ConnectionManager.getTransactionConnection();
/*     */ 
/* 156 */       pstmt = con.prepareStatement("DELETE FROM jiveRating WHERE score=?");
/* 157 */       pstmt.setLong(1, rating.getScore());
/* 158 */       pstmt.execute();
/* 159 */       pstmt.close();
/*     */ 
/* 162 */       pstmt = con.prepareStatement("DELETE FROM jiveRatingType WHERE score=?");
/* 163 */       pstmt.setLong(1, rating.getScore());
/* 164 */       pstmt.execute();
/* 165 */       pstmt.close();
/*     */ 
/* 167 */       this.availableRatings.remove(index);
/*     */ 
/* 170 */       sortRatings();
/*     */ 
/* 173 */       RatingManagerFactory.ratingsCache.clear();
/*     */     }
/*     */     catch (SQLException e) {
/* 176 */       Log.error(e);
/* 177 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 180 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Iterator getRatings(ForumMessage message) {
/* 185 */     if (message == null) {
/* 186 */       throw new IllegalArgumentException("Cannot retrieve ratings for null message");
/*     */     }
/*     */ 
/* 189 */     return getRatings(2, message.getID());
/*     */   }
/*     */ 
/*     */   public Iterator getRatings(ForumThread thread) {
/* 193 */     if (thread == null) {
/* 194 */       throw new IllegalArgumentException("Cannot retrieve ratings for null thread");
/*     */     }
/*     */ 
/* 197 */     return getRatings(1, thread.getID());
/*     */   }
/*     */ 
/*     */   private Iterator getRatings(int objectType, long objectID) {
/* 201 */     String ratingCacheKey = getCacheKey(objectType, objectID);
/*     */ 
/* 203 */     if (RatingManagerFactory.ratingsCache.get(ratingCacheKey) == null) {
/* 204 */       loadRatings(objectType, objectID);
/*     */     }
/*     */ 
/* 207 */     RatingCacheObject cacheObject = (RatingCacheObject)RatingManagerFactory.ratingsCache.get(ratingCacheKey);
/* 208 */     Map userRatings = cacheObject.getUserRatings();
/* 209 */     List guestRatings = cacheObject.getGuestRatings();
/*     */ 
/* 211 */     ArrayList temp = new ArrayList(guestRatings.size() + userRatings.size());
/* 212 */     for (int i = 0; i < guestRatings.size(); i++) {
/* 213 */       temp.add(guestRatings.get(i));
/*     */     }
/*     */ 
/* 216 */     temp.addAll(userRatings.values());
/*     */ 
/* 218 */     return temp.iterator();
/*     */   }
/*     */ 
/*     */   public int getRatingCount(ForumMessage message) {
/* 222 */     if (message == null) {
/* 223 */       throw new IllegalArgumentException("Cannot retrieve ratings for null message");
/*     */     }
/*     */ 
/* 226 */     return getRatingCount(2, message.getID());
/*     */   }
/*     */ 
/*     */   public int getRatingCount(ForumThread thread) {
/* 230 */     if (thread == null) {
/* 231 */       throw new IllegalArgumentException("Cannot retrieve ratings for null thread");
/*     */     }
/*     */ 
/* 234 */     return getRatingCount(1, thread.getID());
/*     */   }
/*     */ 
/*     */   private int getRatingCount(int objectType, long objectID) {
/* 238 */     String ratingCacheKey = getCacheKey(objectType, objectID);
/*     */ 
/* 240 */     if (RatingManagerFactory.ratingsCache.get(ratingCacheKey) == null) {
/* 241 */       loadRatings(objectType, objectID);
/*     */     }
/*     */ 
/* 244 */     RatingCacheObject cacheObject = (RatingCacheObject)RatingManagerFactory.ratingsCache.get(ratingCacheKey);
/* 245 */     int size = 0;
/* 246 */     if (cacheObject != null) {
/* 247 */       size = cacheObject.getUserRatings().size() + cacheObject.getGuestRatings().size();
/*     */     }
/* 249 */     return size;
/*     */   }
/*     */ 
/*     */   public double getMeanRating(long messageID) {
/* 253 */     return getMeanRating(2, messageID);
/*     */   }
/*     */ 
/*     */   public double getMeanRating(ForumMessage message) {
/* 257 */     if (message == null) {
/* 258 */       throw new IllegalArgumentException("Cannot retrieve mean rating for null message");
/*     */     }
/*     */ 
/* 261 */     return getMeanRating(2, message.getID());
/*     */   }
/*     */ 
/*     */   public double getMeanRating(ForumThread thread) {
/* 265 */     if (thread == null) {
/* 266 */       throw new IllegalArgumentException("Cannot retrieve mean rating for null thread");
/*     */     }
/*     */ 
/* 269 */     return getMeanRating(1, thread.getID());
/*     */   }
/*     */ 
/*     */   private double getMeanRating(int objectType, long objectID) {
/* 273 */     String ratingCacheKey = getCacheKey(objectType, objectID);
/*     */ 
/* 275 */     if (RatingManagerFactory.ratingsCache.get(ratingCacheKey) == null) {
/* 276 */       loadRatings(objectType, objectID);
/*     */     }
/*     */ 
/* 279 */     RatingCacheObject cacheObject = (RatingCacheObject)RatingManagerFactory.ratingsCache.get(ratingCacheKey);
/* 280 */     return cacheObject.getMeanRating();
/*     */   }
/*     */ 
/*     */   public boolean hasRated(User user, ForumMessage message) {
/* 284 */     if (message == null) {
/* 285 */       throw new IllegalArgumentException("Cannot retrieve ratings for null message");
/*     */     }
/*     */ 
/* 288 */     return hasRated(user, 2, message.getID());
/*     */   }
/*     */ 
/*     */   public boolean hasRated(User user, ForumThread thread) {
/* 292 */     if (thread == null) {
/* 293 */       throw new IllegalArgumentException("Cannot retrieve ratings for null thread");
/*     */     }
/*     */ 
/* 296 */     return hasRated(user, 1, thread.getID());
/*     */   }
/*     */ 
/*     */   private boolean hasRated(User user, int objectType, long objectID) {
/* 300 */     if (user == null) {
/* 301 */       return false;
/*     */     }
/*     */ 
/* 304 */     String ratingCacheKey = getCacheKey(objectType, objectID);
/*     */ 
/* 306 */     if (RatingManagerFactory.ratingsCache.get(ratingCacheKey) == null) {
/* 307 */       loadRatings(objectType, objectID);
/*     */     }
/*     */ 
/* 310 */     RatingCacheObject cacheObject = (RatingCacheObject)RatingManagerFactory.ratingsCache.get(ratingCacheKey);
/*     */ 
/* 312 */     if (cacheObject.getUserRatings().containsKey(new Long(user.getID()))) {
/* 313 */       return true;
/*     */     }
/*     */ 
/* 316 */     return false;
/*     */   }
/*     */ 
/*     */   public Rating getRating(User user, ForumMessage message) {
/* 320 */     if (message == null) {
/* 321 */       throw new IllegalArgumentException("Cannot retrieve rating for null message");
/*     */     }
/*     */ 
/* 324 */     if (user == null) {
/* 325 */       return null;
/*     */     }
/*     */ 
/* 328 */     return getRating(user, 2, message.getID());
/*     */   }
/*     */ 
/*     */   public Rating getRating(User user, ForumThread thread) {
/* 332 */     if (thread == null) {
/* 333 */       throw new IllegalArgumentException("Cannot retrieve rating for null thread");
/*     */     }
/*     */ 
/* 336 */     if (user == null) {
/* 337 */       return null;
/*     */     }
/* 339 */     return getRating(user, 1, thread.getID());
/*     */   }
/*     */ 
/*     */   private Rating getRating(User user, int objectType, long objectID) {
/* 343 */     String ratingCacheKey = getCacheKey(objectType, objectID);
/*     */ 
/* 345 */     if (RatingManagerFactory.ratingsCache.get(ratingCacheKey) == null) {
/* 346 */       loadRatings(objectType, objectID);
/*     */     }
/*     */ 
/* 349 */     RatingCacheObject cacheObject = (RatingCacheObject)RatingManagerFactory.ratingsCache.get(ratingCacheKey);
/* 350 */     Map userRatings = cacheObject.getUserRatings();
/*     */ 
/* 352 */     if (userRatings.containsKey(new Long(user.getID()))) {
/* 353 */       int score = ((Rating)userRatings.get(new Long(user.getID()))).getScore();
/* 354 */       return getRatingFromScore(score);
/*     */     }
/*     */ 
/* 357 */     return null;
/*     */   }
/*     */ 
/*     */   public void addRating(User user, ForumMessage message, Rating rating)
/*     */     throws UnauthorizedException
/*     */   {
/* 364 */     if (!this.ratingsEnabled) {
/* 365 */       return;
/*     */     }
/*     */ 
/* 368 */     if (message == null) {
/* 369 */       throw new IllegalArgumentException("Cannot add rating to null message");
/*     */     }
/*     */ 
/* 372 */     if (rating == null) {
/* 373 */       throw new IllegalStateException("Rating cannot be null");
/*     */     }
/*     */ 
/* 376 */     Rating oldRating = getRating(user, message);
/* 377 */     boolean updated = addRating(user, 2, message.getID(), rating);
/*     */ 
/* 379 */     if (updated)
/*     */     {
/* 381 */       Map params = new HashMap();
/* 382 */       params.put("User", user);
/* 383 */       params.put("Rating", rating);
/* 384 */       if (oldRating != null) {
/* 385 */         params.put("PreviousRating", oldRating);
/*     */       }
/*     */ 
/* 388 */       MessageEvent event = new MessageEvent(104, message, params);
/* 389 */       MessageEventDispatcher.getInstance().dispatchEvent(event);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addRating(User user, ForumThread thread, Rating rating)
/*     */     throws UnauthorizedException
/*     */   {
/* 397 */     if (!this.ratingsEnabled) {
/* 398 */       return;
/*     */     }
/*     */ 
/* 401 */     if (thread == null) {
/* 402 */       throw new IllegalArgumentException("Cannot add rating to null thread");
/*     */     }
/*     */ 
/* 405 */     if (rating == null) {
/* 406 */       throw new IllegalStateException("Rating cannot be null");
/*     */     }
/*     */ 
/* 409 */     Rating oldRating = getRating(user, thread);
/* 410 */     boolean updated = addRating(user, 1, thread.getID(), rating);
/*     */ 
/* 412 */     if (updated)
/*     */     {
/* 414 */       Map params = new HashMap();
/* 415 */       params.put("User", user);
/* 416 */       params.put("Rating", rating);
/* 417 */       if (oldRating != null) {
/* 418 */         params.put("PreviousRating", oldRating);
/*     */       }
/*     */ 
/* 421 */       ThreadEvent event = new ThreadEvent(114, thread, params);
/* 422 */       ThreadEventDispatcher.getInstance().dispatchEvent(event);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean addRating(User user, int objectType, long objectID, Rating rating) {
/* 427 */     String ratingCacheKey = getCacheKey(objectType, objectID);
/*     */ 
/* 429 */     if (RatingManagerFactory.ratingsCache.get(ratingCacheKey) == null) {
/* 430 */       loadRatings(objectType, objectID);
/*     */     }
/*     */ 
/* 433 */     RatingCacheObject cacheObject = (RatingCacheObject)RatingManagerFactory.ratingsCache.get(ratingCacheKey);
/* 434 */     Map userRatings = cacheObject.getUserRatings();
/* 435 */     List guestRatings = cacheObject.getGuestRatings();
/*     */ 
/* 437 */     Connection con = null;
/* 438 */     PreparedStatement pstmt = null;
/* 439 */     Rating oldRating = null;
/* 440 */     boolean abortTransaction = false;
/*     */     try
/*     */     {
/* 443 */       if (!hasRated(user, objectType, objectID)) {
/* 444 */         con = ConnectionManager.getTransactionConnection();
/* 445 */         pstmt = con.prepareStatement("INSERT INTO jiveRating (objectID, objectType, userID, score) VALUES (?, ?, ?, ?)");
/* 446 */         pstmt.setLong(1, objectID);
/* 447 */         pstmt.setInt(2, objectType);
/* 448 */         if (user != null) {
/* 449 */           pstmt.setLong(3, user.getID());
/*     */         }
/*     */         else {
/* 452 */           pstmt.setLong(3, -1L);
/*     */         }
/* 454 */         pstmt.setInt(4, rating.getScore());
/* 455 */         pstmt.execute();
/*     */       }
/*     */       else {
/* 458 */         oldRating = getRating(user, objectType, objectID);
/*     */ 
/* 460 */         if (oldRating == rating) {
/* 461 */           return false;
/*     */         }
/*     */ 
/* 464 */         con = ConnectionManager.getTransactionConnection();
/* 465 */         pstmt = con.prepareStatement("UPDATE jiveRating set score=? WHERE objectID=? AND objectType=? AND userID=?");
/* 466 */         pstmt.setInt(1, rating.getScore());
/* 467 */         pstmt.setLong(2, objectID);
/* 468 */         pstmt.setInt(3, objectType);
/* 469 */         pstmt.setLong(4, user.getID());
/* 470 */         pstmt.execute();
/*     */       }
/*     */ 
/* 473 */       if (user != null) {
/* 474 */         userRatings.put(new Long(user.getID()), rating);
/*     */       }
/*     */       else {
/* 477 */         guestRatings.add(rating);
/*     */       }
/*     */ 
/* 481 */       cacheObject.calculateMeanRating();
/*     */ 
/* 484 */       RatingManagerFactory.ratingsCache.put(ratingCacheKey, cacheObject);
/*     */     }
/*     */     catch (SQLException e) {
/* 487 */       Log.error(e);
/* 488 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 491 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */ 
/* 494 */     if (!abortTransaction) {
/* 495 */       return true;
/*     */     }
/*     */ 
/* 498 */     return false;
/*     */   }
/*     */ 
/*     */   protected void sortRatings()
/*     */   {
/* 503 */     Collections.sort(this.availableRatings, new Comparator() {
/*     */       public int compare(Object o1, Object o2) {
/* 505 */         Rating rating1 = (Rating)o1;
/* 506 */         Rating rating2 = (Rating)o2;
/* 507 */         if (rating1.getScore() == rating2.getScore()) {
/* 508 */           return 0;
/*     */         }
/* 510 */         if (rating1.getScore() > rating2.getScore()) {
/* 511 */           return 1;
/*     */         }
/*     */ 
/* 514 */         return -1;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   protected void loadAvailableRatings()
/*     */   {
/* 521 */     this.availableRatings = new ArrayList();
/* 522 */     Connection con = null;
/* 523 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 526 */       con = ConnectionManager.getConnection();
/* 527 */       pstmt = con.prepareStatement("SELECT score, description FROM jiveRatingType ORDER BY score ASC");
/* 528 */       ResultSet rs = pstmt.executeQuery();
/* 529 */       while (rs.next()) {
/* 530 */         DbRating rating = new DbRating(rs.getInt(1), rs.getString(2));
/* 531 */         this.availableRatings.add(rating);
/*     */       }
/* 533 */       rs.close();
/*     */     } catch (SQLException e) {
/* 535 */       Log.error(e);
/*     */     } finally {
/* 537 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void loadRatings(int objectType, long objectID) {
/* 542 */     Map userRatings = new Hashtable();
/* 543 */     List guestRatings = new ArrayList();
/* 544 */     Connection con = null;
/* 545 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 548 */       con = ConnectionManager.getConnection();
/* 549 */       pstmt = con.prepareStatement("SELECT r.score, t.description, r.userID FROM jiveRating r, jiveRatingType t WHERE r.objectID=? AND r.objectType=? AND r.score = t.score ORDER BY r.score DESC");
/* 550 */       pstmt.setLong(1, objectID);
/* 551 */       pstmt.setInt(2, objectType);
/* 552 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 554 */       while (rs.next()) {
/* 555 */         Rating rating = new DbRating(rs.getInt(1), rs.getString(2));
/* 556 */         if (rs.getLong(3) != -1L) {
/* 557 */           userRatings.put(new Long(rs.getLong(3)), rating);
/*     */         }
/*     */         else {
/* 560 */           guestRatings.add(rating);
/*     */         }
/*     */       }
/* 563 */       rs.close();
/*     */ 
/* 565 */       RatingCacheObject cacheObject = new RatingCacheObject(userRatings, guestRatings);
/* 566 */       RatingManagerFactory.ratingsCache.put(getCacheKey(objectType, objectID), cacheObject);
/*     */     } catch (SQLException e) {
/* 568 */       Log.error(e);
/*     */     } finally {
/* 570 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   static String getCacheKey(int objectType, long objectID)
/*     */   {
/* 582 */     String key = null;
/* 583 */     switch (objectType) {
/*     */     case 2:
/* 585 */       key = "m-" + objectID;
/* 586 */       break;
/*     */     case 1:
/* 588 */       key = "t-" + objectID;
/* 589 */       break;
/*     */     default:
/* 591 */       throw new IllegalArgumentException("Object type invalid.");
/*     */     }
/* 593 */     return key.intern();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbRatingManager
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.forum.StatusLevelManager;
/*     */ import com.jivesoftware.forum.StatusLevelManagerFactory;
/*     */ import com.jivesoftware.forum.StatusLevelNotFoundException;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class StatusLevelIterator
/*     */   implements Iterator
/*     */ {
/*     */   private long[] elements;
/*  39 */   private int currentIndex = -1;
/*  40 */   private Object nextElement = null;
/*     */   private DatabaseObjectFactory objectFactory;
/*     */ 
/*     */   public StatusLevelIterator(long[] elements)
/*     */   {
/*  45 */     this.elements = elements;
/*     */ 
/*  47 */     this.objectFactory = new DatabaseObjectFactory()
/*     */     {
/*     */       public Object loadObject(long id) {
/*     */         try {
/*  51 */           return StatusLevelManagerFactory.getInstance().getStatusLevel(id);
/*     */         }
/*     */         catch (StatusLevelNotFoundException e)
/*     */         {
/*  56 */           Log.error(e);
/*     */         }
/*  58 */         return null;
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/*  71 */     if ((this.currentIndex + 1 >= this.elements.length) && (this.nextElement == null)) {
/*  72 */       return false;
/*     */     }
/*     */ 
/*  76 */     if (this.nextElement == null) {
/*  77 */       this.nextElement = getNextElement();
/*  78 */       if (this.nextElement == null) {
/*  79 */         return false;
/*     */       }
/*     */     }
/*  82 */     return true;
/*     */   }
/*     */ 
/*     */   public Object next()
/*     */     throws NoSuchElementException
/*     */   {
/*  93 */     Object element = null;
/*  94 */     if (this.nextElement != null) {
/*  95 */       element = this.nextElement;
/*  96 */       this.nextElement = null;
/*     */     }
/*     */     else {
/*  99 */       element = getNextElement();
/* 100 */       if (element == null) {
/* 101 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/* 104 */     return element;
/*     */   }
/*     */ 
/*     */   public void remove()
/*     */     throws UnsupportedOperationException
/*     */   {
/* 111 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Object getNextElement()
/*     */   {
/* 120 */     while (this.currentIndex + 1 < this.elements.length) {
/* 121 */       this.currentIndex += 1;
/* 122 */       Object element = this.objectFactory.loadObject(this.elements[this.currentIndex]);
/* 123 */       if (element != null) {
/* 124 */         return element;
/*     */       }
/*     */     }
/* 127 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.StatusLevelIterator
 * JD-Core Version:    0.6.2
 */
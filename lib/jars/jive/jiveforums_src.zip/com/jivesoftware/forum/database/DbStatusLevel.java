/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Group;
/*     */ import com.jivesoftware.base.GroupManager;
/*     */ import com.jivesoftware.base.GroupNotFoundException;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.database.sequence.SequenceManager;
/*     */ import com.jivesoftware.forum.StatusLevel;
/*     */ import com.jivesoftware.forum.StatusLevelException;
/*     */ import com.jivesoftware.forum.StatusLevelManager;
/*     */ import com.jivesoftware.forum.StatusLevelManagerFactory;
/*     */ import com.jivesoftware.forum.StatusLevelNotFoundException;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheSizes;
/*     */ import com.jivesoftware.util.Cacheable;
/*     */ import com.jivesoftware.util.ExtendedPropertyUtils;
/*     */ import com.jivesoftware.util.ExternalizableLiteUtil;
/*     */ import com.tangosol.io.ExternalizableLite;
/*     */ import com.tangosol.util.ExternalizableHelper;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collections;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DbStatusLevel
/*     */   implements StatusLevel, Cacheable, ExternalizableLite
/*     */ {
/*     */   private static final String ADD_STATUS_LEVEL = "INSERT INTO jiveStatusLevel (statusLevelID, name, description, imagePath, largeImagePath, minPoints, maxPoints, groupID) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
/*     */   private static final String LOAD_BY_ID = "SELECT statusLevelID, name, description, imagePath, largeImagePath, minPoints, maxPoints, groupID FROM jiveStatusLevel WHERE statusLevelID=?";
/*     */   private static final String LOAD_BY_NAME = "SELECT statusLevelID, name, description, imagePath, largeImagePath, minPoints, maxPoints, groupID from jiveStatusLevel WHERE name=?";
/*     */   private static final String SAVE_STATUS_LEVEL = "UPDATE jiveStatusLevel SET name=?, description=?, imagePath=?, largeImagePath = ?, minPoints=?, maxPoints=?, groupID=? WHERE statusLevelID = ?";
/*     */   private static final String LOAD_PROPERTIES = "SELECT name, propValue FROM jiveStatusLevelProp WHERE statusLevelID=?";
/*     */   private static final String INSERT_PROPERTY = "INSERT INTO jiveStatusLevelProp (statusLevelID,name,propValue) VALUES(?,?,?)";
/*     */   private static final String UPDATE_PROPERTY = "UPDATE jiveStatusLevelProp SET propValue=? WHERE name=? AND statusLevelID=?";
/*     */   private static final String DELETE_PROPERTY = "DELETE FROM jiveStatusLevelProp WHERE statusLevelID=? AND name=?";
/*  64 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */   private static final boolean LAZY_PROP_LOADING = true;
/*  77 */   private long id = -1L;
/*     */   private String name;
/*     */   private String description;
/*     */   private String imagePath;
/*     */   private String largeImagePath;
/*     */   private int minPoints;
/*     */   private int maxPoints;
/*     */   private long groupID;
/*     */   private Map properties;
/*     */ 
/*     */   public DbStatusLevel()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected DbStatusLevel(String name, String imagePath, int minPoints, int maxPoints)
/*     */     throws StatusLevelException
/*     */   {
/* 102 */     if (name == null) {
/* 103 */       throw new StatusLevelException("Name cannot be null!");
/*     */     }
/*     */ 
/* 106 */     if (imagePath == null) {
/* 107 */       throw new StatusLevelException("Image path cannot be null");
/*     */     }
/*     */ 
/* 111 */     checkPointRange(minPoints, maxPoints);
/*     */ 
/* 113 */     this.id = SequenceManager.nextID(25);
/* 114 */     this.name = name;
/* 115 */     this.imagePath = imagePath;
/*     */ 
/* 117 */     this.minPoints = minPoints;
/* 118 */     this.maxPoints = maxPoints;
/* 119 */     this.groupID = -1L;
/*     */ 
/* 121 */     insertIntoDb();
/*     */   }
/*     */ 
/*     */   protected DbStatusLevel(String name, String imagePath, Group group)
/*     */     throws StatusLevelException
/*     */   {
/* 136 */     if (name == null) {
/* 137 */       throw new StatusLevelException("Name cannot be null!");
/*     */     }
/*     */ 
/* 140 */     if (imagePath == null) {
/* 141 */       throw new StatusLevelException("Image Path cannot be null");
/*     */     }
/*     */ 
/* 144 */     if (group == null) {
/* 145 */       throw new StatusLevelException("A group must be specified");
/*     */     }
/*     */ 
/* 148 */     checkGroup(group);
/*     */ 
/* 150 */     this.id = SequenceManager.nextID(25);
/* 151 */     this.name = name;
/* 152 */     this.groupID = group.getID();
/* 153 */     this.imagePath = imagePath;
/* 154 */     this.minPoints = -1;
/* 155 */     this.maxPoints = -1;
/*     */ 
/* 157 */     insertIntoDb();
/*     */   }
/*     */ 
/*     */   protected DbStatusLevel(long id) throws StatusLevelNotFoundException {
/* 161 */     if (id < 0L) {
/* 162 */       throw new StatusLevelNotFoundException("ID " + id + " is not valid.");
/*     */     }
/* 164 */     this.id = id;
/* 165 */     loadFromDb();
/*     */   }
/*     */ 
/*     */   protected DbStatusLevel(String name) throws StatusLevelNotFoundException {
/* 169 */     if (name == null) {
/* 170 */       throw new StatusLevelNotFoundException("Name cannot be null");
/*     */     }
/* 172 */     this.name = name;
/* 173 */     loadFromDb();
/*     */   }
/*     */ 
/*     */   public long getID() {
/* 177 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setName(String name) throws UnauthorizedException, StatusLevelException {
/* 181 */     if (this.name.equals(name)) {
/* 182 */       return;
/*     */     }
/*     */ 
/* 185 */     if (name == null) {
/* 186 */       throw new StatusLevelException("name cannot be null");
/*     */     }
/*     */ 
/* 189 */     this.name = name;
/* 190 */     saveToDb();
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 194 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setDescription(String description) throws UnauthorizedException {
/* 198 */     this.description = description;
/* 199 */     saveToDb();
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 203 */     return this.description;
/*     */   }
/*     */ 
/*     */   public void setImagePath(String imagePath) throws UnauthorizedException, StatusLevelException {
/* 207 */     if (imagePath == null) {
/* 208 */       throw new StatusLevelException("imagePath cannot be null");
/*     */     }
/* 210 */     this.imagePath = imagePath;
/* 211 */     saveToDb();
/*     */   }
/*     */ 
/*     */   public String getImagePath() {
/* 215 */     return this.imagePath;
/*     */   }
/*     */ 
/*     */   public String getLargeImagePath() {
/* 219 */     return this.largeImagePath;
/*     */   }
/*     */ 
/*     */   public void setLargeImagePath(String largeImagePath) throws UnauthorizedException
/*     */   {
/* 224 */     if ((largeImagePath == null) && (this.largeImagePath == null)) {
/* 225 */       return;
/*     */     }
/*     */ 
/* 229 */     if ((this.largeImagePath != null) && (this.largeImagePath.equals(largeImagePath))) {
/* 230 */       return;
/*     */     }
/*     */ 
/* 233 */     this.largeImagePath = largeImagePath;
/* 234 */     saveToDb();
/*     */   }
/*     */ 
/*     */   public int getMinPoints() {
/* 238 */     return this.minPoints;
/*     */   }
/*     */ 
/*     */   public int getMaxPoints() {
/* 242 */     return this.maxPoints;
/*     */   }
/*     */ 
/*     */   public void setPointRange(int minPoints, int maxPoints) throws UnauthorizedException, StatusLevelException
/*     */   {
/* 247 */     checkPointRange(minPoints, maxPoints);
/* 248 */     this.minPoints = minPoints;
/* 249 */     this.maxPoints = maxPoints;
/*     */ 
/* 251 */     if ((minPoints > -1) && (maxPoints > -1)) {
/* 252 */       this.groupID = -1L;
/*     */     }
/*     */ 
/* 255 */     saveToDb();
/*     */   }
/*     */ 
/*     */   public void setGroup(Group group) throws UnauthorizedException, StatusLevelException {
/* 259 */     if (group == null) {
/* 260 */       this.groupID = -1L;
/* 261 */       saveToDb();
/*     */ 
/* 263 */       StatusLevelManagerFactory.statusLevelCache.remove("_groupLevels");
/* 264 */       StatusLevelManagerFactory.statusLevelCache.remove("_pointLevels");
/* 265 */       return;
/*     */     }
/*     */ 
/* 268 */     checkGroup(group);
/* 269 */     this.groupID = group.getID();
/* 270 */     this.maxPoints = -1;
/* 271 */     this.minPoints = -1;
/* 272 */     saveToDb();
/*     */ 
/* 274 */     StatusLevelManagerFactory.statusLevelCache.remove("_groupLevels");
/* 275 */     StatusLevelManagerFactory.statusLevelCache.remove("_pointLevels");
/*     */   }
/*     */ 
/*     */   public Group getGroup() {
/* 279 */     if (this.groupID > 0L) {
/*     */       try {
/* 281 */         return FACTORY.getGroupManager().getGroup(this.groupID);
/*     */       }
/*     */       catch (GroupNotFoundException e) {
/* 284 */         Log.debug(e);
/*     */       }
/*     */     }
/* 287 */     return null;
/*     */   }
/*     */ 
/*     */   public String getProperty(String name) {
/* 291 */     if (this.properties == null) {
/* 292 */       loadPropertiesFromDb();
/*     */     }
/* 294 */     return (String)this.properties.get(name);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value) throws UnauthorizedException {
/* 298 */     if (this.properties == null) {
/* 299 */       loadPropertiesFromDb();
/*     */     }
/*     */ 
/* 302 */     value = ExtendedPropertyUtils.validateExtendedProperty(name, value);
/*     */ 
/* 304 */     if (this.properties.containsKey(name))
/*     */     {
/* 307 */       if (!value.equals(this.properties.get(name))) {
/* 308 */         this.properties.put(name, value);
/* 309 */         updatePropertyInDb(name, value);
/*     */ 
/* 311 */         StatusLevelManagerFactory.statusLevelCache.put(new Long(this.id), this);
/*     */       }
/*     */     } else {
/* 314 */       this.properties.put(name, value);
/* 315 */       insertPropertyIntoDb(name, value);
/*     */ 
/* 317 */       StatusLevelManagerFactory.statusLevelCache.put(new Long(this.id), this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) throws UnauthorizedException
/*     */   {
/* 323 */     if (this.properties == null) {
/* 324 */       loadPropertiesFromDb();
/*     */     }
/*     */ 
/* 327 */     if (this.properties.containsKey(name)) {
/* 328 */       this.properties.remove(name);
/* 329 */       deletePropertyFromDb(name);
/*     */ 
/* 331 */       StatusLevelManagerFactory.statusLevelCache.put(new Long(this.id), this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames() {
/* 336 */     if (this.properties == null) {
/* 337 */       loadPropertiesFromDb();
/*     */     }
/* 339 */     return Collections.unmodifiableSet(this.properties.keySet()).iterator();
/*     */   }
/*     */ 
/*     */   public int getCachedSize()
/*     */   {
/* 344 */     int size = 0;
/* 345 */     size += CacheSizes.sizeOfObject();
/* 346 */     size += CacheSizes.sizeOfLong();
/* 347 */     size += CacheSizes.sizeOfString(this.name);
/* 348 */     size += CacheSizes.sizeOfString(this.description);
/* 349 */     size += CacheSizes.sizeOfString(this.imagePath);
/* 350 */     size += CacheSizes.sizeOfInt();
/* 351 */     size += CacheSizes.sizeOfInt();
/* 352 */     size += CacheSizes.sizeOfLong();
/* 353 */     size += CacheSizes.sizeOfMap(this.properties);
/* 354 */     return size;
/*     */   }
/*     */ 
/*     */   public void readExternal(DataInput in) throws IOException {
/* 358 */     this.id = ExternalizableHelper.readLong(in);
/* 359 */     this.name = ExternalizableHelper.readSafeUTF(in);
/* 360 */     this.description = ExternalizableHelper.readSafeUTF(in);
/* 361 */     this.imagePath = ExternalizableHelper.readSafeUTF(in);
/* 362 */     this.minPoints = ExternalizableHelper.readInt(in);
/* 363 */     this.maxPoints = ExternalizableHelper.readInt(in);
/* 364 */     this.groupID = ExternalizableHelper.readLong(in);
/* 365 */     this.properties = ExternalizableLiteUtil.readStringMap(in);
/*     */   }
/*     */ 
/*     */   public void writeExternal(DataOutput out) throws IOException {
/* 369 */     ExternalizableHelper.writeLong(out, this.id);
/* 370 */     ExternalizableHelper.writeSafeUTF(out, this.name);
/* 371 */     ExternalizableHelper.writeSafeUTF(out, this.description);
/* 372 */     ExternalizableHelper.writeSafeUTF(out, this.imagePath);
/* 373 */     ExternalizableHelper.writeInt(out, this.minPoints);
/* 374 */     ExternalizableHelper.writeInt(out, this.maxPoints);
/* 375 */     ExternalizableHelper.writeLong(out, this.groupID);
/* 376 */     ExternalizableLiteUtil.writeStringMap(out, this.properties);
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 380 */     return (int)this.id;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o) {
/* 384 */     if (this == o) {
/* 385 */       return true;
/*     */     }
/*     */ 
/* 388 */     if ((o != null) && ((o instanceof ExternalizableLite))) {
/* 389 */       return this.id == ((ExternalizableLite)o).getID();
/*     */     }
/*     */ 
/* 392 */     return false;
/*     */   }
/*     */ 
/*     */   private void loadFromDb() throws StatusLevelNotFoundException
/*     */   {
/* 397 */     Connection con = null;
/* 398 */     PreparedStatement pstmt = null;
/* 399 */     ResultSet rs = null;
/*     */     try
/*     */     {
/* 402 */       con = ConnectionManager.getConnection();
/* 403 */       if (this.id > 0L) {
/* 404 */         pstmt = con.prepareStatement("SELECT statusLevelID, name, description, imagePath, largeImagePath, minPoints, maxPoints, groupID FROM jiveStatusLevel WHERE statusLevelID=?");
/* 405 */         pstmt.setLong(1, getID());
/*     */       }
/*     */       else {
/* 408 */         pstmt = con.prepareStatement("SELECT statusLevelID, name, description, imagePath, largeImagePath, minPoints, maxPoints, groupID from jiveStatusLevel WHERE name=?");
/* 409 */         pstmt.setString(1, getName());
/*     */       }
/* 411 */       rs = pstmt.executeQuery();
/* 412 */       if (!rs.next()) {
/* 413 */         throw new StatusLevelNotFoundException("StatusLevel " + getID() + " could not be loaded from the database");
/*     */       }
/*     */ 
/* 416 */       this.id = rs.getLong(1);
/* 417 */       this.name = rs.getString(2);
/* 418 */       this.description = rs.getString(3);
/* 419 */       this.imagePath = rs.getString(4);
/* 420 */       this.largeImagePath = rs.getString(5);
/* 421 */       this.minPoints = rs.getInt(6);
/* 422 */       this.maxPoints = rs.getInt(7);
/* 423 */       this.groupID = rs.getLong(8);
/*     */ 
/* 425 */       rs.close();
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 443 */       Log.error(e);
/* 444 */       throw new StatusLevelNotFoundException("StatusLevel " + getID() + " could not be loaded from the database");
/*     */     }
/*     */     finally
/*     */     {
/* 448 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 450 */     addToCache();
/*     */   }
/*     */ 
/*     */   private void insertIntoDb() {
/* 454 */     Connection con = null;
/* 455 */     PreparedStatement pstmt = null;
/* 456 */     boolean abortTransaction = false;
/*     */     try {
/* 458 */       con = ConnectionManager.getTransactionConnection();
/* 459 */       pstmt = con.prepareStatement("INSERT INTO jiveStatusLevel (statusLevelID, name, description, imagePath, largeImagePath, minPoints, maxPoints, groupID) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
/* 460 */       pstmt.setLong(1, this.id);
/* 461 */       pstmt.setString(2, this.name);
/* 462 */       pstmt.setString(3, this.description);
/* 463 */       pstmt.setString(4, this.imagePath);
/* 464 */       pstmt.setString(5, this.largeImagePath);
/* 465 */       pstmt.setInt(6, this.minPoints);
/* 466 */       pstmt.setInt(7, this.maxPoints);
/* 467 */       pstmt.setLong(8, this.groupID);
/* 468 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 471 */       Log.error(sqle);
/* 472 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 475 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */ 
/* 478 */     addToCache();
/*     */   }
/*     */ 
/*     */   private synchronized void saveToDb() {
/* 482 */     Connection con = null;
/* 483 */     PreparedStatement pstmt = null;
/*     */     try {
/* 485 */       con = ConnectionManager.getConnection();
/* 486 */       pstmt = con.prepareStatement("UPDATE jiveStatusLevel SET name=?, description=?, imagePath=?, largeImagePath = ?, minPoints=?, maxPoints=?, groupID=? WHERE statusLevelID = ?");
/* 487 */       pstmt.setString(1, this.name);
/* 488 */       pstmt.setString(2, this.description);
/* 489 */       pstmt.setString(3, this.imagePath);
/* 490 */       pstmt.setString(4, this.largeImagePath);
/* 491 */       pstmt.setInt(5, this.minPoints);
/* 492 */       pstmt.setInt(6, this.maxPoints);
/* 493 */       pstmt.setLong(7, this.groupID);
/* 494 */       pstmt.setLong(8, this.id);
/* 495 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 498 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 501 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 504 */     addToCache();
/*     */   }
/*     */ 
/*     */   private synchronized void loadPropertiesFromDb()
/*     */   {
/* 511 */     this.properties = new Hashtable();
/* 512 */     Connection con = null;
/* 513 */     PreparedStatement pstmt = null;
/*     */     try {
/* 515 */       con = ConnectionManager.getConnection();
/* 516 */       pstmt = con.prepareStatement("SELECT name, propValue FROM jiveStatusLevelProp WHERE statusLevelID=?");
/* 517 */       pstmt.setLong(1, this.id);
/* 518 */       ResultSet rs = pstmt.executeQuery();
/* 519 */       while (rs.next()) {
/* 520 */         String name = rs.getString(1);
/* 521 */         String value = rs.getString(2);
/* 522 */         this.properties.put(name, value);
/*     */       }
/* 524 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 527 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 530 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 534 */     StatusLevelManagerFactory.statusLevelCache.put(new Long(this.id), this);
/*     */   }
/*     */ 
/*     */   private void insertPropertyIntoDb(String name, String value)
/*     */   {
/* 541 */     Connection con = null;
/* 542 */     PreparedStatement pstmt = null;
/* 543 */     boolean abortTransaction = false;
/*     */     try {
/* 545 */       con = ConnectionManager.getTransactionConnection();
/* 546 */       pstmt = con.prepareStatement("INSERT INTO jiveStatusLevelProp (statusLevelID,name,propValue) VALUES(?,?,?)");
/* 547 */       pstmt.setLong(1, this.id);
/* 548 */       pstmt.setString(2, name);
/* 549 */       pstmt.setString(3, value);
/* 550 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 553 */       Log.error(sqle);
/* 554 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 557 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updatePropertyInDb(String name, String value)
/*     */   {
/* 565 */     Connection con = null;
/* 566 */     PreparedStatement pstmt = null;
/* 567 */     boolean abortTransaction = false;
/*     */     try {
/* 569 */       con = ConnectionManager.getTransactionConnection();
/* 570 */       pstmt = con.prepareStatement("UPDATE jiveStatusLevelProp SET propValue=? WHERE name=? AND statusLevelID=?");
/* 571 */       pstmt.setString(1, value);
/* 572 */       pstmt.setString(2, name);
/* 573 */       pstmt.setLong(3, this.id);
/* 574 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 577 */       Log.error(sqle);
/* 578 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 581 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void deletePropertyFromDb(String name)
/*     */   {
/* 589 */     Connection con = null;
/* 590 */     PreparedStatement pstmt = null;
/* 591 */     boolean abortTransaction = false;
/*     */     try {
/* 593 */       con = ConnectionManager.getTransactionConnection();
/* 594 */       pstmt = con.prepareStatement("DELETE FROM jiveStatusLevelProp WHERE statusLevelID=? AND name=?");
/* 595 */       pstmt.setLong(1, this.id);
/* 596 */       pstmt.setString(2, name);
/* 597 */       pstmt.execute();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 600 */       Log.error(sqle);
/* 601 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 604 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkPointRange(int minPoints, int maxPoints) throws StatusLevelException
/*     */   {
/* 610 */     if (minPoints < 0) {
/* 611 */       throw new StatusLevelException("Minimum point value must be zero or greater.");
/*     */     }
/*     */ 
/* 615 */     if ((minPoints > maxPoints) && (maxPoints > 0)) {
/* 616 */       throw new StatusLevelException("minPoints cannot be greater than maxPoints!");
/*     */     }
/*     */ 
/* 619 */     StatusLevelManager statusLevelManager = FACTORY.getStatusLevelManager();
/*     */ 
/* 623 */     for (Iterator i = statusLevelManager.getPointStatusLevels(); i.hasNext(); ) {
/* 624 */       StatusLevel statusLevel = (ExternalizableLite)i.next();
/*     */ 
/* 627 */       if (statusLevel.getID() != getID())
/*     */       {
/* 631 */         if (isInRange(minPoints, statusLevel)) {
/* 632 */           throw new StatusLevelException("Min points value is in the range for status level " + statusLevel.getName());
/*     */         }
/*     */ 
/* 636 */         if (isInRange(maxPoints, statusLevel)) {
/* 637 */           throw new StatusLevelException("Max points value is in range for status level" + statusLevel.getName());
/*     */         }
/*     */ 
/* 641 */         if ((maxPoints < 0) && (statusLevel.getMaxPoints() < 0))
/* 642 */           throw new StatusLevelException("Max points value is in range for status level" + statusLevel.getName());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isInRange(int value)
/*     */   {
/* 650 */     return isInRange(value, this);
/*     */   }
/*     */ 
/*     */   protected boolean isInRange(int value, StatusLevel statusLevel)
/*     */   {
/* 655 */     if ((statusLevel.getMinPoints() < 0) && (statusLevel.getMaxPoints() < 0)) {
/* 656 */       return false;
/*     */     }
/*     */ 
/* 660 */     if ((statusLevel.getMaxPoints() < 0) && (value >= statusLevel.getMinPoints())) {
/* 661 */       return true;
/*     */     }
/*     */ 
/* 665 */     return (value >= statusLevel.getMinPoints()) && (value <= statusLevel.getMaxPoints());
/*     */   }
/*     */ 
/*     */   protected void checkGroup(Group group)
/*     */     throws StatusLevelException
/*     */   {
/* 673 */     if (group == null) {
/* 674 */       return;
/*     */     }
/* 676 */     StatusLevelManager statusLevelManager = FACTORY.getStatusLevelManager();
/*     */ 
/* 678 */     for (Iterator i = statusLevelManager.getGroupStatusLevels(); i.hasNext(); ) {
/* 679 */       StatusLevel statusLevel = (ExternalizableLite)i.next();
/*     */ 
/* 682 */       if (statusLevel.getID() != getID())
/*     */       {
/* 686 */         if (statusLevel.getGroup().equals(group))
/* 687 */           throw new StatusLevelException("group " + group.getName() + " is already use by " + "status level --> " + statusLevel.getName());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addToCache()
/*     */   {
/* 694 */     StatusLevelManagerFactory.statusLevelIDCache.put(this.name, new Long(this.id));
/* 695 */     StatusLevelManagerFactory.statusLevelCache.put(new Long(this.id), this);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbStatusLevel
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.StatusLevelCalculator;
/*     */ import com.jivesoftware.forum.event.ForumEvent;
/*     */ import com.jivesoftware.forum.event.ForumEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ForumListener;
/*     */ import com.jivesoftware.forum.event.MessageEvent;
/*     */ import com.jivesoftware.forum.event.MessageEventDispatcher;
/*     */ import com.jivesoftware.forum.event.MessageListener;
/*     */ import com.jivesoftware.forum.event.ThreadEvent;
/*     */ import com.jivesoftware.forum.event.ThreadEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ThreadListener;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.CacheSizes;
/*     */ import com.jivesoftware.util.Cacheable;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import com.tangosol.io.ExternalizableLite;
/*     */ import com.tangosol.util.ExternalizableHelper;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ public class PostCountStatusLevelCalculator
/*     */   implements StatusLevelCalculator, MessageListener, ForumListener, ThreadListener
/*     */ {
/*  39 */   public static final Cache postCountCache = CacheFactory.createCache("User Forum and Category Post Counts", "postCountCache", 65536, 43200000L);
/*     */   private static final String SYSTEM_LEADERS = "SELECT userID, count(messageID) AS cnt FROM jiveMessage WHERE modValue >= 1 AND userID IS NOT NULL  GROUP BY userID ORDER BY cnt DESC";
/*     */   private static final String FORUM_LEADERS = "SELECT userID, count(jiveMessage.messageID) as cnt FROM jiveMessage WHERE forumID = ? AND modValue >= 1 AND userID IS NOT NULL  GROUP BY jiveMessage.userID ORDER BY cnt DESC";
/*     */   private static final String CATEGORY_LEADERS = "SELECT jiveMessage.userID, count(jiveMessage.messageID) AS cnt FROM jiveMessage, jiveForum, jiveCategory WHERE jiveMessage.forumID=jiveForum.forumID  AND jiveForum.categoryID=jiveCategory.categoryID  AND jiveCategory.lft >= ? AND jiveCategory.rgt <= ? AND jiveMessage.modValue >= 1 AND jiveMessage.userID IS NOT NULL  GROUP BY jiveMessage.userID ORDER BY cnt DESC";
/*  67 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */ 
/*     */   public PostCountStatusLevelCalculator()
/*     */   {
/*  71 */     MessageEventDispatcher.getInstance().addListener(this);
/*  72 */     ForumEventDispatcher.getInstance().addListener(this);
/*  73 */     ThreadEventDispatcher.getInstance().addListener(this);
/*     */   }
/*     */ 
/*     */   public int getPointLevel(User user) {
/*  77 */     return FACTORY.getUserMessageCount(user);
/*     */   }
/*     */ 
/*     */   public int getPointLevel(User user, Forum forum) {
/*  81 */     PostCountCacheKey key = new PostCountCacheKey(0, forum.getID(), user.getID());
/*     */ 
/*  83 */     Integer value = (Integer)postCountCache.get(key);
/*  84 */     if (value != null) {
/*  85 */       return value.intValue();
/*     */     }
/*     */ 
/*  89 */     ResultFilter filter = new ResultFilter();
/*  90 */     filter.setUserID(user.getID());
/*  91 */     int count = forum.getMessageCount(filter);
/*     */ 
/*  93 */     postCountCache.put(key, new Integer(count));
/*     */ 
/*  95 */     return count;
/*     */   }
/*     */ 
/*     */   public int getPointLevel(User user, ForumCategory category) {
/*  99 */     PostCountCacheKey key = new PostCountCacheKey(14, category.getID(), user.getID());
/*     */ 
/* 101 */     Integer value = (Integer)postCountCache.get(key);
/* 102 */     if (value != null) {
/* 103 */       return value.intValue();
/*     */     }
/*     */ 
/* 106 */     ResultFilter filter = new ResultFilter();
/* 107 */     filter.setUserID(user.getID());
/* 108 */     int count = category.getMessageCount(filter);
/*     */ 
/* 110 */     postCountCache.put(key, new Integer(count));
/*     */ 
/* 112 */     return count;
/*     */   }
/*     */ 
/*     */   public long[] getLeaderIds(int startIndex, int numResults) {
/* 116 */     LongList longList = new LongList();
/* 117 */     Connection con = null;
/* 118 */     PreparedStatement pstmt = null;
/*     */     try {
/* 120 */       con = ConnectionManager.getConnection();
/* 121 */       pstmt = ConnectionManager.createScrollablePreparedStatement(con, "SELECT userID, count(messageID) AS cnt FROM jiveMessage WHERE modValue >= 1 AND userID IS NOT NULL  GROUP BY userID ORDER BY cnt DESC");
/*     */ 
/* 123 */       ResultSet rs = pstmt.executeQuery();
/* 124 */       ConnectionManager.setFetchSize(rs, startIndex + numResults);
/* 125 */       ConnectionManager.scrollResultSet(rs, startIndex);
/*     */ 
/* 127 */       for (int i = 0; (i < numResults) && 
/* 128 */         (rs.next()); i++)
/*     */       {
/* 130 */         long userId = rs.getLong(1);
/* 131 */         int count = rs.getInt(2);
/*     */ 
/* 133 */         longList.add(userId);
/* 134 */         FACTORY.cacheManager.userMessageCountCache.put(new Long(userId), new Integer(count));
/*     */       }
/*     */ 
/* 142 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 145 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 148 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 152 */     return longList.toArray();
/*     */   }
/*     */ 
/*     */   public long[] getLeaderIds(ForumCategory category, int startIndex, int numResults) {
/* 156 */     LongList longList = new LongList();
/* 157 */     Connection con = null;
/* 158 */     PreparedStatement pstmt = null;
/*     */     try {
/* 160 */       con = ConnectionManager.getConnection();
/* 161 */       pstmt = con.prepareStatement("SELECT jiveMessage.userID, count(jiveMessage.messageID) AS cnt FROM jiveMessage, jiveForum, jiveCategory WHERE jiveMessage.forumID=jiveForum.forumID  AND jiveForum.categoryID=jiveCategory.categoryID  AND jiveCategory.lft >= ? AND jiveCategory.rgt <= ? AND jiveMessage.modValue >= 1 AND jiveMessage.userID IS NOT NULL  GROUP BY jiveMessage.userID ORDER BY cnt DESC");
/* 162 */       int[] leftright = DbForumCategory.getLftRgtValues(category.getID());
/* 163 */       pstmt.setLong(1, leftright[0]);
/* 164 */       pstmt.setLong(2, leftright[1]);
/*     */ 
/* 166 */       ResultSet rs = pstmt.executeQuery();
/* 167 */       ConnectionManager.setFetchSize(rs, startIndex + numResults);
/* 168 */       ConnectionManager.scrollResultSet(rs, startIndex);
/*     */ 
/* 170 */       for (int i = 0; (i < numResults) && 
/* 171 */         (rs.next()); i++)
/*     */       {
/* 172 */         long userID = rs.getLong(1);
/* 173 */         int count = rs.getInt(2);
/*     */ 
/* 175 */         longList.add(userID);
/*     */ 
/* 179 */         PostCountCacheKey key = new PostCountCacheKey(14, category.getID(), userID);
/*     */ 
/* 181 */         postCountCache.put(key, new Integer(count));
/*     */       }
/*     */ 
/* 187 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 190 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 193 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 196 */     return longList.toArray();
/*     */   }
/*     */ 
/*     */   public long[] getLeaderIds(Forum forum, int startIndex, int numResults) {
/* 200 */     LongList longList = new LongList();
/*     */ 
/* 202 */     Connection con = null;
/* 203 */     PreparedStatement pstmt = null;
/*     */     try {
/* 205 */       con = ConnectionManager.getConnection();
/* 206 */       pstmt = con.prepareStatement("SELECT userID, count(jiveMessage.messageID) as cnt FROM jiveMessage WHERE forumID = ? AND modValue >= 1 AND userID IS NOT NULL  GROUP BY jiveMessage.userID ORDER BY cnt DESC");
/* 207 */       pstmt.setLong(1, forum.getID());
/*     */ 
/* 209 */       ResultSet rs = pstmt.executeQuery();
/* 210 */       ConnectionManager.setFetchSize(rs, startIndex + numResults);
/* 211 */       ConnectionManager.scrollResultSet(rs, startIndex);
/*     */ 
/* 213 */       for (int i = 0; (i < numResults) && 
/* 214 */         (rs.next()); i++)
/*     */       {
/* 215 */         long userID = rs.getLong(1);
/* 216 */         int count = rs.getInt(2);
/*     */ 
/* 218 */         longList.add(userID);
/*     */ 
/* 221 */         PostCountCacheKey key = new PostCountCacheKey(0, forum.getID(), userID);
/*     */ 
/* 223 */         postCountCache.put(key, new Integer(count));
/*     */       }
/*     */ 
/* 229 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 232 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 235 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 238 */     return longList.toArray();
/*     */   }
/*     */ 
/*     */   public void messageAdded(MessageEvent event) {
/* 242 */     User user = event.getMessage().getUser();
/*     */ 
/* 245 */     if (user != null) {
/* 246 */       Forum forum = event.getMessage().getForum();
/* 247 */       addPointsToCache(forum, user.getID(), 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void messageDeleted(MessageEvent event) {
/* 252 */     User user = event.getMessage().getUser();
/*     */ 
/* 255 */     if (user != null) {
/* 256 */       Forum forum = event.getMessage().getForum();
/* 257 */       removePointsFromCache(forum, user.getID(), 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void messageMoved(MessageEvent event)
/*     */   {
/* 263 */     if (!event.getMessage().isAnonymous())
/* 264 */       postCountCache.clear(); 
/*     */   }
/*     */   public void messageModified(MessageEvent event) {
/*     */   }
/*     */   public void messageModerationModified(MessageEvent event) {
/*     */   }
/*     */ 
/*     */   public void messageRated(MessageEvent event) {
/*     */   }
/*     */ 
/*     */   public void forumAdded(ForumEvent event) {
/*     */   }
/*     */ 
/* 277 */   public void forumDeleted(ForumEvent event) { postCountCache.clear(); }
/*     */ 
/*     */   public void forumMoved(ForumEvent event)
/*     */   {
/* 281 */     postCountCache.clear();
/*     */   }
/*     */ 
/*     */   public void forumMerged(ForumEvent event) {
/* 285 */     postCountCache.clear();
/*     */   }
/*     */   public void threadAdded(ThreadEvent event) {
/*     */   }
/*     */ 
/*     */   public void threadDeleted(ThreadEvent event) {
/* 291 */     postCountCache.clear();
/*     */   }
/*     */ 
/*     */   public void threadMoved(ThreadEvent event) {
/* 295 */     postCountCache.clear();
/*     */   }
/*     */ 
/*     */   public void threadModerationModified(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadRated(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void addPointsToCache(Forum forum, long userID, int points)
/*     */   {
/* 395 */     PostCountCacheKey key = new PostCountCacheKey(0, forum.getID(), userID);
/*     */ 
/* 398 */     Integer value = (Integer)postCountCache.get(key);
/*     */ 
/* 401 */     if (value != null) {
/* 402 */       postCountCache.put(key, new Integer(value.intValue() + points));
/*     */     }
/*     */ 
/* 406 */     ForumCategory parent = forum.getForumCategory();
/* 407 */     if (parent != null)
/* 408 */       addPointsToCache(parent, userID, points);
/*     */   }
/*     */ 
/*     */   private void addPointsToCache(ForumCategory category, long userID, int points)
/*     */   {
/* 413 */     PostCountCacheKey key = new PostCountCacheKey(14, category.getID(), userID);
/*     */ 
/* 416 */     Integer value = (Integer)postCountCache.get(key);
/*     */ 
/* 419 */     if (value != null) {
/* 420 */       postCountCache.put(key, new Integer(value.intValue() + points));
/*     */     }
/*     */ 
/* 424 */     ForumCategory parent = category.getParentCategory();
/* 425 */     if (parent != null)
/* 426 */       addPointsToCache(parent, userID, points);
/*     */   }
/*     */ 
/*     */   private void removePointsFromCache(Forum forum, long userID, int points)
/*     */   {
/* 431 */     PostCountCacheKey key = new PostCountCacheKey(0, forum.getID(), userID);
/*     */ 
/* 434 */     Integer value = (Integer)postCountCache.get(key);
/*     */ 
/* 437 */     if (value != null) {
/* 438 */       postCountCache.put(key, new Integer(value.intValue() - points));
/*     */     }
/*     */ 
/* 442 */     ForumCategory parent = forum.getForumCategory();
/* 443 */     if (parent != null)
/* 444 */       removePointsFromCache(parent, userID, points);
/*     */   }
/*     */ 
/*     */   private void removePointsFromCache(ForumCategory category, long userID, int points)
/*     */   {
/* 449 */     PostCountCacheKey key = new PostCountCacheKey(0, category.getID(), userID);
/*     */ 
/* 452 */     Integer value = (Integer)postCountCache.get(key);
/*     */ 
/* 455 */     if (value != null) {
/* 456 */       postCountCache.put(key, new Integer(value.intValue() - points));
/*     */     }
/*     */ 
/* 460 */     ForumCategory parent = category.getParentCategory();
/* 461 */     if (parent != null)
/* 462 */       removePointsFromCache(parent, userID, points);
/*     */   }
/*     */ 
/*     */   public static class PostCountCacheKey
/*     */     implements Cacheable, ExternalizableLite
/*     */   {
/*     */     private int objectType;
/*     */     private long objectID;
/*     */     private long userID;
/*     */ 
/*     */     public PostCountCacheKey()
/*     */     {
/*     */     }
/*     */ 
/*     */     public PostCountCacheKey(int objectType, long objectId, long userID)
/*     */     {
/* 313 */       this.objectType = objectType;
/* 314 */       this.objectID = objectId;
/* 315 */       this.userID = userID;
/*     */     }
/*     */ 
/*     */     public int getObjectType() {
/* 319 */       return this.objectType;
/*     */     }
/*     */ 
/*     */     public long getObjectID() {
/* 323 */       return this.objectID;
/*     */     }
/*     */ 
/*     */     public long getUserID() {
/* 327 */       return this.userID;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o) {
/* 331 */       if (this == o) {
/* 332 */         return true;
/*     */       }
/* 334 */       if (!(o instanceof PostCountCacheKey)) {
/* 335 */         return false;
/*     */       }
/*     */ 
/* 338 */       PostCountCacheKey keyPostCount = (PostCountCacheKey)o;
/*     */ 
/* 340 */       if (this.objectID != keyPostCount.objectID) {
/* 341 */         return false;
/*     */       }
/* 343 */       if (this.objectType != keyPostCount.objectType) {
/* 344 */         return false;
/*     */       }
/* 346 */       if (this.userID != keyPostCount.userID) {
/* 347 */         return false;
/*     */       }
/*     */ 
/* 350 */       return true;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 355 */       int result = this.objectType;
/* 356 */       result = 1429 * result + (int)(this.objectID ^ this.objectID >>> 32);
/* 357 */       result = 1429 * result + (int)(this.userID ^ this.userID >>> 32);
/* 358 */       return result;
/*     */     }
/*     */ 
/*     */     public void writeExternal(DataOutput out) throws IOException {
/* 362 */       ExternalizableHelper.writeInt(out, this.objectType);
/* 363 */       ExternalizableHelper.writeLong(out, this.objectID);
/* 364 */       ExternalizableHelper.writeLong(out, this.userID);
/*     */     }
/*     */ 
/*     */     public void readExternal(DataInput in) throws IOException {
/* 368 */       this.objectType = ExternalizableHelper.readInt(in);
/* 369 */       this.objectID = ExternalizableHelper.readLong(in);
/* 370 */       this.userID = ExternalizableHelper.readLong(in);
/*     */     }
/*     */ 
/*     */     public int getCachedSize() {
/* 374 */       int size = 0;
/* 375 */       size += CacheSizes.sizeOfObject();
/* 376 */       size += CacheSizes.sizeOfInt();
/* 377 */       size += CacheSizes.sizeOfLong();
/* 378 */       size += CacheSizes.sizeOfLong();
/* 379 */       return size;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 383 */       return "CacheKey[ objectType=" + this.objectType + ", objectID=" + this.objectID + ", userID=" + this.userID + " ]";
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.PostCountStatusLevelCalculator
 * JD-Core Version:    0.6.2
 */
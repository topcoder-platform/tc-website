/*    */ package com.jivesoftware.forum.database;
/*    */ 
/*    */ import com.jivesoftware.base.AuthFactory;
/*    */ import com.jivesoftware.forum.Query;
/*    */ import com.jivesoftware.forum.QueryResult;
/*    */ import com.jivesoftware.forum.RatingManager;
/*    */ import com.jivesoftware.forum.RatingManagerFactory;
/*    */ import java.util.Comparator;
/*    */ import java.util.Date;
/*    */ 
/*    */ class QueryResultComparator
/*    */   implements Comparator
/*    */ {
/*    */   private Query query;
/*    */ 
/*    */   public QueryResultComparator(Query dbQuery)
/*    */   {
/* 21 */     this.query = dbQuery;
/*    */   }
/*    */ 
/*    */   public int compare(Object object1, Object object2) {
/* 25 */     QueryResult r1 = (QueryResult)object1;
/* 26 */     QueryResult r2 = (QueryResult)object2;
/*    */ 
/* 28 */     int result = 0;
/*    */ 
/* 30 */     if ((this.query.getSortField() == 10001) && (this.query.getSortOrder() == 0)) {
/* 31 */       result = new Double(r2.getRelevance()).compareTo(new Double(r1.getRelevance()));
/*    */ 
/* 33 */       if (result == 0) {
/* 34 */         result = r1.getSubject().toLowerCase().compareTo(r2.getSubject().toLowerCase());
/*    */       }
/*    */ 
/* 37 */       return result;
/*    */     }
/*    */ 
/* 40 */     if ((this.query.getSortField() == 10001) && (this.query.getSortOrder() == 1)) {
/* 41 */       result = new Double(r1.getRelevance()).compareTo(new Double(r2.getRelevance()));
/*    */ 
/* 43 */       if (result == 0) {
/* 44 */         result = r1.getSubject().toLowerCase().compareTo(r2.getSubject().toLowerCase());
/*    */       }
/*    */ 
/* 47 */       return result;
/*    */     }
/* 49 */     if ((this.query.getSortField() == 9) && (this.query.getSortOrder() == 0)) {
/* 50 */       result = r2.getModificationDate().compareTo(r1.getModificationDate());
/*    */     }
/* 52 */     else if ((this.query.getSortField() == 9) && (this.query.getSortOrder() == 1)) {
/* 53 */       result = r1.getModificationDate().compareTo(r2.getModificationDate());
/*    */     }
/* 55 */     else if ((this.query.getSortField() == 107) && (this.query.getSortOrder() == 1)) {
/* 56 */       RatingManager manager = RatingManagerFactory.getInstance(AuthFactory.getAnonymousAuthToken());
/*    */ 
/* 58 */       result = new Double(manager.getMeanRating(r1.getMessageID())).compareTo(new Double(manager.getMeanRating(r2.getMessageID())));
/*    */     }
/* 61 */     else if ((this.query.getSortField() == 107) && (this.query.getSortOrder() == 0)) {
/* 62 */       RatingManager manager = RatingManagerFactory.getInstance(AuthFactory.getAnonymousAuthToken());
/*    */ 
/* 64 */       result = new Double(manager.getMeanRating(r2.getMessageID())).compareTo(new Double(manager.getMeanRating(r1.getMessageID())));
/*    */     }
/* 67 */     else if ((this.query.getSortField() == 6) && (this.query.getSortOrder() == 0)) {
/* 68 */       result = r2.getSubject().toLowerCase().compareTo(r1.getSubject().toLowerCase());
/*    */     }
/* 70 */     else if ((this.query.getSortField() == 6) && (this.query.getSortOrder() == 1)) {
/* 71 */       result = r1.getSubject().toLowerCase().compareTo(r2.getSubject().toLowerCase());
/*    */     }
/*    */     else
/*    */     {
/* 75 */       return new Double(r2.getRelevance()).compareTo(new Double(r1.getRelevance()));
/*    */     }
/*    */ 
/* 79 */     if ((result == 0) && (this.query.getSortOrder() == 0)) {
/* 80 */       result = new Double(r2.getRelevance()).compareTo(new Double(r1.getRelevance()));
/*    */     }
/* 82 */     else if ((result == 0) && (this.query.getSortOrder() == 1)) {
/* 83 */       result = new Double(r1.getRelevance()).compareTo(new Double(r2.getRelevance()));
/*    */     }
/*    */ 
/* 86 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.QueryResultComparator
 * JD-Core Version:    0.6.2
 */
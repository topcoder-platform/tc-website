/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Group;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.event.GroupEvent;
/*     */ import com.jivesoftware.base.event.GroupEventDispatcher;
/*     */ import com.jivesoftware.base.event.GroupListener;
/*     */ import com.jivesoftware.base.event.JivePropertyEvent;
/*     */ import com.jivesoftware.base.event.JivePropertyEventDispatcher;
/*     */ import com.jivesoftware.base.event.JivePropertyListener;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.StatusLevel;
/*     */ import com.jivesoftware.forum.StatusLevelAlreadyExistsException;
/*     */ import com.jivesoftware.forum.StatusLevelCalculator;
/*     */ import com.jivesoftware.forum.StatusLevelException;
/*     */ import com.jivesoftware.forum.StatusLevelManager;
/*     */ import com.jivesoftware.forum.StatusLevelManagerFactory;
/*     */ import com.jivesoftware.forum.StatusLevelNotFoundException;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheSizes;
/*     */ import com.jivesoftware.util.Cacheable;
/*     */ import com.jivesoftware.util.CoherenceCache;
/*     */ import com.jivesoftware.util.CoherenceCache.Entry;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import com.jivesoftware.util.StringUtils;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import com.tangosol.io.ExternalizableLite;
/*     */ import com.tangosol.net.Cluster;
/*     */ import com.tangosol.net.Member;
/*     */ import com.tangosol.util.Binary;
/*     */ import com.tangosol.util.ExternalizableHelper;
/*     */ import com.tangosol.util.SafeHashMap.Entry;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class DbStatusLevelManager
/*     */   implements StatusLevelManager, GroupListener, JivePropertyListener
/*     */ {
/*     */   static final String POINT_LEVELS = "_pointLevels";
/*     */   static final String GROUP_LEVELS = "_groupLevels";
/*     */   private static final String DELETE_STATUS_LEVEL = "DELETE FROM jiveStatusLevel where statusLevelID = ?";
/*     */   private static final String DELETE_STATUS_LEVEL_PROPS = "DELETE FROM jiveStatusLevelProp where statusLevelID = ?";
/*     */   private static final String ALL_GROUP_STATUS_LEVELS = "SELECT statusLevelID FROM jiveStatusLevel WHERE groupID > 0";
/*     */   private static final String ALL_POINT_STATUS_LEVELS = "SELECT statusLevelID FROM jiveStatusLevel WHERE groupID < 0 ORDER BY minPoints DESC";
/*     */   private static final String DELETE_STATUS_LEVEL_BY_GROUP = "DELETE FROM jiveStatusLevel WHERE groupID = ?";
/*  53 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */ 
/*  56 */   private static final LeaderQueryCache leaderQueryCache = new LeaderQueryCache("leaderQueryCache", 524288, 21600000L);
/*     */   private static final long REUPDATE_TIME = 300000L;
/*  62 */   private static final Object updateLock = new Object();
/*     */   public static final int BLOCK_SIZE = 100;
/*     */ 
/*     */   public DbStatusLevelManager()
/*     */   {
/*  72 */     GroupEventDispatcher.getInstance().addListener(this);
/*  73 */     JivePropertyEventDispatcher.getInstance().addListener(this);
/*     */   }
/*     */ 
/*     */   public StatusLevel createStatusLevel(String name, String imagePath, int minPoints, int maxPoints)
/*     */     throws UnauthorizedException, StatusLevelException, StatusLevelAlreadyExistsException
/*     */   {
/*  79 */     StatusLevel newStatusLevel = null;
/*  80 */     name = name.trim();
/*  81 */     name = StringUtils.replace(name, "&nbsp;", "");
/*     */     try {
/*  83 */       getStatusLevel(name);
/*     */ 
/*  85 */       throw new StatusLevelAlreadyExistsException("Status level " + name + " already exists");
/*     */     }
/*     */     catch (StatusLevelNotFoundException e)
/*     */     {
/*  90 */       newStatusLevel = new DbStatusLevel(name, imagePath, minPoints, maxPoints);
/*     */ 
/*  96 */       StatusLevelManagerFactory.statusLevelCache.remove("_pointLevels");
/*     */     }
/*  98 */     return newStatusLevel;
/*     */   }
/*     */ 
/*     */   public StatusLevel createStatusLevel(String name, String imagePath, Group group) throws UnauthorizedException, StatusLevelException, StatusLevelAlreadyExistsException
/*     */   {
/* 103 */     StatusLevel newStatusLevel = null;
/* 104 */     name = name.trim();
/* 105 */     name = StringUtils.replace(name, "&nbsp;", "");
/*     */     try
/*     */     {
/* 108 */       getStatusLevel(name);
/*     */ 
/* 110 */       throw new StatusLevelAlreadyExistsException("Status level " + name + " already exists");
/*     */     }
/*     */     catch (StatusLevelNotFoundException e) {
/* 113 */       newStatusLevel = new DbStatusLevel(name, imagePath, group);
/*     */ 
/* 117 */       LongList groupLevels = (LongList)StatusLevelManagerFactory.statusLevelCache.get("_groupLevels");
/*     */ 
/* 119 */       if (groupLevels != null) {
/* 120 */         groupLevels.add(newStatusLevel.getID());
/* 121 */         StatusLevelManagerFactory.statusLevelCache.put("_groupLevels", groupLevels);
/*     */       }
/*     */     }
/* 124 */     return newStatusLevel;
/*     */   }
/*     */ 
/*     */   public void deleteStatusLevel(StatusLevel statusLevel) throws UnauthorizedException {
/* 128 */     if (statusLevel == null) {
/* 129 */       throw new IllegalArgumentException("statusLevel cannot be null");
/*     */     }
/* 131 */     Connection con = null;
/* 132 */     PreparedStatement pstmt = null;
/* 133 */     boolean abortTransaction = false;
/*     */     try {
/* 135 */       con = ConnectionManager.getTransactionConnection();
/*     */ 
/* 138 */       pstmt = con.prepareStatement("DELETE FROM jiveStatusLevelProp where statusLevelID = ?");
/* 139 */       pstmt.setLong(1, statusLevel.getID());
/* 140 */       pstmt.executeUpdate();
/*     */ 
/* 143 */       pstmt = con.prepareStatement("DELETE FROM jiveStatusLevel where statusLevelID = ?");
/* 144 */       pstmt.setLong(1, statusLevel.getID());
/* 145 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 148 */       Log.error(sqle);
/* 149 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 152 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */ 
/* 159 */     if (statusLevel.getGroup() != null) {
/* 160 */       StatusLevelManagerFactory.statusLevelCache.remove("_groupLevels");
/*     */     }
/*     */     else {
/* 163 */       StatusLevelManagerFactory.statusLevelCache.remove("_pointLevels");
/*     */     }
/*     */ 
/* 168 */     StatusLevelManagerFactory.statusLevelIDCache.remove(statusLevel.getName());
/* 169 */     StatusLevelManagerFactory.statusLevelCache.remove(new Long(statusLevel.getID()));
/*     */   }
/*     */ 
/*     */   public Iterator getGroupStatusLevels()
/*     */   {
/* 174 */     LongList list = (LongList)StatusLevelManagerFactory.statusLevelCache.get("_groupLevels");
/* 175 */     if (list != null) {
/* 176 */       return new StatusLevelIterator(list.toArray());
/*     */     }
/*     */ 
/* 179 */     list = new LongList();
/* 180 */     Connection con = null;
/* 181 */     PreparedStatement pstmt = null;
/*     */     try {
/* 183 */       con = ConnectionManager.getConnection();
/* 184 */       pstmt = con.prepareStatement("SELECT statusLevelID FROM jiveStatusLevel WHERE groupID > 0");
/* 185 */       ResultSet rs = pstmt.executeQuery();
/* 186 */       while (rs.next()) {
/* 187 */         list.add(rs.getLong(1));
/*     */       }
/* 189 */       rs.close();
/*     */ 
/* 191 */       StatusLevelManagerFactory.statusLevelCache.put("_groupLevels", list);
/*     */     }
/*     */     catch (SQLException sqle) {
/* 194 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 197 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 200 */     return new StatusLevelIterator(list.toArray());
/*     */   }
/*     */ 
/*     */   public Iterator getPointStatusLevels() {
/* 204 */     LongList list = (LongList)StatusLevelManagerFactory.statusLevelCache.get("_pointLevels");
/* 205 */     if (list != null) {
/* 206 */       return new StatusLevelIterator(list.toArray());
/*     */     }
/*     */ 
/* 209 */     list = new LongList();
/* 210 */     Connection con = null;
/* 211 */     PreparedStatement pstmt = null;
/*     */     try {
/* 213 */       con = ConnectionManager.getConnection();
/* 214 */       pstmt = con.prepareStatement("SELECT statusLevelID FROM jiveStatusLevel WHERE groupID < 0 ORDER BY minPoints DESC");
/* 215 */       ResultSet rs = pstmt.executeQuery();
/* 216 */       while (rs.next()) {
/* 217 */         list.add(rs.getLong(1));
/*     */       }
/* 219 */       rs.close();
/*     */ 
/* 221 */       StatusLevelManagerFactory.statusLevelCache.put("_pointLevels", list);
/*     */     }
/*     */     catch (SQLException sqle) {
/* 224 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 227 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 230 */     return new StatusLevelIterator(list.toArray());
/*     */   }
/*     */ 
/*     */   public int getPointLevel(User user) {
/* 234 */     return StatusLevelManagerFactory.getCalculator().getPointLevel(user);
/*     */   }
/*     */ 
/*     */   public int getPointLevel(User user, Forum forum) {
/* 238 */     return StatusLevelManagerFactory.getCalculator().getPointLevel(user, forum);
/*     */   }
/*     */ 
/*     */   public int getPointLevel(User user, ForumCategory category) {
/* 242 */     return StatusLevelManagerFactory.getCalculator().getPointLevel(user, category);
/*     */   }
/*     */ 
/*     */   public Iterator getLeaders() {
/* 246 */     long[] ids = getLeaderBlock(17, -1L, 0);
/*     */ 
/* 248 */     return new StatusLevelLeaderBlockIterator(ids, 0, 10, 17, -1L, this);
/*     */   }
/*     */ 
/*     */   public Iterator getLeaders(int startIndex, int numResults) {
/* 252 */     long[] ids = getLeaderBlock(17, -1L, 0);
/*     */ 
/* 254 */     return new StatusLevelLeaderBlockIterator(ids, startIndex, numResults, 17, -1L, this);
/*     */   }
/*     */ 
/*     */   public Iterator getLeaders(Forum forum)
/*     */   {
/* 259 */     long[] ids = getLeaderBlock(0, forum.getID(), 0);
/*     */ 
/* 261 */     return new StatusLevelLeaderBlockIterator(ids, 0, 10, 0, forum.getID(), this);
/*     */   }
/*     */ 
/*     */   public Iterator getLeaders(Forum forum, int startIndex, int numResults)
/*     */   {
/* 266 */     long[] ids = getLeaderBlock(0, forum.getID(), 0);
/*     */ 
/* 268 */     return new StatusLevelLeaderBlockIterator(ids, startIndex, numResults, 0, forum.getID(), this);
/*     */   }
/*     */ 
/*     */   public Iterator getLeaders(ForumCategory category)
/*     */   {
/* 273 */     long[] ids = getLeaderBlock(14, category.getID(), 0);
/*     */ 
/* 275 */     return new StatusLevelLeaderBlockIterator(ids, 0, 10, 14, category.getID(), this);
/*     */   }
/*     */ 
/*     */   public Iterator getLeaders(ForumCategory category, int startIndex, int numResults)
/*     */   {
/* 280 */     long[] ids = getLeaderBlock(14, category.getID(), 0);
/*     */ 
/* 282 */     return new StatusLevelLeaderBlockIterator(ids, startIndex, numResults, 14, category.getID(), this);
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevel(long statusLevelID) throws StatusLevelNotFoundException
/*     */   {
/* 287 */     StatusLevel statusLevel = (StatusLevel)StatusLevelManagerFactory.statusLevelCache.get(new Long(statusLevelID));
/*     */ 
/* 289 */     if (statusLevel == null) {
/* 290 */       statusLevel = new DbStatusLevel(statusLevelID);
/*     */     }
/* 292 */     return statusLevel;
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevel(String name) throws StatusLevelNotFoundException {
/* 296 */     Long id = (Long)StatusLevelManagerFactory.statusLevelIDCache.get(name);
/*     */ 
/* 298 */     StatusLevel statusLevel = null;
/* 299 */     if (id != null) {
/* 300 */       statusLevel = (StatusLevel)StatusLevelManagerFactory.statusLevelCache.get(id);
/*     */     }
/*     */ 
/* 304 */     if (statusLevel == null)
/*     */     {
/* 306 */       statusLevel = new DbStatusLevel(name);
/*     */     }
/* 308 */     return statusLevel;
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevel(User user) {
/* 312 */     StatusLevel level = getGroupStatusLevel(user);
/* 313 */     if (level != null) {
/* 314 */       return level;
/*     */     }
/* 316 */     int count = getPointLevel(user);
/* 317 */     return getStatusLevelByPoints(count);
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevel(User user, Forum forum) {
/* 321 */     StatusLevel level = getGroupStatusLevel(user);
/* 322 */     if (level != null) {
/* 323 */       return level;
/*     */     }
/* 325 */     int points = getPointLevel(user);
/* 326 */     return getStatusLevelByPoints(points);
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevel(User user, ForumCategory category) {
/* 330 */     StatusLevel level = getGroupStatusLevel(user);
/* 331 */     if (level != null) {
/* 332 */       return level;
/*     */     }
/* 334 */     int points = getPointLevel(user, category);
/* 335 */     return getStatusLevelByPoints(points);
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevelByPoints(int pointLevel)
/*     */   {
/* 340 */     int maximum = -1;
/* 341 */     StatusLevel maximumLevel = null;
/*     */ 
/* 343 */     for (Iterator i = getPointStatusLevels(); i.hasNext(); ) {
/* 344 */       StatusLevel statusLevel = (DbStatusLevel)i.next();
/*     */ 
/* 348 */       if (statusLevel.getMaxPoints() > maximum) {
/* 349 */         maximum = statusLevel.getMaxPoints();
/* 350 */         maximumLevel = statusLevel;
/*     */       }
/*     */ 
/* 353 */       if (statusLevel.isInRange(pointLevel)) {
/* 354 */         return statusLevel;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 360 */     if (pointLevel >= maximum) {
/* 361 */       return maximumLevel;
/*     */     }
/*     */ 
/* 364 */     return null;
/*     */   }
/*     */ 
/*     */   public void setStatusLevelsEnabled(boolean statusLevelEnabled) throws UnauthorizedException {
/* 368 */     StatusLevelManagerFactory.setStatusLevelsEnabled(statusLevelEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isStatusLevelsEnabled() {
/* 372 */     return StatusLevelManagerFactory.isStatusLevelsEnabled();
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevel(Group group) {
/* 376 */     for (Iterator i = getGroupStatusLevels(); i.hasNext(); ) {
/* 377 */       StatusLevel current = (StatusLevel)i.next();
/* 378 */       if (current.getGroup().equals(group)) {
/* 379 */         return current;
/*     */       }
/*     */     }
/* 382 */     return null;
/*     */   }
/*     */ 
/*     */   public long[] getLeaderBlock(int objectType, long objectID, int startIndex) {
/* 386 */     return (long[])leaderQueryCache.get(new LeaderQueryCacheKey(objectType, objectID, startIndex, 100));
/*     */   }
/*     */ 
/*     */   public void groupCreated(GroupEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void groupDeleted(GroupEvent event)
/*     */   {
/* 395 */     if (com.jivesoftware.util.CacheFactory.isSeniorClusterMember()) {
/* 396 */       Connection con = null;
/* 397 */       PreparedStatement pstmt = null;
/*     */       try {
/* 399 */         con = ConnectionManager.getConnection();
/* 400 */         pstmt = con.prepareStatement("DELETE FROM jiveStatusLevel WHERE groupID = ?");
/* 401 */         pstmt.setLong(1, event.getGroup().getID());
/* 402 */         pstmt.executeUpdate();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 405 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 408 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */ 
/* 412 */       LongList list = (LongList)StatusLevelManagerFactory.statusLevelCache.remove("_groupLevels");
/*     */ 
/* 414 */       if (list != null)
/*     */       {
/* 416 */         int i = 0; for (int size = list.size(); i < size; i++) {
/* 417 */           Long id = new Long(list.get(i));
/* 418 */           StatusLevel level = (StatusLevel)StatusLevelManagerFactory.statusLevelCache.remove(id);
/*     */ 
/* 421 */           if (level != null)
/* 422 */             StatusLevelManagerFactory.statusLevelIDCache.remove(level.getName());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void groupUserAdded(GroupEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void groupUserDeleted(GroupEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void groupAdministratorAdded(GroupEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void groupAdministratorDeleted(GroupEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void groupModified(GroupEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void jivePropertyAdded(JivePropertyEvent jivePropertyEvent)
/*     */   {
/* 450 */     if ("StatusLevelCalculator.className".equals(jivePropertyEvent.getName()))
/*     */     {
/* 452 */       leaderQueryCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void jivePropertyRemoved(JivePropertyEvent jivePropertyEvent) {
/* 457 */     if ("StatusLevelCalculator.className".equals(jivePropertyEvent.getName()))
/*     */     {
/* 459 */       leaderQueryCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void jivePropertyModified(JivePropertyEvent jivePropertyEvent) {
/* 464 */     if ("StatusLevelCalculator.className".equals(jivePropertyEvent.getName()))
/*     */     {
/* 466 */       leaderQueryCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private StatusLevel getGroupStatusLevel(User user) {
/* 471 */     for (Iterator i = getGroupStatusLevels(); i.hasNext(); ) {
/* 472 */       StatusLevel statusLevel = (StatusLevel)i.next();
/* 473 */       Group group = statusLevel.getGroup();
/* 474 */       if (group == null) {
/* 475 */         return null;
/*     */       }
/* 477 */       if (group.isMember(user)) {
/* 478 */         return statusLevel;
/*     */       }
/*     */     }
/* 481 */     return null;
/*     */   }
/*     */ 
/*     */   public static class LeaderQueryCacheUpdateTask
/*     */     implements Runnable
/*     */   {
/*     */     private DbStatusLevelManager.LeaderQueryCache.Entry entry;
/*     */ 
/*     */     public LeaderQueryCacheUpdateTask(DbStatusLevelManager.LeaderQueryCache.Entry entry)
/*     */     {
/* 803 */       this.entry = entry;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 808 */       DbStatusLevelManager.LeaderQueryCacheKey key = (DbStatusLevelManager.LeaderQueryCacheKey)this.entry.getKey();
/*     */ 
/* 810 */       Log.debug("updating cache for key " + key);
/*     */ 
/* 813 */       long[] userIDs = null;
/*     */       try {
/* 815 */         StatusLevelCalculator calculator = StatusLevelManagerFactory.getCalculator();
/*     */ 
/* 817 */         switch (key.getObjectType())
/*     */         {
/*     */         case 17:
/* 820 */           userIDs = calculator.getLeaderIds(key.getStartIndex(), key.getNumResults());
/*     */ 
/* 822 */           break;
/*     */         case 0:
/* 828 */           userIDs = calculator.getLeaderIds(DbStatusLevelManager.FACTORY.getForum(key.getObjectID()), key.getStartIndex(), key.getNumResults());
/*     */ 
/* 830 */           break;
/*     */         case 14:
/* 835 */           userIDs = calculator.getLeaderIds(DbStatusLevelManager.FACTORY.getForumCategory(key.getObjectID()), key.getStartIndex(), key.getNumResults());
/*     */ 
/* 838 */           break;
/*     */         default:
/* 843 */           throw new IllegalArgumentException("unrecognized object type " + key.getObjectType());
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e)
/*     */       {
/* 849 */         Log.error(e);
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 852 */         Log.error(e);
/*     */       }
/*     */ 
/* 855 */       if (userIDs == null) {
/* 856 */         userIDs = new long[0];
/*     */       }
/* 858 */       DbStatusLevelManager.leaderQueryCache.put(key, new DbStatusLevelManager.LeaderQueryCache.ValueWrapper(userIDs));
/* 859 */       this.entry.updateFlag = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class LeaderQueryCacheKey
/*     */     implements Cacheable, ExternalizableLite
/*     */   {
/*     */     private int objectType;
/*     */     private long objectID;
/*     */     private int startIndex;
/*     */     private int numResults;
/*     */ 
/*     */     public LeaderQueryCacheKey()
/*     */     {
/*     */     }
/*     */ 
/*     */     public LeaderQueryCacheKey(int objectType, long objectId, int startIndex, int numResults)
/*     */     {
/* 693 */       this.objectType = objectType;
/* 694 */       this.objectID = objectId;
/* 695 */       this.startIndex = startIndex;
/* 696 */       this.numResults = numResults;
/*     */     }
/*     */ 
/*     */     public int getObjectType() {
/* 700 */       return this.objectType;
/*     */     }
/*     */ 
/*     */     public long getObjectID() {
/* 704 */       return this.objectID;
/*     */     }
/*     */ 
/*     */     public int getStartIndex() {
/* 708 */       return this.startIndex;
/*     */     }
/*     */ 
/*     */     public int getNumResults() {
/* 712 */       return this.numResults;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o) {
/* 716 */       if (this == o) {
/* 717 */         return true;
/*     */       }
/* 719 */       if (!(o instanceof LeaderQueryCacheKey)) {
/* 720 */         return false;
/*     */       }
/*     */ 
/* 723 */       LeaderQueryCacheKey leaderQueryCacheKey = (LeaderQueryCacheKey)o;
/*     */ 
/* 725 */       if (this.numResults != leaderQueryCacheKey.numResults) {
/* 726 */         return false;
/*     */       }
/* 728 */       if (this.objectID != leaderQueryCacheKey.objectID) {
/* 729 */         return false;
/*     */       }
/* 731 */       if (this.objectType != leaderQueryCacheKey.objectType) {
/* 732 */         return false;
/*     */       }
/* 734 */       if (this.startIndex != leaderQueryCacheKey.startIndex) {
/* 735 */         return false;
/*     */       }
/*     */ 
/* 738 */       return true;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 743 */       int result = this.objectType;
/* 744 */       result = 1429 * result + (int)(this.objectID ^ this.objectID >>> 32);
/* 745 */       result = 1429 * result + this.startIndex;
/* 746 */       result = 1429 * result + this.numResults;
/* 747 */       return result;
/*     */     }
/*     */ 
/*     */     public void writeExternal(DataOutput out) throws IOException {
/* 751 */       ExternalizableHelper.writeInt(out, this.objectType);
/* 752 */       ExternalizableHelper.writeLong(out, this.objectID);
/* 753 */       ExternalizableHelper.writeInt(out, this.startIndex);
/* 754 */       ExternalizableHelper.writeInt(out, this.numResults);
/*     */     }
/*     */ 
/*     */     public void readExternal(DataInput in) throws IOException {
/* 758 */       this.objectType = ExternalizableHelper.readInt(in);
/* 759 */       this.objectID = ExternalizableHelper.readLong(in);
/* 760 */       this.startIndex = ExternalizableHelper.readInt(in);
/* 761 */       this.numResults = ExternalizableHelper.readInt(in);
/*     */     }
/*     */ 
/*     */     public int getCachedSize() {
/* 765 */       int size = 0;
/* 766 */       size += CacheSizes.sizeOfObject();
/* 767 */       size += CacheSizes.sizeOfInt();
/* 768 */       size += CacheSizes.sizeOfLong();
/* 769 */       size += CacheSizes.sizeOfInt();
/* 770 */       size += CacheSizes.sizeOfInt();
/* 771 */       return size;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 775 */       return "LeaderQueryCacheKey[ objectType=" + this.objectType + ", objectID=" + this.objectID + ", startIndex=" + this.startIndex + ", numResults=" + this.numResults + " ]";
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static class LeaderQueryCache extends CoherenceCache
/*     */   {
/*     */     public LeaderQueryCache(String name, int maxSize, long maxLifetime)
/*     */     {
/* 496 */       super(maxSize, maxLifetime);
/*     */     }
/*     */ 
/*     */     public SafeHashMap.Entry getEntry(Object key) {
/* 500 */       Entry entry = (Entry)super.getEntry(key);
/*     */ 
/* 502 */       if (entry == null) {
/* 503 */         return null;
/*     */       }
/*     */ 
/* 521 */       if (!(entry.getValue() instanceof Binary)) {
/* 522 */         ValueWrapper value = (ValueWrapper)entry.getValue();
/*     */ 
/* 526 */         if (value.getClusterMemberID() == getMemberID())
/*     */         {
/* 529 */           synchronized (DbStatusLevelManager.updateLock)
/*     */           {
/* 532 */             if (!entry.updateFlag)
/*     */             {
/* 534 */               long now = System.currentTimeMillis();
/*     */ 
/* 537 */               if (now - entry.timestamp > 300000L) {
/* 538 */                 entry.updateFlag = true;
/*     */ 
/* 540 */                 Runnable r = new DbStatusLevelManager.LeaderQueryCacheUpdateTask(entry);
/* 541 */                 TaskEngine.addTask(r);
/*     */               }
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 551 */       return entry;
/*     */     }
/*     */ 
/*     */     public Object get(Object key) {
/* 555 */       Object value = super.get(key);
/* 556 */       if (value == null)
/*     */       {
/* 558 */         synchronized (this)
/*     */         {
/* 560 */           value = super.get(key);
/*     */ 
/* 562 */           if (value == null)
/*     */           {
/* 564 */             long[] empty = new long[0];
/*     */ 
/* 566 */             super.put(key, new ValueWrapper(empty));
/* 567 */             value = empty;
/*     */ 
/* 572 */             Entry entry = (Entry)super.getEntry(key);
/*     */ 
/* 575 */             Runnable r = new DbStatusLevelManager.LeaderQueryCacheUpdateTask(entry);
/* 576 */             TaskEngine.addTask(r);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 582 */       if ((value instanceof ValueWrapper)) {
/* 583 */         ValueWrapper vw = (ValueWrapper)value;
/* 584 */         return vw.getValue();
/*     */       }
/* 586 */       return value;
/*     */     }
/*     */ 
/*     */     protected static int getMemberID()
/*     */     {
/* 595 */       if (!com.jivesoftware.util.CacheFactory.isClusteringEnabled()) {
/* 596 */         return 1;
/*     */       }
/*     */ 
/* 599 */       return com.tangosol.net.CacheFactory.ensureCluster().getLocalMember().getId();
/*     */     }
/*     */ 
/*     */     protected SafeHashMap.Entry instantiateEntry()
/*     */     {
/* 604 */       return new Entry();
/*     */     }
/*     */ 
/*     */     public static class ValueWrapper
/*     */       implements ExternalizableLite
/*     */     {
/*     */       private int clusterMemberID;
/*     */       private Object value;
/*     */ 
/*     */       public ValueWrapper(Object value)
/*     */       {
/* 637 */         this.clusterMemberID = DbStatusLevelManager.LeaderQueryCache.getMemberID();
/* 638 */         this.value = value;
/*     */       }
/*     */ 
/*     */       public ValueWrapper()
/*     */       {
/*     */       }
/*     */ 
/*     */       public int getClusterMemberID()
/*     */       {
/* 654 */         return this.clusterMemberID;
/*     */       }
/*     */ 
/*     */       public Object getValue()
/*     */       {
/* 663 */         return this.value;
/*     */       }
/*     */ 
/*     */       public void readExternal(DataInput in) throws IOException {
/* 667 */         this.clusterMemberID = in.readInt();
/* 668 */         this.value = ExternalizableHelper.readObject(in);
/*     */       }
/*     */ 
/*     */       public void writeExternal(DataOutput out) throws IOException {
/* 672 */         out.writeInt(this.clusterMemberID);
/* 673 */         ExternalizableHelper.writeObject(out, this.value);
/*     */       }
/*     */     }
/*     */ 
/*     */     public class Entry extends CoherenceCache.Entry
/*     */     {
/* 612 */       public boolean updateFlag = true;
/*     */ 
/* 614 */       public long timestamp = System.currentTimeMillis();
/*     */ 
/*     */       public Entry()
/*     */       {
/* 607 */         super();
/*     */       }
/*     */ 
/*     */       public boolean isExpired()
/*     */       {
/* 618 */         return (!this.updateFlag) && (super.isExpired());
/*     */       }
/*     */ 
/*     */       public Object setValue(Object o) {
/* 622 */         this.timestamp = System.currentTimeMillis();
/* 623 */         return super.setValue(o);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbStatusLevelManager
 * JD-Core Version:    0.6.2
 */
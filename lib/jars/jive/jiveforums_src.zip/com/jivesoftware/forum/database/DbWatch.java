/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserManagerFactory;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.forum.Watch;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheSizes;
/*     */ import com.jivesoftware.util.Cacheable;
/*     */ import com.tangosol.io.ExternalizableLite;
/*     */ import com.tangosol.util.ExternalizableHelper;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ public class DbWatch
/*     */   implements Watch, Cacheable, ExternalizableLite
/*     */ {
/*     */   private static final String CREATE_WATCH = "INSERT INTO jiveWatch (userID, objectType, objectID, watchType, expirable) VALUES (?, ?, ?, ?, 1)";
/*     */   private static final String DELETE_WATCH = "DELETE FROM jiveWatch WHERE userID=? AND objectType=? AND objectID=? AND watchType=?";
/*     */   private static final String UPDATE_WATCH_TYPE = "UPDATE jiveWatch SET watchType=? WHERE userID=? AND objectType=? AND objectID=?";
/*     */   private static final String UPDATE_WATCH_EXPIRATION = "UPDATE jiveWatch SET expirable=? WHERE userID=? AND objectType=? AND objectID=?";
/*     */   private long userID;
/*     */   private int objectType;
/*     */   private long objectID;
/*     */   private int watchType;
/*     */   private boolean expirable;
/*     */ 
/*     */   public DbWatch(long userID, int objectType, long objectID, int watchType, boolean expirable)
/*     */   {
/*  54 */     this.userID = userID;
/*  55 */     this.objectType = objectType;
/*  56 */     this.objectID = objectID;
/*  57 */     this.watchType = watchType;
/*  58 */     this.expirable = expirable;
/*     */   }
/*     */ 
/*     */   public DbWatch()
/*     */   {
/*     */   }
/*     */ 
/*     */   public User getUser()
/*     */   {
/*  71 */     User user = null;
/*     */     try {
/*  73 */       user = UserManagerFactory.getInstance().getUser(this.userID);
/*     */     }
/*     */     catch (UserNotFoundException unfe) {
/*  76 */       Log.error(unfe);
/*     */     }
/*  78 */     return user;
/*     */   }
/*     */ 
/*     */   public long getObjectID() {
/*  82 */     return this.objectID;
/*     */   }
/*     */ 
/*     */   public int getObjectType() {
/*  86 */     return this.objectType;
/*     */   }
/*     */ 
/*     */   public int getWatchType() {
/*  90 */     return this.watchType;
/*     */   }
/*     */ 
/*     */   public void setWatchType(int watchType)
/*     */   {
/*  95 */     if (this.watchType == watchType) {
/*  96 */       return;
/*     */     }
/*  98 */     int oldWatchType = this.watchType;
/*  99 */     this.watchType = watchType;
/*     */ 
/* 101 */     Connection con = null;
/* 102 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 105 */       con = ConnectionManager.getConnection();
/* 106 */       pstmt = con.prepareStatement("UPDATE jiveWatch SET watchType=? WHERE userID=? AND objectType=? AND objectID=?");
/* 107 */       pstmt.setInt(1, watchType);
/* 108 */       pstmt.setLong(2, this.userID);
/* 109 */       pstmt.setInt(3, this.objectType);
/* 110 */       pstmt.setLong(4, this.objectID);
/* 111 */       pstmt.executeUpdate();
/*     */     } catch (SQLException e) {
/* 113 */       Log.error(e);
/*     */     } finally {
/* 115 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 119 */     DbForumFactory factory = DbForumFactory.getInstance();
/* 120 */     String key = DbWatchManager.getCacheKey(this.userID, this.objectType);
/* 121 */     factory.cacheManager.watchCache.remove(key);
/*     */ 
/* 123 */     key = DbWatchManager.getCacheKey(this.objectType, this.objectID, oldWatchType);
/* 124 */     factory.cacheManager.watchCache.remove(key);
/* 125 */     key = DbWatchManager.getCacheKey(this.objectType, this.objectID, watchType);
/* 126 */     factory.cacheManager.watchCache.remove(key);
/*     */   }
/*     */ 
/*     */   public boolean isExpirable() {
/* 130 */     return this.expirable;
/*     */   }
/*     */ 
/*     */   public void setExpirable(boolean expirable)
/*     */   {
/* 135 */     if (this.expirable == expirable) {
/* 136 */       return;
/*     */     }
/* 138 */     this.expirable = expirable;
/*     */ 
/* 140 */     Connection con = null;
/* 141 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 144 */       con = ConnectionManager.getConnection();
/* 145 */       pstmt = con.prepareStatement("UPDATE jiveWatch SET expirable=? WHERE userID=? AND objectType=? AND objectID=?");
/* 146 */       pstmt.setInt(1, expirable ? 1 : 0);
/* 147 */       pstmt.setLong(2, this.userID);
/* 148 */       pstmt.setInt(3, this.objectType);
/* 149 */       pstmt.setLong(4, this.objectID);
/* 150 */       pstmt.executeUpdate();
/*     */     } catch (SQLException e) {
/* 152 */       Log.error(e);
/*     */     } finally {
/* 154 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 158 */     String key = DbWatchManager.getCacheKey(this.userID, this.objectType);
/* 159 */     DbForumFactory.getInstance().cacheManager.watchCache.remove(key);
/*     */   }
/*     */ 
/*     */   public int getCachedSize()
/*     */   {
/* 165 */     int size = 0;
/* 166 */     size += CacheSizes.sizeOfObject();
/* 167 */     size += CacheSizes.sizeOfLong();
/* 168 */     size += CacheSizes.sizeOfLong();
/* 169 */     size += CacheSizes.sizeOfInt();
/* 170 */     size += CacheSizes.sizeOfInt();
/* 171 */     size += CacheSizes.sizeOfBoolean();
/* 172 */     return size;
/*     */   }
/*     */ 
/*     */   public void readExternal(DataInput in)
/*     */     throws IOException
/*     */   {
/* 178 */     this.userID = ExternalizableHelper.readLong(in);
/* 179 */     this.objectType = ExternalizableHelper.readInt(in);
/* 180 */     this.objectID = ExternalizableHelper.readLong(in);
/* 181 */     this.watchType = ExternalizableHelper.readInt(in);
/* 182 */     this.expirable = in.readBoolean();
/*     */   }
/*     */ 
/*     */   public void writeExternal(DataOutput out) throws IOException {
/* 186 */     ExternalizableHelper.writeLong(out, this.userID);
/* 187 */     ExternalizableHelper.writeInt(out, this.objectType);
/* 188 */     ExternalizableHelper.writeLong(out, this.objectID);
/* 189 */     ExternalizableHelper.writeInt(out, this.watchType);
/* 190 */     out.writeBoolean(this.expirable);
/*     */   }
/*     */ 
/*     */   protected void insertIntoDb()
/*     */   {
/* 196 */     Connection con = null;
/* 197 */     PreparedStatement pstmt = null;
/*     */     try {
/* 199 */       con = ConnectionManager.getConnection();
/* 200 */       pstmt = con.prepareStatement("INSERT INTO jiveWatch (userID, objectType, objectID, watchType, expirable) VALUES (?, ?, ?, ?, 1)");
/* 201 */       pstmt.setLong(1, this.userID);
/* 202 */       pstmt.setInt(2, this.objectType);
/* 203 */       pstmt.setLong(3, this.objectID);
/* 204 */       pstmt.setInt(4, this.watchType);
/* 205 */       pstmt.execute();
/*     */     } catch (SQLException e) {
/* 207 */       Log.error(e);
/*     */     } finally {
/* 209 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 212 */     String key = DbWatchManager.getCacheKey(this.userID, this.objectType);
/* 213 */     DbForumFactory.getInstance().cacheManager.watchCache.remove(key);
/*     */   }
/*     */ 
/*     */   protected void deleteFromDb() {
/* 217 */     Connection con = null;
/*     */     try
/*     */     {
/* 220 */       con = ConnectionManager.getConnection();
/* 221 */       deleteFromDb(con);
/*     */     } catch (SQLException e) {
/* 223 */       Log.error(e);
/*     */     } finally {
/* 225 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteFromDb(Connection con) throws SQLException {
/* 230 */     PreparedStatement pstmt = null;
/*     */     try {
/* 232 */       pstmt = con.prepareStatement("DELETE FROM jiveWatch WHERE userID=? AND objectType=? AND objectID=? AND watchType=?");
/* 233 */       pstmt.setLong(1, this.userID);
/* 234 */       pstmt.setInt(2, this.objectType);
/* 235 */       pstmt.setLong(3, this.objectID);
/* 236 */       pstmt.setInt(4, this.watchType);
/* 237 */       pstmt.execute();
/*     */     }
/*     */     finally {
/* 240 */       ConnectionManager.closePreparedStatement(pstmt);
/*     */     }
/*     */ 
/* 243 */     DbForumFactory factory = DbForumFactory.getInstance();
/* 244 */     String key = DbWatchManager.getCacheKey(this.userID, this.objectType);
/* 245 */     factory.cacheManager.watchCache.remove(key);
/*     */ 
/* 247 */     key = DbWatchManager.getCacheKey(this.objectType, this.objectID, this.watchType);
/* 248 */     factory.cacheManager.watchCache.remove(key);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbWatch
 * JD-Core Version:    0.6.2
 */
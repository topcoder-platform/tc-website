/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.database.CachedPreparedStatement;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadIterator;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class ForumThreadBlockIterator extends ForumThreadIterator
/*     */ {
/*     */   private long[] block;
/*     */   private int blockID;
/*     */   private int blockStart;
/*     */   private CachedPreparedStatement query;
/*     */   private int startIndex;
/*     */   private int currentIndex;
/*     */   private int endIndex;
/*     */   private int objectType;
/*     */   private long objectID;
/*     */   private DbForumFactory factory;
/*  41 */   private Object previousElement = null;
/*  42 */   private Object nextElement = null;
/*     */ 
/*  44 */   private int previousElementIndex = -1;
/*  45 */   private int nextElementIndex = -1;
/*     */ 
/*     */   protected ForumThreadBlockIterator(long[] block, CachedPreparedStatement query, int startIndex, int endIndex, int objectType, long objectID, DbForumFactory factory)
/*     */   {
/*  62 */     this.block = block;
/*  63 */     this.blockID = (startIndex / 400);
/*  64 */     this.blockStart = (this.blockID * 400);
/*  65 */     this.query = query;
/*  66 */     this.currentIndex = (startIndex - 1);
/*  67 */     this.startIndex = startIndex;
/*  68 */     this.endIndex = endIndex;
/*  69 */     this.objectType = objectType;
/*  70 */     this.objectID = objectID;
/*  71 */     this.factory = factory;
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/*  76 */     if (this.currentIndex == this.endIndex) {
/*  77 */       return false;
/*     */     }
/*     */ 
/*  82 */     if (this.nextElement == null) {
/*  83 */       Object element = null;
/*  84 */       int index = this.currentIndex;
/*  85 */       while ((index + 1 < this.endIndex) && (element == null)) {
/*  86 */         index++;
/*  87 */         element = getElement(index);
/*     */       }
/*     */ 
/*  90 */       if (element == null) {
/*  91 */         return false;
/*     */       }
/*     */ 
/*  94 */       this.nextElement = element;
/*  95 */       this.nextElementIndex = index;
/*     */     }
/*     */ 
/*  98 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean hasPrevious()
/*     */   {
/* 103 */     if (this.currentIndex == this.startIndex) {
/* 104 */       return false;
/*     */     }
/*     */ 
/* 108 */     if (this.previousElement == null) {
/* 109 */       Object element = null;
/* 110 */       int index = this.currentIndex;
/* 111 */       while ((index >= this.startIndex) && (element == null)) {
/* 112 */         index--;
/* 113 */         element = getElement(index);
/*     */       }
/*     */ 
/* 117 */       if (element == null) {
/* 118 */         return false;
/*     */       }
/*     */ 
/* 121 */       this.previousElement = element;
/* 122 */       this.previousElementIndex = index;
/*     */     }
/*     */ 
/* 125 */     return true;
/*     */   }
/*     */ 
/*     */   public Object next() throws NoSuchElementException {
/* 129 */     Object element = null;
/* 130 */     if ((this.nextElement != null) && (this.nextElementIndex != -1)) {
/* 131 */       element = this.nextElement;
/* 132 */       this.currentIndex = this.nextElementIndex;
/* 133 */       this.nextElement = null;
/* 134 */       this.nextElementIndex = -1;
/*     */     }
/*     */     else {
/* 137 */       element = getNextElement();
/* 138 */       if (element == null) {
/* 139 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/* 142 */     return element;
/*     */   }
/*     */ 
/*     */   public Object previous() {
/* 146 */     Object element = null;
/* 147 */     if ((this.previousElement != null) && (this.previousElementIndex != -1)) {
/* 148 */       element = this.previousElement;
/* 149 */       this.currentIndex = this.previousElementIndex;
/* 150 */       this.previousElement = null;
/* 151 */       this.previousElementIndex = -1;
/*     */     }
/*     */     else {
/* 154 */       element = getPreviousElement();
/* 155 */       if (element == null) {
/* 156 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/* 159 */     return element;
/*     */   }
/*     */   public void setIndex(ForumThread thread) {
/* 165 */     this.nextElement = null;
/* 166 */     this.previousElement = null;
/* 167 */     this.nextElementIndex = -1;
/* 168 */     this.previousElementIndex = -1;
/*     */     long threadID;
/*     */     int i;
/*     */     try { threadID = thread.getID();
/*     */ 
/* 175 */       for (i = this.startIndex; i < this.endIndex; ) {
/* 176 */         long[] currentBlock = getBlock(i);
/* 177 */         if (currentBlock.length == 0) {
/* 178 */           throw new NoSuchElementException("Thread with id " + threadID + " is not a valid index in the iteration.");
/*     */         }
/*     */ 
/* 181 */         int blockID = i / 400;
/* 182 */         int blockStart = blockID * 400;
/*     */ 
/* 184 */         if (blockStart < this.startIndex)
/*     */         {
/* 187 */           for (int j = this.startIndex % 400; j < currentBlock.length; i++)
/*     */           {
/* 189 */             if (currentBlock[j] == threadID) {
/* 190 */               this.currentIndex = i;
/*     */               return;
/*     */             }
/* 187 */             j++;
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 197 */           for (int j = 0; j < currentBlock.length; i++) {
/* 198 */             if (currentBlock[j] == threadID) {
/* 199 */               this.currentIndex = i;
/*     */               return;
/*     */             }
/* 197 */             j++;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */ 
/* 209 */     throw new NoSuchElementException("Thread with id " + thread.getID() + " is not a valid index in the iteration.");
/*     */   }
/*     */ 
/*     */   private long[] getBlock(int startIndex)
/*     */     throws Exception
/*     */   {
/* 215 */     return QueryCache.getBlock(this.query, this.objectType, this.objectID, startIndex, true);
/*     */   }
/*     */ 
/*     */   private Object getNextElement()
/*     */   {
/* 225 */     this.previousElement = null;
/* 226 */     this.previousElementIndex = -1;
/*     */ 
/* 228 */     Object element = null;
/* 229 */     while ((this.currentIndex + 1 < this.endIndex) && (element == null)) {
/* 230 */       this.currentIndex += 1;
/* 231 */       element = getElement(this.currentIndex);
/*     */     }
/*     */ 
/* 234 */     return element;
/*     */   }
/*     */ 
/*     */   private Object getPreviousElement()
/*     */   {
/* 244 */     this.nextElement = null;
/* 245 */     this.nextElementIndex = -1;
/*     */ 
/* 247 */     Object element = null;
/* 248 */     while ((this.currentIndex >= this.startIndex) && (element == null)) {
/* 249 */       this.currentIndex -= 1;
/* 250 */       element = getElement(this.currentIndex);
/*     */     }
/* 252 */     return element;
/*     */   }
/*     */ 
/*     */   private Object getElement(int index) {
/* 256 */     if (index < 0) {
/* 257 */       return null;
/*     */     }
/*     */ 
/* 260 */     if ((index < this.blockStart) || (index >= this.blockStart + 400)) {
/*     */       try
/*     */       {
/* 263 */         this.block = QueryCache.getBlock(this.query, this.objectType, this.objectID, index, true);
/* 264 */         this.blockID = (index / 400);
/* 265 */         this.blockStart = (this.blockID * 400);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 269 */         return null;
/*     */       }
/*     */     }
/* 272 */     Object element = null;
/*     */ 
/* 275 */     int relativeIndex = index % 400;
/*     */ 
/* 277 */     if (relativeIndex < this.block.length)
/*     */       try
/*     */       {
/* 280 */         element = this.factory.getForumThread(this.block[relativeIndex]);
/*     */       }
/*     */       catch (ForumThreadNotFoundException tnfe) {
/*     */       }
/* 284 */     return element;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.ForumThreadBlockIterator
 * JD-Core Version:    0.6.2
 */
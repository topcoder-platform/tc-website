/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.util.TextExtractor;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.util.ClassUtils;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.lucene.document.Document;
/*     */ import org.apache.lucene.document.Field;
/*     */ 
/*     */ public class DbAttachmentSearchIndexer
/*     */ {
/*  33 */   private static List textExtractors = new ArrayList();
/*  34 */   private static List DEFAULT_TEXTEXTRACTOR_CLASSES = new ArrayList();
/*     */ 
/*  36 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */ 
/*     */   public static void indexAttachments(long messageID, Document doc)
/*     */   {
/*     */     try
/*     */     {
/*  49 */       ForumMessage message = FACTORY.cacheManager.getMessage(messageID);
/*  50 */       StringBuffer buffer = new StringBuffer();
/*  51 */       for (Iterator i = message.getAttachments(); i.hasNext(); ) {
/*  52 */         Attachment attachment = (Attachment)i.next();
/*  53 */         String contents = getAttachmentContent(attachment);
/*  54 */         if (contents != null) {
/*  55 */           buffer.append(contents).append(" ");
/*     */         }
/*     */       }
/*  58 */       if (!buffer.toString().trim().equals(""))
/*  59 */         doc.add(Field.UnStored("attachmentsText", buffer.toString()));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  63 */       Log.error(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static String getAttachmentContent(Attachment attachment)
/*     */   {
/*  76 */     long attachmentID = attachment.getID();
/*  77 */     String name = attachment.getName();
/*  78 */     if (Log.isDebugEnabled()) {
/*  79 */       Log.debug("Looking at attachment " + attachmentID);
/*     */     }
/*     */ 
/*  83 */     File attachmentTextFile = new File(DbAttachmentManager.getAttachmentDir(), File.separator + attachmentID + ".txt");
/*     */ 
/*  87 */     if ((attachmentTextFile.exists()) && (attachmentTextFile.canRead())) {
/*  88 */       Log.debug("Retrieving cached attachment text from file " + attachmentTextFile.toString());
/*     */ 
/*  90 */       StringWriter out = new StringWriter(256);
/*  91 */       FileReader fr = null;
/*  92 */       BufferedReader br = null;
/*     */       try
/*     */       {
/*  95 */         fr = new FileReader(attachmentTextFile);
/*  96 */         br = new BufferedReader(fr);
/*     */ 
/*  98 */         char[] buf = new char[256];
/*     */         int len;
/* 101 */         while ((len = br.read(buf)) >= 0) {
/* 102 */           out.write(buf, 0, len);
/*     */         }
/* 104 */         return out.toString();
/*     */       } catch (IOException e) {
/* 106 */         Log.error(e); } finally {
/*     */         try {
/* 108 */           if (out != null) out.close();  } catch (IOException e) {
/*     */         }
/*     */         try { if (br != null) br.close();  } catch (IOException e) {
/* 111 */           Log.error(e);
/*     */         }try { if (fr != null) fr.close();  } catch (IOException e) {
/* 113 */           Log.error(e);
/*     */         }
/*     */       }
/*     */     }
/* 117 */     String lcName = name.toLowerCase();
/* 118 */     String extension = "";
/*     */ 
/* 120 */     if (lcName.lastIndexOf('.') != -1) {
/* 121 */       extension = lcName.substring(lcName.lastIndexOf('.'));
/*     */     }
/*     */ 
/* 124 */     for (int i = 0; i < textExtractors.size(); i++) {
/* 125 */       TextExtractor extractor = (TextExtractor)textExtractors.get(i);
/* 126 */       if (extractor.getSupportedFileTypes().contains(extension)) {
/* 127 */         if (Log.isDebugEnabled()) {
/* 128 */           Log.debug("Parsing attachment with extractor " + extractor.getName());
/*     */         }
/*     */ 
/* 131 */         InputStream ais = null;
/*     */         try {
/* 133 */           ais = attachment.getData();
/* 134 */           String text = extractor.getText(lcName, ais);
/*     */           try
/*     */           {
/* 138 */             attachmentTextFile.createNewFile();
/* 139 */             FileWriter w = new FileWriter(attachmentTextFile);
/* 140 */             w.write(text);
/* 141 */             w.close();
/*     */           }
/*     */           catch (IOException e) {
/* 144 */             Log.error(e);
/* 145 */             attachmentTextFile.delete();
/*     */           }
/*     */         }
/*     */         catch (Exception e) {
/* 149 */           Log.error("Unabled to retrieve text from attachment: (" + name + ") because the following error occurred: " + e.getMessage());
/*     */ 
/* 152 */           return "";
/*     */         } finally {
/*     */           try {
/* 155 */             ais.close();
/*     */           }
/*     */           catch (IOException e1) {
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 162 */     if ("text/plain".equals(attachment.getContentType())) {
/* 163 */       if (Log.isDebugEnabled()) {
/* 164 */         Log.debug("Plain text attachment, retrieving text");
/*     */       }
/*     */ 
/* 167 */       StringWriter out = new StringWriter(256);
/* 168 */       InputStream ais = null;
/* 169 */       InputStreamReader ir = null;
/* 170 */       BufferedReader br = null;
/*     */       try
/*     */       {
/* 173 */         ais = attachment.getData();
/* 174 */         ir = new InputStreamReader(ais);
/* 175 */         br = new BufferedReader(ir);
/*     */ 
/* 177 */         char[] buf = new char[256];
/*     */         int len;
/* 180 */         while ((len = br.read(buf)) >= 0) {
/* 181 */           out.write(buf, 0, len);
/*     */         }
/* 183 */         return out.toString();
/*     */       } catch (IOException e) {
/* 185 */         Log.error(e); } finally {
/*     */         try {
/* 187 */           if (out != null) out.close();  } catch (IOException e) {
/*     */         }
/*     */         try { if (br != null) br.close();  } catch (IOException e) {
/* 190 */           Log.error(e);
/*     */         }try { if (ir != null) ir.close();  } catch (IOException e) {
/* 192 */           Log.error(e);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 197 */     if (Log.isDebugEnabled()) {
/* 198 */       Log.debug("Attachment " + name + " is not a type we know how to parse, returning");
/*     */     }
/* 200 */     return "";
/*     */   }
/*     */ 
/*     */   private static synchronized void loadTextExtractors()
/*     */   {
/* 208 */     List extractors = JiveGlobals.getJiveProperties("search.textExtractors");
/*     */ 
/* 210 */     if (extractors.size() == 0) {
/* 211 */       extractors = DEFAULT_TEXTEXTRACTOR_CLASSES;
/*     */     }
/*     */ 
/* 214 */     for (int i = 0; i < extractors.size(); i++) {
/* 215 */       String className = (String)extractors.get(i);
/*     */       try
/*     */       {
/* 218 */         textExtractors.add((TextExtractor)ClassUtils.forName(className).newInstance());
/*     */       }
/*     */       catch (InstantiationException e) {
/* 221 */         Log.error(e);
/*     */       }
/*     */       catch (IllegalAccessException e) {
/* 224 */         Log.error(e);
/*     */       }
/*     */       catch (ClassNotFoundException e) {
/* 227 */         Log.error(e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/* 232 */   public static TextExtractor[] getTextExtractors() { return (TextExtractor[])textExtractors.toArray(new TextExtractor[textExtractors.size()]); }
/*     */ 
/*     */   public static synchronized void addTextExtractor(String className) throws ClassNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 238 */       textExtractors.add((TextExtractor)ClassUtils.forName(className).newInstance());
/* 239 */       saveTextExtractors();
/*     */     }
/*     */     catch (InstantiationException e) {
/* 242 */       throw new IllegalArgumentException("Class is not a TextExtractor");
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 245 */       throw new IllegalArgumentException("Class is not a TextExtractor");
/*     */     }
/*     */     catch (ClassCastException e) {
/* 248 */       throw new IllegalArgumentException("Class is not a TextExtractor");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static synchronized void removeTextExtractor(String className) throws ClassNotFoundException {
/*     */     try {
/* 254 */       TextExtractor extractor = (TextExtractor)ClassUtils.forName(className).newInstance();
/* 255 */       for (int i = 0; i < textExtractors.size(); i++) {
/* 256 */         TextExtractor textExtractor = (TextExtractor)textExtractors.get(i);
/* 257 */         if (textExtractor.getName().equals(extractor.getName())) {
/* 258 */           textExtractors.remove(i);
/* 259 */           saveTextExtractors();
/* 260 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (InstantiationException e) {
/* 265 */       throw new IllegalArgumentException("Class is not a TextExtractor");
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 268 */       throw new IllegalArgumentException("Class is not a TextExtractor");
/*     */     }
/*     */     catch (ClassCastException e) {
/* 271 */       throw new IllegalArgumentException("Class is not a TextExtractor");
/*     */     }
/*     */   }
/*     */ 
/*     */   private static synchronized void saveTextExtractors()
/*     */   {
/* 277 */     List properties = JiveGlobals.getJivePropertyNames("search.textExtractors");
/* 278 */     for (int i = 0; i < properties.size(); i++) {
/* 279 */       String prop = (String)properties.get(i);
/* 280 */       JiveGlobals.deleteJiveProperty(prop);
/*     */     }
/*     */ 
/* 284 */     for (int i = 0; i < textExtractors.size(); i++) {
/* 285 */       TextExtractor extractor = (TextExtractor)textExtractors.get(i);
/* 286 */       JiveGlobals.setJiveProperty("search.textExtractors.extractor" + i, extractor.getClass().getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  39 */     DEFAULT_TEXTEXTRACTOR_CLASSES.add("com.jivesoftware.base.util.PDFExtractor");
/*  40 */     DEFAULT_TEXTEXTRACTOR_CLASSES.add("com.jivesoftware.base.util.WordExtractor");
/*  41 */     DEFAULT_TEXTEXTRACTOR_CLASSES.add("com.jivesoftware.base.util.HtmlExtractor");
/*  42 */     loadTextExtractors();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbAttachmentSearchIndexer
 * JD-Core Version:    0.6.2
 */
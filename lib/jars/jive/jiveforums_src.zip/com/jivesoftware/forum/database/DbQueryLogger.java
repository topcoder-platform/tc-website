/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.database.CachedPreparedStatement;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.Query;
/*     */ import com.jivesoftware.forum.QueryLogger;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.event.ForumEvent;
/*     */ import com.jivesoftware.forum.event.ForumEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ForumListener;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import com.jivesoftware.util.StringUtils;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DbQueryLogger
/*     */   implements QueryLogger, ForumListener
/*     */ {
/*     */   private static final String GET_QUERY_COUNT = "SELECT count(*) FROM jiveSearch WHERE searchType= 19";
/*     */   private static final String GET_USER_QUERY_COUNT = "SELECT count(*) FROM jiveSearch WHERE userID=? AND searchType= 19";
/*     */   private static final String LOAD_QUERY_IDS = "SELECT searchID, searchDate FROM jiveSearch WHERE searchType=19 ORDER BY searchDate DESC";
/*     */   private static final String LOAD_USER_QUERY_IDS = "SELECT searchID, searchDate FROM jiveSearch WHERE userID=? AND searchType=19 ORDER BY searchDate DESC";
/*     */   private static final String INSERT_QUERY = "INSERT INTO jiveSearch (searchID, searchType, userID, query, searchDuration, numResults, searchDate) VALUES (?, 19, ?, ?, ?, ?, ?)";
/*     */   private static final String INSERT_QUERY_CRITERIA = "INSERT INTO jiveSearchCriteria (searchID, criteriaName, criteriaValue) VALUES (?, ?, ?)";
/*     */   private static final String INSERT_CLICK_LOG = "INSERT INTO jiveSearchClick (searchID, messageID, clickDate) VALUES (?, ?, ?)";
/*     */   public static final String SELECT_OLD_ENTRIES = "SELECT searchID FROM jiveSearch where searchDate < ?";
/*  60 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */ 
/*  62 */   private static final Object deleteLock = new Object();
/*     */ 
/*  67 */   private static final Cache searchQueryCache = CacheFactory.createCache("Search Queries", "cache.searchQueryCache", 131072, 21600000L);
/*     */ 
/*  74 */   private static List clickthroughList = new ArrayList();
/*  75 */   private static Object lock = new Object();
/*     */ 
/*  80 */   private static DbQueryLogger instance = new DbQueryLogger();
/*     */   private static long timeWindow;
/*     */ 
/*     */   private DbQueryLogger()
/*     */   {
/* 112 */     TaskEngine.scheduleTask(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 117 */         if (!CacheFactory.isSeniorClusterMember()) {
/* 118 */           return;
/*     */         }
/*     */ 
/* 121 */         if (!JiveGlobals.getJiveBooleanProperty("search.querylogging.enabled", true)) {
/* 122 */           return;
/*     */         }
/*     */ 
/* 126 */         Connection con = null;
/* 127 */         PreparedStatement pstmt = null;
/*     */ 
/* 129 */         LongList ids = new LongList();
/*     */         try {
/* 131 */           con = ConnectionManager.getConnection();
/* 132 */           pstmt = con.prepareStatement("SELECT searchID FROM jiveSearch where searchDate < ?");
/* 133 */           long oldDate = ResultFilter.roundDate(CacheFactory.currentTime - DbQueryLogger.timeWindow, 3600);
/*     */ 
/* 135 */           pstmt.setLong(1, oldDate);
/* 136 */           ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 138 */           while (rs.next()) {
/* 139 */             ids.add(rs.getLong(1));
/*     */           }
/*     */ 
/* 142 */           rs.close();
/* 143 */           pstmt.close();
/*     */ 
/* 145 */           long[] idArray = ids.toArray();
/* 146 */           ConnectionManager.batchDeleteWithoutSubqueries(con, "DELETE FROM jiveSearchClick WHERE searchID IN ", idArray);
/*     */ 
/* 148 */           ConnectionManager.batchDeleteWithoutSubqueries(con, "DELETE FROM jiveSearchCriteria WHERE searchID IN ", idArray);
/*     */ 
/* 150 */           ConnectionManager.batchDeleteWithoutSubqueries(con, "DELETE FROM jiveSearch WHERE searchID IN ", idArray);
/*     */ 
/* 153 */           DbQueryLogger.searchQueryCache.clear();
/*     */         } catch (SQLException e) {
/* 155 */           Log.error(e);
/*     */         } finally {
/* 157 */           ConnectionManager.closeConnection(pstmt, con);
/*     */         }
/*     */       }
/*     */     }
/*     */     , 3600000L, 43200000L);
/*     */ 
/* 163 */     TaskEngine.scheduleTask(new Runnable()
/*     */     {
/*     */       public void run() {
/* 166 */         DbQueryLogger.access$200();
/*     */       }
/*     */     }
/*     */     , 60000L, 60000L);
/*     */ 
/* 170 */     ForumEventDispatcher.getInstance().addListener(this);
/*     */   }
/*     */ 
/*     */   public static DbQueryLogger getInstance() {
/* 174 */     return instance;
/*     */   }
/*     */ 
/*     */   public int getQueryCount() throws UnauthorizedException {
/* 178 */     QueryCacheKey key = new QueryCacheKey(19, -1L, new CachedPreparedStatement("SELECT count(*) FROM jiveSearch WHERE searchType= 19"), -1);
/*     */ 
/* 180 */     return QueryCache.getCount(key, true);
/*     */   }
/*     */ 
/*     */   public int getQueryCount(User user) throws UnauthorizedException {
/* 184 */     CachedPreparedStatement sql = new CachedPreparedStatement("SELECT count(*) FROM jiveSearch WHERE userID=? AND searchType= 19");
/* 185 */     sql.addLong(user.getID());
/* 186 */     QueryCacheKey key = new QueryCacheKey(19, user.getID(), sql, -1);
/* 187 */     return QueryCache.getCount(key, true);
/*     */   }
/*     */ 
/*     */   public Iterator getQueries() throws UnauthorizedException {
/* 191 */     long[] searchBlock = QueryCache.getBlock(new CachedPreparedStatement("SELECT searchID, searchDate FROM jiveSearch WHERE searchType=19 ORDER BY searchDate DESC"), 19, -1L, 0, true);
/*     */ 
/* 193 */     int endIndex = getQueryCount();
/* 194 */     return new QueryBlockIterator(searchBlock, new CachedPreparedStatement("SELECT searchID, searchDate FROM jiveSearch WHERE searchType=19 ORDER BY searchDate DESC"), 0, endIndex, -1L);
/*     */   }
/*     */ 
/*     */   public Iterator getQueries(User user) throws UnauthorizedException
/*     */   {
/* 199 */     CachedPreparedStatement sql = new CachedPreparedStatement("SELECT searchID, searchDate FROM jiveSearch WHERE userID=? AND searchType=19 ORDER BY searchDate DESC");
/* 200 */     sql.addLong(user.getID());
/* 201 */     long[] searchBlock = QueryCache.getBlock(sql, 19, user.getID(), 0, true);
/*     */ 
/* 203 */     int endIndex = getQueryCount(user);
/* 204 */     return new QueryBlockIterator(searchBlock, sql, 0, endIndex, user.getID());
/*     */   }
/*     */ 
/*     */   public void logQuery(User user, DbQuery query)
/*     */   {
/* 214 */     if (!JiveGlobals.getJiveBooleanProperty("search.querylogging.enabled", true)) {
/* 215 */       return;
/*     */     }
/*     */ 
/* 218 */     Connection con = null;
/* 219 */     PreparedStatement pstmt = null;
/* 220 */     boolean abortTransaction = false;
/*     */     try
/*     */     {
/* 223 */       con = ConnectionManager.getTransactionConnection();
/* 224 */       pstmt = con.prepareStatement("INSERT INTO jiveSearch (searchID, searchType, userID, query, searchDuration, numResults, searchDate) VALUES (?, 19, ?, ?, ?, ?, ?)");
/*     */ 
/* 226 */       pstmt.setLong(1, query.getID());
/* 227 */       if (user != null) {
/* 228 */         pstmt.setLong(2, user.getID());
/*     */       }
/*     */       else {
/* 231 */         pstmt.setNull(2, 2);
/*     */       }
/* 233 */       if (query.getQueryString() != null) {
/* 234 */         pstmt.setString(3, query.getQueryString());
/*     */       }
/*     */       else {
/* 237 */         pstmt.setString(3, "*");
/*     */       }
/*     */ 
/* 240 */       pstmt.setLong(4, query.getSearchDuration());
/* 241 */       pstmt.setInt(5, query.getResultCount());
/* 242 */       pstmt.setLong(6, query.getSearchDate().getTime());
/* 243 */       pstmt.execute();
/* 244 */       pstmt.close();
/*     */ 
/* 246 */       Map criteria = new HashMap();
/*     */ 
/* 248 */       if (query.getBeforeDate() != null) {
/* 249 */         criteria.put("beforeDate", StringUtils.dateToMillis(query.getBeforeDate()));
/*     */       }
/*     */ 
/* 252 */       if (query.getAfterDate() != null) {
/* 253 */         criteria.put("afterDate", StringUtils.dateToMillis(query.getAfterDate()));
/*     */       }
/*     */ 
/* 256 */       if (query.getFilteredUser() != null) {
/* 257 */         criteria.put("filteredUserID", "" + query.getFilteredUser().getID());
/*     */       }
/*     */ 
/* 260 */       if (query.getFilteredThread() != null) {
/* 261 */         criteria.put("threadID", "" + query.getFilteredThread().getID());
/*     */       }
/*     */ 
/* 264 */       if ((query.getForums() != null) && (query.getForums().length > 0)) {
/* 265 */         Forum[] forums = query.getForums();
/* 266 */         for (int j = 0; j < forums.length; j++) {
/* 267 */           if (criteria.get("forumID") == null) {
/* 268 */             List cats = new ArrayList();
/* 269 */             cats.add(new Long(forums[j].getID()));
/* 270 */             criteria.put("forumID", cats);
/*     */           }
/*     */           else {
/* 273 */             List cats = (List)criteria.get("forumID");
/* 274 */             cats.add(new Long(forums[j].getID()));
/* 275 */             criteria.put("forumID", cats);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 280 */       if (query.getSortField() != 10001) {
/* 281 */         criteria.put("sortField", "" + query.getSortField());
/*     */       }
/*     */ 
/* 284 */       if (query.getSortOrder() != 1) {
/* 285 */         criteria.put("sortOrder", "" + query.getSortOrder());
/*     */       }
/*     */ 
/* 288 */       pstmt = con.prepareStatement("INSERT INTO jiveSearchCriteria (searchID, criteriaName, criteriaValue) VALUES (?, ?, ?)");
/*     */ 
/* 290 */       for (Iterator iterator = criteria.keySet().iterator(); iterator.hasNext(); ) {
/* 291 */         String key = (String)iterator.next();
/* 292 */         Object value = criteria.get(key);
/* 293 */         if ((value instanceof String)) {
/* 294 */           pstmt.setLong(1, query.getID());
/* 295 */           pstmt.setString(2, key);
/* 296 */           pstmt.setString(3, (String)value);
/* 297 */           if (ConnectionManager.isBatchUpdatesSupported()) {
/* 298 */             pstmt.addBatch();
/*     */           }
/*     */           else
/* 301 */             pstmt.execute();
/*     */         }
/*     */         else
/*     */         {
/* 305 */           List values = (List)value;
/* 306 */           for (int i = 0; i < values.size(); i++) {
/* 307 */             Object v = values.get(i);
/* 308 */             pstmt.setLong(1, query.getID());
/* 309 */             pstmt.setString(2, key);
/* 310 */             pstmt.setString(3, v.toString());
/* 311 */             if (ConnectionManager.isBatchUpdatesSupported()) {
/* 312 */               pstmt.addBatch();
/*     */             }
/*     */             else {
/* 315 */               pstmt.execute();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 321 */       if (ConnectionManager.isBatchUpdatesSupported()) {
/* 322 */         pstmt.executeBatch();
/*     */       }
/*     */ 
/* 326 */       FACTORY.cacheManager.queryRemove(19, user == null ? -1L : user.getID());
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 330 */       Log.error(e);
/* 331 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 334 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void logSearchClick(long searchID, long messageID)
/*     */   {
/* 345 */     if (!JiveGlobals.getJiveBooleanProperty("search.querylogging.enabled", true)) {
/* 346 */       return;
/*     */     }
/*     */ 
/* 349 */     ClickLogItem logItem = new ClickLogItem(searchID, messageID, new Date());
/* 350 */     synchronized (clickthroughList) {
/* 351 */       clickthroughList.add(logItem);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Query getQuery(long queryID)
/*     */     throws NotFoundException
/*     */   {
/* 363 */     Query query = (Query)searchQueryCache.get(new Long(queryID));
/* 364 */     if (query == null) {
/* 365 */       synchronized (("searchquery-" + queryID).intern()) {
/* 366 */         query = (Query)searchQueryCache.get(new Long(queryID));
/* 367 */         if (query == null) {
/* 368 */           query = new DbQuery(queryID);
/* 369 */           searchQueryCache.put(new Long(queryID), query);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 374 */     return query;
/*     */   }
/*     */ 
/*     */   public Map getLoggedQueryInfo(Query query) {
/* 378 */     Map info = new HashMap();
/*     */     try {
/* 380 */       DbQuery dbQuery = (DbQuery)getQuery(query.getID());
/* 381 */       info.put("searchDuration", new Integer(dbQuery.getSearchDuration()));
/* 382 */       info.put("searchDate", dbQuery.getSearchDate());
/* 383 */       info.put("forums", dbQuery.getForums());
/* 384 */       info.put("numResults", new Integer(dbQuery.getResultCount()));
/*     */     }
/*     */     catch (NotFoundException e) {
/* 387 */       Log.error(e);
/*     */     }
/*     */ 
/* 390 */     return info;
/*     */   }
/*     */ 
/*     */   public void forumAdded(ForumEvent event) {
/*     */   }
/*     */ 
/*     */   public void forumDeleted(final ForumEvent event) {
/* 397 */     TaskEngine.addTask(new Runnable()
/*     */     {
/*     */       private final ForumEvent val$event;
/*     */ 
/*     */       public void run()
/*     */       {
/* 403 */         synchronized (DbQueryLogger.deleteLock) {
/* 404 */           Connection con = null;
/* 405 */           PreparedStatement pstmt = null;
/*     */           try
/*     */           {
/* 408 */             con = ConnectionManager.getConnection();
/*     */ 
/* 410 */             LongList l = new LongList();
/* 411 */             pstmt = con.prepareStatement("SELECT searchID, searchDate FROM jiveSearch WHERE searchType=19 ORDER BY searchDate DESC");
/* 412 */             ResultSet rs = pstmt.executeQuery();
/* 413 */             while (rs.next()) {
/* 414 */               l.add(rs.getLong(1));
/*     */             }
/*     */ 
/* 417 */             rs.close();
/* 418 */             pstmt.close();
/* 419 */             String query = "DELETE FROM jiveSearchCriteria WHERE criteriaName='forumID' AND criteriaValue='" + event.getForum().getID() + "' AND " + "searchID IN";
/*     */ 
/* 423 */             ConnectionManager.batchDeleteWithoutSubqueries(con, query, l.toArray());
/*     */           }
/*     */           catch (SQLException e) {
/* 426 */             Log.error(e);
/*     */           }
/*     */           finally {
/* 429 */             ConnectionManager.closeConnection(pstmt, con);
/*     */           }
/*     */         }
/*     */       }
/*     */     });
/* 437 */     searchQueryCache.clear();
/*     */   }
/*     */ 
/*     */   public void forumMoved(ForumEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void forumMerged(ForumEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   private static void batchInserts() {
/* 449 */     if (clickthroughList.size() == 0) {
/* 450 */       return;
/*     */     }
/*     */ 
/* 454 */     synchronized (lock)
/*     */     {
/*     */       ClickLogItem[] clickArray;
/* 459 */       synchronized (clickthroughList) {
/* 460 */         clickArray = (ClickLogItem[])clickthroughList.toArray(new ClickLogItem[clickthroughList.size()]);
/* 461 */         clickthroughList.clear();
/*     */       }
/*     */ 
/* 464 */       Connection con = null;
/* 465 */       PreparedStatement pstmt = null;
/*     */       try
/*     */       {
/* 468 */         con = ConnectionManager.getConnection();
/* 469 */         pstmt = con.prepareStatement("INSERT INTO jiveSearchClick (searchID, messageID, clickDate) VALUES (?, ?, ?)");
/* 470 */         for (int i = 0; i < clickArray.length; i++) {
/* 471 */           ClickLogItem log = clickArray[i];
/* 472 */           pstmt.setLong(1, log.getSearchID());
/* 473 */           pstmt.setLong(2, log.getMessageID());
/* 474 */           pstmt.setLong(3, log.getClickDate().getTime());
/* 475 */           if (ConnectionManager.isBatchUpdatesSupported()) {
/* 476 */             pstmt.addBatch();
/*     */           }
/*     */           else {
/* 479 */             pstmt.execute();
/*     */           }
/*     */         }
/*     */ 
/* 483 */         if (ConnectionManager.isBatchUpdatesSupported()) {
/* 484 */           pstmt.executeBatch();
/*     */         }
/*     */       }
/*     */       catch (SQLException e)
/*     */       {
/* 489 */         Log.warn("Unable to log clickthrough", e);
/*     */       }
/*     */       finally {
/* 492 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  92 */     if (JiveGlobals.getJiveProperty("queryLogger.timeWindow") != null) {
/*  93 */       int days = JiveGlobals.getJiveIntProperty("queryLogger.timeWindow", 90);
/*  94 */       timeWindow = days * 86400000L;
/*     */     }
/*     */     else
/*     */     {
/*  98 */       timeWindow = 7776000000L;
/*  99 */       String time = JiveGlobals.getJiveProperty("search.querylogger.expiryTime");
/* 100 */       if (time != null)
/*     */         try {
/* 102 */           timeWindow = Long.parseLong(time);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   class ClickLogItem
/*     */   {
/*     */     private long searchID;
/*     */     private long messageID;
/*     */     private Date clickDate;
/*     */ 
/*     */     ClickLogItem(long searchID, long messageID, Date clickDate)
/*     */     {
/* 503 */       this.searchID = searchID;
/* 504 */       this.messageID = messageID;
/* 505 */       this.clickDate = clickDate;
/*     */     }
/*     */ 
/*     */     public long getSearchID() {
/* 509 */       return this.searchID;
/*     */     }
/*     */ 
/*     */     public long getMessageID() {
/* 513 */       return this.messageID;
/*     */     }
/*     */ 
/*     */     public Date getClickDate() {
/* 517 */       return this.clickDate;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbQueryLogger
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.database;
/*    */ 
/*    */ import com.jivesoftware.forum.event.SearchIndexEvent;
/*    */ import com.jivesoftware.forum.event.SearchIndexEventDispatcher;
/*    */ import com.jivesoftware.forum.event.SearchIndexListener;
/*    */ import com.jivesoftware.util.DefaultCache;
/*    */ 
/*    */ class LuceneFilterCache extends DefaultCache
/*    */   implements SearchIndexListener
/*    */ {
/*    */   LuceneFilterCache()
/*    */   {
/* 23 */     super("SearchFilter", -1, -1L);
/* 24 */     SearchIndexEventDispatcher.getInstance().addListener(this);
/*    */   }
/*    */ 
/*    */   public synchronized Object put(Object key, Object value)
/*    */   {
/* 35 */     return super.put(key, value);
/*    */   }
/*    */ 
/*    */   public synchronized Object get(Object key)
/*    */   {
/* 45 */     return super.get(key);
/*    */   }
/*    */ 
/*    */   public void messageAdded(SearchIndexEvent event) {
/* 49 */     clear();
/*    */   }
/*    */ 
/*    */   public void messageDeleted(SearchIndexEvent event) {
/* 53 */     clear();
/*    */   }
/*    */ 
/*    */   public void rebuildStarted(SearchIndexEvent event)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void rebuildCompleted(SearchIndexEvent event) {
/* 61 */     clear();
/*    */   }
/*    */ 
/*    */   public void updateStarted(SearchIndexEvent event)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void updateCompleted(SearchIndexEvent event) {
/* 69 */     clear();
/*    */   }
/*    */ 
/*    */   public void optimizeStarted(SearchIndexEvent event)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void optimizeCompleted(SearchIndexEvent event)
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.LuceneFilterCache
 * JD-Core Version:    0.6.2
 */
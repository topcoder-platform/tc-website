/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.StatusLevel;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class StatusLevelLeaderBlockIterator
/*     */   implements Iterator
/*     */ {
/*     */   private long[] block;
/*     */   private int blockID;
/*     */   private int blockStart;
/*     */   private DbStatusLevelManager manager;
/*     */   private int currentIndex;
/*     */   private int currentSize;
/*     */   private int size;
/*     */   private int objectType;
/*     */   private long objectID;
/*  43 */   private Object nextElement = null;
/*     */ 
/*  45 */   private int nextElementIndex = -1;
/*     */ 
/*  47 */   private boolean isBlockGroups = false;
/*     */ 
/*  49 */   private boolean isBlocksEmpty = false;
/*     */ 
/*  51 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */ 
/*     */   protected StatusLevelLeaderBlockIterator(long[] block, int startIndex, int size, int objectType, long objectID, DbStatusLevelManager manager)
/*     */   {
/*  70 */     this.block = block;
/*  71 */     this.blockID = (startIndex / 100);
/*  72 */     this.blockStart = (this.blockID * 100);
/*  73 */     this.currentIndex = (startIndex - 1);
/*  74 */     this.currentSize = 0;
/*  75 */     this.size = size;
/*  76 */     this.objectType = objectType;
/*  77 */     this.objectID = objectID;
/*  78 */     this.manager = manager;
/*     */ 
/*  80 */     this.isBlockGroups = JiveGlobals.getJiveBooleanProperty("statusLevels.blockGroupLeaders");
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/*  85 */     if (this.currentSize > this.size) {
/*  86 */       return false;
/*     */     }
/*     */ 
/*  91 */     if (this.nextElement == null) {
/*  92 */       Object element = null;
/*  93 */       int index = this.currentIndex;
/*     */ 
/*  95 */       boolean isSkipped = true;
/*  96 */       while ((this.currentSize < this.size) && (isSkipped) && (!this.isBlocksEmpty) && ((this.block.length >= 100) || (index + 1 - this.blockStart < this.block.length)))
/*     */       {
/* 101 */         index++;
/* 102 */         element = getElement(index);
/* 103 */         isSkipped = isSkipped(element);
/* 104 */         if (!isSkipped) {
/* 105 */           this.currentSize += 1;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 110 */       if ((element == null) || (isSkipped)) {
/* 111 */         return false;
/*     */       }
/*     */ 
/* 114 */       this.nextElement = element;
/* 115 */       this.nextElementIndex = index;
/*     */     }
/*     */ 
/* 118 */     return true;
/*     */   }
/*     */ 
/*     */   public Object next() throws NoSuchElementException {
/* 122 */     Object element = null;
/* 123 */     if ((this.nextElement != null) && (this.nextElementIndex != -1)) {
/* 124 */       element = this.nextElement;
/* 125 */       this.currentIndex = this.nextElementIndex;
/* 126 */       this.nextElement = null;
/* 127 */       this.nextElementIndex = -1;
/*     */     }
/*     */     else {
/* 130 */       element = getNextElement();
/* 131 */       if (element == null) {
/* 132 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/* 135 */     return element;
/*     */   }
/*     */ 
/*     */   public void remove() {
/* 139 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   private Object getNextElement()
/*     */   {
/* 150 */     Object element = null;
/* 151 */     boolean isSkipped = true;
/* 152 */     while ((this.currentSize < this.size) && (isSkipped) && (!this.isBlocksEmpty)) {
/* 153 */       this.currentIndex += 1;
/* 154 */       element = getElement(this.currentIndex);
/* 155 */       isSkipped = isSkipped(element);
/* 156 */       if (!isSkipped) {
/* 157 */         this.currentSize += 1;
/*     */       }
/*     */     }
/* 160 */     if (!isSkipped) {
/* 161 */       return element;
/*     */     }
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */   private Object getElement(int index) {
/* 167 */     if (index < 0) {
/* 168 */       return null;
/*     */     }
/* 170 */     if ((this.block != null) && (this.block.length == 0))
/*     */     {
/* 173 */       this.isBlocksEmpty = true;
/* 174 */       return null;
/*     */     }
/*     */ 
/* 177 */     if (this.block.length < 100)
/*     */     {
/* 181 */       if ((index < this.blockStart) || (index >= this.blockStart + 100))
/*     */       {
/*     */         try
/*     */         {
/* 185 */           this.block = this.manager.getLeaderBlock(this.objectType, this.objectID, index);
/*     */ 
/* 187 */           this.blockID = (index / 100);
/* 188 */           this.blockStart = (this.blockID * 100);
/*     */         }
/*     */         catch (Exception e) {
/* 191 */           Log.warn(e);
/*     */ 
/* 193 */           return null;
/*     */         }
/*     */       }
/*     */     }
/* 196 */     Object element = null;
/*     */ 
/* 199 */     int relativeIndex = index % 100;
/*     */ 
/* 201 */     if (relativeIndex < this.block.length)
/*     */       try
/*     */       {
/* 204 */         element = FACTORY.getUserManager().getUser(this.block[relativeIndex]);
/*     */       }
/*     */       catch (UserNotFoundException unfe) {
/*     */       }
/* 208 */     return element;
/*     */   }
/*     */ 
/*     */   boolean isSkipped(Object o)
/*     */   {
/* 214 */     if (o == null) {
/* 215 */       return true;
/*     */     }
/*     */ 
/* 218 */     User user = (User)o;
/*     */ 
/* 220 */     StatusLevel statusLevel = this.manager.getStatusLevel(user);
/*     */ 
/* 223 */     boolean isSkip = (this.isBlockGroups) && (statusLevel != null) && (statusLevel.getGroup() != null);
/* 224 */     return isSkip;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.StatusLevelLeaderBlockIterator
 * JD-Core Version:    0.6.2
 */
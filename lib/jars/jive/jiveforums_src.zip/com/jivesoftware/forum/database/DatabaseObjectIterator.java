/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.AnnouncementNotFoundException;
/*     */ import com.jivesoftware.forum.AttachmentNotFoundException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.PrivateMessageNotFoundException;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class DatabaseObjectIterator
/*     */   implements Iterator
/*     */ {
/*     */   private long[] elements;
/*  43 */   private int currentIndex = -1;
/*  44 */   private Object nextElement = null;
/*     */   private DatabaseObjectFactory objectFactory;
/*     */ 
/*     */   public DatabaseObjectIterator(int type, long[] elements, final Object extraObject)
/*     */   {
/*  70 */     this.elements = elements;
/*     */ 
/*  74 */     switch (type)
/*     */     {
/*     */     case 3:
/*  78 */       this.objectFactory = new DatabaseObjectFactory() { ForumFactory factory = (ForumFactory)extraObject;
/*     */         private final Object val$extraObject;
/*     */ 
/*     */         public Object loadObject(long id) {
/*     */           try { return this.factory.getUserManager().getUser(id);
/*     */           } catch (UserNotFoundException unfe) {
/*     */           }
/*  86 */           return null;
/*     */         }
/*     */       };
/*  89 */       break;
/*     */     case 14:
/*  93 */       this.objectFactory = new DatabaseObjectFactory() { ForumFactory factory = (ForumFactory)extraObject;
/*     */         private final Object val$extraObject;
/*     */ 
/*     */         public Object loadObject(long id) {
/*     */           try { return this.factory.getForumCategory(id);
/*     */           } catch (ForumCategoryNotFoundException fcnfe) {
/*     */           }
/* 101 */           return null;
/*     */         }
/*     */       };
/* 104 */       break;
/*     */     case 0:
/* 108 */       this.objectFactory = new DatabaseObjectFactory() { ForumFactory factory = (ForumFactory)extraObject;
/*     */         private final Object val$extraObject;
/*     */ 
/*     */         public Object loadObject(long id) {
/*     */           try { return this.factory.getForum(id); } catch (ForumNotFoundException mnfe) {
/*     */           }
/*     */           catch (UnauthorizedException ue) {
/*     */           }
/* 117 */           return null;
/*     */         }
/*     */       };
/* 120 */       break;
/*     */     case 1:
/* 129 */       if ((extraObject instanceof Forum)) {
/* 130 */         this.objectFactory = new DatabaseObjectFactory() { Forum forum = (Forum)extraObject;
/*     */           private final Object val$extraObject;
/*     */ 
/*     */           public Object loadObject(long id) {
/*     */             try { return this.forum.getThread(id);
/*     */             } catch (ForumThreadNotFoundException tnfe) {
/*     */             }
/* 138 */             return null;
/*     */           }
/*     */         };
/*     */       }
/*     */       else {
/* 143 */         this.objectFactory = new DatabaseObjectFactory() { DbForumFactory factory = (DbForumFactory)extraObject;
/*     */           private final Object val$extraObject;
/*     */ 
/*     */           public Object loadObject(long id) {
/*     */             try { return this.factory.cacheManager.getForumThread(id);
/*     */             } catch (ForumThreadNotFoundException mnfe) {
/*     */             }
/* 151 */             return null;
/*     */           }
/*     */         };
/*     */       }
/* 155 */       break;
/*     */     case 2:
/* 164 */       if ((extraObject instanceof ForumThread)) {
/* 165 */         this.objectFactory = new DatabaseObjectFactory() { ForumThread thread = (ForumThread)extraObject;
/*     */           private final Object val$extraObject;
/*     */ 
/*     */           public Object loadObject(long id) {
/*     */             try { return this.thread.getMessage(id);
/*     */             } catch (ForumMessageNotFoundException mnfe) {
/*     */             }
/* 173 */             return null;
/*     */           }
/*     */         };
/*     */       }
/*     */       else {
/* 178 */         this.objectFactory = new DatabaseObjectFactory() { DbForumFactory factory = (DbForumFactory)extraObject;
/*     */           private final Object val$extraObject;
/*     */ 
/*     */           public Object loadObject(long id) {
/*     */             try { return this.factory.getMessage(id);
/*     */             } catch (ForumMessageNotFoundException mnfe) {
/*     */             }
/* 186 */             return null;
/*     */           }
/*     */         };
/*     */       }
/* 190 */       break;
/*     */     case 13:
/* 194 */       this.objectFactory = new DatabaseObjectFactory() { DbForumFactory factory = (DbForumFactory)extraObject;
/*     */         private final Object val$extraObject;
/*     */ 
/*     */         public Object loadObject(long id) {
/*     */           try { return this.factory.cacheManager.getAttachment(id);
/*     */           } catch (AttachmentNotFoundException anfe) {
/*     */           }
/* 202 */           return null;
/*     */         }
/*     */       };
/* 205 */       break;
/*     */     case 20:
/* 209 */       this.objectFactory = new DatabaseObjectFactory() { DbPrivateMessageManager manager = (DbPrivateMessageManager)extraObject;
/*     */         private final Object val$extraObject;
/*     */ 
/*     */         public Object loadObject(long id) {
/*     */           try { return this.manager.getPrivateMessage(id);
/*     */           } catch (PrivateMessageNotFoundException pmnfe) {
/*     */           }
/* 217 */           return null;
/*     */         }
/*     */       };
/* 220 */       break;
/*     */     case 22:
/* 224 */       this.objectFactory = new DatabaseObjectFactory() { DbAnnouncementManager manager = (DbAnnouncementManager)extraObject;
/*     */         private final Object val$extraObject;
/*     */ 
/*     */         public Object loadObject(long id) {
/*     */           try { return this.manager.getAnnouncement(id);
/*     */           } catch (AnnouncementNotFoundException anfe) {
/*     */           }
/* 232 */           return null;
/*     */         }
/*     */       };
/* 235 */       break;
/*     */     case 4:
/*     */     case 5:
/*     */     case 6:
/*     */     case 7:
/*     */     case 8:
/*     */     case 9:
/*     */     case 10:
/*     */     case 11:
/*     */     case 12:
/*     */     case 15:
/*     */     case 16:
/*     */     case 17:
/*     */     case 18:
/*     */     case 19:
/*     */     case 21:
/*     */     default:
/* 238 */       throw new IllegalArgumentException("Illegal type specified");
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/* 250 */     if ((this.elements == null) || ((this.currentIndex + 1 >= this.elements.length) && (this.nextElement == null))) {
/* 251 */       return false;
/*     */     }
/*     */ 
/* 255 */     if (this.nextElement == null) {
/* 256 */       this.nextElement = getNextElement();
/* 257 */       if (this.nextElement == null) {
/* 258 */         return false;
/*     */       }
/*     */     }
/* 261 */     return true;
/*     */   }
/*     */ 
/*     */   public Object next()
/*     */     throws NoSuchElementException
/*     */   {
/* 271 */     Object element = null;
/* 272 */     if (this.nextElement != null) {
/* 273 */       element = this.nextElement;
/* 274 */       this.nextElement = null;
/*     */     }
/*     */     else {
/* 277 */       element = getNextElement();
/* 278 */       if (element == null) {
/* 279 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/* 282 */     return element;
/*     */   }
/*     */ 
/*     */   public void remove()
/*     */     throws UnsupportedOperationException
/*     */   {
/* 289 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Object getNextElement()
/*     */   {
/* 299 */     if (this.elements == null) {
/* 300 */       return null;
/*     */     }
/*     */ 
/* 303 */     while (this.currentIndex + 1 < this.elements.length) {
/* 304 */       this.currentIndex += 1;
/* 305 */       Object element = this.objectFactory.loadObject(this.elements[this.currentIndex]);
/* 306 */       if (element != null) {
/* 307 */         return element;
/*     */       }
/*     */     }
/* 310 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DatabaseObjectIterator
 * JD-Core Version:    0.6.2
 */
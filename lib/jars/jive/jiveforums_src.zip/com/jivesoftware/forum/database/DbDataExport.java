/*      */ package com.jivesoftware.forum.database;
/*      */ 
/*      */ import com.jivesoftware.base.AuthFactory;
/*      */ import com.jivesoftware.base.AuthToken;
/*      */ import com.jivesoftware.base.Group;
/*      */ import com.jivesoftware.base.GroupManager;
/*      */ import com.jivesoftware.base.JiveGlobals;
/*      */ import com.jivesoftware.base.Log;
/*      */ import com.jivesoftware.base.PermissionType;
/*      */ import com.jivesoftware.base.PermissionsManager;
/*      */ import com.jivesoftware.base.Poll;
/*      */ import com.jivesoftware.base.PollManager;
/*      */ import com.jivesoftware.base.PollManagerFactory;
/*      */ import com.jivesoftware.base.UnauthorizedException;
/*      */ import com.jivesoftware.base.User;
/*      */ import com.jivesoftware.base.UserManager;
/*      */ import com.jivesoftware.base.UserNotFoundException;
/*      */ import com.jivesoftware.base.database.DbPoll;
/*      */ import com.jivesoftware.base.database.Vote;
/*      */ import com.jivesoftware.forum.Announcement;
/*      */ import com.jivesoftware.forum.AnnouncementManager;
/*      */ import com.jivesoftware.forum.Attachment;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumCategory;
/*      */ import com.jivesoftware.forum.ForumFactory;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*      */ import com.jivesoftware.forum.ForumThread;
/*      */ import com.jivesoftware.forum.PrivateMessage;
/*      */ import com.jivesoftware.forum.PrivateMessageFolder;
/*      */ import com.jivesoftware.forum.PrivateMessageManager;
/*      */ import com.jivesoftware.forum.TreeWalker;
/*      */ import com.jivesoftware.util.AbstractPollableRunnable;
/*      */ import com.jivesoftware.util.Cache;
/*      */ import com.jivesoftware.util.StringUtils;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Serializable;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.nio.charset.Charset;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import java.util.SortedMap;
/*      */ import java.util.zip.ZipEntry;
/*      */ import java.util.zip.ZipOutputStream;
/*      */ import org.apache.commons.cli.BasicParser;
/*      */ import org.apache.commons.cli.CommandLine;
/*      */ import org.apache.commons.cli.CommandLineParser;
/*      */ import org.apache.commons.cli.HelpFormatter;
/*      */ import org.apache.commons.cli.Option;
/*      */ import org.apache.commons.cli.Options;
/*      */ 
/*      */ public class DbDataExport extends AbstractPollableRunnable
/*      */   implements Serializable
/*      */ {
/*   55 */   private static String NAME = "Jive Software Database Export Utility";
/*      */ 
/*   61 */   public static final SimpleDateFormat DEFAULT_FILE_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd-HHmm");
/*      */   public static final String DEFAULT_ENCODING = "UTF-8";
/*   71 */   private static final long[] PERM_TYPES = { 512L, 8L, 2L, 4L, 256L, 288230376151711744L, 128L, 1L, 576460752303423488L, 144115188075855872L, 2048L, 64L, 1152921504606846976L, 2305843009213693952L, 4611686018427387904L, -9223372036854775808L, 72057594037927936L, 16L };
/*      */ 
/*   93 */   private static final String[] PERM_NAMES = { "FORUM_CATEGORY_ADMIN", "CREATE_MESSAGE_ATTACHMENT", "CREATE_MESSAGE", "CREATE_THREAD", "FORUM_ADMIN", "GROUP_ADMIN", "MODERATOR", "READ_FORUM", "SYSTEM_ADMIN", "USER_ADMIN", "CREATE_PRIVATE_MESSAGE_ATTACHMENT", "RATE_MESSAGE", "CUSTOM_1", "CUSTOM_2", "CUSTOM_3", "CUSTOM_4", "VIEW_ONLINE_STATUS", "CREATE_POLL" };
/*      */ 
/*  115 */   private boolean exportIDsEnabled = true;
/*  116 */   private boolean exportUsersEnabled = true;
/*  117 */   private boolean exportGroupsEnabled = true;
/*  118 */   private boolean exportForumsEnabled = true;
/*  119 */   private boolean exportPermsEnabled = true;
/*  120 */   private boolean exportPollsEnabled = true;
/*  121 */   private boolean exportAnnouncementsEnabled = true;
/*  122 */   private boolean exportJivePropertiesEnabled = true;
/*  123 */   private boolean exportPrivateMessagesEnabled = true;
/*  124 */   private boolean exportAttachmentsEnabled = true;
/*      */   private Set exportedForums;
/*      */   private Set exportedCategories;
/*      */   private File exportFile;
/*      */   private int writeBuffer;
/*      */   private SimpleDateFormat dateFormatter;
/*      */   private String encoding;
/*  136 */   private int indent = 0;
/*      */   private ForumFactory factory;
/*  142 */   private int taskMaximum = 0;
/*  143 */   private int taskValue = 0;
/*      */   private Collection errors;
/*      */   private OutputStream outputStream;
/*  152 */   private Collection exportedAttachments = new ArrayList();
/*      */ 
/*      */   public DbDataExport(ForumFactory factory)
/*      */     throws UnauthorizedException
/*      */   {
/*  162 */     if (!factory.isAuthorized(576460752303423488L)) {
/*  163 */       throw new UnauthorizedException("Must have system admin privileges to export data.");
/*      */     }
/*      */ 
/*  167 */     this.factory = factory;
/*  168 */     this.exportIDsEnabled = true;
/*  169 */     this.exportUsersEnabled = true;
/*  170 */     this.exportGroupsEnabled = true;
/*  171 */     this.exportForumsEnabled = true;
/*  172 */     this.exportPermsEnabled = true;
/*  173 */     this.exportedForums = new HashSet();
/*  174 */     this.exportedCategories = new HashSet();
/*  175 */     this.errors = new HashSet();
/*      */ 
/*  178 */     this.writeBuffer = 262144;
/*      */     try {
/*  180 */       this.writeBuffer = Integer.parseInt(JiveGlobals.getJiveProperty("dataExport.writeBuffer"));
/*      */     }
/*      */     catch (NumberFormatException ignored)
/*      */     {
/*      */     }
/*      */ 
/*  186 */     this.dateFormatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SS z");
/*      */     try {
/*  188 */       this.dateFormatter = new SimpleDateFormat(JiveGlobals.getJiveProperty("dataExport.fileDateFormat"));
/*      */     }
/*      */     catch (Exception ignored)
/*      */     {
/*      */     }
/*      */ 
/*  195 */     this.encoding = "UTF-8";
/*  196 */     String encodingParam = JiveGlobals.getJiveProperty("dataExport.encoding");
/*  197 */     if (encodingParam != null) {
/*  198 */       this.encoding = encodingParam;
/*      */     }
/*      */ 
/*  202 */     this.exportFile = new File(new File(JiveGlobals.getJiveHome(), "data"), DEFAULT_FILE_DATE_FORMAT.format(new Date()) + ".zip");
/*      */   }
/*      */ 
/*      */   public boolean isExportIDsEnabled()
/*      */   {
/*  214 */     return this.exportIDsEnabled;
/*      */   }
/*      */ 
/*      */   public void setExportIDsEnabled(boolean exportIDs)
/*      */   {
/*  228 */     checkRunning();
/*  229 */     this.exportIDsEnabled = exportIDs;
/*      */   }
/*      */ 
/*      */   public boolean isExportUsersEnabled()
/*      */   {
/*  238 */     return this.exportUsersEnabled;
/*      */   }
/*      */ 
/*      */   public void setExportUsersEnabled(boolean exportUsers)
/*      */   {
/*  247 */     checkRunning();
/*  248 */     this.exportUsersEnabled = exportUsers;
/*      */   }
/*      */ 
/*      */   public boolean isExportGroupsEnabled()
/*      */   {
/*  257 */     return this.exportGroupsEnabled;
/*      */   }
/*      */ 
/*      */   public void setExportGroupsEnabled(boolean exportGroups)
/*      */   {
/*  266 */     checkRunning();
/*  267 */     this.exportGroupsEnabled = exportGroups;
/*      */   }
/*      */ 
/*      */   public boolean isExportForumsEnabled()
/*      */   {
/*  276 */     return this.exportForumsEnabled;
/*      */   }
/*      */ 
/*      */   public void setExportForumsEnabled(boolean exportForums)
/*      */   {
/*  285 */     checkRunning();
/*  286 */     this.exportForumsEnabled = exportForums;
/*      */   }
/*      */ 
/*      */   public boolean isExportPermsEnabled()
/*      */   {
/*  295 */     return this.exportPermsEnabled;
/*      */   }
/*      */ 
/*      */   public void setExportPermsEnabled(boolean exportPerms)
/*      */   {
/*  307 */     checkRunning();
/*  308 */     this.exportPermsEnabled = exportPerms;
/*      */   }
/*      */ 
/*      */   public boolean isExportPollsEnabled()
/*      */   {
/*  317 */     return this.exportPollsEnabled;
/*      */   }
/*      */ 
/*      */   public void setExportPollsEnabled(boolean exportPollsEnabled)
/*      */   {
/*  327 */     checkRunning();
/*  328 */     this.exportPollsEnabled = exportPollsEnabled;
/*      */   }
/*      */ 
/*      */   public boolean isExportAnnouncementsEnabled()
/*      */   {
/*  337 */     return this.exportAnnouncementsEnabled;
/*      */   }
/*      */ 
/*      */   public void setExportAnnouncementsEnabled(boolean exportAnnouncementsEnabled)
/*      */   {
/*  347 */     checkRunning();
/*  348 */     this.exportAnnouncementsEnabled = exportAnnouncementsEnabled;
/*      */   }
/*      */ 
/*      */   public boolean isExportPrivateMessagesEnabled()
/*      */   {
/*  357 */     return this.exportPrivateMessagesEnabled;
/*      */   }
/*      */ 
/*      */   public void setExportPrivateMessagesEnabled(boolean exportPrivateMessagesEnabled)
/*      */   {
/*  367 */     checkRunning();
/*  368 */     this.exportPrivateMessagesEnabled = exportPrivateMessagesEnabled;
/*      */   }
/*      */ 
/*      */   public Collection getExportedForums()
/*      */   {
/*  381 */     return this.exportedForums;
/*      */   }
/*      */ 
/*      */   public Collection getExportedCategories()
/*      */   {
/*  392 */     return this.exportedCategories;
/*      */   }
/*      */ 
/*      */   public void setExportJivePropertiesEnabled(boolean exportJivePropertiesEnabled)
/*      */   {
/*  402 */     checkRunning();
/*  403 */     this.exportJivePropertiesEnabled = exportJivePropertiesEnabled;
/*      */   }
/*      */ 
/*      */   public boolean isExportJivePropertiesEnabled()
/*      */   {
/*  412 */     return this.exportJivePropertiesEnabled;
/*      */   }
/*      */ 
/*      */   public boolean isExportAttachmentsEnabled()
/*      */   {
/*  421 */     return this.exportAttachmentsEnabled;
/*      */   }
/*      */ 
/*      */   public void setExportAttachmentsEnabled(boolean exportAttachmentsEnabled)
/*      */   {
/*  431 */     this.exportAttachmentsEnabled = exportAttachmentsEnabled;
/*      */   }
/*      */ 
/*      */   public OutputStream getOutputStream()
/*      */   {
/*  440 */     return this.outputStream;
/*      */   }
/*      */ 
/*      */   public void setOutputStream(OutputStream outputStream)
/*      */   {
/*  449 */     checkRunning();
/*  450 */     this.outputStream = outputStream;
/*      */   }
/*      */ 
/*      */   public String getEncoding()
/*      */   {
/*  459 */     return this.encoding;
/*      */   }
/*      */ 
/*      */   public void setEncoding(String encoding)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  469 */     checkRunning();
/*      */ 
/*  471 */     if ((encoding == null) || ("".equals(encoding.trim()))) {
/*  472 */       throw new UnsupportedEncodingException("Encoding not specified.");
/*      */     }
/*  474 */     String enc = encoding.trim();
/*  475 */     SortedMap charsets = Charset.availableCharsets();
/*  476 */     for (Iterator iter = charsets.keySet().iterator(); iter.hasNext(); ) {
/*  477 */       Charset charset = (Charset)charsets.get(iter.next());
/*  478 */       String name = charset.name();
/*  479 */       if (enc.equals(name)) {
/*  480 */         this.encoding = enc;
/*  481 */         return;
/*      */       }
/*      */ 
/*  484 */       for (aliases = charset.aliases().iterator(); aliases.hasNext(); ) {
/*  485 */         String alias = (String)aliases.next();
/*  486 */         if (enc.equals(alias)) {
/*  487 */           this.encoding = enc;
/*      */           return;
/*      */         }
/*      */       }
/*      */     }
/*      */     Iterator aliases;
/*  492 */     throw new UnsupportedEncodingException("Unsupported encoding: " + enc);
/*      */   }
/*      */ 
/*      */   public void setFilename(String filename)
/*      */     throws IllegalArgumentException
/*      */   {
/*  504 */     checkRunning();
/*      */ 
/*  506 */     if (filename == null) {
/*  507 */       throw new IllegalArgumentException("Invalid filename");
/*      */     }
/*      */ 
/*  510 */     for (int i = 0; i < filename.length(); i++) {
/*  511 */       char ch = filename.charAt(i);
/*  512 */       if (((ch < '0') || (ch > '9')) && ((ch < 'A') || (ch > 'Z')) && ((ch < 'a') || (ch > 'z')) && (ch != '_') && (ch != '-') && (ch != '.'))
/*      */       {
/*  515 */         throw new IllegalArgumentException("Invalid filename");
/*      */       }
/*      */     }
/*      */ 
/*  519 */     if (filename.indexOf("..") > -1)
/*  520 */       throw new IllegalArgumentException("Invalid filename");
/*      */   }
/*      */ 
/*      */   public String getFilename()
/*      */   {
/*  531 */     return this.exportFile.getName();
/*      */   }
/*      */ 
/*      */   public int getTaskMaximum() {
/*  535 */     return this.taskMaximum;
/*      */   }
/*      */ 
/*      */   public int getTaskValue() {
/*  539 */     return this.taskValue;
/*      */   }
/*      */ 
/*      */   public Collection getErrors()
/*      */   {
/*  548 */     return Collections.unmodifiableCollection(this.errors);
/*      */   }
/*      */ 
/*      */   public void doRun()
/*      */   {
/*  555 */     Log.debug("Starting XML data export process...");
/*      */ 
/*  558 */     ZipOutputStream zout = null;
/*  559 */     OutputStream out = this.outputStream != null ? this.outputStream : null;
/*      */     try
/*      */     {
/*  562 */       initTaskCount();
/*      */ 
/*  564 */       if (out == null)
/*      */         try {
/*  566 */           out = new BufferedOutputStream(new FileOutputStream(this.exportFile), this.writeBuffer);
/*      */         } catch (Exception e) {
/*  570 */           this.errors.add(new Exception("Failed when creating output file for XML data.", e));
/*      */ 
/*  697 */           Log.debug("Finished XML data export process. Errors? " + (this.errors.size() > 0));
/*      */           return;
/*      */         }
/*      */       try {
/*  576 */         zout = new ZipOutputStream(out);
/*  577 */         ZipEntry entry = new ZipEntry("export.xml");
/*  578 */         zout.putNextEntry(entry);
/*  579 */         out = zout;
/*      */       } catch (Exception e) { this.errors.add(new Exception("Failed to create ZIP output.", e));
/*      */ 
/*  697 */         Log.debug("Finished XML data export process. Errors? " + (this.errors.size() > 0));
/*      */         return;
/*      */       }
/*  587 */       out.write(getHeaderXML().getBytes(this.encoding));
/*      */ 
/*  589 */       if (this.exportJivePropertiesEnabled)
/*      */       {
/*  591 */         exportJiveProperties(out);
/*  592 */         this.taskValue += 1;
/*      */       }
/*      */ 
/*  596 */       if (this.exportUsersEnabled) {
/*  597 */         out.write(indent().getBytes(this.encoding));
/*  598 */         out.write("<UserList>\n".getBytes(this.encoding));
/*  599 */         this.indent += 1;
/*  600 */         exportUsers(out);
/*  601 */         this.indent -= 1;
/*  602 */         out.write(indent().getBytes(this.encoding));
/*  603 */         out.write("</UserList>\n".getBytes(this.encoding));
/*  604 */         this.taskValue += 1;
/*      */       }
/*      */ 
/*  608 */       if ((this.exportGroupsEnabled) && (this.factory.getGroupManager().getGroupCount() > 0)) {
/*  609 */         out.write(indent().getBytes(this.encoding));
/*  610 */         out.write("<GroupList>\n".getBytes(this.encoding));
/*  611 */         this.indent += 1;
/*  612 */         exportGroups(out);
/*  613 */         this.indent -= 1;
/*  614 */         out.write(indent().getBytes(this.encoding));
/*  615 */         out.write("</GroupList>\n".getBytes(this.encoding));
/*  616 */         this.taskValue += 1;
/*      */       }
/*      */ 
/*  620 */       if (this.exportForumsEnabled)
/*      */       {
/*  623 */         exportForumCategories(out);
/*  624 */         this.taskValue += 1;
/*      */       }
/*      */ 
/*  628 */       if (this.exportPrivateMessagesEnabled) {
/*  629 */         exportUserPrivateMessages(out);
/*  630 */         this.taskValue += 1;
/*      */       }
/*      */ 
/*  633 */       if (this.exportAnnouncementsEnabled) {
/*  634 */         exportAnnouncements(out, null);
/*  635 */         this.taskValue += 1;
/*      */       }
/*      */ 
/*  638 */       if (this.exportPollsEnabled) {
/*  639 */         exportPolls(out, 17, -1L);
/*  640 */         this.taskValue += 1;
/*      */       }
/*      */ 
/*  644 */       if (this.exportPermsEnabled) {
/*  645 */         out.write(getPermissionsXML().getBytes(this.encoding));
/*  646 */         this.taskValue += 1;
/*      */       }
/*      */       else
/*      */       {
/*  651 */         out.write(getAdminPermXML().getBytes(this.encoding));
/*  652 */         this.taskValue += 1;
/*      */       }
/*      */ 
/*  656 */       this.indent -= 1;
/*  657 */       out.write("</Jive>".getBytes(this.encoding));
/*      */ 
/*  660 */       zout.closeEntry();
/*      */ 
/*  664 */       for (Iterator i = this.exportedAttachments.iterator(); i.hasNext(); ) {
/*  665 */         Attachment attachment = (Attachment)i.next();
/*      */         try
/*      */         {
/*  668 */           ZipEntry zipEntry = new ZipEntry("attachments/" + attachment.getID() + ".bin");
/*  669 */           zout.putNextEntry(zipEntry);
/*      */ 
/*  671 */           InputStream in = attachment.getData();
/*      */ 
/*  674 */           byte[] buf = new byte[131072];
/*      */           int len;
/*  676 */           while ((len = in.read(buf)) != -1) {
/*  677 */             zout.write(buf, 0, len);
/*      */           }
/*      */ 
/*  680 */           in.close();
/*  681 */           zout.closeEntry();
/*      */         }
/*      */         catch (IOException ioe) {
/*  684 */           Log.error("trouble adding " + attachment + " to the zip ", ioe);
/*      */         }
/*      */       }
/*      */ 
/*  688 */       zout.flush();
/*  689 */       zout.close();
/*      */     }
/*      */     catch (Exception e) {
/*  692 */       Log.error(e);
/*  693 */       this.errors.add(new Exception("Error occurred when generating Jive Forums XML data.", e));
/*      */     }
/*      */     finally
/*      */     {
/*  697 */       Log.debug("Finished XML data export process. Errors? " + (this.errors.size() > 0));
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkRunning() {
/*  702 */     if (isRunning())
/*  703 */       throw new IllegalStateException("Can not set properties when export is running.");
/*      */   }
/*      */ 
/*      */   private String getHeaderXML()
/*      */   {
/*  708 */     StringBuffer buf = new StringBuffer(200);
/*  709 */     buf.append("<?xml version=\"1.0\" encoding=\"" + this.encoding + "\"?>\n");
/*  710 */     buf.append("<Jive xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"http://www.jivesoftware.com/products/forums/jiveforums.xsd\" ");
/*      */ 
/*  714 */     buf.append("xmlversion=\"").append("4.0").append("\" exportDate=\"" + this.dateFormatter.format(new Date()) + "\">\n");
/*      */ 
/*  717 */     this.indent += 1;
/*  718 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   private void exportJiveProperties(OutputStream out) throws IOException {
/*  722 */     out.write(indent().getBytes(this.encoding));
/*  723 */     out.write("<JivePropertyList>\n".getBytes(this.encoding));
/*  724 */     this.indent += 1;
/*  725 */     for (Iterator i = JiveGlobals.getJivePropertyNames().iterator(); i.hasNext(); ) {
/*  726 */       String name = (String)i.next();
/*  727 */       String value = JiveGlobals.getJiveProperty(name);
/*      */ 
/*  729 */       StringBuffer buff = new StringBuffer();
/*      */ 
/*  731 */       buff.append(indent()).append("<Property name=\"").append(StringUtils.escapeForXML(name)).append("\" value=\"").append(StringUtils.escapeForXML(value)).append("\" />\n");
/*      */ 
/*  738 */       out.write(buff.toString().getBytes(this.encoding));
/*      */     }
/*      */ 
/*  741 */     this.indent -= 1;
/*  742 */     out.write(indent().getBytes(this.encoding));
/*  743 */     out.write("</JivePropertyList>\n".getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private String getPermissionsXML() throws UnauthorizedException {
/*  747 */     StringBuffer buf = new StringBuffer(1024);
/*      */ 
/*  750 */     exportPermissions(this.factory.getPermissionsManager(), buf);
/*      */ 
/*  752 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   private String getAdminPermXML() throws UnauthorizedException {
/*  756 */     boolean hasPerms = false;
/*  757 */     StringBuffer buf = new StringBuffer(1024);
/*  758 */     PermissionsManager permManager = this.factory.getPermissionsManager();
/*  759 */     buf.append(indent()).append("<UserPermissionList>");
/*  760 */     this.indent += 1;
/*  761 */     for (int i = 0; i < PERM_NAMES.length; i++) {
/*  762 */       Iterator userList = permManager.usersWithPermission(PermissionType.ADDITIVE, 576460752303423488L);
/*      */ 
/*  764 */       while (userList.hasNext()) {
/*  765 */         User user = (User)userList.next();
/*  766 */         if (user != null) {
/*  767 */           hasPerms = true;
/*  768 */           buf.append(indent()).append("<UserPermission usertype=\"USER\" username=\"");
/*  769 */           buf.append(StringUtils.escapeForXML(user.getUsername()));
/*  770 */           buf.append("\" permissionType=\"ADDITIVE\" permission=\"").append(PERM_NAMES[i]).append("\"/>\n");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  776 */       userList = permManager.usersWithPermission(PermissionType.NEGATIVE, 576460752303423488L);
/*      */ 
/*  778 */       while (userList.hasNext()) {
/*  779 */         User user = (User)userList.next();
/*  780 */         if (user != null) {
/*  781 */           hasPerms = true;
/*  782 */           buf.append(indent()).append("<UserPermission usertype=\"USER\" username=\"");
/*  783 */           buf.append(StringUtils.escapeForXML(user.getUsername()));
/*  784 */           buf.append("\" permissionType=\"NEGATIVE\" permission=\"").append(PERM_NAMES[i]).append("\"/>\n");
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  789 */     this.indent -= 1;
/*  790 */     buf.append(indent()).append("</UserPermissionList>\n");
/*      */ 
/*  792 */     if (hasPerms) {
/*  793 */       return buf.toString();
/*      */     }
/*      */ 
/*  796 */     return "";
/*      */   }
/*      */ 
/*      */   private void exportThread(OutputStream out, ForumThread thread) throws Exception
/*      */   {
/*  801 */     StringBuffer buf = new StringBuffer(4096);
/*  802 */     buf.append(indent());
/*  803 */     if (this.exportIDsEnabled) {
/*  804 */       buf.append("<Thread id=\"").append(thread.getID()).append("\">\n");
/*      */     }
/*      */     else {
/*  807 */       buf.append("<Thread>\n");
/*      */     }
/*  809 */     this.indent += 1;
/*  810 */     buf.append(indent()).append("<CreationDate>");
/*  811 */     buf.append(this.dateFormatter.format(thread.getCreationDate()));
/*  812 */     buf.append("</CreationDate>\n").append(indent()).append("<ModifiedDate>");
/*  813 */     buf.append(this.dateFormatter.format(thread.getModificationDate()));
/*  814 */     buf.append("</ModifiedDate>\n");
/*      */ 
/*  816 */     Iterator propertyNames = thread.getPropertyNames();
/*  817 */     if (propertyNames.hasNext()) {
/*  818 */       buf.append(indent()).append("<PropertyList>\n");
/*  819 */       this.indent += 1;
/*  820 */       while (propertyNames.hasNext()) {
/*  821 */         String propName = StringUtils.escapeForXML((String)propertyNames.next());
/*  822 */         String propValue = StringUtils.escapeForXML(thread.getProperty(propName));
/*  823 */         if (propValue != null) {
/*  824 */           propName = StringUtils.escapeForXML(propName);
/*  825 */           buf.append(indent()).append("<Property name=\"").append(propName).append("\" ");
/*  826 */           buf.append("value=\"").append(propValue).append("\"/>\n");
/*      */         }
/*      */       }
/*  829 */       this.indent -= 1;
/*  830 */       buf.append(indent()).append("</PropertyList>\n");
/*      */     }
/*      */ 
/*  833 */     out.write(buf.toString().getBytes(this.encoding));
/*      */ 
/*  836 */     outputMessages(thread.getRootMessage(), out);
/*      */ 
/*  838 */     if (this.exportPollsEnabled) {
/*  839 */       exportPolls(out, 1, thread.getID());
/*      */     }
/*      */ 
/*  842 */     this.indent -= 1;
/*  843 */     out.write(indent().getBytes(this.encoding));
/*  844 */     out.write("</Thread>\n".getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private void outputMessages(ForumMessage message, OutputStream out) throws Exception {
/*  848 */     StringBuffer buf = new StringBuffer();
/*      */ 
/*  850 */     buf.append(indent());
/*  851 */     if (this.exportIDsEnabled) {
/*  852 */       buf.append("<Message id=\"").append(message.getID()).append("\">\n");
/*      */     }
/*      */     else {
/*  855 */       buf.append("<Message>\n");
/*      */     }
/*  857 */     this.indent += 1;
/*  858 */     buf.append(indent()).append("<Subject>");
/*  859 */     buf.append(StringUtils.escapeForXML(message.getUnfilteredSubject()));
/*  860 */     buf.append("</Subject>\n").append(indent()).append("<Body>");
/*  861 */     buf.append(StringUtils.escapeForXML(message.getUnfilteredBody()));
/*  862 */     buf.append("</Body>\n");
/*  863 */     if ((!message.isAnonymous()) && (message.getUser() != null)) {
/*  864 */       buf.append(indent()).append("<Username>");
/*  865 */       buf.append(StringUtils.escapeForXML(message.getUser().getUsername()));
/*  866 */       buf.append("</Username>\n");
/*      */     }
/*  868 */     buf.append(indent()).append("<CreationDate>");
/*  869 */     buf.append(this.dateFormatter.format(message.getCreationDate()));
/*  870 */     buf.append("</CreationDate>\n").append(indent()).append("<ModifiedDate>");
/*  871 */     buf.append(this.dateFormatter.format(message.getModificationDate()));
/*  872 */     buf.append("</ModifiedDate>\n");
/*      */ 
/*  874 */     Iterator propertyNames = message.getPropertyNames();
/*  875 */     if (propertyNames.hasNext()) {
/*  876 */       buf.append(indent()).append("<PropertyList>\n");
/*  877 */       this.indent += 1;
/*  878 */       while (propertyNames.hasNext()) {
/*  879 */         String propName = (String)propertyNames.next();
/*  880 */         String propValue = StringUtils.escapeForXML(message.getUnfilteredProperty(propName));
/*      */ 
/*  882 */         if (propValue != null) {
/*  883 */           propName = StringUtils.escapeForXML(propName);
/*  884 */           buf.append(indent()).append("<Property name=\"").append(propName).append("\" ");
/*  885 */           buf.append("value=\"").append(propValue).append("\"/>\n");
/*      */         }
/*      */       }
/*  888 */       this.indent -= 1;
/*  889 */       buf.append(indent()).append("</PropertyList>\n");
/*      */     }
/*      */ 
/*  892 */     out.write(buf.toString().getBytes(this.encoding));
/*      */ 
/*  895 */     TreeWalker walker = message.getForumThread().getTreeWalker();
/*  896 */     int childCount = walker.getChildCount(message);
/*  897 */     if (childCount > 0) {
/*  898 */       out.write(indent().getBytes(this.encoding));
/*  899 */       out.write("<MessageList>\n".getBytes(this.encoding));
/*  900 */       this.indent += 1;
/*  901 */       for (int i = 0; i < childCount; i++) {
/*      */         try {
/*  903 */           ForumMessage childMessage = walker.getChild(message, i);
/*  904 */           outputMessages(childMessage, out);
/*      */         }
/*      */         catch (ForumMessageNotFoundException fmnfe) {
/*  907 */           Log.error(fmnfe);
/*      */         }
/*      */         catch (Exception e) {
/*  910 */           Log.error(e);
/*      */         }
/*      */       }
/*  913 */       this.indent -= 1;
/*  914 */       out.write(indent().getBytes(this.encoding));
/*  915 */       out.write("</MessageList>\n".getBytes(this.encoding));
/*      */     }
/*      */ 
/*  918 */     if (this.exportAttachmentsEnabled) {
/*  919 */       out.write(indent().getBytes(this.encoding));
/*  920 */       out.write("<AttachmentList>\n".getBytes(this.encoding));
/*      */ 
/*  923 */       for (Iterator i = message.getAttachments(); i.hasNext(); ) {
/*  924 */         Attachment attachment = (Attachment)i.next();
/*  925 */         exportAttachment(out, attachment);
/*      */       }
/*      */ 
/*  928 */       out.write(indent().getBytes(this.encoding));
/*  929 */       out.write("</AttachmentList>\n".getBytes(this.encoding));
/*      */     }
/*      */ 
/*  933 */     this.indent -= 1;
/*  934 */     out.write(indent().getBytes(this.encoding));
/*  935 */     out.write("</Message>\n".getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private String getUserXML(User user) throws UnauthorizedException {
/*  939 */     StringBuffer buf = new StringBuffer(512);
/*  940 */     buf.append(indent());
/*  941 */     buf.append("<User id=\"").append(user.getID()).append("\">\n");
/*      */ 
/*  943 */     this.indent += 1;
/*  944 */     buf.append(indent()).append("<Username>");
/*  945 */     buf.append(StringUtils.escapeForXML(user.getUsername()));
/*  946 */     buf.append("</Username>\n").append(indent()).append("<Password>");
/*  947 */     buf.append(StringUtils.escapeForXML(user.getPasswordHash()));
/*  948 */     boolean emailVisible = user.isEmailVisible();
/*  949 */     boolean nameVisible = user.isNameVisible();
/*  950 */     String name = user.getName();
/*  951 */     buf.append("</Password>\n").append(indent());
/*  952 */     buf.append("<Email visible=\"" + emailVisible + "\">");
/*  953 */     buf.append(StringUtils.escapeForXML(user.getEmail()));
/*  954 */     buf.append("</Email>\n");
/*  955 */     if (name != null) {
/*  956 */       buf.append(indent()).append("<Name visible=\"" + nameVisible + "\">");
/*  957 */       buf.append(StringUtils.escapeForXML(name));
/*  958 */       buf.append("</Name>\n");
/*      */     }
/*      */ 
/*  961 */     buf.append(indent()).append("<CreationDate>");
/*  962 */     buf.append(this.dateFormatter.format(user.getCreationDate())).append("</CreationDate>\n");
/*  963 */     buf.append(indent()).append("<ModifiedDate>");
/*  964 */     buf.append(this.dateFormatter.format(user.getModificationDate())).append("</ModifiedDate>\n");
/*      */ 
/*  966 */     Iterator userProps = user.getPropertyNames();
/*  967 */     if (userProps.hasNext()) {
/*  968 */       buf.append(indent()).append("<PropertyList>\n");
/*  969 */       this.indent += 1;
/*  970 */       while (userProps.hasNext()) {
/*  971 */         String propName = (String)userProps.next();
/*  972 */         String propValue = StringUtils.escapeForXML(user.getProperty(propName));
/*  973 */         if (propValue != null)
/*      */         {
/*  975 */           propName = StringUtils.escapeForXML(propName);
/*  976 */           buf.append(indent()).append("<Property name=\"").append(propName).append("\" ");
/*  977 */           buf.append("value=\"").append(propValue).append("\"/>\n");
/*      */         }
/*      */       }
/*  980 */       this.indent -= 1;
/*  981 */       buf.append(indent()).append("</PropertyList>\n");
/*      */     }
/*  983 */     this.indent -= 1;
/*  984 */     buf.append(indent()).append("</User>\n");
/*  985 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   private String getGroupXML(Group group) {
/*  989 */     StringBuffer buf = new StringBuffer(512);
/*  990 */     buf.append(indent());
/*  991 */     if (this.exportIDsEnabled) {
/*  992 */       buf.append("<Group id=\"").append(group.getID()).append("\">\n");
/*      */     }
/*      */     else {
/*  995 */       buf.append("<Group>\n");
/*      */     }
/*  997 */     this.indent += 1;
/*  998 */     buf.append(indent()).append("<Name>");
/*  999 */     buf.append(StringUtils.escapeForXML(group.getName()));
/* 1000 */     buf.append("</Name>\n");
/* 1001 */     if (group.getDescription() != null) {
/* 1002 */       buf.append(indent()).append("<Description>");
/* 1003 */       buf.append(StringUtils.escapeForXML(group.getDescription()));
/* 1004 */       buf.append("</Description>\n");
/*      */     }
/*      */     else {
/* 1007 */       buf.append(indent()).append("<Description />\n");
/*      */     }
/*      */ 
/* 1011 */     buf.append(indent()).append("<CreationDate>");
/* 1012 */     buf.append(this.dateFormatter.format(group.getCreationDate())).append("</CreationDate>\n");
/* 1013 */     buf.append(indent()).append("<ModifiedDate>");
/* 1014 */     buf.append(this.dateFormatter.format(group.getModificationDate())).append("</ModifiedDate>\n");
/*      */ 
/* 1016 */     Iterator groupProps = group.getPropertyNames();
/* 1017 */     if (groupProps.hasNext()) {
/* 1018 */       buf.append(indent()).append("<PropertyList>\n");
/* 1019 */       this.indent += 1;
/* 1020 */       while (groupProps.hasNext()) {
/* 1021 */         String propName = (String)groupProps.next();
/* 1022 */         String propValue = StringUtils.escapeForXML(group.getProperty(propName));
/* 1023 */         if (propValue != null)
/*      */         {
/* 1025 */           propName = StringUtils.escapeForXML(propName);
/* 1026 */           buf.append(indent()).append("<Property name=\"").append(propName).append("\" ");
/* 1027 */           buf.append("value=\"").append(propValue).append("\"/>\n");
/*      */         }
/*      */       }
/* 1030 */       this.indent -= 1;
/* 1031 */       buf.append(indent()).append("</PropertyList>\n");
/*      */     }
/*      */ 
/* 1034 */     Iterator admins = group.getAdministrators();
/* 1035 */     if (admins.hasNext()) {
/* 1036 */       buf.append(indent()).append("<AdministratorList>\n");
/* 1037 */       this.indent += 1;
/* 1038 */       while (admins.hasNext()) {
/* 1039 */         String username = StringUtils.escapeForXML(((User)admins.next()).getUsername());
/* 1040 */         buf.append(indent()).append("<Username>").append(username).append("</Username>\n");
/*      */       }
/* 1042 */       this.indent -= 1;
/* 1043 */       buf.append(indent()).append("</AdministratorList>\n");
/*      */     }
/*      */ 
/* 1046 */     Iterator members = group.getMembers();
/* 1047 */     if (members.hasNext()) {
/* 1048 */       buf.append(indent()).append("<MemberList>\n");
/* 1049 */       this.indent += 1;
/* 1050 */       while (members.hasNext()) {
/* 1051 */         String username = StringUtils.escapeForXML(((User)members.next()).getUsername());
/* 1052 */         buf.append(indent()).append("<Username>").append(username).append("</Username>\n");
/*      */       }
/* 1054 */       this.indent -= 1;
/* 1055 */       buf.append(indent()).append("</MemberList>\n");
/*      */     }
/* 1057 */     this.indent -= 1;
/* 1058 */     buf.append(indent()).append("</Group>\n");
/* 1059 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   private void exportUsers(OutputStream out) throws IOException, UnauthorizedException {
/* 1063 */     UserManager userManager = this.factory.getUserManager();
/* 1064 */     for (Iterator iter = userManager.users(); iter.hasNext(); ) {
/* 1065 */       User user = (User)iter.next();
/* 1066 */       out.write(getUserXML(user).getBytes(this.encoding));
/*      */     }
/*      */   }
/*      */ 
/*      */   private void exportGroups(OutputStream out) throws IOException {
/* 1071 */     GroupManager groupManager = this.factory.getGroupManager();
/* 1072 */     for (Iterator iter = groupManager.getGroups(); iter.hasNext(); ) {
/* 1073 */       Group group = (Group)iter.next();
/* 1074 */       out.write(getGroupXML(group).getBytes(this.encoding));
/*      */     }
/*      */   }
/*      */ 
/*      */   private void exportForumCategories(OutputStream out)
/*      */     throws Exception
/*      */   {
/* 1082 */     ForumCategory rootCategory = this.factory.getRootForumCategory();
/* 1083 */     this.indent += 1;
/* 1084 */     exportForums(rootCategory.getForums(), out);
/* 1085 */     this.indent -= 1;
/*      */ 
/* 1087 */     exportForumCategories(rootCategory.getCategories(), out);
/*      */   }
/*      */ 
/*      */   private void exportForumCategories(Iterator categories, OutputStream out) throws Exception
/*      */   {
/* 1092 */     out.write(indent().getBytes(this.encoding));
/* 1093 */     out.write("<CategoryList>\n".getBytes(this.encoding));
/* 1094 */     this.indent += 1;
/*      */ 
/* 1096 */     while (categories.hasNext()) {
/* 1097 */       ForumCategory category = (ForumCategory)categories.next();
/* 1098 */       exportForumCategory(category, out);
/*      */     }
/* 1100 */     this.indent -= 1;
/* 1101 */     out.write(indent().getBytes(this.encoding));
/* 1102 */     out.write("</CategoryList>\n".getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private void exportPermissions(PermissionsManager permManager, StringBuffer buf)
/*      */   {
/* 1114 */     if (this.exportPermsEnabled) {
/* 1115 */       StringBuffer permBuf = new StringBuffer();
/* 1116 */       boolean hasPerms = false;
/*      */ 
/* 1118 */       permBuf.append(indent()).append("<PermissionList>\n");
/* 1119 */       this.indent += 1;
/*      */ 
/* 1121 */       permBuf.append(indent()).append("<UserPermissionList>\n");
/* 1122 */       this.indent += 1;
/* 1123 */       for (int i = 0; i < PERM_NAMES.length; i++) {
/* 1124 */         Iterator userList = permManager.usersWithPermission(PermissionType.ADDITIVE, PERM_TYPES[i]);
/*      */ 
/* 1126 */         while (userList.hasNext()) {
/* 1127 */           User user = (User)userList.next();
/* 1128 */           if (user != null) {
/* 1129 */             hasPerms = true;
/* 1130 */             permBuf.append(indent());
/* 1131 */             permBuf.append("<UserPermission usertype=\"USER\" username=\"");
/* 1132 */             permBuf.append(StringUtils.escapeForXML(user.getUsername()));
/* 1133 */             permBuf.append("\" permissionType=\"ADDITIVE\" permission=\"" + PERM_NAMES[i] + "\"/>\n");
/*      */           }
/*      */         }
/*      */ 
/* 1137 */         userList = permManager.usersWithPermission(PermissionType.NEGATIVE, PERM_TYPES[i]);
/*      */ 
/* 1139 */         while (userList.hasNext()) {
/* 1140 */           User user = (User)userList.next();
/* 1141 */           if (user != null) {
/* 1142 */             hasPerms = true;
/* 1143 */             permBuf.append(indent());
/* 1144 */             permBuf.append("<UserPermission usertype=\"USER\" username=\"");
/* 1145 */             permBuf.append(StringUtils.escapeForXML(user.getUsername()));
/* 1146 */             permBuf.append("\" permissionType=\"NEGATIVE\" permission=\"" + PERM_NAMES[i] + "\"/>\n");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1151 */         if (permManager.anonymousUserHasPermission(PermissionType.ADDITIVE, PERM_TYPES[i]))
/*      */         {
/* 1153 */           hasPerms = true;
/* 1154 */           permBuf.append(indent()).append("<UserPermission usertype=\"ANONYMOUS\"");
/* 1155 */           permBuf.append(" permissionType=\"ADDITIVE\" permission=\"" + PERM_NAMES[i] + "\"/>\n");
/*      */         }
/*      */ 
/* 1158 */         if (permManager.anonymousUserHasPermission(PermissionType.NEGATIVE, PERM_TYPES[i]))
/*      */         {
/* 1160 */           hasPerms = true;
/* 1161 */           permBuf.append(indent()).append("<UserPermission usertype=\"ANONYMOUS\"");
/* 1162 */           permBuf.append(" permissionType=\"NEGATIVE\" permission=\"" + PERM_NAMES[i] + "\"/>\n");
/*      */         }
/*      */ 
/* 1166 */         if (permManager.registeredUserHasPermission(PermissionType.ADDITIVE, PERM_TYPES[i]))
/*      */         {
/* 1168 */           hasPerms = true;
/* 1169 */           permBuf.append(indent()).append("<UserPermission usertype=\"REGISTERED_USERS\"");
/*      */ 
/* 1171 */           permBuf.append(" permissionType=\"ADDITIVE\" permission=\"" + PERM_NAMES[i] + "\"/>\n");
/*      */         }
/*      */ 
/* 1174 */         if (permManager.registeredUserHasPermission(PermissionType.NEGATIVE, PERM_TYPES[i]))
/*      */         {
/* 1176 */           hasPerms = true;
/* 1177 */           permBuf.append(indent()).append("<UserPermission usertype=\"REGISTERED_USERS\"");
/*      */ 
/* 1179 */           permBuf.append(" permissionType=\"NEGATIVE\" permission=\"" + PERM_NAMES[i] + "\"/>\n");
/*      */         }
/*      */       }
/*      */ 
/* 1183 */       this.indent -= 1;
/* 1184 */       permBuf.append(indent()).append("</UserPermissionList>\n");
/*      */ 
/* 1187 */       permBuf.append(indent()).append("<GroupPermissionList>\n");
/* 1188 */       this.indent += 1;
/* 1189 */       for (int i = 0; i < PERM_NAMES.length; i++) {
/* 1190 */         Iterator groupList = permManager.groupsWithPermission(PermissionType.ADDITIVE, PERM_TYPES[i]);
/*      */ 
/* 1192 */         while (groupList.hasNext()) {
/* 1193 */           Group group = (Group)groupList.next();
/* 1194 */           if (group != null) {
/* 1195 */             hasPerms = true;
/* 1196 */             permBuf.append(indent());
/* 1197 */             permBuf.append("<GroupPermission groupname=\"");
/* 1198 */             permBuf.append(StringUtils.escapeForXML(group.getName())).append("\"");
/* 1199 */             permBuf.append(" permissionType=\"ADDITIVE\" permission=\"").append(PERM_NAMES[i]).append("\"/>\n");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1204 */         groupList = permManager.groupsWithPermission(PermissionType.NEGATIVE, PERM_TYPES[i]);
/*      */ 
/* 1206 */         while (groupList.hasNext()) {
/* 1207 */           Group group = (Group)groupList.next();
/* 1208 */           if (group != null) {
/* 1209 */             hasPerms = true;
/* 1210 */             permBuf.append(indent());
/* 1211 */             permBuf.append("<GroupPermission groupname=\"");
/* 1212 */             permBuf.append(StringUtils.escapeForXML(group.getName())).append("\"");
/* 1213 */             permBuf.append(" permissionType=\"NEGATIVE\" permission=\"").append(PERM_NAMES[i]).append("\"/>\n");
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1219 */       this.indent -= 1;
/* 1220 */       permBuf.append(indent()).append("</GroupPermissionList>\n");
/*      */ 
/* 1222 */       this.indent -= 1;
/* 1223 */       permBuf.append(indent()).append("</PermissionList>\n");
/*      */ 
/* 1226 */       if (hasPerms)
/* 1227 */         buf.append(permBuf);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void exportForumCategory(ForumCategory category, OutputStream out)
/*      */     throws Exception
/*      */   {
/* 1235 */     if ((this.exportedCategories.size() == 0) || (this.exportedCategories.contains(new Long(category.getID()))))
/*      */     {
/* 1238 */       StringBuffer buff = new StringBuffer();
/* 1239 */       buff.append(indent()).append("<Category ");
/* 1240 */       buff.append(" id=\"").append(category.getID()).append("\" >\n");
/*      */ 
/* 1242 */       this.indent += 1;
/*      */ 
/* 1245 */       buff.append(indent()).append("<Name>").append(StringUtils.escapeForXML(category.getName())).append("</Name>\n");
/*      */ 
/* 1250 */       if (category.getDescription() != null) {
/* 1251 */         buff.append(indent()).append("<Description>").append(StringUtils.escapeForXML(category.getDescription())).append("</Description>\n");
/*      */       }
/*      */       else
/*      */       {
/* 1257 */         buff.append(indent()).append("<Description />\n");
/*      */       }
/*      */ 
/* 1260 */       buff.append(indent()).append("<CreationDate>").append(DEFAULT_FILE_DATE_FORMAT.format(category.getCreationDate())).append("</CreationDate>\n");
/*      */ 
/* 1265 */       buff.append(indent()).append("<ModifiedDate>").append(DEFAULT_FILE_DATE_FORMAT.format(category.getModificationDate())).append("</ModifiedDate>\n");
/*      */ 
/* 1271 */       exportPermissions(category.getPermissionsManager(), buff);
/*      */ 
/* 1274 */       buff.append(indent()).append("<PropertyList>\n");
/* 1275 */       this.indent += 1;
/* 1276 */       for (Iterator i = category.getPropertyNames(); i.hasNext(); ) {
/* 1277 */         String name = StringUtils.escapeForXML((String)i.next());
/* 1278 */         String value = StringUtils.escapeForXML(category.getProperty(name));
/* 1279 */         buff.append(indent());
/* 1280 */         buff.append("<Property name=\"").append(name).append("\" value=\"").append(value).append("\" />\n");
/*      */       }
/*      */ 
/* 1286 */       this.indent -= 1;
/* 1287 */       buff.append(indent()).append("</PropertyList>\n");
/*      */ 
/* 1289 */       out.write(buff.toString().getBytes(this.encoding));
/*      */ 
/* 1291 */       exportForums(category.getForums(), out);
/*      */ 
/* 1293 */       exportForumCategories(category.getCategories(), out);
/*      */ 
/* 1295 */       if (this.exportAnnouncementsEnabled) {
/* 1296 */         exportAnnouncements(out, category);
/*      */       }
/*      */ 
/* 1299 */       if (this.exportPollsEnabled) {
/* 1300 */         exportPolls(out, 14, category.getID());
/*      */       }
/*      */ 
/* 1303 */       this.indent -= 1;
/*      */ 
/* 1305 */       out.write(indent().getBytes(this.encoding));
/* 1306 */       out.write("</Category>\n".getBytes(this.encoding));
/*      */     }
/*      */   }
/*      */ 
/*      */   private void exportForums(Iterator forums, OutputStream out) throws Exception {
/* 1311 */     out.write(indent().getBytes(this.encoding));
/* 1312 */     out.write("<ForumList>\n".getBytes(this.encoding));
/* 1313 */     this.indent += 1;
/* 1314 */     while (forums.hasNext()) {
/* 1315 */       Forum forum = (Forum)forums.next();
/* 1316 */       exportForum(forum, out);
/*      */     }
/* 1318 */     this.indent -= 1;
/* 1319 */     out.write(indent().getBytes(this.encoding));
/* 1320 */     out.write("</ForumList>\n".getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private void exportForum(Forum forum, OutputStream out) throws Exception
/*      */   {
/* 1325 */     StringBuffer buf = new StringBuffer(4096);
/*      */ 
/* 1329 */     if ((this.exportedForums.size() == 0) || (this.exportedForums.contains(new Long(forum.getID())))) {
/* 1330 */       String name = forum.getName();
/* 1331 */       buf.append(indent());
/* 1332 */       if (this.exportIDsEnabled) {
/* 1333 */         buf.append("<Forum id=\"").append(forum.getID()).append("\">\n");
/*      */       }
/*      */       else {
/* 1336 */         buf.append("<Forum>\n");
/*      */       }
/* 1338 */       this.indent += 1;
/* 1339 */       buf.append(indent()).append("<Name>");
/* 1340 */       buf.append(StringUtils.escapeForXML(name));
/* 1341 */       buf.append("</Name>\n");
/* 1342 */       if (forum.getDescription() != null) {
/* 1343 */         buf.append(indent()).append("<Description>");
/* 1344 */         buf.append(StringUtils.escapeForXML(forum.getDescription()));
/* 1345 */         buf.append("</Description>\n");
/*      */       }
/*      */       else {
/* 1348 */         buf.append(indent()).append("<Description />\n");
/*      */       }
/* 1350 */       buf.append(indent()).append("<CreationDate>");
/* 1351 */       buf.append(this.dateFormatter.format(forum.getCreationDate()));
/* 1352 */       buf.append("</CreationDate>\n");
/* 1353 */       buf.append(indent()).append("<ModifiedDate>");
/* 1354 */       buf.append(this.dateFormatter.format(forum.getModificationDate()));
/* 1355 */       buf.append("</ModifiedDate>\n");
/*      */ 
/* 1358 */       exportPermissions(forum.getPermissionsManager(), buf);
/*      */ 
/* 1361 */       Iterator propertyNames = forum.getPropertyNames();
/* 1362 */       if (propertyNames.hasNext()) {
/* 1363 */         buf.append(indent()).append("<PropertyList>\n");
/* 1364 */         this.indent += 1;
/* 1365 */         while (propertyNames.hasNext()) {
/* 1366 */           String propName = (String)propertyNames.next();
/* 1367 */           String propValue = StringUtils.escapeForXML(forum.getProperty(propName));
/* 1368 */           if (propValue != null) {
/* 1369 */             propName = StringUtils.escapeForXML(propName);
/* 1370 */             buf.append(indent());
/* 1371 */             buf.append("<Property name=\"").append(propName).append("\" ");
/* 1372 */             buf.append("value=\"").append(propValue).append("\"/>\n");
/*      */           }
/*      */         }
/* 1375 */         this.indent -= 1;
/* 1376 */         buf.append(indent()).append("</PropertyList>\n");
/*      */       }
/*      */ 
/* 1380 */       out.write(buf.toString().getBytes(this.encoding));
/*      */ 
/* 1383 */       if (forum.getThreadCount() > 0) {
/* 1384 */         out.write(indent().getBytes(this.encoding));
/* 1385 */         out.write("<ThreadList>\n".getBytes(this.encoding));
/* 1386 */         this.indent += 1;
/* 1387 */         for (Iterator iter = forum.getThreads(); iter.hasNext(); ) {
/* 1388 */           ForumThread thread = (ForumThread)iter.next();
/* 1389 */           exportThread(out, thread);
/*      */         }
/* 1391 */         this.indent -= 1;
/* 1392 */         out.write(indent().getBytes(this.encoding));
/* 1393 */         out.write("</ThreadList>\n".getBytes(this.encoding));
/*      */       }
/*      */ 
/* 1396 */       if (this.exportAnnouncementsEnabled) {
/* 1397 */         exportAnnouncements(out, forum);
/*      */       }
/*      */ 
/* 1400 */       if (this.exportPollsEnabled) {
/* 1401 */         exportPolls(out, 0, forum.getID());
/*      */       }
/*      */ 
/* 1404 */       this.indent -= 1;
/* 1405 */       out.write(indent().getBytes(this.encoding));
/* 1406 */       out.write("</Forum>\n".getBytes(this.encoding));
/*      */     }
/*      */   }
/*      */ 
/*      */   private void exportUserPrivateMessages(OutputStream out) throws Exception {
/* 1411 */     out.write(indent().getBytes(this.encoding));
/* 1412 */     out.write("<UserPrivateMessageList>\n".getBytes(this.encoding));
/* 1413 */     this.indent += 1;
/*      */ 
/* 1416 */     for (Iterator i = this.factory.getUserManager().users(); i.hasNext(); )
/*      */     {
/* 1418 */       User user = (User)i.next();
/* 1419 */       exportFolders(user, out);
/*      */     }
/*      */ 
/* 1422 */     this.indent -= 1;
/* 1423 */     out.write(indent().getBytes(this.encoding));
/* 1424 */     out.write("</UserPrivateMessageList>\n".getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private void exportFolders(User user, OutputStream out) throws Exception {
/* 1428 */     PrivateMessageManager mgr = this.factory.getPrivateMessageManager();
/*      */ 
/* 1430 */     StringBuffer buffer = new StringBuffer(indent()).append("<FolderList username=\"").append(StringUtils.escapeForXML(user.getUsername())).append("\" >\n");
/*      */ 
/* 1435 */     out.write(buffer.toString().getBytes(this.encoding));
/*      */ 
/* 1437 */     this.indent += 1;
/*      */ 
/* 1439 */     for (Iterator i = mgr.getFolders(user); i.hasNext(); ) {
/* 1440 */       PrivateMessageFolder folder = (PrivateMessageFolder)i.next();
/*      */ 
/* 1442 */       buffer = new StringBuffer(indent()).append("<Folder id=\"").append(folder.getID()).append("\" >\n");
/*      */ 
/* 1447 */       this.indent += 1;
/*      */ 
/* 1449 */       buffer.append(indent()).append("<Name>").append(folder.getName()).append("</Name>\n");
/* 1450 */       out.write(buffer.toString().getBytes(this.encoding));
/*      */ 
/* 1452 */       exportPrivateMessages(folder.getMessages(), out);
/*      */ 
/* 1454 */       this.indent -= 1;
/* 1455 */       out.write(indent().getBytes(this.encoding));
/* 1456 */       out.write("</Folder>\n".getBytes(this.encoding));
/*      */     }
/*      */ 
/* 1459 */     this.indent -= 1;
/* 1460 */     out.write(indent().getBytes(this.encoding));
/* 1461 */     out.write("</FolderList>\n".getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private void exportPrivateMessages(Iterator messages, OutputStream out) throws Exception {
/* 1465 */     out.write(indent().getBytes(this.encoding));
/* 1466 */     out.write("<PrivateMessageList>\n".getBytes(this.encoding));
/* 1467 */     this.indent += 1;
/*      */ 
/* 1469 */     while (messages.hasNext()) {
/* 1470 */       PrivateMessage message = (PrivateMessage)messages.next();
/* 1471 */       exportPrivateMessage(message, out);
/*      */     }
/*      */ 
/* 1474 */     this.indent -= 1;
/* 1475 */     out.write(indent().getBytes(this.encoding));
/* 1476 */     out.write("</PrivateMessageList>\n".getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private void exportPrivateMessage(PrivateMessage msg, OutputStream out) throws Exception {
/* 1480 */     StringBuffer buffer = new StringBuffer(indent()).append("<PrivateMessage id=\"").append(msg.getID()).append("\" >\n");
/*      */ 
/* 1485 */     this.indent += 1;
/*      */ 
/* 1487 */     buffer.append(indent()).append("<Subject>").append(StringUtils.escapeForXML(msg.getSubject())).append("</Subject>\n");
/*      */ 
/* 1492 */     buffer.append(indent()).append("<Body>").append(StringUtils.escapeForXML(msg.getBody())).append("</Body>\n");
/*      */ 
/* 1497 */     if (msg.getSender() != null) {
/* 1498 */       buffer.append(indent()).append("<Sender username=\"").append(StringUtils.escapeForXML(msg.getSender().getUsername())).append("\" />\n");
/*      */     }
/*      */ 
/* 1505 */     if (msg.getRecipient() != null) {
/* 1506 */       buffer.append(indent()).append("<Recipient username=\"").append(StringUtils.escapeForXML(msg.getRecipient().getUsername())).append("\" />\n");
/*      */     }
/*      */ 
/* 1512 */     buffer.append(indent()).append("<CreationDate>").append(this.dateFormatter.format(msg.getDate())).append("</CreationDate>\n");
/*      */ 
/* 1517 */     buffer.append(indent()).append("<PropertyList>\n");
/* 1518 */     this.indent += 1;
/*      */ 
/* 1520 */     for (Iterator i = msg.getPropertyNames(); i.hasNext(); ) {
/* 1521 */       String name = StringUtils.escapeForXML((String)i.next());
/* 1522 */       String value = StringUtils.escapeForXML(msg.getProperty(name));
/*      */ 
/* 1524 */       buffer.append(indent()).append("<Property name=\"").append(name).append("\" value=\"").append(value).append("\" />\n");
/*      */     }
/*      */ 
/* 1532 */     this.indent -= 1;
/* 1533 */     buffer.append(indent()).append("</PropertyList>\n");
/*      */ 
/* 1535 */     this.indent -= 1;
/* 1536 */     buffer.append(indent()).append("</PrivateMessage>\n");
/*      */ 
/* 1538 */     out.write(buffer.toString().getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private void exportAnnouncements(OutputStream out, Object container) throws Exception {
/* 1542 */     out.write(indent().getBytes(this.encoding));
/* 1543 */     out.write("<AnnouncementList>\n".getBytes(this.encoding));
/* 1544 */     this.indent += 1;
/*      */ 
/* 1546 */     AnnouncementManager announcementManager = this.factory.getAnnouncementManager();
/* 1547 */     for (Iterator i = announcementManager.getAnnouncements(container); i.hasNext(); ) {
/* 1548 */       Announcement announcement = (Announcement)i.next();
/* 1549 */       exportAnnouncement(out, announcement, container);
/*      */     }
/*      */ 
/* 1552 */     this.indent -= 1;
/* 1553 */     out.write(indent().getBytes(this.encoding));
/* 1554 */     out.write("</AnnouncementList>\n".getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private void exportAnnouncement(OutputStream out, Announcement announcement, Object container)
/*      */     throws Exception
/*      */   {
/* 1561 */     StringBuffer buffer = new StringBuffer(indent());
/* 1562 */     buffer.append("<Announcement id=\"").append(announcement.getID()).append("\" >");
/* 1563 */     this.indent += 1;
/*      */ 
/* 1565 */     buffer.append(indent());
/* 1566 */     buffer.append(getObjectString(container));
/*      */ 
/* 1568 */     buffer.append(indent());
/* 1569 */     buffer.append("<Username>").append(StringUtils.escapeForXML(announcement.getUser().getUsername())).append("</Username>\n");
/*      */ 
/* 1573 */     buffer.append(indent());
/* 1574 */     buffer.append("<Subject>").append(StringUtils.escapeForXML(announcement.getSubject())).append("</Subject>\n");
/*      */ 
/* 1578 */     buffer.append(indent());
/* 1579 */     buffer.append("<Body>").append(StringUtils.escapeForXML(announcement.getBody())).append("</Body>\n");
/*      */ 
/* 1583 */     if (announcement.getStartDate() != null) {
/* 1584 */       buffer.append(indent());
/* 1585 */       buffer.append("<StartDate>").append(this.dateFormatter.format(announcement.getStartDate())).append("</StartDate>\n");
/*      */     }
/*      */ 
/* 1590 */     if (announcement.getEndDate() != null) {
/* 1591 */       buffer.append(indent());
/* 1592 */       buffer.append("<EndDate>").append(this.dateFormatter.format(announcement.getEndDate())).append("</EndDate>\n");
/*      */     }
/*      */ 
/* 1597 */     this.indent -= 1;
/* 1598 */     buffer.append("</Announcement>\n");
/*      */ 
/* 1600 */     out.write(buffer.toString().getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private void exportPolls(OutputStream out, int objectType, long objectId) throws Exception {
/* 1604 */     out.write(indent().getBytes(this.encoding));
/* 1605 */     out.write("<PollList>\n".getBytes(this.encoding));
/* 1606 */     this.indent += 1;
/*      */ 
/* 1608 */     for (Iterator i = this.factory.getPollManager().getPolls(objectType, objectId); i.hasNext(); ) {
/* 1609 */       Poll poll = (Poll)i.next();
/* 1610 */       exportPoll(out, poll, objectType, objectId);
/*      */     }
/*      */ 
/* 1613 */     this.indent -= 1;
/* 1614 */     out.write(indent().getBytes(this.encoding));
/* 1615 */     out.write("</PollList>\n".getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private void exportPoll(OutputStream out, Poll poll, int objectType, long objectId)
/*      */     throws Exception
/*      */   {
/* 1621 */     StringBuffer buffer = new StringBuffer(indent());
/* 1622 */     buffer.append("<Poll id=\"").append(poll.getID()).append("\" >\n");
/* 1623 */     this.indent += 1;
/*      */ 
/* 1625 */     buffer.append(indent());
/* 1626 */     buffer.append(getObjectString(objectType, objectId));
/*      */ 
/* 1628 */     buffer.append(indent());
/* 1629 */     buffer.append("<Username>").append(StringUtils.escapeForXML(poll.getUser().getUsername())).append("</Username>\n");
/*      */ 
/* 1632 */     buffer.append(indent());
/* 1633 */     buffer.append("<Name>").append(poll.getName()).append("</Name>\n");
/*      */ 
/* 1635 */     buffer.append(indent());
/* 1636 */     buffer.append("<Description>").append(poll.getDescription()).append("</Description>\n");
/*      */ 
/* 1638 */     buffer.append(indent());
/* 1639 */     buffer.append("<CreationDate>").append(this.dateFormatter.format(poll.getCreationDate())).append("</CreationDate>\n");
/*      */ 
/* 1643 */     buffer.append(indent());
/* 1644 */     buffer.append("<ModifiedDate>").append(this.dateFormatter.format(poll.getModificationDate())).append("</ModifiedDate>\n");
/*      */ 
/* 1648 */     buffer.append(indent());
/* 1649 */     buffer.append("<StartDate>").append(this.dateFormatter.format(poll.getStartDate())).append("</StartDate>\n");
/*      */ 
/* 1654 */     buffer.append(indent());
/* 1655 */     buffer.append("<EndDate>").append(this.dateFormatter.format(poll.getEndDate())).append("</EndDate>\n");
/*      */ 
/* 1659 */     buffer.append(indent());
/* 1660 */     buffer.append("<ExpireDate>").append(this.dateFormatter.format(poll.getExpirationDate())).append("</ExpireDate>\n");
/*      */ 
/* 1664 */     buffer.append(indent());
/* 1665 */     buffer.append("<PollModeList>\n");
/* 1666 */     this.indent += 1;
/*      */ 
/* 1668 */     buffer.append(getPollModeList(poll));
/*      */ 
/* 1670 */     this.indent -= 1;
/* 1671 */     buffer.append(indent());
/* 1672 */     buffer.append("</PollModeList>\n");
/*      */ 
/* 1674 */     buffer.append(indent());
/* 1675 */     buffer.append("<PollOptionList>\n");
/* 1676 */     this.indent += 1;
/* 1677 */     int i = 0; for (int size = poll.getOptionCount(); i < size; i++)
/*      */     {
/* 1679 */       buffer.append(indent());
/* 1680 */       buffer.append("<PollOption index=\"").append(i).append("\">").append(StringUtils.escapeForXML(poll.getOption(i))).append("</PollOption>\n");
/*      */     }
/*      */ 
/* 1685 */     this.indent -= 1;
/* 1686 */     buffer.append(indent());
/* 1687 */     buffer.append("</PollOptionList>\n");
/*      */ 
/* 1689 */     buffer.append(indent());
/* 1690 */     buffer.append("<PollVoteList>\n");
/* 1691 */     out.write(buffer.toString().getBytes(this.encoding));
/* 1692 */     this.indent += 1;
/*      */ 
/* 1694 */     DbPoll dbPoll = (DbPoll)PollManagerFactory.pollCache.get(new Long(poll.getID()));
/*      */ 
/* 1696 */     for (Iterator i = dbPoll.getVotes(); i.hasNext(); ) {
/* 1697 */       Vote vote = (Vote)i.next();
/* 1698 */       exportPollVote(out, vote);
/*      */     }
/*      */ 
/* 1701 */     this.indent -= 1;
/* 1702 */     out.write(indent().getBytes(this.encoding));
/* 1703 */     out.write("</PollVoteList>\n".getBytes(this.encoding));
/*      */ 
/* 1705 */     this.indent -= 1;
/* 1706 */     out.write(indent().getBytes(this.encoding));
/* 1707 */     out.write("</Poll>\n".getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private void exportAttachment(OutputStream out, Attachment attachment) throws Exception {
/* 1711 */     this.exportedAttachments.add(attachment);
/*      */ 
/* 1713 */     StringBuffer buffer = new StringBuffer();
/*      */ 
/* 1715 */     buffer.append(indent());
/* 1716 */     buffer.append("<Attachment id=\"").append(attachment.getID()).append("\" contentType=\"").append(StringUtils.escapeForXML(attachment.getContentType())).append("\" >\n");
/*      */ 
/* 1718 */     this.indent += 1;
/*      */ 
/* 1720 */     buffer.append(indent());
/* 1721 */     buffer.append("<Name>").append(StringUtils.escapeForXML(attachment.getName())).append("</Name>\n");
/*      */ 
/* 1723 */     buffer.append(indent());
/* 1724 */     buffer.append("<PropertyList>\n");
/* 1725 */     this.indent += 1;
/*      */ 
/* 1727 */     for (Iterator i = attachment.getPropertyNames(); i.hasNext(); ) {
/* 1728 */       String name = StringUtils.escapeForXML((String)i.next());
/* 1729 */       String value = StringUtils.escapeForXML(attachment.getProperty(name));
/*      */ 
/* 1731 */       buffer.append(indent()).append("<Property name=\"").append(name).append("\" value=\"").append(value).append("\" />\n");
/*      */     }
/*      */ 
/* 1739 */     this.indent -= 1;
/* 1740 */     buffer.append(indent());
/* 1741 */     buffer.append("</PropertyList>\n");
/*      */ 
/* 1743 */     this.indent -= 1;
/* 1744 */     buffer.append(indent());
/* 1745 */     buffer.append("</Attachment>\n");
/*      */ 
/* 1747 */     out.write(buffer.toString().getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private String getPollModeList(Poll poll) {
/* 1751 */     StringBuffer buffer = new StringBuffer();
/*      */ 
/* 1753 */     if (poll.isModeEnabled(32L)) {
/* 1754 */       buffer.append(indent());
/* 1755 */       buffer.append("<PollMode mode=\"ALLOW_ANONYMOUS_VOTE_MODIFICATION\" />\n");
/*      */     }
/*      */ 
/* 1758 */     if (poll.isModeEnabled(16L)) {
/* 1759 */       buffer.append(indent());
/* 1760 */       buffer.append("<PollMode mode=\"ALLOW_USER_VOTE_MODIFICATION\" />\n");
/*      */     }
/*      */ 
/* 1763 */     if (poll.isModeEnabled(256L)) {
/* 1764 */       buffer.append(indent());
/* 1765 */       buffer.append("<PollMode mode=\"MULTIPLE_SELECTIONS_ALLOWED\" />\n");
/*      */     }
/*      */ 
/* 1768 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */   private void exportPollVote(OutputStream out, Vote vote) throws Exception {
/* 1772 */     StringBuffer buffer = new StringBuffer(indent());
/* 1773 */     buffer.append("<PollVote>\n");
/* 1774 */     this.indent += 1;
/*      */ 
/* 1776 */     User user = null;
/*      */     try {
/* 1778 */       this.factory.getUserManager().getUser(vote.getUserID());
/*      */     }
/*      */     catch (UserNotFoundException e)
/*      */     {
/*      */     }
/*      */ 
/* 1784 */     buffer.append(indent());
/* 1785 */     if (user != null) {
/* 1786 */       buffer.append("<Username>").append(StringUtils.escapeForXML(user.getName())).append("</Username>\n");
/*      */     }
/*      */     else
/*      */     {
/* 1790 */       buffer.append("<Guest id=\"").append(vote.getUniqueID()).append("\" />\n");
/*      */     }
/*      */ 
/* 1793 */     buffer.append(indent());
/* 1794 */     buffer.append("<CreationDate>").append(this.dateFormatter.format(vote.getVoteDate())).append("</CreationDate>\n");
/*      */ 
/* 1798 */     this.indent -= 1;
/* 1799 */     buffer.append(indent());
/* 1800 */     buffer.append("</PollVote>\n");
/*      */ 
/* 1802 */     out.write(buffer.toString().getBytes(this.encoding));
/*      */   }
/*      */ 
/*      */   private String getObjectString(int objectType, long objectId) {
/* 1806 */     switch (objectType) {
/*      */     case 17:
/* 1808 */       return "<Object id=\"-1\" type=\"SYSTEM\" />\n";
/*      */     case 0:
/* 1810 */       return "<Object id=\"" + objectId + "\" type=\"FORUM\" />";
/*      */     case 14:
/* 1815 */       return "<Object id=\"" + objectId + "\" type=\"CATEGORY\" />";
/*      */     case 1:
/* 1820 */       return "<Object id=\"" + objectId + "\" type=\"THREAD\" />";
/*      */     }
/*      */ 
/* 1825 */     throw new IllegalArgumentException("unrecognized object type --> " + objectType);
/*      */   }
/*      */ 
/*      */   private String getObjectString(Object o)
/*      */   {
/* 1831 */     if (o == null) {
/* 1832 */       return "<Object id=\"-1\" type=\"SYSTEM\" />\n";
/*      */     }
/*      */ 
/* 1835 */     if ((o instanceof Forum)) {
/* 1836 */       Forum f = (Forum)o;
/* 1837 */       return "<Object id=\"" + f.getID() + "\" type=\"FORUM\" />\n";
/*      */     }
/*      */ 
/* 1843 */     if ((o instanceof ForumCategory)) {
/* 1844 */       ForumCategory c = (ForumCategory)o;
/* 1845 */       return "<Object id=\"" + c.getID() + "\" type=\"CATEGORY\" />\n";
/*      */     }
/*      */ 
/* 1852 */     if ((o instanceof ForumThread)) {
/* 1853 */       ForumThread t = (ForumThread)o;
/* 1854 */       return "<Object id\"" + t.getID() + "\" type=\"THREAD\" />\n";
/*      */     }
/*      */ 
/* 1860 */     throw new IllegalArgumentException("Unrecognized type --> " + o.getClass());
/*      */   }
/*      */ 
/*      */   private String indent()
/*      */   {
/* 1866 */     char[] spaces = new char[this.indent * 2];
/* 1867 */     Arrays.fill(spaces, ' ');
/* 1868 */     return new String(spaces);
/*      */   }
/*      */ 
/*      */   private void initTaskCount()
/*      */   {
/* 1877 */     int numOps = 0;
/*      */ 
/* 1880 */     if (this.exportUsersEnabled) {
/* 1881 */       numOps++;
/*      */     }
/*      */ 
/* 1884 */     if (this.exportGroupsEnabled) {
/* 1885 */       numOps++;
/*      */     }
/*      */ 
/* 1888 */     if (this.exportForumsEnabled) {
/* 1889 */       numOps++;
/*      */     }
/*      */ 
/* 1892 */     if (this.exportJivePropertiesEnabled) {
/* 1893 */       numOps++;
/*      */     }
/*      */ 
/* 1896 */     if (this.exportPrivateMessagesEnabled) {
/* 1897 */       numOps++;
/*      */     }
/*      */ 
/* 1900 */     if (this.exportPollsEnabled) {
/* 1901 */       numOps++;
/*      */     }
/*      */ 
/* 1904 */     numOps++;
/*      */ 
/* 1906 */     if (this.exportAnnouncementsEnabled) {
/* 1907 */       numOps++;
/*      */     }
/*      */ 
/* 1911 */     this.taskMaximum = numOps;
/* 1912 */     this.taskValue = 0;
/*      */   }
/*      */ 
/*      */   public static void main(String[] args)
/*      */   {
/* 1917 */     Options options = new Options();
/*      */ 
/* 1919 */     Option o = new Option("username", true, "required - the username to export with with");
/* 1920 */     o.setRequired(true);
/* 1921 */     options.addOption(o);
/*      */ 
/* 1923 */     o = new Option("password", true, "required - the user's password");
/* 1924 */     o.setRequired(true);
/* 1925 */     options.addOption(o);
/*      */ 
/* 1927 */     o = new Option("output", true, "required - the output file");
/* 1928 */     o.setRequired(true);
/* 1929 */     options.addOption(o);
/*      */ 
/* 1931 */     CommandLineParser commandLineParser = new BasicParser();
/* 1932 */     CommandLine cli = null;
/*      */ 
/* 1934 */     boolean isError = false;
/*      */     try
/*      */     {
/* 1937 */       cli = commandLineParser.parse(options, args);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1941 */       System.err.println(e.getMessage());
/*      */     }
/*      */ 
/* 1945 */     if ((isError) || (cli == null)) {
/* 1946 */       usageAndExit(options);
/*      */     }
/*      */ 
/* 1949 */     String username = cli.getOptionValue("username");
/* 1950 */     String password = cli.getOptionValue("password");
/* 1951 */     String output = cli.getOptionValue("output");
/*      */ 
/* 1954 */     AuthToken authToken = null;
/*      */     try {
/* 1956 */       authToken = AuthFactory.getAuthToken(username, password);
/*      */     }
/*      */     catch (UnauthorizedException e) {
/* 1959 */       System.err.println("Error authenticating user " + username + ". " + "Please make sure you're using the correct username and " + "password.");
/*      */ 
/* 1962 */       System.exit(1);
/*      */     }
/*      */     try
/*      */     {
/* 1966 */       DbDataExport instance = new DbDataExport(DbForumFactory.getInstance(authToken));
/*      */ 
/* 1968 */       System.out.println("\nBeginning export, writing to " + output + "...");
/*      */ 
/* 1970 */       File file = new File(output);
/* 1971 */       file.createNewFile();
/*      */ 
/* 1973 */       OutputStream out = new BufferedOutputStream(new FileOutputStream(file));
/*      */ 
/* 1975 */       instance.setOutputStream(out);
/* 1976 */       instance.doRun();
/*      */     }
/*      */     catch (Exception e) {
/* 1979 */       System.err.println(e.getMessage());
/* 1980 */       Log.error(e);
/*      */     }
/* 1982 */     System.exit(0);
/*      */   }
/*      */ 
/*      */   private static void usageAndExit(Options options) {
/* 1986 */     printNameAndVersion();
/* 1987 */     HelpFormatter formatter = new HelpFormatter();
/* 1988 */     formatter.printHelp("java -classpath=[jive classpath] -DjavaHome=[javaHome]  com.jivesoftware.forum.database.DbDataExport \n ", options);
/*      */ 
/* 1992 */     System.exit(1);
/*      */   }
/*      */ 
/*      */   private static void printNameAndVersion() {
/* 1996 */     System.out.println("\n");
/* 1997 */     String fullName = NAME;
/* 1998 */     System.out.println(fullName);
/* 1999 */     for (int i = 0; i < fullName.length(); i++) {
/* 2000 */       System.out.print('_');
/*      */     }
/* 2002 */     System.out.print("\n");
/* 2003 */     System.out.println("\n");
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbDataExport
 * JD-Core Version:    0.6.2
 */
/*      */ package com.jivesoftware.forum.database;
/*      */ 
/*      */ import com.jivesoftware.base.JiveGlobals;
/*      */ import com.jivesoftware.base.JiveManager;
/*      */ import com.jivesoftware.base.Log;
/*      */ import com.jivesoftware.base.User;
/*      */ import com.jivesoftware.base.database.ConnectionManager;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumCategory;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*      */ import com.jivesoftware.forum.ForumThread;
/*      */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*      */ import com.jivesoftware.forum.ReadTracker;
/*      */ import com.jivesoftware.forum.ResultFilter;
/*      */ import com.jivesoftware.util.Cache;
/*      */ import com.jivesoftware.util.CacheFactory;
/*      */ import com.jivesoftware.util.CacheSizes;
/*      */ import com.jivesoftware.util.Cacheable;
/*      */ import com.jivesoftware.util.LongList;
/*      */ import com.jivesoftware.util.TaskEngine;
/*      */ import com.tangosol.io.ExternalizableLite;
/*      */ import com.tangosol.util.ExternalizableHelper;
/*      */ import edu.emory.mathcs.backport.java.util.concurrent.ConcurrentHashMap;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.IOException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ 
/*      */ public class DbReadTracker
/*      */   implements ReadTracker, JiveManager
/*      */ {
/*      */   public static final String GET_FORUM_OBJECTS = "SELECT objectID, readDate FROM jiveReadTracker WHERE userID=? AND objectType=0";
/*      */   public static final String GET_THREAD_OBJECTS = "SELECT objectID, forumID, readDate FROM jiveReadTracker, jiveThread WHERE jiveReadTracker.userID=? AND objectType=1 AND objectID=threadID";
/*      */   public static final String GET_MESSAGE_OBJECTS = "SELECT objectID, forumID, readDate FROM jiveReadTracker, jiveMessage WHERE jiveReadTracker.userID=? AND objectType=2 AND objectID=messageID";
/*      */   public static final String INSERT_OBJECT_READ = "INSERT INTO jiveReadTracker (userID, objectType, objectID, readDate) VALUES (?,?,?,?)";
/*      */   public static final String UPDATE_OBJECT_READ = "UPDATE jiveReadTracker SET readDate=? WHERE userID=? AND objectType=? AND objectID=?";
/*      */   public static final String DELETE_OLD_ENTRIES = "DELETE FROM jiveReadTracker WHERE readDate < ?";
/*      */   public static final String DELETE_OLD_THREADS_IN_FORUM = "DELETE FROM jiveReadTracker WHERE userID=? AND objectType=1 AND readDate < ? AND objectID IN    (SELECT jt.threadID FROM jiveThread jt, jiveReadTracker jrt    WHERE jrt.objectType=1   AND jrt.objectID=jt.threadID AND jt.forumID=?)";
/*      */   public static final String DELETE_OLD_MESSAGES_IN_FORUM = "DELETE FROM jiveReadTracker WHERE userID=? AND objectType=2 AND readDate < ? AND objectID IN    (SELECT jm.messageID FROM jiveMessage jm, jiveReadTracker jrt    WHERE jrt.objectType=2   AND jrt.objectID=jm.messageID AND jm.forumID=?)";
/*      */   public static final String SELECT_OLD_THREADS_IN_FORUM = "SELECT jrt.objectID FROM jiveReadTracker jrt, jiveThread jT WHERE jrt.userID=? AND objectType=1 AND objectID=jT.threadID AND jT.forumID=? AND readDate < ?";
/*      */   public static final String SELECT_OLD_MESSAGES_IN_FORUM = "SELECT jrt.objectID FROM jiveReadTracker jrt, jiveMessage jM WHERE jrt.userID=? AND objectType=2 AND objectID=jM.messageID AND jM.forumID=? AND readDate < ?";
/*      */   public static final String DELETE_OLD_OBJECT_IN_FORUM = "DELETE FROM jiveReadTracker WHERE userID=? AND objectID=? AND objectType=?";
/*      */   private static DbForumFactory FACTORY;
/*  110 */   private static long timeWindow = days * 86400000L;
/*  111 */   private static boolean readTrackingEnabled = JiveGlobals.getJiveBooleanProperty("readTracker.enabled", true);
/*      */ 
/*   95 */   private static LinkedList insertQueue = new LinkedList();
/*      */ 
/*  101 */   private static LinkedList updateQueue = new LinkedList();
/*      */ 
/*  103 */   private static DbReadTracker instance = new DbReadTracker();
/*  104 */   private static boolean initialized = false;
/*      */ 
/*      */   public static DbReadTracker getInstance()
/*      */   {
/*  120 */     return instance;
/*      */   }
/*      */ 
/*      */   public synchronized void initialize()
/*      */   {
/*  126 */     if (!initialized) {
/*  127 */       FACTORY = DbForumFactory.getInstance();
/*      */ 
/*  131 */       TaskEngine.scheduleTask(new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*  136 */           if (!CacheFactory.isSeniorClusterMember()) {
/*  137 */             return;
/*      */           }
/*  139 */           Connection con = null;
/*  140 */           PreparedStatement pstmt = null;
/*  141 */           boolean abortTransaction = false;
/*      */           try {
/*  143 */             con = ConnectionManager.getTransactionConnection();
/*  144 */             pstmt = con.prepareStatement("DELETE FROM jiveReadTracker WHERE readDate < ?");
/*  145 */             long oldDate = ResultFilter.roundDate(CacheFactory.currentTime - DbReadTracker.timeWindow, 3600);
/*      */ 
/*  147 */             pstmt.setLong(1, oldDate);
/*  148 */             pstmt.execute();
/*      */           }
/*      */           catch (SQLException sqle) {
/*  151 */             Log.error(sqle);
/*  152 */             abortTransaction = true;
/*      */           }
/*      */           finally {
/*  155 */             ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */           }
/*      */ 
/*  160 */           DbReadTracker.FACTORY.cacheManager.readTrackerCache.clear();
/*      */         }
/*      */       }
/*      */       , 3600000L, 43200000L);
/*      */ 
/*  165 */       TaskEngine.scheduleTask(new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*      */           int maxInserts;
/*      */           int maxUpdates;
/*  173 */           synchronized (DbReadTracker.insertQueue) {
/*  174 */             synchronized (DbReadTracker.updateQueue) {
/*  175 */               maxInserts = DbReadTracker.insertQueue.size();
/*  176 */               maxUpdates = DbReadTracker.updateQueue.size();
/*      */             }
/*      */           }
/*  179 */           DbReadTracker.batchInserts(maxInserts);
/*  180 */           DbReadTracker.batchUpdates(maxUpdates);
/*      */         }
/*      */       }
/*      */       , 60000L, 60000L);
/*      */ 
/*  184 */       initialized = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isReadTrackingEnabled() {
/*  189 */     return readTrackingEnabled;
/*      */   }
/*      */ 
/*      */   public void setReadTrackingEnabled(boolean enabled) {
/*  193 */     readTrackingEnabled = enabled;
/*  194 */     JiveGlobals.setJiveProperty("readTracker.enabled", String.valueOf(enabled));
/*      */   }
/*      */ 
/*      */   public int getReadStatus(User user, ForumThread thread) {
/*  198 */     if ((user == null) || (thread == null)) {
/*  199 */       throw new IllegalArgumentException("Parameters cannot be null.");
/*      */     }
/*  201 */     long forumID = thread.getForum().getID();
/*  202 */     long cutoffDate = getCutoffDate(getUserTracker(user), forumID);
/*      */ 
/*  205 */     if (thread.getModificationDate().getTime() <= cutoffDate) {
/*  206 */       return 2;
/*      */     }
/*      */ 
/*  209 */     return getUserTracker(user).getReadStatus(thread);
/*      */   }
/*      */ 
/*      */   public int getReadStatus(User user, ForumMessage message)
/*      */   {
/*  214 */     long forumID = message.getForumThread().getForum().getID();
/*  215 */     long cutoffDate = getCutoffDate(getUserTracker(user), forumID);
/*      */ 
/*  218 */     if (message.getModificationDate().getTime() < cutoffDate) {
/*  219 */       return 2;
/*      */     }
/*      */ 
/*  222 */     return getUserTracker(user).getReadStatus(message);
/*      */   }
/*      */ 
/*      */   public void markRead(User user, ForumMessage message)
/*      */   {
/*  227 */     if ((user == null) || (message == null)) {
/*  228 */       throw new IllegalArgumentException("Parameters cannot be null.");
/*      */     }
/*      */ 
/*  232 */     long forumID = message.getForumThread().getForum().getID();
/*  233 */     long cutoffDate = getCutoffDate(getUserTracker(user), forumID);
/*      */ 
/*  235 */     if (message.getModificationDate().getTime() > cutoffDate) {
/*  236 */       UserReadTracker readTracker = getUserTracker(user);
/*  237 */       if (readTracker.markRead(message))
/*      */       {
/*  239 */         FACTORY.cacheManager.readTrackerCache.put(new Long(readTracker.userID), readTracker);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void markRead(User user, Forum forum) {
/*  245 */     if ((user == null) || (forum == null)) {
/*  246 */       throw new IllegalArgumentException("Parameters cannot be null.");
/*      */     }
/*      */ 
/*  249 */     UserReadTracker readTracker = getUserTracker(user);
/*  250 */     readTracker.markRead(forum);
/*      */ 
/*  253 */     FACTORY.cacheManager.readTrackerCache.put(new Long(readTracker.userID), readTracker);
/*      */   }
/*      */ 
/*      */   public void markRead(User user, ForumCategory category) {
/*  257 */     if ((user == null) || (category == null)) {
/*  258 */       throw new IllegalArgumentException("Parameters cannot be null.");
/*      */     }
/*      */ 
/*  262 */     for (Iterator iter = category.getRecursiveForums(); iter.hasNext(); )
/*  263 */       markRead(user, (Forum)iter.next());
/*      */   }
/*      */ 
/*      */   public int getUnreadThreadCount(User user, Forum forum)
/*      */   {
/*  268 */     if ((user == null) || (forum == null)) {
/*  269 */       throw new IllegalArgumentException("Parameters cannot be null.");
/*      */     }
/*      */ 
/*  272 */     UserReadTracker readTracker = getUserTracker(user);
/*  273 */     long forumID = forum.getID();
/*  274 */     long cutoffDate = getCutoffDate(readTracker, forumID);
/*      */ 
/*  278 */     int readCount = 0;
/*      */ 
/*  280 */     Iterator keys = readTracker.readThreads.keySet().iterator();
/*  281 */     while (keys.hasNext()) {
/*  282 */       ReadTrackerKey key = (ReadTrackerKey)keys.next();
/*  283 */       if (key.getForumID() == forumID) {
/*  284 */         long threadID = key.getObjectID();
/*  285 */         long readDate = ((Long)readTracker.readThreads.get(key)).longValue();
/*      */         try
/*      */         {
/*  288 */           ForumThread thread = FACTORY.cacheManager.getForumThread(threadID);
/*  289 */           long modifiedDate = thread.getModificationDate().getTime();
/*      */ 
/*  295 */           if ((modifiedDate > cutoffDate) && (modifiedDate <= readDate)) {
/*  296 */             readCount++;
/*      */           }
/*      */         }
/*      */         catch (ForumThreadNotFoundException e)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*  304 */     ResultFilter filter = ResultFilter.createDefaultThreadFilter();
/*  305 */     filter.setModificationDateRangeMin(new Date(cutoffDate));
/*  306 */     int threadCount = forum.getThreadCount(filter);
/*      */ 
/*  310 */     return threadCount - readCount;
/*      */   }
/*      */ 
/*      */   public int getUnreadThreadCount(User user, ForumCategory category) {
/*  314 */     if ((user == null) || (category == null)) {
/*  315 */       throw new IllegalArgumentException("Parameters cannot be null.");
/*      */     }
/*      */ 
/*  318 */     int count = 0;
/*      */ 
/*  321 */     for (Iterator iter = category.getRecursiveForums(); iter.hasNext(); ) {
/*  322 */       count += getUnreadThreadCount(user, (Forum)iter.next());
/*      */     }
/*      */ 
/*  325 */     return count;
/*      */   }
/*      */ 
/*      */   public Iterator getUnreadThreads(User user, Forum forum) {
/*  329 */     if ((user == null) || (forum == null)) {
/*  330 */       throw new IllegalArgumentException("Parameters cannot be null.");
/*      */     }
/*      */ 
/*  333 */     UserReadTracker readTracker = getUserTracker(user);
/*  334 */     long cutoffDate = getCutoffDate(readTracker, forum.getID());
/*      */ 
/*  338 */     ResultFilter filter = ResultFilter.createDefaultThreadFilter();
/*  339 */     filter.setModificationDateRangeMin(new Date(cutoffDate));
/*      */ 
/*  341 */     return new UnreadIterator(1, forum.getThreads(filter), getUserTracker(user));
/*      */   }
/*      */ 
/*      */   public Iterator getUnreadThreads(User user, ForumCategory category)
/*      */   {
/*  346 */     if ((user == null) || (category == null)) {
/*  347 */       throw new IllegalArgumentException("Parameters cannot be null.");
/*      */     }
/*      */ 
/*  350 */     List unreadThreads = new LinkedList();
/*      */ 
/*  353 */     for (Iterator iter = category.getRecursiveForums(); iter.hasNext(); ) {
/*  354 */       Forum forum = (Forum)iter.next();
/*  355 */       for (threads = getUnreadThreads(user, forum); threads.hasNext(); )
/*  356 */         unreadThreads.add(threads.next());
/*      */     }
/*      */     Iterator threads;
/*  360 */     return unreadThreads.iterator();
/*      */   }
/*      */ 
/*      */   public int getUnreadMessageCount(User user, Forum forum) {
/*  364 */     if ((user == null) || (forum == null)) {
/*  365 */       throw new IllegalArgumentException("Parameters cannot be null.");
/*      */     }
/*      */ 
/*  368 */     UserReadTracker readTracker = getUserTracker(user);
/*  369 */     long forumID = forum.getID();
/*  370 */     long cutoffDate = getCutoffDate(readTracker, forumID);
/*      */ 
/*  374 */     int readCount = 0;
/*      */ 
/*  376 */     Iterator keys = readTracker.readMessages.keySet().iterator();
/*  377 */     while (keys.hasNext()) {
/*  378 */       ReadTrackerKey key = (ReadTrackerKey)keys.next();
/*  379 */       if (key.getForumID() == forumID) {
/*  380 */         long messageID = key.getObjectID();
/*  381 */         long readDate = ((Long)readTracker.readMessages.get(key)).longValue();
/*      */         try {
/*  383 */           ForumMessage message = FACTORY.cacheManager.getMessage(messageID);
/*  384 */           long modifiedDate = message.getModificationDate().getTime();
/*      */ 
/*  390 */           if ((modifiedDate > cutoffDate) && (modifiedDate <= readDate)) {
/*  391 */             readCount++;
/*      */           }
/*      */         }
/*      */         catch (ForumMessageNotFoundException e)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*  399 */     ResultFilter filter = ResultFilter.createDefaultMessageFilter();
/*  400 */     filter.setModificationDateRangeMin(new Date(cutoffDate));
/*  401 */     int messageCount = forum.getMessageCount(filter);
/*      */ 
/*  405 */     return messageCount - readCount;
/*      */   }
/*      */ 
/*      */   public int getUnreadMessageCount(User user, ForumCategory category) {
/*  409 */     if ((user == null) || (category == null)) {
/*  410 */       throw new IllegalArgumentException("Parameters cannot be null.");
/*      */     }
/*      */ 
/*  413 */     int count = 0;
/*      */ 
/*  416 */     for (Iterator iter = category.getRecursiveForums(); iter.hasNext(); ) {
/*  417 */       count += getUnreadMessageCount(user, (Forum)iter.next());
/*      */     }
/*      */ 
/*  420 */     return count;
/*      */   }
/*      */ 
/*      */   public Iterator getUnreadMessages(User user, Forum forum) {
/*  424 */     if ((user == null) || (forum == null)) {
/*  425 */       throw new IllegalArgumentException("Parameters cannot be null.");
/*      */     }
/*      */ 
/*  428 */     UserReadTracker readTracker = getUserTracker(user);
/*  429 */     long cutoffDate = getCutoffDate(readTracker, forum.getID());
/*      */ 
/*  433 */     ResultFilter filter = ResultFilter.createDefaultMessageFilter();
/*  434 */     filter.setModificationDateRangeMin(new Date(cutoffDate));
/*      */ 
/*  436 */     return new UnreadIterator(2, forum.getMessages(filter), readTracker);
/*      */   }
/*      */ 
/*      */   public Iterator getUnreadMessages(User user, ForumCategory category)
/*      */   {
/*  441 */     if ((user == null) || (category == null)) {
/*  442 */       throw new IllegalArgumentException("Parameters cannot be null.");
/*      */     }
/*      */ 
/*  445 */     List unreadMessages = new LinkedList();
/*      */ 
/*  448 */     for (Iterator iter = category.getRecursiveForums(); iter.hasNext(); ) {
/*  449 */       Forum forum = (Forum)iter.next();
/*  450 */       for (threads = getUnreadMessages(user, forum); threads.hasNext(); )
/*  451 */         unreadMessages.add(threads.next());
/*      */     }
/*      */     Iterator threads;
/*  455 */     return unreadMessages.iterator();
/*      */   }
/*      */ 
/*      */   private UserReadTracker getUserTracker(User user)
/*      */   {
/*  465 */     Long userID = new Long(user.getID());
/*  466 */     UserReadTracker userTracker = null;
/*      */ 
/*  468 */     synchronized (user) {
/*  469 */       userTracker = (UserReadTracker)FACTORY.cacheManager.readTrackerCache.get(userID);
/*      */ 
/*  471 */       if (userTracker == null) {
/*  472 */         userTracker = new UserReadTracker(user.getID());
/*  473 */         FACTORY.cacheManager.readTrackerCache.put(userID, userTracker);
/*      */       }
/*      */     }
/*      */ 
/*  477 */     return userTracker;
/*      */   }
/*      */ 
/*      */   private static long getCutoffDate(UserReadTracker readTracker, long forumID)
/*      */   {
/*  484 */     long cutoffDate = ResultFilter.roundDate(CacheFactory.currentTime - timeWindow, 3600);
/*      */ 
/*  488 */     Long date = (Long)readTracker.readForums.get(new Long(forumID));
/*  489 */     if (date != null) {
/*  490 */       cutoffDate = cutoffDate > date.longValue() ? cutoffDate : date.longValue();
/*      */     }
/*      */ 
/*  493 */     return cutoffDate;
/*      */   }
/*      */ 
/*      */   private static void batchInserts(int maxInserts)
/*      */   {
/*  501 */     if (maxInserts == 0) {
/*  502 */       return;
/*      */     }
/*      */ 
/*  505 */     Connection con = null;
/*  506 */     PreparedStatement pstmt = null;
/*      */     try
/*      */     {
/*  509 */       con = ConnectionManager.getConnection();
/*  510 */       pstmt = con.prepareStatement("INSERT INTO jiveReadTracker (userID, objectType, objectID, readDate) VALUES (?,?,?,?)");
/*  511 */       for (int i = 0; i < maxInserts; i++) {
/*  512 */         synchronized (insertQueue) {
/*  513 */           long[] result = (long[])insertQueue.removeLast();
/*  514 */           pstmt.setLong(1, result[0]);
/*  515 */           pstmt.setInt(2, 2);
/*  516 */           pstmt.setLong(3, result[1]);
/*  517 */           pstmt.setLong(4, result[2]);
/*  518 */           if (ConnectionManager.isBatchUpdatesSupported()) {
/*  519 */             pstmt.addBatch();
/*      */           }
/*      */           else {
/*  522 */             pstmt.execute();
/*      */           }
/*      */         }
/*      */       }
/*  526 */       if (ConnectionManager.isBatchUpdatesSupported())
/*  527 */         pstmt.executeBatch();
/*      */     }
/*      */     catch (SQLException sqle)
/*      */     {
/*  531 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/*  534 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void batchUpdates(int maxUpdates)
/*      */   {
/*  543 */     if (maxUpdates == 0) {
/*  544 */       return;
/*      */     }
/*      */ 
/*  547 */     Connection con = null;
/*  548 */     PreparedStatement pstmt = null;
/*      */     try
/*      */     {
/*  551 */       con = ConnectionManager.getConnection();
/*  552 */       pstmt = con.prepareStatement("UPDATE jiveReadTracker SET readDate=? WHERE userID=? AND objectType=? AND objectID=?");
/*  553 */       for (int i = 0; i < maxUpdates; i++) {
/*  554 */         synchronized (updateQueue) {
/*  555 */           long[] result = (long[])updateQueue.removeLast();
/*  556 */           pstmt.setLong(1, result[2]);
/*  557 */           pstmt.setLong(2, result[0]);
/*  558 */           pstmt.setInt(3, 2);
/*  559 */           pstmt.setLong(4, result[1]);
/*  560 */           if (ConnectionManager.isBatchUpdatesSupported()) {
/*  561 */             pstmt.addBatch();
/*      */           }
/*      */           else {
/*  564 */             pstmt.execute();
/*      */           }
/*      */         }
/*      */       }
/*  568 */       if (ConnectionManager.isBatchUpdatesSupported())
/*  569 */         pstmt.executeBatch();
/*      */     }
/*      */     catch (SQLException sqle)
/*      */     {
/*  573 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/*  576 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  109 */     int days = JiveGlobals.getJiveIntProperty("readTracker.timeWindow", 30);
/*      */   }
/*      */ 
/*      */   public static class UserReadTracker
/*      */     implements Cacheable, ExternalizableLite
/*      */   {
/*      */     long userID;
/*      */     Map readForums;
/*      */     Map readThreads;
/*      */     Map readMessages;
/*      */ 
/*      */     public UserReadTracker(long userID)
/*      */     {
/*  740 */       this.userID = userID;
/*  741 */       this.readForums = new ConcurrentHashMap(16, 0.75F, 4);
/*  742 */       this.readThreads = new ConcurrentHashMap(16, 0.75F, 4);
/*  743 */       this.readMessages = new ConcurrentHashMap(16, 0.75F, 4);
/*  744 */       loadReadsFromDb();
/*      */     }
/*      */ 
/*      */     public UserReadTracker()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void readExternal(DataInput in)
/*      */       throws IOException
/*      */     {
/*  755 */       this.userID = ExternalizableHelper.readLong(in);
/*      */ 
/*  757 */       this.readForums = new ConcurrentHashMap(16, 0.75F, 4);
/*  758 */       int size = ExternalizableHelper.readInt(in);
/*  759 */       for (int i = 0; i < size; i++) {
/*  760 */         this.readForums.put(ExternalizableHelper.readObject(in), ExternalizableHelper.readObject(in));
/*      */       }
/*      */ 
/*  763 */       this.readThreads = new ConcurrentHashMap(16, 0.75F, 4);
/*  764 */       size = ExternalizableHelper.readInt(in);
/*  765 */       for (int i = 0; i < size; i++) {
/*  766 */         this.readThreads.put(ExternalizableHelper.readObject(in), ExternalizableHelper.readObject(in));
/*      */       }
/*      */ 
/*  769 */       this.readMessages = new ConcurrentHashMap(16, 0.75F, 4);
/*  770 */       size = ExternalizableHelper.readInt(in);
/*  771 */       for (int i = 0; i < size; i++)
/*  772 */         this.readMessages.put(ExternalizableHelper.readObject(in), ExternalizableHelper.readObject(in));
/*      */     }
/*      */ 
/*      */     public void writeExternal(DataOutput out) throws IOException
/*      */     {
/*  777 */       ExternalizableHelper.writeLong(out, this.userID);
/*      */ 
/*  779 */       Map.Entry[] entries = (Map.Entry[])this.readForums.entrySet().toArray(new Map.Entry[0]);
/*  780 */       ExternalizableHelper.writeInt(out, entries.length);
/*  781 */       for (int i = 0; i < entries.length; i++) {
/*  782 */         Map.Entry entry = entries[i];
/*  783 */         ExternalizableHelper.writeObject(out, entry.getKey());
/*  784 */         ExternalizableHelper.writeObject(out, entry.getValue());
/*      */       }
/*      */ 
/*  787 */       entries = (Map.Entry[])this.readThreads.entrySet().toArray(new Map.Entry[0]);
/*  788 */       ExternalizableHelper.writeInt(out, entries.length);
/*  789 */       for (int i = 0; i < entries.length; i++) {
/*  790 */         Map.Entry entry = entries[i];
/*  791 */         ExternalizableHelper.writeObject(out, entry.getKey());
/*  792 */         ExternalizableHelper.writeObject(out, entry.getValue());
/*      */       }
/*      */ 
/*  795 */       entries = (Map.Entry[])this.readMessages.entrySet().toArray(new Map.Entry[0]);
/*  796 */       ExternalizableHelper.writeInt(out, entries.length);
/*  797 */       for (int i = 0; i < entries.length; i++) {
/*  798 */         Map.Entry entry = entries[i];
/*  799 */         ExternalizableHelper.writeObject(out, entry.getKey());
/*  800 */         ExternalizableHelper.writeObject(out, entry.getValue());
/*      */       }
/*      */     }
/*      */ 
/*      */     public int getReadStatus(ForumThread thread) {
/*  805 */       DbReadTracker.ReadTrackerKey key = new DbReadTracker.ReadTrackerKey(thread.getID(), thread.getForum().getID());
/*  806 */       Long readDate = (Long)this.readThreads.get(key);
/*  807 */       if (readDate == null)
/*      */       {
/*  813 */         long highWaterMark = DbReadTracker.getCutoffDate(this, thread.getForum().getID());
/*  814 */         if ((thread.getCreationDate().getTime() < highWaterMark) && (thread.getModificationDate().getTime() > highWaterMark))
/*      */         {
/*  816 */           return 1;
/*      */         }
/*      */ 
/*  819 */         return 0;
/*      */       }
/*      */ 
/*  822 */       if (readDate.longValue() < thread.getModificationDate().getTime()) {
/*  823 */         return 1;
/*      */       }
/*      */ 
/*  826 */       return 2;
/*      */     }
/*      */ 
/*      */     public int getReadStatus(ForumMessage message)
/*      */     {
/*  831 */       DbReadTracker.ReadTrackerKey key = new DbReadTracker.ReadTrackerKey(message.getID(), message.getForumThread().getForum().getID());
/*      */ 
/*  833 */       Long readDate = (Long)this.readMessages.get(key);
/*  834 */       if (readDate == null)
/*      */       {
/*  840 */         long highWaterMark = DbReadTracker.getCutoffDate(this, message.getForumThread().getForum().getID());
/*      */ 
/*  842 */         if ((message.getCreationDate().getTime() < highWaterMark) && (message.getModificationDate().getTime() > highWaterMark))
/*      */         {
/*  845 */           return 1;
/*      */         }
/*      */ 
/*  848 */         return 0;
/*      */       }
/*      */ 
/*  851 */       if (readDate.longValue() < message.getModificationDate().getTime()) {
/*  852 */         return 1;
/*      */       }
/*      */ 
/*  855 */       return 2;
/*      */     }
/*      */ 
/*      */     public synchronized boolean markRead(ForumMessage message)
/*      */     {
/*  860 */       boolean updatedStatus = false;
/*  861 */       DbReadTracker.ReadTrackerKey key = new DbReadTracker.ReadTrackerKey(message.getID(), message.getForumThread().getForum().getID());
/*      */ 
/*  863 */       Long readDate = (Long)this.readMessages.get(key);
/*      */ 
/*  865 */       if (readDate == null)
/*      */       {
/*  870 */         readDate = new Long(message.getModificationDate().getTime());
/*  871 */         this.readMessages.put(key, readDate);
/*  872 */         long[] insertData = { this.userID, message.getID(), readDate.longValue() };
/*  873 */         synchronized (DbReadTracker.insertQueue) {
/*  874 */           DbReadTracker.insertQueue.addFirst(insertData);
/*      */         }
/*  876 */         updatedStatus = true;
/*      */       }
/*  881 */       else if (message.getModificationDate().getTime() > readDate.longValue()) {
/*  882 */         readDate = new Long(message.getModificationDate().getTime());
/*  883 */         this.readMessages.put(key, readDate);
/*  884 */         long[] updateData = { this.userID, message.getID(), readDate.longValue() };
/*  885 */         synchronized (DbReadTracker.updateQueue) {
/*  886 */           DbReadTracker.updateQueue.addFirst(updateData);
/*      */         }
/*  888 */         updatedStatus = true;
/*      */       }
/*      */ 
/*  895 */       return (markRead(message.getForumThread())) || (updatedStatus);
/*      */     }
/*      */ 
/*      */     private synchronized boolean markRead(ForumThread thread) {
/*  899 */       DbReadTracker.ReadTrackerKey key = new DbReadTracker.ReadTrackerKey(thread.getID(), thread.getForum().getID());
/*  900 */       Long readDate = (Long)this.readThreads.get(key);
/*      */ 
/*  902 */       if ((readDate != null) && (readDate.longValue() >= thread.getModificationDate().getTime()))
/*      */       {
/*  904 */         return false;
/*      */       }
/*      */ 
/*  907 */       boolean insert = readDate == null;
/*  908 */       readDate = new Long(thread.getModificationDate().getTime());
/*      */ 
/*  911 */       Connection con = null;
/*  912 */       PreparedStatement pstmt = null;
/*      */       try
/*      */       {
/*  915 */         con = ConnectionManager.getConnection();
/*  916 */         if (insert) {
/*  917 */           pstmt = con.prepareStatement("INSERT INTO jiveReadTracker (userID, objectType, objectID, readDate) VALUES (?,?,?,?)");
/*  918 */           pstmt.setLong(1, this.userID);
/*  919 */           pstmt.setInt(2, 1);
/*  920 */           pstmt.setLong(3, thread.getID());
/*  921 */           pstmt.setLong(4, readDate.longValue());
/*      */           try
/*      */           {
/*  924 */             pstmt.execute();
/*      */           }
/*      */           catch (SQLException e)
/*      */           {
/*  929 */             Log.error(e);
/*  930 */             pstmt.close();
/*      */ 
/*  933 */             insert = false;
/*      */           }
/*      */         }
/*      */         else {
/*  937 */           pstmt = con.prepareStatement("UPDATE jiveReadTracker SET readDate=? WHERE userID=? AND objectType=? AND objectID=?");
/*  938 */           pstmt.setLong(1, readDate.longValue());
/*  939 */           pstmt.setLong(2, this.userID);
/*  940 */           pstmt.setInt(3, 1);
/*  941 */           pstmt.setLong(4, thread.getID());
/*  942 */           int updateCount = pstmt.executeUpdate();
/*      */ 
/*  945 */           if (updateCount == 0) {
/*  946 */             Log.error("Failed to update read count for thread: " + thread.getID() + ", user: " + this.userID + ", attempting insert");
/*      */ 
/*  949 */             pstmt.close();
/*  950 */             pstmt = con.prepareStatement("INSERT INTO jiveReadTracker (userID, objectType, objectID, readDate) VALUES (?,?,?,?)");
/*  951 */             pstmt.setLong(1, this.userID);
/*  952 */             pstmt.setInt(2, 1);
/*  953 */             pstmt.setLong(3, thread.getID());
/*  954 */             pstmt.setLong(4, readDate.longValue());
/*  955 */             pstmt.execute();
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  961 */         this.readThreads.put(key, readDate);
/*      */       }
/*      */       catch (SQLException sqle) {
/*  964 */         Log.error(sqle);
/*      */       }
/*      */       finally {
/*  967 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*  969 */       return true;
/*      */     }
/*      */ 
/*      */     public synchronized void markRead(Forum forum)
/*      */     {
/*  985 */       long modificationDate = forum.getModificationDate().getTime();
/*  986 */       final long date = getRoundedDate(modificationDate);
/*  987 */       final long forumID = forum.getID();
/*      */ 
/*  991 */       boolean insert = this.readForums.get(new Long(forumID)) == null;
/*      */ 
/*  993 */       this.readForums.put(new Long(forumID), new Long(date));
/*      */ 
/*  997 */       synchronized (DbReadTracker.insertQueue) {
/*  998 */         for (int i = DbReadTracker.insertQueue.size() - 1; i >= 0; i--) {
/*  999 */           long[] data = (long[])DbReadTracker.insertQueue.get(i);
/* 1000 */           if (this.userID == data[0])
/*      */           {
/*      */             try
/*      */             {
/* 1005 */               ForumMessage message = DbForumFactory.getInstance().getMessage(data[1]);
/* 1006 */               if ((message.getForumThread().getForum().getID() == forumID) && (data[2] <= date))
/*      */               {
/* 1009 */                 DbReadTracker.insertQueue.remove(i);
/*      */               }
/*      */             }
/*      */             catch (ForumMessageNotFoundException e)
/*      */             {
/* 1014 */               Log.error(e);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1018 */       synchronized (DbReadTracker.updateQueue) {
/* 1019 */         for (int i = DbReadTracker.updateQueue.size() - 1; i >= 0; i--) {
/* 1020 */           long[] data = (long[])DbReadTracker.updateQueue.get(i);
/* 1021 */           if (this.userID == data[0])
/*      */           {
/*      */             try
/*      */             {
/* 1025 */               ForumMessage message = DbForumFactory.getInstance().getMessage(data[1]);
/* 1026 */               if ((message.getForumThread().getForum().getID() == forumID) && (data[2] <= date))
/*      */               {
/* 1028 */                 DbReadTracker.updateQueue.remove(i);
/*      */               }
/*      */             }
/*      */             catch (ForumMessageNotFoundException e)
/*      */             {
/* 1033 */               Log.error(e);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1042 */       ResultFilter filter = ResultFilter.createDefaultMessageFilter();
/* 1043 */       filter.setModificationDateRangeMin(new Date(date));
/* 1044 */       Iterator messages = forum.getMessages(filter);
/* 1045 */       while (messages.hasNext()) {
/* 1046 */         ForumMessage message = (ForumMessage)messages.next();
/* 1047 */         if (message.getModificationDate().getTime() <= modificationDate) {
/* 1048 */           markRead(message);
/*      */         }
/*      */       }
/*      */ 
/* 1052 */       Connection con = null;
/* 1053 */       PreparedStatement pstmt = null;
/*      */       try {
/* 1055 */         con = ConnectionManager.getConnection();
/* 1056 */         if (insert) {
/* 1057 */           pstmt = con.prepareStatement("INSERT INTO jiveReadTracker (userID, objectType, objectID, readDate) VALUES (?,?,?,?)");
/* 1058 */           pstmt.setLong(1, this.userID);
/* 1059 */           pstmt.setInt(2, 0);
/* 1060 */           pstmt.setLong(3, forum.getID());
/* 1061 */           pstmt.setLong(4, date);
/*      */           try
/*      */           {
/* 1064 */             pstmt.execute();
/*      */           }
/*      */           catch (SQLException e)
/*      */           {
/* 1069 */             Log.error(e);
/*      */             try {
/* 1071 */               pstmt.close();
/*      */             }
/*      */             catch (Exception pe)
/*      */             {
/*      */             }
/* 1076 */             insert = false;
/*      */           }
/*      */         }
/*      */ 
/* 1080 */         if (!insert) {
/* 1081 */           pstmt = con.prepareStatement("UPDATE jiveReadTracker SET readDate=? WHERE userID=? AND objectType=? AND objectID=?");
/* 1082 */           pstmt.setLong(1, date);
/* 1083 */           pstmt.setLong(2, this.userID);
/* 1084 */           pstmt.setInt(3, 0);
/* 1085 */           pstmt.setLong(4, forum.getID());
/* 1086 */           pstmt.execute();
/*      */         }
/*      */       }
/*      */       catch (SQLException sqle) {
/* 1090 */         Log.error(sqle);
/*      */       }
/*      */       finally {
/* 1093 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*      */ 
/* 1098 */       Object updateTask = new Runnable() { private final long val$date;
/*      */         private final Forum val$forum;
/*      */         private final long val$forumID;
/*      */ 
/* 1102 */         public void run() { Connection con = null;
/* 1103 */           PreparedStatement pstmt = null;
/*      */           try
/*      */           {
/* 1106 */             con = ConnectionManager.getConnection();
/*      */ 
/* 1110 */             Date cutoffDate = new Date(date);
/*      */ 
/* 1113 */             if (ConnectionManager.isSubqueriesSupported()) {
/* 1114 */               ConnectionManager.disablePostgresTablescan(con);
/*      */               try {
/* 1116 */                 pstmt = con.prepareStatement("DELETE FROM jiveReadTracker WHERE userID=? AND objectType=1 AND readDate < ? AND objectID IN    (SELECT jt.threadID FROM jiveThread jt, jiveReadTracker jrt    WHERE jrt.objectType=1   AND jrt.objectID=jt.threadID AND jt.forumID=?)");
/* 1117 */                 pstmt.setLong(1, DbReadTracker.UserReadTracker.this.userID);
/* 1118 */                 pstmt.setLong(2, cutoffDate.getTime());
/* 1119 */                 pstmt.setLong(3, forumID.getID());
/* 1120 */                 pstmt.execute();
/* 1121 */                 pstmt.close();
/*      */ 
/* 1123 */                 pstmt = con.prepareStatement("DELETE FROM jiveReadTracker WHERE userID=? AND objectType=2 AND readDate < ? AND objectID IN    (SELECT jm.messageID FROM jiveMessage jm, jiveReadTracker jrt    WHERE jrt.objectType=2   AND jrt.objectID=jm.messageID AND jm.forumID=?)");
/* 1124 */                 pstmt.setLong(1, DbReadTracker.UserReadTracker.this.userID);
/* 1125 */                 pstmt.setLong(2, cutoffDate.getTime());
/* 1126 */                 pstmt.setLong(3, forumID.getID());
/* 1127 */                 pstmt.execute();
/* 1128 */                 pstmt.close();
/*      */               }
/*      */               finally
/*      */               {
/*      */               }
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/* 1137 */               LongList threadIDs = new LongList();
/* 1138 */               pstmt = con.prepareStatement("SELECT jrt.objectID FROM jiveReadTracker jrt, jiveThread jT WHERE jrt.userID=? AND objectType=1 AND objectID=jT.threadID AND jT.forumID=? AND readDate < ?");
/* 1139 */               pstmt.setLong(1, DbReadTracker.UserReadTracker.this.userID);
/* 1140 */               pstmt.setLong(2, forumID.getID());
/* 1141 */               pstmt.setLong(3, cutoffDate.getTime());
/* 1142 */               ResultSet rs = pstmt.executeQuery();
/* 1143 */               while (rs.next()) {
/* 1144 */                 threadIDs.add(rs.getLong(1));
/*      */               }
/* 1146 */               rs.close();
/* 1147 */               pstmt.close();
/*      */ 
/* 1150 */               StringBuffer sql = new StringBuffer();
/* 1151 */               sql.append("DELETE FROM jiveReadTracker WHERE userID=").append(DbReadTracker.UserReadTracker.this.userID);
/* 1152 */               sql.append(" AND objectType=").append(1);
/* 1153 */               sql.append(" AND objectID IN");
/* 1154 */               ConnectionManager.batchDeleteWithoutSubqueries(con, sql.toString(), threadIDs.toArray());
/*      */ 
/* 1156 */               threadIDs.clear();
/*      */ 
/* 1159 */               LongList messageIDs = new LongList();
/* 1160 */               pstmt = con.prepareStatement("SELECT jrt.objectID FROM jiveReadTracker jrt, jiveMessage jM WHERE jrt.userID=? AND objectType=2 AND objectID=jM.messageID AND jM.forumID=? AND readDate < ?");
/* 1161 */               pstmt.setLong(1, DbReadTracker.UserReadTracker.this.userID);
/* 1162 */               pstmt.setLong(2, forumID.getID());
/* 1163 */               pstmt.setLong(3, cutoffDate.getTime());
/* 1164 */               rs = pstmt.executeQuery();
/* 1165 */               while (rs.next()) {
/* 1166 */                 messageIDs.add(rs.getLong(1));
/*      */               }
/* 1168 */               rs.close();
/* 1169 */               pstmt.close();
/*      */ 
/* 1172 */               sql = new StringBuffer();
/* 1173 */               sql.append("DELETE FROM jiveReadTracker WHERE userID=").append(DbReadTracker.UserReadTracker.this.userID);
/* 1174 */               sql.append(" AND objectType=").append(2);
/* 1175 */               sql.append(" AND objectID IN");
/* 1176 */               ConnectionManager.batchDeleteWithoutSubqueries(con, sql.toString(), messageIDs.toArray());
/*      */ 
/* 1178 */               messageIDs.clear();
/*      */             }
/*      */           }
/*      */           catch (SQLException sqle)
/*      */           {
/* 1183 */             Log.error(sqle);
/*      */           }
/*      */           finally {
/* 1186 */             ConnectionManager.closeConnection(con);
/*      */           }
/*      */ 
/* 1191 */           Iterator keys = DbReadTracker.UserReadTracker.this.readThreads.keySet().iterator();
/* 1192 */           while (keys.hasNext()) {
/* 1193 */             DbReadTracker.ReadTrackerKey key = (DbReadTracker.ReadTrackerKey)keys.next();
/* 1194 */             long readDate = ((Long)DbReadTracker.UserReadTracker.this.readThreads.get(key)).longValue();
/*      */ 
/* 1197 */             if ((key.getForumID() == this.val$forumID) && (readDate <= date)) {
/* 1198 */               keys.remove();
/*      */             }
/*      */           }
/*      */ 
/* 1202 */           keys = DbReadTracker.UserReadTracker.this.readMessages.keySet().iterator();
/* 1203 */           while (keys.hasNext()) {
/* 1204 */             DbReadTracker.ReadTrackerKey key = (DbReadTracker.ReadTrackerKey)keys.next();
/* 1205 */             long readDate = ((Long)DbReadTracker.UserReadTracker.this.readMessages.get(key)).longValue();
/*      */ 
/* 1208 */             if ((key.getForumID() == this.val$forumID) && (readDate <= date))
/* 1209 */               keys.remove();
/*      */           }
/*      */         }
/*      */       };
/* 1214 */       TaskEngine.addTask((Runnable)updateTask);
/*      */     }
/*      */ 
/*      */     public int getCachedSize()
/*      */     {
/* 1220 */       int size = 0;
/* 1221 */       size += CacheSizes.sizeOfObject();
/* 1222 */       size += CacheSizes.sizeOfLong();
/* 1223 */       size += this.readThreads.size() * CacheSizes.sizeOfLong() * 3;
/* 1224 */       size += this.readMessages.size() * CacheSizes.sizeOfLong() * 3;
/* 1225 */       size += this.readForums.size() * CacheSizes.sizeOfLong() * 3;
/* 1226 */       return size;
/*      */     }
/*      */ 
/*      */     private static long getRoundedDate(long date)
/*      */     {
/* 1238 */       Calendar cal = Calendar.getInstance();
/* 1239 */       cal.setTime(new Date(date));
/*      */ 
/* 1241 */       if (cal.get(11) > 12) {
/* 1242 */         cal.set(11, 12);
/*      */       }
/*      */       else {
/* 1245 */         cal.set(11, 0);
/*      */       }
/* 1247 */       cal.set(12, 0);
/* 1248 */       cal.set(13, 0);
/* 1249 */       cal.set(14, 0);
/* 1250 */       return cal.getTime().getTime();
/*      */     }
/*      */ 
/*      */     private void loadReadsFromDb()
/*      */     {
/* 1257 */       Connection con = null;
/* 1258 */       PreparedStatement pstmt = null;
/*      */       try {
/* 1260 */         con = ConnectionManager.getConnection();
/*      */ 
/* 1263 */         pstmt = con.prepareStatement("SELECT objectID, readDate FROM jiveReadTracker WHERE userID=? AND objectType=0");
/* 1264 */         pstmt.setLong(1, this.userID);
/* 1265 */         ResultSet rs = pstmt.executeQuery();
/* 1266 */         while (rs.next()) {
/* 1267 */           long forumID = rs.getLong(1);
/* 1268 */           long readDate = Long.parseLong(rs.getString(2).trim());
/* 1269 */           this.readForums.put(new Long(forumID), new Long(readDate));
/*      */         }
/* 1271 */         rs.close();
/* 1272 */         pstmt.close();
/*      */ 
/* 1275 */         pstmt = con.prepareStatement("SELECT objectID, forumID, readDate FROM jiveReadTracker, jiveThread WHERE jiveReadTracker.userID=? AND objectType=1 AND objectID=threadID");
/* 1276 */         pstmt.setLong(1, this.userID);
/* 1277 */         rs = pstmt.executeQuery();
/* 1278 */         while (rs.next()) {
/* 1279 */           long threadID = rs.getLong(1);
/* 1280 */           long forumID = rs.getLong(2);
/* 1281 */           long readDate = Long.parseLong(rs.getString(3).trim());
/* 1282 */           DbReadTracker.ReadTrackerKey key = new DbReadTracker.ReadTrackerKey(threadID, forumID);
/* 1283 */           this.readThreads.put(key, new Long(readDate));
/*      */         }
/* 1285 */         rs.close();
/* 1286 */         pstmt.close();
/*      */ 
/* 1289 */         pstmt = con.prepareStatement("SELECT objectID, forumID, readDate FROM jiveReadTracker, jiveMessage WHERE jiveReadTracker.userID=? AND objectType=2 AND objectID=messageID");
/* 1290 */         pstmt.setLong(1, this.userID);
/* 1291 */         rs = pstmt.executeQuery();
/* 1292 */         while (rs.next()) {
/* 1293 */           long messageID = rs.getLong(1);
/* 1294 */           long forumID = rs.getLong(2);
/* 1295 */           long readDate = Long.parseLong(rs.getString(3).trim());
/* 1296 */           DbReadTracker.ReadTrackerKey key = new DbReadTracker.ReadTrackerKey(messageID, forumID);
/* 1297 */           this.readMessages.put(key, new Long(readDate));
/*      */         }
/* 1299 */         rs.close();
/*      */       }
/*      */       catch (SQLException sqle) {
/* 1302 */         Log.error(sqle);
/*      */       }
/*      */       finally {
/* 1305 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class ReadTrackerKey
/*      */     implements Cacheable, ExternalizableLite
/*      */   {
/*      */     private long objectID;
/*      */     private long forumID;
/*      */ 
/*      */     public ReadTrackerKey(long objectID, long forumID)
/*      */     {
/*  668 */       this.objectID = objectID;
/*  669 */       this.forumID = forumID;
/*      */     }
/*      */ 
/*      */     public ReadTrackerKey()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void readExternal(DataInput in) throws IOException {
/*  677 */       this.objectID = ExternalizableHelper.readLong(in);
/*  678 */       this.forumID = ExternalizableHelper.readLong(in);
/*      */     }
/*      */ 
/*      */     public void writeExternal(DataOutput out) throws IOException {
/*  682 */       ExternalizableHelper.writeLong(out, this.objectID);
/*  683 */       ExternalizableHelper.writeLong(out, this.forumID);
/*      */     }
/*      */ 
/*      */     public long getObjectID() {
/*  687 */       return this.objectID;
/*      */     }
/*      */ 
/*      */     public long getForumID() {
/*  691 */       return this.forumID;
/*      */     }
/*      */ 
/*      */     public int getCachedSize()
/*      */     {
/*  697 */       int size = 0;
/*  698 */       size += CacheSizes.sizeOfObject();
/*  699 */       size += CacheSizes.sizeOfLong() * 2;
/*  700 */       return size;
/*      */     }
/*      */ 
/*      */     public boolean equals(Object obj) {
/*  704 */       if (this == obj) {
/*  705 */         return true;
/*      */       }
/*  707 */       if ((obj instanceof ReadTrackerKey)) {
/*  708 */         ReadTrackerKey otherKey = (ReadTrackerKey)obj;
/*  709 */         return (this.objectID == otherKey.objectID) && (this.forumID == otherKey.forumID);
/*      */       }
/*      */ 
/*  712 */       return false;
/*      */     }
/*      */ 
/*      */     public int hashCode() {
/*  716 */       return toString().hashCode();
/*      */     }
/*      */ 
/*      */     public String toString() {
/*  720 */       return this.objectID + ", " + this.forumID;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class UnreadIterator
/*      */     implements Iterator
/*      */   {
/*      */     private int objectType;
/*      */     private Iterator iterator;
/*  589 */     private Object nextElement = null;
/*      */     private DbReadTracker.UserReadTracker userTracker;
/*      */ 
/*      */     public UnreadIterator(int objectType, Iterator iterator, DbReadTracker.UserReadTracker userTracker)
/*      */     {
/*  593 */       this.objectType = objectType;
/*  594 */       this.iterator = iterator;
/*  595 */       this.userTracker = userTracker;
/*      */     }
/*      */ 
/*      */     public boolean hasNext()
/*      */     {
/*  601 */       if ((!this.iterator.hasNext()) && (this.nextElement == null)) {
/*  602 */         return false;
/*      */       }
/*      */ 
/*  606 */       if (this.nextElement == null) {
/*  607 */         this.nextElement = getNextElement();
/*  608 */         if (this.nextElement == null) {
/*  609 */           return false;
/*      */         }
/*      */       }
/*  612 */       return true;
/*      */     }
/*      */ 
/*      */     public Object next() throws NoSuchElementException {
/*  616 */       Object element = null;
/*  617 */       if (this.nextElement != null) {
/*  618 */         element = this.nextElement;
/*  619 */         this.nextElement = null;
/*      */       }
/*      */       else {
/*  622 */         element = getNextElement();
/*  623 */         if (element == null) {
/*  624 */           throw new NoSuchElementException();
/*      */         }
/*      */       }
/*  627 */       return element;
/*      */     }
/*      */ 
/*      */     public void remove() throws UnsupportedOperationException {
/*  631 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Object getNextElement()
/*      */     {
/*  641 */       while (this.iterator.hasNext()) {
/*  642 */         switch (this.objectType) {
/*      */         case 1:
/*  644 */           ForumThread thread = (ForumThread)this.iterator.next();
/*  645 */           if (this.userTracker.getReadStatus(thread) != 2) {
/*  646 */             return thread;
/*      */           }
/*      */           break;
/*      */         case 2:
/*  650 */           ForumMessage message = (ForumMessage)this.iterator.next();
/*  651 */           if (this.userTracker.getReadStatus(message) != 2) {
/*  652 */             return message;
/*      */           }
/*      */           break;
/*      */         }
/*      */       }
/*      */ 
/*  658 */       return null;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbReadTracker
 * JD-Core Version:    0.6.2
 */
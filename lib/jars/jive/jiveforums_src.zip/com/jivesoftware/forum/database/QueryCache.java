/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.CachedPreparedStatement;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.database.ConnectionManager.DatabaseType;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.CoherenceCache;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import com.tangosol.net.AbstractInvocable;
/*     */ import com.tangosol.net.CacheService;
/*     */ import com.tangosol.util.ConcurrentMap;
/*     */ import com.tangosol.util.ExternalizableLite;
/*     */ import com.tangosol.util.MapEvent;
/*     */ import com.tangosol.util.MapListener;
/*     */ import com.tangosol.util.WrapperConcurrentMap;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class QueryCache
/*     */   implements Cache
/*     */ {
/*  51 */   private static BackingCache backingInstance = new BackingCache(null);
/*     */   public static final int BLOCK_SIZE = 400;
/*  59 */   private static final long[] EMPTY_BLOCK = new long[0];
/*     */ 
/*  72 */   private static ConcurrentMap mapSemaphore = new WrapperConcurrentMap(new HashMap());
/*     */   private Cache cache;
/*     */ 
/*     */   public static Cache getBackingInstance()
/*     */   {
/*  62 */     return backingInstance;
/*     */   }
/*     */ 
/*     */   public QueryCache(Cache cache)
/*     */   {
/*  85 */     this.cache = cache;
/*     */ 
/*  87 */     cache.setMaxCacheSize(-1);
/*     */   }
/*     */ 
/*     */   protected static long[] getBlock(CachedPreparedStatement cachedPstmt, int objectType, long objectID, int startIndex, boolean useCache)
/*     */   {
/* 102 */     int blockID = startIndex / 400;
/* 103 */     int blockStart = blockID * 400;
/*     */ 
/* 105 */     QueryCacheKey key = new QueryCacheKey(objectType, objectID, cachedPstmt, blockID);
/*     */ 
/* 109 */     StringBuffer internKey = new StringBuffer().append(cachedPstmt.hashCode()).append(blockID);
/* 110 */     synchronized (internKey.toString().intern())
/*     */     {
/* 112 */       long[] objectIDs = null;
/* 113 */       if (useCache) {
/* 114 */         objectIDs = (long[])DbForumFactory.getInstance().cacheManager.queryGet(key);
/*     */       }
/*     */ 
/* 117 */       if (objectIDs != null)
/*     */       {
/* 125 */         if (startIndex >= blockStart + objectIDs.length)
/*     */         {
/* 127 */           return EMPTY_BLOCK;
/*     */         }
/*     */ 
/* 130 */         return objectIDs;
/*     */       }
/*     */ 
/* 135 */       String sql = cachedPstmt.getSQL();
/*     */ 
/* 138 */       if (ConnectionManager.getDatabaseType() == ConnectionManager.DatabaseType.MYSQL) {
/* 139 */         sql = sql + " LIMIT " + blockStart + "," + 400;
/*     */       }
/* 143 */       else if (ConnectionManager.getDatabaseType() == ConnectionManager.DatabaseType.POSTGRES) {
/* 144 */         sql = sql + " LIMIT 400 OFFSET " + blockStart;
/*     */       }
/*     */ 
/* 147 */       LongList objectList = new LongList(400);
/* 148 */       Connection con = null;
/* 149 */       PreparedStatement pstmt = null;
/*     */       try {
/* 151 */         con = ConnectionManager.getConnection();
/* 152 */         pstmt = ConnectionManager.createScrollablePreparedStatement(con, sql);
/* 153 */         cachedPstmt.setParams(pstmt);
/*     */ 
/* 157 */         if ((ConnectionManager.getDatabaseType() != ConnectionManager.DatabaseType.MYSQL) && (ConnectionManager.getDatabaseType() != ConnectionManager.DatabaseType.POSTGRES))
/*     */         {
/* 160 */           ConnectionManager.setMaxRows(pstmt, 400 * (blockID + 1));
/*     */         }
/* 162 */         ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 164 */         ConnectionManager.setFetchSize(rs, 400);
/*     */ 
/* 168 */         if ((ConnectionManager.getDatabaseType() != ConnectionManager.DatabaseType.MYSQL) && (ConnectionManager.getDatabaseType() != ConnectionManager.DatabaseType.POSTGRES))
/*     */         {
/* 171 */           ConnectionManager.scrollResultSet(rs, blockStart);
/*     */         }
/*     */ 
/* 175 */         count = 0;
/* 176 */         while ((rs.next()) && (count < 400)) {
/* 177 */           objectList.add(rs.getLong(1));
/* 178 */           count++;
/*     */         }
/* 180 */         rs.close();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 183 */         Log.error(sqle);
/*     */ 
/* 185 */         int count = objectList.toArray();
/*     */ 
/* 188 */         ConnectionManager.closeConnection(pstmt, con);
/* 189 */         return count;
/*     */       }
/*     */       finally
/*     */       {
/* 188 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/* 190 */       objectIDs = objectList.toArray();
/*     */ 
/* 192 */       if (useCache) {
/* 193 */         DbForumFactory.getInstance().cacheManager.queryPut(key, objectIDs);
/*     */       }
/*     */ 
/* 202 */       if (startIndex >= blockStart + objectIDs.length)
/*     */       {
/* 204 */         return EMPTY_BLOCK;
/*     */       }
/*     */ 
/* 207 */       return objectIDs;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static int getCount(QueryCacheKey key, boolean useCache)
/*     */   {
/* 219 */     CachedPreparedStatement cachedPstmt = key.getSQL();
/*     */ 
/* 223 */     StringBuffer internKey = new StringBuffer().append(cachedPstmt.hashCode());
/* 224 */     internKey.append(key.getSQL()).append(key.getBlockID());
/* 225 */     synchronized (internKey.toString().intern()) {
/* 226 */       Integer count = null;
/* 227 */       if (useCache) {
/* 228 */         count = (Integer)DbForumFactory.getInstance().cacheManager.queryGet(key);
/*     */       }
/*     */ 
/* 231 */       if (count != null) {
/* 232 */         return count.intValue();
/*     */       }
/*     */ 
/* 236 */       Connection con = null;
/* 237 */       PreparedStatement pstmt = null;
/*     */       try {
/* 239 */         con = ConnectionManager.getConnection();
/* 240 */         pstmt = con.prepareStatement(cachedPstmt.getSQL());
/* 241 */         cachedPstmt.setParams(pstmt);
/* 242 */         ResultSet rs = pstmt.executeQuery();
/* 243 */         rs.next();
/* 244 */         count = new Integer(rs.getInt(1));
/* 245 */         rs.close();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 248 */         Log.error(sqle);
/* 249 */         int i = 0;
/*     */ 
/* 252 */         ConnectionManager.closeConnection(pstmt, con);
/* 253 */         return i;
/*     */       }
/*     */       finally
/*     */       {
/* 252 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */ 
/* 255 */       if (useCache) {
/* 256 */         DbForumFactory.getInstance().cacheManager.queryPut(key, count);
/*     */       }
/* 258 */       return count.intValue();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void remove(int objectType, long objectID)
/*     */   {
/* 312 */     String idKey = getIDKey(objectType, objectID);
/* 313 */     boolean removedLocally = removeLocal(idKey, true);
/* 314 */     if ((removedLocally) && (CacheFactory.isClusteringEnabled()))
/*     */     {
/* 316 */       CacheFactory.doClusterTask(new CacheDeleteTask(idKey), null, true);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean removeLocal(final String idKey, boolean waitForLock)
/*     */   {
/* 335 */     boolean itemsRemoved = false;
/*     */ 
/* 337 */     if (waitForLock) {
/* 338 */       mapSemaphore.lock(idKey, -1L);
/*     */     }
/* 343 */     else if (!mapSemaphore.lock(idKey)) {
/* 344 */       TaskEngine.addTask(2, new Runnable() { private final String val$idKey;
/*     */ 
/* 346 */         public void run() { DbForumFactory.getInstance().cacheManager.queryCache.removeLocal(idKey, true); }
/*     */ 
/*     */       });
/* 349 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 353 */       boolean shortTermEnabled = DbForumFactory.getInstance().cacheManager.isShortTermQueryCacheEnabled();
/* 354 */       List queryKeys = (List)backingInstance.idMap.get(idKey);
/* 355 */       if (queryKeys != null) {
/* 356 */         Object[] listElements = null;
/* 357 */         synchronized (queryKeys) {
/* 358 */           listElements = queryKeys.toArray();
/*     */         }
/*     */ 
/* 361 */         int i = 0; for (int n = listElements.length; i < n; i++) {
/* 362 */           Object queryKey = listElements[i];
/*     */ 
/* 364 */           if (queryKey != null)
/*     */           {
/* 369 */             if ((shortTermEnabled) && (!DbForumFactory.getInstance().cacheManager.shortTermQueryCache.containsKey(queryKey)))
/*     */             {
/* 372 */               Object value = this.cache.get(queryKey);
/* 373 */               if (value != null) {
/* 374 */                 DbForumFactory.getInstance().cacheManager.shortTermQueryCache.put(queryKey, new ShortTermQueryCache.ValueWrapper(value));
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/* 379 */             backingInstance.remove(queryKey);
/* 380 */             itemsRemoved = true;
/*     */           }
/*     */         }
/*     */       }
/*     */     } finally {
/* 385 */       mapSemaphore.unlock(idKey);
/*     */     }
/* 387 */     return itemsRemoved;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 393 */     return this.cache.getName();
/*     */   }
/*     */ 
/*     */   public int getMaxCacheSize() {
/* 397 */     return this.cache.getMaxCacheSize();
/*     */   }
/*     */ 
/*     */   public void setMaxCacheSize(int maxSize)
/*     */   {
/*     */   }
/*     */ 
/*     */   public long getMaxLifetime()
/*     */   {
/* 406 */     return this.cache.getMaxLifetime();
/*     */   }
/*     */ 
/*     */   public void setMaxLifetime(long maxLifetime) {
/* 410 */     this.cache.setMaxLifetime(maxLifetime);
/*     */   }
/*     */ 
/*     */   public int getCacheSize() {
/* 414 */     return this.cache.getCacheSize();
/*     */   }
/*     */ 
/*     */   public long getCacheHits() {
/* 418 */     return this.cache.getCacheHits();
/*     */   }
/*     */ 
/*     */   public long getCacheMisses() {
/* 422 */     return this.cache.getCacheMisses();
/*     */   }
/*     */ 
/*     */   public int size() {
/* 426 */     return this.cache.size();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/* 430 */     return this.cache.isEmpty();
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key) {
/* 434 */     return this.cache.containsKey(key);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value) {
/* 438 */     return this.cache.containsValue(value);
/*     */   }
/*     */ 
/*     */   public Object get(Object key) {
/* 442 */     Object value = this.cache.get(key);
/* 443 */     if ((value == null) && (DbForumFactory.getInstance().cacheManager.isShortTermQueryCacheEnabled())) {
/* 444 */       value = DbForumFactory.getInstance().cacheManager.shortTermQueryCache.get(key);
/* 445 */       if (value != null) {
/* 446 */         value = ((ShortTermQueryCache.ValueWrapper)value).getValue();
/*     */       }
/*     */     }
/* 449 */     return value;
/*     */   }
/*     */ 
/*     */   public Object put(Object key, Object value) {
/* 453 */     QueryCacheKey qKey = (QueryCacheKey)key;
/* 454 */     String idKey = getIDKey(qKey.getObjectType(), qKey.getObjectID());
/*     */ 
/* 456 */     mapSemaphore.lock(idKey, -1L);
/*     */     try {
/* 458 */       return this.cache.put(key, value);
/*     */     }
/*     */     finally
/*     */     {
/* 462 */       mapSemaphore.unlock(idKey);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object remove(Object key) {
/* 467 */     QueryCacheKey qKey = (QueryCacheKey)key;
/* 468 */     String idKey = getIDKey(qKey.getObjectType(), qKey.getObjectID());
/*     */ 
/* 470 */     mapSemaphore.lock(idKey, -1L);
/*     */     try {
/* 472 */       return this.cache.remove(key);
/*     */     }
/*     */     finally
/*     */     {
/* 476 */       mapSemaphore.unlock(idKey);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void putAll(Map t) {
/* 481 */     this.cache.putAll(t);
/*     */   }
/*     */ 
/*     */   public void clear() {
/* 485 */     this.cache.clear();
/*     */   }
/*     */ 
/*     */   public Set keySet() {
/* 489 */     return this.cache.keySet();
/*     */   }
/*     */ 
/*     */   public Collection values() {
/* 493 */     return this.cache.values();
/*     */   }
/*     */ 
/*     */   public Set entrySet() {
/* 497 */     return this.cache.entrySet();
/*     */   }
/*     */ 
/*     */   private static String getIDKey(int objectType, long objectID) {
/* 501 */     return objectType + "," + objectID;
/*     */   }
/*     */ 
/*     */   protected static final class BackingCache extends CoherenceCache
/*     */     implements MapListener
/*     */   {
/*     */     protected Map idMap;
/*     */ 
/*     */     private BackingCache()
/*     */     {
/* 527 */       super(-1, -1L);
/* 528 */       this.idMap = new Hashtable();
/*     */ 
/* 530 */       addMapListener(this);
/*     */     }
/*     */ 
/*     */     public void entryInserted(MapEvent event) {
/* 534 */       QueryCacheKey qKey = (QueryCacheKey)event.getKey();
/* 535 */       String idKey = QueryCache.getIDKey(qKey.getObjectType(), qKey.getObjectID());
/*     */ 
/* 538 */       List queryKeys = (List)this.idMap.get(idKey);
/*     */ 
/* 540 */       if (queryKeys == null) {
/* 541 */         queryKeys = new ArrayList();
/* 542 */         this.idMap.put(idKey, queryKeys);
/*     */       }
/* 544 */       synchronized (queryKeys)
/*     */       {
/* 546 */         queryKeys.add(qKey);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void entryUpdated(MapEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void entryDeleted(MapEvent event) {
/* 555 */       QueryCacheKey key = (QueryCacheKey)event.getKey();
/* 556 */       String idKey = QueryCache.getIDKey(key.getObjectType(), key.getObjectID());
/*     */ 
/* 559 */       List queryKeys = (List)this.idMap.get(idKey);
/*     */ 
/* 561 */       if (queryKeys != null)
/* 562 */         synchronized (queryKeys)
/*     */         {
/* 564 */           queryKeys.remove(key);
/*     */ 
/* 566 */           if (queryKeys.isEmpty())
/* 567 */             this.idMap.remove(idKey);
/*     */         }
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 574 */       super.clear();
/* 575 */       this.idMap.clear();
/*     */     }
/*     */ 
/*     */     BackingCache(QueryCache.1 x0)
/*     */     {
/* 512 */       this();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class CacheDeleteTask extends AbstractInvocable
/*     */     implements ExternalizableLite
/*     */   {
/*     */     private String idKey;
/*     */ 
/*     */     public CacheDeleteTask(String idKey)
/*     */     {
/* 276 */       this.idKey = idKey;
/*     */     }
/*     */ 
/*     */     public CacheDeleteTask()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void readExternal(DataInput in) throws IOException
/*     */     {
/* 285 */       this.idKey = in.readUTF();
/*     */     }
/*     */ 
/*     */     public void writeExternal(DataOutput out) throws IOException {
/* 289 */       out.writeUTF(this.idKey);
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 294 */       DbForumFactory factory = DbForumFactory.getInstance();
/*     */ 
/* 298 */       if (CacheFactory.getOptimisticCacheService().isRunning())
/* 299 */         factory.cacheManager.queryCache.removeLocal(this.idKey, false);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.QueryCache
 * JD-Core Version:    0.6.2
 */
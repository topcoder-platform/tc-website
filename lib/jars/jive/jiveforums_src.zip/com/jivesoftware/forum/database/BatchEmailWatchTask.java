/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.AuthFactory;
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.log.JiveLogImpl;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.WatchManager;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.EmailTask;
/*     */ import com.jivesoftware.util.JiveVelocityResourceLoader;
/*     */ import com.jivesoftware.util.LocaleUtils;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ import org.apache.velocity.tools.generic.DateTool;
/*     */ 
/*     */ public class BatchEmailWatchTask
/*     */   implements Runnable, Serializable
/*     */ {
/*     */   private long userID;
/*     */   public static final String DEFAULT_DIGEST_SUBJECT = "Forum Watch Digest for $dateTool.format('short_date', $endDate, $userLocale, $userTimeZone)";
/*     */   public static final String DEFAULT_DIGEST_BODY = "Hello $user.getName(),\n\nThe following updates have been made since $dateTool.format('short', $startDate, $userLocale, $userTimeZone)\n\n#if (!$watchedThreads.isEmpty())\n## the watchedThreads is a map which maps a Long(threadID) -> a List of ForumMessage objects\n#foreach ($threadID in $watchedThreads.keySet())\n\nTopic \"$forumFactory.getForumThread($threadID).getName()\" has been updated #if($watchedThreads.get($threadID).size() == 1)one time #else$watchedThreads.get($threadID).size() times #end\n\n#foreach ($message in $watchedThreads.get($threadID))\n    $jiveURL/thread.jspa?messageID=$message.getID()#$message.getID()\n#end\n#end\n#end\n\n#if (!$watchedForums.isEmpty())\n## the watchedForums is a map which maps a Long(forumID) -> a List of ForumMessage objects\n#foreach ($forumID in $watchedForums.keySet())\n\nForum \"$forumFactory.getForum($forumID).getName()\" has been updated #if($watchedForums.get($forumID).size() == 1)one time #else$watchedForums.get($forumID).size() times #end\n\n#foreach ($message in $watchedForums.get($forumID))\n\n    \"$message.getSubject()\" was created on $dateTool.format('short', $message.getCreationDate(), $userLocale, $userTimeZone)\n    $jiveURL/thread.jspa?messageID=$message.getID()#$message.getID()\n#end\n#end\n#end\n\n#if (!$watchedCategories.isEmpty())\n## the watchedCategories is a map which maps a Long(categoryID) -> a List of ForumMessage objects\n#foreach ($categoryID in $watchedCategories.keySet())\n\nCategory \"$forumFactory.getForumCategory($categoryID).getName()\" has been updated #if($watchedCategories.get($categoryID).size() == 1)one time #else$watchedCategories.get($categoryID).size() times #end\n\n#foreach ($message in $watchedCategories.get($categoryID))\n\n    \"$message.getSubject()\" was created on $dateTool.format('short', $message.getCreationDate(), $userLocale, $userTimeZone)\n    $jiveURL/thread.jspa?messageID=$message.getID()#$message.getID()\n#end\n#end\n#end\n\n#if (!$watchedUsers.isEmpty())\n## the watchedUsers is a map which maps a Long(userID) -> a List of ForumMessage objects\n#foreach ($userID in $watchedUsers.keySet())\n\nUser \"$forumFactory.getUserManager().getUser($userID).getUsername()\" has created #if($watchedUsers.get($userID).size() == 1)one new message #else$watchedUsers.get($userID).size() new messages #end\n\n#foreach ($message in $watchedUsers.get($userID))\n\n    \"$message.getSubject()\" was created on $dateTool.format('short', $message.getCreationDate(), $userLocale, $userTimeZone)\n    $jiveURL/thread.jspa?messageID=$message.getID()#$message.getID()\n#end\n#end\n#end";
/*     */   private static final String GET_DATE = "SELECT prevEmailDate FROM jiveBatchWatch WHERE userID=?";
/*     */   private static final String SET_DATE = "UPDATE jiveBatchWatch SET prevEmailDate=? WHERE userID=?";
/*  98 */   private static VelocityEngine ve = new VelocityEngine();
/*     */ 
/*     */   public BatchEmailWatchTask()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BatchEmailWatchTask(long userID)
/*     */   {
/* 123 */     this.userID = userID;
/*     */   }
/*     */ 
/*     */   public long getUserID() {
/* 127 */     return this.userID;
/*     */   }
/*     */ 
/*     */   public void setUserID(long userID) {
/* 131 */     this.userID = userID;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 138 */     Log.debug("Running batch email watch task for user " + this.userID);
/*     */ 
/* 141 */     if (!CacheFactory.isSeniorClusterMember()) {
/* 142 */       Log.debug("Stopping batch email watch task for user " + this.userID + " - not master cluster member");
/*     */ 
/* 144 */       return;
/*     */     }
/*     */ 
/* 147 */     Date now = new Date();
/* 148 */     Date previousEmailDate = getPreviousEmailDate();
/*     */ 
/* 154 */     if (now.getTime() - previousEmailDate.getTime() < 3600000L) {
/* 155 */       Log.debug("Stopping batch email watch task for user " + this.userID + " - less than 1 hour has passed since previous batch run for this user.");
/*     */ 
/* 157 */       return;
/*     */     }
/*     */ 
/* 162 */     savePreviousEmailDate(now);
/*     */ 
/* 165 */     if (!JiveGlobals.getJiveBooleanProperty("watches.emailNotifyEnabled", true)) {
/* 166 */       Log.debug("Stopping batch email watch task for user " + this.userID + " - email notification is globally disabled.");
/*     */ 
/* 168 */       return;
/*     */     }
/*     */ 
/* 173 */     if (!JiveGlobals.getJiveBooleanProperty("watches.digestEmailNotifyEnabled", true)) {
/* 174 */       Log.debug("Stopping batch email watch task for user " + this.userID + " - digest email notification is globally disabled.");
/*     */ 
/* 176 */       return;
/*     */     }
/*     */ 
/* 180 */     ForumFactory factory = ForumFactory.getInstance(new DummyAuthToken(this.userID));
/*     */     User user;
/*     */     try {
/* 183 */       user = factory.getUserManager().getUser(this.userID);
/*     */     }
/*     */     catch (UserNotFoundException e) {
/* 186 */       Log.error(e);
/* 187 */       return; } 
/*     */ DbForumFactory dbfactory = DbForumFactory.getInstance();
/* 191 */     boolean allowSelfEmails = JiveGlobals.getJiveBooleanProperty("watches.allowSelfUpdates");
/*     */ 
/* 193 */     HashMap watchedThreads = new HashMap();
/* 194 */     HashMap watchedForums = new HashMap();
/* 195 */     HashMap watchedCategories = new HashMap();
/* 196 */     HashMap watchedUsers = new HashMap();
/*     */ 
/* 201 */     ResultFilter filter = new ResultFilter();
/* 202 */     filter.setModificationDateRangeMin(ResultFilter.roundDate(previousEmailDate, 3600000));
/* 203 */     filter.setSortField(9);
/* 204 */     filter.setSortOrder(1);
/*     */ 
/* 206 */     WatchManager watchManager = dbfactory.getWatchManager();
/*     */ 
/* 210 */     Collection allMessages = new ArrayList();
/*     */     Iterator watches;
/*     */     try { watches = watchManager.getAllWatches(user, 1);
/* 215 */       while (watches.hasNext()) {
/* 216 */         ForumThread thread = (ForumThread)watches.next();
/* 217 */         ArrayList list = new ArrayList();
/* 218 */         for (Iterator i = thread.getMessages(filter); i.hasNext(); ) {
/* 219 */           ForumMessage msg = (ForumMessage)i.next();
/* 220 */           Long messageID = new Long(msg.getID());
/*     */ 
/* 222 */           if ((allowSelfEmails) || (msg.isAnonymous()) || (msg.getUser().getID() != user.getID()))
/*     */           {
/* 225 */             if (!list.contains(messageID)) {
/* 226 */               list.add(msg);
/* 227 */               allMessages.add(messageID);
/*     */             }
/*     */           }
/*     */         }
/* 231 */         if (!list.isEmpty())
/* 232 */           watchedThreads.put(new Long(thread.getID()), list);
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 237 */       Log.error(e);
/*     */     }
/*     */ 
/* 242 */     Set categoryWatchedForums = new HashSet();
/*     */     try
/*     */     {
/* 246 */       watches = watchManager.getAllWatches(user, 14);
/* 247 */       while (watches.hasNext()) {
/* 248 */         ForumCategory category = (ForumCategory)watches.next();
/* 249 */         for (Iterator i = category.getRecursiveForums(); i.hasNext(); ) {
/* 250 */           categoryWatchedForums.add(i.next());
/*     */         }
/* 252 */         ArrayList list = new ArrayList();
/* 253 */         for (Iterator i = category.getMessages(filter); i.hasNext(); ) {
/* 254 */           ForumMessage msg = (ForumMessage)i.next();
/* 255 */           Long messageID = new Long(msg.getID());
/*     */ 
/* 257 */           if ((allowSelfEmails) || (msg.isAnonymous()) || (msg.getUser().getID() != user.getID()))
/*     */           {
/* 260 */             if ((!list.contains(messageID)) && (!allMessages.contains(messageID))) {
/* 261 */               list.add(msg);
/* 262 */               allMessages.add(messageID);
/*     */             }
/*     */           }
/*     */         }
/* 265 */         if (!list.isEmpty())
/* 266 */           watchedCategories.put(new Long(category.getID()), list);
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 271 */       Log.error(e);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 276 */       watches = watchManager.getAllWatches(user, 0);
/* 277 */       while (watches.hasNext()) {
/* 278 */         Forum forum = (Forum)watches.next();
/*     */ 
/* 281 */         if (!categoryWatchedForums.contains(forum)) {
/* 282 */           ArrayList list = new ArrayList();
/* 283 */           for (Iterator i = forum.getMessages(filter); i.hasNext(); ) {
/* 284 */             ForumMessage msg = (ForumMessage)i.next();
/* 285 */             Long messageID = new Long(msg.getID());
/*     */ 
/* 287 */             if ((allowSelfEmails) || (msg.isAnonymous()) || (msg.getUser().getID() != user.getID()))
/*     */             {
/* 290 */               if ((!list.contains(messageID)) && (!allMessages.contains(messageID))) {
/* 291 */                 list.add(msg);
/* 292 */                 allMessages.add(messageID);
/*     */               }
/*     */             }
/*     */           }
/* 295 */           if (!list.isEmpty())
/* 296 */             watchedForums.put(new Long(forum.getID()), list);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 302 */       Log.error(e);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 307 */       watches = watchManager.getAllWatches(user, 3);
/* 308 */       while (watches.hasNext()) {
/* 309 */         User u = (User)watches.next();
/* 310 */         ArrayList list = new ArrayList();
/* 311 */         for (Iterator i = dbfactory.getUserMessages(u); i.hasNext(); ) {
/* 312 */           ForumMessage msg = (ForumMessage)i.next();
/* 313 */           Long messageID = new Long(msg.getID());
/*     */ 
/* 315 */           if ((allowSelfEmails) || (msg.isAnonymous()) || (msg.getUser().getID() != user.getID()))
/*     */           {
/* 318 */             if ((!list.contains(messageID)) && (!allMessages.contains(messageID))) {
/* 319 */               list.add(msg);
/* 320 */               allMessages.add(messageID);
/*     */             }
/*     */           }
/*     */         }
/* 324 */         if (!list.isEmpty())
/* 325 */           watchedUsers.put(new Long(u.getID()), list);
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 330 */       Log.error(e);
/*     */     }
/*     */ 
/* 334 */     if ((watchedThreads.isEmpty()) && (watchedForums.isEmpty()) && (watchedCategories.isEmpty()) && (watchedUsers.isEmpty()))
/*     */     {
/* 336 */       Log.debug("Stopping batch email watch task for user " + this.userID + " - no updated content.");
/*     */ 
/* 338 */       return;
/*     */     }
/*     */ 
/* 342 */     String toName = user.getName();
/* 343 */     String toEmail = user.getEmail();
/* 344 */     String fromEmail = getFromEmail();
/* 345 */     String fromName = getFromName();
/* 346 */     String subject = getSubject();
/* 347 */     String body = getBody();
/*     */     try
/*     */     {
/* 352 */       Map context = new HashMap();
/* 353 */       context.put("watchedThreads", watchedThreads);
/* 354 */       context.put("watchedForums", watchedForums);
/* 355 */       context.put("watchedCategories", watchedCategories);
/* 356 */       context.put("watchedUsers", watchedUsers);
/*     */ 
/* 359 */       context.put("user", user);
/* 360 */       context.put("username", user.getUsername());
/* 361 */       context.put("email", user.getEmail());
/* 362 */       context.put("name", user.getName() == null ? user.getUsername() : user.getName());
/* 363 */       context.put("userID", Long.toString(user.getID()));
/*     */ 
/* 365 */       context.put("jiveURL", JiveGlobals.getJiveProperty("jiveURL"));
/* 366 */       context.put("forumFactory", factory);
/* 367 */       context.put("userTimeZone", LocaleUtils.getTimeZone(null, user));
/* 368 */       context.put("userLocale", LocaleUtils.getUserLocale(null, user));
/* 369 */       context.put("startDate", previousEmailDate);
/* 370 */       context.put("endDate", now);
/*     */ 
/* 373 */       context.put("dateTool", new DateTool());
/* 374 */       VelocityContext velContext = new VelocityContext(context);
/*     */ 
/* 377 */       Writer sw = new StringWriter();
/* 378 */       ve.evaluate(velContext, sw, "digestEmailWatch", subject);
/* 379 */       subject = sw.toString();
/*     */ 
/* 382 */       sw = new StringWriter();
/* 383 */       ve.evaluate(velContext, sw, "digestEmailWatch", body);
/* 384 */       body = sw.toString();
/*     */     }
/*     */     catch (Exception e) {
/* 387 */       Log.error(e);
/* 388 */       return;
/*     */     }
/*     */ 
/* 392 */     EmailTask emailTask = new EmailTask();
/* 393 */     emailTask.addMessage(toName, toEmail, fromName, fromEmail, subject, body, null);
/* 394 */     emailTask.run();
/*     */   }
/*     */ 
/*     */   private Date getPreviousEmailDate() {
/* 398 */     Connection con = null;
/* 399 */     PreparedStatement pstmt = null;
/*     */     try {
/* 401 */       con = ConnectionManager.getConnection();
/* 402 */       pstmt = con.prepareStatement("SELECT prevEmailDate FROM jiveBatchWatch WHERE userID=?");
/* 403 */       pstmt.setLong(1, this.userID);
/* 404 */       ResultSet rs = pstmt.executeQuery();
/* 405 */       if (rs.next()) {
/* 406 */         return new Date(rs.getLong(1));
/*     */       }
/* 408 */       rs.close();
/*     */     }
/*     */     catch (SQLException e) {
/* 411 */       Log.error(e);
/*     */     }
/*     */     finally {
/* 414 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 417 */     return new Date(System.currentTimeMillis() - 86400000L);
/*     */   }
/*     */ 
/*     */   private void savePreviousEmailDate(Date date) {
/* 421 */     Connection con = null;
/* 422 */     PreparedStatement pstmt = null;
/*     */     try {
/* 424 */       con = ConnectionManager.getConnection();
/* 425 */       pstmt = con.prepareStatement("UPDATE jiveBatchWatch SET prevEmailDate=? WHERE userID=?");
/* 426 */       pstmt.setLong(1, date.getTime());
/* 427 */       pstmt.setLong(2, this.userID);
/* 428 */       pstmt.execute();
/*     */     }
/*     */     catch (SQLException e) {
/* 431 */       Log.error(e);
/*     */     }
/*     */     finally {
/* 434 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getFromEmail()
/*     */   {
/* 444 */     if (JiveGlobals.getJiveProperty("watches.email.forumdigest.fromEmail") != null) {
/* 445 */       return JiveGlobals.getJiveProperty("watches.email.forumdigest.fromEmail");
/*     */     }
/* 447 */     if (JiveGlobals.getJiveProperty("watches.email.fromEmail") != null) {
/* 448 */       return JiveGlobals.getJiveProperty("watches.email.fromEmail");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 453 */       AuthToken anonAuthToken = AuthFactory.getAnonymousAuthToken();
/* 454 */       User user = ForumFactory.getInstance(anonAuthToken).getUserManager().getUser("admin");
/* 455 */       if (user.getEmail() != null)
/* 456 */         return user.getEmail();
/*     */     }
/*     */     catch (UserNotFoundException e)
/*     */     {
/* 460 */       Log.error(e);
/*     */     }
/*     */ 
/* 464 */     return null;
/*     */   }
/*     */ 
/*     */   private String getFromName()
/*     */   {
/* 473 */     if (JiveGlobals.getJiveProperty("watches.email.forumdigest.fromName") != null) {
/* 474 */       return JiveGlobals.getJiveProperty("watches.email.forumdigest.fromName");
/*     */     }
/* 476 */     if (JiveGlobals.getJiveProperty("watches.email.fromName") != null) {
/* 477 */       return JiveGlobals.getJiveProperty("watches.email.fromName");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 482 */       AuthToken anonAuthToken = AuthFactory.getAnonymousAuthToken();
/* 483 */       User user = ForumFactory.getInstance(anonAuthToken).getUserManager().getUser("admin");
/* 484 */       if (user.getName() != null)
/* 485 */         return user.getName();
/*     */     }
/*     */     catch (UserNotFoundException e)
/*     */     {
/* 489 */       Log.error(e);
/*     */     }
/*     */ 
/* 493 */     return "Jive Adminstrator";
/*     */   }
/*     */ 
/*     */   private String getSubject() {
/* 497 */     String subject = JiveGlobals.getJiveProperty("watches.email.forumdigest.subject");
/*     */ 
/* 499 */     if (subject == null) {
/* 500 */       subject = "Forum Watch Digest for $dateTool.format('short_date', $endDate, $userLocale, $userTimeZone)";
/*     */     }
/*     */ 
/* 503 */     return subject;
/*     */   }
/*     */ 
/*     */   private String getBody() {
/* 507 */     String body = JiveGlobals.getJiveProperty("watches.email.forumdigest.body");
/*     */ 
/* 509 */     if (body == null) {
/* 510 */       body = "Hello $user.getName(),\n\nThe following updates have been made since $dateTool.format('short', $startDate, $userLocale, $userTimeZone)\n\n#if (!$watchedThreads.isEmpty())\n## the watchedThreads is a map which maps a Long(threadID) -> a List of ForumMessage objects\n#foreach ($threadID in $watchedThreads.keySet())\n\nTopic \"$forumFactory.getForumThread($threadID).getName()\" has been updated #if($watchedThreads.get($threadID).size() == 1)one time #else$watchedThreads.get($threadID).size() times #end\n\n#foreach ($message in $watchedThreads.get($threadID))\n    $jiveURL/thread.jspa?messageID=$message.getID()#$message.getID()\n#end\n#end\n#end\n\n#if (!$watchedForums.isEmpty())\n## the watchedForums is a map which maps a Long(forumID) -> a List of ForumMessage objects\n#foreach ($forumID in $watchedForums.keySet())\n\nForum \"$forumFactory.getForum($forumID).getName()\" has been updated #if($watchedForums.get($forumID).size() == 1)one time #else$watchedForums.get($forumID).size() times #end\n\n#foreach ($message in $watchedForums.get($forumID))\n\n    \"$message.getSubject()\" was created on $dateTool.format('short', $message.getCreationDate(), $userLocale, $userTimeZone)\n    $jiveURL/thread.jspa?messageID=$message.getID()#$message.getID()\n#end\n#end\n#end\n\n#if (!$watchedCategories.isEmpty())\n## the watchedCategories is a map which maps a Long(categoryID) -> a List of ForumMessage objects\n#foreach ($categoryID in $watchedCategories.keySet())\n\nCategory \"$forumFactory.getForumCategory($categoryID).getName()\" has been updated #if($watchedCategories.get($categoryID).size() == 1)one time #else$watchedCategories.get($categoryID).size() times #end\n\n#foreach ($message in $watchedCategories.get($categoryID))\n\n    \"$message.getSubject()\" was created on $dateTool.format('short', $message.getCreationDate(), $userLocale, $userTimeZone)\n    $jiveURL/thread.jspa?messageID=$message.getID()#$message.getID()\n#end\n#end\n#end\n\n#if (!$watchedUsers.isEmpty())\n## the watchedUsers is a map which maps a Long(userID) -> a List of ForumMessage objects\n#foreach ($userID in $watchedUsers.keySet())\n\nUser \"$forumFactory.getUserManager().getUser($userID).getUsername()\" has created #if($watchedUsers.get($userID).size() == 1)one new message #else$watchedUsers.get($userID).size() new messages #end\n\n#foreach ($message in $watchedUsers.get($userID))\n\n    \"$message.getSubject()\" was created on $dateTool.format('short', $message.getCreationDate(), $userLocale, $userTimeZone)\n    $jiveURL/thread.jspa?messageID=$message.getID()#$message.getID()\n#end\n#end\n#end";
/*     */     }
/*     */ 
/* 513 */     return body;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 518 */     if (this == o) {
/* 519 */       return true;
/*     */     }
/* 521 */     if (!(o instanceof BatchEmailWatchTask)) {
/* 522 */       return false;
/*     */     }
/*     */ 
/* 525 */     BatchEmailWatchTask batchEmailWatchTask = (BatchEmailWatchTask)o;
/*     */ 
/* 527 */     if (this.userID != batchEmailWatchTask.userID) {
/* 528 */       return false;
/*     */     }
/*     */ 
/* 531 */     return true;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 535 */     return (int)(this.userID ^ this.userID >>> 32);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/* 103 */       ve.setProperty("resource.loader", "jive");
/* 104 */       ve.setProperty("jive.resource.loader.public.name", "Jive");
/* 105 */       ve.setProperty("jive.resource.loader.description", " Jive Velocity Resource Loader");
/* 106 */       ve.setProperty("jive.resource.loader.class", JiveVelocityResourceLoader.class.getName());
/* 107 */       ve.setProperty("velocimacro.library", "");
/* 108 */       ve.setProperty("runtime.log.logsystem.class", JiveLogImpl.class.getName());
/* 109 */       ve.init();
/*     */     }
/*     */     catch (Exception e) {
/* 112 */       Log.error("Exception in creating VelocityEngine.", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DummyAuthToken
/*     */     implements AuthToken, Serializable
/*     */   {
/*     */     private long userID;
/*     */ 
/*     */     public DummyAuthToken(long userID)
/*     */     {
/* 546 */       this.userID = userID;
/*     */     }
/*     */ 
/*     */     public long getUserID() {
/* 550 */       return this.userID;
/*     */     }
/*     */ 
/*     */     public boolean isAnonymous() {
/* 554 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.BatchEmailWatchTask
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.JiveManager;
/*     */ import com.jivesoftware.base.LicenseManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.database.CachedPreparedStatement;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.event.UserEvent;
/*     */ import com.jivesoftware.base.event.UserEventDispatcher;
/*     */ import com.jivesoftware.base.event.UserListener;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.Question;
/*     */ import com.jivesoftware.forum.Question.State;
/*     */ import com.jivesoftware.forum.QuestionFilter;
/*     */ import com.jivesoftware.forum.QuestionFilter.SortField;
/*     */ import com.jivesoftware.forum.QuestionManager;
/*     */ import com.jivesoftware.forum.event.ForumEvent;
/*     */ import com.jivesoftware.forum.event.ForumEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ForumListener;
/*     */ import com.jivesoftware.forum.event.MessageEvent;
/*     */ import com.jivesoftware.forum.event.MessageEventDispatcher;
/*     */ import com.jivesoftware.forum.event.MessageListener;
/*     */ import com.jivesoftware.forum.event.QuestionEvent;
/*     */ import com.jivesoftware.forum.event.QuestionEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ThreadEvent;
/*     */ import com.jivesoftware.forum.event.ThreadEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ThreadListener;
/*     */ import com.jivesoftware.forum.expert.OpenQuestionMonitor;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DbQuestionManager
/*     */   implements QuestionManager, JiveManager
/*     */ {
/*     */   private static final String DELETE_QUESTION = "DELETE FROM jiveQuestion WHERE threadID=?";
/*     */   private static final String DELETE_ANSWERS = "DELETE FROM jiveQuestion WHERE threadID=?";
/*     */   private static final String DELETE_QUESTIONS_BY_FORUM = "DELETE FROM jiveQuestion WHERE forumID=?";
/*     */   private static final String DELETE_ANSWERS_BY_FORUM = "DELETE FROM jiveAnswer WHERE forumID=?";
/*     */   private static final String MOVE_QUESTIONS_BY_FORUM = "UPDATE jiveQuestion SET forumID=? WHERE forumID=?";
/*     */   private static final String MOVE_ANSWERS_BY_FORUM = "UPDATE jiveAnswer SET forumID=? WHERE forumID=?";
/*     */   private static final String CLEAR_USER_FROM_QUESTIONS = "UPDATE jiveQuestion SET userID=-1 WHERE userID=?";
/*     */   private static final String CLEAR_USER_FROM_ANSWERS = "UPDATE jiveAnswer SET userID=-1 WHERE userID=?";
/*     */   private static final String DELETE_QUESTION_BY_THREAD = "DELETE FROM jiveQuestion WHERE threadID=?";
/*     */   private static final String DELETE_ANSWERS_BY_THREAD = "DELETE from jiveAnswer WHERE threadID=?";
/*     */   private static final String DELETE_ANSWER_BY_MESSAGE = "DELETE from jiveAnswer WHERE messageID=?";
/*     */   private static final String UPDATE_QUESTION_FORUM = "UPDATE jiveQuestion SET forumID=? WHERE threadID=?";
/*     */   private static final String UPDATE_ANSWER_FORUM = "UPDATE jiveAnswer SET forumID=? WHERE threadID=?";
/*     */   private static final String UPDATE_ANSWER_THREAD = "UPDATE jiveAnswer SET threadID=?, forumID=? WHERE messageID=?";
/*     */   private static DbForumFactory FACTORY;
/*  66 */   private static DbQuestionManager instance = new DbQuestionManager();
/*  67 */   private static boolean initialized = false;
/*     */   private static final String NULL_QUESTION = "null";
/*  71 */   private static final QuestionFilter DEFAULT_FILTER = new QuestionFilter();
/*     */ 
/*     */   public static DbQuestionManager getInstance() {
/*  74 */     return instance;
/*     */   }
/*     */ 
/*     */   private DbQuestionManager() {
/*  78 */     LicenseManager.validateLicense("Jive Forums Expert Edition", "4.2");
/*     */   }
/*     */ 
/*     */   public synchronized void initialize() {
/*  82 */     if (!initialized) {
/*  83 */       FACTORY = DbForumFactory.getInstance();
/*     */ 
/*  85 */       OpenQuestionMonitor.getInstance();
/*     */ 
/*  88 */       QuestionEventListener listener = new QuestionEventListener(null);
/*  89 */       UserEventDispatcher.getInstance().addListener(listener);
/*  90 */       ForumEventDispatcher.getInstance().addListener(listener);
/*  91 */       ThreadEventDispatcher.getInstance().addListener(listener);
/*  92 */       MessageEventDispatcher.getInstance().addListener(listener);
/*  93 */       initialized = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getHelpfulAnswersPerThread() {
/*  98 */     return 2;
/*     */   }
/*     */ 
/*     */   public void setHelpfulAnswersPerThread(int count)
/*     */   {
/*     */   }
/*     */ 
/*     */   public Question getQuestion(ForumThread thread) throws NotFoundException {
/* 106 */     return getQuestion(thread.getID());
/*     */   }
/*     */ 
/*     */   public Question getQuestion(long threadID) throws NotFoundException {
/* 110 */     Object question = FACTORY.cacheManager.questionCache.get(new Long(threadID));
/*     */ 
/* 112 */     if (question == null) {
/*     */       try {
/* 114 */         question = new DbQuestion(threadID);
/* 115 */         FACTORY.cacheManager.questionCache.put(new Long(threadID), question);
/*     */       }
/*     */       catch (NotFoundException nfe)
/*     */       {
/* 119 */         FACTORY.cacheManager.questionCache.put(new Long(threadID), "null");
/* 120 */         throw nfe;
/*     */       }
/*     */     }
/* 123 */     else if (question.equals("null")) {
/* 124 */       throw new NotFoundException();
/*     */     }
/* 126 */     return (Question)question;
/*     */   }
/*     */ 
/*     */   public boolean hasQuestion(ForumThread thread) {
/* 130 */     Object question = FACTORY.cacheManager.questionCache.get(new Long(thread.getID()));
/*     */ 
/* 132 */     if (question != null) {
/* 133 */       if (question.equals("null")) {
/* 134 */         return false;
/*     */       }
/*     */ 
/* 137 */       return true;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 142 */       getQuestion(thread);
/* 143 */       return true;
/*     */     } catch (NotFoundException ignored) {
/*     */     }
/* 146 */     return false;
/*     */   }
/*     */ 
/*     */   public Question createQuestion(ForumThread thread) throws UnauthorizedException
/*     */   {
/*     */     try
/*     */     {
/* 153 */       getQuestion(thread);
/* 154 */       throw new IllegalArgumentException("Question already exists for thread " + thread);
/*     */     }
/*     */     catch (NotFoundException nfe)
/*     */     {
/* 159 */       Question question = new DbQuestion(thread);
/* 160 */       FACTORY.cacheManager.questionCache.put(new Long(thread.getID()), question);
/*     */ 
/* 163 */       QuestionEvent event = new QuestionEvent(160, question, Collections.EMPTY_MAP);
/*     */ 
/* 165 */       QuestionEventDispatcher.getInstance().dispatchEvent(event);
/*     */ 
/* 167 */       expireQueryCache(question);
/* 168 */       return question;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteQuestion(Question question) {
/* 173 */     QuestionEvent event = new QuestionEvent(161, question, Collections.EMPTY_MAP);
/*     */ 
/* 175 */     QuestionEventDispatcher.getInstance().dispatchEvent(event);
/*     */ 
/* 177 */     long threadID = question.getForumThread().getID();
/* 178 */     Connection con = null;
/* 179 */     PreparedStatement pstmt = null;
/* 180 */     boolean abortTransaction = false;
/*     */     try {
/* 182 */       con = ConnectionManager.getTransactionConnection();
/* 183 */       pstmt = con.prepareStatement("DELETE FROM jiveQuestion WHERE threadID=?");
/* 184 */       pstmt.setLong(1, question.getForumThread().getID());
/* 185 */       pstmt.execute();
/* 186 */       pstmt.close();
/*     */ 
/* 188 */       pstmt = con.prepareStatement("DELETE FROM jiveQuestion WHERE threadID=?");
/* 189 */       pstmt.setLong(1, threadID);
/* 190 */       pstmt.execute();
/*     */     }
/*     */     catch (SQLException e) {
/* 193 */       Log.error(e);
/* 194 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 197 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */ 
/* 200 */     FACTORY.cacheManager.questionCache.remove(new Long(threadID));
/* 201 */     expireQueryCache(question);
/*     */   }
/*     */ 
/*     */   public int getQuestionCount() {
/* 205 */     return getQuestionCount(DEFAULT_FILTER);
/*     */   }
/*     */ 
/*     */   public int getQuestionCount(QuestionFilter questionFilter) {
/* 209 */     CachedPreparedStatement sql = getQuestionListSQL(30, -1L, questionFilter, true);
/*     */ 
/* 211 */     QueryCacheKey key = new QueryCacheKey(30, -1L, sql, -1);
/*     */ 
/* 213 */     return QueryCache.getCount(key, true);
/*     */   }
/*     */ 
/*     */   public int getQuestionCount(ForumCategory category) {
/* 217 */     return getQuestionCount(category, DEFAULT_FILTER);
/*     */   }
/*     */ 
/*     */   public int getQuestionCount(ForumCategory category, QuestionFilter questionFilter) {
/* 221 */     CachedPreparedStatement sql = getQuestionListSQL(29, category.getID(), questionFilter, true);
/*     */ 
/* 223 */     QueryCacheKey key = new QueryCacheKey(29, category.getID(), sql, -1);
/*     */ 
/* 225 */     return QueryCache.getCount(key, true);
/*     */   }
/*     */ 
/*     */   public int getQuestionCount(Forum forum) {
/* 229 */     return getQuestionCount(forum, DEFAULT_FILTER);
/*     */   }
/*     */ 
/*     */   public int getQuestionCount(Forum forum, QuestionFilter questionFilter) {
/* 233 */     CachedPreparedStatement sql = getQuestionListSQL(28, forum.getID(), questionFilter, true);
/*     */ 
/* 235 */     QueryCacheKey key = new QueryCacheKey(28, forum.getID(), sql, -1);
/* 236 */     return QueryCache.getCount(key, true);
/*     */   }
/*     */ 
/*     */   public Iterator getQuestions() {
/* 240 */     return getQuestions(DEFAULT_FILTER);
/*     */   }
/*     */ 
/*     */   public Iterator getQuestions(QuestionFilter questionFilter) {
/* 244 */     CachedPreparedStatement query = getQuestionListSQL(30, -1L, questionFilter, false);
/*     */ 
/* 246 */     long[] questionBlock = QueryCache.getBlock(query, 30, -1L, questionFilter.getStartIndex(), true);
/*     */ 
/* 248 */     int startIndex = questionFilter.getStartIndex();
/*     */     int endIndex;
/*     */     int endIndex;
/* 252 */     if (questionFilter.getNumResults() == 2147483524) {
/* 253 */       endIndex = getQuestionCount(questionFilter);
/*     */     }
/*     */     else {
/* 256 */       endIndex = questionFilter.getNumResults() + startIndex;
/*     */     }
/* 258 */     return new QuestionBlockIterator(questionBlock, query, startIndex, endIndex, 17, -1L);
/*     */   }
/*     */ 
/*     */   public Iterator getQuestions(ForumCategory category)
/*     */   {
/* 263 */     return getQuestions(category, DEFAULT_FILTER);
/*     */   }
/*     */ 
/*     */   public Iterator getQuestions(ForumCategory category, QuestionFilter questionFilter) {
/* 267 */     CachedPreparedStatement query = getQuestionListSQL(29, category.getID(), questionFilter, false);
/*     */ 
/* 269 */     long[] questionBlock = QueryCache.getBlock(query, 29, category.getID(), questionFilter.getStartIndex(), true);
/*     */ 
/* 271 */     int startIndex = questionFilter.getStartIndex();
/*     */     int endIndex;
/*     */     int endIndex;
/* 275 */     if (questionFilter.getNumResults() == 2147483524) {
/* 276 */       endIndex = getQuestionCount(category, questionFilter);
/*     */     }
/*     */     else {
/* 279 */       endIndex = questionFilter.getNumResults() + startIndex;
/*     */     }
/* 281 */     return new QuestionBlockIterator(questionBlock, query, startIndex, endIndex, 29, category.getID());
/*     */   }
/*     */ 
/*     */   public Iterator getQuestions(Forum forum)
/*     */   {
/* 286 */     return getQuestions(forum, DEFAULT_FILTER);
/*     */   }
/*     */ 
/*     */   public Iterator getQuestions(Forum forum, QuestionFilter questionFilter) {
/* 290 */     CachedPreparedStatement query = getQuestionListSQL(28, forum.getID(), questionFilter, false);
/*     */ 
/* 292 */     long[] questionBlock = QueryCache.getBlock(query, 28, forum.getID(), questionFilter.getStartIndex(), true);
/*     */ 
/* 294 */     int startIndex = questionFilter.getStartIndex();
/*     */     int endIndex;
/*     */     int endIndex;
/* 298 */     if (questionFilter.getNumResults() == 2147483524) {
/* 299 */       endIndex = getQuestionCount(forum, questionFilter);
/*     */     }
/*     */     else {
/* 302 */       endIndex = questionFilter.getNumResults() + startIndex;
/*     */     }
/* 304 */     return new QuestionBlockIterator(questionBlock, query, startIndex, endIndex, 0, forum.getID());
/*     */   }
/*     */ 
/*     */   static void expireQueryCache(Question question)
/*     */   {
/* 314 */     FACTORY.cacheManager.queryRemove(30, -1L);
/* 315 */     Forum forum = question.getForumThread().getForum();
/* 316 */     FACTORY.cacheManager.queryRemove(28, forum.getID());
/* 317 */     ForumCategory category = forum.getForumCategory();
/* 318 */     FACTORY.cacheManager.queryRemove(29, category.getID());
/* 319 */     while ((category = category.getParentCategory()) != null)
/* 320 */       FACTORY.cacheManager.queryRemove(29, category.getID());
/*     */   }
/*     */ 
/*     */   protected CachedPreparedStatement getQuestionListSQL(int objectType, long objectID, QuestionFilter questionFilter, boolean countQuery)
/*     */   {
/* 331 */     QuestionFilter.SortField sortField = questionFilter.getSortField();
/*     */ 
/* 333 */     CachedPreparedStatement pstmt = new CachedPreparedStatement();
/* 334 */     StringBuffer query = new StringBuffer(80);
/* 335 */     if (!countQuery) {
/* 336 */       query.append("SELECT jiveQuestion.threadID");
/*     */     }
/*     */     else {
/* 339 */       query.append("SELECT count(*)");
/*     */     }
/*     */ 
/* 342 */     boolean filterUser = questionFilter.getUserID() != 2147483524L;
/* 343 */     boolean filterCreationDate = (questionFilter.getCreationDateRangeMin() != null) || (questionFilter.getCreationDateRangeMax() != null);
/*     */ 
/* 345 */     boolean filterResolutionDate = (questionFilter.getResolutionDateRangeMin() != null) || (questionFilter.getResolutionDateRangeMax() != null);
/*     */ 
/* 347 */     int propertyCount = questionFilter.getPropertyCount();
/*     */ 
/* 350 */     if (!countQuery) {
/* 351 */       if (sortField == QuestionFilter.SortField.resolution_state) {
/* 352 */         query.append(", jiveQuestion.resolutionState");
/*     */       }
/* 354 */       else if (sortField == QuestionFilter.SortField.resolution_date) {
/* 355 */         query.append(", jiveQuestion.resolutionDate");
/*     */       }
/* 357 */       else if (sortField == QuestionFilter.SortField.creation_date) {
/* 358 */         query.append(", jiveQuestion.creationDate");
/*     */       }
/* 360 */       else if (sortField == QuestionFilter.SortField.extended_property) {
/* 361 */         query.append(", propTable.propValue");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 366 */     query.append(" FROM jiveQuestion");
/* 367 */     for (int i = 0; i < propertyCount; i++) {
/* 368 */       query.append(", jiveQuestionProp p").append(i);
/*     */     }
/* 370 */     if (sortField == QuestionFilter.SortField.extended_property) {
/* 371 */       query.append(", jiveQuestionProp propTable");
/*     */     }
/* 373 */     if (objectType == 29) {
/* 374 */       query.append(", jiveForum, jiveCategory");
/*     */     }
/*     */ 
/* 378 */     boolean whereFlag = false;
/* 379 */     if (objectType == 28) {
/* 380 */       query.append(" WHERE forumID=?");
/* 381 */       pstmt.addLong(objectID);
/* 382 */       whereFlag = true;
/*     */     }
/* 384 */     else if (objectType == 29) {
/* 385 */       int[] lftRgt = DbForumCategory.getLftRgtValues(objectID);
/* 386 */       query.append(" WHERE jiveQuestion.forumID=jiveForum.forumID AND jiveForum.categoryID=jiveCategory.categoryID AND jiveCategory.lft>=? AND jiveCategory.rgt <=?");
/*     */ 
/* 389 */       pstmt.addInt(lftRgt[0]);
/* 390 */       pstmt.addInt(lftRgt[1]);
/* 391 */       whereFlag = true;
/*     */     }
/*     */ 
/* 394 */     if (filterUser) {
/* 395 */       if (!whereFlag) {
/* 396 */         query.append(" WHERE");
/* 397 */         whereFlag = true;
/*     */       }
/*     */       else {
/* 400 */         query.append(" AND");
/*     */       }
/* 402 */       query.append(" jiveQuestion.userID=?");
/* 403 */       pstmt.addLong(questionFilter.getUserID());
/*     */     }
/*     */ 
/* 406 */     for (int i = 0; i < propertyCount; i++) {
/* 407 */       if (!whereFlag) {
/* 408 */         query.append(" WHERE");
/* 409 */         whereFlag = true;
/*     */       }
/*     */       else {
/* 412 */         query.append(" AND");
/*     */       }
/* 414 */       query.append(" jiveQuestion.threadID=p").append(i).append(".threadID");
/* 415 */       query.append(" AND p").append(i).append(".name=?");
/* 416 */       pstmt.addString(questionFilter.getPropertyName(i));
/* 417 */       query.append(" AND p").append(i).append(".propValue=?");
/* 418 */       pstmt.addString(questionFilter.getPropertyValue(i));
/*     */     }
/*     */ 
/* 422 */     if ((questionFilter.getResolutionStates().size() != 4) && (questionFilter.getResolutionStates().size() != 0))
/*     */     {
/* 425 */       if (!whereFlag) {
/* 426 */         query.append(" WHERE (");
/* 427 */         whereFlag = true;
/*     */       }
/*     */       else {
/* 430 */         query.append(" AND (");
/*     */       }
/* 432 */       Iterator i = questionFilter.getResolutionStates().iterator();
/* 433 */       Question.State state = (Question.State)i.next();
/* 434 */       query.append("jiveQuestion.resolutionState=?");
/* 435 */       pstmt.addInt(state.getCode());
/* 436 */       while (i.hasNext()) {
/* 437 */         state = (Question.State)i.next();
/* 438 */         query.append(" OR jiveQuestion.resolutionState=?");
/* 439 */         pstmt.addInt(state.getCode());
/*     */       }
/* 441 */       query.append(")");
/*     */     }
/*     */ 
/* 444 */     if (sortField == QuestionFilter.SortField.extended_property) {
/* 445 */       if (!whereFlag) {
/* 446 */         query.append(" WHERE");
/* 447 */         whereFlag = true;
/*     */       }
/*     */       else {
/* 450 */         query.append(" AND");
/*     */       }
/* 452 */       query.append(" jiveQuestion.threadID=propTable.threadID");
/* 453 */       query.append(" AND propTable.name=?");
/* 454 */       pstmt.addString(questionFilter.getSortPropertyName());
/*     */     }
/*     */ 
/* 458 */     if (filterCreationDate) {
/* 459 */       if (questionFilter.getCreationDateRangeMin() != null) {
/* 460 */         if (!whereFlag) {
/* 461 */           query.append(" WHERE");
/* 462 */           whereFlag = true;
/*     */         }
/*     */         else {
/* 465 */           query.append(" AND");
/*     */         }
/* 467 */         query.append(" jiveQuestion.creationDate >= ?");
/* 468 */         pstmt.addLong(questionFilter.getCreationDateRangeMin().getTime());
/*     */       }
/* 470 */       if (questionFilter.getCreationDateRangeMax() != null) {
/* 471 */         if (!whereFlag) {
/* 472 */           query.append(" WHERE");
/* 473 */           whereFlag = true;
/*     */         }
/*     */         else {
/* 476 */           query.append(" AND");
/*     */         }
/* 478 */         query.append(" jiveQuestion.creationDate <= ?");
/* 479 */         pstmt.addLong(questionFilter.getCreationDateRangeMax().getTime());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 484 */     if (filterResolutionDate) {
/* 485 */       if (questionFilter.getResolutionDateRangeMin() != null) {
/* 486 */         if (!whereFlag) {
/* 487 */           query.append(" WHERE");
/* 488 */           whereFlag = true;
/*     */         }
/*     */         else {
/* 491 */           query.append(" AND");
/*     */         }
/* 493 */         query.append(" jiveQuestion.resolutionDate >= ?");
/* 494 */         pstmt.addLong(questionFilter.getResolutionDateRangeMin().getTime());
/*     */       }
/* 496 */       if (questionFilter.getResolutionDateRangeMax() != null) {
/* 497 */         if (!whereFlag) {
/* 498 */           query.append(" WHERE");
/* 499 */           whereFlag = true;
/*     */         }
/*     */         else {
/* 502 */           query.append(" AND");
/*     */         }
/* 504 */         query.append(" jiveQuestion.resolutionDate <= ?");
/* 505 */         pstmt.addLong(questionFilter.getResolutionDateRangeMax().getTime());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 510 */     if (!countQuery) {
/* 511 */       boolean hasPriorOrderBy = false;
/* 512 */       if (questionFilter.isGroupByForum()) {
/* 513 */         hasPriorOrderBy = true;
/* 514 */         query.append(" ORDER BY jiveQuestion.forumID");
/*     */       }
/*     */ 
/* 517 */       if (sortField == QuestionFilter.SortField.resolution_state) {
/* 518 */         query.append(hasPriorOrderBy ? ", " : " ORDER BY ");
/* 519 */         query.append(" jiveQuestion.resolutionState");
/*     */       }
/* 521 */       else if (sortField == QuestionFilter.SortField.resolution_date) {
/* 522 */         query.append(hasPriorOrderBy ? ", " : " ORDER BY ");
/* 523 */         query.append(" jiveQuestion.resolutionDate");
/*     */       }
/* 525 */       else if (sortField == QuestionFilter.SortField.creation_date) {
/* 526 */         query.append(hasPriorOrderBy ? ", " : " ORDER BY ");
/* 527 */         query.append(" jiveQuestion.creationDate");
/*     */       }
/* 529 */       else if (sortField == QuestionFilter.SortField.extended_property) {
/* 530 */         query.append(hasPriorOrderBy ? ", " : " ORDER BY ");
/* 531 */         query.append(" propTable.propValue");
/*     */       }
/*     */ 
/* 534 */       if (questionFilter.getSortOrder() == 0) {
/* 535 */         query.append(" DESC");
/*     */       }
/*     */       else {
/* 538 */         query.append(" ASC");
/*     */       }
/*     */     }
/*     */ 
/* 542 */     pstmt.setSQL(query.toString());
/* 543 */     return pstmt;
/*     */   }
/*     */ 
/*     */   private static class QuestionEventListener
/*     */     implements UserListener, ForumListener, ThreadListener, MessageListener
/*     */   {
/*     */     private QuestionEventListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void userCreated(UserEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void userDeleted(UserEvent event)
/*     */     {
/* 559 */       long userID = event.getUser().getID();
/*     */ 
/* 561 */       QuestionFilter filter = new QuestionFilter();
/* 562 */       filter.setUserID(userID);
/* 563 */       for (Iterator i = DbQuestionManager.getInstance().getQuestions(filter); i.hasNext(); ) {
/* 564 */         Question question = (Question)i.next();
/*     */         try
/*     */         {
/* 568 */           question.setState(Question.State.resolved);
/*     */         }
/*     */         catch (UnauthorizedException ue) {
/* 571 */           Log.error(ue);
/*     */         }
/*     */       }
/*     */ 
/* 575 */       Connection con = null;
/* 576 */       PreparedStatement pstmt = null;
/*     */       try {
/* 578 */         con = ConnectionManager.getConnection();
/* 579 */         pstmt = con.prepareStatement("UPDATE jiveAnswer SET userID=-1 WHERE userID=?");
/* 580 */         pstmt.setLong(1, userID);
/* 581 */         pstmt.execute();
/* 582 */         pstmt.close();
/*     */ 
/* 584 */         pstmt = con.prepareStatement("UPDATE jiveQuestion SET userID=-1 WHERE userID=?");
/* 585 */         pstmt.setLong(1, userID);
/* 586 */         pstmt.execute();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 589 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 592 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void userModified(UserEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void forumAdded(ForumEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void forumDeleted(ForumEvent event) {
/* 605 */       long forumID = event.getForum().getID();
/* 606 */       Connection con = null;
/* 607 */       PreparedStatement pstmt = null;
/*     */       try {
/* 609 */         con = ConnectionManager.getConnection();
/* 610 */         pstmt = con.prepareStatement("DELETE FROM jiveAnswer WHERE forumID=?");
/* 611 */         pstmt.setLong(1, forumID);
/* 612 */         pstmt.execute();
/* 613 */         pstmt.close();
/*     */ 
/* 615 */         pstmt = con.prepareStatement("DELETE FROM jiveQuestion WHERE forumID=?");
/* 616 */         pstmt.setLong(1, forumID);
/* 617 */         pstmt.executeUpdate();
/*     */       }
/*     */       catch (SQLException sqle)
/*     */       {
/* 625 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 628 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void forumMoved(ForumEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void forumMerged(ForumEvent event) {
/* 637 */       long newForumID = event.getForum().getID();
/* 638 */       long oldForumID = ((Long)event.getParams().get("mergedForumID")).longValue();
/* 639 */       Connection con = null;
/* 640 */       PreparedStatement pstmt = null;
/*     */       try {
/* 642 */         con = ConnectionManager.getConnection();
/* 643 */         pstmt = con.prepareStatement("UPDATE jiveAnswer SET forumID=? WHERE forumID=?");
/* 644 */         pstmt.setLong(1, newForumID);
/* 645 */         pstmt.setLong(2, oldForumID);
/* 646 */         pstmt.execute();
/* 647 */         pstmt.close();
/*     */ 
/* 649 */         pstmt = con.prepareStatement("UPDATE jiveQuestion SET forumID=? WHERE forumID=?");
/* 650 */         pstmt.setLong(1, newForumID);
/* 651 */         pstmt.setLong(2, oldForumID);
/* 652 */         pstmt.execute();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 655 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 658 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void threadAdded(ThreadEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void threadDeleted(ThreadEvent event)
/*     */     {
/* 668 */       if (!DbQuestionManager.getInstance().hasQuestion(event.getThread())) {
/* 669 */         return;
/*     */       }
/* 671 */       long threadID = event.getThread().getID();
/* 672 */       Connection con = null;
/* 673 */       PreparedStatement pstmt = null;
/*     */       try {
/* 675 */         con = ConnectionManager.getConnection();
/* 676 */         pstmt = con.prepareStatement("DELETE from jiveAnswer WHERE threadID=?");
/* 677 */         pstmt.setLong(1, threadID);
/* 678 */         pstmt.execute();
/* 679 */         pstmt.close();
/*     */ 
/* 681 */         pstmt = con.prepareStatement("DELETE FROM jiveQuestion WHERE threadID=?");
/* 682 */         pstmt.setLong(1, threadID);
/* 683 */         pstmt.execute();
/*     */ 
/* 686 */         DbQuestionManager.FACTORY.cacheManager.questionCache.remove(new Long(threadID));
/*     */       }
/*     */       catch (SQLException sqle) {
/* 689 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 692 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void threadMoved(ThreadEvent event)
/*     */     {
/* 698 */       if (!DbQuestionManager.getInstance().hasQuestion(event.getThread())) {
/* 699 */         return;
/*     */       }
/* 701 */       long threadID = event.getThread().getID();
/* 702 */       long forumID = event.getThread().getForum().getID();
/* 703 */       Connection con = null;
/* 704 */       PreparedStatement pstmt = null;
/*     */       try {
/* 706 */         con = ConnectionManager.getConnection();
/* 707 */         pstmt = con.prepareStatement("UPDATE jiveAnswer SET forumID=? WHERE threadID=?");
/* 708 */         pstmt.setLong(1, forumID);
/* 709 */         pstmt.setLong(2, threadID);
/* 710 */         pstmt.execute();
/* 711 */         pstmt.close();
/*     */ 
/* 713 */         pstmt = con.prepareStatement("UPDATE jiveQuestion SET forumID=? WHERE threadID=?");
/* 714 */         pstmt.setLong(1, forumID);
/* 715 */         pstmt.setLong(2, threadID);
/* 716 */         pstmt.execute();
/*     */ 
/* 719 */         DbQuestionManager.FACTORY.cacheManager.questionCache.remove(new Long(threadID));
/*     */       }
/*     */       catch (SQLException sqle) {
/* 722 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 725 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void threadModerationModified(ThreadEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void threadRated(ThreadEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void messageAdded(MessageEvent event)
/*     */     {
/* 741 */       ForumMessage message = event.getMessage();
/* 742 */       ForumThread thread = message.getForumThread();
/* 743 */       if (DbQuestionManager.getInstance().hasQuestion(thread))
/*     */         try {
/* 745 */           Question question = DbQuestionManager.getInstance().getQuestion(thread);
/* 746 */           if ((question.getState() == Question.State.open) && (
/* 747 */             (message.isAnonymous()) || (!message.getUser().equals(thread.getRootMessage().getUser()))))
/*     */           {
/* 750 */             question.setState(Question.State.possibly_resolved);
/*     */           }
/*     */         }
/*     */         catch (NotFoundException nfe) {
/*     */         }
/*     */         catch (UnauthorizedException ue) {
/*     */         }
/*     */     }
/*     */ 
/*     */     public void messageDeleted(MessageEvent event) {
/* 760 */       long messageID = event.getMessage().getID();
/* 761 */       ForumThread thread = event.getMessage().getForumThread();
/*     */ 
/* 763 */       if (!DbQuestionManager.getInstance().hasQuestion(thread)) {
/* 764 */         return;
/*     */       }
/* 766 */       Connection con = null;
/* 767 */       PreparedStatement pstmt = null;
/*     */       try {
/* 769 */         con = ConnectionManager.getConnection();
/* 770 */         pstmt = con.prepareStatement("DELETE from jiveAnswer WHERE messageID=?");
/* 771 */         pstmt.setLong(1, messageID);
/* 772 */         int count = pstmt.executeUpdate();
/* 773 */         if (count != 0)
/*     */         {
/* 775 */           DbQuestionManager.FACTORY.cacheManager.questionCache.remove(new Long(thread.getID()));
/*     */         }
/*     */       }
/*     */       catch (SQLException sqle) {
/* 779 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 782 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void messageMoved(MessageEvent event) {
/* 787 */       Connection con = null;
/* 788 */       PreparedStatement pstmt = null;
/*     */       try {
/* 790 */         con = ConnectionManager.getConnection();
/* 791 */         pstmt = con.prepareStatement("UPDATE jiveAnswer SET threadID=?, forumID=? WHERE messageID=?");
/* 792 */         pstmt.setLong(1, event.getMessage().getForumThread().getID());
/* 793 */         pstmt.setLong(2, event.getMessage().getForumThread().getForum().getID());
/* 794 */         pstmt.setLong(3, event.getMessage().getID());
/* 795 */         pstmt.execute();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 798 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 801 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void messageModified(MessageEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void messageModerationModified(MessageEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void messageRated(MessageEvent event)
/*     */     {
/*     */     }
/*     */ 
/*     */     QuestionEventListener(DbQuestionManager.1 x0)
/*     */     {
/* 551 */       this();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbQuestionManager
 * JD-Core Version:    0.6.2
 */
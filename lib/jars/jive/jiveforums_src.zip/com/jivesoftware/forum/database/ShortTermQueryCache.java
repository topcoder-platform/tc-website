/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.util.CoherenceCache;
/*     */ import com.jivesoftware.util.CoherenceCache.Entry;
/*     */ import com.tangosol.io.ExternalizableLite;
/*     */ import com.tangosol.net.Cluster;
/*     */ import com.tangosol.net.Member;
/*     */ import com.tangosol.util.Binary;
/*     */ import com.tangosol.util.ExternalizableHelper;
/*     */ import com.tangosol.util.SafeHashMap.Entry;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.Executor;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.Executors;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.Date;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ 
/*     */ public class ShortTermQueryCache extends CoherenceCache
/*     */ {
/*     */   private Timer timer;
/*     */   private Executor executor;
/*     */ 
/*     */   public ShortTermQueryCache(String name, int maxSize, long maxLifetime)
/*     */   {
/*  59 */     super(name, maxSize, maxLifetime);
/*  60 */     this.timer = new Timer(true);
/*  61 */     this.executor = Executors.newCachedThreadPool();
/*     */   }
/*     */ 
/*     */   public Executor getExecutor()
/*     */   {
/*  71 */     return this.executor;
/*     */   }
/*     */ 
/*     */   public SafeHashMap.Entry getEntry(Object key) {
/*  75 */     Entry entry = (Entry)super.getEntry(key);
/*  76 */     if (entry == null) {
/*  77 */       return null;
/*     */     }
/*     */ 
/*  95 */     if ((!entry.updateFlag) && (!(entry.getValue() instanceof Binary))) {
/*  96 */       ValueWrapper value = (ValueWrapper)entry.getValue();
/*     */ 
/*  99 */       if (value.getClusterMemberID() == getMemberID()) {
/* 100 */         entry.updateFlag = true;
/* 101 */         QueryCacheKey queryKey = (QueryCacheKey)key;
/* 102 */         long date = getMaxLifetime() + entry.getCreatedMillis();
/*     */ 
/* 104 */         final Runnable runnable = new QueryCacheUpdateTask(queryKey);
/*     */ 
/* 108 */         TimerTask timerTask = new TimerTask() { private final Runnable val$runnable;
/*     */ 
/* 110 */           public void run() { ShortTermQueryCache.this.executor.execute(runnable); }
/*     */ 
/*     */         };
/* 113 */         this.timer.schedule(timerTask, new Date(date));
/*     */       }
/*     */     }
/* 116 */     return entry;
/*     */   }
/*     */ 
/*     */   protected static int getMemberID()
/*     */   {
/* 125 */     if (!com.jivesoftware.util.CacheFactory.isClusteringEnabled()) {
/* 126 */       return 1;
/*     */     }
/*     */ 
/* 129 */     return com.tangosol.net.CacheFactory.ensureCluster().getLocalMember().getId();
/*     */   }
/*     */ 
/*     */   protected SafeHashMap.Entry instantiateEntry()
/*     */   {
/* 134 */     return new Entry();
/*     */   }
/*     */ 
/*     */   public static class ValueWrapper
/*     */     implements ExternalizableLite
/*     */   {
/*     */     private int clusterMemberID;
/*     */     private Object value;
/*     */ 
/*     */     public ValueWrapper(Object value)
/*     */     {
/* 159 */       this.clusterMemberID = ShortTermQueryCache.getMemberID();
/* 160 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public ValueWrapper()
/*     */     {
/*     */     }
/*     */ 
/*     */     public int getClusterMemberID()
/*     */     {
/* 176 */       return this.clusterMemberID;
/*     */     }
/*     */ 
/*     */     public Object getValue()
/*     */     {
/* 185 */       return this.value;
/*     */     }
/*     */ 
/*     */     public void readExternal(DataInput in) throws IOException {
/* 189 */       this.clusterMemberID = in.readInt();
/* 190 */       this.value = ExternalizableHelper.readObject(in);
/*     */     }
/*     */ 
/*     */     public void writeExternal(DataOutput out) throws IOException {
/* 194 */       out.writeInt(this.clusterMemberID);
/* 195 */       ExternalizableHelper.writeObject(out, this.value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public class Entry extends CoherenceCache.Entry
/*     */   {
/* 141 */     public boolean updateFlag = false;
/*     */ 
/*     */     public Entry()
/*     */     {
/* 137 */       super();
/*     */     }
/*     */ 
/*     */     public boolean isExpired()
/*     */     {
/* 145 */       return (!this.updateFlag) && (super.isExpired());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.ShortTermQueryCache
 * JD-Core Version:    0.6.2
 */
/*      */ package com.jivesoftware.forum.database;
/*      */ 
/*      */ import com.jivesoftware.base.AuthFactory;
/*      */ import com.jivesoftware.base.AuthToken;
/*      */ import com.jivesoftware.base.FilterManager;
/*      */ import com.jivesoftware.base.JiveGlobals;
/*      */ import com.jivesoftware.base.Log;
/*      */ import com.jivesoftware.base.UnauthorizedException;
/*      */ import com.jivesoftware.base.User;
/*      */ import com.jivesoftware.base.UserManager;
/*      */ import com.jivesoftware.base.UserNotFoundException;
/*      */ import com.jivesoftware.base.database.ConnectionManager;
/*      */ import com.jivesoftware.base.database.sequence.SequenceManager;
/*      */ import com.jivesoftware.forum.Attachment;
/*      */ import com.jivesoftware.forum.AttachmentException;
/*      */ import com.jivesoftware.forum.AttachmentManager;
/*      */ import com.jivesoftware.forum.AttachmentNotFoundException;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*      */ import com.jivesoftware.forum.ForumThread;
/*      */ import com.jivesoftware.forum.TreeWalker;
/*      */ import com.jivesoftware.forum.event.MessageEvent;
/*      */ import com.jivesoftware.forum.event.MessageEventDispatcher;
/*      */ import com.jivesoftware.util.Cache;
/*      */ import com.jivesoftware.util.CacheFactory;
/*      */ import com.jivesoftware.util.CacheSizes;
/*      */ import com.jivesoftware.util.Cacheable;
/*      */ import com.jivesoftware.util.ExtendedPropertyUtils;
/*      */ import com.jivesoftware.util.ExternalizableLiteUtil;
/*      */ import com.jivesoftware.util.LongList;
/*      */ import com.jivesoftware.util.profile.Profiler;
/*      */ import com.tangosol.io.ExternalizableLite;
/*      */ import com.tangosol.util.ConcurrentMap;
/*      */ import com.tangosol.util.ExternalizableHelper;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ public class DbForumMessage
/*      */   implements ForumMessage, Cacheable, ExternalizableLite
/*      */ {
/*      */   private static final String LOAD_ATTACHMENTS = "SELECT attachmentID FROM jiveAttachment WHERE objectType=2 AND objectID=?";
/*      */   private static final String LOAD_PROPERTIES = "SELECT name, propValue FROM jiveMessageProp WHERE messageID=?";
/*      */   private static final String INSERT_PROPERTY = "INSERT INTO jiveMessageProp (messageID,name,propValue) VALUES (?,?,?)";
/*      */   private static final String UPDATE_PROPERTY = "UPDATE jiveMessageProp SET propValue=? WHERE name=? AND messageID=?";
/*      */   private static final String DELETE_PROPERTY = "DELETE FROM jiveMessageProp WHERE messageID=? AND name=?";
/*      */   private static final String LOAD_MESSAGE = "SELECT messageID, parentMessageID, threadID, forumID, forumIndex, userID, subject, body, modValue, rewardPoints, creationDate, modificationDate FROM jiveMessage WHERE messageID=?";
/*      */   private static final String LOAD_MESSAGE_BY_INDEX = "SELECT messageID, parentMessageID, threadID, forumID, forumIndex, userID, subject, body, modValue, rewardPoints, creationDate, modificationDate FROM jiveMessage WHERE forumID=? AND forumIndex=?";
/*      */   private static final String BULK_LOAD_MESSAGES = "SELECT messageID, parentMessageID, threadID, forumIndex, userID, subject, body, modValue, rewardPoints, creationDate, modificationDate FROM jiveMessage WHERE forumID=? AND forumIndex >= ? AND forumIndex < ?";
/*      */   private static final String GET_FORUM_INDEX = "SELECT forumIndexCounter from jiveForum WHERE forumID=?";
/*      */   public static final String UPDATE_FORUM_INDEX = "UPDATE jiveMessage SET forumIndex=? WHERE messageID=?";
/*      */   private static final String UPDATE_FORUM_INDEX_COUNTER = "UPDATE jiveForum SET forumIndexCounter=? WHERE forumID=? AND forumIndexCounter=?";
/*      */   private static final String INSERT_MESSAGE = "INSERT INTO jiveMessage (messageID, parentMessageID, threadID, forumID, forumIndex, userID, subject, body, modValue, rewardPoints, creationDate, modificationDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
/*      */   private static final String UPDATE_MESSAGE_MODIFIED_DATE = "UPDATE jiveMessage SET modificationDate=? WHERE messageID=?";
/*      */   private static final String UPDATE_MESSAGE_USER = "UPDATE jiveMessage SET userID=? WHERE messageID=?";
/*      */   private static final String UPDATE_PARENT_ID = "UPDATE jiveMessage SET parentMessageID=? WHERE messageID=?";
/*      */   private static final String SAVE_MESSAGE = "UPDATE jiveMessage SET subject=?, body=?, modValue=?, rewardPoints=?, creationDate=?, modificationDate=? WHERE messageID=?";
/*      */   private static final String INSERT_MODERATION_ENTRY = "INSERT INTO jiveModeration (objectID, objectType, userID, modDate, modValue) VALUES (?, ?, ?, ?, ?)";
/*      */   private static final long serialVersionUID = 1L;
/*   99 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*      */ 
/*  101 */   private static long filterExpiration = -1L;
/*      */   public static final String PROP_CONTENT_TYPE = "jive.contentType";
/*      */   public static final String PROP_NAME = "name";
/*      */   public static final String PROP_EMAIL = "email";
/*      */   public static final String PROP_IP = "IP";
/*      */   public static final String PROP_USER = "user";
/*      */   public static final String PROP_SOURCE = "source";
/*      */   public static final String TEXT_HTML = "text/html";
/*  141 */   private long id = -1L;
/*      */   private Date creationDate;
/*      */   private Date modificationDate;
/*  144 */   private String subject = "";
/*  145 */   private String body = "";
/*      */   private long userID;
/*  148 */   private int forumIndex = -1;
/*  149 */   private long parentMessageID = -1L;
/*  150 */   protected long threadID = -1L;
/*  151 */   protected long forumID = -1L;
/*      */ 
/*  154 */   protected int moderationValue = -2147483648;
/*  155 */   private int rewardPoints = 0;
/*  156 */   private Map properties = null;
/*      */   private LongList attachments;
/*  161 */   protected String filteredSubject = null;
/*  162 */   protected String filteredBody = null;
/*  163 */   protected Map filteredProperties = null;
/*      */   private long filteredTime;
/*  173 */   private int saveState = -1;
/*      */ 
/*  175 */   private transient Object saveLock = new Object();
/*      */ 
/*      */   public static long getFilterExpiration()
/*      */   {
/*  123 */     return filterExpiration;
/*      */   }
/*      */ 
/*      */   public static void setFilterExpiration(long filterExpiration)
/*      */   {
/*  138 */     filterExpiration = filterExpiration;
/*      */   }
/*      */ 
/*      */   protected DbForumMessage(User user, Forum forum)
/*      */   {
/*  187 */     if (user != null) {
/*  188 */       this.userID = user.getID();
/*      */     }
/*      */     else {
/*  191 */       this.userID = -1L;
/*      */     }
/*  193 */     this.forumID = forum.getID();
/*      */ 
/*  195 */     long now = System.currentTimeMillis();
/*  196 */     this.creationDate = new Date(now);
/*  197 */     this.modificationDate = new Date(now);
/*  198 */     this.properties = new Hashtable();
/*  199 */     this.attachments = new LongList();
/*      */   }
/*      */ 
/*      */   protected DbForumMessage(long messageID)
/*      */     throws ForumMessageNotFoundException
/*      */   {
/*  208 */     if (messageID < 0L) {
/*  209 */       throw new ForumMessageNotFoundException("Message ID " + messageID + " is not valid.");
/*      */     }
/*  211 */     this.id = messageID;
/*  212 */     loadFromDb();
/*  213 */     setSaveState(1);
/*      */   }
/*      */ 
/*      */   protected DbForumMessage(long forumID, int forumIndex)
/*      */     throws ForumMessageNotFoundException
/*      */   {
/*  223 */     if ((forumID < 0L) || (forumIndex < 0)) {
/*  224 */       throw new ForumMessageNotFoundException("Forum ID or forum index not valid: " + forumID + ", " + forumIndex);
/*      */     }
/*      */ 
/*  227 */     this.forumID = forumID;
/*  228 */     this.forumIndex = forumIndex;
/*  229 */     loadFromDb();
/*  230 */     setSaveState(1);
/*      */   }
/*      */ 
/*      */   public DbForumMessage()
/*      */   {
/*      */   }
/*      */ 
/*      */   public long getID()
/*      */   {
/*  244 */     return this.id;
/*      */   }
/*      */ 
/*      */   public int getForumIndex() {
/*  248 */     return this.forumIndex;
/*      */   }
/*      */ 
/*      */   void setForumIndex(int forumIndex, Connection con)
/*      */     throws SQLException
/*      */   {
/*  260 */     PreparedStatement pstmt = null;
/*      */     try {
/*  262 */       pstmt = con.prepareStatement("UPDATE jiveMessage SET forumIndex=? WHERE messageID=?");
/*  263 */       pstmt.setInt(1, forumIndex);
/*  264 */       pstmt.setLong(2, this.id);
/*  265 */       pstmt.executeUpdate();
/*  266 */       this.forumIndex = forumIndex;
/*      */     }
/*      */     finally {
/*  269 */       ConnectionManager.closePreparedStatement(pstmt);
/*      */     }
/*      */ 
/*  272 */     FACTORY.cacheManager.messagePut(this.id, this);
/*  273 */     String key = this.forumID + '-' + forumIndex;
/*  274 */     FACTORY.cacheManager.forumIndexPut(key, this.id);
/*      */   }
/*      */ 
/*      */   public Date getCreationDate() {
/*  278 */     return new Date(this.creationDate.getTime());
/*      */   }
/*      */ 
/*      */   public void setCreationDate(Date creationDate)
/*      */   {
/*  284 */     if ((isReadyToSave()) && (getForumThread().getRootMessage().getID() != this.id)) {
/*      */       ForumMessage parent;
/*      */       try {
/*  287 */         parent = getForumThread().getTreeWalker().getParent(this);
/*      */       }
/*      */       catch (ForumMessageNotFoundException e) {
/*  290 */         Log.error(e);
/*  291 */         return;
/*      */       }
/*      */ 
/*  296 */       if (parent.getCreationDate().compareTo(creationDate) > 0) {
/*  297 */         Log.warn("Attempting to set the creation date of message " + this.id + " to be younger than it's parent message, correcting dates.");
/*      */ 
/*  299 */         Log.debug("Creation date of parent: " + parent.getCreationDate() + ", creation date attempting to be set: " + creationDate, new Exception());
/*      */ 
/*  302 */         long pDate = parent.getCreationDate().getTime();
/*  303 */         Date newDate = new Date(pDate + 1L);
/*  304 */         this.creationDate = new Date(newDate.getTime());
/*      */       }
/*      */       else {
/*  307 */         this.creationDate = new Date(creationDate.getTime());
/*      */       }
/*      */     }
/*      */     else {
/*  311 */       this.creationDate = new Date(creationDate.getTime());
/*      */     }
/*      */ 
/*  315 */     if (this.modificationDate.compareTo(this.creationDate) < 0) {
/*  316 */       this.modificationDate.setTime(this.creationDate.getTime());
/*      */     }
/*      */ 
/*  320 */     if (!isReadyToSave()) {
/*  321 */       return;
/*      */     }
/*  323 */     saveToDb();
/*      */ 
/*  325 */     FACTORY.cacheManager.messagePut(this.id, this);
/*      */     try {
/*  327 */       FACTORY.cacheManager.getForumThread(this.threadID).clearCache();
/*      */ 
/*  329 */       DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  330 */       dbForum.clearCache();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   public Date getModificationDate() {
/*  338 */     return new Date(this.modificationDate.getTime());
/*      */   }
/*      */ 
/*      */   public void setModificationDate(Date modificationDate) {
/*  342 */     this.modificationDate = new Date(modificationDate.getTime());
/*      */ 
/*  345 */     if (this.modificationDate.compareTo(this.creationDate) < 0) {
/*  346 */       Log.warn("Attempting to set the modification date of message " + this.id + " to be younger than it's creation date, correcting dates.");
/*      */ 
/*  348 */       Log.debug("Creation date of message: " + this.creationDate + ", modification date attempting to be set: " + modificationDate, new Exception());
/*      */ 
/*  352 */       this.modificationDate.setTime(this.creationDate.getTime());
/*      */     }
/*      */ 
/*  356 */     if (!isReadyToSave()) {
/*  357 */       return;
/*      */     }
/*  359 */     saveToDb();
/*      */ 
/*  361 */     FACTORY.cacheManager.messagePut(this.id, this);
/*      */     try {
/*  363 */       FACTORY.cacheManager.getForumThread(this.threadID).clearCache();
/*      */ 
/*  365 */       DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  366 */       dbForum.clearCache();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getSubject() {
/*  374 */     checkFilterCache();
/*      */ 
/*  376 */     if (this.filteredSubject == null) {
/*  377 */       FilterManager filterManager = getForum().getFilterManager();
/*  378 */       this.filteredSubject = filterManager.applyFilters(this, 8L, this.subject);
/*      */     }
/*      */ 
/*  381 */     return this.filteredSubject;
/*      */   }
/*      */ 
/*      */   public String getUnfilteredSubject() {
/*  385 */     return this.subject;
/*      */   }
/*      */ 
/*      */   public void setSubject(String subject)
/*      */   {
/*  390 */     if (this.subject.equals(subject)) {
/*  391 */       return;
/*      */     }
/*      */ 
/*  394 */     this.subject = subject;
/*      */ 
/*  397 */     this.filteredSubject = null;
/*      */ 
/*  400 */     if (!isReadyToSave()) {
/*  401 */       return;
/*      */     }
/*      */ 
/*  405 */     saveToDb();
/*      */ 
/*  408 */     Connection con = null;
/*      */     try {
/*  410 */       con = ConnectionManager.getConnection();
/*  411 */       updateModifiedDate(System.currentTimeMillis(), con);
/*      */     }
/*      */     catch (Exception e) {
/*  414 */       Log.error(e);
/*      */     }
/*      */     finally {
/*  417 */       ConnectionManager.closeConnection(con);
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  422 */       DbInterceptorManager manager = (DbInterceptorManager)getForum().getInterceptorManager();
/*  423 */       manager.invokeInterceptors(this, 3);
/*      */     }
/*      */     catch (Exception e) {
/*  426 */       Log.error(e);
/*      */     }
/*      */ 
/*  430 */     FACTORY.cacheManager.messagePut(this.id, this);
/*      */     try {
/*  432 */       FACTORY.cacheManager.getForumThread(this.threadID).clearCache();
/*      */ 
/*  434 */       DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  435 */       dbForum.clearCache();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*      */ 
/*  442 */     MessageEvent event = new MessageEvent(102, this, Collections.EMPTY_MAP);
/*      */ 
/*  444 */     MessageEventDispatcher.getInstance().dispatchEvent(event);
/*      */   }
/*      */ 
/*      */   public String getBody() {
/*  448 */     checkFilterCache();
/*      */ 
/*  450 */     if (this.filteredBody == null) {
/*  451 */       this.filteredBody = getForum().getFilterManager().applyFilters(this, 16L, this.body);
/*      */     }
/*      */ 
/*  454 */     return this.filteredBody;
/*      */   }
/*      */ 
/*      */   public String getUnfilteredBody() {
/*  458 */     return this.body;
/*      */   }
/*      */ 
/*      */   public void setBody(String body)
/*      */   {
/*  463 */     if (body == null) {
/*  464 */       throw new IllegalArgumentException("Body cannot be null");
/*      */     }
/*      */ 
/*  468 */     if (body.equals(this.body)) {
/*  469 */       return;
/*      */     }
/*      */ 
/*  475 */     int maxSize = JiveGlobals.getJiveIntProperty("message.maxBodySize", 524288);
/*  476 */     if (body.length() > maxSize / 2) {
/*  477 */       body = body.substring(0, maxSize / 2);
/*      */     }
/*      */ 
/*  481 */     this.body = body;
/*      */ 
/*  484 */     this.filteredBody = null;
/*      */ 
/*  487 */     if (!isReadyToSave()) {
/*  488 */       return;
/*      */     }
/*      */ 
/*  492 */     saveToDb();
/*      */ 
/*  495 */     Connection con = null;
/*      */     try {
/*  497 */       con = ConnectionManager.getConnection();
/*  498 */       updateModifiedDate(System.currentTimeMillis(), con);
/*      */     }
/*      */     catch (Exception e) {
/*  501 */       Log.error(e);
/*      */     }
/*      */     finally {
/*  504 */       ConnectionManager.closeConnection(con);
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  509 */       DbInterceptorManager manager = (DbInterceptorManager)getForum().getInterceptorManager();
/*  510 */       manager.invokeInterceptors(this, 3);
/*      */     }
/*      */     catch (Exception e) {
/*  513 */       Log.error(e);
/*      */     }
/*      */ 
/*  517 */     FACTORY.cacheManager.messagePut(this.id, this);
/*      */     try {
/*  519 */       FACTORY.cacheManager.getForumThread(this.threadID).clearCache();
/*      */ 
/*  521 */       DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  522 */       dbForum.clearCache();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*      */ 
/*  529 */     MessageEvent event = new MessageEvent(102, this, Collections.EMPTY_MAP);
/*      */ 
/*  531 */     MessageEventDispatcher.getInstance().dispatchEvent(event);
/*      */   }
/*      */ 
/*      */   public User getUser() {
/*  535 */     if (this.userID == -1L) {
/*  536 */       return null;
/*      */     }
/*  538 */     User user = null;
/*      */     try {
/*  540 */       user = FACTORY.getUserManager().getUser(this.userID);
/*      */     }
/*      */     catch (UserNotFoundException unfe) {
/*  543 */       Log.error(unfe);
/*      */     }
/*  545 */     return user;
/*      */   }
/*      */ 
/*      */   public void setUser(User user)
/*      */   {
/*  550 */     if ((user == null) || (user.getID() == this.userID)) {
/*  551 */       return;
/*      */     }
/*      */ 
/*  554 */     this.userID = user.getID();
/*      */ 
/*  556 */     if (!isReadyToSave()) {
/*  557 */       return;
/*      */     }
/*      */ 
/*  561 */     Connection con = null;
/*  562 */     PreparedStatement pstmt = null;
/*      */     try {
/*  564 */       con = ConnectionManager.getConnection();
/*  565 */       pstmt = con.prepareStatement("UPDATE jiveMessage SET userID=? WHERE messageID=?");
/*  566 */       pstmt.setLong(1, this.userID);
/*  567 */       pstmt.setLong(2, this.id);
/*  568 */       pstmt.executeUpdate();
/*      */     } catch (SQLException e) {
/*  570 */       Log.error(e);
/*      */     } finally {
/*  572 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/*  576 */     FACTORY.cacheManager.messagePut(this.id, this);
/*  577 */     FACTORY.cacheManager.userMessageCountCache.remove(new Long(this.userID));
/*      */   }
/*      */ 
/*      */   public ForumMessage getParentMessage() {
/*  581 */     long id = getParentMessageID();
/*  582 */     if (id == -1L) {
/*  583 */       return null;
/*      */     }
/*  585 */     DbForumMessage message = null;
/*      */     try {
/*  587 */       message = FACTORY.cacheManager.getMessage(id);
/*      */     }
/*      */     catch (ForumMessageNotFoundException fmnfe) {
/*  590 */       Log.error(fmnfe);
/*      */     }
/*  592 */     return message;
/*      */   }
/*      */ 
/*      */   public Attachment createAttachment(String name, String contentType, InputStream data)
/*      */     throws IllegalStateException, AttachmentException
/*      */   {
/*  598 */     AttachmentManager attachmentManager = FACTORY.getAttachmentManager();
/*      */ 
/*  600 */     if (getAttachmentCount() > attachmentManager.getMaxAttachmentsPerMessage()) {
/*  601 */       throw new AttachmentException(1, name);
/*      */     }
/*  603 */     Attachment attachment = new DbAttachment(2, this.id, name, contentType, data);
/*      */ 
/*  605 */     synchronized (this.attachments) {
/*  606 */       this.attachments.add(attachment.getID());
/*      */     }
/*      */ 
/*  609 */     if (isReadyToSave())
/*      */     {
/*  611 */       Connection con = null;
/*      */       try {
/*  613 */         con = ConnectionManager.getConnection();
/*  614 */         updateModifiedDate(System.currentTimeMillis(), con);
/*      */       }
/*      */       catch (Exception e) {
/*  617 */         Log.error(e);
/*      */       }
/*      */       finally {
/*  620 */         ConnectionManager.closeConnection(con);
/*      */       }
/*      */ 
/*  624 */       FACTORY.cacheManager.messagePut(this.id, this);
/*      */     }
/*  626 */     return attachment;
/*      */   }
/*      */ 
/*      */   public int getAttachmentCount() {
/*  630 */     if (this.attachments == null) {
/*  631 */       getAttachments();
/*      */     }
/*  633 */     synchronized (this.attachments) {
/*  634 */       return this.attachments.size();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteAttachment(Attachment attachment) throws AttachmentException
/*      */   {
/*  640 */     if (!isReadyToSave()) {
/*  641 */       if (this.attachments == null) {
/*  642 */         getAttachments();
/*      */       }
/*  644 */       synchronized (this.attachments) {
/*  645 */         int index = this.attachments.indexOf(attachment.getID());
/*  646 */         if (index >= 0) {
/*  647 */           this.attachments.remove(index);
/*      */         }
/*      */         else
/*      */         {
/*  651 */           throw new IllegalArgumentException("Attachment does not belong to message");
/*      */         }
/*      */         return;
/*      */       }
/*      */     }
/*      */     DbAttachment dbAttachment;
/*      */     DbAttachment dbAttachment;
/*  659 */     if ((attachment instanceof DbAttachment))
/*  660 */       dbAttachment = (DbAttachment)attachment;
/*      */     else {
/*      */       try
/*      */       {
/*  664 */         dbAttachment = FACTORY.cacheManager.getAttachment(attachment.getID());
/*      */       }
/*      */       catch (AttachmentNotFoundException anfe) {
/*  667 */         throw new AttachmentException(3, anfe, attachment.getName());
/*      */       }
/*      */     }
/*      */ 
/*  671 */     if (dbAttachment.getObjectID() != this.id) {
/*  672 */       throw new IllegalArgumentException("Attachment does not belong to message.");
/*      */     }
/*  674 */     Connection con = null;
/*      */     try {
/*  676 */       con = ConnectionManager.getConnection();
/*  677 */       dbAttachment.delete(con);
/*  678 */       this.attachments = null;
/*      */ 
/*  680 */       FACTORY.cacheManager.messagePut(this.id, this);
/*      */     }
/*      */     catch (Exception e) {
/*  683 */       throw new AttachmentException(3, e, attachment.getName());
/*      */     }
/*      */     finally {
/*  686 */       ConnectionManager.closeConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Iterator getAttachments() {
/*  691 */     if (this.attachments == null) {
/*  692 */       LongList attachmentList = new LongList();
/*  693 */       Connection con = null;
/*  694 */       PreparedStatement pstmt = null;
/*      */       try {
/*  696 */         con = ConnectionManager.getConnection();
/*  697 */         pstmt = con.prepareStatement("SELECT attachmentID FROM jiveAttachment WHERE objectType=2 AND objectID=?");
/*  698 */         pstmt.setLong(1, this.id);
/*  699 */         ResultSet rs = pstmt.executeQuery();
/*  700 */         while (rs.next()) {
/*  701 */           attachmentList.add(rs.getLong(1));
/*      */         }
/*  703 */         rs.close();
/*      */       }
/*      */       catch (SQLException sqle) {
/*  706 */         Log.error(sqle);
/*      */       }
/*      */       finally {
/*  709 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*  711 */       this.attachments = attachmentList;
/*      */     }
/*  713 */     return new DatabaseObjectIterator(13, this.attachments.toArray(), FACTORY);
/*      */   }
/*      */ 
/*      */   public int getModerationValue() {
/*  717 */     return this.moderationValue;
/*      */   }
/*      */ 
/*      */   public void setModerationValue(int value, AuthToken authToken)
/*      */   {
/*  722 */     if (this.moderationValue == value) {
/*  723 */       return;
/*      */     }
/*      */ 
/*  726 */     if (authToken == null) {
/*  727 */       authToken = AuthFactory.getAnonymousAuthToken();
/*      */     }
/*      */ 
/*  730 */     setModValue(value, authToken);
/*      */ 
/*  739 */     DbForumThread thread = (DbForumThread)getForumThread();
/*  740 */     if ((thread != null) && (thread.getRootMessage().getID() == this.id))
/*  741 */       thread.setModValue(value, authToken);
/*      */   }
/*      */ 
/*      */   public String getProperty(String name)
/*      */   {
/*  746 */     if (this.properties == null) {
/*  747 */       loadPropertiesFromDb();
/*      */     }
/*  749 */     checkFilterCache();
/*      */ 
/*  751 */     if (this.filteredProperties == null) {
/*  752 */       Hashtable props = new Hashtable();
/*  753 */       FilterManager filterManager = getForum().getFilterManager();
/*  754 */       for (Iterator i = getPropertyNames(); i.hasNext(); ) {
/*  755 */         String propName = (String)i.next();
/*  756 */         String filteredValue = filterManager.applyFilters(this, 4L, (String)this.properties.get(propName));
/*      */ 
/*  758 */         props.put(propName, filteredValue);
/*      */       }
/*  760 */       this.filteredProperties = props;
/*      */     }
/*      */ 
/*  763 */     return (String)this.filteredProperties.get(name);
/*      */   }
/*      */ 
/*      */   public String getUnfilteredProperty(String name) {
/*  767 */     if (this.properties == null) {
/*  768 */       loadPropertiesFromDb();
/*      */     }
/*  770 */     return (String)this.properties.get(name);
/*      */   }
/*      */ 
/*      */   public Collection getProperties(String parentName)
/*      */   {
/*      */     Object[] keys;
/*  775 */     synchronized (this.properties) {
/*  776 */       keys = this.properties.keySet().toArray();
/*      */     }
/*  778 */     ArrayList results = new ArrayList();
/*  779 */     int i = 0; for (int n = keys.length; i < n; i++) {
/*  780 */       String key = (String)keys[i];
/*  781 */       if ((key.startsWith(parentName)) && 
/*  782 */         (!key.equals(parentName)))
/*      */       {
/*  785 */         if (key.substring(parentName.length()).lastIndexOf(".") == 0) {
/*  786 */           results.add(getProperty(key));
/*      */         }
/*      */       }
/*      */     }
/*  790 */     return Collections.unmodifiableCollection(results);
/*      */   }
/*      */ 
/*      */   public void setProperty(String name, String value) {
/*  794 */     if (this.properties == null) {
/*  795 */       loadPropertiesFromDb();
/*      */     }
/*      */ 
/*  798 */     value = ExtendedPropertyUtils.validateExtendedProperty(name, value);
/*      */ 
/*  800 */     if (this.properties.containsKey(name))
/*      */     {
/*  803 */       if (!value.equals(this.properties.get(name))) {
/*  804 */         synchronized (this.properties) {
/*  805 */           this.properties.put(name, value);
/*      */         }
/*      */ 
/*  808 */         this.filteredProperties = null;
/*  809 */         if (isReadyToSave()) {
/*  810 */           updatePropertyInDb(name, value);
/*      */ 
/*  812 */           FACTORY.cacheManager.messagePut(this.id, this);
/*      */           try
/*      */           {
/*  815 */             FACTORY.cacheManager.getForumThread(this.threadID).clearCache();
/*      */ 
/*  817 */             DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  818 */             dbForum.clearCache();
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/*      */           }
/*      */ 
/*  825 */           MessageEvent event = new MessageEvent(102, this, Collections.EMPTY_MAP);
/*      */ 
/*  827 */           MessageEventDispatcher.getInstance().dispatchEvent(event);
/*      */         }
/*      */       }
/*      */     } else {
/*  831 */       synchronized (this.properties) {
/*  832 */         this.properties.put(name, value);
/*      */       }
/*  834 */       if (isReadyToSave()) {
/*  835 */         Connection con = null;
/*  836 */         boolean abortTransaction = false;
/*      */         try {
/*  838 */           con = ConnectionManager.getTransactionConnection();
/*  839 */           insertPropertyIntoDb(name, value, con);
/*      */         }
/*      */         catch (SQLException sqle) {
/*  842 */           Log.error(sqle);
/*  843 */           abortTransaction = true;
/*      */         }
/*      */         finally {
/*  846 */           ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*      */         }
/*      */ 
/*  849 */         this.filteredProperties = null;
/*      */ 
/*  851 */         FACTORY.cacheManager.messagePut(this.id, this);
/*      */         try {
/*  853 */           FACTORY.cacheManager.getForumThread(this.threadID).clearCache();
/*      */ 
/*  855 */           DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  856 */           dbForum.clearCache();
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/*      */ 
/*  863 */         MessageEvent event = new MessageEvent(102, this, Collections.EMPTY_MAP);
/*      */ 
/*  865 */         MessageEventDispatcher.getInstance().dispatchEvent(event);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteProperty(String name) {
/*  871 */     if (this.properties == null) {
/*  872 */       loadPropertiesFromDb();
/*      */     }
/*      */ 
/*  875 */     if (this.properties.containsKey(name)) {
/*  876 */       synchronized (this.properties) {
/*  877 */         this.properties.remove(name);
/*      */       }
/*      */ 
/*  880 */       if (isReadyToSave()) {
/*  881 */         deletePropertyFromDb(name);
/*      */ 
/*  883 */         this.filteredProperties = null;
/*  884 */         FACTORY.cacheManager.messagePut(this.id, this);
/*      */         try {
/*  886 */           FACTORY.cacheManager.getForumThread(this.threadID).clearCache();
/*      */ 
/*  888 */           DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  889 */           dbForum.clearCache();
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/*      */ 
/*  896 */         MessageEvent event = new MessageEvent(102, this, Collections.EMPTY_MAP);
/*      */ 
/*  898 */         MessageEventDispatcher.getInstance().dispatchEvent(event);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public Iterator getPropertyNames() {
/*  904 */     if (this.properties == null) {
/*  905 */       loadPropertiesFromDb();
/*      */     }
/*  907 */     synchronized (this.properties) {
/*  908 */       List names = new ArrayList(this.properties.size());
/*  909 */       for (Iterator i = this.properties.keySet().iterator(); i.hasNext(); ) {
/*  910 */         names.add(i.next());
/*      */       }
/*  912 */       return Collections.unmodifiableList(names).iterator();
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isAnonymous()
/*      */   {
/*  918 */     if (this.userID == -1L) {
/*  919 */       return true;
/*      */     }
/*      */ 
/*  924 */     return getUser() == null;
/*      */   }
/*      */ 
/*      */   public long getParentMessageID()
/*      */   {
/*  940 */     return this.parentMessageID;
/*      */   }
/*      */ 
/*      */   public ForumThread getForumThread() {
/*  944 */     if (this.threadID == -1L)
/*  945 */       return null;
/*      */     try
/*      */     {
/*  948 */       return FACTORY.cacheManager.getForumThread(this.threadID);
/*      */     }
/*      */     catch (Exception e) {
/*  951 */       Log.error(e);
/*  952 */     }return null;
/*      */   }
/*      */ 
/*      */   public Forum getForum()
/*      */   {
/*  957 */     if (this.forumID == -1L)
/*  958 */       return null;
/*      */     try
/*      */     {
/*  961 */       return FACTORY.cacheManager.getForum(this.forumID);
/*      */     }
/*      */     catch (Exception e) {
/*  964 */       Log.error(e);
/*  965 */     }return null;
/*      */   }
/*      */ 
/*      */   public boolean isAuthorized(long type)
/*      */   {
/*  970 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean isHtml() {
/*  974 */     return "text/html".equals(getProperty("jive.contentType"));
/*      */   }
/*      */ 
/*      */   public int getCachedSize()
/*      */   {
/*  983 */     int size = 0;
/*  984 */     size += CacheSizes.sizeOfObject();
/*  985 */     size += CacheSizes.sizeOfLong();
/*  986 */     size += CacheSizes.sizeOfString(this.subject) * 2;
/*  987 */     size += CacheSizes.sizeOfString(this.body) * 2;
/*  988 */     size += CacheSizes.sizeOfDate();
/*  989 */     size += CacheSizes.sizeOfDate();
/*  990 */     size += CacheSizes.sizeOfLong();
/*  991 */     size += CacheSizes.sizeOfLong();
/*  992 */     size += CacheSizes.sizeOfLong();
/*  993 */     size += CacheSizes.sizeOfLong();
/*  994 */     size += CacheSizes.sizeOfInt();
/*  995 */     size += CacheSizes.sizeOfMap(this.properties) * 2;
/*  996 */     size += CacheSizes.sizeOfObject();
/*  997 */     size += CacheSizes.sizeOfInt();
/*  998 */     size += CacheSizes.sizeOfInt();
/*  999 */     size += CacheSizes.sizeOfBoolean();
/* 1000 */     if (this.attachments != null) {
/* 1001 */       size += CacheSizes.sizeOfLong() * this.attachments.size() + CacheSizes.sizeOfObject();
/*      */     }
/*      */ 
/* 1005 */     return size;
/*      */   }
/*      */ 
/*      */   public void readExternal(DataInput in)
/*      */     throws IOException
/*      */   {
/* 1011 */     this.id = ExternalizableHelper.readLong(in);
/* 1012 */     this.creationDate = new Date(in.readLong());
/* 1013 */     this.modificationDate = new Date(in.readLong());
/* 1014 */     this.subject = ExternalizableHelper.readSafeUTF(in);
/* 1015 */     this.filteredSubject = ExternalizableHelper.readSafeUTF(in);
/* 1016 */     this.body = ExternalizableHelper.readSafeUTF(in);
/* 1017 */     this.filteredBody = ExternalizableHelper.readSafeUTF(in);
/* 1018 */     this.userID = ExternalizableHelper.readLong(in);
/*      */ 
/* 1020 */     this.forumIndex = ExternalizableHelper.readInt(in);
/* 1021 */     this.parentMessageID = ExternalizableHelper.readLong(in);
/* 1022 */     this.threadID = ExternalizableHelper.readLong(in);
/* 1023 */     this.forumID = ExternalizableHelper.readLong(in);
/* 1024 */     this.moderationValue = ExternalizableHelper.readInt(in);
/* 1025 */     this.rewardPoints = ExternalizableHelper.readInt(in);
/* 1026 */     this.properties = ExternalizableLiteUtil.readStringMap(in);
/* 1027 */     this.filteredProperties = ExternalizableLiteUtil.readStringMap(in);
/* 1028 */     this.attachments = ExternalizableLiteUtil.readLongList(in);
/* 1029 */     this.saveState = ExternalizableHelper.readInt(in);
/* 1030 */     this.filteredTime = ExternalizableHelper.readLong(in);
/*      */   }
/*      */ 
/*      */   public void writeExternal(DataOutput out) throws IOException {
/* 1034 */     ExternalizableHelper.writeLong(out, this.id);
/* 1035 */     out.writeLong(this.creationDate.getTime());
/* 1036 */     out.writeLong(this.modificationDate.getTime());
/* 1037 */     ExternalizableHelper.writeSafeUTF(out, this.subject);
/* 1038 */     ExternalizableHelper.writeSafeUTF(out, this.filteredSubject);
/* 1039 */     ExternalizableHelper.writeSafeUTF(out, this.body);
/* 1040 */     ExternalizableHelper.writeSafeUTF(out, this.filteredBody);
/* 1041 */     ExternalizableHelper.writeLong(out, this.userID);
/*      */ 
/* 1043 */     ExternalizableHelper.writeInt(out, this.forumIndex);
/* 1044 */     ExternalizableHelper.writeLong(out, this.parentMessageID);
/* 1045 */     ExternalizableHelper.writeLong(out, this.threadID);
/* 1046 */     ExternalizableHelper.writeLong(out, this.forumID);
/* 1047 */     ExternalizableHelper.writeInt(out, this.moderationValue);
/* 1048 */     ExternalizableHelper.writeInt(out, this.rewardPoints);
/* 1049 */     ExternalizableLiteUtil.writeStringMap(out, this.properties);
/* 1050 */     ExternalizableLiteUtil.writeStringMap(out, this.filteredProperties);
/* 1051 */     ExternalizableLiteUtil.writeLongList(out, this.attachments);
/* 1052 */     ExternalizableHelper.writeInt(out, this.saveState);
/* 1053 */     ExternalizableHelper.writeLong(out, this.filteredTime);
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1064 */     return "[" + this.id + "] " + this.subject;
/*      */   }
/*      */ 
/*      */   public int hashCode() {
/* 1068 */     return (int)this.id;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object object) {
/* 1072 */     if (this == object) {
/* 1073 */       return true;
/*      */     }
/* 1075 */     if ((object != null) && ((object instanceof ExternalizableLite))) {
/* 1076 */       return this.id == ((ExternalizableLite)object).getID();
/*      */     }
/*      */ 
/* 1079 */     return false;
/*      */   }
/*      */ 
/*      */   protected int getRewardPoints()
/*      */   {
/* 1087 */     return this.rewardPoints;
/*      */   }
/*      */ 
/*      */   protected void setRewardPoints(int rewardPoints, Connection con)
/*      */     throws SQLException
/*      */   {
/* 1097 */     int oldPoints = this.rewardPoints;
/* 1098 */     this.rewardPoints = rewardPoints;
/*      */     try {
/* 1100 */       saveToDb(con);
/*      */     }
/*      */     catch (SQLException sqle)
/*      */     {
/* 1104 */       this.rewardPoints = oldPoints;
/* 1105 */       throw sqle;
/*      */     }
/*      */ 
/* 1108 */     FACTORY.cacheManager.messagePut(this.id, this);
/*      */   }
/*      */ 
/*      */   protected void setModValue(int value, AuthToken authToken) {
/* 1112 */     if (this.moderationValue == value) {
/* 1113 */       return;
/*      */     }
/* 1115 */     int oldModerationValue = this.moderationValue;
/* 1116 */     this.moderationValue = value;
/*      */ 
/* 1118 */     if (!isReadyToSave()) {
/* 1119 */       return;
/*      */     }
/* 1121 */     saveToDb();
/*      */ 
/* 1126 */     if ((oldModerationValue < 1) && (value >= 1))
/*      */     {
/* 1130 */       Connection con = null;
/*      */       try {
/* 1132 */         con = ConnectionManager.getConnection();
/* 1133 */         updateModifiedDate(System.currentTimeMillis(), con);
/*      */ 
/* 1136 */         if (this.forumIndex == 0)
/* 1137 */           setForumIndex(getForumIndexValues(1, this.forumID), con);
/*      */       }
/*      */       catch (SQLException sqle)
/*      */       {
/* 1141 */         Log.error(sqle);
/*      */       }
/*      */       finally {
/* 1144 */         ConnectionManager.closeConnection(con);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1149 */     FACTORY.cacheManager.messagePut(this.id, this);
/*      */     try
/*      */     {
/* 1153 */       DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/* 1154 */       DbForumThread dbThread = (DbForumThread)dbForum.getThread(this.threadID);
/*      */ 
/* 1156 */       dbThread.clearCache();
/* 1157 */       dbForum.clearCache();
/*      */ 
/* 1160 */       FACTORY.cacheManager.threadPut(dbThread.getID(), dbThread);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*      */ 
/* 1168 */     Connection con = null;
/* 1169 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1171 */       con = ConnectionManager.getConnection();
/* 1172 */       pstmt = con.prepareStatement("INSERT INTO jiveModeration (objectID, objectType, userID, modDate, modValue) VALUES (?, ?, ?, ?, ?)");
/* 1173 */       pstmt.setLong(1, this.id);
/* 1174 */       pstmt.setInt(2, 2);
/* 1175 */       if (authToken.isAnonymous()) {
/* 1176 */         pstmt.setNull(3, -5);
/*      */       }
/*      */       else {
/* 1179 */         pstmt.setLong(3, authToken.getUserID());
/*      */       }
/* 1181 */       pstmt.setLong(4, this.modificationDate.getTime());
/* 1182 */       pstmt.setInt(5, this.moderationValue);
/* 1183 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (Exception e) {
/* 1186 */       Log.error(e);
/*      */     }
/*      */     finally {
/* 1189 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/* 1194 */     Object params = new TreeMap();
/* 1195 */     ((Map)params).put("oldModerationValue", new Integer(oldModerationValue));
/* 1196 */     if (authToken != null) {
/* 1197 */       ((Map)params).put("moderatorID", new Long(authToken.getUserID()));
/*      */     }
/*      */     else {
/* 1200 */       ((Map)params).put("moderatorID", new Long(-1L));
/*      */     }
/* 1202 */     MessageEvent event = new MessageEvent(103, this, (Map)params);
/*      */ 
/* 1204 */     MessageEventDispatcher.getInstance().dispatchEvent(event);
/*      */   }
/*      */ 
/*      */   private boolean isReadyToSave() {
/* 1208 */     synchronized (this.saveLock) {
/* 1209 */       if (this.saveState == 0) {
/*      */         try {
/* 1211 */           this.saveLock.wait();
/*      */         }
/*      */         catch (InterruptedException ie) {
/* 1214 */           Log.error(ie);
/*      */         }
/*      */       }
/*      */ 
/* 1218 */       return this.saveState == 1;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void setSaveState(int saveState)
/*      */   {
/* 1233 */     synchronized (this.saveLock) {
/* 1234 */       if ((this.saveState == 0) && (saveState != 0)) {
/* 1235 */         this.saveLock.notifyAll();
/*      */       }
/* 1237 */       this.saveState = saveState;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkFilterCache()
/*      */   {
/* 1245 */     if ((filterExpiration > 0L) && 
/* 1246 */       (CacheFactory.currentTime > this.filteredTime + filterExpiration)) {
/* 1247 */       this.filteredSubject = null;
/* 1248 */       this.filteredBody = null;
/* 1249 */       this.filteredProperties = null;
/* 1250 */       this.filteredTime = CacheFactory.currentTime;
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void loadPropertiesFromDb()
/*      */   {
/* 1259 */     this.properties = new Hashtable();
/* 1260 */     Connection con = null;
/* 1261 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1263 */       con = ConnectionManager.getConnection();
/* 1264 */       pstmt = con.prepareStatement("SELECT name, propValue FROM jiveMessageProp WHERE messageID=?");
/* 1265 */       pstmt.setLong(1, this.id);
/* 1266 */       ResultSet rs = pstmt.executeQuery();
/* 1267 */       while (rs.next()) {
/* 1268 */         this.properties.put(rs.getString(1), rs.getString(2));
/*      */       }
/* 1270 */       rs.close();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 1273 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/* 1276 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void insertPropertyIntoDb(String name, String value, Connection con)
/*      */     throws SQLException
/*      */   {
/* 1284 */     Profiler.begin("propInsert");
/* 1285 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1287 */       pstmt = con.prepareStatement("INSERT INTO jiveMessageProp (messageID,name,propValue) VALUES (?,?,?)");
/* 1288 */       pstmt.setLong(1, this.id);
/* 1289 */       pstmt.setString(2, name);
/* 1290 */       pstmt.setString(3, value);
/* 1291 */       pstmt.executeUpdate();
/*      */     }
/*      */     finally {
/* 1294 */       ConnectionManager.closePreparedStatement(pstmt);
/*      */     }
/* 1296 */     Profiler.end("propInsert");
/*      */   }
/*      */ 
/*      */   private void updatePropertyInDb(String name, String value)
/*      */   {
/* 1303 */     Connection con = null;
/* 1304 */     PreparedStatement pstmt = null;
/* 1305 */     boolean abortTransaction = false;
/*      */     try {
/* 1307 */       con = ConnectionManager.getTransactionConnection();
/* 1308 */       pstmt = con.prepareStatement("UPDATE jiveMessageProp SET propValue=? WHERE name=? AND messageID=?");
/* 1309 */       pstmt.setString(1, value);
/* 1310 */       pstmt.setString(2, name);
/* 1311 */       pstmt.setLong(3, this.id);
/* 1312 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 1315 */       Log.error(sqle);
/* 1316 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/* 1319 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void deletePropertyFromDb(String name)
/*      */   {
/* 1327 */     Connection con = null;
/* 1328 */     PreparedStatement pstmt = null;
/* 1329 */     boolean abortTransaction = false;
/*      */     try {
/* 1331 */       con = ConnectionManager.getTransactionConnection();
/* 1332 */       pstmt = con.prepareStatement("DELETE FROM jiveMessageProp WHERE messageID=? AND name=?");
/* 1333 */       pstmt.setLong(1, this.id);
/* 1334 */       pstmt.setString(2, name);
/* 1335 */       pstmt.execute();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 1338 */       Log.error(sqle);
/* 1339 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/* 1342 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void moveMessage(DbForumThread newThread, long parentMessageID, Connection con)
/*      */     throws SQLException
/*      */   {
/*      */     DbForumThread oldThread;
/*      */     try
/*      */     {
/* 1361 */       oldThread = FACTORY.cacheManager.getForumThread(this.threadID);
/*      */     }
/*      */     catch (Exception e) {
/* 1364 */       Log.error(e);
/* 1365 */       return;
/*      */     }
/*      */ 
/* 1369 */     List messageList = new ArrayList();
/* 1370 */     messageList.add(this);
/* 1371 */     Date modificationDate = newThread.getModificationDate();
/* 1372 */     if (this.modificationDate.after(modificationDate)) {
/* 1373 */       modificationDate = this.modificationDate;
/*      */     }
/* 1375 */     Iterator children = oldThread.getTreeWalker().getRecursiveChildren(this);
/* 1376 */     while (children.hasNext()) {
/* 1377 */       ForumMessage child = (DbForumMessage)children.next();
/* 1378 */       messageList.add(child);
/*      */ 
/* 1380 */       if (child.getModificationDate().after(modificationDate)) {
/* 1381 */         modificationDate = child.getModificationDate();
/*      */       }
/*      */     }
/*      */ 
/* 1385 */     DbForumMessage[] messages = (DbForumMessage[])messageList.toArray(new DbForumMessage[messageList.size()]);
/*      */ 
/* 1389 */     StringBuffer sql = new StringBuffer();
/* 1390 */     sql.append("UPDATE jiveMessage SET forumID=?, threadID=? WHERE messageID IN(");
/*      */ 
/* 1392 */     sql.append(messages[0].getID());
/* 1393 */     for (int i = 1; i < messages.length; i++) {
/* 1394 */       sql.append(", ").append(messages[i].getID());
/*      */     }
/* 1396 */     sql.append(")");
/*      */ 
/* 1398 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1400 */       pstmt = con.prepareStatement(sql.toString());
/* 1401 */       pstmt.setLong(1, newThread.forumID);
/* 1402 */       pstmt.setLong(2, newThread.getID());
/* 1403 */       pstmt.execute();
/* 1404 */       pstmt.close();
/*      */ 
/* 1407 */       pstmt = con.prepareStatement("UPDATE jiveMessage SET parentMessageID=? WHERE messageID=?");
/* 1408 */       if (parentMessageID == -1L) {
/* 1409 */         pstmt.setNull(1, -5);
/*      */       }
/*      */       else {
/* 1412 */         pstmt.setLong(1, parentMessageID);
/*      */       }
/* 1414 */       pstmt.setLong(2, this.id);
/* 1415 */       pstmt.execute();
/*      */ 
/* 1417 */       this.parentMessageID = parentMessageID;
/*      */     }
/*      */     finally {
/* 1420 */       ConnectionManager.closePreparedStatement(pstmt);
/*      */     }
/*      */ 
/* 1425 */     if (oldThread.forumID != newThread.forumID)
/*      */     {
/* 1428 */       int nextForumIndex = getForumIndexValues(messages.length, newThread.forumID) - messages.length + 1;
/*      */ 
/* 1430 */       for (int i = 0; i < messages.length; nextForumIndex++) {
/* 1431 */         messages[i].setForumIndex(nextForumIndex, con);
/*      */ 
/* 1430 */         i++;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1437 */     Object eventParams = new HashMap();
/* 1438 */     ((Map)eventParams).put("oldThreadID", new Long(oldThread.getID()));
/* 1439 */     ((Map)eventParams).put("oldForumID", new Long(oldThread.forumID));
/* 1440 */     for (int i = 0; i < messages.length; i++) {
/* 1441 */       messages[i].threadID = newThread.getID();
/* 1442 */       messages[i].forumID = newThread.forumID;
/* 1443 */       MessageEvent messageEvent = new MessageEvent(105, messages[i], Collections.unmodifiableMap((Map)eventParams));
/*      */ 
/* 1445 */       MessageEventDispatcher.getInstance().dispatchEvent(messageEvent);
/*      */     }
/*      */ 
/* 1449 */     newThread.setModificationDate(modificationDate);
/*      */ 
/* 1452 */     newThread.clearCache();
/* 1453 */     oldThread.clearCache();
/*      */   }
/*      */ 
/*      */   protected void updateModifiedDate(long date, Connection con)
/*      */     throws SQLException
/*      */   {
/* 1462 */     if (date > this.modificationDate.getTime()) {
/* 1463 */       this.modificationDate.setTime(date);
/* 1464 */       PreparedStatement pstmt = null;
/*      */       try {
/* 1466 */         pstmt = con.prepareStatement("UPDATE jiveMessage SET modificationDate=? WHERE messageID=?");
/* 1467 */         pstmt.setLong(1, this.modificationDate.getTime());
/* 1468 */         pstmt.setLong(2, this.id);
/* 1469 */         pstmt.executeUpdate();
/*      */       }
/*      */       finally {
/* 1472 */         ConnectionManager.closePreparedStatement(pstmt);
/*      */       }
/*      */ 
/* 1475 */       DbForumThread dbThread = (DbForumThread)getForumThread();
/* 1476 */       dbThread.updateModifiedDate(date, con);
/*      */ 
/* 1478 */       FACTORY.cacheManager.threadPut(this.id, dbThread);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void loadFromDb()
/*      */     throws ForumMessageNotFoundException
/*      */   {
/* 1487 */     Connection con = null;
/* 1488 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1490 */       con = ConnectionManager.getConnection();
/*      */ 
/* 1492 */       if (this.id != -1L) {
/* 1493 */         pstmt = con.prepareStatement("SELECT messageID, parentMessageID, threadID, forumID, forumIndex, userID, subject, body, modValue, rewardPoints, creationDate, modificationDate FROM jiveMessage WHERE messageID=?");
/* 1494 */         pstmt.setLong(1, this.id);
/*      */       }
/*      */       else
/*      */       {
/* 1498 */         pstmt = con.prepareStatement("SELECT messageID, parentMessageID, threadID, forumID, forumIndex, userID, subject, body, modValue, rewardPoints, creationDate, modificationDate FROM jiveMessage WHERE forumID=? AND forumIndex=?");
/* 1499 */         pstmt.setLong(1, this.forumID);
/* 1500 */         pstmt.setInt(2, this.forumIndex);
/*      */       }
/*      */ 
/* 1503 */       ResultSet rs = pstmt.executeQuery();
/* 1504 */       if (!rs.next()) {
/* 1505 */         throw new ForumMessageNotFoundException("Message " + this.id + " could not be loaded from the database.");
/*      */       }
/*      */ 
/* 1508 */       this.id = rs.getLong(1);
/* 1509 */       this.parentMessageID = rs.getLong(2);
/* 1510 */       if (rs.wasNull()) {
/* 1511 */         this.parentMessageID = -1L;
/*      */       }
/* 1513 */       this.threadID = rs.getLong(3);
/* 1514 */       this.forumID = rs.getLong(4);
/* 1515 */       this.forumIndex = rs.getInt(5);
/* 1516 */       this.userID = rs.getLong(6);
/* 1517 */       if (rs.wasNull()) {
/* 1518 */         this.userID = -1L;
/*      */       }
/* 1520 */       this.subject = rs.getString(7);
/* 1521 */       if (rs.wasNull()) {
/* 1522 */         this.subject = "";
/*      */       }
/*      */ 
/* 1525 */       this.body = ConnectionManager.getLargeTextField(rs, 8);
/* 1526 */       if (rs.wasNull()) {
/* 1527 */         this.body = "";
/*      */       }
/* 1529 */       this.moderationValue = rs.getInt(9);
/* 1530 */       this.rewardPoints = rs.getInt(10);
/* 1531 */       this.creationDate = new Date(rs.getLong(11));
/* 1532 */       this.modificationDate = new Date(rs.getLong(12));
/* 1533 */       rs.close();
/* 1534 */       pstmt.close();
/*      */ 
/* 1537 */       LongList attachmentList = new LongList();
/* 1538 */       pstmt = con.prepareStatement("SELECT attachmentID FROM jiveAttachment WHERE objectType=2 AND objectID=?");
/* 1539 */       pstmt.setLong(1, this.id);
/* 1540 */       rs = pstmt.executeQuery();
/* 1541 */       while (rs.next()) {
/* 1542 */         attachmentList.add(rs.getLong(1));
/*      */       }
/* 1544 */       rs.close();
/* 1545 */       this.attachments = attachmentList;
/*      */ 
/* 1548 */       pstmt.close();
/* 1549 */       this.properties = new Hashtable();
/* 1550 */       pstmt = con.prepareStatement("SELECT name, propValue FROM jiveMessageProp WHERE messageID=?");
/* 1551 */       pstmt.setLong(1, this.id);
/* 1552 */       rs = pstmt.executeQuery();
/* 1553 */       while (rs.next())
/*      */       {
/* 1555 */         this.properties.put(rs.getString(1), rs.getString(2));
/*      */       }
/* 1557 */       rs.close();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 1560 */       throw new ForumMessageNotFoundException("Message with id " + this.id + " could not be loaded from the database.");
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/* 1565 */       Log.warn("WARNING: In DbForumMessage.loadFromDb() -- there was an error parsing the dates returned from the database. Ensure that they're being stored correctly.");
/*      */ 
/* 1568 */       throw new ForumMessageNotFoundException("Message with id " + this.id + " could not be loaded from the database.");
/*      */     }
/*      */     finally
/*      */     {
/* 1573 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected static void loadBulkFromDb(long forumID, int startForumIndex, int endForumIndex)
/*      */   {
/* 1589 */     DbForumFactory factory = DbForumFactory.getInstance();
/* 1590 */     Cache forumIndexCache = factory.cacheManager.forumIndexCache;
/* 1591 */     Cache messageCache = factory.cacheManager.messageCache;
/*      */ 
/* 1594 */     Long[] messageIDs = new Long[endForumIndex - startForumIndex];
/*      */ 
/* 1596 */     Arrays.fill(messageIDs, new Long(-1L));
/*      */ 
/* 1598 */     Connection con = null;
/* 1599 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1601 */       con = ConnectionManager.getConnection();
/* 1602 */       pstmt = con.prepareStatement("SELECT messageID, parentMessageID, threadID, forumIndex, userID, subject, body, modValue, rewardPoints, creationDate, modificationDate FROM jiveMessage WHERE forumID=? AND forumIndex >= ? AND forumIndex < ?");
/* 1603 */       pstmt.setLong(1, forumID);
/* 1604 */       pstmt.setInt(2, startForumIndex);
/* 1605 */       pstmt.setInt(3, endForumIndex);
/*      */ 
/* 1607 */       ResultSet rs = pstmt.executeQuery();
/* 1608 */       while (rs.next()) {
/* 1609 */         long messageID = rs.getLong(1);
/* 1610 */         Long msgIDLong = new Long(messageID);
/* 1611 */         long parentMessageID = rs.getLong(2);
/* 1612 */         if (rs.wasNull()) {
/* 1613 */           parentMessageID = -1L;
/*      */         }
/* 1615 */         long threadID = rs.getLong(3);
/* 1616 */         int forumIndex = rs.getInt(4);
/*      */ 
/* 1619 */         messageIDs[(forumIndex - startForumIndex)] = msgIDLong;
/*      */ 
/* 1623 */         if (!messageCache.containsKey(msgIDLong))
/*      */         {
/* 1628 */           DbForumMessage message = new DbForumMessage();
/* 1629 */           message.id = messageID;
/* 1630 */           message.parentMessageID = parentMessageID;
/* 1631 */           message.threadID = threadID;
/* 1632 */           message.forumID = forumID;
/* 1633 */           message.forumIndex = forumIndex;
/* 1634 */           message.userID = rs.getLong(5);
/* 1635 */           if (rs.wasNull()) {
/* 1636 */             message.userID = -1L;
/*      */           }
/* 1638 */           message.subject = rs.getString(6);
/* 1639 */           if (rs.wasNull()) {
/* 1640 */             message.subject = "";
/*      */           }
/*      */ 
/* 1643 */           message.body = ConnectionManager.getLargeTextField(rs, 7);
/* 1644 */           if (rs.wasNull()) {
/* 1645 */             message.body = "";
/*      */           }
/* 1647 */           message.moderationValue = rs.getInt(8);
/* 1648 */           message.rewardPoints = rs.getInt(9);
/* 1649 */           message.creationDate = new Date(rs.getLong(10));
/* 1650 */           message.modificationDate = new Date(rs.getLong(11));
/*      */ 
/* 1652 */           message.setSaveState(1);
/*      */ 
/* 1655 */           messageCache.put(msgIDLong, message);
/*      */         }
/*      */       }
/* 1657 */       rs.close();
/*      */     }
/* 1660 */     catch (SQLException sqle) { Log.error(sqle);
/*      */       return;
/*      */     }
/*      */     catch (NumberFormatException nfe) {
/* 1664 */       Log.warn("WARNING: In DbForumMessage.loadBulkFromDb() -- there was an error parsing the dates returned from the database. Ensure that they're being stored correctly.");
/*      */       return;
/*      */     }
/*      */     finally
/*      */     {
/* 1670 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/* 1674 */     for (int i = 0; i < messageIDs.length; i++) {
/* 1675 */       int forumIndex = startForumIndex + i;
/* 1676 */       Long messageID = messageIDs[i];
/* 1677 */       String key = forumID + '-' + forumIndex;
/*      */ 
/* 1679 */       forumIndexCache.put(key, messageID);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void prepareInsertIntoDb(DbForumThread thread)
/*      */     throws SQLException, UnauthorizedException
/*      */   {
/* 1695 */     Forum forum = thread.getForum();
/* 1696 */     if (forum.getID() != this.forumID) {
/* 1697 */       throw new UnauthorizedException("Message created in forum " + this.forumID + " cannot be added to forum " + forum.getID());
/*      */     }
/*      */ 
/* 1701 */     if (this.id == -1L) {
/* 1702 */       this.id = SequenceManager.nextID(2);
/*      */     }
/*      */ 
/* 1708 */     if (this.moderationValue < 1) {
/* 1709 */       this.forumIndex = 0;
/*      */     }
/*      */     else
/* 1712 */       this.forumIndex = getForumIndexValues(1, this.forumID);
/*      */   }
/*      */ 
/*      */   protected void insertIntoDb(DbForumThread thread, long parentMessageID, Connection con)
/*      */     throws SQLException, UnauthorizedException
/*      */   {
/* 1728 */     Profiler.begin("insertIntoDb");
/*      */ 
/* 1730 */     if (this.id == -1L) {
/* 1731 */       throw new IllegalStateException("Must call prepareInsertIntoDb before calling this method.");
/*      */     }
/*      */ 
/* 1735 */     setSaveState(0);
/*      */ 
/* 1737 */     this.threadID = thread.getID();
/* 1738 */     this.parentMessageID = parentMessageID;
/*      */ 
/* 1740 */     Forum forum = thread.getForum();
/*      */ 
/* 1742 */     if (forum.getID() != this.forumID) {
/* 1743 */       throw new UnauthorizedException("Message created in forum " + this.forumID + " cannot be added to forum " + forum.getID());
/*      */     }
/*      */ 
/* 1749 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1751 */       Profiler.begin("insertSql");
/* 1752 */       pstmt = con.prepareStatement("INSERT INTO jiveMessage (messageID, parentMessageID, threadID, forumID, forumIndex, userID, subject, body, modValue, rewardPoints, creationDate, modificationDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
/* 1753 */       pstmt.setLong(1, this.id);
/* 1754 */       if (parentMessageID == -1L) {
/* 1755 */         pstmt.setNull(2, -5);
/*      */       }
/*      */       else {
/* 1758 */         pstmt.setLong(2, parentMessageID);
/*      */       }
/* 1760 */       pstmt.setLong(3, this.threadID);
/* 1761 */       pstmt.setLong(4, thread.forumID);
/* 1762 */       pstmt.setInt(5, this.forumIndex);
/* 1763 */       if (this.userID == -1L) {
/* 1764 */         pstmt.setNull(6, -5);
/*      */       }
/*      */       else {
/* 1767 */         pstmt.setLong(6, this.userID);
/*      */       }
/* 1769 */       pstmt.setString(7, this.subject);
/*      */ 
/* 1771 */       ConnectionManager.setLargeTextField(pstmt, 8, this.body);
/* 1772 */       pstmt.setInt(9, this.moderationValue);
/* 1773 */       pstmt.setInt(10, this.rewardPoints);
/* 1774 */       pstmt.setLong(11, this.creationDate.getTime());
/* 1775 */       pstmt.setLong(12, this.modificationDate.getTime());
/* 1776 */       pstmt.executeUpdate();
/*      */     }
/*      */     finally {
/* 1779 */       ConnectionManager.closePreparedStatement(pstmt);
/* 1780 */       Profiler.end("insertSql");
/*      */     }
/*      */ 
/* 1784 */     for (Iterator i = this.properties.keySet().iterator(); i.hasNext(); ) {
/* 1785 */       String name = (String)i.next();
/* 1786 */       String value = (String)this.properties.get(name);
/* 1787 */       insertPropertyIntoDb(name, value, con);
/*      */     }
/*      */ 
/* 1792 */     synchronized (this.attachments) {
/* 1793 */       for (int i = 0; i < this.attachments.size(); i++) {
/* 1794 */         DbAttachment.setObjectID(this.attachments.get(i), this.id, con);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1800 */     setSaveState(1);
/*      */ 
/* 1802 */     Profiler.end("insertIntoDb");
/*      */   }
/*      */ 
/*      */   private synchronized void saveToDb()
/*      */   {
/* 1809 */     boolean abortTransaction = false;
/* 1810 */     Connection con = null;
/*      */     try {
/* 1812 */       con = ConnectionManager.getTransactionConnection();
/* 1813 */       saveToDb(con);
/*      */     }
/*      */     catch (Exception e) {
/* 1816 */       Log.error(e);
/* 1817 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/* 1820 */       ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void saveToDb(Connection con)
/*      */     throws SQLException
/*      */   {
/* 1829 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1831 */       pstmt = con.prepareStatement("UPDATE jiveMessage SET subject=?, body=?, modValue=?, rewardPoints=?, creationDate=?, modificationDate=? WHERE messageID=?");
/* 1832 */       pstmt.setString(1, this.subject);
/*      */ 
/* 1834 */       ConnectionManager.setLargeTextField(pstmt, 2, this.body);
/* 1835 */       pstmt.setInt(3, this.moderationValue);
/* 1836 */       pstmt.setInt(4, this.rewardPoints);
/* 1837 */       pstmt.setLong(5, this.creationDate.getTime());
/* 1838 */       pstmt.setLong(6, this.modificationDate.getTime());
/* 1839 */       pstmt.setLong(7, this.id);
/* 1840 */       pstmt.executeUpdate();
/*      */     }
/*      */     finally {
/* 1843 */       ConnectionManager.closePreparedStatement(pstmt);
/*      */     }
/*      */   }
/*      */ 
/*      */   static int getForumIndexValues(int count, long forumID)
/*      */     throws SQLException
/*      */   {
/* 1860 */     if (SequenceManager.isNamedSequencesSupportd()) {
/*      */       try {
/* 1862 */         Profiler.begin("getForumIndexValues");
/* 1863 */         return (int)SequenceManager.nextID("forumIdx" + forumID);
/*      */       } finally {
/* 1865 */         Profiler.end("getForumIndexValues");
/*      */       }
/*      */     }
/*      */ 
/* 1869 */     String key = "forumIndex-" + forumID;
/*      */     try {
/* 1871 */       Profiler.begin("getForumIndexValues");
/*      */ 
/* 1873 */       Profiler.begin("lock");
/* 1874 */       CacheFactory.lockingMap.lock(key, -1L);
/* 1875 */       Profiler.end("lock");
/*      */ 
/* 1877 */       for (int i = 0; i < 3; i++) {
/* 1878 */         Connection con = null;
/* 1879 */         PreparedStatement pstmt = null;
/* 1880 */         boolean abortTransaction = false;
/*      */         try {
/* 1882 */           con = ConnectionManager.getTransactionConnection();
/*      */ 
/* 1884 */           pstmt = con.prepareStatement("SELECT forumIndexCounter from jiveForum WHERE forumID=?");
/* 1885 */           pstmt.setLong(1, forumID);
/* 1886 */           ResultSet rs = pstmt.executeQuery();
/* 1887 */           if (!rs.next()) {
/* 1888 */             throw new SQLException("Loading the current forumIndex failed. The jiveForum table may not be correct.");
/*      */           }
/*      */ 
/* 1891 */           int currentIndex = rs.getInt(1);
/* 1892 */           rs.close();
/* 1893 */           pstmt.close();
/*      */ 
/* 1896 */           int newIndex = currentIndex + count;
/*      */ 
/* 1900 */           pstmt = con.prepareStatement("UPDATE jiveForum SET forumIndexCounter=? WHERE forumID=? AND forumIndexCounter=?");
/* 1901 */           pstmt.setInt(1, newIndex);
/* 1902 */           pstmt.setLong(2, forumID);
/* 1903 */           pstmt.setInt(3, currentIndex);
/*      */ 
/* 1907 */           if (pstmt.executeUpdate() == 1) {
/* 1908 */             int j = newIndex;
/*      */ 
/* 1916 */             ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */ 
/* 1929 */             return j;
/*      */           }
/*      */         }
/*      */         catch (SQLException sqle)
/*      */         {
/* 1912 */           abortTransaction = true;
/* 1913 */           throw sqle;
/*      */         }
/*      */         finally {
/* 1916 */           ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */         }
/* 1918 */         Log.warn("Getting next forumIndex for forum " + forumID + " failed. Trying again.");
/*      */ 
/* 1920 */         Thread.yield();
/*      */       }
/*      */     }
/*      */     finally {
/* 1924 */       Profiler.begin("unlock");
/* 1925 */       CacheFactory.lockingMap.unlock(key);
/* 1926 */       Profiler.end("unlock");
/*      */ 
/* 1928 */       Profiler.end("getForumIndexValues");
/*      */     }
/* 1930 */     throw new SQLException("Failed at attempt to get next forumIndex in forum " + forumID + ".");
/*      */   }
/*      */ 
/*      */   private void readObject(ObjectInputStream in)
/*      */     throws IOException, ClassNotFoundException
/*      */   {
/* 1936 */     in.defaultReadObject();
/*      */ 
/* 1940 */     this.saveLock = new Object();
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbForumMessage
 * JD-Core Version:    0.6.2
 */
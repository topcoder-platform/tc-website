package com.jivesoftware.forum.database;

abstract interface DatabaseObjectFactory
{
  public abstract Object loadObject(long paramLong);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DatabaseObjectFactory
 * JD-Core Version:    0.6.2
 */
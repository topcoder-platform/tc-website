/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.FilterManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.database.sequence.SequenceManager;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.AttachmentException;
/*     */ import com.jivesoftware.forum.AttachmentManager;
/*     */ import com.jivesoftware.forum.AttachmentNotFoundException;
/*     */ import com.jivesoftware.forum.PrivateMessage;
/*     */ import com.jivesoftware.forum.PrivateMessageFolder;
/*     */ import com.jivesoftware.forum.PrivateMessageFolderNotFoundException;
/*     */ import com.jivesoftware.forum.PrivateMessageManager;
/*     */ import com.jivesoftware.forum.PrivateMessageNotFoundException;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheSizes;
/*     */ import com.jivesoftware.util.Cacheable;
/*     */ import com.jivesoftware.util.ExtendedPropertyUtils;
/*     */ import com.jivesoftware.util.ExternalizableLiteUtil;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import com.tangosol.io.ExternalizableLite;
/*     */ import com.tangosol.util.ExternalizableHelper;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DbPrivateMessage
/*     */   implements PrivateMessage, Cacheable, ExternalizableLite
/*     */ {
/*     */   public static final String DRAFTS_PROPERTY_KEY = "draft.to";
/*     */   private static final String UPDATE_READ_STATUS = "UPDATE jivePMessage SET readStatus=? WHERE pMessageID=?";
/*     */   private static final String LOAD_ATTACHMENTS = "SELECT attachmentID FROM jiveAttachment WHERE objectType=20 AND objectID=?";
/*     */   private static final String LOAD_PROPERTIES = "SELECT name, propValue FROM jivePMessageProp WHERE pMessageID=?";
/*     */   private static final String INSERT_PROPERTY = "INSERT INTO jivePMessageProp(pMessageID,name,propValue) VALUES(?,?,?)";
/*     */   private static final String UPDATE_PROPERTY = "UPDATE jivePMessageProp SET propValue=? WHERE name=? AND pMessageID=?";
/*     */   private static final String DELETE_PROPERTY = "DELETE FROM jivePMessageProp WHERE pMessageID=? AND name=?";
/*     */   private static final String LOAD_PRIVATE_MESSAGE = "SELECT ownerID, senderID, recipientID, subject, body, readStatus, folderID, pMessageDate FROM jivePMessage WHERE pMessageID=?";
/*     */   private static final String INSERT_PRIVATE_MESSAGE = "INSERT INTO jivePMessage(pMessageID, ownerID, senderID, recipientID,subject, body, readStatus, folderID, pMessageDate) VALUES(?,?,?,?,?,?,?,?,?)";
/*     */   private static final String SAVE_PRIVATE_MESSAGE = "UPDATE jivePMessage SET subject=?, body=?, recipientID=?, readStatus=?,folderID=?, pMessageDate=? WHERE pMessageID=?";
/*     */   private static final String SET_FOLDER = "UPDATE jivePMessage SET folderID=?, ownerID=? WHERE pMessageID=?";
/*     */   private static final long serialVersionUID = 1L;
/*  73 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */ 
/*  75 */   private long id = -1L;
/*     */   private Date date;
/*  77 */   private String subject = "";
/*  78 */   private String body = "";
/*  79 */   private long ownerID = -1L;
/*  80 */   private long senderID = -1L;
/*  81 */   private long recipientID = -1L;
/*  82 */   private int folderID = -1;
/*     */ 
/*  84 */   private boolean read = false;
/*     */ 
/*  86 */   private Map properties = null;
/*     */   private LongList attachments;
/*  91 */   protected String filteredSubject = null;
/*  92 */   protected String filteredBody = null;
/*  93 */   protected Map filteredProperties = null;
/*     */ 
/* 100 */   private boolean readyToSave = false;
/*     */ 
/*     */   public DbPrivateMessage(User sender)
/*     */   {
/* 108 */     if (sender != null) {
/* 109 */       this.senderID = sender.getID();
/*     */     }
/* 111 */     this.properties = new Hashtable();
/* 112 */     this.attachments = new LongList();
/*     */   }
/*     */ 
/*     */   public DbPrivateMessage(DbPrivateMessage originalMessage)
/*     */   {
/* 121 */     this.date = new Date(originalMessage.date.getTime());
/* 122 */     this.subject = originalMessage.subject;
/* 123 */     this.body = originalMessage.body;
/* 124 */     this.ownerID = originalMessage.ownerID;
/* 125 */     this.senderID = originalMessage.senderID;
/* 126 */     this.recipientID = originalMessage.recipientID;
/* 127 */     this.folderID = originalMessage.folderID;
/* 128 */     this.read = originalMessage.read;
/* 129 */     this.properties = new Hashtable(originalMessage.properties);
/* 130 */     this.attachments = new LongList();
/* 131 */     if (originalMessage.attachments != null)
/* 132 */       for (int i = 0; i < originalMessage.attachments.size(); i++)
/*     */         try {
/* 134 */           Attachment attachment = FACTORY.cacheManager.getAttachment(originalMessage.attachments.get(i));
/*     */ 
/* 136 */           createAttachment(attachment.getName(), attachment.getContentType(), attachment.getData());
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 140 */           Log.error(e);
/*     */         }
/*     */   }
/*     */ 
/*     */   public DbPrivateMessage(long pMessageID)
/*     */     throws PrivateMessageNotFoundException
/*     */   {
/* 154 */     this.id = pMessageID;
/* 155 */     loadFromDb();
/* 156 */     this.readyToSave = true;
/*     */   }
/*     */ 
/*     */   public DbPrivateMessage()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void readExternal(DataInput in)
/*     */     throws IOException
/*     */   {
/* 167 */     this.id = ExternalizableHelper.readLong(in);
/* 168 */     this.date = new Date(in.readLong());
/* 169 */     this.subject = ExternalizableHelper.readSafeUTF(in);
/* 170 */     this.body = ExternalizableHelper.readSafeUTF(in);
/* 171 */     this.ownerID = ExternalizableHelper.readLong(in);
/* 172 */     this.senderID = ExternalizableHelper.readLong(in);
/* 173 */     this.recipientID = ExternalizableHelper.readLong(in);
/* 174 */     this.folderID = ExternalizableHelper.readInt(in);
/* 175 */     this.read = in.readBoolean();
/* 176 */     this.readyToSave = in.readBoolean();
/* 177 */     this.properties = ExternalizableLiteUtil.readStringMap(in);
/* 178 */     this.attachments = ExternalizableLiteUtil.readLongList(in);
/* 179 */     this.readyToSave = in.readBoolean();
/*     */   }
/*     */ 
/*     */   public void writeExternal(DataOutput out) throws IOException {
/* 183 */     ExternalizableHelper.writeLong(out, this.id);
/* 184 */     if (this.date != null) {
/* 185 */       out.writeLong(this.date.getTime());
/*     */     }
/* 187 */     ExternalizableHelper.writeSafeUTF(out, this.subject);
/* 188 */     ExternalizableHelper.writeSafeUTF(out, this.body);
/* 189 */     ExternalizableHelper.writeLong(out, this.ownerID);
/* 190 */     ExternalizableHelper.writeLong(out, this.senderID);
/* 191 */     ExternalizableHelper.writeLong(out, this.recipientID);
/* 192 */     ExternalizableHelper.writeInt(out, this.folderID);
/* 193 */     out.writeBoolean(this.read);
/* 194 */     out.writeBoolean(this.readyToSave);
/* 195 */     ExternalizableLiteUtil.writeStringMap(out, this.properties);
/* 196 */     ExternalizableLiteUtil.writeLongList(out, this.attachments);
/* 197 */     out.writeBoolean(this.readyToSave);
/*     */   }
/*     */ 
/*     */   public long getID() {
/* 201 */     return this.id;
/*     */   }
/*     */ 
/*     */   public Date getDate() {
/* 205 */     return this.date;
/*     */   }
/*     */ 
/*     */   void setDate(Date date) {
/* 209 */     this.date = date;
/*     */   }
/*     */ 
/*     */   public PrivateMessageFolder getFolder() {
/* 213 */     if (this.folderID == -1) {
/* 214 */       return null;
/*     */     }
/* 216 */     PrivateMessageFolder folder = null;
/*     */     try {
/* 218 */       DbPrivateMessageManager manager = (DbPrivateMessageManager)FACTORY.getPrivateMessageManager();
/*     */ 
/* 220 */       folder = manager.getPrivateMessageFolder(this.folderID, this.ownerID);
/*     */     }
/*     */     catch (PrivateMessageFolderNotFoundException e) {
/* 223 */       Log.error(e);
/*     */     }
/* 225 */     return folder;
/*     */   }
/*     */ 
/*     */   public void setFolder(PrivateMessageFolder folder) {
/* 229 */     this.ownerID = folder.getOwner().getID();
/* 230 */     this.folderID = folder.getID();
/* 231 */     if (this.readyToSave) {
/* 232 */       Connection con = null;
/* 233 */       PreparedStatement pstmt = null;
/* 234 */       boolean abortTransaction = false;
/*     */       try {
/* 236 */         con = ConnectionManager.getTransactionConnection();
/* 237 */         pstmt = con.prepareStatement("UPDATE jivePMessage SET folderID=?, ownerID=? WHERE pMessageID=?");
/* 238 */         pstmt.setInt(1, this.folderID);
/* 239 */         pstmt.setLong(2, this.ownerID);
/* 240 */         pstmt.setLong(3, this.id);
/* 241 */         pstmt.executeUpdate();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 244 */         Log.error(sqle);
/* 245 */         abortTransaction = true;
/*     */       }
/*     */       finally {
/* 248 */         ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */       }
/*     */     }
/*     */ 
/* 252 */     if (folder.getID() == 4) {
/* 253 */       FACTORY.cacheManager.privateMessageCache.remove("total_pmcount-" + this.ownerID);
/* 254 */       FACTORY.cacheManager.privateMessageCache.remove("unread_pmcount-" + this.ownerID);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getSubject()
/*     */   {
/* 260 */     if (this.filteredSubject == null) {
/* 261 */       FilterManager filterManager = FACTORY.getPrivateMessageManager().getFilterManager();
/* 262 */       this.filteredSubject = filterManager.applyFilters(this, 8L, this.subject);
/*     */     }
/*     */ 
/* 265 */     return this.filteredSubject;
/*     */   }
/*     */ 
/*     */   public String getUnfilteredSubject() {
/* 269 */     return this.subject;
/*     */   }
/*     */ 
/*     */   public void setSubject(String subject) throws UnauthorizedException
/*     */   {
/* 274 */     if ((this.readyToSave) && (this.folderID != 3)) {
/* 275 */       throw new UnauthorizedException("Cannot edit a private message after it has been sent");
/*     */     }
/* 277 */     this.subject = subject;
/* 278 */     this.filteredSubject = null;
/* 279 */     if (this.readyToSave)
/* 280 */       saveToDb();
/*     */   }
/*     */ 
/*     */   public String getBody()
/*     */   {
/* 286 */     if (this.filteredBody == null) {
/* 287 */       FilterManager filterManager = FACTORY.getPrivateMessageManager().getFilterManager();
/* 288 */       this.filteredBody = filterManager.applyFilters(this, 16L, this.body);
/*     */     }
/*     */ 
/* 291 */     return this.filteredBody;
/*     */   }
/*     */ 
/*     */   public String getUnfilteredBody() {
/* 295 */     return this.body;
/*     */   }
/*     */ 
/*     */   public void setBody(String body) throws UnauthorizedException
/*     */   {
/* 300 */     if (body == null) {
/* 301 */       throw new IllegalArgumentException("Body cannot be null");
/*     */     }
/*     */ 
/* 305 */     if ((this.readyToSave) && (this.folderID != 3)) {
/* 306 */       throw new UnauthorizedException("Cannot edit a private message after it has been sent");
/*     */     }
/*     */ 
/* 310 */     if (body.equals(this.body)) {
/* 311 */       return;
/*     */     }
/*     */ 
/* 315 */     this.body = body;
/*     */ 
/* 317 */     if (!this.readyToSave) {
/* 318 */       return;
/*     */     }
/*     */ 
/* 322 */     this.filteredBody = null;
/*     */ 
/* 325 */     saveToDb();
/*     */   }
/*     */ 
/*     */   public User getSender() {
/* 329 */     User sender = null;
/*     */     try {
/* 331 */       sender = FACTORY.getUserManager().getUser(this.senderID);
/*     */     } catch (UserNotFoundException unfe) {
/*     */     }
/* 334 */     return sender;
/*     */   }
/*     */ 
/*     */   public User getRecipient() {
/* 338 */     User recipient = null;
/*     */     try {
/* 340 */       recipient = FACTORY.getUserManager().getUser(this.recipientID);
/*     */     } catch (UserNotFoundException unfe) {
/*     */     }
/* 343 */     return recipient;
/*     */   }
/*     */ 
/*     */   public void setRecipient(User recipient) {
/* 347 */     if (recipient != null) {
/* 348 */       this.recipientID = recipient.getID();
/*     */     }
/*     */     else
/* 351 */       this.recipientID = -1L;
/*     */   }
/*     */ 
/*     */   public boolean isRead()
/*     */   {
/* 356 */     return this.read;
/*     */   }
/*     */ 
/*     */   public synchronized void setRead(boolean read)
/*     */   {
/* 361 */     if (this.read == read) {
/* 362 */       return;
/*     */     }
/* 364 */     this.read = read;
/* 365 */     Connection con = null;
/* 366 */     PreparedStatement pstmt = null;
/* 367 */     boolean abortTransaction = false;
/*     */     try {
/* 369 */       con = ConnectionManager.getTransactionConnection();
/* 370 */       pstmt = con.prepareStatement("UPDATE jivePMessage SET readStatus=? WHERE pMessageID=?");
/* 371 */       pstmt.setInt(1, read ? 1 : 0);
/* 372 */       pstmt.setLong(2, this.id);
/* 373 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 376 */       Log.error(sqle);
/* 377 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 380 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/* 382 */     FACTORY.cacheManager.privateMessageCache.put(new Long(this.id), this);
/*     */ 
/* 384 */     String unreadKey = "unread_pmcount-" + this.ownerID;
/* 385 */     Integer unreadCount = (Integer)FACTORY.cacheManager.privateMessageCache.get(unreadKey);
/* 386 */     if (unreadCount != null) {
/* 387 */       unreadCount = new Integer(unreadCount.intValue() + (read ? -1 : 1));
/* 388 */       FACTORY.cacheManager.privateMessageCache.put(unreadKey, unreadCount);
/*     */     }
/*     */ 
/* 391 */     FACTORY.cacheManager.privateMessageFolderCache.remove(DbPrivateMessageFolder.getCacheKey(this.folderID, this.ownerID));
/*     */   }
/*     */ 
/*     */   public Attachment createAttachment(String name, String contentType, InputStream data)
/*     */     throws IllegalStateException, AttachmentException, UnauthorizedException
/*     */   {
/* 399 */     if ((this.readyToSave) && (this.folderID != 3)) {
/* 400 */       throw new UnauthorizedException("Cannot edit a private message after it has been sent");
/*     */     }
/*     */ 
/* 403 */     AttachmentManager attachmentManager = FACTORY.getAttachmentManager();
/*     */ 
/* 405 */     if (getAttachmentCount() > attachmentManager.getMaxAttachmentsPerMessage()) {
/* 406 */       throw new AttachmentException(1, name);
/*     */     }
/* 408 */     Attachment attachment = new DbAttachment(20, this.id, name, contentType, data);
/*     */ 
/* 410 */     synchronized (this.attachments) {
/* 411 */       this.attachments.add(attachment.getID());
/*     */     }
/*     */ 
/* 414 */     if (this.readyToSave)
/*     */     {
/* 416 */       FACTORY.cacheManager.privateMessageCache.put(new Long(this.id), this);
/*     */     }
/* 418 */     return attachment;
/*     */   }
/*     */ 
/*     */   public int getAttachmentCount() {
/* 422 */     if (this.attachments == null)
/*     */     {
/* 424 */       getAttachments();
/*     */     }
/* 426 */     synchronized (this.attachments) {
/* 427 */       return this.attachments.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteAttachment(Attachment attachment)
/*     */     throws AttachmentException, UnauthorizedException
/*     */   {
/* 435 */     if ((this.readyToSave) && (this.folderID != 3)) {
/* 436 */       throw new UnauthorizedException("Cannot edit a private message after it has been sent");
/*     */     }
/*     */ 
/* 439 */     if (!this.readyToSave) {
/* 440 */       synchronized (this.attachments) {
/* 441 */         int index = this.attachments.indexOf(attachment.getID());
/* 442 */         if (index >= 0) {
/* 443 */           this.attachments.remove(index);
/*     */         }
/*     */         else
/*     */         {
/* 447 */           throw new IllegalArgumentException("Attachment does not belong to message");
/*     */         }
/* 449 */         return;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 454 */     DbAttachment dbAttachment = null;
/* 455 */     if ((attachment instanceof DbAttachment))
/* 456 */       dbAttachment = (DbAttachment)attachment;
/*     */     else {
/*     */       try
/*     */       {
/* 460 */         dbAttachment = FACTORY.cacheManager.getAttachment(attachment.getID());
/*     */       }
/*     */       catch (AttachmentNotFoundException anfe) {
/* 463 */         throw new AttachmentException(3, anfe, attachment.getName());
/*     */       }
/*     */     }
/*     */ 
/* 467 */     if (dbAttachment.getObjectID() != this.id) {
/* 468 */       throw new IllegalArgumentException("Attachment does not belong to message.");
/*     */     }
/* 470 */     Connection con = null;
/*     */     try {
/* 472 */       con = ConnectionManager.getConnection();
/* 473 */       dbAttachment.delete(con);
/* 474 */       this.attachments = null;
/*     */ 
/* 476 */       FACTORY.cacheManager.privateMessageCache.put(new Long(this.id), this);
/*     */     }
/*     */     catch (Exception e) {
/* 479 */       throw new AttachmentException(3, e, attachment.getName());
/*     */     }
/*     */     finally {
/* 482 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Iterator getAttachments() {
/* 487 */     if (this.attachments == null) {
/* 488 */       LongList attachmentList = new LongList();
/* 489 */       Connection con = null;
/* 490 */       PreparedStatement pstmt = null;
/*     */       try {
/* 492 */         con = ConnectionManager.getConnection();
/* 493 */         pstmt = con.prepareStatement("SELECT attachmentID FROM jiveAttachment WHERE objectType=20 AND objectID=?");
/* 494 */         pstmt.setLong(1, this.id);
/* 495 */         ResultSet rs = pstmt.executeQuery();
/* 496 */         while (rs.next()) {
/* 497 */           attachmentList.add(rs.getLong(1));
/*     */         }
/* 499 */         rs.close();
/* 500 */         this.attachments = attachmentList;
/*     */ 
/* 502 */         FACTORY.cacheManager.privateMessageCache.put(new Long(this.id), this);
/*     */       }
/*     */       catch (SQLException sqle) {
/* 505 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 508 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */     }
/* 511 */     return new DatabaseObjectIterator(13, this.attachments.toArray(), FACTORY);
/*     */   }
/*     */ 
/*     */   public String getProperty(String name)
/*     */   {
/* 517 */     if (this.filteredProperties == null) {
/* 518 */       Hashtable props = new Hashtable();
/* 519 */       FilterManager filterManager = FACTORY.getPrivateMessageManager().getFilterManager();
/* 520 */       for (Iterator i = getPropertyNames(); i.hasNext(); ) {
/* 521 */         String propName = (String)i.next();
/* 522 */         String filteredValue = filterManager.applyFilters(this, 4L, (String)this.properties.get(propName));
/*     */ 
/* 524 */         props.put(propName, filteredValue);
/*     */       }
/* 526 */       this.filteredProperties = props;
/*     */     }
/*     */ 
/* 529 */     return (String)this.filteredProperties.get(name);
/*     */   }
/*     */ 
/*     */   public String getUnfilteredProperty(String name) {
/* 533 */     return (String)this.properties.get(name);
/*     */   }
/*     */ 
/*     */   public Collection getProperties(String parentName) {
/* 537 */     Object[] keys = this.properties.keySet().toArray();
/* 538 */     ArrayList results = new ArrayList();
/* 539 */     int i = 0; for (int n = keys.length; i < n; i++) {
/* 540 */       String key = (String)keys[i];
/* 541 */       if ((key.startsWith(parentName)) && 
/* 542 */         (!key.equals(parentName)))
/*     */       {
/* 545 */         if (key.substring(parentName.length()).lastIndexOf(".") == 0) {
/* 546 */           results.add(this.properties.get(key));
/*     */         }
/*     */       }
/*     */     }
/* 550 */     return Collections.unmodifiableCollection(results);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value)
/*     */   {
/* 555 */     value = ExtendedPropertyUtils.validateExtendedProperty(name, value);
/*     */ 
/* 557 */     if (this.properties.containsKey(name))
/*     */     {
/* 560 */       if (!value.equals(this.properties.get(name))) {
/* 561 */         this.properties.put(name, value);
/* 562 */         if (this.readyToSave) {
/* 563 */           updatePropertyInDb(name, value);
/*     */ 
/* 565 */           this.filteredProperties = null;
/*     */ 
/* 567 */           FACTORY.cacheManager.privateMessageCache.put(new Long(this.id), this);
/*     */         }
/*     */       }
/*     */     } else {
/* 571 */       this.properties.put(name, value);
/* 572 */       if (this.readyToSave) {
/* 573 */         Connection con = null;
/* 574 */         boolean abortTransaction = false;
/*     */         try {
/* 576 */           con = ConnectionManager.getTransactionConnection();
/* 577 */           insertPropertyIntoDb(name, value, con);
/*     */         }
/*     */         catch (SQLException sqle) {
/* 580 */           Log.error(sqle);
/* 581 */           abortTransaction = true;
/*     */         }
/*     */         finally {
/* 584 */           ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*     */         }
/*     */ 
/* 587 */         this.filteredProperties = null;
/*     */ 
/* 589 */         FACTORY.cacheManager.privateMessageCache.put(new Long(this.id), this);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name)
/*     */   {
/* 596 */     if (this.properties.containsKey(name)) {
/* 597 */       this.properties.remove(name);
/*     */ 
/* 599 */       if (this.readyToSave) {
/* 600 */         deletePropertyFromDb(name);
/*     */ 
/* 602 */         this.filteredProperties = null;
/*     */ 
/* 604 */         FACTORY.cacheManager.privateMessageCache.put(new Long(this.id), this);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames() {
/* 610 */     return Collections.unmodifiableSet(this.properties.keySet()).iterator();
/*     */   }
/*     */ 
/*     */   public long getOwnerID()
/*     */   {
/* 619 */     return this.ownerID;
/*     */   }
/*     */ 
/*     */   public boolean isAuthorized(long permissionType) {
/* 623 */     return true;
/*     */   }
/*     */ 
/*     */   public int getCachedSize() {
/* 627 */     int size = 0;
/* 628 */     size += CacheSizes.sizeOfObject();
/* 629 */     size += CacheSizes.sizeOfLong();
/* 630 */     size += CacheSizes.sizeOfString(this.subject) * 2;
/* 631 */     size += CacheSizes.sizeOfString(this.body) * 2;
/* 632 */     size += CacheSizes.sizeOfDate();
/* 633 */     size += CacheSizes.sizeOfInt();
/* 634 */     size += CacheSizes.sizeOfLong();
/* 635 */     size += CacheSizes.sizeOfLong();
/* 636 */     size += CacheSizes.sizeOfLong();
/* 637 */     size += CacheSizes.sizeOfMap(this.properties) * 2;
/* 638 */     size += CacheSizes.sizeOfObject();
/* 639 */     size += CacheSizes.sizeOfBoolean();
/* 640 */     if (this.attachments != null) {
/* 641 */       size += CacheSizes.sizeOfLong() * this.attachments.size() + CacheSizes.sizeOfObject();
/*     */     }
/*     */ 
/* 644 */     return size;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 648 */     return "[" + this.id + "] \"" + this.subject + "\", from " + getSender() + " to " + getRecipient();
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 652 */     return (int)this.id;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object) {
/* 656 */     if (this == object) {
/* 657 */       return true;
/*     */     }
/* 659 */     if ((object != null) && ((object instanceof ExternalizableLite))) {
/* 660 */       return this.id == ((ExternalizableLite)object).getID();
/*     */     }
/*     */ 
/* 663 */     return false;
/*     */   }
/*     */ 
/*     */   private void insertPropertyIntoDb(String name, String value, Connection con)
/*     */     throws SQLException
/*     */   {
/* 671 */     PreparedStatement pstmt = null;
/*     */     try {
/* 673 */       pstmt = con.prepareStatement("INSERT INTO jivePMessageProp(pMessageID,name,propValue) VALUES(?,?,?)");
/* 674 */       pstmt.setLong(1, this.id);
/* 675 */       pstmt.setString(2, name);
/* 676 */       pstmt.setString(3, value);
/* 677 */       pstmt.executeUpdate();
/*     */     }
/*     */     finally {
/* 680 */       ConnectionManager.closePreparedStatement(pstmt);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updatePropertyInDb(String name, String value)
/*     */   {
/* 688 */     Connection con = null;
/* 689 */     PreparedStatement pstmt = null;
/* 690 */     boolean abortTransaction = false;
/*     */     try {
/* 692 */       con = ConnectionManager.getTransactionConnection();
/* 693 */       pstmt = con.prepareStatement("UPDATE jivePMessageProp SET propValue=? WHERE name=? AND pMessageID=?");
/* 694 */       pstmt.setString(1, value);
/* 695 */       pstmt.setString(2, name);
/* 696 */       pstmt.setLong(3, this.id);
/* 697 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 700 */       Log.error(sqle);
/* 701 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 704 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void deletePropertyFromDb(String name)
/*     */   {
/* 712 */     Connection con = null;
/* 713 */     PreparedStatement pstmt = null;
/* 714 */     boolean abortTransaction = false;
/*     */     try {
/* 716 */       con = ConnectionManager.getTransactionConnection();
/* 717 */       pstmt = con.prepareStatement("DELETE FROM jivePMessageProp WHERE pMessageID=? AND name=?");
/* 718 */       pstmt.setLong(1, this.id);
/* 719 */       pstmt.setString(2, name);
/* 720 */       pstmt.execute();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 723 */       Log.error(sqle);
/* 724 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 727 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadFromDb()
/*     */     throws PrivateMessageNotFoundException
/*     */   {
/* 735 */     Connection con = null;
/* 736 */     PreparedStatement pstmt = null;
/*     */     try {
/* 738 */       con = ConnectionManager.getConnection();
/* 739 */       pstmt = con.prepareStatement("SELECT ownerID, senderID, recipientID, subject, body, readStatus, folderID, pMessageDate FROM jivePMessage WHERE pMessageID=?");
/* 740 */       pstmt.setLong(1, this.id);
/*     */ 
/* 742 */       ResultSet rs = pstmt.executeQuery();
/* 743 */       if (!rs.next()) {
/* 744 */         throw new PrivateMessageNotFoundException("Private Message " + this.id + " could not be loaded from the database.");
/*     */       }
/*     */ 
/* 747 */       this.ownerID = rs.getLong(1);
/* 748 */       this.senderID = rs.getLong(2);
/* 749 */       if (rs.wasNull()) {
/* 750 */         this.senderID = -1L;
/*     */       }
/* 752 */       this.recipientID = rs.getLong(3);
/* 753 */       if (rs.wasNull()) {
/* 754 */         this.recipientID = -1L;
/*     */       }
/* 756 */       this.subject = rs.getString(4);
/* 757 */       if (rs.wasNull()) {
/* 758 */         this.subject = "";
/*     */       }
/*     */ 
/* 761 */       this.body = ConnectionManager.getLargeTextField(rs, 5);
/* 762 */       if (rs.wasNull()) {
/* 763 */         this.body = "";
/*     */       }
/* 765 */       this.read = (rs.getInt(6) == 1);
/* 766 */       this.folderID = rs.getInt(7);
/* 767 */       this.date = new Date(rs.getLong(8));
/* 768 */       rs.close();
/* 769 */       pstmt.close();
/*     */ 
/* 772 */       this.properties = new Hashtable();
/* 773 */       pstmt = con.prepareStatement("SELECT name, propValue FROM jivePMessageProp WHERE pMessageID=?");
/* 774 */       pstmt.setLong(1, this.id);
/* 775 */       rs = pstmt.executeQuery();
/* 776 */       while (rs.next())
/*     */       {
/* 778 */         this.properties.put(rs.getString(1), rs.getString(2));
/*     */       }
/* 780 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 783 */       throw new PrivateMessageNotFoundException("Private message with id " + this.id + " could not be loaded from the database.");
/*     */     }
/*     */     catch (NumberFormatException nfe)
/*     */     {
/* 788 */       Log.warn("WARNING: In DbPrivateMessage.loadFromDb() -- there was an error parsing the dates returned from the database. Ensure that they're being stored correctly.");
/*     */ 
/* 791 */       throw new PrivateMessageNotFoundException("Private message with id " + this.id + " could not be loaded from the database.");
/*     */     }
/*     */     finally
/*     */     {
/* 796 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void insertIntoDb()
/*     */     throws SQLException, UnauthorizedException
/*     */   {
/* 804 */     this.id = SequenceManager.nextID(20);
/* 805 */     this.date = new Date();
/*     */ 
/* 808 */     Connection con = null;
/* 809 */     boolean abortTransaction = false;
/*     */     try {
/* 811 */       con = ConnectionManager.getConnection();
/* 812 */       PreparedStatement pstmt = con.prepareStatement("INSERT INTO jivePMessage(pMessageID, ownerID, senderID, recipientID,subject, body, readStatus, folderID, pMessageDate) VALUES(?,?,?,?,?,?,?,?,?)");
/* 813 */       pstmt.setLong(1, this.id);
/* 814 */       pstmt.setLong(2, this.ownerID);
/* 815 */       if (this.senderID == -1L) {
/* 816 */         pstmt.setNull(3, -5);
/*     */       }
/*     */       else {
/* 819 */         pstmt.setLong(3, this.senderID);
/*     */       }
/* 821 */       if (this.recipientID == -1L) {
/* 822 */         pstmt.setNull(4, -5);
/*     */       }
/*     */       else {
/* 825 */         pstmt.setLong(4, this.recipientID);
/*     */       }
/* 827 */       pstmt.setString(5, this.subject);
/*     */ 
/* 829 */       ConnectionManager.setLargeTextField(pstmt, 6, this.body);
/* 830 */       pstmt.setInt(7, this.read ? 1 : 0);
/* 831 */       pstmt.setInt(8, this.folderID);
/* 832 */       pstmt.setLong(9, this.date.getTime());
/* 833 */       pstmt.executeUpdate();
/* 834 */       pstmt.close();
/*     */ 
/* 837 */       for (Iterator i = this.properties.keySet().iterator(); i.hasNext(); ) {
/* 838 */         String name = (String)i.next();
/* 839 */         String value = (String)this.properties.get(name);
/* 840 */         insertPropertyIntoDb(name, value, con);
/*     */       }
/*     */ 
/* 845 */       synchronized (this.attachments) {
/* 846 */         for (int i = 0; i < this.attachments.size(); i++)
/* 847 */           DbAttachment.setObjectID(this.attachments.get(i), this.id, con);
/*     */       }
/*     */     }
/*     */     catch (SQLException sqle)
/*     */     {
/* 852 */       abortTransaction = true;
/* 853 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 856 */       ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*     */     }
/*     */ 
/* 861 */     this.readyToSave = true;
/*     */   }
/*     */ 
/*     */   protected synchronized void saveToDb()
/*     */   {
/* 868 */     this.date = new Date();
/* 869 */     boolean abortTransaction = false;
/* 870 */     Connection con = null;
/* 871 */     PreparedStatement pstmt = null;
/*     */     try {
/* 873 */       con = ConnectionManager.getTransactionConnection();
/* 874 */       pstmt = con.prepareStatement("UPDATE jivePMessage SET subject=?, body=?, recipientID=?, readStatus=?,folderID=?, pMessageDate=? WHERE pMessageID=?");
/* 875 */       pstmt.setString(1, this.subject);
/*     */ 
/* 877 */       ConnectionManager.setLargeTextField(pstmt, 2, this.body);
/* 878 */       pstmt.setLong(3, this.recipientID);
/* 879 */       pstmt.setInt(4, this.read ? 1 : 0);
/* 880 */       pstmt.setInt(5, this.folderID);
/* 881 */       pstmt.setLong(6, this.date.getTime());
/* 882 */       pstmt.setLong(7, this.id);
/* 883 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (Exception e) {
/* 886 */       Log.error(e);
/* 887 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 890 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */ 
/* 893 */     this.readyToSave = true;
/*     */ 
/* 896 */     FACTORY.cacheManager.privateMessageCache.put(new Long(this.id), this);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbPrivateMessage
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Filter;
/*     */ import com.jivesoftware.base.FilterChain;
/*     */ import com.jivesoftware.base.FilterManager;
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.JiveManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.util.BeanUtils;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.ClassUtils;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DbFilterManager
/*     */   implements FilterManager, JiveManager
/*     */ {
/*  31 */   public static final String[] DEFAULT_FILTER_CLASSES = { "com.jivesoftware.base.filter.HTMLFilter", "com.jivesoftware.base.filter.Newline", "com.jivesoftware.base.filter.TextStyle", "com.jivesoftware.base.filter.URLConverter", "com.jivesoftware.base.filter.Profanity", "com.jivesoftware.base.filter.JavaCodeHighlighter", "com.jivesoftware.base.filter.WordBreak", "com.jivesoftware.base.filter.QuoteFilter", "com.jivesoftware.base.filter.Emoticon", "com.jivesoftware.base.filter.MSWordToText", "com.jivesoftware.base.filter.Regex", "com.jivesoftware.forum.filter.JIRAFilter", "com.jivesoftware.base.filter.XMLFilter" };
/*     */ 
/*  47 */   private static ArrayList availableFilters = null;
/*     */   private static DbForumFactory FACTORY;
/*  50 */   private boolean initialized = false;
/*     */   private int objectType;
/*     */   private long objectID;
/*     */   private Filter[] filters;
/*     */   private long[] filterTypes;
/*     */ 
/*     */   public DbFilterManager(int objectType, long objectID)
/*     */   {
/*  61 */     this.objectType = objectType;
/*  62 */     this.objectID = objectID;
/*     */   }
/*     */ 
/*     */   public synchronized void initialize() {
/*  66 */     if (!this.initialized) {
/*  67 */       FACTORY = DbForumFactory.getInstance();
/*  68 */       initialSetup();
/*  69 */       if (this.objectType == 17) {
/*  70 */         loadGlobalFilters();
/*     */       }
/*  72 */       else if (this.objectType == 14) {
/*     */         try {
/*  74 */           loadCategoryFilters();
/*     */         }
/*     */         catch (ForumCategoryNotFoundException e) {
/*  77 */           Log.error(e);
/*     */         }
/*     */       }
/*  80 */       else if (this.objectType == 0) {
/*     */         try {
/*  82 */           loadForumFilters();
/*     */         }
/*     */         catch (ForumNotFoundException e) {
/*  85 */           Log.error(e);
/*     */         }
/*     */       }
/*  88 */       this.initialized = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Filter[] getAvailableFilters() throws UnauthorizedException {
/*  93 */     if (availableFilters == null) {
/*  94 */       loadAvailableFilters();
/*     */     }
/*  96 */     return (Filter[])availableFilters.toArray(new Filter[availableFilters.size()]);
/*     */   }
/*     */ 
/*     */   public void addFilterClass(String className)
/*     */     throws UnauthorizedException, ClassNotFoundException, IllegalArgumentException
/*     */   {
/* 103 */     Class newClass = ClassUtils.forName(className);
/*     */     try {
/* 105 */       Object newFilter = newClass.newInstance();
/* 106 */       if (!(newFilter instanceof Filter)) {
/* 107 */         throw new IllegalArgumentException("Class is not a Filter");
/*     */       }
/* 109 */       synchronized (availableFilters)
/*     */       {
/* 111 */         for (int i = 0; i < availableFilters.size(); i++) {
/* 112 */           if (newFilter.getClass().equals(availableFilters.get(i).getClass())) {
/* 113 */             return;
/*     */           }
/*     */         }
/*     */ 
/* 117 */         availableFilters.add(newFilter);
/*     */ 
/* 120 */         JiveGlobals.deleteJiveProperty("filter.filterClasses");
/* 121 */         Filter[] filters = (Filter[])availableFilters.toArray(new Filter[0]);
/* 122 */         Map propertyMap = new HashMap(filters.length);
/* 123 */         for (int i = 0; i < filters.length; i++) {
/* 124 */           String cName = filters[i].getClass().getName();
/* 125 */           propertyMap.put("filter.filterClasses.filter" + i, cName);
/*     */         }
/* 127 */         JiveGlobals.setJiveProperties(propertyMap);
/*     */       }
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 131 */       throw new IllegalArgumentException(e.getMessage());
/*     */     }
/*     */     catch (InstantiationException e2) {
/* 134 */       throw new IllegalArgumentException(e2.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public String applyFilters(Object source, long filterType, String string) {
/* 139 */     if (this.objectType == 17) {
/* 140 */       if (this.filters.length == 0) {
/* 141 */         return string;
/*     */       }
/* 143 */       FilterChain chain = getFilterChain(source, filterType);
/* 144 */       return chain.applyFilters(0, string);
/*     */     }
/* 146 */     if (this.objectType == 14)
/*     */       try {
/* 148 */         DbForumFactory factory = DbForumFactory.getInstance();
/* 149 */         ForumCategory category = factory.getForumCategory(this.objectID);
/* 150 */         ForumCategory parentCategory = category.getParentCategory();
/* 151 */         if (parentCategory == null) {
/* 152 */           string = factory.getFilterManager().applyFilters(source, filterType, string);
/*     */         }
/*     */         else {
/* 155 */           string = parentCategory.getFilterManager().applyFilters(source, filterType, string);
/*     */         }
/* 157 */         if (this.filters.length == 0) {
/* 158 */           return string;
/*     */         }
/* 160 */         FilterChain chain = getFilterChain(source, filterType);
/* 161 */         return chain.applyFilters(0, string);
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e) {
/*     */       }
/* 165 */     else if (this.objectType == 0)
/*     */       try {
/* 167 */         DbForumFactory factory = DbForumFactory.getInstance();
/* 168 */         Forum forum = factory.getForum(this.objectID);
/* 169 */         ForumCategory category = forum.getForumCategory();
/* 170 */         string = category.getFilterManager().applyFilters(source, filterType, string);
/* 171 */         if (this.filters.length == 0) {
/* 172 */           return string;
/*     */         }
/* 174 */         FilterChain chain = getFilterChain(source, filterType);
/* 175 */         return chain.applyFilters(0, string);
/*     */       }
/*     */       catch (ForumNotFoundException e)
/*     */       {
/*     */       }
/* 180 */     return string;
/*     */   }
/*     */ 
/*     */   public int getFilterCount() throws UnauthorizedException {
/* 184 */     return this.filters.length;
/*     */   }
/*     */ 
/*     */   public Filter getFilter(int index) {
/* 188 */     if ((index < 0) || (index > this.filters.length)) {
/* 189 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 191 */     return this.filters[index];
/*     */   }
/*     */ 
/*     */   public Filter[] getFilters() throws UnauthorizedException {
/* 195 */     return this.filters;
/*     */   }
/*     */ 
/*     */   public void addFilter(int index, Filter filter) {
/* 199 */     if ((index < 0) || (index > this.filters.length)) {
/* 200 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 202 */     if (filter == null) {
/* 203 */       throw new NullPointerException("Parameter filter was null.");
/*     */     }
/* 205 */     List newFilters = new ArrayList(Arrays.asList(this.filters));
/* 206 */     LongList newTypes = new LongList(this.filterTypes);
/* 207 */     newFilters.add(index, filter);
/*     */ 
/* 209 */     newTypes.add(index, 0L);
/* 210 */     this.filters = ((Filter[])newFilters.toArray(new Filter[newFilters.size()]));
/* 211 */     this.filterTypes = newTypes.toArray();
/* 212 */     saveFilters();
/*     */   }
/*     */ 
/*     */   public void addFilter(Filter filter) {
/* 216 */     if (this.filters != null) {
/* 217 */       addFilter(this.filters.length, filter);
/*     */     }
/*     */     else
/* 220 */       addFilter(0, filter);
/*     */   }
/*     */ 
/*     */   public synchronized void removeFilter(int index) throws UnauthorizedException
/*     */   {
/* 225 */     if ((index < 0) || (index > this.filters.length - 1)) {
/* 226 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 228 */     List newFilters = new ArrayList(Arrays.asList(this.filters));
/* 229 */     LongList newTypes = new LongList(this.filterTypes);
/* 230 */     newFilters.remove(index);
/* 231 */     newTypes.remove(index);
/* 232 */     this.filters = ((Filter[])newFilters.toArray(new Filter[newFilters.size()]));
/* 233 */     this.filterTypes = newTypes.toArray();
/* 234 */     saveFilters();
/*     */   }
/*     */ 
/*     */   public long getFilterTypes(int index) {
/* 238 */     if ((index < 0) || (index > this.filterTypes.length - 1)) {
/* 239 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 241 */     return this.filterTypes[index];
/*     */   }
/*     */ 
/*     */   public synchronized void addFilterTypes(int index, long filterTypes) {
/* 245 */     if ((index < 0) || (index > this.filterTypes.length - 1)) {
/* 246 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 248 */     this.filterTypes[index] |= filterTypes;
/* 249 */     saveFilters();
/*     */   }
/*     */ 
/*     */   public synchronized void removeFilterTypes(int index, long filterTypes) {
/* 253 */     if ((index < 0) || (index > this.filterTypes.length - 1)) {
/* 254 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 256 */     filterTypes ^= -1L;
/* 257 */     this.filterTypes[index] &= filterTypes;
/* 258 */     saveFilters();
/*     */   }
/*     */ 
/*     */   public synchronized void saveFilters() {
/* 262 */     String context = null;
/*     */ 
/* 264 */     if (this.objectType == 17) {
/* 265 */       JiveGlobals.deleteJiveProperty("filter.global");
/* 266 */       context = "filter.global.";
/*     */     }
/* 268 */     else if (this.objectType == 14) {
/*     */       try {
/* 270 */         DbForumCategory category = FACTORY.cacheManager.getForumCategory(this.objectID);
/* 271 */         List propertyNames = new ArrayList();
/* 272 */         for (Iterator i = category.getPropertyNames(); i.hasNext(); ) {
/* 273 */           propertyNames.add(i.next());
/*     */         }
/* 275 */         for (int i = 0; i < propertyNames.size(); i++) {
/* 276 */           String property = (String)propertyNames.get(i);
/* 277 */           if (property.startsWith("jive.filter"))
/* 278 */             category.deleteProperty(property);
/*     */         }
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e)
/*     */       {
/* 283 */         Log.error(e);
/*     */       }
/* 285 */       context = "jive.filter.";
/*     */     }
/* 287 */     else if (this.objectType == 0) {
/*     */       try {
/* 289 */         DbForum forum = FACTORY.cacheManager.getForum(this.objectID);
/* 290 */         List propertyNames = new ArrayList();
/* 291 */         for (Iterator i = forum.getPropertyNames(); i.hasNext(); ) {
/* 292 */           propertyNames.add(i.next());
/*     */         }
/* 294 */         for (int i = 0; i < propertyNames.size(); i++) {
/* 295 */           String property = (String)propertyNames.get(i);
/* 296 */           if (property.startsWith("jive.filter"))
/* 297 */             forum.deleteProperty(property);
/*     */         }
/*     */       }
/*     */       catch (ForumNotFoundException e)
/*     */       {
/* 302 */         Log.error(e);
/*     */       }
/* 304 */       context = "jive.filter.";
/*     */     }
/*     */ 
/* 307 */     Map propertyMap = new HashMap();
/*     */ 
/* 309 */     if (this.filters.length > 0) {
/* 310 */       propertyMap.put(context + "filterCount", String.valueOf(this.filters.length));
/*     */     }
/*     */ 
/* 314 */     for (int i = 0; i < this.filters.length; i++) {
/* 315 */       Filter filter = this.filters[i];
/* 316 */       String filterContext = context + "filter" + i + ".";
/*     */ 
/* 319 */       propertyMap.put(filterContext + "className", filter.getClass().getName());
/*     */ 
/* 322 */       Map filterProps = BeanUtils.getProperties(filter);
/* 323 */       for (Iterator iter = filterProps.keySet().iterator(); iter.hasNext(); ) {
/* 324 */         String name = (String)iter.next();
/* 325 */         String value = (String)filterProps.get(name);
/* 326 */         if (value != null) {
/* 327 */           propertyMap.put(filterContext + "properties." + name, value);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 332 */       propertyMap.put(filterContext + "filterTypes", Long.toString(this.filterTypes[i]));
/*     */     }
/*     */ 
/* 335 */     if (this.objectType == 17) {
/* 336 */       JiveGlobals.setJiveProperties(propertyMap);
/*     */     }
/* 338 */     else if (this.objectType == 14) {
/*     */       try {
/* 340 */         category = FACTORY.cacheManager.getForumCategory(this.objectID);
/* 341 */         for (i = propertyMap.keySet().iterator(); i.hasNext(); ) {
/* 342 */           String name = (String)i.next();
/* 343 */           String value = (String)propertyMap.get(name);
/* 344 */           category.setProperty(name, value);
/*     */         }
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e)
/*     */       {
/*     */         DbForumCategory category;
/*     */         Iterator i;
/* 348 */         Log.error(e);
/*     */       }
/*     */     }
/* 351 */     else if (this.objectType == 0) {
/*     */       try {
/* 353 */         forum = FACTORY.cacheManager.getForum(this.objectID);
/* 354 */         for (i = propertyMap.keySet().iterator(); i.hasNext(); ) {
/* 355 */           String name = (String)i.next();
/* 356 */           String value = (String)propertyMap.get(name);
/* 357 */           forum.setProperty(name, value);
/*     */         }
/*     */       }
/*     */       catch (ForumNotFoundException e)
/*     */       {
/*     */         DbForum forum;
/*     */         Iterator i;
/* 361 */         Log.error(e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 366 */     DbForumFactory.getInstance().cacheManager.messageCache.clear();
/*     */ 
/* 369 */     if (this.objectType == 17) {
/* 370 */       DbForumFactory.getInstance().cacheManager.announcementCache.clear();
/* 371 */       DbForumFactory.getInstance().cacheManager.privateMessageCache.clear();
/*     */     }
/*     */ 
/* 375 */     CacheFactory.doClusterTask(new UpdateClusterTask(this.objectType, this.objectID));
/*     */   }
/*     */ 
/*     */   private static synchronized void initialSetup()
/*     */   {
/* 382 */     if (JiveGlobals.getJiveBooleanProperty("filter.initialSetup")) {
/* 383 */       return;
/*     */     }
/*     */ 
/* 386 */     JiveGlobals.deleteJiveProperty("filter.global");
/* 387 */     Map propertyMap = new HashMap();
/* 388 */     propertyMap.put("filter.global.filterCount", "5");
/* 389 */     propertyMap.put("filter.global.filter0.className", "com.jivesoftware.base.filter.HTMLFilter");
/* 390 */     propertyMap.put("filter.global.filter0.filterTypes", "24");
/* 391 */     propertyMap.put("filter.global.filter1.className", "com.jivesoftware.base.filter.TextStyle");
/* 392 */     propertyMap.put("filter.global.filter1.filterTypes", "24");
/* 393 */     propertyMap.put("filter.global.filter2.className", "com.jivesoftware.base.filter.Emoticon");
/* 394 */     propertyMap.put("filter.global.filter2.filterTypes", "24");
/* 395 */     propertyMap.put("filter.global.filter3.className", "com.jivesoftware.base.filter.URLConverter");
/* 396 */     propertyMap.put("filter.global.filter3.filterTypes", "16");
/* 397 */     propertyMap.put("filter.global.filter4.className", "com.jivesoftware.base.filter.Newline");
/* 398 */     propertyMap.put("filter.global.filter4.filterTypes", "24");
/* 399 */     JiveGlobals.setJiveProperties(propertyMap);
/*     */ 
/* 401 */     JiveGlobals.setJiveProperty("filter.initialSetup", "true");
/*     */   }
/*     */ 
/*     */   private void loadGlobalFilters()
/*     */   {
/* 406 */     int filterCount = JiveGlobals.getJiveIntProperty("filter.global.filterCount", 0);
/*     */ 
/* 409 */     List filterList = new ArrayList(filterCount);
/* 410 */     LongList filterTypesList = new LongList(filterCount);
/* 411 */     for (int i = 0; i < filterCount; i++) {
/*     */       try {
/* 413 */         String filterContext = "filter.global.filter" + i + ".";
/* 414 */         String className = JiveGlobals.getJiveProperty(filterContext + "className");
/* 415 */         Log.debug("Loading global filter " + i + ": " + className);
/* 416 */         Filter filter = (Filter)ClassUtils.forName(className).newInstance();
/*     */ 
/* 419 */         List props = JiveGlobals.getJivePropertyNames(filterContext + "properties");
/* 420 */         Map filterProps = new HashMap();
/*     */ 
/* 422 */         for (int k = 0; k < props.size(); k++) {
/* 423 */           String key = (String)props.get(k);
/* 424 */           String value = JiveGlobals.getJiveProperty((String)props.get(k));
/*     */ 
/* 427 */           filterProps.put(key.substring(key.lastIndexOf(".") + 1), value);
/*     */         }
/*     */ 
/* 431 */         BeanUtils.setProperties(filter, filterProps);
/*     */ 
/* 434 */         long types = 0L;
/* 435 */         String fTypes = JiveGlobals.getJiveProperty(filterContext + "filterTypes");
/* 436 */         if (fTypes == null) {
/* 437 */           fTypes = "0";
/*     */         }
/* 439 */         types = Long.parseLong(fTypes);
/*     */ 
/* 442 */         filterList.add(filter);
/* 443 */         filterTypesList.add(types);
/*     */       }
/*     */       catch (Exception e) {
/* 446 */         Log.error("Error loading global filter " + i, e);
/*     */       }
/*     */     }
/* 449 */     this.filters = ((Filter[])filterList.toArray(new Filter[filterList.size()]));
/* 450 */     this.filterTypes = filterTypesList.toArray();
/*     */   }
/*     */ 
/*     */   private void loadCategoryFilters() throws ForumCategoryNotFoundException {
/* 454 */     DbForumCategory category = FACTORY.cacheManager.getForumCategory(this.objectID);
/* 455 */     int filterCount = 0;
/* 456 */     String fCount = category.getProperty("jive.filter.filterCount");
/* 457 */     if (fCount != null) {
/*     */       try {
/* 459 */         filterCount = Integer.parseInt(fCount);
/*     */       }
/*     */       catch (NumberFormatException nfe)
/*     */       {
/*     */       }
/*     */     }
/* 465 */     List filterList = new ArrayList(filterCount);
/* 466 */     LongList filterTypesList = new LongList(filterCount);
/* 467 */     for (int i = 0; i < filterCount; i++) {
/*     */       try {
/* 469 */         String filterContext = "jive.filter.filter" + i + ".";
/* 470 */         String className = category.getProperty(filterContext + "className");
/* 471 */         Log.debug("Loading category filter " + i + " in " + category + " : " + className);
/* 472 */         Filter filter = (Filter)ClassUtils.forName(className).newInstance();
/*     */ 
/* 475 */         Iterator props = getChildrenPropertyNames(filterContext + "properties", category.getPropertyNames());
/*     */ 
/* 477 */         Map filterProps = new HashMap();
/*     */ 
/* 479 */         for (Iterator k = props; k.hasNext(); ) {
/* 480 */           String key = (String)k.next();
/* 481 */           String value = category.getProperty(key);
/*     */ 
/* 484 */           filterProps.put(key.substring(key.lastIndexOf(".") + 1), value);
/*     */         }
/*     */ 
/* 488 */         BeanUtils.setProperties(filter, filterProps);
/*     */ 
/* 491 */         long types = 0L;
/* 492 */         String fTypes = category.getProperty(filterContext + "filterTypes");
/* 493 */         if (fTypes == null) {
/* 494 */           fTypes = "0";
/*     */         }
/* 496 */         types = Long.parseLong(fTypes);
/*     */ 
/* 499 */         filterList.add(filter);
/* 500 */         filterTypesList.add(types);
/*     */       }
/*     */       catch (Exception e) {
/* 503 */         Log.error("Error loading category filter " + i, e);
/*     */       }
/*     */     }
/* 506 */     this.filters = ((Filter[])filterList.toArray(new Filter[filterList.size()]));
/* 507 */     this.filterTypes = filterTypesList.toArray();
/*     */   }
/*     */ 
/*     */   private void loadForumFilters() throws ForumNotFoundException {
/* 511 */     DbForum forum = FACTORY.cacheManager.getForum(this.objectID);
/* 512 */     int filterCount = 0;
/* 513 */     String fCount = forum.getProperty("jive.filter.filterCount");
/* 514 */     if (fCount != null) {
/*     */       try {
/* 516 */         filterCount = Integer.parseInt(fCount);
/*     */       }
/*     */       catch (NumberFormatException nfe)
/*     */       {
/*     */       }
/*     */     }
/* 522 */     List filterList = new ArrayList(filterCount);
/* 523 */     LongList filterTypesList = new LongList(filterCount);
/* 524 */     for (int i = 0; i < filterCount; i++) {
/*     */       try {
/* 526 */         String filterContext = "jive.filter.filter" + i + ".";
/* 527 */         String className = forum.getProperty(filterContext + "className");
/* 528 */         Log.debug("Loading forum filter " + i + " in " + forum + " : " + className);
/* 529 */         Filter filter = (Filter)ClassUtils.forName(className).newInstance();
/*     */ 
/* 532 */         Iterator props = getChildrenPropertyNames(filterContext + "properties", forum.getPropertyNames());
/*     */ 
/* 534 */         Map filterProps = new HashMap();
/*     */ 
/* 536 */         for (Iterator k = props; k.hasNext(); ) {
/* 537 */           String key = (String)k.next();
/* 538 */           String value = forum.getProperty(key);
/*     */ 
/* 541 */           filterProps.put(key.substring(key.lastIndexOf(".") + 1), value);
/*     */         }
/*     */ 
/* 545 */         BeanUtils.setProperties(filter, filterProps);
/*     */ 
/* 548 */         long types = 0L;
/* 549 */         String fTypes = forum.getProperty(filterContext + "filterTypes");
/* 550 */         if (fTypes == null) {
/* 551 */           fTypes = "0";
/*     */         }
/* 553 */         types = Long.parseLong(fTypes);
/*     */ 
/* 556 */         filterList.add(filter);
/* 557 */         filterTypesList.add(types);
/*     */       }
/*     */       catch (Exception e) {
/* 560 */         Log.error("Error loading forum filter " + i, e);
/*     */       }
/*     */     }
/* 563 */     this.filters = ((Filter[])filterList.toArray(new Filter[filterList.size()]));
/* 564 */     this.filterTypes = filterTypesList.toArray();
/*     */   }
/*     */ 
/*     */   private static synchronized void loadAvailableFilters() {
/* 568 */     availableFilters = new ArrayList();
/*     */ 
/* 570 */     for (int i = 0; i < DEFAULT_FILTER_CLASSES.length; i++) {
/*     */       try {
/* 572 */         String className = DEFAULT_FILTER_CLASSES[i];
/* 573 */         Class filterClass = ClassUtils.forName(className);
/*     */ 
/* 575 */         Filter filter = (Filter)filterClass.newInstance();
/* 576 */         availableFilters.add(filter);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*     */     }
/* 582 */     List classNames = JiveGlobals.getJiveProperties("filter.filterClasses");
/* 583 */     label189: for (int i = 0; i < classNames.size(); i++)
/*     */       try {
/* 585 */         String className = JiveGlobals.getJiveProperty("filter.filterClasses.filter" + i);
/* 586 */         Class filterClass = ClassUtils.forName(className);
/*     */ 
/* 588 */         Filter filter = (Filter)filterClass.newInstance();
/*     */ 
/* 590 */         for (int j = 0; j < availableFilters.size(); j++) {
/* 591 */           if (filterClass.equals(availableFilters.get(j).getClass())) {
/*     */             break label189;
/*     */           }
/*     */         }
/* 595 */         availableFilters.add(filter);
/*     */       } catch (Exception e) {
/* 597 */         Log.error("Error loading filter " + i, e);
/*     */       }
/*     */   }
/*     */ 
/*     */   protected FilterChain getFilterChain(Object source, long filterType) {
/* 602 */     return new FilterChain(source, filterType, this.filters, this.filterTypes);
/*     */   }
/*     */ 
/*     */   private static Iterator getChildrenPropertyNames(String parent, Iterator properties)
/*     */   {
/* 613 */     List results = new ArrayList();
/* 614 */     for (Iterator i = properties; i.hasNext(); ) {
/* 615 */       String name = (String)i.next();
/* 616 */       if ((name.startsWith(parent)) && (!name.equals(parent))) {
/* 617 */         results.add(name);
/*     */       }
/*     */     }
/* 620 */     return results.iterator();
/*     */   }
/*     */ 
/*     */   private static class UpdateClusterTask
/*     */     implements Runnable, Serializable
/*     */   {
/*     */     private int objectType;
/*     */     private long objectID;
/*     */ 
/*     */     public UpdateClusterTask(int objectType, long objectID)
/*     */     {
/* 632 */       this.objectType = objectType;
/* 633 */       this.objectID = objectID;
/*     */     }
/*     */ 
/*     */     public void run() {
/* 637 */       DbForumFactory factory = DbForumFactory.getInstance();
/* 638 */       if (this.objectType == 17) {
/* 639 */         DbFilterManager manager = (DbFilterManager)factory.getFilterManager();
/* 640 */         manager.loadGlobalFilters();
/*     */       }
/* 642 */       else if (this.objectType == 14) {
/*     */         try {
/* 644 */           DbForumCategory category = (DbForumCategory)factory.getForumCategory(this.objectID);
/* 645 */           DbFilterManager manager = (DbFilterManager)category.getFilterManager();
/* 646 */           manager.loadCategoryFilters();
/*     */         }
/*     */         catch (ForumCategoryNotFoundException fcnfe) {
/* 649 */           Log.error(fcnfe);
/*     */         }
/*     */       }
/* 652 */       else if (this.objectType == 0) {
/*     */         try {
/* 654 */           DbForum forum = (DbForum)factory.getForum(this.objectID);
/* 655 */           DbFilterManager manager = (DbFilterManager)forum.getFilterManager();
/* 656 */           manager.loadForumFilters();
/*     */         }
/*     */         catch (ForumNotFoundException fnfe) {
/* 659 */           Log.error(fnfe);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbFilterManager
 * JD-Core Version:    0.6.2
 */
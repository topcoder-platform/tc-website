/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.database.CachedPreparedStatement;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class QueryBlockIterator
/*     */   implements Iterator
/*     */ {
/*     */   private long[] queryBlock;
/*     */   private int blockID;
/*     */   private int blockStart;
/*     */   private CachedPreparedStatement sql;
/*     */   private int startIndex;
/*     */   private int currentIndex;
/*     */   private int endIndex;
/*     */   private long userID;
/*  41 */   private Object previousElement = null;
/*  42 */   private Object nextElement = null;
/*     */ 
/*     */   protected QueryBlockIterator(long[] queryBlock, CachedPreparedStatement query, int startIndex, int endIndex, long userID)
/*     */   {
/*  55 */     this.queryBlock = queryBlock;
/*  56 */     this.blockID = (startIndex / 400);
/*  57 */     this.blockStart = (this.blockID * 400);
/*  58 */     this.sql = query;
/*  59 */     this.currentIndex = (startIndex - 1);
/*  60 */     this.startIndex = startIndex;
/*  61 */     this.endIndex = endIndex;
/*  62 */     this.userID = userID;
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/*  67 */     if (this.currentIndex == this.endIndex) {
/*  68 */       return false;
/*     */     }
/*     */ 
/*  74 */     if (this.nextElement == null) {
/*  75 */       this.nextElement = getNextElement();
/*     */ 
/*  77 */       if (this.nextElement == null) {
/*  78 */         return false;
/*     */       }
/*     */     }
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean hasPrevious()
/*     */   {
/*  86 */     if (this.currentIndex == this.startIndex) {
/*  87 */       return false;
/*     */     }
/*     */ 
/*  91 */     if (this.previousElement == null) {
/*  92 */       this.previousElement = getPreviousElement();
/*     */ 
/*  94 */       if (this.previousElement == null) {
/*  95 */         return false;
/*     */       }
/*     */     }
/*  98 */     return true;
/*     */   }
/*     */ 
/*     */   public Object next() throws NoSuchElementException {
/* 102 */     Object element = null;
/* 103 */     if (this.nextElement != null) {
/* 104 */       element = this.nextElement;
/* 105 */       this.nextElement = null;
/*     */     }
/*     */     else {
/* 108 */       element = getNextElement();
/* 109 */       if (element == null) {
/* 110 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/* 113 */     return element;
/*     */   }
/*     */ 
/*     */   public Object previous() {
/* 117 */     Object element = null;
/* 118 */     if (this.previousElement != null) {
/* 119 */       element = this.previousElement;
/* 120 */       this.previousElement = null;
/*     */     }
/*     */     else {
/* 123 */       element = getPreviousElement();
/* 124 */       if (element == null) {
/* 125 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/* 128 */     return element;
/*     */   }
/*     */ 
/*     */   public void remove() {
/* 132 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void setIndex(DbQuery query)
/*     */   {
/* 138 */     this.nextElement = null;
/* 139 */     this.previousElement = null;
/*     */ 
/* 142 */     long searchID = query.getID();
/*     */ 
/* 145 */     for (int i = this.startIndex; i < this.endIndex; i++) {
/* 146 */       long[] currentBlock = QueryCache.getBlock(this.sql, 19, this.userID, i, true);
/*     */ 
/* 148 */       if (currentBlock.length == 0) {
/* 149 */         throw new NoSuchElementException("Query with id " + searchID + " is not a valid index in the iteration.");
/*     */       }
/*     */ 
/* 152 */       int blockID = i / 400;
/* 153 */       int blockEnd = blockID * 400 + 400;
/*     */ 
/* 156 */       if (this.startIndex < blockEnd)
/*     */       {
/* 159 */         int j = this.startIndex % 400;
/* 160 */         for (; j < currentBlock.length; i++)
/*     */         {
/* 162 */           if (currentBlock[j] == searchID) {
/* 163 */             this.currentIndex = i;
/*     */             return;
/*     */           }
/* 160 */           j++;
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 170 */         for (int j = 0; j < currentBlock.length; i++) {
/* 171 */           if (currentBlock[j] == searchID) {
/* 172 */             this.currentIndex = i;
/*     */             return;
/*     */           }
/* 170 */           j++;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 179 */     throw new NoSuchElementException("Query with id " + query.getID() + " is not a valid index in the iteration.");
/*     */   }
/*     */ 
/*     */   private Object getNextElement()
/*     */   {
/* 189 */     this.previousElement = null;
/* 190 */     Object element = null;
/* 191 */     while ((this.currentIndex + 1 < this.endIndex) && (element == null)) {
/* 192 */       this.currentIndex += 1;
/* 193 */       element = getElement(this.currentIndex);
/*     */     }
/* 195 */     return element;
/*     */   }
/*     */ 
/*     */   private Object getPreviousElement()
/*     */   {
/* 204 */     this.nextElement = null;
/*     */ 
/* 206 */     Object element = null;
/* 207 */     while ((this.currentIndex >= this.startIndex) && (element == null)) {
/* 208 */       this.currentIndex -= 1;
/* 209 */       element = getElement(this.currentIndex);
/*     */     }
/* 211 */     return element;
/*     */   }
/*     */ 
/*     */   private Object getElement(int index) {
/* 215 */     if (index < 0) {
/* 216 */       return null;
/*     */     }
/*     */ 
/* 219 */     if ((index < this.blockStart) || (index >= this.blockStart + 400))
/*     */     {
/* 221 */       this.queryBlock = QueryCache.getBlock(this.sql, 19, this.userID, index, true);
/*     */ 
/* 223 */       this.blockID = (index / 400);
/* 224 */       this.blockStart = (this.blockID * 400);
/*     */     }
/*     */ 
/* 227 */     Object element = null;
/*     */ 
/* 230 */     int relativeIndex = index % 400;
/*     */ 
/* 232 */     if (relativeIndex < this.queryBlock.length)
/*     */       try
/*     */       {
/* 235 */         element = DbQueryLogger.getInstance().getQuery(this.queryBlock[relativeIndex]);
/*     */       } catch (NotFoundException qnfe) {
/* 237 */         Log.error(qnfe);
/*     */       }
/* 239 */     return element;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.QueryBlockIterator
 * JD-Core Version:    0.6.2
 */
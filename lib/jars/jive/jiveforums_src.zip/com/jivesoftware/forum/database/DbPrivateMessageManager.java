/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.FilterManager;
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.JiveManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.PermissionType;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.database.DbPermissionsManager;
/*     */ import com.jivesoftware.forum.PrivateMessage;
/*     */ import com.jivesoftware.forum.PrivateMessageFolder;
/*     */ import com.jivesoftware.forum.PrivateMessageFolderNotFoundException;
/*     */ import com.jivesoftware.forum.PrivateMessageManager;
/*     */ import com.jivesoftware.forum.PrivateMessageNotFoundException;
/*     */ import com.jivesoftware.forum.PrivateMessageRejectedException;
/*     */ import com.jivesoftware.forum.event.PrivateMessageEvent;
/*     */ import com.jivesoftware.forum.event.PrivateMessageEventDispatcher;
/*     */ import com.jivesoftware.forum.proxy.PrivateMessageProxy;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class DbPrivateMessageManager
/*     */   implements PrivateMessageManager, JiveManager
/*     */ {
/*     */   private static final String USER_MESSAGE_COUNT = "SELECT count(*) FROM jivePMessage WHERE ownerID=? AND folderID<>4";
/*     */   private static final String USER_UNREAD_MESSAGE_COUNT = "SELECT count(*) FROM jivePMessage WHERE ownerID=? AND folderID<>4 AND readStatus=0";
/*     */   private static final String GET_FOLDERS = "SELECT folderID FROM jivePMessageFldr WHERE userID=?";
/*     */   private static final String GET_FOLDER_COUNT = "SELECT count(folderID) FROM jivePMessageFldr WHERE userID=?";
/*     */   private static final String DELETE_FOLDER = "DELETE FROM jivePMessageFldr WHERE folderID=? AND userID=?";
/*     */   private static final String PURGE_TRASH = "DELETE FROM jivePMessage WHERE folderID=4";
/*     */   private static final String PURGE_TRASH_FOR_USER = "DELETE FROM jivePMessage WHERE ownerID=? AND folderID=4";
/*  51 */   private static DbPrivateMessageManager instance = new DbPrivateMessageManager();
/*     */   private static DbForumFactory FACTORY;
/*  54 */   private static boolean initialized = false;
/*     */ 
/*  56 */   private int maxMessagesPerUser = JiveGlobals.getJiveIntProperty("privateMessages.maxMessages", 100);
/*     */ 
/*  58 */   private boolean pmEnabled = JiveGlobals.getJiveBooleanProperty("privateMessages.enabled", true);
/*     */ 
/*     */   public static DbPrivateMessageManager getInstance()
/*     */   {
/*  67 */     return instance;
/*     */   }
/*     */ 
/*     */   public synchronized void initialize()
/*     */   {
/*  76 */     if (!initialized) {
/*  77 */       FACTORY = DbForumFactory.getInstance();
/*     */ 
/*  79 */       TaskEngine.scheduleTask(new PurgeTrashTask(null), 3600000L, 86400000L);
/*     */ 
/*  81 */       initialized = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isPrivateMessagesEnabled() {
/*  86 */     return this.pmEnabled;
/*     */   }
/*     */ 
/*     */   public void setPrivateMessagesEnabled(boolean enabled) throws UnauthorizedException {
/*  90 */     this.pmEnabled = enabled;
/*  91 */     JiveGlobals.setJiveProperty("privateMessages.enabled", "" + enabled);
/*     */   }
/*     */ 
/*     */   public FilterManager getFilterManager()
/*     */   {
/*  96 */     return FACTORY.getFilterManager();
/*     */   }
/*     */ 
/*     */   public int getMaxMessagesPerUser() {
/* 100 */     return this.maxMessagesPerUser;
/*     */   }
/*     */ 
/*     */   public void setMaxMessagesPerUser(int maxMessagesPerUser) {
/* 104 */     this.maxMessagesPerUser = maxMessagesPerUser;
/* 105 */     JiveGlobals.setJiveProperty("privateMessages.maxMessages", Integer.toString(maxMessagesPerUser));
/*     */   }
/*     */ 
/*     */   public int getMessageCount(User user)
/*     */   {
/* 110 */     String key = "total_pmcount-" + user.getID();
/* 111 */     Integer count = (Integer)FACTORY.cacheManager.privateMessageCache.get(key);
/* 112 */     if (count != null) {
/* 113 */       return count.intValue();
/*     */     }
/*     */ 
/* 116 */     Connection con = null;
/* 117 */     PreparedStatement pstmt = null;
/*     */     try {
/* 119 */       con = ConnectionManager.getConnection();
/* 120 */       pstmt = con.prepareStatement("SELECT count(*) FROM jivePMessage WHERE ownerID=? AND folderID<>4");
/* 121 */       pstmt.setLong(1, user.getID());
/* 122 */       ResultSet rs = pstmt.executeQuery();
/* 123 */       rs.next();
/* 124 */       count = new Integer(rs.getInt(1));
/* 125 */       rs.close();
/*     */ 
/* 127 */       FACTORY.cacheManager.privateMessageCache.put(key, count);
/*     */     }
/*     */     catch (Exception e) {
/* 130 */       Log.error(e);
/*     */     }
/*     */     finally {
/* 133 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 135 */     return count.intValue();
/*     */   }
/*     */ 
/*     */   public int getUnreadMessageCount(User user) {
/* 139 */     String key = "unread_pmcount-" + user.getID();
/* 140 */     Integer count = (Integer)FACTORY.cacheManager.privateMessageCache.get(key);
/* 141 */     if (count != null) {
/* 142 */       return count.intValue();
/*     */     }
/* 144 */     Connection con = null;
/* 145 */     PreparedStatement pstmt = null;
/*     */     try {
/* 147 */       con = ConnectionManager.getConnection();
/* 148 */       pstmt = con.prepareStatement("SELECT count(*) FROM jivePMessage WHERE ownerID=? AND folderID<>4 AND readStatus=0");
/* 149 */       pstmt.setLong(1, user.getID());
/* 150 */       ResultSet rs = pstmt.executeQuery();
/* 151 */       rs.next();
/* 152 */       count = new Integer(rs.getInt(1));
/* 153 */       rs.close();
/*     */ 
/* 155 */       FACTORY.cacheManager.privateMessageCache.put(key, count);
/*     */     }
/*     */     catch (Exception e) {
/* 158 */       Log.error(e);
/*     */     }
/*     */     finally {
/* 161 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 163 */     return count.intValue();
/*     */   }
/*     */ 
/*     */   public int getFolderCount(User user)
/*     */   {
/* 169 */     int count = 4;
/* 170 */     Connection con = null;
/* 171 */     PreparedStatement pstmt = null;
/*     */     try {
/* 173 */       con = ConnectionManager.getConnection();
/* 174 */       pstmt = con.prepareStatement("SELECT count(folderID) FROM jivePMessageFldr WHERE userID=?");
/* 175 */       pstmt.setLong(1, user.getID());
/* 176 */       ResultSet rs = pstmt.executeQuery();
/* 177 */       rs.next();
/* 178 */       count += rs.getInt(1);
/* 179 */       rs.close();
/*     */     }
/*     */     catch (Exception e) {
/* 182 */       Log.error(e);
/*     */     }
/*     */     finally {
/* 185 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 187 */     return count;
/*     */   }
/*     */ 
/*     */   public Iterator getFolders(User user)
/*     */   {
/* 192 */     Cache cache = FACTORY.cacheManager.privateMessageFolderCache;
/* 193 */     String key = "folders_" + user.getID();
/* 194 */     int[] folderIDs = (int[])cache.get(key);
/* 195 */     if (folderIDs == null) {
/* 196 */       List folderList = new ArrayList();
/* 197 */       Connection con = null;
/* 198 */       PreparedStatement pstmt = null;
/*     */       try {
/* 200 */         con = ConnectionManager.getConnection();
/* 201 */         pstmt = con.prepareStatement("SELECT folderID FROM jivePMessageFldr WHERE userID=?");
/* 202 */         pstmt.setLong(1, user.getID());
/* 203 */         ResultSet rs = pstmt.executeQuery();
/* 204 */         while (rs.next()) {
/* 205 */           folderList.add(new Integer(rs.getInt(1)));
/*     */         }
/* 207 */         rs.close();
/*     */       }
/*     */       catch (Exception e) {
/* 210 */         Log.error(e);
/*     */       }
/*     */       finally {
/* 213 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/* 215 */       folderIDs = new int[folderList.size()];
/* 216 */       for (int i = 0; i < folderIDs.length; i++) {
/* 217 */         folderIDs[i] = ((Integer)folderList.get(i)).intValue();
/*     */       }
/* 219 */       cache.put(key, folderIDs);
/*     */     }
/* 221 */     List folders = new ArrayList();
/*     */     try {
/* 223 */       folders.add(getPrivateMessageFolder(1, user.getID()));
/* 224 */       folders.add(getPrivateMessageFolder(2, user.getID()));
/* 225 */       folders.add(getPrivateMessageFolder(3, user.getID()));
/* 226 */       folders.add(getPrivateMessageFolder(4, user.getID()));
/*     */     }
/*     */     catch (PrivateMessageFolderNotFoundException e)
/*     */     {
/*     */     }
/* 231 */     List userFolders = new ArrayList();
/* 232 */     for (int i = 0; i < folderIDs.length; i++) {
/*     */       try {
/* 234 */         userFolders.add(getPrivateMessageFolder(folderIDs[i], user.getID()));
/*     */       }
/*     */       catch (PrivateMessageFolderNotFoundException e) {
/* 237 */         Log.error(e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 242 */     if (userFolders.size() > 0) {
/* 243 */       Collections.sort(userFolders, new Comparator() {
/*     */         public int compare(Object o1, Object o2) {
/* 245 */           return ((PrivateMessageFolder)o1).getName().toLowerCase().compareTo(((PrivateMessageFolder)o2).getName().toLowerCase());
/*     */         }
/*     */       });
/* 249 */       folders.addAll(userFolders);
/*     */     }
/* 251 */     return Collections.unmodifiableList(folders).iterator();
/*     */   }
/*     */ 
/*     */   public PrivateMessageFolder getFolder(User user, int folderID)
/*     */     throws PrivateMessageFolderNotFoundException
/*     */   {
/* 257 */     return getPrivateMessageFolder(folderID, user.getID());
/*     */   }
/*     */ 
/*     */   public PrivateMessageFolder createFolder(User user, String name) throws UnauthorizedException {
/* 261 */     PrivateMessageFolder folder = new DbPrivateMessageFolder(user.getID(), name);
/*     */ 
/* 263 */     String key = "folders_" + user.getID();
/* 264 */     FACTORY.cacheManager.privateMessageFolderCache.remove(key);
/* 265 */     return folder;
/*     */   }
/*     */ 
/*     */   public void deleteFolder(PrivateMessageFolder folder) throws UnauthorizedException {
/* 269 */     int folderID = folder.getID();
/*     */ 
/* 272 */     if (folderID == 4) {
/* 273 */       Connection con = null;
/* 274 */       PreparedStatement pstmt = null;
/* 275 */       boolean abortTransaction = false;
/*     */       try {
/* 277 */         con = ConnectionManager.getTransactionConnection();
/* 278 */         pstmt = con.prepareStatement("DELETE FROM jivePMessage WHERE ownerID=? AND folderID=4");
/* 279 */         pstmt.setLong(1, folder.getOwner().getID());
/* 280 */         pstmt.execute();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 283 */         abortTransaction = true;
/* 284 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 287 */         ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 292 */       PrivateMessageFolder trash = null;
/*     */       try {
/* 294 */         trash = getPrivateMessageFolder(4, folder.getOwner().getID());
/*     */       }
/*     */       catch (PrivateMessageFolderNotFoundException fnfe)
/*     */       {
/* 298 */         Log.error(fnfe);
/*     */       }
/* 300 */       for (Iterator i = folder.getMessages(); i.hasNext(); ) {
/* 301 */         PrivateMessage message = (PrivateMessage)i.next();
/* 302 */         folder.moveMessage(message, trash);
/*     */       }
/*     */ 
/* 305 */       FACTORY.cacheManager.privateMessageCache.remove("total_pmcount-" + folder.getOwner().getID());
/* 306 */       FACTORY.cacheManager.privateMessageCache.remove("unread_pmcount-" + folder.getOwner().getID());
/*     */     }
/*     */ 
/* 310 */     if ((folderID == 1) || (folderID == 3) || (folderID == 2) || (folderID == 4))
/*     */     {
/* 315 */       return;
/*     */     }
/*     */ 
/* 319 */     Connection con = null;
/* 320 */     PreparedStatement pstmt = null;
/* 321 */     boolean abortTransaction = false;
/*     */     try {
/* 323 */       con = ConnectionManager.getTransactionConnection();
/* 324 */       pstmt = con.prepareStatement("DELETE FROM jivePMessageFldr WHERE folderID=? AND userID=?");
/* 325 */       pstmt.setInt(1, folder.getID());
/* 326 */       pstmt.setLong(2, folder.getOwner().getID());
/* 327 */       pstmt.execute();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 330 */       Log.error(sqle);
/* 331 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 334 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */ 
/* 338 */     String key = "folders_" + folder.getOwner().getID();
/* 339 */     Cache cache = FACTORY.cacheManager.privateMessageFolderCache;
/* 340 */     int[] folderIDs = (int[])cache.get(key);
/* 341 */     if (folderIDs != null) {
/* 342 */       for (int i = 0; i < folderIDs.length; i++) {
/* 343 */         cache.remove(DbPrivateMessageFolder.getCacheKey(folderIDs[i], folder.getOwner().getID()));
/*     */       }
/*     */     }
/* 346 */     cache.remove(key);
/*     */   }
/*     */ 
/*     */   public PrivateMessage getMessage(long pMessageID) throws PrivateMessageNotFoundException {
/* 350 */     return getPrivateMessage(pMessageID);
/*     */   }
/*     */ 
/*     */   public PrivateMessage createMessage(User sender) throws UnauthorizedException {
/* 354 */     return new DbPrivateMessage(sender);
/*     */   }
/*     */ 
/*     */   public void saveMessageAsDraft(PrivateMessage privateMessage)
/*     */     throws PrivateMessageRejectedException
/*     */   {
/* 360 */     if (privateMessage.getRecipient() != null) {
/* 361 */       throw new IllegalArgumentException("Private message has already been sent");
/*     */     }
/*     */ 
/* 364 */     if ((this.maxMessagesPerUser != -1) && (getMessageCount(privateMessage.getSender()) >= this.maxMessagesPerUser))
/*     */     {
/* 367 */       throw new PrivateMessageRejectedException(PrivateMessageRejectedException.SENDER_MAILBOX_FULL);
/*     */     }
/*     */ 
/* 370 */     DbPrivateMessage dbPrivateMessage = null;
/* 371 */     if ((privateMessage instanceof PrivateMessageProxy)) {
/* 372 */       PrivateMessageProxy proxy = (PrivateMessageProxy)privateMessage;
/* 373 */       dbPrivateMessage = (DbPrivateMessage)proxy.getProxiedPrivateMessage();
/*     */     }
/*     */     else {
/* 376 */       dbPrivateMessage = (DbPrivateMessage)privateMessage;
/*     */     }
/*     */     try {
/* 379 */       PrivateMessageFolder drafts = getFolder(privateMessage.getSender(), 3);
/*     */ 
/* 381 */       dbPrivateMessage.setFolder(drafts);
/*     */     }
/*     */     catch (PrivateMessageFolderNotFoundException e) {
/*     */     }
/* 385 */     dbPrivateMessage.setRead(true);
/* 386 */     if (dbPrivateMessage.getID() == -1L) {
/*     */       try {
/* 388 */         dbPrivateMessage.insertIntoDb();
/*     */       }
/*     */       catch (Exception e) {
/* 391 */         Log.error(e);
/*     */       }
/*     */     }
/*     */     else {
/* 395 */       dbPrivateMessage.saveToDb();
/*     */     }
/*     */ 
/* 398 */     FACTORY.cacheManager.privateMessageFolderCache.remove(DbPrivateMessageFolder.getCacheKey(3, dbPrivateMessage.getSender().getID()));
/*     */ 
/* 401 */     long userID = privateMessage.getSender().getID();
/* 402 */     FACTORY.cacheManager.privateMessageCache.remove("total_pmcount-" + userID);
/* 403 */     FACTORY.cacheManager.privateMessageCache.remove("unread_pmcount-" + userID);
/*     */   }
/*     */ 
/*     */   public void sendMessage(PrivateMessage privateMessage, User recipient, boolean copyToSentFolder)
/*     */     throws PrivateMessageRejectedException
/*     */   {
/* 409 */     if (recipient == null) {
/* 410 */       throw new IllegalArgumentException("Recipient is null");
/*     */     }
/* 412 */     if (privateMessage.getRecipient() != null) {
/* 413 */       throw new IllegalArgumentException("Private message has already been sent");
/*     */     }
/*     */ 
/* 417 */     Permissions recipientPermAdd = FACTORY.permissionsManager.getFinalUserPerms(17, -1L, recipient.getID(), PermissionType.ADDITIVE);
/*     */ 
/* 419 */     Permissions recipientPermNeg = FACTORY.permissionsManager.getFinalUserPerms(17, -1L, recipient.getID(), PermissionType.NEGATIVE);
/*     */ 
/* 421 */     if ((!recipientPermAdd.hasPermission(32L)) || (recipientPermNeg.hasPermission(32L)))
/*     */     {
/* 423 */       throw new PrivateMessageRejectedException(PrivateMessageRejectedException.NOT_ALLOWED);
/*     */     }
/*     */ 
/* 427 */     Permissions senderPermAdd = FACTORY.permissionsManager.getFinalUserPerms(17, -1L, privateMessage.getSender().getID(), PermissionType.ADDITIVE);
/*     */ 
/* 429 */     Permissions senderPermNeg = FACTORY.permissionsManager.getFinalUserPerms(17, -1L, privateMessage.getSender().getID(), PermissionType.NEGATIVE);
/*     */ 
/* 431 */     if ((!senderPermAdd.hasPermission(32L)) || (senderPermNeg.hasPermission(32L)))
/*     */     {
/* 433 */       throw new PrivateMessageRejectedException(PrivateMessageRejectedException.NOT_ALLOWED);
/*     */     }
/*     */ 
/* 438 */     if ((this.maxMessagesPerUser != -1) && (getMessageCount(recipient) >= this.maxMessagesPerUser)) {
/* 439 */       throw new PrivateMessageRejectedException(PrivateMessageRejectedException.RECIPIENT_MAILBOX_FULL);
/*     */     }
/*     */ 
/* 443 */     if ((this.maxMessagesPerUser != -1) && (copyToSentFolder) && (getMessageCount(privateMessage.getSender()) >= this.maxMessagesPerUser))
/*     */     {
/* 446 */       throw new PrivateMessageRejectedException(PrivateMessageRejectedException.SENDER_MAILBOX_FULL);
/*     */     }
/*     */ 
/* 450 */     DbPrivateMessage dbPrivateMessage = null;
/* 451 */     if ((privateMessage instanceof PrivateMessageProxy)) {
/* 452 */       PrivateMessageProxy proxy = (PrivateMessageProxy)privateMessage;
/* 453 */       dbPrivateMessage = (DbPrivateMessage)proxy.getProxiedPrivateMessage();
/*     */     }
/*     */     else {
/* 456 */       dbPrivateMessage = (DbPrivateMessage)privateMessage;
/*     */     }
/* 458 */     dbPrivateMessage.setRecipient(recipient);
/*     */ 
/* 460 */     boolean wasDraft = dbPrivateMessage.getFolder() != null;
/*     */     try {
/* 462 */       PrivateMessageFolder drafts = getFolder(recipient, 1);
/* 463 */       dbPrivateMessage.setFolder(drafts);
/*     */     }
/*     */     catch (PrivateMessageFolderNotFoundException e) {
/*     */     }
/* 467 */     dbPrivateMessage.setRead(false);
/* 468 */     if (dbPrivateMessage.getID() == -1L) {
/*     */       try {
/* 470 */         dbPrivateMessage.insertIntoDb();
/*     */       }
/*     */       catch (Exception e) {
/* 473 */         Log.error(e);
/*     */       }
/*     */     }
/*     */     else {
/* 477 */       dbPrivateMessage.saveToDb();
/*     */     }
/*     */ 
/* 480 */     if (copyToSentFolder) {
/*     */       try {
/* 482 */         DbPrivateMessage copy = new DbPrivateMessage(dbPrivateMessage);
/*     */ 
/* 484 */         copy.setRead(true);
/*     */ 
/* 486 */         copy.setFolder(getPrivateMessageFolder(2, copy.getSender().getID()));
/*     */ 
/* 488 */         copy.insertIntoDb();
/*     */       }
/*     */       catch (Exception e) {
/* 491 */         Log.error(e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 496 */     FACTORY.cacheManager.privateMessageFolderCache.remove(DbPrivateMessageFolder.getCacheKey(1, recipient.getID()));
/*     */ 
/* 498 */     if (wasDraft) {
/* 499 */       FACTORY.cacheManager.privateMessageFolderCache.remove(DbPrivateMessageFolder.getCacheKey(3, dbPrivateMessage.getSender().getID()));
/*     */     }
/*     */ 
/* 502 */     if (copyToSentFolder) {
/* 503 */       FACTORY.cacheManager.privateMessageFolderCache.remove(DbPrivateMessageFolder.getCacheKey(2, dbPrivateMessage.getSender().getID()));
/*     */     }
/*     */ 
/* 508 */     long userID = privateMessage.getRecipient().getID();
/* 509 */     FACTORY.cacheManager.privateMessageCache.remove("total_pmcount-" + userID);
/* 510 */     FACTORY.cacheManager.privateMessageCache.remove("unread_pmcount-" + userID);
/*     */ 
/* 513 */     PrivateMessageEvent event = new PrivateMessageEvent(140, dbPrivateMessage, Collections.EMPTY_MAP);
/*     */ 
/* 515 */     PrivateMessageEventDispatcher.getInstance().dispatchEvent(event);
/*     */   }
/*     */ 
/*     */   DbPrivateMessage getPrivateMessage(long pMessageID)
/*     */     throws PrivateMessageNotFoundException
/*     */   {
/* 526 */     Cache cache = FACTORY.cacheManager.privateMessageCache;
/* 527 */     DbPrivateMessage privateMessage = (DbPrivateMessage)cache.get(new Long(pMessageID));
/*     */ 
/* 529 */     if (privateMessage == null) {
/* 530 */       synchronized (("pm" + Long.toString(pMessageID)).intern()) {
/* 531 */         privateMessage = (DbPrivateMessage)cache.get(new Long(pMessageID));
/* 532 */         if (privateMessage == null) {
/* 533 */           privateMessage = new DbPrivateMessage(pMessageID);
/* 534 */           cache.put(new Long(pMessageID), privateMessage);
/*     */         }
/*     */       }
/*     */     }
/* 538 */     return privateMessage;
/*     */   }
/*     */ 
/*     */   DbPrivateMessageFolder getPrivateMessageFolder(int folderID, long userID)
/*     */     throws PrivateMessageFolderNotFoundException
/*     */   {
/* 556 */     if (folderID == 4) {
/* 557 */       return new DbPrivateMessageFolder(folderID, userID);
/*     */     }
/*     */ 
/* 560 */     Cache cache = FACTORY.cacheManager.privateMessageFolderCache;
/* 561 */     String key = DbPrivateMessageFolder.getCacheKey(folderID, userID);
/* 562 */     DbPrivateMessageFolder folder = (DbPrivateMessageFolder)cache.get(key);
/* 563 */     if (folder == null) {
/* 564 */       synchronized (key.intern()) {
/* 565 */         folder = (DbPrivateMessageFolder)cache.get(key);
/* 566 */         if (folder == null) {
/* 567 */           folder = new DbPrivateMessageFolder(folderID, userID);
/* 568 */           cache.put(key, folder);
/*     */         }
/*     */       }
/*     */     }
/* 572 */     return folder;
/*     */   }
/*     */ 
/*     */   private static class PurgeTrashTask implements Runnable
/*     */   {
/*     */     private PurgeTrashTask() {
/*     */     }
/*     */ 
/*     */     public void run() {
/* 581 */       Connection con = null;
/* 582 */       Statement stmt = null;
/* 583 */       boolean abortTransaction = false;
/*     */       try {
/* 585 */         con = ConnectionManager.getTransactionConnection();
/* 586 */         stmt = con.createStatement();
/* 587 */         stmt.execute("DELETE FROM jivePMessage WHERE folderID=4");
/*     */       }
/*     */       catch (SQLException sqle) {
/* 590 */         abortTransaction = true;
/* 591 */         Log.error(sqle);
/*     */       } finally {
/*     */         try {
/* 594 */           if (stmt != null) stmt.close(); 
/*     */         } catch (Exception e) { Log.error(e); }
/* 596 */         ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*     */       }
/*     */     }
/*     */ 
/*     */     PurgeTrashTask(DbPrivateMessageManager.1 x0)
/*     */     {
/* 578 */       this();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbPrivateMessageManager
 * JD-Core Version:    0.6.2
 */
/*      */ package com.jivesoftware.forum.database;
/*      */ 
/*      */ import com.jivesoftware.base.JiveGlobals;
/*      */ import com.jivesoftware.base.JiveManager;
/*      */ import com.jivesoftware.base.LicenseException;
/*      */ import com.jivesoftware.base.LicenseManager;
/*      */ import com.jivesoftware.base.Log;
/*      */ import com.jivesoftware.base.User;
/*      */ import com.jivesoftware.base.database.ConnectionManager;
/*      */ import com.jivesoftware.base.util.HtmlExtractor;
/*      */ import com.jivesoftware.base.util.TextExtractor;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*      */ import com.jivesoftware.forum.ForumNotFoundException;
/*      */ import com.jivesoftware.forum.ForumThread;
/*      */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*      */ import com.jivesoftware.forum.SearchManager;
/*      */ import com.jivesoftware.forum.Version;
/*      */ import com.jivesoftware.forum.Version.Edition;
/*      */ import com.jivesoftware.forum.event.ForumEvent;
/*      */ import com.jivesoftware.forum.event.ForumEventDispatcher;
/*      */ import com.jivesoftware.forum.event.ForumListener;
/*      */ import com.jivesoftware.forum.event.MessageEvent;
/*      */ import com.jivesoftware.forum.event.MessageEventDispatcher;
/*      */ import com.jivesoftware.forum.event.MessageListener;
/*      */ import com.jivesoftware.forum.event.SearchIndexEvent;
/*      */ import com.jivesoftware.forum.event.SearchIndexEventDispatcher;
/*      */ import com.jivesoftware.forum.event.ThreadEvent;
/*      */ import com.jivesoftware.forum.event.ThreadEventDispatcher;
/*      */ import com.jivesoftware.forum.event.ThreadListener;
/*      */ import com.jivesoftware.util.CacheFactory;
/*      */ import com.jivesoftware.util.ClassUtils;
/*      */ import com.jivesoftware.util.LongList;
/*      */ import com.jivesoftware.util.ReadWriteLock;
/*      */ import com.jivesoftware.util.Semaphore;
/*      */ import com.jivesoftware.util.StringUtils;
/*      */ import com.jivesoftware.util.TaskEngine;
/*      */ import com.jivesoftware.util.TaskQueue;
/*      */ import com.jivesoftware.util.XMLProperties;
/*      */ import com.jivesoftware.util.search.JiveAnalyzer;
/*      */ import com.jivesoftware.util.search.StandardSynonymAnalyzer;
/*      */ import java.io.File;
/*      */ import java.io.FileWriter;
/*      */ import java.io.FilenameFilter;
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimerTask;
/*      */ import org.apache.lucene.analysis.Analyzer;
/*      */ import org.apache.lucene.document.DateField;
/*      */ import org.apache.lucene.document.Field;
/*      */ import org.apache.lucene.index.IndexReader;
/*      */ import org.apache.lucene.index.IndexWriter;
/*      */ import org.apache.lucene.index.Term;
/*      */ import org.apache.lucene.search.IndexSearcher;
/*      */ import org.apache.lucene.search.Searcher;
/*      */ import org.apache.lucene.store.Directory;
/*      */ import org.apache.lucene.store.FSDirectory;
/*      */ import org.dom4j.DocumentFactory;
/*      */ import org.dom4j.io.OutputFormat;
/*      */ import org.dom4j.io.XMLWriter;
/*      */ 
/*      */ public class DbSearchManager
/*      */   implements SearchManager, JiveManager, Runnable, MessageListener, ThreadListener, ForumListener
/*      */ {
/*      */   public static final String STANDARD_ANALYZER = "com.jivesoftware.util.search.StandardSynonymAnalyzer";
/*      */   public static final String BRAZILIAN_ANALYZER = "com.jivesoftware.util.search.BrazilianStemmingAnalyzer";
/*      */   public static final String CJK_ANALYZER = "com.jivesoftware.util.search.CJKAnalyzer";
/*      */   public static final String CZECH_ANALYZER = "com.jivesoftware.util.search.CzechAnalyzer";
/*      */   public static final String DANISH_ANALYZER = "com.jivesoftware.util.search.DanishStemmingAnalyzer";
/*      */   public static final String DUTCH_ANALYZER = "com.jivesoftware.util.search.DutchStemmingAnalyzer";
/*      */   public static final String ENGLISH_ANALYZER = "com.jivesoftware.util.search.EnglishStemmingAnalyzer";
/*      */   public static final String FINNISH_ANALYZER = "com.jivesoftware.util.search.FinnishStemmingAnalyzer";
/*      */   public static final String FRENCH_ANALYZER = "com.jivesoftware.util.search.FrenchStemmingAnalyzer";
/*      */   public static final String GERMAN_ANALYZER = "com.jivesoftware.util.search.GermanStemmingAnalyzer";
/*      */   public static final String ITALIAN_ANALYZER = "com.jivesoftware.util.search.ItalianStemmingAnalyzer";
/*      */   public static final String NORWEGIAN_ANALYZER = "com.jivesoftware.util.search.NorwegianStemmingAnalyzer";
/*      */   public static final String PORTUGUESE_ANALYZER = "com.jivesoftware.util.search.PortugueseStemmingAnalyzer";
/*      */   public static final String RUSSIAN_ANALYZER = "com.jivesoftware.util.search.RussianStemmingAnalyzer";
/*      */   public static final String SPANISH_ANALYZER = "com.jivesoftware.util.search.SpanishStemmingAnalyzer";
/*      */   public static final String SWEDISH_ANALYZER = "com.jivesoftware.util.search.SwedishStemmingAnalyzer";
/*      */   private static final String MESSAGES_BEFORE_DATE = "SELECT jiveMessage.messageID, jiveMessage.userID, jiveMessage.threadID, jiveMessage.forumID, subject, body, jiveMessage.creationDate, jiveMessage.modificationDate FROM jiveMessage, jiveForum WHERE jiveForum.forumID=jiveMessage.forumID AND messageID >= ? AND messageID < ? AND jiveMessage.modificationDate < ? AND jiveMessage.modValue >= 1";
/*      */   private static final String MESSAGES_BEFORE_DATE_COUNT = "SELECT count(*) FROM jiveMessage, jiveForum WHERE jiveForum.forumID=jiveMessage.forumID AND jiveMessage.modValue >= 1 AND jiveMessage.modificationDate < ?";
/*      */   private static final String MESSAGES_SINCE_DATE = "SELECT jiveMessage.messageID, jiveMessage.userID, jiveMessage.threadID, jiveMessage.forumID, subject, body, jiveMessage.creationDate, jiveMessage.modificationDate  FROM jiveMessage, jiveForum WHERE jiveForum.forumID=jiveMessage.forumID AND jiveMessage.modValue >= 1 AND jiveMessage.modificationDate > ? AND jiveMessage.modificationDate < ?";
/*      */   private static final String MESSAGES_SINCE_DATE_COUNT = "SELECT count(*) FROM jiveMessage, jiveForum WHERE jiveForum.forumID=jiveMessage.forumID AND jiveMessage.modValue >= 1 AND jiveMessage.modificationDate > ? AND jiveMessage.modificationDate < ?";
/*      */   private static final String MESSAGE_IDS_SINCE_DATE = "SELECT jiveMessage.messageID FROM jiveMessage, jiveForum WHERE jiveForum.forumID=jiveMessage.forumID AND jiveMessage.modificationDate > ? AND jiveMessage.modificationDate < ?";
/*      */   private static final String HIGHEST_MESSAGE_ID = "SELECT MAX(messageID) FROM jiveMessage";
/*  228 */   protected static Analyzer indexerAnalyzer = null;
/*      */ 
/*  235 */   protected static Analyzer searcherAnalyzer = null;
/*      */ 
/*  240 */   protected static ReadWriteLock searcherLock = new ReadWriteLock();
/*      */   private static final int BLOCK_SIZE = 500;
/*  247 */   private static DbSearchManager instance = new DbSearchManager();
/*  248 */   private static XMLProperties properties = null;
/*  249 */   private static boolean initialized = false;
/*      */ 
/*  251 */   private static File mainDir = null;
/*  252 */   private static Directory searchDirectory = null;
/*      */ 
/*  254 */   private static Searcher searcher = null;
/*  255 */   private static IndexReader searcherReader = null;
/*      */ 
/*  257 */   private static Semaphore indexLock = new Semaphore(1L);
/*  258 */   private static Semaphore newIndexLock = new Semaphore(1L);
/*      */ 
/*  265 */   private boolean searchEnabled = true;
/*      */ 
/*  270 */   private boolean wildcardIgnored = false;
/*      */ 
/*  275 */   private boolean attachmentSearchEnabled = false;
/*      */ 
/*  281 */   private boolean autoIndexEnabled = true;
/*      */   private int autoIndexInterval;
/*      */   private Date lastIndexed;
/*      */   private boolean filterHTMLEnabled;
/*  300 */   private int currentCount = 0;
/*  301 */   private int totalCount = -1;
/*      */ 
/*  306 */   private TimerTask timerTask = null;
/*      */ 
/*  308 */   private TaskQueue queue = new TaskQueue();
/*      */ 
/*  313 */   private boolean rebuildScheduled = false;
/*      */ 
/*      */   public static DbSearchManager getInstance()
/*      */   {
/*  317 */     return instance;
/*      */   }
/*      */ 
/*      */   private DbSearchManager()
/*      */   {
/*  322 */     this.autoIndexInterval = JiveGlobals.getJiveIntProperty("search.autoIndexInterval", 10);
/*      */ 
/*  325 */     this.searchEnabled = JiveGlobals.getJiveBooleanProperty("search.enabled", true);
/*      */ 
/*  328 */     this.wildcardIgnored = JiveGlobals.getJiveBooleanProperty("search.wildcardIgnored");
/*      */ 
/*  332 */     boolean isEntOrExpert = (Version.getEdition() == Version.Edition.ENTERPRISE) || (Version.getEdition() == Version.Edition.EXPERT);
/*      */ 
/*  335 */     this.attachmentSearchEnabled = JiveGlobals.getJiveBooleanProperty("search.attachmentsEnabled", isEntOrExpert);
/*      */ 
/*  339 */     this.filterHTMLEnabled = JiveGlobals.getJiveBooleanProperty("search.filterHTMLEnabled");
/*      */ 
/*  342 */     this.autoIndexEnabled = JiveGlobals.getJiveBooleanProperty("search.autoIndexEnabled", true);
/*      */   }
/*      */ 
/*      */   public synchronized void initialize()
/*      */   {
/*  347 */     if (initialized) {
/*  348 */       return;
/*      */     }
/*      */ 
/*  352 */     String mainDirectory = JiveGlobals.getJiveProperty("search.mainDirectory");
/*  353 */     if (mainDirectory == null) {
/*  354 */       mainDirectory = new File(JiveGlobals.getJiveHome(), "search").toString();
/*      */     }
/*      */ 
/*  357 */     if (!mainDirectory.endsWith(File.separator)) {
/*  358 */       mainDirectory = mainDirectory + File.separator;
/*      */     }
/*      */ 
/*  362 */     mainDir = new File(mainDirectory);
/*  363 */     if (!mainDir.exists()) {
/*  364 */       mainDir.mkdir();
/*      */     }
/*      */ 
/*  367 */     loadProperties();
/*  368 */     loadAnalyzer();
/*      */ 
/*  371 */     String lastInd = properties.getProperty("search.lastIndexed");
/*      */     try {
/*  373 */       this.lastIndexed = new Date(Long.parseLong(lastInd));
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  379 */       this.lastIndexed = new Date(0L);
/*      */     }
/*      */ 
/*  382 */     Thread thread = new Thread(this.queue);
/*      */ 
/*  384 */     thread.setDaemon(true);
/*  385 */     thread.start();
/*      */ 
/*  387 */     if (this.attachmentSearchEnabled) {
/*      */       try {
/*  389 */         LicenseManager.validateLicense("Jive Forums Enterprise", "4.2");
/*      */       }
/*      */       catch (LicenseException le) {
/*  392 */         Log.error("Error enabling attachment search: a valid Jive Forums Enterprise is required to use the attachment search feature.");
/*      */ 
/*  394 */         this.attachmentSearchEnabled = false;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  399 */     if (this.autoIndexEnabled) {
/*  400 */       this.timerTask = TaskEngine.scheduleTask(this, this.autoIndexInterval * 60000L, this.autoIndexInterval * 60000L);
/*      */     }
/*      */ 
/*  406 */     String jiveHome = JiveGlobals.getJiveHome();
/*  407 */     if (jiveHome == null) {
/*  408 */       Log.error("ERROR: the jiveHome property is not set.");
/*      */     }
/*      */ 
/*  413 */     String subDir = properties.getProperty("search.directory");
/*      */ 
/*  418 */     if ((subDir == null) || (!new File(mainDir, subDir).exists()))
/*      */     {
/*  420 */       File[] files = mainDir.listFiles();
/*      */       try {
/*  422 */         for (int i = 0; i < files.length; i++) {
/*  423 */           File file = files[i];
/*      */ 
/*  428 */           if ((file.isDirectory()) && (file.getName().length() == 8)) {
/*  429 */             File[] subfiles = file.listFiles();
/*  430 */             for (int j = 0; j < subfiles.length; j++) {
/*  431 */               subfiles[j].delete();
/*      */             }
/*  433 */             file.delete();
/*      */           }
/*      */           else {
/*  436 */             files[i].delete();
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (Exception e) {
/*  441 */         Log.error(e);
/*      */       }
/*      */ 
/*  444 */       rebuildIndex();
/*      */     }
/*      */     else
/*      */     {
/*  448 */       File searchDir = new File(mainDir, subDir);
/*      */ 
/*  450 */       File[] files = mainDir.listFiles();
/*      */       try
/*      */       {
/*  453 */         for (int i = 0; i < files.length; i++) {
/*  454 */           File file = files[i];
/*      */ 
/*  467 */           if ((file.isDirectory()) && (!file.equals(searchDir)) && (file.getName().length() == 8)) {
/*  468 */             File[] subfiles = file.listFiles();
/*  469 */             for (int j = 0; j < subfiles.length; j++) {
/*  470 */               subfiles[j].delete();
/*      */             }
/*  472 */             file.delete();
/*      */           }
/*  474 */           else if (!"jive_search.xml".equals(file.getName())) {
/*  475 */             files[i].delete();
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  480 */         files = searchDir.listFiles(new FilenameFilter() {
/*      */           public boolean accept(File dir, String name) {
/*  482 */             if (name.endsWith(".lock")) {
/*  483 */               return true;
/*      */             }
/*  485 */             return false;
/*      */           }
/*      */         });
/*  489 */         if (files != null)
/*  490 */           for (int i = 0; i < files.length; i++) {
/*  491 */             File file = files[i];
/*  492 */             file.delete();
/*      */           }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  497 */         Log.error(e);
/*      */       }
/*      */ 
/*  502 */       if (!searchDir.exists())
/*  503 */         rebuildIndex();
/*      */       else {
/*      */         try
/*      */         {
/*  507 */           searchDirectory = FSDirectory.getDirectory(searchDir, false);
/*      */ 
/*  510 */           if (!IndexReader.indexExists(searchDirectory)) {
/*  511 */             Log.error("Lucene says index does not exist or is corrupt in directory " + searchDir + ", rebuilding index.");
/*      */ 
/*  513 */             searchDirectory = null;
/*  514 */             rebuildIndex();
/*      */           }
/*      */         }
/*      */         catch (IOException ioe) {
/*  518 */           Log.error(ioe);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  525 */     if ((this.autoIndexEnabled) && (!JiveGlobals.getJiveBooleanProperty("search.disableAutoOptimize", false)))
/*      */     {
/*  527 */       TaskEngine.scheduleTask(new OptimizeTask(null), 900000L, 43200000L);
/*      */     }
/*      */ 
/*  531 */     ThreadEventDispatcher.getInstance().addListener(this);
/*  532 */     MessageEventDispatcher.getInstance().addListener(this);
/*  533 */     ForumEventDispatcher.getInstance().addListener(this);
/*      */ 
/*  535 */     initialized = true;
/*      */   }
/*      */ 
/*      */   private static synchronized void loadProperties()
/*      */   {
/*  544 */     if (properties == null) {
/*  545 */       String jiveHome = JiveGlobals.getJiveHome();
/*  546 */       if (jiveHome == null) {
/*  547 */         Log.error("ERROR: the jiveHome property is not set.");
/*  548 */         return;
/*      */       }
/*      */ 
/*  551 */       String searchXML = new File(mainDir, "jive_search.xml").toString();
/*      */ 
/*  555 */       File file = new File(searchXML);
/*      */ 
/*  557 */       if (!file.exists()) {
/*  558 */         org.dom4j.Document doc = DocumentFactory.getInstance().createDocument(DocumentFactory.getInstance().createElement("jiveSearch"));
/*      */ 
/*  561 */         Writer out = null;
/*      */         try
/*      */         {
/*  564 */           out = new FileWriter(file);
/*  565 */           XMLWriter outputter = new XMLWriter(out, OutputFormat.createPrettyPrint());
/*  566 */           outputter.write(doc);
/*  567 */           outputter.flush();
/*      */         }
/*      */         catch (Exception e) {
/*  570 */           Log.error(e);
/*      */         } finally {
/*      */           try {
/*  573 */             if (out != null) out.close(); 
/*      */           }
/*      */           catch (Exception e) {  }
/*      */ 
/*      */         }
/*      */       }
/*  578 */       XMLProperties p = null;
/*      */       try {
/*  580 */         p = new XMLProperties(searchXML);
/*      */       }
/*      */       catch (IOException e) {
/*  583 */         Log.error(e);
/*      */       }
/*      */ 
/*  586 */       properties = p;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void loadAnalyzer()
/*      */   {
/*  594 */     Analyzer analyzer = null;
/*      */ 
/*  596 */     String analyzerClass = JiveGlobals.getJiveProperty("search.analyzer.className");
/*      */ 
/*  598 */     List stopWords = new ArrayList();
/*  599 */     if (JiveGlobals.getJiveProperty("search.analyzer.stopWordList") != null) {
/*  600 */       String words = JiveGlobals.getJiveProperty("search.analyzer.stopWordList");
/*  601 */       StringTokenizer st = new StringTokenizer(words, ",");
/*      */ 
/*  603 */       while (st.hasMoreTokens()) {
/*  604 */         stopWords.add(st.nextToken().trim());
/*      */       }
/*      */     }
/*  607 */     if (analyzerClass != null) {
/*      */       try {
/*  609 */         analyzer = getAnalyzerInstance(analyzerClass, stopWords);
/*      */       }
/*      */       catch (Exception e) {
/*  612 */         Log.error("Error loading custom search analyzer: " + analyzerClass, e);
/*      */       }
/*      */     }
/*      */ 
/*  616 */     if ((analyzer == null) && (stopWords.size() > 0)) {
/*  617 */       analyzer = new StandardSynonymAnalyzer((String[])stopWords.toArray(new String[stopWords.size()]));
/*      */     }
/*  620 */     else if (analyzer == null) {
/*  621 */       analyzer = new StandardSynonymAnalyzer();
/*      */     }
/*      */ 
/*  624 */     indexerAnalyzer = analyzer;
/*      */ 
/*  627 */     analyzer = null;
/*  628 */     if (analyzerClass != null) {
/*      */       try {
/*  630 */         analyzer = getAnalyzerInstance(analyzerClass, stopWords);
/*      */       }
/*      */       catch (Exception e) {
/*  633 */         Log.error("Error loading custom search analyzer: " + analyzerClass, e);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  638 */     if ((analyzer == null) && (stopWords.size() > 0)) {
/*  639 */       analyzer = new StandardSynonymAnalyzer((String[])stopWords.toArray(new String[stopWords.size()]));
/*      */     }
/*  642 */     else if (analyzer == null) {
/*  643 */       analyzer = new StandardSynonymAnalyzer();
/*      */     }
/*      */ 
/*  649 */     if ((analyzer instanceof JiveAnalyzer)) {
/*  650 */       ((JiveAnalyzer)analyzer).setDisableSynonyms(true);
/*      */     }
/*      */ 
/*  653 */     searcherAnalyzer = analyzer;
/*      */   }
/*      */ 
/*      */   private static Analyzer getAnalyzerInstance(String analyzerClass, List stopWords)
/*      */     throws Exception
/*      */   {
/*  659 */     Analyzer analyzer = null;
/*      */ 
/*  661 */     Class c = ClassUtils.forName(analyzerClass);
/*      */ 
/*  663 */     if (stopWords.size() > 0) {
/*  664 */       Class[] params = { new String[0].getClass() };
/*      */       try {
/*  666 */         Constructor constructor = c.getConstructor(params);
/*  667 */         Object[] initargs = { (String[])(String[])stopWords.toArray(new String[stopWords.size()]) };
/*  668 */         analyzer = (Analyzer)constructor.newInstance(initargs);
/*      */       }
/*      */       catch (NoSuchMethodException e)
/*      */       {
/*  672 */         analyzer = (Analyzer)c.newInstance();
/*      */       }
/*      */     }
/*      */     else {
/*  676 */       analyzer = (Analyzer)c.newInstance();
/*      */     }
/*      */ 
/*  679 */     return analyzer;
/*      */   }
/*      */ 
/*      */   public static XMLProperties getProperties() {
/*  683 */     return properties;
/*      */   }
/*      */ 
/*      */   public static String getAnalyzer()
/*      */   {
/*  712 */     String analyzerClass = JiveGlobals.getJiveProperty("search.analyzer.className");
/*  713 */     if (analyzerClass == null) {
/*  714 */       return "com.jivesoftware.util.search.StandardSynonymAnalyzer";
/*      */     }
/*      */ 
/*  717 */     return analyzerClass;
/*      */   }
/*      */ 
/*      */   public static void setAnalyzer(String className)
/*      */   {
/*  749 */     if (className == null) {
/*  750 */       throw new NullPointerException("Argument is null.");
/*      */     }
/*      */ 
/*  753 */     if (className.equals(getAnalyzer())) {
/*  754 */       return;
/*      */     }
/*      */ 
/*  757 */     if (className.equals("com.jivesoftware.util.search.StandardSynonymAnalyzer")) {
/*  758 */       JiveGlobals.deleteJiveProperty("search.analyzer.className");
/*      */     }
/*      */     else {
/*  761 */       JiveGlobals.setJiveProperty("search.analyzer.className", className);
/*      */     }
/*  763 */     loadAnalyzer();
/*      */   }
/*      */ 
/*      */   public int getAutoIndexInterval()
/*      */   {
/*  773 */     return this.autoIndexInterval;
/*      */   }
/*      */ 
/*      */   public void setAutoIndexInterval(int minutes) {
/*  777 */     this.autoIndexInterval = minutes;
/*  778 */     JiveGlobals.setJiveProperty("search.autoIndexInterval", "" + this.autoIndexInterval);
/*      */ 
/*  781 */     if (this.timerTask != null) {
/*  782 */       this.timerTask.cancel();
/*      */     }
/*  784 */     this.timerTask = TaskEngine.scheduleTask(this, this.autoIndexInterval * 60000L, this.autoIndexInterval * 60000L);
/*      */   }
/*      */ 
/*      */   public Date getLastIndexedDate()
/*      */   {
/*  789 */     return this.lastIndexed;
/*      */   }
/*      */ 
/*      */   public boolean isSearchEnabled() {
/*  793 */     return this.searchEnabled;
/*      */   }
/*      */ 
/*      */   public void setSearchEnabled(boolean searchEnabled) {
/*  797 */     this.searchEnabled = searchEnabled;
/*  798 */     JiveGlobals.setJiveProperty("search.enabled", String.valueOf(searchEnabled));
/*      */   }
/*      */ 
/*      */   public boolean isAttachmentSearchEnabled() {
/*  802 */     return this.attachmentSearchEnabled;
/*      */   }
/*      */ 
/*      */   public void setAttachmentSearchEnabled(boolean attachmentSearchEnabled) {
/*  806 */     if (attachmentSearchEnabled) {
/*      */       try {
/*  808 */         LicenseManager.validateLicense("Jive Forums Enterprise", "4.2");
/*      */       }
/*      */       catch (LicenseException le) {
/*  811 */         Log.error("Error enabling attachment search: a valid Jive Forums Enterprise is required to use the attachment search feature.");
/*      */ 
/*  813 */         attachmentSearchEnabled = false;
/*      */       }
/*      */     }
/*  816 */     this.attachmentSearchEnabled = attachmentSearchEnabled;
/*  817 */     JiveGlobals.setJiveProperty("search.attachmentsEnabled", String.valueOf(attachmentSearchEnabled));
/*      */   }
/*      */ 
/*      */   public boolean isFilterHTMLEnabled() {
/*  821 */     return this.filterHTMLEnabled;
/*      */   }
/*      */ 
/*      */   public void setFilterHTMLEnabled(boolean filterHTMLEnabled) {
/*  825 */     this.filterHTMLEnabled = filterHTMLEnabled;
/*  826 */     JiveGlobals.setJiveProperty("search.filterHTMLEnabled", String.valueOf(filterHTMLEnabled));
/*      */   }
/*      */ 
/*      */   public TextExtractor[] getTextExtractors()
/*      */   {
/*  831 */     if (this.attachmentSearchEnabled) {
/*  832 */       return DbAttachmentSearchIndexer.getTextExtractors();
/*      */     }
/*  834 */     return new TextExtractor[0];
/*      */   }
/*      */ 
/*      */   public void addTextExtractor(String className) throws ClassNotFoundException {
/*  838 */     if (this.attachmentSearchEnabled)
/*  839 */       DbAttachmentSearchIndexer.addTextExtractor(className);
/*      */   }
/*      */ 
/*      */   public synchronized void removeTextExtractor(String className) throws ClassNotFoundException
/*      */   {
/*  844 */     if (this.attachmentSearchEnabled)
/*  845 */       DbAttachmentSearchIndexer.removeTextExtractor(className);
/*      */   }
/*      */ 
/*      */   public boolean isBusy()
/*      */   {
/*  852 */     return (indexLock.permits() == 0L) || (newIndexLock.permits() == 0L);
/*      */   }
/*      */ 
/*      */   public synchronized int getPercentComplete() {
/*  856 */     if (!isBusy()) {
/*  857 */       return -1;
/*      */     }
/*      */ 
/*  860 */     if ((this.totalCount == -1) || (this.totalCount == 0)) {
/*  861 */       return 0;
/*      */     }
/*      */ 
/*  864 */     return (int)(this.currentCount / this.totalCount * 100.0D);
/*      */   }
/*      */ 
/*      */   public int getTotalCount()
/*      */   {
/*  869 */     return this.totalCount;
/*      */   }
/*      */ 
/*      */   public int getCurrentCount() {
/*  873 */     return this.currentCount;
/*      */   }
/*      */ 
/*      */   public boolean isWildcardIgnored() {
/*  877 */     return this.wildcardIgnored;
/*      */   }
/*      */ 
/*      */   public void setWildcardIgnored(boolean value) {
/*  881 */     this.wildcardIgnored = value;
/*  882 */     JiveGlobals.setJiveProperty("search.wildcardIgnored", "" + value);
/*      */   }
/*      */ 
/*      */   public boolean isAutoIndexEnabled() {
/*  886 */     return this.autoIndexEnabled;
/*      */   }
/*      */ 
/*      */   public void setAutoIndexEnabled(boolean enabled)
/*      */   {
/*  891 */     if ((!this.autoIndexEnabled) && (enabled)) {
/*  892 */       if (this.timerTask != null) {
/*  893 */         this.timerTask.cancel();
/*      */       }
/*  895 */       this.timerTask = TaskEngine.scheduleTask(this, this.autoIndexInterval * 60000L, this.autoIndexInterval * 60000L);
/*      */     }
/*  899 */     else if ((this.autoIndexEnabled) && (!enabled) && 
/*  900 */       (this.timerTask != null)) {
/*  901 */       this.timerTask.cancel();
/*      */     }
/*      */ 
/*  904 */     this.autoIndexEnabled = enabled;
/*  905 */     JiveGlobals.setJiveProperty("search.autoIndexEnabled", "" + enabled);
/*      */   }
/*      */ 
/*      */   public synchronized void addToIndex(ForumMessage message) {
/*  909 */     if (this.searchEnabled)
/*  910 */       addToIndex(message, true);
/*      */   }
/*      */ 
/*      */   public synchronized void addToIndex(ForumMessage message, boolean cluster)
/*      */   {
/*  915 */     this.queue.add(new AddTask(message));
/*      */ 
/*  918 */     if ((CacheFactory.isClusteringEnabled()) && (cluster))
/*      */       try {
/*  920 */         DbForumFactory factory = DbForumFactory.getInstance();
/*  921 */         DbForumMessage dbMessage = (DbForumMessage)factory.getMessage(message.getID());
/*  922 */         SearchClusterTask task = new SearchClusterTask();
/*  923 */         task.setAdd(true);
/*  924 */         task.setMessage(dbMessage);
/*  925 */         CacheFactory.doClusterTask(task);
/*      */       }
/*      */       catch (ForumMessageNotFoundException e) {
/*  928 */         Log.error(e);
/*      */       }
/*      */   }
/*      */ 
/*      */   public void removeFromIndex(ForumMessage message)
/*      */   {
/*  934 */     removeFromIndex(message, true);
/*      */   }
/*      */ 
/*      */   public synchronized void removeFromIndex(ForumMessage message, boolean cluster) {
/*  938 */     this.queue.add(new RemoveTask(message.getID(), DeletionType.MESSAGE));
/*      */ 
/*  941 */     if ((CacheFactory.isClusteringEnabled()) && (cluster))
/*      */       try {
/*  943 */         DbForumFactory factory = DbForumFactory.getInstance();
/*  944 */         DbForumMessage dbMessage = (DbForumMessage)factory.getMessage(message.getID());
/*  945 */         SearchClusterTask task = new SearchClusterTask();
/*  946 */         task.setDelete(true);
/*  947 */         task.setMessage(dbMessage);
/*  948 */         CacheFactory.doClusterTask(task);
/*      */       }
/*      */       catch (ForumMessageNotFoundException e) {
/*  951 */         Log.error(e);
/*      */       }
/*      */   }
/*      */ 
/*      */   public void removeFromIndex(ForumThread thread)
/*      */   {
/*  957 */     removeFromIndex(thread, true);
/*      */   }
/*      */ 
/*      */   public synchronized void removeFromIndex(ForumThread thread, boolean cluster) {
/*  961 */     this.queue.add(new RemoveTask(thread.getID(), DeletionType.THREAD));
/*      */ 
/*  964 */     if ((CacheFactory.isClusteringEnabled()) && (cluster))
/*      */       try {
/*  966 */         DbForumFactory factory = DbForumFactory.getInstance();
/*  967 */         DbForumThread dbThread = (DbForumThread)factory.getForumThread(thread.getID());
/*  968 */         SearchClusterTask task = new SearchClusterTask();
/*  969 */         task.setDelete(true);
/*  970 */         task.setThread(dbThread);
/*  971 */         CacheFactory.doClusterTask(task);
/*      */       }
/*      */       catch (ForumThreadNotFoundException e) {
/*  974 */         Log.error(e);
/*      */       }
/*      */   }
/*      */ 
/*      */   public void removeFromIndex(Forum forum)
/*      */   {
/*  980 */     removeFromIndex(forum, true);
/*      */   }
/*      */ 
/*      */   public synchronized void removeFromIndex(Forum forum, boolean cluster) {
/*  984 */     this.queue.add(new RemoveTask(forum.getID(), DeletionType.FORUM));
/*      */ 
/*  987 */     if ((CacheFactory.isClusteringEnabled()) && (cluster))
/*      */       try {
/*  989 */         DbForumFactory factory = DbForumFactory.getInstance();
/*  990 */         DbForum dbForum = (DbForum)factory.getForum(forum.getID());
/*  991 */         SearchClusterTask task = new SearchClusterTask();
/*  992 */         task.setDelete(true);
/*  993 */         task.setForum(dbForum);
/*  994 */         CacheFactory.doClusterTask(task);
/*      */       }
/*      */       catch (ForumNotFoundException e) {
/*  997 */         Log.error(e);
/*      */       }
/*      */   }
/*      */ 
/*      */   public synchronized void updateIndex()
/*      */   {
/* 1003 */     if (this.searchEnabled)
/* 1004 */       TaskEngine.addTask(2, new IndexTask(false));
/*      */   }
/*      */ 
/*      */   public synchronized void rebuildIndex()
/*      */   {
/* 1009 */     if (this.searchEnabled)
/* 1010 */       TaskEngine.addTask(2, new IndexTask(true));
/*      */   }
/*      */ 
/*      */   public synchronized void optimize()
/*      */   {
/* 1015 */     if (this.searchEnabled)
/* 1016 */       this.queue.add(new OptimizeTask(null));
/*      */   }
/*      */ 
/*      */   private void rebuildIndex(Date end)
/*      */   {
/* 1027 */     if ((this.searchEnabled) && (!this.rebuildScheduled)) {
/* 1028 */       this.queue.add(new RebuildTask(end));
/*      */     }
/*      */     else
/* 1031 */       Log.warn("Search index rebuild already scheduled - not allowing another rebuild until current rebuild is complete.");
/*      */   }
/*      */ 
/*      */   protected final void updateIndex(Date start, Date end)
/*      */   {
/* 1042 */     if (this.searchEnabled)
/* 1043 */       this.queue.add(new UpdateTask(start, end));
/*      */   }
/*      */ 
/*      */   public synchronized void run()
/*      */   {
/* 1053 */     if (!this.searchEnabled) {
/* 1054 */       return;
/*      */     }
/*      */ 
/* 1058 */     TaskEngine.addTask(0, new IndexTask(false));
/*      */   }
/*      */ 
/*      */   protected final void addMessageToIndex(long messageID, long userID, long threadID, long forumID, String subject, String body, Date creationDate, Date modificationDate, IndexWriter writer)
/*      */     throws IOException
/*      */   {
/* 1070 */     if (writer == null) {
/* 1071 */       return;
/*      */     }
/*      */ 
/* 1074 */     org.apache.lucene.document.Document doc = new org.apache.lucene.document.Document();
/* 1075 */     doc.add(Field.Keyword("messageID", Long.toString(messageID)));
/* 1076 */     doc.add(Field.Keyword("userID", Long.toString(userID)));
/* 1077 */     doc.add(Field.Keyword("threadID", Long.toString(threadID)));
/* 1078 */     doc.add(Field.Keyword("forumID", Long.toString(forumID)));
/* 1079 */     if (subject != null) {
/* 1080 */       doc.add(Field.Text("subject", this.filterHTMLEnabled ? filterHTML(subject) : subject));
/*      */     }
/*      */     else {
/* 1083 */       doc.add(Field.Text("subject", ""));
/*      */     }
/* 1085 */     if (body != null) {
/* 1086 */       doc.add(Field.UnStored("body", this.filterHTMLEnabled ? filterHTML(body) : body));
/*      */     }
/*      */ 
/* 1089 */     doc.add(Field.Keyword("creationDate", DateField.dateToString(creationDate)));
/* 1090 */     doc.add(Field.Keyword("modificationDate", DateField.dateToString(modificationDate)));
/*      */ 
/* 1092 */     if (this.attachmentSearchEnabled) {
/* 1093 */       DbAttachmentSearchIndexer.indexAttachments(messageID, doc);
/*      */     }
/* 1095 */     writer.addDocument(doc);
/* 1096 */     closeSearcherReader();
/*      */   }
/*      */ 
/*      */   protected final void deleteMessagesFromIndex(long[] messages, IndexReader reader)
/*      */     throws IOException
/*      */   {
/* 1105 */     if ((messages == null) || (reader == null)) {
/* 1106 */       return;
/*      */     }
/*      */ 
/* 1110 */     for (int i = 0; i < messages.length; i++) {
/* 1111 */       Term term = new Term("messageID", Long.toString(messages[i]));
/* 1112 */       reader.delete(term);
/*      */     }
/*      */ 
/* 1115 */     closeSearcherReader();
/*      */   }
/*      */ 
/*      */   private static IndexWriter getWriter()
/*      */     throws IOException
/*      */   {
/* 1123 */     if ((searchDirectory != null) && (IndexReader.indexExists(searchDirectory))) {
/* 1124 */       IndexWriter writer = new IndexWriter(searchDirectory, indexerAnalyzer, false);
/* 1125 */       return writer;
/*      */     }
/*      */ 
/* 1129 */     if (searchDirectory == null) {
/* 1130 */       Log.warn("Search directory not set, you must rebuild the index.");
/*      */     }
/* 1132 */     else if (!IndexReader.indexExists(searchDirectory)) {
/* 1133 */       Log.warn("Search directory " + searchDirectory + " does not appear to " + "be a valid search index. You must rebuild the index.");
/*      */     }
/*      */ 
/* 1136 */     return null;
/*      */   }
/*      */ 
/*      */   static IndexReader getReader()
/*      */     throws IOException
/*      */   {
/* 1144 */     if ((searchDirectory != null) && (IndexReader.indexExists(searchDirectory))) {
/* 1145 */       return IndexReader.open(searchDirectory);
/*      */     }
/*      */ 
/* 1149 */     if (searchDirectory == null) {
/* 1150 */       Log.warn("Search directory not set, you must rebuild the index.");
/*      */     }
/* 1152 */     else if (!IndexReader.indexExists(searchDirectory)) {
/* 1153 */       Log.warn("Search directory " + searchDirectory + " does not appear to " + "be a valid search index. You must rebuild the index.");
/*      */     }
/*      */ 
/* 1156 */     return null;
/*      */   }
/*      */ 
/*      */   static Searcher getSearcher()
/*      */     throws IOException
/*      */   {
/* 1172 */     synchronized (indexerAnalyzer) {
/* 1173 */       if (searcherReader == null) {
/* 1174 */         if ((searchDirectory != null) && (IndexReader.indexExists(searchDirectory))) {
/* 1175 */           searcherReader = IndexReader.open(searchDirectory);
/* 1176 */           searcher = new IndexSearcher(searcherReader);
/*      */         }
/*      */         else
/*      */         {
/* 1180 */           if (searchDirectory == null) {
/* 1181 */             Log.warn("Search directory not set, you must rebuild the index.");
/*      */           }
/* 1183 */           else if (!IndexReader.indexExists(searchDirectory)) {
/* 1184 */             Log.warn("Search directory " + searchDirectory + " does not appear to " + "be a valid search index. You must rebuild the index.");
/*      */           }
/*      */ 
/* 1187 */           return null;
/*      */         }
/*      */       }
/*      */     }
/* 1191 */     return searcher;
/*      */   }
/*      */ 
/*      */   private static void closeSearcherReader()
/*      */     throws IOException
/*      */   {
/* 1201 */     if (searcherReader != null)
/*      */       try {
/* 1203 */         searcherLock.acquireWriteLock();
/* 1204 */         searcherReader.close();
/*      */       }
/*      */       finally {
/* 1207 */         searcherReader = null;
/* 1208 */         searcherLock.releaseWriteLock();
/*      */       }
/*      */   }
/*      */ 
/*      */   public void messageAdded(MessageEvent event)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void messageDeleted(MessageEvent event)
/*      */   {
/* 1220 */     ForumMessage message = event.getMessage();
/* 1221 */     removeFromIndex(message);
/*      */   }
/*      */ 
/*      */   public void messageModified(MessageEvent event)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void messageModerationModified(MessageEvent event) {
/* 1229 */     ForumMessage message = event.getMessage();
/*      */ 
/* 1232 */     boolean isRootMessage = message.equals(message.getForumThread().getRootMessage());
/* 1233 */     if (isRootMessage) {
/* 1234 */       return;
/*      */     }
/*      */ 
/* 1238 */     int oldValue = ((Integer)event.getParams().get("oldModerationValue")).intValue();
/* 1239 */     int newValue = message.getModerationValue();
/*      */ 
/* 1242 */     if ((oldValue < 1) && (newValue >= 1))
/*      */     {
/* 1244 */       addToIndex(message);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void messageRated(MessageEvent event)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void messageMoved(MessageEvent event) {
/* 1253 */     ForumMessage message = event.getMessage();
/* 1254 */     removeFromIndex(message);
/* 1255 */     int modValue = message.getModerationValue();
/*      */ 
/* 1258 */     if (modValue >= 1) {
/* 1259 */       removeFromIndex(message);
/* 1260 */       addToIndex(message);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void threadAdded(ThreadEvent event)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void threadDeleted(ThreadEvent event)
/*      */   {
/* 1271 */     ForumThread thread = event.getThread();
/* 1272 */     removeFromIndex(thread);
/*      */   }
/*      */ 
/*      */   public void threadMoved(ThreadEvent event) {
/* 1276 */     ForumThread thread = event.getThread();
/* 1277 */     int threadModValue = thread.getModerationValue();
/* 1278 */     if (threadModValue < 1) {
/* 1279 */       return;
/*      */     }
/* 1281 */     removeFromIndex(thread);
/* 1282 */     for (Iterator iter = thread.getMessages(); iter.hasNext(); ) {
/* 1283 */       ForumMessage message = (ForumMessage)iter.next();
/* 1284 */       int modValue = message.getModerationValue();
/*      */ 
/* 1286 */       if (modValue >= 1)
/* 1287 */         addToIndex(message);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void threadModerationModified(ThreadEvent event)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void threadRated(ThreadEvent event)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void forumAdded(ForumEvent event)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void forumDeleted(ForumEvent event)
/*      */   {
/* 1308 */     Forum forum = event.getForum();
/* 1309 */     removeFromIndex(forum);
/*      */   }
/*      */ 
/*      */   public void forumMoved(ForumEvent event)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void forumMerged(ForumEvent event) {
/* 1317 */     Forum forum = event.getForum();
/* 1318 */     removeFromIndex(forum);
/*      */   }
/*      */ 
/*      */   private String filterHTML(String body)
/*      */   {
/* 1324 */     return new HtmlExtractor().getText(body);
/*      */   }
/*      */ 
/*      */   private static class DeletionType
/*      */   {
/* 1839 */     public static final DeletionType MESSAGE = new DeletionType("MESSAGE");
/* 1840 */     public static final DeletionType THREAD = new DeletionType("THREAD");
/* 1841 */     public static final DeletionType FORUM = new DeletionType("FORUM");
/*      */     private final String myName;
/*      */ 
/*      */     private DeletionType(String name)
/*      */     {
/* 1846 */       this.myName = name;
/*      */     }
/*      */ 
/*      */     public String toString() {
/* 1850 */       return this.myName;
/*      */     }
/*      */   }
/*      */ 
/*      */   private class RebuildTask
/*      */     implements Runnable
/*      */   {
/*      */     Date end;
/*      */ 
/*      */     public RebuildTask(Date end)
/*      */     {
/* 1690 */       this.end = end;
/* 1691 */       DbSearchManager.this.rebuildScheduled = true;
/*      */     }
/*      */ 
/*      */     public void run() {
/*      */       try {
/* 1696 */         if (!DbSearchManager.newIndexLock.attempt(10000L))
/*      */         {
/* 1699 */           DbSearchManager.this.rebuildScheduled = false;
/* 1700 */           return;
/*      */         }
/*      */       }
/*      */       catch (InterruptedException ie) {
/* 1704 */         DbSearchManager.this.rebuildScheduled = false;
/* 1705 */         return;
/*      */       }
/*      */ 
/* 1709 */       Log.info("Search indexer rebuild task started at " + new Date());
/*      */ 
/* 1712 */       Map params = Collections.EMPTY_MAP;
/* 1713 */       SearchIndexEvent event = new SearchIndexEvent(142, params);
/* 1714 */       SearchIndexEventDispatcher.getInstance().dispatchEvent(event);
/*      */ 
/* 1716 */       Directory newDirectory = null;
/* 1717 */       String newDirName = null;
/* 1718 */       Connection con = null;
/* 1719 */       PreparedStatement pstmt = null;
/* 1720 */       IndexWriter writer = null;
/*      */       try
/*      */       {
/*      */         while (true)
/*      */         {
/* 1725 */           newDirName = StringUtils.randomString(8);
/* 1726 */           File searchDir = new File(DbSearchManager.mainDir, newDirName);
/* 1727 */           if (!searchDir.exists()) {
/* 1728 */             searchDir.mkdir();
/*      */             try {
/* 1730 */               newDirectory = FSDirectory.getDirectory(searchDir, false);
/*      */             }
/*      */             catch (IOException ioe) {
/* 1733 */               Log.error(ioe);
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1739 */         writer = new IndexWriter(newDirectory, DbSearchManager.indexerAnalyzer, true);
/* 1740 */         con = ConnectionManager.getConnection();
/*      */ 
/* 1742 */         pstmt = con.prepareStatement("SELECT count(*) FROM jiveMessage, jiveForum WHERE jiveForum.forumID=jiveMessage.forumID AND jiveMessage.modValue >= 1 AND jiveMessage.modificationDate < ?");
/* 1743 */         pstmt.setLong(1, this.end.getTime());
/* 1744 */         ResultSet rs = pstmt.executeQuery();
/* 1745 */         rs.next();
/*      */ 
/* 1748 */         DbSearchManager.this.totalCount = rs.getInt(1);
/* 1749 */         rs.close();
/* 1750 */         pstmt.close();
/*      */ 
/* 1758 */         pstmt = con.prepareStatement("SELECT MAX(messageID) FROM jiveMessage");
/* 1759 */         rs = pstmt.executeQuery();
/* 1760 */         rs.next();
/* 1761 */         long maxID = rs.getLong(1);
/* 1762 */         long sentinal = maxID / 500L;
/* 1763 */         rs.close();
/* 1764 */         pstmt.close();
/*      */ 
/* 1768 */         pstmt = con.prepareStatement("SELECT jiveMessage.messageID, jiveMessage.userID, jiveMessage.threadID, jiveMessage.forumID, subject, body, jiveMessage.creationDate, jiveMessage.modificationDate FROM jiveMessage, jiveForum WHERE jiveForum.forumID=jiveMessage.forumID AND messageID >= ? AND messageID < ? AND jiveMessage.modificationDate < ? AND jiveMessage.modValue >= 1");
/* 1769 */         for (int i = 0; i <= sentinal; i++) {
/* 1770 */           pstmt.setLong(1, 500 * i);
/* 1771 */           pstmt.setLong(2, 500 * (i + 1));
/* 1772 */           pstmt.setLong(3, this.end.getTime());
/* 1773 */           rs = pstmt.executeQuery();
/* 1774 */           while (rs.next())
/*      */           {
/* 1776 */             DbSearchManager.access$908(DbSearchManager.this);
/* 1777 */             long messageID = rs.getLong(1);
/*      */             try {
/* 1779 */               long userID = rs.getLong(2);
/*      */ 
/* 1781 */               if (rs.wasNull()) {
/* 1782 */                 userID = -1L;
/*      */               }
/* 1784 */               long threadID = rs.getLong(3);
/* 1785 */               long forumID = rs.getLong(4);
/* 1786 */               String subject = rs.getString(5);
/* 1787 */               String body = ConnectionManager.getLargeTextField(rs, 6);
/* 1788 */               Date creationDate = new Date(Long.parseLong(rs.getString(7).trim()));
/* 1789 */               Date modificationDate = new Date(Long.parseLong(rs.getString(8).trim()));
/* 1790 */               DbSearchManager.this.addMessageToIndex(messageID, userID, threadID, forumID, subject, body, creationDate, modificationDate, writer);
/*      */             }
/*      */             catch (Exception e)
/*      */             {
/* 1795 */               Log.warn("There was a problem loading message " + messageID + " when rebuilding " + "the search indexes. The message was skipped.", e);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/* 1800 */           rs.close();
/*      */         }
/* 1802 */         writer.optimize();
/*      */ 
/* 1804 */         DbSearchManager.access$1302(newDirectory);
/*      */ 
/* 1806 */         DbSearchManager.access$700();
/*      */ 
/* 1808 */         DbSearchManager.properties.setProperty("search.directory", newDirName);
/*      */ 
/* 1810 */         DbSearchManager.this.lastIndexed = this.end;
/*      */ 
/* 1812 */         DbSearchManager.properties.setProperty("search.lastIndexed", "" + this.end.getTime());
/*      */       }
/*      */       catch (Exception e) {
/* 1815 */         Log.error(e);
/*      */       }
/*      */       finally {
/* 1818 */         ConnectionManager.closeConnection(pstmt, con);
/*      */         try { if (writer != null) writer.close();  } catch (Exception e) {
/* 1820 */           Log.error(e);
/*      */         }
/* 1822 */         DbSearchManager.this.currentCount = 0;
/* 1823 */         DbSearchManager.this.totalCount = -1;
/*      */ 
/* 1825 */         DbSearchManager.newIndexLock.release();
/* 1826 */         DbSearchManager.this.rebuildScheduled = false;
/*      */       }
/*      */ 
/* 1830 */       Log.info("Search indexer rebuild task completed at " + new Date());
/*      */ 
/* 1833 */       event = new SearchIndexEvent(143, params);
/* 1834 */       SearchIndexEventDispatcher.getInstance().dispatchEvent(event);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class UpdateTask
/*      */     implements Runnable
/*      */   {
/*      */     Date start;
/*      */     Date end;
/*      */ 
/*      */     public UpdateTask(Date start, Date end)
/*      */     {
/* 1552 */       this.start = start;
/* 1553 */       this.end = end;
/*      */     }
/*      */ 
/*      */     public void run() {
/*      */       try {
/* 1558 */         if (!DbSearchManager.indexLock.attempt(10000L))
/*      */         {
/* 1561 */           return;
/*      */         }
/*      */       }
/*      */       catch (InterruptedException ie) {
/* 1565 */         return;
/*      */       }
/*      */ 
/* 1569 */       Map params = Collections.EMPTY_MAP;
/* 1570 */       SearchIndexEvent event = new SearchIndexEvent(144, params);
/* 1571 */       SearchIndexEventDispatcher.getInstance().dispatchEvent(event);
/*      */ 
/* 1573 */       Connection con = null;
/* 1574 */       PreparedStatement pstmt = null;
/* 1575 */       IndexWriter writer = null;
/* 1576 */       LongList messages = new LongList();
/*      */       try
/*      */       {
/* 1579 */         con = ConnectionManager.getConnection();
/*      */ 
/* 1586 */         pstmt = con.prepareStatement("SELECT jiveMessage.messageID FROM jiveMessage, jiveForum WHERE jiveForum.forumID=jiveMessage.forumID AND jiveMessage.modificationDate > ? AND jiveMessage.modificationDate < ?");
/* 1587 */         pstmt.setLong(1, this.start.getTime());
/* 1588 */         pstmt.setLong(2, this.end.getTime());
/* 1589 */         ResultSet rs = pstmt.executeQuery();
/* 1590 */         while (rs.next()) {
/* 1591 */           messages.add(rs.getLong(1));
/*      */         }
/* 1593 */         rs.close();
/* 1594 */         pstmt.close();
/*      */ 
/* 1596 */         IndexReader reader = null;
/*      */         try {
/* 1598 */           reader = DbSearchManager.getReader();
/* 1599 */           if (reader != null)
/* 1600 */             DbSearchManager.this.deleteMessagesFromIndex(messages.toArray(), reader);
/*      */         }
/*      */         finally
/*      */         {
/*      */           try
/*      */           {
/* 1606 */             if (reader != null) reader.close(); 
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/*      */           }
/*      */         }
/* 1611 */         pstmt = con.prepareStatement("SELECT count(*) FROM jiveMessage, jiveForum WHERE jiveForum.forumID=jiveMessage.forumID AND jiveMessage.modValue >= 1 AND jiveMessage.modificationDate > ? AND jiveMessage.modificationDate < ?");
/* 1612 */         pstmt.setLong(1, this.start.getTime());
/* 1613 */         pstmt.setLong(2, this.end.getTime());
/* 1614 */         rs = pstmt.executeQuery();
/* 1615 */         if (!rs.next())
/*      */         {
/*      */           return;
/*      */         }
/*      */ 
/* 1620 */         DbSearchManager.this.totalCount = rs.getInt(1);
/* 1621 */         rs.close();
/* 1622 */         pstmt.close();
/*      */ 
/* 1625 */         writer = DbSearchManager.access$500();
/* 1626 */         pstmt = con.prepareStatement("SELECT jiveMessage.messageID, jiveMessage.userID, jiveMessage.threadID, jiveMessage.forumID, subject, body, jiveMessage.creationDate, jiveMessage.modificationDate  FROM jiveMessage, jiveForum WHERE jiveForum.forumID=jiveMessage.forumID AND jiveMessage.modValue >= 1 AND jiveMessage.modificationDate > ? AND jiveMessage.modificationDate < ?");
/* 1627 */         pstmt.setLong(1, this.start.getTime());
/* 1628 */         pstmt.setLong(2, this.end.getTime());
/* 1629 */         rs = pstmt.executeQuery();
/* 1630 */         while (rs.next())
/*      */         {
/* 1632 */           DbSearchManager.access$908(DbSearchManager.this);
/* 1633 */           long messageID = rs.getLong(1);
/*      */           try {
/* 1635 */             long userID = rs.getLong(2);
/*      */ 
/* 1637 */             if (rs.wasNull()) {
/* 1638 */               userID = -1L;
/*      */             }
/* 1640 */             long threadID = rs.getLong(3);
/* 1641 */             long forumID = rs.getLong(4);
/* 1642 */             String subject = rs.getString(5);
/* 1643 */             String body = ConnectionManager.getLargeTextField(rs, 6);
/* 1644 */             Date creationDate = new Date(Long.parseLong(rs.getString(7).trim()));
/* 1645 */             Date modificationDate = new Date(Long.parseLong(rs.getString(8).trim()));
/* 1646 */             DbSearchManager.this.addMessageToIndex(messageID, userID, threadID, forumID, subject, body, creationDate, modificationDate, writer);
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/* 1651 */             Log.warn("There was a problem loading message " + messageID + " when updating " + "the search indexes. The message was skipped.", e);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1657 */         rs.close();
/*      */ 
/* 1660 */         DbSearchManager.access$700();
/*      */ 
/* 1662 */         DbSearchManager.this.lastIndexed = this.end;
/*      */ 
/* 1664 */         DbSearchManager.properties.setProperty("search.lastIndexed", "" + this.end.getTime());
/*      */       }
/*      */       catch (Exception e) {
/* 1667 */         Log.error(e);
/*      */       }
/*      */       finally {
/* 1670 */         ConnectionManager.closeConnection(pstmt, con);
/*      */         try { if (writer != null) writer.close();  } catch (Exception e) {
/* 1672 */           Log.error(e);
/*      */         }
/* 1674 */         DbSearchManager.this.currentCount = 0;
/* 1675 */         DbSearchManager.this.totalCount = -1;
/*      */ 
/* 1677 */         DbSearchManager.indexLock.release();
/*      */       }
/*      */ 
/* 1681 */       event = new SearchIndexEvent(145, params);
/* 1682 */       SearchIndexEventDispatcher.getInstance().dispatchEvent(event);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class RemoveTask
/*      */     implements Runnable
/*      */   {
/*      */     long id;
/*      */     DbSearchManager.DeletionType type;
/*      */ 
/*      */     public RemoveTask(long id, DbSearchManager.DeletionType type)
/*      */     {
/* 1470 */       this.id = id;
/* 1471 */       this.type = type;
/*      */     }
/*      */ 
/*      */     public void run() {
/* 1475 */       if (!DbSearchManager.this.searchEnabled) {
/* 1476 */         return;
/*      */       }
/*      */       try
/*      */       {
/* 1480 */         if (!DbSearchManager.indexLock.attempt(10000L))
/*      */         {
/* 1483 */           return;
/*      */         }
/*      */       }
/*      */       catch (InterruptedException ie) {
/* 1487 */         return;
/*      */       }
/*      */ 
/* 1490 */       IndexReader reader = null;
/*      */       try
/*      */       {
/* 1493 */         reader = DbSearchManager.getReader();
/* 1494 */         if (this.type.equals(DbSearchManager.DeletionType.MESSAGE)) {
/* 1495 */           if (reader != null) {
/* 1496 */             long[] toDelete = { this.id };
/*      */ 
/* 1498 */             for (int i = 0; i < toDelete.length; i++) {
/* 1499 */               Term term = new Term("messageID", Long.toString(toDelete[i]));
/* 1500 */               reader.delete(term);
/*      */             }
/*      */ 
/* 1504 */             Map params = new HashMap();
/* 1505 */             params.put("messageID", new Long(this.id));
/* 1506 */             SearchIndexEvent event = new SearchIndexEvent(141, params);
/* 1507 */             SearchIndexEventDispatcher.getInstance().dispatchEvent(event);
/*      */           }
/*      */           else {
/* 1510 */             Log.error("Unable to delete message " + this.id + " from search index: reader was null!");
/*      */           }
/*      */         }
/* 1513 */         else if (this.type.equals(DbSearchManager.DeletionType.THREAD)) {
/* 1514 */           if (reader != null) {
/* 1515 */             Term term = new Term("threadID", Long.toString(this.id));
/* 1516 */             reader.delete(term);
/*      */           }
/*      */           else {
/* 1519 */             Log.error("Unable to delete thread " + this.id + " from search index: reader was null!");
/*      */           }
/*      */         }
/* 1522 */         else if (this.type.equals(DbSearchManager.DeletionType.FORUM)) {
/* 1523 */           if (reader != null) {
/* 1524 */             Term term = new Term("forumID", Long.toString(this.id));
/* 1525 */             reader.delete(term);
/*      */           }
/*      */           else {
/* 1528 */             Log.error("Unable to delete forum " + this.id + " from search index: reader was null!");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1533 */         DbSearchManager.access$700();
/*      */       }
/*      */       catch (IOException ioe) {
/* 1536 */         Log.error(ioe);
/*      */       } finally {
/*      */         try {
/* 1539 */           if (reader != null) reader.close(); 
/*      */         }
/*      */         catch (Exception e) {  }
/*      */ 
/* 1542 */         DbSearchManager.indexLock.release();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class AddTask
/*      */     implements Runnable
/*      */   {
/*      */     ForumMessage message;
/*      */ 
/*      */     public AddTask(ForumMessage message)
/*      */     {
/* 1403 */       this.message = message;
/*      */     }
/*      */ 
/*      */     public void run() {
/* 1407 */       if (!DbSearchManager.this.searchEnabled) {
/* 1408 */         return;
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/* 1413 */         if (!DbSearchManager.indexLock.attempt(10000L))
/*      */         {
/* 1416 */           return;
/*      */         }
/*      */       }
/*      */       catch (InterruptedException ie) {
/* 1420 */         return;
/*      */       }
/*      */ 
/* 1423 */       IndexWriter writer = null;
/*      */       try
/*      */       {
/* 1426 */         writer = DbSearchManager.access$500();
/* 1427 */         if (writer == null)
/*      */         {
/*      */           return;
/*      */         }
/* 1431 */         long messageID = this.message.getID();
/* 1432 */         long userID = -1L;
/* 1433 */         if (!this.message.isAnonymous()) {
/* 1434 */           User user = this.message.getUser();
/* 1435 */           if (user != null) {
/* 1436 */             userID = user.getID();
/*      */           }
/*      */         }
/* 1439 */         long threadID = this.message.getForumThread().getID();
/* 1440 */         long forumID = this.message.getForumThread().getForum().getID();
/* 1441 */         String subject = this.message.getUnfilteredSubject();
/* 1442 */         String body = this.message.getUnfilteredBody();
/*      */ 
/* 1444 */         DbSearchManager.this.addMessageToIndex(messageID, userID, threadID, forumID, subject, body, this.message.getCreationDate(), this.message.getModificationDate(), writer);
/*      */       }
/*      */       catch (IOException ioe)
/*      */       {
/* 1449 */         Log.error(ioe);
/*      */       } finally {
/*      */         try {
/* 1452 */           if (writer != null) writer.close(); 
/*      */         } catch (Exception e) { Log.error(e); }
/*      */ 
/* 1455 */         DbSearchManager.indexLock.release();
/*      */       }
/*      */ 
/* 1458 */       Map params = new HashMap();
/* 1459 */       params.put("messageID", new Long(this.message.getID()));
/* 1460 */       SearchIndexEvent event = new SearchIndexEvent(140, params);
/* 1461 */       SearchIndexEventDispatcher.getInstance().dispatchEvent(event);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class OptimizeTask
/*      */     implements Runnable
/*      */   {
/*      */     private OptimizeTask()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       try
/*      */       {
/* 1357 */         if (!DbSearchManager.indexLock.attempt(10000L))
/*      */         {
/* 1360 */           return;
/*      */         }
/*      */       }
/*      */       catch (InterruptedException ie) {
/* 1364 */         return;
/*      */       }
/*      */ 
/* 1367 */       Log.debug("Starting optimization of search index");
/*      */ 
/* 1370 */       Map params = Collections.EMPTY_MAP;
/* 1371 */       SearchIndexEvent event = new SearchIndexEvent(146, params);
/* 1372 */       SearchIndexEventDispatcher.getInstance().dispatchEvent(event);
/*      */ 
/* 1374 */       IndexWriter writer = null;
/*      */       try {
/* 1376 */         writer = DbSearchManager.access$500();
/* 1377 */         if (writer != null)
/* 1378 */           writer.optimize();
/*      */       }
/*      */       catch (IOException ioe)
/*      */       {
/* 1382 */         Log.error(ioe);
/*      */       } finally {
/*      */         try {
/* 1385 */           if (writer != null) writer.close(); 
/*      */         } catch (Exception e) { Log.error(e); }
/*      */ 
/* 1388 */         DbSearchManager.indexLock.release();
/*      */       }
/*      */ 
/* 1391 */       Log.debug("Ending optimization of search index");
/*      */ 
/* 1394 */       event = new SearchIndexEvent(147, params);
/* 1395 */       SearchIndexEventDispatcher.getInstance().dispatchEvent(event);
/*      */     }
/*      */ 
/*      */     OptimizeTask(DbSearchManager.1 x1)
/*      */     {
/* 1352 */       this();
/*      */     }
/*      */   }
/*      */ 
/*      */   private class IndexTask
/*      */     implements Runnable
/*      */   {
/*      */     private boolean rebuildOperation;
/*      */ 
/*      */     public IndexTask(boolean rebuildOperation)
/*      */     {
/* 1334 */       this.rebuildOperation = rebuildOperation;
/*      */ 
/* 1336 */       if (DbSearchManager.this.lastIndexed.getTime() == 0L)
/* 1337 */         this.rebuildOperation = true;
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/* 1342 */       Date now = new Date();
/* 1343 */       if ((this.rebuildOperation) && (!DbSearchManager.this.rebuildScheduled)) {
/* 1344 */         DbSearchManager.this.rebuildIndex(now);
/*      */       }
/*      */       else
/* 1347 */         DbSearchManager.this.updateIndex(DbSearchManager.this.lastIndexed, now);
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbSearchManager
 * JD-Core Version:    0.6.2
 */
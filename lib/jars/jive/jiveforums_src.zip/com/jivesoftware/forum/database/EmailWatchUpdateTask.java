/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.AuthFactory;
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.base.log.JiveLogImpl;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.util.EmailTask;
/*     */ import com.jivesoftware.util.JiveVelocityResourceLoader;
/*     */ import com.jivesoftware.util.LocaleUtils;
/*     */ import com.jivesoftware.util.StringUtils;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import javax.mail.Address;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.Part;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ import org.apache.velocity.tools.generic.DateTool;
/*     */ 
          /**
           * Change notes 1.1 (Module Assembly - TC Forums Reply To Email Feature version 1.0):
           * <ol>
           *   <li>Sets the reply-to filed when sending the emails.</li>
           * </ol>
           *
           * @version 1.1
           */
/*     */ public class EmailWatchUpdateTask
/*     */   implements Runnable
/*     */ {
/*     */   private String objectType;
/*     */   private ForumMessage message;
/*     */   private long[] users;
/*     */   public static final String DEFAULT_THREAD_SUBJECT = "Thread \"$threadName\" has been updated by $messageUser";
/*     */   public static final String DEFAULT_FORUM_SUBJECT = "Forum \"$forumName\" has been updated by $messageUser";
/*     */   public static final String DEFAULT_CATEGORY_SUBJECT = "Category \"$categoryName\" has been updated by $messageUser";
/*     */   public static final String DEFAULT_USER_SUBJECT = "User \"$user-username\" has posted a new message";
/*     */   public static final String DEFAULT_THREAD_BODY = "$name,\n\nYou are watching the thread \"$threadName\", which was updated $messageCreationDate by $messageUser.\nTo view the thread, visit:\n$jiveURL/thread.jspa?forumID=$forumID&threadID=$threadID";
/*     */   public static final String DEFAULT_FORUM_BODY = "$name,\n\nYou are watching the forum \"$forumName\", which was updated $messageCreationDate by $messageUser.\n\nTo view the forum, visit:\n$jiveURL/forum.jspa?forumID=$forumID.\n\nTo view the thread, visit:\n$jiveURL/thread.jspa?forumID=$forumID&threadID=$threadID";
/*     */   public static final String DEFAULT_CATEGORY_BODY = "$name,\n\nYou are watching the category \"$categoryName\", which was updated $messageCreationDate by $messageUser.\n\nTo view the category visit:\n$jiveURL/index.jspa?categoryID=$categoryID.\n\nTo view the thread, visit:\n$jiveURL/thread.jspa?forumID=$forumID&threadID=$threadID.";
/*     */   public static final String DEFAULT_USER_BODY = "$name,\n\nYou are watching the user \"$user-username\", who just posted a message at $messageCreationDate.\n\nTo view the message, visit:\n$jiveURL/thread.jspa?threadID=$threadID&messageID=$messageID#$messageID\n\nTo view the user's profile, see:\n$jiveURL/profile.jspa?userID=$user-ID";
/*     */ 
/*     */   public EmailWatchUpdateTask(int objectType, ForumMessage message, long[] users)
/*     */   {
/*  78 */     if (objectType == 1) {
/*  79 */       this.objectType = "thread";
/*     */     }
/*  81 */     else if (objectType == 0) {
/*  82 */       this.objectType = "forum";
/*     */     }
/*  84 */     else if (objectType == 14) {
/*  85 */       this.objectType = "forumCategory";
/*     */     }
/*  87 */     else if (objectType == 3) {
/*  88 */       this.objectType = "user";
/*     */     }
/*  90 */     this.message = message;
/*  91 */     this.users = users;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  99 */     if (this.users.length > 0)
/*     */     {
/* 101 */       EmailTask emailTask = new EmailTask();
                String replyToEmailSuffix = JiveGlobals.getJiveProperty("watches.replyToEmailSuffix");
/*     */ 
/* 103 */       for (int i = 0; i < this.users.length; i++) {
/*     */         try {
/* 105 */           DbForumFactory factory = DbForumFactory.getInstance();
/* 106 */           User user = factory.userManager.getUser(this.users[i]);
/*     */ 
/* 110 */           if ((this.message.isAnonymous()) || (user.getID() != this.message.getUser().getID()) || (JiveGlobals.getJiveBooleanProperty("watches.allowSelfUpdates")))
/*     */           {
/* 113 */             String toName = user.getName();
/* 114 */             String toEmail = user.getEmail();
/* 115 */             String fromEmail = getFromEmail();
/* 116 */             String fromName = getFromName();
/* 117 */             String subject = getSubject(user);
/* 118 */             String body = getBody(user);
                      String replyToEmail = createForumReplyToIdentifier(user.getID(), this.message.getID()) + replyToEmailSuffix;
/* 119 */             addMessage(emailTask, toName, toEmail, fromName, fromEmail, replyToEmail, subject, body, null);
/*     */           }
/*     */         }
/*     */         catch (UserNotFoundException e)
/*     */         {
/*     */         }
                  catch (SQLException e)
                  {
                      Log.error(e);
                  }
/*     */       }
/* 126 */       emailTask.run();
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getFromEmail()
/*     */   {
/* 136 */     if (JiveGlobals.getJiveProperty("watches.email." + this.objectType + ".fromEmail") != null) {
/* 137 */       return JiveGlobals.getJiveProperty("watches.email." + this.objectType + ".fromEmail");
/*     */     }
/* 139 */     if (JiveGlobals.getJiveProperty("watches.email.fromEmail") != null) {
/* 140 */       return JiveGlobals.getJiveProperty("watches.email.fromEmail");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 145 */       AuthToken anonAuthToken = AuthFactory.getAnonymousAuthToken();
/* 146 */       User user = ForumFactory.getInstance(anonAuthToken).getUserManager().getUser("admin");
/* 147 */       if (user.getEmail() != null)
/* 148 */         return user.getEmail();
/*     */     }
/*     */     catch (UserNotFoundException e)
/*     */     {
/* 152 */       Log.error(e);
/*     */     }
/*     */ 
/* 156 */     return null;
/*     */   }
/*     */ 
/*     */   private String getFromName()
/*     */   {
/* 165 */     if (JiveGlobals.getJiveProperty("watches.email." + this.objectType + ".fromName") != null) {
/* 166 */       return JiveGlobals.getJiveProperty("watches.email." + this.objectType + ".fromName");
/*     */     }
/* 168 */     if (JiveGlobals.getJiveProperty("watches.email.fromName") != null) {
/* 169 */       return JiveGlobals.getJiveProperty("watches.email.fromName");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 174 */       AuthToken anonAuthToken = AuthFactory.getAnonymousAuthToken();
/* 175 */       User user = ForumFactory.getInstance(anonAuthToken).getUserManager().getUser("admin");
/* 176 */       if (user.getName() != null)
/* 177 */         return user.getName();
/*     */     }
/*     */     catch (UserNotFoundException e)
/*     */     {
/* 181 */       Log.error(e);
/*     */     }
/*     */ 
/* 185 */     return "Jive Adminstrator";
/*     */   }
/*     */ 
/*     */   private String getSubject(User user) {
/* 189 */     String subject = JiveGlobals.getJiveProperty("watches.email." + this.objectType + ".subject");
/*     */ 
/* 191 */     if (subject == null) {
/* 192 */       if ("thread".equals(this.objectType)) {
/* 193 */         subject = "Thread \"$threadName\" has been updated by $messageUser";
/*     */       }
/* 195 */       else if ("forum".equals(this.objectType)) {
/* 196 */         subject = "Forum \"$forumName\" has been updated by $messageUser";
/*     */       }
/* 198 */       else if ("forumCategory".equals(this.objectType)) {
/* 199 */         subject = "Category \"$categoryName\" has been updated by $messageUser";
/*     */       }
/* 201 */       else if ("user".equals(this.objectType)) {
/* 202 */         subject = "User \"$user-username\" has posted a new message";
/*     */       }
/*     */     }
/*     */ 
/* 206 */     return replaceTokens(subject, user);
/*     */   }
/*     */ 
/*     */   private String getBody(User user) {
/* 210 */     String body = JiveGlobals.getJiveProperty("watches.email." + this.objectType + ".body");
/*     */ 
/* 212 */     if (body == null) {
/* 213 */       if ("thread".equals(this.objectType)) {
/* 214 */         body = "$name,\n\nYou are watching the thread \"$threadName\", which was updated $messageCreationDate by $messageUser.\nTo view the thread, visit:\n$jiveURL/thread.jspa?forumID=$forumID&threadID=$threadID";
/*     */       }
/* 216 */       else if ("forum".equals(this.objectType)) {
/* 217 */         body = "$name,\n\nYou are watching the forum \"$forumName\", which was updated $messageCreationDate by $messageUser.\n\nTo view the forum, visit:\n$jiveURL/forum.jspa?forumID=$forumID.\n\nTo view the thread, visit:\n$jiveURL/thread.jspa?forumID=$forumID&threadID=$threadID";
/*     */       }
/* 219 */       else if ("forumCategory".equals(this.objectType)) {
/* 220 */         body = "$name,\n\nYou are watching the category \"$categoryName\", which was updated $messageCreationDate by $messageUser.\n\nTo view the category visit:\n$jiveURL/index.jspa?categoryID=$categoryID.\n\nTo view the thread, visit:\n$jiveURL/thread.jspa?forumID=$forumID&threadID=$threadID.";
/*     */       }
/* 222 */       else if ("user".equals(this.objectType)) {
/* 223 */         body = "$name,\n\nYou are watching the user \"$user-username\", who just posted a message at $messageCreationDate.\n\nTo view the message, visit:\n$jiveURL/thread.jspa?threadID=$threadID&messageID=$messageID#$messageID\n\nTo view the user's profile, see:\n$jiveURL/profile.jspa?userID=$user-ID";
/*     */       }
/*     */     }
/*     */ 
/* 227 */     return replaceTokens(body, user);
/*     */   }
/*     */ 
/*     */   private String replaceTokens(String string, User user)
/*     */   {
/* 238 */     Map context = new HashMap();
/*     */ 
/* 241 */     String messageUser = LocaleUtils.getLocalizedString("global.guest", LocaleUtils.getUserLocale(null, user));
/*     */ 
/* 243 */     if (!this.message.isAnonymous()) {
/* 244 */       if (this.message.getUser().getName() != null) {
/* 245 */         messageUser = this.message.getUser().getName();
/*     */ 
/* 247 */         if (!this.message.getUser().isNameVisible())
/* 248 */           messageUser = this.message.getUser().getUsername();
/*     */       }
/*     */       else
/*     */       {
/* 252 */         messageUser = this.message.getUser().getUsername();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 257 */     context.put("message", this.message);
/* 258 */     context.put("messageUser", messageUser);
/* 259 */     context.put("messageID", Long.toString(this.message.getID()));
/* 260 */     context.put("messageSubject", this.message.getUnfilteredSubject());
/* 261 */     context.put("messageBody", this.message.getUnfilteredBody());
/* 262 */     context.put("messageModificatonDate", JiveGlobals.formatDateTime(this.message.getModificationDate()));
/* 263 */     context.put("messageCreationDate", JiveGlobals.formatDateTime(this.message.getCreationDate()));
/*     */ 
/* 266 */     ForumThread thread = this.message.getForumThread();
/* 267 */     context.put("thread", thread);
/* 268 */     context.put("threadID", Long.toString(thread.getID()));
/* 269 */     context.put("threadName", thread.getRootMessage().getUnfilteredSubject());
/* 270 */     context.put("threadModificatonDate", JiveGlobals.formatDateTime(thread.getModificationDate()));
/* 271 */     context.put("threadCreationDate", JiveGlobals.formatDateTime(thread.getCreationDate()));
/*     */ 
/* 274 */     context.put("user", user);
/* 275 */     context.put("username", user.getUsername());
/* 276 */     context.put("email", user.getEmail());
/* 277 */     context.put("name", user.getName() == null ? user.getUsername() : user.getName());
/* 278 */     context.put("userID", Long.toString(user.getID()));
/*     */ 
/* 282 */     Forum forum = thread.getForum();
/* 283 */     context.put("forum", forum);
/* 284 */     context.put("forumID", Long.toString(forum.getID()));
/* 285 */     context.put("forumName", forum.getName());
/*     */ 
/* 288 */     ForumCategory category = forum.getForumCategory();
/* 289 */     context.put("category", category);
/* 290 */     context.put("categoryID", Long.toString(category.getID()));
/* 291 */     context.put("categoryName", category.getName());
/*     */ 
/* 294 */     if (!this.message.isAnonymous()) {
/* 295 */       User wUser = this.message.getUser();
/* 296 */       context.put("watchedUser", wUser);
/* 297 */       context.put("user-ID", Long.toString(wUser.getID()));
/* 298 */       context.put("user-username", wUser.getUsername());
/* 299 */       context.put("user-name", wUser.getName() == null ? wUser.getUsername() : wUser.getName());
/* 300 */       context.put("user-email", !wUser.isEmailVisible() ? "xxxx@xxxxxx" : wUser.getEmail());
/*     */     }
/*     */ 
/* 305 */     context.put("jiveURL", JiveGlobals.getJiveProperty("jiveURL"));
/* 306 */     context.put("forumFactory", ForumFactory.getInstance(new DummyAuthToken(user.getID())));
/* 307 */     context.put("userTimeZone", LocaleUtils.getTimeZone(null, user));
/* 308 */     context.put("userLocale", LocaleUtils.getUserLocale(null, user));
/*     */ 
/* 310 */     context.put("dateTool", new DateTool());
/*     */     try
/*     */     {
/* 315 */       VelocityEngine ve = new VelocityEngine();
/* 316 */       ve.setProperty("resource.loader", "jive");
/* 317 */       ve.setProperty("jive.resource.loader.public.name", "Jive");
/* 318 */       ve.setProperty("jive.resource.loader.description", " Jive Velocity Resource Loader");
/* 319 */       ve.setProperty("jive.resource.loader.class", JiveVelocityResourceLoader.class.getName());
/* 320 */       ve.setProperty("velocimacro.library", "");
/* 321 */       ve.setProperty("runtime.log.logsystem.class", JiveLogImpl.class.getName());
/* 322 */       ve.init();
/*     */ 
/* 324 */       VelocityContext velContext = new VelocityContext(context);
/* 325 */       Writer sw = new StringWriter();
/* 326 */       ve.evaluate(velContext, sw, "emailWatch", string);
/* 327 */       return sw.toString();
/*     */     }
/*     */     catch (Exception e) {
/* 330 */       Log.error(e);
/* 331 */     }return null;
/*     */   }
/*     */ 
/*     */   private static class DummyAuthToken
/*     */     implements AuthToken, Serializable
/*     */   {
/*     */     private long userID;
/*     */ 
/*     */     public DummyAuthToken(long userID)
/*     */     {
/* 343 */       this.userID = userID;
/*     */     }
/*     */ 
/*     */     public long getUserID() {
/* 347 */       return this.userID;
/*     */     }
/*     */ 
/*     */     public boolean isAnonymous() {
/* 351 */       return false;
/*     */     }
/*     */   }

            /**
             * Adds the email message to email task.
             *
             * @param emailTask the email task
             * @param toName the user name to send to
             * @param toEmail the email address to send to
             * @param fromName the user name of the sender
             * @param fromEmail the email address of the sender
             * @param replyToEmail the reply-to email address
             * @param subject the email subject
             * @param textBody the email text body
             * @param htmlBody the email html body
             * @since 1.1
             */
            private void addMessage(EmailTask emailTask, String toName, String toEmail, String fromName,
                String fromEmail, String replyToEmail, String subject, String textBody, String htmlBody) {
                // Check for errors in the given fields:
                if (toEmail == null || fromEmail == null || subject == null ||
                        (textBody == null && htmlBody == null))
                {
                    Log.error("Error sending email: Invalid fields: "
                            + ((toEmail == null) ? "toEmail " : "")
                            + ((fromEmail == null) ? "fromEmail " : "")
                            + ((subject == null) ? "subject " : "")
                            + ((textBody == null && htmlBody == null) ? "textBody or htmlBody " : "")
                    );
                }
                else {
                    try {
                        String encoding = MimeUtility.mimeCharset("UTF-8");
                        MimeMessage message = emailTask.createMessage();
                        Address to;
                        Address from;

                        if (toName != null) {
                            to = new InternetAddress(toEmail, toName, encoding);
                        }
                        else {
                            to = new InternetAddress(toEmail, "", encoding);
                        }

                        if (fromName != null) {
                            from = new InternetAddress(fromEmail, fromName, encoding);
                        }
                        else {
                            from = new InternetAddress(fromEmail, "", encoding);
                        }

                        // Set the date of the message to be the current date
                        SimpleDateFormat format = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z",
                                java.util.Locale.US);
                        format.setTimeZone(JiveGlobals.getTimeZone());
                        message.setHeader("Date", format.format(new Date()));
                        message.setHeader("Content-Transfer-Encoding", "8bit");
                        message.setRecipient(Message.RecipientType.TO, to);
                        message.setFrom(from);
                        Address replyTo = new InternetAddress(replyToEmail, fromName != null ? fromName : "", encoding);
                        message.setReplyTo(new Address[] { replyTo });
                        message.setSubject(StringUtils.replace(subject, "\n", ""), encoding);
                        // Create HTML, plain-text, or combination message
                        if (textBody != null && htmlBody != null) {
                            MimeMultipart content = new MimeMultipart("alternative");
                            // Plain-text
                            MimeBodyPart text = new MimeBodyPart();
                            text.setText(textBody, encoding);
                            text.setDisposition(Part.INLINE);
                            content.addBodyPart(text);
                            // HTML
                            MimeBodyPart html = new MimeBodyPart();
                            html.setContent(htmlBody, "text/html; charset=UTF-8");
                            html.setDisposition(Part.INLINE);
                            html.setHeader("Content-Transfer-Encoding", "8bit");
                            content.addBodyPart(html);
                            // Add multipart to message.
                            message.setContent(content);
                            message.setDisposition(Part.INLINE);
                            emailTask.addMessage(message);
                        }
                        else if (textBody != null) {
                            MimeBodyPart bPart = new MimeBodyPart();
                            bPart.setText(textBody, encoding);
                            bPart.setDisposition(Part.INLINE);
                            bPart.setHeader("Content-Transfer-Encoding", "8bit");
                            MimeMultipart mPart = new MimeMultipart();
                            mPart.addBodyPart(bPart);
                            message.setContent(mPart);
                            message.setDisposition(Part.INLINE);
                            // Add the message to the send list
                            emailTask.addMessage(message);
                        }
                        else if (htmlBody != null) {
                            MimeBodyPart bPart = new MimeBodyPart();
                            bPart.setContent(htmlBody, "text/html; charset=UTF-8");
                            bPart.setDisposition(Part.INLINE);
                            bPart.setHeader("Content-Transfer-Encoding", "8bit");
                            MimeMultipart mPart = new MimeMultipart();
                            mPart.addBodyPart(bPart);
                            message.setContent(mPart);
                            message.setDisposition(Part.INLINE);
                            // Add the message to the send list
                            emailTask.addMessage(message);
                        }
                    }
                    catch (Exception e) {
                        Log.error(e);
                    }
                }
            }
            
            /**
             * Creates the reply-to identifier for the user id and message id.
             *
             * @param userId the user id
             * @param messageId the message id
             * @return the reply-to identifier
             * @throws SQLException if any error occurs
             * @since 1.1
             */
            private String createForumReplyToIdentifier(long userId, long messageId) throws SQLException {
                Connection connection = null;
                PreparedStatement ps = null;
                try {
                    connection = ConnectionManager.getConnection();
                    ps = connection.prepareStatement("INSERT INTO jive_reply_to_identifiers (reply_to_identifier, user_id, message_id) VALUES (?, ?, ?)");
                    String replyToIdentifier = UUID.randomUUID().toString();
                    ps.setString(1, replyToIdentifier);
                    ps.setLong(2, userId);
                    ps.setLong(3, messageId);
                    ps.executeUpdate();
                    return replyToIdentifier;
                } finally {
                    ConnectionManager.closeConnection(ps, connection);
                }
            }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.EmailWatchUpdateTask
 * JD-Core Version:    0.6.2
 */

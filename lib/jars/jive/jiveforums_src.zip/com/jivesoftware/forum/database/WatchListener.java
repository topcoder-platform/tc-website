/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.event.UserEvent;
/*     */ import com.jivesoftware.base.event.UserListener;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.event.CategoryEvent;
/*     */ import com.jivesoftware.forum.event.CategoryListener;
/*     */ import com.jivesoftware.forum.event.ForumEvent;
/*     */ import com.jivesoftware.forum.event.ForumListener;
/*     */ import com.jivesoftware.forum.event.MessageEvent;
/*     */ import com.jivesoftware.forum.event.MessageListener;
/*     */ import com.jivesoftware.forum.event.ThreadEvent;
/*     */ import com.jivesoftware.forum.event.ThreadListener;
/*     */ import com.jivesoftware.util.profile.Profiler;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class WatchListener
/*     */   implements CategoryListener, ForumListener, ThreadListener, MessageListener, UserListener
/*     */ {
/*     */   private DbWatchManager manager;
/*     */ 
/*     */   public WatchListener(DbWatchManager manager)
/*     */   {
/*  34 */     this.manager = manager;
/*     */   }
/*     */ 
/*     */   public void categoryAdded(CategoryEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void categoryDeleted(CategoryEvent event)
/*     */   {
/*  45 */     this.manager.deleteWatches(14, event.getCategory().getID());
/*     */   }
/*     */ 
/*     */   public void categoryMoved(CategoryEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void forumAdded(ForumEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void forumDeleted(ForumEvent event)
/*     */   {
/*  60 */     this.manager.deleteWatches(0, event.getForum().getID());
/*     */ 
/*  62 */     this.manager.deleteThreadWatches(event.getForum().getID());
/*     */   }
/*     */ 
/*     */   public void forumMoved(ForumEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void forumMerged(ForumEvent event) {
/*  70 */     long newForumID = event.getForum().getID();
/*  71 */     long oldForumID = ((Long)event.getParams().get("mergedForumID")).longValue();
/*  72 */     this.manager.moveWatches(0, oldForumID, newForumID);
/*     */   }
/*     */ 
/*     */   public void threadAdded(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadDeleted(ThreadEvent event)
/*     */   {
/*  83 */     this.manager.deleteWatches(1, event.getThread().getID());
/*     */   }
/*     */ 
/*     */   public void threadMoved(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadModerationModified(ThreadEvent event) {
/*  91 */     ForumThread thread = event.getThread();
/*     */ 
/*  93 */     int oldValue = ((Integer)event.getParams().get("oldModerationValue")).intValue();
/*  94 */     int newValue = thread.getModerationValue();
/*     */ 
/*  97 */     if ((oldValue < 1) && (newValue >= 1))
/*  98 */       this.manager.notifyWatchUpdate(thread.getRootMessage());
/*     */   }
/*     */ 
/*     */   public void threadRated(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageAdded(MessageEvent event)
/*     */   {
/* 109 */     ForumMessage message = event.getMessage();
/*     */ 
/* 112 */     boolean isRootMessage = message.equals(message.getForumThread().getRootMessage());
/*     */     int modValue;
/*     */     int modValue;
/* 114 */     if (isRootMessage) {
/* 115 */       modValue = message.getForumThread().getModerationValue();
/*     */     }
/*     */     else {
/* 118 */       modValue = message.getModerationValue();
/*     */     }
/*     */ 
/* 122 */     if (modValue >= 1) {
/* 123 */       Profiler.begin("watch");
/* 124 */       this.manager.notifyWatchUpdate(message);
/* 125 */       Profiler.end("watch");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void messageDeleted(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageModified(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageMoved(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageModerationModified(MessageEvent event)
/*     */   {
/* 144 */     ForumMessage message = event.getMessage();
/*     */ 
/* 147 */     boolean isRootMessage = message.equals(message.getForumThread().getRootMessage());
/* 148 */     if (isRootMessage) {
/* 149 */       return;
/*     */     }
/*     */ 
/* 152 */     int oldValue = ((Integer)event.getParams().get("oldModerationValue")).intValue();
/* 153 */     int newValue = message.getModerationValue();
/*     */ 
/* 156 */     if ((oldValue < 1) && (newValue >= 1))
/*     */     {
/* 159 */       this.manager.notifyWatchUpdate(message);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void messageRated(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void userCreated(UserEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void userDeleted(UserEvent event) {
/* 172 */     User user = event.getUser();
/*     */ 
/* 174 */     this.manager.deleteWatches(user);
/*     */ 
/* 176 */     this.manager.deleteWatches(3, user.getID());
/*     */   }
/*     */ 
/*     */   public void userModified(UserEvent event)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.WatchListener
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.net;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.JiveManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.forum.net.policies.BasicAcceptPolicy;
/*     */ import com.jivesoftware.util.AlreadyExistsException;
/*     */ import com.jivesoftware.util.LocaleUtils;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class AcceptManager
/*     */   implements JiveManager
/*     */ {
/*  39 */   private LinkedList ports = new LinkedList();
/*     */ 
/*  41 */   private final AcceptPolicy policy = new BasicAcceptPolicy(true);
/*     */ 
/*  46 */   private ConnectionManager connManager = null;
/*     */   private String propNamePrefix;
/*  50 */   private boolean initialized = false;
/*     */ 
/*     */   public AcceptManager(ConnectionManager connMan, String portNamePrefix)
/*     */   {
/*  62 */     this.connManager = connMan;
/*  63 */     this.propNamePrefix = portNamePrefix;
/*  64 */     List portNames = JiveGlobals.getJivePropertyNames(this.propNamePrefix);
/*  65 */     Iterator portIter = portNames.iterator();
/*  66 */     while (portIter.hasNext()) {
/*  67 */       AcceptPort port = null;
/*     */       try {
/*  69 */         port = new AcceptPort(this.connManager, (String)portIter.next());
/*  70 */         this.ports.add(port);
/*     */       }
/*     */       catch (IOException e) {
/*  73 */         Log.error("Could not open port", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void initialize() {
/*  79 */     if (!this.initialized)
/*  80 */       this.initialized = true;
/*     */   }
/*     */ 
/*     */   public AcceptPolicy getGlobalAcceptPolicy()
/*     */   {
/*  90 */     if (this.policy == null) {
/*  91 */       throw new IllegalStateException("Must initialize and start module before use");
/*     */     }
/*     */ 
/*  94 */     return this.policy;
/*     */   }
/*     */ 
/*     */   public int getAcceptPortCount()
/*     */   {
/* 103 */     return this.ports.size();
/*     */   }
/*     */ 
/*     */   public Iterator getAcceptPorts()
/*     */   {
/* 112 */     return this.ports.iterator();
/*     */   }
/*     */ 
/*     */   public Iterator getAcceptPorts(BasicResultFilter filter)
/*     */   {
/* 123 */     return filter.filter(this.ports.iterator());
/*     */   }
/*     */ 
/*     */   public AcceptPort getAcceptPort(InetAddress portAddress, int portNumber)
/*     */     throws NotFoundException
/*     */   {
/* 148 */     AcceptPort matchedPort = null;
/* 149 */     Iterator portIter = this.ports.iterator();
/* 150 */     while (portIter.hasNext()) {
/* 151 */       AcceptPort acceptPort = (AcceptPort)portIter.next();
/* 152 */       if ((acceptPort.getAddress() == portAddress) && (acceptPort.getPort() == portNumber))
/*     */       {
/* 154 */         matchedPort = acceptPort;
/*     */       }
/*     */     }
/* 157 */     if (matchedPort == null) {
/* 158 */       throw new NotFoundException(portAddress.toString());
/*     */     }
/* 160 */     return matchedPort;
/*     */   }
/*     */ 
/*     */   public AcceptPort createAcceptPort(InetAddress portAddress, int portNumber)
/*     */     throws AlreadyExistsException
/*     */   {
/* 188 */     if (this.connManager == null) {
/* 189 */       throw new IllegalStateException("Connection Manager not ready");
/*     */     }
/*     */ 
/* 192 */     Iterator portIter = this.ports.iterator();
/* 193 */     while (portIter.hasNext()) {
/* 194 */       AcceptPort acceptPort = (AcceptPort)portIter.next();
/* 195 */       if ((acceptPort.getAddress().equals(portAddress)) && (acceptPort.getPort() == portNumber))
/*     */       {
/* 197 */         throw new AlreadyExistsException(portAddress.toString());
/*     */       }
/*     */     }
/* 200 */     List portNames = JiveGlobals.getJivePropertyNames(this.propNamePrefix);
/*     */ 
/* 202 */     for (int i = 0; portNames.contains(this.propNamePrefix + ".port" + i); i++);
/* 205 */     return new AcceptPort(this.connManager, this.propNamePrefix + ".port" + i, portAddress, portNumber);
/*     */   }
/*     */ 
/*     */   public void deleteAcceptPort(AcceptPort acceptPort)
/*     */   {
/* 217 */     this.ports.remove(acceptPort);
/*     */     try
/*     */     {
/* 220 */       acceptPort.remove();
/*     */     }
/*     */     catch (IOException e) {
/* 223 */       Log.error(LocaleUtils.getLocalizedString("admin.error"), e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.AcceptManager
 * JD-Core Version:    0.6.2
 */
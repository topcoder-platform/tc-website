/*    */ package com.jivesoftware.forum.net.spi;
/*    */ 
/*    */ import com.jivesoftware.forum.net.Connection;
/*    */ import com.jivesoftware.forum.net.ConnectionMonitor;
/*    */ 
/*    */ public class TransientConnectionMonitor extends BasicTransientMonitor
/*    */   implements ConnectionMonitor
/*    */ {
/*    */   public void addSample(Connection conn)
/*    */   {
/* 33 */     addSample(1L);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.spi.TransientConnectionMonitor
 * JD-Core Version:    0.6.2
 */
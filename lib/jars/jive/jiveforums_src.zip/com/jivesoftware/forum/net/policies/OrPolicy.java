/*    */ package com.jivesoftware.forum.net.policies;
/*    */ 
/*    */ import com.jivesoftware.forum.net.AcceptPolicy;
/*    */ import com.jivesoftware.forum.net.Connection;
/*    */ 
/*    */ public class OrPolicy
/*    */   implements AcceptPolicy
/*    */ {
/*    */   private AcceptPolicy policy1;
/*    */   private AcceptPolicy policy2;
/*    */ 
/*    */   public OrPolicy(AcceptPolicy firstPolicy, AcceptPolicy secondPolicy)
/*    */   {
/* 39 */     this.policy1 = firstPolicy;
/* 40 */     this.policy2 = secondPolicy;
/*    */   }
/*    */ 
/*    */   public boolean evaluate(Connection connection)
/*    */   {
/* 50 */     return (this.policy1.evaluate(connection)) || (this.policy2.evaluate(connection));
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.policies.OrPolicy
 * JD-Core Version:    0.6.2
 */
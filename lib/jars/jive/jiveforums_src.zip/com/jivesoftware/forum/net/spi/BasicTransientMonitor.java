/*     */ package com.jivesoftware.forum.net.spi;
/*     */ 
/*     */ import com.jivesoftware.forum.net.Monitor;
/*     */ import com.jivesoftware.util.CircularLinkedList;
/*     */ import com.jivesoftware.util.ReadWriteLock;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class BasicTransientMonitor
/*     */   implements Monitor
/*     */ {
/*     */   private long totalSamples;
/*     */   private long totalTime;
/*     */   private long lastSampleTime;
/*     */   private long firstSampleTime;
/*     */   private Date startUpTime;
/*     */   private int frameSize;
/*     */   private static final int DEFAULT_FRAME_SIZE = 20;
/*     */   private CircularLinkedList frameList;
/*     */   private ReadWriteLock frameLock;
/*     */   private static final float MS_TO_SECONDS = 1000.0F;
/*     */ 
/*     */   public BasicTransientMonitor()
/*     */   {
/*  27 */     this.totalSamples = 0L;
/*     */ 
/*  29 */     this.totalTime = 0L;
/*     */ 
/*  31 */     this.lastSampleTime = -1L;
/*     */ 
/*  33 */     this.firstSampleTime = -1L;
/*     */ 
/*  35 */     this.startUpTime = new Date();
/*     */ 
/*  37 */     this.frameSize = 20;
/*     */ 
/*  41 */     this.frameList = new CircularLinkedList();
/*     */ 
/*  43 */     this.frameLock = new ReadWriteLock();
/*     */   }
/*     */ 
/*     */   public void addSample(long quantity)
/*     */   {
/*  48 */     if (this.lastSampleTime < 0L) {
/*  49 */       this.lastSampleTime = this.startUpTime.getTime();
/*     */     }
/*  51 */     addSample(quantity, this.lastSampleTime, System.currentTimeMillis());
/*     */   }
/*     */ 
/*     */   public void addSample(long quantity, long startTime, long endTime)
/*     */   {
/*  62 */     this.totalSamples += quantity;
/*  63 */     this.totalTime += endTime - startTime;
/*  64 */     this.lastSampleTime = endTime;
/*  65 */     if (this.firstSampleTime == -1L) {
/*  66 */       this.firstSampleTime = startTime;
/*     */     }
/*  68 */     this.frameLock.acquireWriteLock();
/*     */     try {
/*  70 */       Sample sample = new Sample(quantity, endTime - startTime);
/*  71 */       if (this.frameList.size() < this.frameSize) {
/*  72 */         this.frameList.add(sample);
/*     */       }
/*     */       else
/*     */       {
/*  80 */         this.frameList.prev();
/*  81 */         this.frameList.setNext(sample);
/*     */       }
/*     */     }
/*     */     finally {
/*  85 */       this.frameLock.releaseWriteLock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getTotal() {
/*  90 */     return this.totalSamples;
/*     */   }
/*     */ 
/*     */   public long getTotalTime() {
/*  94 */     return this.totalTime;
/*     */   }
/*     */ 
/*     */   public float getRate() {
/*  98 */     float rate = 0.0F;
/*  99 */     if (this.totalTime != 0L) {
/* 100 */       rate = (float)this.totalSamples / ((float)this.totalTime * 1000.0F);
/*     */     }
/* 102 */     return rate;
/*     */   }
/*     */ 
/*     */   public Date getFirstSampleDate() {
/* 106 */     Date time = this.startUpTime;
/* 107 */     if (this.firstSampleTime > 0L) {
/* 108 */       time = new Date(this.firstSampleTime);
/*     */     }
/* 110 */     return time;
/*     */   }
/*     */ 
/*     */   public Date getLastSampleDate() {
/* 114 */     Date time = null;
/* 115 */     if (this.lastSampleTime > 0L) {
/* 116 */       time = new Date(this.lastSampleTime);
/*     */     }
/*     */     else {
/* 119 */       time = this.startUpTime;
/*     */     }
/* 121 */     return time;
/*     */   }
/*     */ 
/*     */   public int getFrameSize() {
/* 125 */     return this.frameSize;
/*     */   }
/*     */ 
/*     */   public void setFrameSize(int newSize) {
/* 129 */     this.frameLock.acquireWriteLock();
/*     */     try {
/* 131 */       while (this.frameList.size() > newSize) {
/* 132 */         this.frameList.prev();
/* 133 */         this.frameList.remove();
/*     */       }
/*     */     }
/*     */     finally {
/* 137 */       this.frameLock.releaseWriteLock();
/*     */     }
/* 139 */     this.frameSize = newSize;
/*     */   }
/*     */ 
/*     */   public long getFrameTotal() {
/* 143 */     long quantity = 0L;
/* 144 */     if (this.frameList.size() > 0) {
/* 145 */       this.frameLock.acquireWriteLock();
/*     */       try {
/* 147 */         this.frameList.mark();
/* 148 */         while (this.frameList.getPassCount() == 0) {
/* 149 */           Sample sample = (Sample)this.frameList.next();
/* 150 */           quantity += sample.getQuantity();
/*     */         }
/*     */       }
/*     */       finally {
/* 154 */         this.frameLock.releaseWriteLock();
/*     */       }
/*     */     }
/* 157 */     return quantity;
/*     */   }
/*     */ 
/*     */   public long getFrameTotalTime() {
/* 161 */     long time = 0L;
/* 162 */     if (this.frameList.size() > 0) {
/* 163 */       this.frameLock.acquireWriteLock();
/*     */       try {
/* 165 */         this.frameList.mark();
/* 166 */         while (this.frameList.getPassCount() == 0) {
/* 167 */           Sample sample = (Sample)this.frameList.next();
/* 168 */           time += sample.getTime();
/*     */         }
/*     */       }
/*     */       finally {
/* 172 */         this.frameLock.releaseWriteLock();
/*     */       }
/*     */     }
/* 175 */     return time;
/*     */   }
/*     */ 
/*     */   public float getFrameRate() {
/* 179 */     long time = 0L;
/* 180 */     float quantity = 0.0F;
/* 181 */     if (this.frameList.size() > 0) {
/* 182 */       this.frameLock.acquireWriteLock();
/*     */       try {
/* 184 */         this.frameList.mark();
/* 185 */         while (this.frameList.getPassCount() == 0) {
/* 186 */           Sample sample = (Sample)this.frameList.next();
/* 187 */           time += sample.getTime();
/* 188 */           quantity += (float)sample.getQuantity();
/*     */         }
/*     */       }
/*     */       finally {
/* 192 */         this.frameLock.releaseWriteLock();
/*     */       }
/*     */     }
/* 195 */     float rate = 0.0F;
/* 196 */     if (time != 0L) {
/* 197 */       rate = quantity / (float)time * 1000.0F;
/*     */     }
/* 199 */     return rate;
/*     */   }
/*     */ 
/*     */   private class Sample
/*     */   {
/*     */     private long q;
/*     */     private long t;
/*     */ 
/*     */     Sample(long quantity, long time)
/*     */     {
/* 217 */       this.q = quantity;
/* 218 */       this.t = time;
/*     */     }
/*     */ 
/*     */     final long getQuantity()
/*     */     {
/* 227 */       return this.q;
/*     */     }
/*     */ 
/*     */     final long getTime()
/*     */     {
/* 236 */       return this.t;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.spi.BasicTransientMonitor
 * JD-Core Version:    0.6.2
 */
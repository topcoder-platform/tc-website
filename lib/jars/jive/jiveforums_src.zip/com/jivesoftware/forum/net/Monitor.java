package com.jivesoftware.forum.net;

import java.util.Date;

public abstract interface Monitor
{
  public abstract void addSample(long paramLong1, long paramLong2, long paramLong3);

  public abstract void addSample(long paramLong);

  public abstract long getTotal();

  public abstract long getTotalTime();

  public abstract float getRate();

  public abstract Date getFirstSampleDate();

  public abstract Date getLastSampleDate();

  public abstract int getFrameSize();

  public abstract void setFrameSize(int paramInt);

  public abstract long getFrameTotal();

  public abstract long getFrameTotalTime();

  public abstract float getFrameRate();
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.Monitor
 * JD-Core Version:    0.6.2
 */
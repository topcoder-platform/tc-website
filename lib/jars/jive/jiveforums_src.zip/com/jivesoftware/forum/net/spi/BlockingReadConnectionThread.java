/*    */ package com.jivesoftware.forum.net.spi;
/*    */ 
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.forum.net.Connection;
/*    */ import com.jivesoftware.forum.nntp.NNTPParser;
/*    */ import com.jivesoftware.forum.nntp.NNTPServer;
/*    */ import com.jivesoftware.forum.nntp.Session;
/*    */ import com.jivesoftware.forum.nntp.SessionManager;
/*    */ import com.jivesoftware.forum.nntp.SessionNotFoundException;
/*    */ 
/*    */ public class BlockingReadConnectionThread
/*    */   implements Runnable
/*    */ {
/*    */   private Connection connection;
/*    */ 
/*    */   public BlockingReadConnectionThread(Connection connection)
/*    */   {
/* 27 */     this.connection = connection;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/* 34 */     NNTPServer server = NNTPServer.getInstance();
/* 35 */     NNTPParser parser = null;
/*    */     try {
/* 37 */       parser = server.getSessionManager().getSession(this.connection).getParser();
/*    */     }
/* 40 */     catch (SessionNotFoundException snfe) { Log.error(snfe);
/* 41 */       close();
/*    */       return;
/*    */     }
/*    */     while (true) if (!this.connection.isClosed()) {
/*    */         try
/*    */         {
/* 48 */           if (!parser.parse()) {
/* 49 */             break label63;
/*    */           }
/*    */         }
/*    */         catch (Exception e)
/*    */         {
/*    */         }
/*    */       }
/*    */ 
/* 57 */     label63: close();
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/* 64 */     if ((this.connection != null) && (!this.connection.isClosed()))
/*    */       try {
/* 66 */         this.connection.close();
/*    */       }
/*    */       catch (Exception e) {
/* 69 */         Log.error(e);
/*    */       }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.spi.BlockingReadConnectionThread
 * JD-Core Version:    0.6.2
 */
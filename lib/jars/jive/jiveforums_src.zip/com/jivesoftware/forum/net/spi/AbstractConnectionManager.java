/*     */ package com.jivesoftware.forum.net.spi;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.JiveManager;
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.net.BasicResultFilter;
/*     */ import com.jivesoftware.forum.net.Connection;
/*     */ import com.jivesoftware.forum.net.ConnectionCloseListener;
/*     */ import com.jivesoftware.forum.net.ConnectionManager;
/*     */ import com.jivesoftware.forum.net.ConnectionMonitor;
/*     */ import com.jivesoftware.util.ConcurrentHashSet;
/*     */ import com.jivesoftware.util.LongHashMap;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.SynchronousQueue;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.ThreadPoolExecutor;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.TimeUnit;
/*     */ import java.io.IOException;
/*     */ import java.net.Socket;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public abstract class AbstractConnectionManager
/*     */   implements ConnectionManager, JiveManager
/*     */ {
/*  43 */   private LongHashMap id2connections = new LongHashMap();
/*     */ 
/*  45 */   private ConcurrentHashSet connections = new ConcurrentHashSet();
/*     */ 
/*  47 */   private ConnectionMonitor connectedMonitor = new TransientConnectionMonitor();
/*     */ 
/*  49 */   private ConnectionMonitor configMonitor = new TransientConnectionMonitor();
/*     */ 
/*  51 */   private ConnectionMonitor disconnectedMonitor = new TransientConnectionMonitor();
/*     */ 
/*  53 */   private static int ID_FACTORY = 0;
/*     */ 
/*  55 */   private Hashtable blockingConnThreads = new Hashtable();
/*     */   private int maxConnections;
/*     */   private ThreadPoolExecutor threadPool;
/*  59 */   private boolean initialized = false;
/*     */ 
/*     */   public AbstractConnectionManager()
/*     */   {
/*  65 */     this.maxConnections = JiveGlobals.getJiveIntProperty("nntp.maxConnections", 2500);
/*     */   }
/*     */ 
/*     */   public synchronized void initialize() {
/*  69 */     if (!this.initialized) {
/*  70 */       this.initialized = true;
/*  71 */       this.threadPool = new ThreadPoolExecutor(1, this.maxConnections, 1L, TimeUnit.MINUTES, new SynchronousQueue());
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getMaxConnections()
/*     */   {
/*  77 */     return this.maxConnections;
/*     */   }
/*     */ 
/*     */   public void setMaxConnections(int maxConnections) {
/*  81 */     this.maxConnections = maxConnections;
/*  82 */     JiveGlobals.setJiveProperty("nntp.maxConnections", String.valueOf(maxConnections));
/*  83 */     if (this.initialized)
/*  84 */       this.threadPool.setMaximumPoolSize(maxConnections);
/*     */   }
/*     */ 
/*     */   public int getConnectionCount()
/*     */   {
/*  89 */     return this.connections.size();
/*     */   }
/*     */ 
/*     */   public Iterator getConnections() {
/*  93 */     return this.connections.iterator();
/*     */   }
/*     */ 
/*     */   public Iterator getConnections(BasicResultFilter filter) {
/*  97 */     return filter.filter(this.connections.iterator());
/*     */   }
/*     */ 
/*     */   public Connection getConnection(int id) throws NotFoundException {
/* 101 */     synchronized (this.id2connections) {
/* 102 */       return (Connection)this.id2connections.get(id);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Connection createConnection(Socket socket, boolean acceptCreated, boolean secure)
/*     */     throws IOException
/*     */   {
/*     */     int connectionID;
/* 110 */     synchronized (this) {
/* 111 */       connectionID = ID_FACTORY++;
/*     */     }
/* 113 */     Connection con = new SocketChannelConnection(socket, connectionID, true, secure);
/* 114 */     con.setConnectionManager(this);
/* 115 */     return con;
/*     */   }
/*     */ 
/*     */   public void addConnection(Connection con) {
/* 119 */     if (con.isClosed()) {
/* 120 */       return;
/*     */     }
/* 122 */     con.setConnectionManager(this);
/*     */ 
/* 124 */     this.connections.add(con);
/* 125 */     synchronized (this.id2connections) {
/* 126 */       this.id2connections.put(con.getID(), con);
/*     */     }
/*     */ 
/* 129 */     BlockingReadConnectionThread readThread = new BlockingReadConnectionThread(con);
/* 130 */     this.threadPool.execute(readThread);
/* 131 */     this.blockingConnThreads.put(con, readThread);
/*     */ 
/* 133 */     this.connectedMonitor.addSample(con);
/*     */   }
/*     */ 
/*     */   public void removeConnection(Connection conn) throws IllegalStateException {
/* 137 */     this.connections.remove(conn);
/* 138 */     synchronized (this.id2connections) {
/* 139 */       this.id2connections.removeKey(conn.getID());
/*     */     }
/* 141 */     BlockingReadConnectionThread readThread = (BlockingReadConnectionThread)this.blockingConnThreads.get(conn);
/*     */ 
/* 143 */     if (readThread != null) {
/* 144 */       readThread.close();
/*     */     }
/* 146 */     this.blockingConnThreads.remove(conn);
/*     */ 
/* 148 */     this.disconnectedMonitor.addSample(conn);
/*     */   }
/*     */ 
/*     */   public ConnectionMonitor getConnectedMonitor() {
/* 152 */     return this.connectedMonitor;
/*     */   }
/*     */ 
/*     */   public ConnectionMonitor getConfigMonitor() {
/* 156 */     return this.configMonitor;
/*     */   }
/*     */ 
/*     */   public ConnectionMonitor getDisconnectedMonitor() {
/* 160 */     return this.disconnectedMonitor;
/*     */   }
/*     */ 
/*     */   public Object registerCloseListener(ConnectionCloseListener listener, Object handbackMessage)
/*     */     throws UnauthorizedException
/*     */   {
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */   public Object removeCloseListener(ConnectionCloseListener listener)
/*     */     throws UnauthorizedException
/*     */   {
/* 172 */     return null;
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.spi.AbstractConnectionManager
 * JD-Core Version:    0.6.2
 */
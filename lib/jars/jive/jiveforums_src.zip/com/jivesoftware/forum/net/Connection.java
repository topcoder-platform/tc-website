package com.jivesoftware.forum.net;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Date;

public abstract interface Connection
{
  public static final int STATUS_READ_CLOSED = -1;
  public static final int STATUS_READ_READY = 0;
  public static final int STATUS_READ_LOADED = 1;
  public static final int STATUS_READ_SCHEDULED = 2;
  public static final int STATUS_READ_ACTIVE = 3;

  public abstract int getID();

  public abstract Date getConnectDate();

  public abstract long getUptime();

  public abstract BandwidthMonitor getConsumerBandwidthMonitor();

  public abstract BandwidthMonitor getProducerBandwidthMonitor();

  public abstract InetAddress getRemoteAddress();

  public abstract int getRemotePort();

  public abstract InetAddress getLocalAddress();

  public abstract int getLocalPort();

  public abstract Socket getSocket();

  public abstract Writer getWriter();

  public abstract Reader getReader();

  public abstract void close()
    throws IOException;

  public abstract boolean isClosed();

  public abstract boolean isAcceptCreated();

  public abstract boolean isSecure();

  public abstract void setSecure(boolean paramBoolean);

  public abstract void setConnectionManager(ConnectionManager paramConnectionManager);

  public abstract int getReadStatus();

  public abstract void setReadStatus(int paramInt);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.Connection
 * JD-Core Version:    0.6.2
 */
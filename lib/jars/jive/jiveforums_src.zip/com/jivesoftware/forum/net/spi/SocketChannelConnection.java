/*     */ package com.jivesoftware.forum.net.spi;
/*     */ 
/*     */ import com.jivesoftware.forum.net.BandwidthMonitor;
/*     */ import com.jivesoftware.forum.net.Connection;
/*     */ import com.jivesoftware.forum.net.ConnectionManager;
/*     */ import com.jivesoftware.forum.nntp.NNTPServerConfig;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class SocketChannelConnection
/*     */   implements Connection
/*     */ {
/*     */   private int ID;
/*     */   private Socket socket;
/*     */   private Reader reader;
/*     */   private Writer writer;
/*  35 */   private ConnectionManager connManager = null;
/*     */   private boolean acceptCreated;
/*     */   private boolean secure;
/*     */   private long connectDate;
/*  40 */   private BandwidthMonitor consumerMonitor = new TransientBandwidthMonitor();
/*  41 */   private BandwidthMonitor producerMonitor = new TransientBandwidthMonitor();
/*  42 */   private int status = 0;
/*     */ 
/*     */   public SocketChannelConnection(Socket socket, int connectionID, boolean isAcceptCreated, boolean isSecure)
/*     */     throws IOException
/*     */   {
/*  57 */     this.socket = socket;
/*  58 */     NNTPServerConfig serverConfig = NNTPServerConfig.getInstance();
/*  59 */     this.writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), serverConfig.getMimeCharacterEncoding()));
/*     */ 
/*  61 */     this.reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
/*     */ 
/*  63 */     this.ID = connectionID;
/*  64 */     this.acceptCreated = isAcceptCreated;
/*  65 */     this.secure = isSecure;
/*  66 */     this.connectDate = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */   public int getID() {
/*  70 */     return this.ID;
/*     */   }
/*     */ 
/*     */   public Date getConnectDate() {
/*  74 */     return new Date(this.connectDate);
/*     */   }
/*     */ 
/*     */   public long getUptime() {
/*  78 */     return System.currentTimeMillis() - this.connectDate;
/*     */   }
/*     */ 
/*     */   public BandwidthMonitor getConsumerBandwidthMonitor() {
/*  82 */     return this.consumerMonitor;
/*     */   }
/*     */ 
/*     */   public BandwidthMonitor getProducerBandwidthMonitor() {
/*  86 */     return this.producerMonitor;
/*     */   }
/*     */ 
/*     */   public InetAddress getRemoteAddress() {
/*  90 */     return ((InetSocketAddress)this.socket.getRemoteSocketAddress()).getAddress();
/*     */   }
/*     */ 
/*     */   public int getRemotePort() {
/*  94 */     return ((InetSocketAddress)this.socket.getRemoteSocketAddress()).getPort();
/*     */   }
/*     */ 
/*     */   public InetAddress getLocalAddress() {
/*  98 */     return ((InetSocketAddress)this.socket.getLocalSocketAddress()).getAddress();
/*     */   }
/*     */ 
/*     */   public int getLocalPort() {
/* 102 */     return ((InetSocketAddress)this.socket.getLocalSocketAddress()).getPort();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 111 */     this.status = -1;
/*     */     try {
/*     */       try {
/* 114 */         this.writer.close(); } catch (Exception e) {
/*     */       }
/*     */       try {
/* 117 */         this.reader.close();
/*     */       } catch (Exception e) {
/*     */       }
/* 120 */       this.socket.close();
/*     */     }
/*     */     finally {
/* 123 */       if (this.connManager != null)
/*     */         try {
/* 125 */           this.connManager.removeConnection(this);
/*     */         }
/*     */         catch (InterruptedException e) {
/* 128 */           throw new IOException(e.getMessage());
/*     */         }
/*     */         finally {
/* 131 */           this.connManager = null;
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isClosed()
/*     */   {
/* 138 */     return this.status == -1;
/*     */   }
/*     */ 
/*     */   public boolean isAcceptCreated() {
/* 142 */     return this.acceptCreated;
/*     */   }
/*     */ 
/*     */   public boolean isSecure() {
/* 146 */     return this.secure;
/*     */   }
/*     */ 
/*     */   public void setSecure(boolean isSecure) {
/* 150 */     this.secure = isSecure;
/*     */   }
/*     */ 
/*     */   public void setConnectionManager(ConnectionManager manager) {
/* 154 */     this.connManager = manager;
/*     */   }
/*     */ 
/*     */   public int getReadStatus() {
/* 158 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void setReadStatus(int readStatus) {
/* 162 */     this.status = readStatus;
/*     */   }
/*     */ 
/*     */   public Socket getSocket() {
/* 166 */     return this.socket;
/*     */   }
/*     */ 
/*     */   public Writer getWriter() {
/* 170 */     return this.writer;
/*     */   }
/*     */ 
/*     */   public Reader getReader() {
/* 174 */     return this.reader;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 178 */     return "Connection " + this.ID;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.spi.SocketChannelConnection
 * JD-Core Version:    0.6.2
 */
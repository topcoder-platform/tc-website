/*     */ package com.jivesoftware.forum.net;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.forum.net.policies.BasicAcceptPolicy;
/*     */ import com.jivesoftware.forum.net.spi.TransientConnectionMonitor;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ 
/*     */ public class AcceptPort
/*     */ {
/*     */   private static final int BIGGEST_PORT = 65535;
/*     */   private InetAddress address;
/*     */   private int port;
/*  41 */   private boolean secure = false;
/*     */ 
/*  43 */   private final AcceptPolicy policy = new BasicAcceptPolicy(true);
/*     */ 
/*  45 */   private long startTime = -1L;
/*     */ 
/*  47 */   private ConnectionMonitor acceptMonitor = new TransientConnectionMonitor();
/*     */ 
/*  49 */   private ConnectionMonitor connectMonitor = new TransientConnectionMonitor();
/*     */ 
/*  51 */   private ConnectionMonitor disconnectMonitor = new TransientConnectionMonitor();
/*     */ 
/*  53 */   private AcceptThread acceptThread = null;
/*     */   private ConnectionManager conManager;
/*     */   private String configName;
/*     */ 
/*     */   public AcceptPort(ConnectionManager connectionManager, String configPrefixName)
/*     */     throws IOException
/*     */   {
/*  71 */     this.configName = configPrefixName;
/*  72 */     this.conManager = connectionManager;
/*  73 */     String hostname = JiveGlobals.getJiveProperty(this.configName + ".hostname");
/*  74 */     this.port = JiveGlobals.getJiveIntProperty(this.configName + ".portnumber", 119);
/*  75 */     this.secure = JiveGlobals.getJiveBooleanProperty(this.configName + ".secure");
/*  76 */     if ((this.port < 1) || (this.port > 65535)) {
/*  77 */       throw new IOException("Port number configuration is out of valid range: 0-65535");
/*     */     }
/*  79 */     if ((hostname != null) && (hostname.trim().length() > 0)) {
/*  80 */       this.address = InetAddress.getByName(hostname);
/*     */     }
/*     */     else
/*  83 */       this.address = null;
/*     */   }
/*     */ 
/*     */   public AcceptPort(ConnectionManager connectionManager, String configPrefixName, InetAddress bindAddress, int bindport)
/*     */   {
/* 104 */     this.port = bindport;
/* 105 */     this.configName = configPrefixName;
/* 106 */     this.conManager = connectionManager;
/* 107 */     this.address = bindAddress;
/* 108 */     savePort();
/*     */   }
/*     */ 
/*     */   public boolean isSecure()
/*     */   {
/* 117 */     return this.secure;
/*     */   }
/*     */ 
/*     */   public void setSecure(boolean secure)
/*     */   {
/* 130 */     this.secure = secure;
/* 131 */     savePort();
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 140 */     return this.port;
/*     */   }
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 152 */     this.port = port;
/* 153 */     savePort();
/*     */   }
/*     */ 
/*     */   public InetAddress getAddress()
/*     */   {
/* 168 */     return this.address;
/*     */   }
/*     */ 
/*     */   public void setAddress(InetAddress address)
/*     */   {
/* 187 */     this.address = address;
/* 188 */     savePort();
/*     */   }
/*     */ 
/*     */   public long getUptime()
/*     */   {
/* 198 */     long uptime = -1L;
/* 199 */     if (this.startTime > 0L) {
/* 200 */       uptime = System.currentTimeMillis() - this.startTime;
/*     */     }
/* 202 */     return uptime;
/*     */   }
/*     */ 
/*     */   public void open()
/*     */     throws IOException, SecurityException, IllegalArgumentException
/*     */   {
/* 213 */     if (this.acceptThread == null) {
/* 214 */       this.acceptThread = new AcceptThread();
/* 215 */       this.acceptThread.start();
/* 216 */       this.startTime = System.currentTimeMillis();
/* 217 */       Log.info("Opened NNTP accept port " + toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 227 */     if (this.acceptThread != null) {
/* 228 */       this.acceptThread.close();
/* 229 */       this.acceptThread = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void remove()
/*     */     throws IOException
/*     */   {
/* 239 */     JiveGlobals.deleteJiveProperty(this.configName);
/* 240 */     if (this.startTime > 0L)
/* 241 */       close();
/*     */   }
/*     */ 
/*     */   public AcceptPolicy getAcceptPolicy()
/*     */   {
/* 258 */     return this.policy;
/*     */   }
/*     */ 
/*     */   public ConnectionMonitor getAcceptMonitor()
/*     */   {
/* 271 */     return this.acceptMonitor;
/*     */   }
/*     */ 
/*     */   public ConnectionMonitor getConnectMonitor()
/*     */   {
/* 281 */     return this.connectMonitor;
/*     */   }
/*     */ 
/*     */   public ConnectionMonitor getDisconnectMonitor()
/*     */   {
/* 291 */     return this.disconnectMonitor;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 300 */     StringBuffer info = new StringBuffer(this.address == null ? "any" : this.address.toString());
/*     */ 
/* 302 */     info.append("/");
/* 303 */     info.append(Integer.toString(this.port));
/* 304 */     if (this.secure) {
/* 305 */       info.append(" SECURE");
/*     */     }
/* 307 */     return info.toString();
/*     */   }
/*     */ 
/*     */   private void savePort()
/*     */   {
/* 314 */     if (this.address != null) {
/* 315 */       JiveGlobals.setJiveProperty(this.configName + ".hostname", this.address.getHostName());
/*     */     }
/* 317 */     JiveGlobals.setJiveProperty(this.configName + ".portnumber", Integer.toString(this.port));
/* 318 */     JiveGlobals.setJiveProperty(this.configName + ".secure", Boolean.toString(this.secure));
/*     */   }
/*     */ 
/*     */   private class AcceptThread extends Thread
/*     */   {
/*     */     private ServerSocket server;
/* 327 */     private boolean running = false;
/*     */ 
/*     */     AcceptThread()
/*     */       throws IOException
/*     */     {
/* 333 */       super();
/* 334 */       setDaemon(false);
/* 335 */       if (AcceptPort.this.address == null) {
/* 336 */         this.server = new ServerSocket(AcceptPort.this.port, 100);
/*     */       }
/*     */       else {
/* 339 */         this.server = new ServerSocket(AcceptPort.this.port, 100, AcceptPort.this.address);
/*     */       }
/* 341 */       setPriority(10);
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 351 */       this.running = true;
/* 352 */       while (this.running)
/*     */         try {
/* 354 */           Socket socket = this.server.accept();
/* 355 */           this.server.getReceiveBufferSize();
/* 356 */           Connection con = AcceptPort.this.conManager.createConnection(socket, true, AcceptPort.this.secure);
/* 357 */           AcceptPort.this.acceptMonitor.addSample(con);
/* 358 */           if (AcceptPort.this.policy.evaluate(con)) {
/* 359 */             AcceptPort.this.connectMonitor.addSample(con);
/* 360 */             AcceptPort.this.conManager.addConnection(con);
/*     */           }
/*     */           else {
/* 363 */             AcceptPort.this.disconnectMonitor.addSample(con);
/*     */           }
/*     */         }
/*     */         catch (IOException e) {
/* 367 */           if (this.running)
/* 368 */             Log.error(e);
/*     */         }
/*     */     }
/*     */ 
/*     */     public void close()
/*     */     {
/* 378 */       if (this.running) {
/* 379 */         this.running = false;
/* 380 */         AcceptPort.this.startTime = -1L;
/*     */         try {
/* 382 */           this.server.close();
/*     */         }
/*     */         catch (IOException e) {
/* 385 */           Log.warn("Trouble closing the accept port", e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.AcceptPort
 * JD-Core Version:    0.6.2
 */
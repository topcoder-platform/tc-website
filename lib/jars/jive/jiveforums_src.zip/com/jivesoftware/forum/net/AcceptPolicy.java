package com.jivesoftware.forum.net;

public abstract interface AcceptPolicy
{
  public abstract boolean evaluate(Connection paramConnection);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.AcceptPolicy
 * JD-Core Version:    0.6.2
 */
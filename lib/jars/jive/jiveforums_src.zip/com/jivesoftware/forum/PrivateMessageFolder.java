package com.jivesoftware.forum;

import com.jivesoftware.base.User;
import java.util.Iterator;

public abstract interface PrivateMessageFolder
{
  public static final int FOLDER_INBOX = 1;
  public static final int FOLDER_SENT = 2;
  public static final int FOLDER_DRAFTS = 3;
  public static final int FOLDER_TRASH = 4;
  public static final int SORT_DATE = 1000;
  public static final int SORT_SUBJECT = 1001;
  public static final int SORT_SENDER = 1002;

  public abstract int getID();

  public abstract User getOwner();

  public abstract String getName();

  public abstract void setName(String paramString);

  public abstract Iterator getMessages();

  public abstract Iterator getMessages(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean);

  public abstract int getMessageCount();

  public abstract int getUnreadMessageCount();

  public abstract void deleteMessage(PrivateMessage paramPrivateMessage);

  public abstract void moveMessage(PrivateMessage paramPrivateMessage, PrivateMessageFolder paramPrivateMessageFolder);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.PrivateMessageFolder
 * JD-Core Version:    0.6.2
 */
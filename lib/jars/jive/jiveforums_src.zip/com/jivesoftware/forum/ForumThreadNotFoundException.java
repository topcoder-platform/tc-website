/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ public class ForumThreadNotFoundException extends Exception
/*    */ {
/*    */   public ForumThreadNotFoundException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ForumThreadNotFoundException(String msg)
/*    */   {
/* 26 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.ForumThreadNotFoundException
 * JD-Core Version:    0.6.2
 */
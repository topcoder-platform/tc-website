package com.jivesoftware.forum;

import com.jivesoftware.base.UnauthorizedException;
import com.jivesoftware.base.User;
import java.io.InputStream;
import java.util.Iterator;

public abstract interface AvatarManager
{
  public abstract Avatar createAvatar(User paramUser, String paramString1, String paramString2, InputStream paramInputStream)
    throws UnauthorizedException, AvatarException;

  public abstract void setActiveAvatar(User paramUser, Avatar paramAvatar)
    throws UnauthorizedException;

  public abstract Avatar getAvatar(long paramLong)
    throws AvatarNotFoundException;

  public abstract Iterator getAvatars(User paramUser);

  public abstract Avatar getActiveAvatar(User paramUser);

  public abstract Iterator getGlobalAvatars();

  public abstract void deleteAvatar(Avatar paramAvatar)
    throws UnauthorizedException;

  public abstract void setAvatarsEnabled(boolean paramBoolean)
    throws UnauthorizedException;

  public abstract boolean isAvatarsEnabled();

  public abstract int getMaxAllowableHeight();

  public abstract void setMaxAllowableHeight(int paramInt)
    throws UnauthorizedException;

  public abstract int getMaxAllowableWidth();

  public abstract void setMaxAllowableWidth(int paramInt)
    throws UnauthorizedException;

  public abstract boolean isAllowImageResize();

  public abstract void setAllowImageResize(boolean paramBoolean)
    throws UnauthorizedException;

  public abstract int getMaxUserAvatars();

  public abstract void setMaxUserAvatars(int paramInt)
    throws UnauthorizedException;

  public abstract int getAvatarCount(User paramUser);

  public abstract boolean isModerateUserAvatars();

  public abstract void setModerateUserAvatars(boolean paramBoolean)
    throws UnauthorizedException;

  public abstract Iterator getModerationAvatars()
    throws UnauthorizedException;

  public abstract int getModerationAvatarCount();
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.AvatarManager
 * JD-Core Version:    0.6.2
 */
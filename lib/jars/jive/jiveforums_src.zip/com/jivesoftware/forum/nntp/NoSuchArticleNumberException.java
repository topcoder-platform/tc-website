/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class NoSuchArticleNumberException extends ArticleNotFoundException
/*    */ {
/*    */   private static final int CODE = 423;
/* 23 */   private static final NNTPResponse NOT_FOUND = new StaticNNTPResponse(423, "no such article number in this group");
/*    */ 
/*    */   public NoSuchArticleNumberException()
/*    */   {
/* 30 */     this.response = NOT_FOUND;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NoSuchArticleNumberException
 * JD-Core Version:    0.6.2
 */
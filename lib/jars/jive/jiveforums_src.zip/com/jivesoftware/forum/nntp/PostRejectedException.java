/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class PostRejectedException extends NNTPException
/*    */ {
/*    */   private static final int CODE = 437;
/* 28 */   private static final NNTPResponse RESPONSE = new StaticNNTPResponse(437, "posting rejected");
/*    */ 
/*    */   public PostRejectedException()
/*    */   {
/* 34 */     this.response = RESPONSE;
/*    */   }
/*    */ 
/*    */   public PostRejectedException(Throwable cause) {
/* 38 */     super(cause);
/* 39 */     this.response = RESPONSE;
/*    */   }
/*    */ 
/*    */   public PostRejectedException(String message) {
/* 43 */     super(message);
/* 44 */     this.response = RESPONSE;
/*    */   }
/*    */ 
/*    */   public PostRejectedException(String message, Throwable cause) {
/* 48 */     super(message, cause);
/* 49 */     this.response = RESPONSE;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.PostRejectedException
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import com.jivesoftware.forum.net.Connection;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class XOverResponse extends NNTPResponseBuffer
/*     */ {
/*     */   private static final int CODE = 224;
/*     */   private static final String TEXT = "Overview information follows";
/*     */ 
/*     */   private XOverResponse(Connection connection)
/*     */     throws IOException
/*     */   {
/*  37 */     super(connection, 224, "Overview information follows", true);
/*     */   }
/*     */ 
/*     */   public static NNTPResponse sendXOver(ArticlePointer pointer, ArticleFilter filter, Connection connection)
/*     */     throws NoGroupSelectedException, ArticleNotSelectedException, NoPermissionException, ArticleNotFoundException, IOException
/*     */   {
/*  59 */     XOverResponse response = null;
/*  60 */     Article article = null;
/*     */ 
/*  62 */     switch (filter.getMode())
/*     */     {
/*     */     case 0:
/*  65 */       article = pointer.getCurrentArticle();
/*     */ 
/*  68 */       response = new XOverResponse(connection);
/*     */ 
/*  70 */       addXOver(response, article);
/*  71 */       break;
/*     */     case 1:
/*  74 */       article = pointer.getArticle(filter.getMessageID());
/*     */ 
/*  77 */       response = new XOverResponse(connection);
/*     */ 
/*  79 */       addXOver(response, article);
/*  80 */       break;
/*     */     case 2:
/*  83 */       article = pointer.getArticle(filter.getArticleNumber());
/*     */ 
/*  86 */       response = new XOverResponse(connection);
/*     */ 
/*  88 */       addXOver(response, article);
/*  89 */       break;
/*     */     default:
/*  91 */       Iterator artIter = pointer.getArticles(filter);
/*     */ 
/*  94 */       response = new XOverResponse(connection);
/*     */ 
/*  98 */       response.flush();
/*  99 */       while (artIter.hasNext()) {
/* 100 */         addXOver(response, (Article)artIter.next());
/*     */       }
/*     */     }
/* 103 */     return response;
/*     */   }
/*     */ 
/*     */   private static void addXOver(XOverResponse response, Article article)
/*     */     throws IOException
/*     */   {
/* 116 */     response.append(Integer.toString(article.getNumber()));
/* 117 */     response.appendXParameter(article.getSubject());
/* 118 */     response.appendXParameter(article.getAuthor());
/* 119 */     response.appendXParameter(article.getDate());
/* 120 */     response.appendXParameter(article.getMessageID());
/* 121 */     response.appendXParameter(article.getReferences());
/* 122 */     response.appendXParameter(Integer.toString(article.getByteCount()));
/* 123 */     response.appendXParameter(Integer.toString(article.getLineCount())).endLine();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.XOverResponse
 * JD-Core Version:    0.6.2
 */
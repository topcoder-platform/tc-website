package com.jivesoftware.forum.nntp;

import java.util.Iterator;

public abstract interface ArticlePointer
{
  public abstract Article getArticle(int paramInt)
    throws NoGroupSelectedException, ArticleNotFoundException, NoPermissionException;

  public abstract Article getArticle(String paramString)
    throws ArticleNotFoundException, NoPermissionException;

  public abstract Article getCurrentArticle()
    throws ArticleNotFoundException, NoPermissionException, ArticleNotSelectedException, NoGroupSelectedException;

  public abstract int getCurrentArticleNumber()
    throws ArticleNotSelectedException;

  public abstract Iterator getArticles(ArticleFilter paramArticleFilter)
    throws NoGroupSelectedException, ArticleNotSelectedException, NoPermissionException, ArticleNotFoundException;

  public abstract NewsGroup getGroup()
    throws NoGroupSelectedException, NoPermissionException;

  public abstract NewsGroup setGroup(String paramString)
    throws NoPermissionException, NewsGroupNotFoundException;

  public abstract Article last()
    throws NoGroupSelectedException, ArticleNotFoundException, ArticleNotSelectedException, NoPermissionException;

  public abstract Article next()
    throws NoGroupSelectedException, ArticleNotFoundException, ArticleNotSelectedException, NoPermissionException;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.ArticlePointer
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ import com.jivesoftware.forum.net.Connection;
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class NewNewsResponse extends NNTPResponseBuffer
/*    */ {
/*    */   private static final int CODE = 230;
/*    */ 
/*    */   private NewNewsResponse(Connection connection)
/*    */     throws IOException
/*    */   {
/* 38 */     super(connection, 230, "list of new articles by message-id follows", true);
/*    */   }
/*    */ 
/*    */   public static NNTPResponse getList(Connection connection, Iterator articleIter)
/*    */     throws IOException
/*    */   {
/* 52 */     NewNewsResponse response = new NewNewsResponse(connection);
/*    */ 
/* 56 */     if (articleIter.hasNext()) {
/* 57 */       Article art = (Article)articleIter.next();
/* 58 */       response.appendLine(art.getMessageID());
/* 59 */       response.flush();
/*    */     }
/*    */ 
/* 62 */     while (articleIter.hasNext()) {
/* 63 */       Article art = (Article)articleIter.next();
/* 64 */       response.appendLine(art.getMessageID());
/*    */     }
/* 66 */     return response;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NewNewsResponse
 * JD-Core Version:    0.6.2
 */
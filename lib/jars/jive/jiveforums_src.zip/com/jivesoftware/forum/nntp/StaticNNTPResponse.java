/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ import com.jivesoftware.forum.net.Connection;
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ 
/*    */ public class StaticNNTPResponse
/*    */   implements NNTPResponse
/*    */ {
/*    */   private int value;
/*    */   private String fullText;
/*    */ 
/*    */   public StaticNNTPResponse(int val, String staticText)
/*    */   {
/* 41 */     this.value = val;
/* 42 */     if (val < 0) {
/* 43 */       this.fullText = (staticText + "\r\n");
/*    */     }
/*    */     else
/* 46 */       this.fullText = (Integer.toString(val) + " " + staticText + "\r\n");
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 51 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void send(Connection con) throws IOException {
/* 55 */     Writer writer = con.getWriter();
/* 56 */     writer.write(this.fullText);
/* 57 */     writer.flush();
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 61 */     return this.fullText;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.StaticNNTPResponse
 * JD-Core Version:    0.6.2
 */
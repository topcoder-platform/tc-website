/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class NoPermissionException extends NNTPException
/*    */ {
/*    */   private static final int CODE = 502;
/* 29 */   public static final NNTPResponse RESPONSE = new StaticNNTPResponse(502, "access restriction or permission denied");
/*    */ 
/*    */   public NoPermissionException()
/*    */   {
/* 36 */     this.response = RESPONSE;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NoPermissionException
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.nntp.spi;
/*     */ 
/*     */ import com.jivesoftware.base.AuthFactory;
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.base.stats.ReadStat;
/*     */ import com.jivesoftware.base.stats.ReadStatsManager;
/*     */ import com.jivesoftware.base.stats.ReadStatsManagerFactory;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.database.DbForum;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.forum.database.DbForumMessage;
/*     */ import com.jivesoftware.forum.nntp.Article;
/*     */ import com.jivesoftware.forum.nntp.ArticleFilter;
/*     */ import com.jivesoftware.forum.nntp.ArticleNotFoundException;
/*     */ import com.jivesoftware.forum.nntp.NNTPDate;
/*     */ import com.jivesoftware.forum.nntp.NewsGroup;
/*     */ import com.jivesoftware.forum.nntp.NewsGroupFilter;
/*     */ import com.jivesoftware.forum.nntp.NewsGroupNotFoundException;
/*     */ import com.jivesoftware.forum.nntp.NoGroupSelectedException;
/*     */ import com.jivesoftware.forum.nntp.NoPermissionException;
/*     */ import com.jivesoftware.forum.nntp.PostFailedException;
/*     */ import com.jivesoftware.forum.nntp.PostRejectedException;
/*     */ import com.jivesoftware.forum.stats.NNTPReadStatSession;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public final class ForumSession
/*     */ {
/*  49 */   private static DbForumFactory dbFactory = DbForumFactory.getInstance();
/*     */   private ForumFactory forumFactory;
/*     */   private NNTPReadStatSession readStatSession;
/*  57 */   private long userID = -1L;
/*     */ 
/*     */   public ForumSession(NNTPReadStatSession session)
/*     */   {
/*  63 */     this.forumFactory = ForumFactory.getInstance(AuthFactory.getAnonymousAuthToken());
/*  64 */     this.readStatSession = session;
/*     */   }
/*     */ 
/*     */   public boolean isAuthenticated()
/*     */   {
/*  73 */     return this.userID != -1L;
/*     */   }
/*     */ 
/*     */   public boolean authenticate(String username, String password)
/*     */   {
/*  85 */     boolean auth = false;
/*     */     try {
/*  87 */       AuthToken token = AuthFactory.getAuthToken(username, password);
/*  88 */       this.forumFactory = ForumFactory.getInstance(token);
/*  89 */       this.userID = this.forumFactory.getUserManager().getUser(username).getID();
/*  90 */       auth = true;
/*     */     }
/*     */     catch (Exception e) {
/*  93 */       auth = false;
/*     */     }
/*  95 */     return auth;
/*     */   }
/*     */ 
/*     */   public ForumFactory getForumFactory() {
/*  99 */     return this.forumFactory;
/*     */   }
/*     */ 
/*     */   public User getUser()
/*     */   {
/* 108 */     User user = null;
/* 109 */     if (this.forumFactory != null) {
/*     */       try {
/* 111 */         user = this.forumFactory.getUserManager().getUser(this.userID);
/*     */       }
/*     */       catch (UserNotFoundException ignored)
/*     */       {
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 120 */     return user;
/*     */   }
/*     */ 
/*     */   public Iterator getNewsGroups(NewsGroupFilter filter)
/*     */   {
/*     */     Iterator forumIterator;
/*     */     Iterator forumIterator;
/* 138 */     if ((filter != null) && (filter.getStartDate() != null))
/*     */     {
/* 140 */       ResultFilter forumFilter = ResultFilter.createDefaultForumFilter();
/* 141 */       forumFilter.setCreationDateRangeMin(filter.getStartDate().toDate());
/* 142 */       ForumCategory rootCat = this.forumFactory.getRootForumCategory();
/* 143 */       forumIterator = rootCat.getRecursiveForums(forumFilter);
/*     */     }
/*     */     else
/*     */     {
/* 147 */       forumIterator = this.forumFactory.getRootForumCategory().getRecursiveForums();
/*     */ 
/* 151 */       if (filter.getNameFilterCount() > 0)
/*     */       {
/* 153 */         forumIterator = new FNameFilterIterator(forumIterator, filter);
/*     */       }
/*     */     }
/* 156 */     return new FFNGIteratorAdapter(forumIterator);
/*     */   }
/*     */ 
/*     */   public NewsGroup getNewsGroup(String groupName)
/*     */     throws NewsGroupNotFoundException, NoPermissionException
/*     */   {
/* 169 */     return new FForumNewsGroupAdapter(getForum(groupName));
/*     */   }
/*     */ 
/*     */   public Forum getForum(String groupName)
/*     */     throws NewsGroupNotFoundException, NoPermissionException
/*     */   {
/*     */     try
/*     */     {
/* 183 */       return this.forumFactory.getForum(groupName.toLowerCase());
/*     */     }
/*     */     catch (ForumNotFoundException fnfe) {
/* 186 */       Log.error("News Group " + groupName + " not found.", fnfe);
/* 187 */       throw new NewsGroupNotFoundException("Group " + groupName + " not found.");
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 190 */       Log.error(ue);
/* 191 */     }throw new NoPermissionException();
/*     */   }
/*     */ 
/*     */   public NewsGroup getNewsGroup(long groupID)
/*     */     throws NewsGroupNotFoundException, NoPermissionException
/*     */   {
/* 205 */     NewsGroup group = null;
/*     */     try {
/* 207 */       group = new FForumNewsGroupAdapter(this.forumFactory.getForum(groupID));
/*     */     }
/*     */     catch (ForumNotFoundException e) {
/* 210 */       throw new NewsGroupNotFoundException();
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 213 */       throw new NoPermissionException();
/*     */     }
/* 215 */     return group;
/*     */   }
/*     */ 
/*     */   public Article getArticle(long messageID)
/*     */     throws ArticleNotFoundException, NoPermissionException
/*     */   {
/*     */     try
/*     */     {
/* 233 */       this.forumFactory.getMessage(messageID);
/*     */ 
/* 236 */       return new FMessageArticleAdapter((DbForumMessage)dbFactory.getMessage(messageID));
/*     */     }
/*     */     catch (ForumMessageNotFoundException e)
/*     */     {
/* 240 */       throw new ArticleNotFoundException();
/*     */     } catch (UnauthorizedException e) {
/*     */     }
/* 243 */     throw new NoPermissionException();
/*     */   }
/*     */ 
/*     */   public Article getArticle(long groupID, int articleNumber)
/*     */     throws ArticleNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 258 */       long messageID = this.forumFactory.getMessageID(groupID, articleNumber);
/* 259 */       if (messageID == -1L) {
/* 260 */         throw new ArticleNotFoundException();
/*     */       }
/* 262 */       DbForumMessage msg = (DbForumMessage)dbFactory.getMessage(messageID);
/*     */ 
/* 264 */       if (this.readStatSession != null) {
/* 265 */         ReadStat readStat = new ReadStat(getUser(), 2, messageID, this.readStatSession);
/* 266 */         ReadStatsManagerFactory.getInstance().addReadStat(readStat);
/*     */       }
/*     */ 
/* 269 */       return new FMessageArticleAdapter(msg);
/*     */     }
/*     */     catch (ForumMessageNotFoundException e) {
/* 272 */       throw new ArticleNotFoundException();
/*     */     }
/*     */     catch (IllegalArgumentException iae) {
/* 275 */       throw new ArticleNotFoundException(iae.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void post(Iterator article)
/*     */     throws NoPermissionException, PostRejectedException, PostFailedException
/*     */   {
/* 298 */     FArticlePostUtil.post(article, this);
/*     */   }
/*     */ 
/*     */   public Article getLastArticle(long groupID, int articleNumber)
/*     */     throws NoPermissionException, ArticleNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 312 */       Forum forum = this.forumFactory.getForum(groupID);
/* 313 */       long minIndex = forum.getMinForumIndex();
/* 314 */       for (int i = articleNumber - 1; i >= minIndex; i--) {
/* 315 */         long messageID = this.forumFactory.getMessageID(groupID, i);
/* 316 */         if (messageID != -1L) {
/* 317 */           return getArticle(messageID);
/*     */         }
/*     */       }
/* 320 */       throw new ArticleNotFoundException();
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 323 */       throw new NoPermissionException();
/*     */     }
/*     */     catch (ForumNotFoundException fnfe) {
/* 326 */       throw new ArticleNotFoundException(fnfe);
/*     */     }
/*     */   }
/*     */ 
/*     */   public final Article getNextArticle(long groupID, int articleNumber)
/*     */     throws NoPermissionException, ArticleNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 341 */       Forum forum = this.forumFactory.getForum(groupID);
/* 342 */       long maxIndex = forum.getMaxForumIndex();
/* 343 */       for (int i = articleNumber + 1; i <= maxIndex; i++) {
/* 344 */         long messageID = this.forumFactory.getMessageID(groupID, i);
/* 345 */         if (messageID != -1L) {
/* 346 */           return getArticle(messageID);
/*     */         }
/*     */       }
/* 349 */       throw new ArticleNotFoundException();
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 352 */       throw new NoPermissionException();
/*     */     }
/*     */     catch (ForumNotFoundException fnfe) {
/* 355 */       throw new ArticleNotFoundException(fnfe);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Iterator getArticles(NewsGroupFilter groupFilter, ArticleFilter articleFilter)
/*     */     throws NoPermissionException, NoGroupSelectedException
/*     */   {
/*     */     try
/*     */     {
/*     */       Iterator artIter;
/* 381 */       if (groupFilter.isSingleGroupFilter()) {
/* 382 */         Forum forum = this.forumFactory.getForum(groupFilter.getGroupID());
/*     */         int endIndex;
/*     */         int startIndex;
/*     */         int endIndex;
/* 386 */         if (articleFilter.getMode() == 3) {
/* 387 */           int startIndex = articleFilter.getStartIndex();
/* 388 */           endIndex = articleFilter.getEndIndex();
/*     */         }
/*     */         else {
/* 391 */           startIndex = forum.getMinForumIndex();
/* 392 */           endIndex = forum.getMaxForumIndex();
/*     */         }
/* 394 */         artIter = new ArticleIterator(startIndex, endIndex, forum.getID());
/*     */       }
/*     */ 
/* 398 */       return getNewNews(groupFilter);
/*     */     }
/*     */     catch (ForumNotFoundException e)
/*     */     {
/* 403 */       throw new NoGroupSelectedException();
/*     */     } catch (UnauthorizedException e) {
/*     */     }
/* 406 */     throw new NoPermissionException();
/*     */   }
/*     */ 
/*     */   private Iterator getNewNews(NewsGroupFilter groupFilter)
/*     */   {
/* 417 */     MultiArticleIterator articleIterator = new MultiArticleIterator();
/*     */ 
/* 419 */     DbForumFactory dbForumFactory = DbForumFactory.getInstance();
/*     */ 
/* 421 */     NNTPDate startDate = groupFilter.getStartDate();
/* 422 */     groupFilter.setStartDate(null);
/* 423 */     Iterator forumIter = getNewsGroups(groupFilter);
/* 424 */     while (forumIter.hasNext())
/*     */     {
/* 431 */       FForumNewsGroupAdapter adapter = (FForumNewsGroupAdapter)forumIter.next();
/* 432 */       Forum forum = adapter.getForum();
/*     */ 
/* 434 */       if (forum.isAuthorized(1L))
/*     */       {
/*     */         try
/*     */         {
/* 438 */           DbForum dbForum = (DbForum)dbForumFactory.getForum(forum.getID());
/* 439 */           ResultFilter artFilter = ResultFilter.createDefaultMessageFilter();
/* 440 */           artFilter.setCreationDateRangeMin(startDate.toDate());
/* 441 */           articleIterator.addIterator(dbForum.getMessages(artFilter));
/*     */         } catch (ForumNotFoundException ignored) {
/*     */         }
/*     */       }
/*     */     }
/* 446 */     return articleIterator;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.ForumSession
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ public class MessageID
/*    */ {
/* 23 */   private static NNTPServerConfig config = NNTPServerConfig.getInstance();
/*    */ 
/* 34 */   private static final Pattern ID_PATTERN = Pattern.compile("<(.+)\\@[^>]*>");
/*    */ 
/*    */   public static boolean isMessageID(String id)
/*    */   {
/* 45 */     if (id == null) {
/* 46 */       return false;
/*    */     }
/* 48 */     Matcher match = ID_PATTERN.matcher(id);
/* 49 */     return match.matches();
/*    */   }
/*    */ 
/*    */   public static String toMessageID(long messageID)
/*    */   {
/* 60 */     StringBuffer buf = new StringBuffer();
/* 61 */     buf.append("<").append(messageID).append("@").append(config.getName()).append(">");
/*    */ 
/* 63 */     return buf.toString();
/*    */   }
/*    */ 
/*    */   public static long parseMessageID(String id)
/*    */   {
/* 73 */     if (id == null) {
/* 74 */       return -1L;
/*    */     }
/* 76 */     int startIndex = id.indexOf("<");
/* 77 */     int endIndex = id.indexOf("@");
/* 78 */     if ((startIndex == -1) || (endIndex == -1) || (startIndex > endIndex))
/* 79 */       return -1L;
/*    */     try
/*    */     {
/* 82 */       return Long.parseLong(id.substring(startIndex + 1, endIndex));
/*    */     } catch (NumberFormatException nfe) {
/*    */     }
/* 85 */     return -1L;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.MessageID
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class SyntaxException extends NNTPException
/*    */ {
/*    */   private static final int CODE = 501;
/* 23 */   private static final NNTPResponse SYNTAX = new StaticNNTPResponse(501, "command syntax error");
/*    */ 
/* 26 */   public static final SyntaxException RESPONSE = new SyntaxException();
/*    */ 
/*    */   public SyntaxException()
/*    */   {
/* 32 */     this.response = SYNTAX;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.SyntaxException
 * JD-Core Version:    0.6.2
 */
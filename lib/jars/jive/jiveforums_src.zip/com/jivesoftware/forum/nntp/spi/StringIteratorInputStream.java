/*     */ package com.jivesoftware.forum.nntp.spi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class StringIteratorInputStream extends InputStream
/*     */ {
/*     */   private Iterator iterator;
/*  30 */   private String current = null;
/*     */ 
/*  32 */   private int currentIndex = -1;
/*     */ 
/*  34 */   private String delimiter = null;
/*     */ 
/*  36 */   private boolean sendingDelimiter = false;
/*     */ 
/*     */   public StringIteratorInputStream(Iterator itr)
/*     */   {
/*  44 */     this.iterator = itr;
/*     */   }
/*     */ 
/*     */   public StringIteratorInputStream(Iterator itr, String delim)
/*     */   {
/*  56 */     this.iterator = itr;
/*  57 */     if ((delim != null) && (delim.length() > 0))
/*  58 */       this.delimiter = delim;
/*     */   }
/*     */ 
/*     */   public int read() throws IOException
/*     */   {
/*  63 */     int read = -1;
/*  64 */     if (this.current == null) {
/*  65 */       if (this.iterator.hasNext()) {
/*  66 */         this.current = ((String)this.iterator.next());
/*  67 */         this.currentIndex = 0;
/*  68 */         if (this.current.length() == 0) {
/*  69 */           if (this.delimiter != null) {
/*  70 */             this.sendingDelimiter = true;
/*  71 */             this.current = this.delimiter;
/*     */           }
/*     */           else {
/*  74 */             this.current = null;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  79 */     else if (this.currentIndex >= this.current.length()) {
/*  80 */       if ((this.delimiter == null) || (this.sendingDelimiter)) {
/*  81 */         this.sendingDelimiter = false;
/*  82 */         this.currentIndex = 0;
/*  83 */         this.current = null;
/*  84 */       }while ((this.current == null) && (this.iterator.hasNext())) {
/*  85 */         this.current = ((String)this.iterator.next());
/*  86 */         if (this.current.length() == 0)
/*  87 */           if (this.delimiter != null) {
/*  88 */             this.sendingDelimiter = true;
/*  89 */             this.current = this.delimiter;
/*     */           }
/*     */           else {
/*  92 */             this.current = null;
/*     */ 
/*  94 */             continue;
/*     */ 
/*  98 */             this.sendingDelimiter = true;
/*  99 */             this.current = this.delimiter;
/* 100 */             this.currentIndex = 0;
/*     */           }
/*     */       }
/*     */     }
/* 103 */     if (this.current != null) {
/* 104 */       read = this.current.charAt(this.currentIndex++);
/*     */     }
/* 106 */     return read;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.StringIteratorInputStream
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.nntp.spi;
/*    */ 
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class FFNGIteratorAdapter
/*    */   implements Iterator
/*    */ {
/*    */   private Iterator iter;
/*    */ 
/*    */   public FFNGIteratorAdapter(Iterator forumIterator)
/*    */   {
/* 35 */     this.iter = forumIterator;
/*    */   }
/*    */ 
/*    */   public void remove() {
/* 39 */     this.iter.remove();
/*    */   }
/*    */ 
/*    */   public boolean hasNext() {
/* 43 */     return this.iter.hasNext();
/*    */   }
/*    */ 
/*    */   public Object next() {
/* 47 */     return new FForumNewsGroupAdapter((Forum)this.iter.next());
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.FFNGIteratorAdapter
 * JD-Core Version:    0.6.2
 */
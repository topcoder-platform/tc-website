/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class NNTPException extends Exception
/*    */ {
/* 25 */   protected NNTPResponse response = FAULT;
/*    */ 
/* 30 */   private static final NNTPResponse FAULT = new StaticNNTPResponse(503, "program fault - command not performed");
/*    */ 
/*    */   public NNTPException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NNTPException(String message)
/*    */   {
/* 51 */     super(message);
/*    */   }
/*    */ 
/*    */   public NNTPException(Throwable cause)
/*    */   {
/* 67 */     super(cause);
/*    */   }
/*    */ 
/*    */   public NNTPException(String message, Throwable cause)
/*    */   {
/* 84 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public NNTPResponse getErrorResponse()
/*    */   {
/* 95 */     return this.response;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NNTPException
 * JD-Core Version:    0.6.2
 */
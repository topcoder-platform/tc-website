/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class PostNotAllowedException extends NNTPException
/*    */ {
/*    */   private static final int CODE = 440;
/* 23 */   private static final NNTPResponse RESPONSE = new StaticNNTPResponse(440, "posting not allowed");
/*    */ 
/*    */   public PostNotAllowedException()
/*    */   {
/* 30 */     this.response = RESPONSE;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.PostNotAllowedException
 * JD-Core Version:    0.6.2
 */
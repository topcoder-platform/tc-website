/*    */ package com.jivesoftware.forum.nntp.spi;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ public class UUBeginIterator extends PeekIterator
/*    */ {
/*    */   public UUBeginIterator(Iterator itr)
/*    */   {
/* 30 */     super(itr);
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 40 */     String name = null;
/* 41 */     boolean next = super.hasNext();
/* 42 */     if (next) {
/* 43 */       String line = (String)super.peek();
/* 44 */       name = MimeTools.detectUuencodedStart(line);
/*    */     }
/* 46 */     return name;
/*    */   }
/*    */ 
/*    */   public String getHeader()
/*    */   {
/* 57 */     String header = null;
/* 58 */     boolean next = super.hasNext();
/* 59 */     if (next) {
/* 60 */       header = (String)super.peek();
/*    */     }
/* 62 */     return header;
/*    */   }
/*    */ 
/*    */   public boolean hasNext()
/*    */   {
/* 71 */     boolean next = super.hasNext();
/* 72 */     if (next) {
/* 73 */       String line = (String)super.peek();
/* 74 */       if (MimeTools.detectUuencodedStart(line) != null) {
/* 75 */         next = false;
/*    */       }
/*    */     }
/* 78 */     return next;
/*    */   }
/*    */ 
/*    */   public Object next() {
/* 82 */     Object next = super.next();
/* 83 */     if (MimeTools.detectUuencodedStart((String)next) != null) {
/* 84 */       throw new NoSuchElementException();
/*    */     }
/* 86 */     return next;
/*    */   }
/*    */ 
/*    */   public Object peek() {
/* 90 */     String line = (String)super.peek();
/* 91 */     if (MimeTools.detectUuencodedStart(line) != null) {
/* 92 */       throw new NoSuchElementException();
/*    */     }
/* 94 */     return line;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.UUBeginIterator
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.nntp.spi;
/*    */ 
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.forum.net.Connection;
/*    */ import com.jivesoftware.forum.net.spi.AbstractConnectionManager;
/*    */ import com.jivesoftware.forum.nntp.SessionAlreadyExistsException;
/*    */ import com.jivesoftware.forum.nntp.SessionManager;
/*    */ 
/*    */ public class NNTPConnectionManager extends AbstractConnectionManager
/*    */ {
/*    */   private SessionManager sessionManager;
/*    */ 
/*    */   public NNTPConnectionManager(SessionManager sessionManager)
/*    */   {
/* 44 */     this.sessionManager = sessionManager;
/*    */   }
/*    */ 
/*    */   public void addConnection(Connection con) {
/* 48 */     if (!this.sessionManager.isSession(con)) {
/*    */       try {
/* 50 */         this.sessionManager.createSession(con);
/*    */       }
/*    */       catch (SessionAlreadyExistsException e) {
/* 53 */         Log.error("Session already exists", e);
/*    */       }
/*    */     }
/* 56 */     super.addConnection(con);
/*    */   }
/*    */ 
/*    */   public void removeConnection(Connection conn) throws IllegalStateException {
/* 60 */     super.removeConnection(conn);
/* 61 */     this.sessionManager.removeSession(conn);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.NNTPConnectionManager
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.JiveManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.forum.net.Connection;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import com.tangosol.net.Invocable;
/*     */ import com.tangosol.net.InvocationService;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.ConcurrentHashMap;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.TimerTask;
/*     */ 
/*     */ public class SessionManager
/*     */   implements JiveManager
/*     */ {
/*     */   public static final int MODE_ALWAYS_REQUIRE_LOGIN = 0;
/*     */   public static final int MODE_USE_PERMISSIONS = 1;
/*     */   public static final int MODE_NEVER_REQUIRE_LOGIN = 2;
/*  56 */   private Map sessions = new ConcurrentHashMap();
/*     */   private boolean anonymousReadAllowed;
/*     */   private int postPermissionMode;
/*     */   private long sessionTimeout;
/*     */   private long sessionPeriod;
/*  65 */   private TimerTask sessionCheckTask = null;
/*     */   private boolean readTrackingEnabled;
/*     */   private static final long DEFAULT_TIMEOUT = 1800000L;
/*     */   private static final long DEFAULT_SESSION_PERIOD = 30000L;
/*  73 */   private boolean initialized = false;
/*     */ 
/*  75 */   private static SessionManager instance = new SessionManager();
/*     */ 
/*     */   public static SessionManager getInstance()
/*     */   {
/*  83 */     return instance;
/*     */   }
/*     */ 
/*     */   private SessionManager()
/*     */   {
/*  90 */     loadConfig();
/*     */   }
/*     */ 
/*     */   public synchronized void initialize() {
/*  94 */     if (!this.initialized) {
/*  95 */       this.initialized = true;
/*  96 */       scheduleSessionChecker();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isSession(Connection conn)
/*     */   {
/* 107 */     return this.sessions.containsKey(conn);
/*     */   }
/*     */ 
/*     */   public Session getSession(Connection con)
/*     */     throws SessionNotFoundException
/*     */   {
/* 119 */     Session session = (Session)this.sessions.get(con);
/*     */ 
/* 121 */     if (session == null) {
/* 122 */       throw new SessionNotFoundException();
/*     */     }
/* 124 */     return session;
/*     */   }
/*     */ 
/*     */   public Session createSession(Connection con)
/*     */     throws SessionAlreadyExistsException
/*     */   {
/* 135 */     Session session = null;
/* 136 */     if (isSession(con))
/* 137 */       throw new SessionAlreadyExistsException();
/*     */     try
/*     */     {
/* 140 */       session = new Session(this, con);
/*     */     }
/*     */     catch (Exception e) {
/*     */       try {
/* 144 */         if (!con.isClosed()) {
/* 145 */           con.close();
/* 146 */           return null;
/*     */         }
/*     */       } catch (IOException e1) {
/* 149 */         Log.error("Could not close connection", e1);
/*     */       }
/*     */     }
/* 152 */     this.sessions.put(con, session);
/*     */ 
/* 154 */     boolean postingOK = false;
/*     */     try {
/* 156 */       postingOK = session.isPostingOK();
/* 157 */       if (postingOK) {
/* 158 */         NNTPParser.WELCOME_POST.send(con);
/*     */       }
/*     */       else
/* 161 */         NNTPParser.WELCOME_NO_POST.send(con);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 165 */       Log.error("Unable to respond using " + (postingOK ? "WELCOME_POST" : "WELCOME_NO_POST"), e);
/*     */       try {
/* 167 */         if (!con.isClosed()) con.close(); 
/*     */       } catch (IOException e1) { Log.error("Could not close connection", e1); }
/*     */ 
/*     */     }
/* 171 */     return session;
/*     */   }
/*     */ 
/*     */   public void removeSession(Connection con)
/*     */   {
/* 180 */     this.sessions.remove(con);
/*     */   }
/*     */ 
/*     */   public long getSessionTimeout()
/*     */   {
/* 190 */     return this.sessionTimeout;
/*     */   }
/*     */ 
/*     */   public void setSessionTimeout(long timeout)
/*     */   {
/* 199 */     this.sessionTimeout = timeout;
/* 200 */     JiveGlobals.setJiveProperty("nntp.session.timeout", Long.toString(this.sessionTimeout));
/*     */ 
/* 202 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   public long getSessionCheckPeriod()
/*     */   {
/* 215 */     return this.sessionPeriod;
/*     */   }
/*     */ 
/*     */   public void setSessionCheckPeriod(long period)
/*     */   {
/* 224 */     this.sessionPeriod = period;
/* 225 */     JiveGlobals.setJiveProperty("nntp.session.checkPeriod", Long.toString(this.sessionPeriod));
/* 226 */     if (this.initialized) {
/* 227 */       if (this.sessionCheckTask != null) {
/* 228 */         this.sessionCheckTask.cancel();
/*     */       }
/* 230 */       scheduleSessionChecker();
/*     */     }
/*     */ 
/* 233 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   public boolean isReadTrackingEnabled()
/*     */   {
/* 242 */     return this.readTrackingEnabled;
/*     */   }
/*     */ 
/*     */   public void setReadTrackingEnabled(boolean readTrackingEnabled)
/*     */   {
/* 251 */     this.readTrackingEnabled = readTrackingEnabled;
/* 252 */     JiveGlobals.setJiveProperty("nntp.session.readTrackingEnabled", String.valueOf(readTrackingEnabled));
/*     */ 
/* 255 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   private void scheduleSessionChecker() {
/* 259 */     this.sessionCheckTask = TaskEngine.scheduleTask(new Runnable() {
/*     */       public void run() {
/* 261 */         long now = System.currentTimeMillis();
/* 262 */         LinkedList idleSessions = new LinkedList();
/*     */         try {
/* 264 */           Iterator sessionIter = SessionManager.this.sessions.values().iterator();
/* 265 */           while (sessionIter.hasNext()) {
/* 266 */             Session session = (Session)sessionIter.next();
/* 267 */             if (now - session.getCommandMonitor().getLastSampleDate().getTime() > SessionManager.this.sessionTimeout)
/*     */             {
/* 271 */               idleSessions.add(session);
/*     */             }
/*     */           }
/*     */         }
/*     */         finally {
/*     */         }
/* 277 */         while (!idleSessions.isEmpty())
/*     */           try {
/* 279 */             ((Session)idleSessions.removeFirst()).quit();
/*     */           } catch (Exception e) {
/* 281 */             Log.error("Closing idle session", e);
/*     */           }
/*     */       }
/*     */     }
/*     */     , this.sessionPeriod, this.sessionPeriod);
/*     */   }
/*     */ 
/*     */   public boolean isAnonymousReadAllowed()
/*     */   {
/* 301 */     return this.anonymousReadAllowed;
/*     */   }
/*     */ 
/*     */   public void setAnonymousReadAllowed(boolean allowed)
/*     */   {
/* 311 */     this.anonymousReadAllowed = allowed;
/* 312 */     JiveGlobals.setJiveProperty("nntp.anonymousReadAllowed", String.valueOf(allowed));
/*     */ 
/* 314 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   public int getPostPermissionMode()
/*     */   {
/* 326 */     return this.postPermissionMode;
/*     */   }
/*     */ 
/*     */   public void setPostPermissionMode(int permissionMode)
/*     */   {
/* 338 */     this.postPermissionMode = permissionMode;
/* 339 */     JiveGlobals.setJiveProperty("nntp.postPermissionMode", String.valueOf(permissionMode));
/*     */ 
/* 341 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   private void loadConfig()
/*     */   {
/* 348 */     this.anonymousReadAllowed = JiveGlobals.getJiveBooleanProperty("nntp.anonymousReadAllowed", true);
/* 349 */     this.postPermissionMode = JiveGlobals.getJiveIntProperty("nntp.postPermissionMode", 1);
/*     */ 
/* 351 */     this.sessionTimeout = JiveGlobals.getJiveIntProperty("nntp.session.timeout", 1800000);
/*     */ 
/* 353 */     this.sessionPeriod = JiveGlobals.getJiveIntProperty("nntp.session.checkPeriod", 30000);
/*     */ 
/* 355 */     this.readTrackingEnabled = JiveGlobals.getJiveBooleanProperty("nntp.session.readTrackingEnabled");
/*     */   }
/*     */ 
/*     */   private static class ReloadConfigTask
/*     */     implements Invocable
/*     */   {
/*     */     public void init(InvocationService invocationService)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 370 */       SessionManager.getInstance().loadConfig();
/*     */     }
/*     */ 
/*     */     public Object getResult() {
/* 374 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.SessionManager
 * JD-Core Version:    0.6.2
 */
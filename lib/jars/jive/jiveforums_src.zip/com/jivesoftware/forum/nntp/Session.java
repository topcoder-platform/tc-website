/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import com.jivesoftware.base.stats.ReadStatsManager;
/*     */ import com.jivesoftware.base.stats.ReadStatsManagerFactory;
/*     */ import com.jivesoftware.base.util.CountryLookup;
/*     */ import com.jivesoftware.forum.net.Connection;
/*     */ import com.jivesoftware.forum.nntp.spi.ArticlePointerImpl;
/*     */ import com.jivesoftware.forum.nntp.spi.CommandMonitorImpl;
/*     */ import com.jivesoftware.forum.nntp.spi.ForumSession;
/*     */ import com.jivesoftware.forum.stats.NNTPReadStatSession;
/*     */ import com.jivesoftware.util.StringUtils;
/*     */ import com.maxmind.geoip.Country;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Session
/*     */ {
/*     */   private ArticlePointer articlePointer;
/*     */   private ForumSession forumSession;
/*     */   private NNTPParser parser;
/*     */   private Connection connection;
/*  49 */   private final boolean postingOK = true;
/*     */ 
/*  51 */   private boolean authenticated = false;
/*     */ 
/*  53 */   private String username = null;
/*     */ 
/*  55 */   private NNTPServerConfig config = NNTPServerConfig.getInstance();
/*     */ 
/*  57 */   private CommandMonitor cmdMonitor = new CommandMonitorImpl();
/*     */ 
/*  59 */   private NNTPReadStatSession readStatSession = null;
/*     */ 
/*     */   public Session(SessionManager sessionManager, Connection conn)
/*     */   {
/*  68 */     String IP = conn.getSocket().getInetAddress().toString();
/*  69 */     if (IP.startsWith("/")) {
/*  70 */       IP = IP.substring(1, IP.length());
/*     */     }
/*     */ 
/*  73 */     if (sessionManager.isReadTrackingEnabled()) {
/*  74 */       String countryCode = null;
/*  75 */       Country country = CountryLookup.getCountry(IP);
/*  76 */       if (country != null) {
/*  77 */         countryCode = country.getCode();
/*     */       }
/*  79 */       String visitorID = StringUtils.randomString(16);
/*  80 */       this.readStatSession = new NNTPReadStatSession(visitorID, new Date(), IP, countryCode);
/*  81 */       ReadStatsManagerFactory.getInstance().addReadStatSession(this.readStatSession);
/*     */     }
/*  83 */     this.connection = conn;
/*  84 */     this.forumSession = new ForumSession(this.readStatSession);
/*  85 */     this.articlePointer = new ArticlePointerImpl(this.forumSession);
/*  86 */     this.parser = new NNTPParser(sessionManager, this, this.connection);
/*     */   }
/*     */ 
/*     */   NNTPReadStatSession getReadStatSession() {
/*  90 */     return this.readStatSession;
/*     */   }
/*     */ 
/*     */   public NNTPParser getParser()
/*     */   {
/*  99 */     return this.parser;
/*     */   }
/*     */ 
/*     */   public ArticlePointer getArticlePointer()
/*     */   {
/* 112 */     return this.articlePointer;
/*     */   }
/*     */ 
/*     */   public void quit()
/*     */     throws IOException
/*     */   {
/* 132 */     this.connection.close();
/*     */ 
/* 134 */     if (this.readStatSession != null)
/* 135 */       this.readStatSession.setEndDate(new Date());
/*     */   }
/*     */ 
/*     */   public boolean isPostingOK()
/*     */   {
/* 148 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isAuthenticated()
/*     */   {
/* 157 */     return this.authenticated;
/*     */   }
/*     */ 
/*     */   public void setUser(String name)
/*     */   {
/* 168 */     this.username = name;
/*     */   }
/*     */ 
/*     */   public boolean setPassword(String password)
/*     */   {
/* 180 */     boolean auth = false;
/* 181 */     if (this.username != null) {
/* 182 */       auth = this.forumSession.authenticate(this.username, password);
/* 183 */       this.authenticated = true;
/*     */     }
/* 185 */     this.username = null;
/* 186 */     return auth;
/*     */   }
/*     */ 
/*     */   public Iterator getNewNews(NewsGroupFilter filter)
/*     */     throws NoGroupSelectedException, NoPermissionException, ArticleNotFoundException
/*     */   {
/*     */     Iterator newsIter;
/*     */     Iterator newsIter;
/* 256 */     if (this.config.isEmptyNewNews()) {
/* 257 */       newsIter = Collections.EMPTY_LIST.iterator();
/*     */     }
/*     */     else {
/* 260 */       newsIter = this.forumSession.getArticles(filter, ArticleFilter.ALL_ARTICLE_FILTER);
/*     */     }
/* 262 */     return newsIter;
/*     */   }
/*     */ 
/*     */   public Iterator getList(NewsGroupFilter filter)
/*     */     throws NoPermissionException, NewsGroupNotFoundException
/*     */   {
/*     */     Iterator groupIter;
/*     */     Iterator groupIter;
/* 350 */     if (this.config.isEmptyList()) {
/* 351 */       String groupName = this.config.getEmptyListGroupName();
/*     */       Iterator groupIter;
/* 352 */       if (groupName.trim().length() > 0) {
/* 353 */         groupIter = Arrays.asList(new Object[] { this.forumSession.getNewsGroup(groupName) }).iterator();
/*     */       }
/*     */       else
/*     */       {
/* 357 */         groupIter = Collections.EMPTY_LIST.iterator();
/*     */       }
/*     */     }
/*     */     else {
/* 361 */       groupIter = this.forumSession.getNewsGroups(filter);
/*     */     }
/* 363 */     return groupIter;
/*     */   }
/*     */ 
/*     */   public CommandMonitor getCommandMonitor()
/*     */   {
/* 373 */     return this.cmdMonitor;
/*     */   }
/*     */ 
/*     */   public void postArticle(Iterator article)
/*     */     throws PostFailedException, PostRejectedException, PostNotAllowedException
/*     */   {
/*     */     try
/*     */     {
/* 396 */       this.forumSession.post(article);
/*     */     }
/*     */     catch (NoPermissionException e) {
/* 399 */       throw new PostNotAllowedException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.Session
 * JD-Core Version:    0.6.2
 */
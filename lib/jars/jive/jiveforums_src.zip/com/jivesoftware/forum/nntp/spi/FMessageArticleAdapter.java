/*     */ package com.jivesoftware.forum.nntp.spi;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.database.DbForumMessage;
/*     */ import com.jivesoftware.forum.nntp.Article;
/*     */ import com.jivesoftware.forum.nntp.MessageID;
/*     */ import com.jivesoftware.forum.nntp.NNTPResponseBuffer;
/*     */ import com.jivesoftware.forum.nntp.NNTPServerConfig;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Iterator;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ 
/*     */ public class FMessageArticleAdapter
/*     */   implements Article
/*     */ {
/*     */   private DbForumMessage message;
/*     */   private static final int CHAR_PER_LINE = 50;
/*     */   private static final String MAGIC_BOUNDARY = ".zeB8CwDOH5aMJzMl";
/*     */   private static final String BOUNDARY_START = "JivePart=_";
/*     */   private static final int MIN_LINE_COUNT = 8;
/*  88 */   private static DateFormat DATE_FORMAT = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z");
/*     */ 
/*  79 */   private String mimeBoundary = null;
/*     */ 
/*  83 */   private NNTPServerConfig serverConfig = NNTPServerConfig.getInstance();
/*     */ 
/*  85 */   private static Pattern removeTabsAndNewlines = Pattern.compile("[\t\r\n]");
/*     */ 
/*     */   public FMessageArticleAdapter(DbForumMessage msg)
/*     */   {
/*  97 */     this.message = msg;
/*     */   }
/*     */ 
/*     */   public int getNumber() {
/* 101 */     return this.message.getForumIndex();
/*     */   }
/*     */ 
/*     */   public String getMessageID()
/*     */   {
/* 114 */     return MessageID.toMessageID(this.message.getID());
/*     */   }
/*     */ 
/*     */   public String getSubject() {
/* 118 */     String encodedSubject = this.message.getUnfilteredSubject();
/*     */     try {
/* 120 */       if ("".equals(encodedSubject)) {
/* 121 */         encodedSubject = " ";
/*     */       }
/*     */       else
/*     */       {
/* 126 */         encodedSubject = removeTabsAndNewlines.matcher(encodedSubject).replaceAll(" ");
/* 127 */         encodedSubject = MimeUtility.encodeText(encodedSubject, this.serverConfig.getMimeCharacterEncoding(), null);
/*     */       }
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/* 132 */       encodedSubject = " ";
/* 133 */       Log.error("Could not encode", e);
/*     */     }
/* 135 */     return encodedSubject;
/*     */   }
/*     */ 
/*     */   public String getAuthor()
/*     */   {
/* 146 */     StringBuffer author = new StringBuffer();
/* 147 */     if ((!this.message.isAnonymous()) && (this.message.getUser() != null)) {
/* 148 */       User user = this.message.getUser();
/* 149 */       if ((user.isNameVisible()) && (user.getName() != null)) {
/* 150 */         author.append(user.getName());
/*     */       }
/*     */       else {
/* 153 */         author.append(user.getUsername());
/*     */       }
/* 155 */       if ((user.isEmailVisible()) && (user.getEmail() != null)) {
/* 156 */         author.append(" <").append(user.getEmail()).append(">");
/*     */       }
/*     */       else {
/* 159 */         author.append(" <>");
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 165 */       String name = this.message.getProperty("name");
/* 166 */       String email = this.message.getProperty("email");
/* 167 */       if ((name == null) && (email == null)) {
/* 168 */         author.append(this.serverConfig.getAnonymousUsername());
/*     */       }
/*     */       else {
/* 171 */         if (name != null) {
/* 172 */           author.append(name);
/*     */         }
/* 174 */         if (email != null) {
/* 175 */           author.append(" <").append(email).append(">");
/*     */         }
/*     */         else {
/* 178 */           author.append(" <>");
/*     */         }
/*     */       }
/*     */     }
/* 182 */     String encodedAuthor = author.toString();
/*     */     try {
/* 184 */       encodedAuthor = MimeUtility.encodeText(encodedAuthor, this.serverConfig.getMimeCharacterEncoding(), null);
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/* 188 */       encodedAuthor = this.serverConfig.getAnonymousUsername();
/* 189 */       Log.error("Could not encode", e);
/*     */     }
/* 191 */     return encodedAuthor;
/*     */   }
/*     */ 
/*     */   public String getDate() {
/* 195 */     return DATE_FORMAT.format(this.message.getModificationDate());
/*     */   }
/*     */ 
/*     */   public String getReferences()
/*     */   {
/* 205 */     long parentMessageID = this.message.getParentMessageID();
/*     */     String ref;
/*     */     String ref;
/* 207 */     if (parentMessageID == -1L) {
/* 208 */       ref = " ";
/*     */     }
/*     */     else {
/* 211 */       ref = MessageID.toMessageID(parentMessageID);
/*     */     }
/* 213 */     return ref;
/*     */   }
/*     */ 
/*     */   public String getNewsGroups() {
/* 217 */     return this.message.getForum().getNNTPName();
/*     */   }
/*     */ 
/*     */   public int getByteCount() {
/* 221 */     int bytes = (getHead().length() + 4 + this.message.getUnfilteredBody().length()) * 2;
/*     */ 
/* 223 */     if (NNTPServerConfig.getInstance().isAttachmentsAllowed()) {
/* 224 */       Iterator attachments = this.message.getAttachments();
/* 225 */       while (attachments.hasNext()) {
/* 226 */         Attachment attachment = (Attachment)attachments.next();
/*     */ 
/* 229 */         bytes = (int)(bytes + attachment.getSize() * 1.33D);
/*     */       }
/*     */     }
/* 232 */     return bytes;
/*     */   }
/*     */ 
/*     */   public int getLineCount()
/*     */   {
/* 237 */     int lines = getByteCount() / 50;
/* 238 */     if (lines < 8) {
/* 239 */       lines = 8;
/*     */     }
/* 241 */     return lines;
/*     */   }
/*     */ 
/*     */   public void sendArticle(NNTPResponseBuffer response)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 257 */       response.appendBulkText(getHead());
/* 258 */       response.endLine();
/* 259 */       response.endLine();
/* 260 */       sendBody(response);
/* 261 */       response.endLine();
/*     */     }
/*     */     catch (Exception e) {
/* 264 */       e.printStackTrace();
/* 265 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sendBody(NNTPResponseBuffer response)
/*     */     throws IOException
/*     */   {
/* 281 */     if ((this.message.getAttachmentCount() > 0) && (this.serverConfig.isAttachmentsAllowed())) {
/* 282 */       addBodyResponse(response);
/* 283 */       Iterator attachments = this.message.getAttachments();
/* 284 */       int bufferSize = this.serverConfig.getWriteBufferSize();
/* 285 */       while (attachments.hasNext()) {
/* 286 */         Attachment att = (Attachment)attachments.next();
/* 287 */         addAttachmentResponse(response, bufferSize, att);
/*     */       }
/* 289 */       response.appendLine("--");
/*     */     }
/*     */     else {
/* 292 */       String body = this.message.getUnfilteredBody();
/*     */       try {
/* 294 */         ByteArrayOutputStream bout = new ByteArrayOutputStream();
/* 295 */         OutputStream out = MimeUtility.encode(bout, "quoted-printable");
/* 296 */         out.write(body.getBytes(this.serverConfig.getMimeCharacterEncoding()));
/* 297 */         body = new String(bout.toByteArray(), "US-ASCII");
/*     */       }
/*     */       catch (MessagingException e)
/*     */       {
/* 302 */         Log.error("Unable to encode NNTP message body", e);
/*     */       }
/*     */ 
/* 305 */       response.appendBulkText(body);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void addAttachmentResponse(NNTPResponseBuffer response, int bufferSize, Attachment att)
/*     */     throws IOException
/*     */   {
/* 320 */     addAttachmentHeaderResponse(response, att);
/*     */ 
/* 322 */     InputStream data = new BufferedInputStream(att.getData());
/*     */     try {
/* 324 */       data = new Base64.InputStream(data, 1);
/* 325 */       byte[] buffer = new byte[bufferSize];
/* 326 */       int length = data.read(buffer);
/* 327 */       while (length != -1) {
/* 328 */         response.append(new String(buffer, 0, length));
/* 329 */         length = data.read(buffer);
/*     */       }
/*     */     }
/*     */     finally {
/* 333 */       data.close();
/*     */     }
/* 335 */     response.endLine();
/* 336 */     response.endLine();
/* 337 */     response.append("--").append(this.mimeBoundary);
/*     */   }
/*     */ 
/*     */   private void addBodyResponse(NNTPResponseBuffer response)
/*     */     throws IOException
/*     */   {
/* 347 */     generateBoundary();
/* 348 */     response.appendLine(this.serverConfig.getMimeIntro());
/* 349 */     response.append("--").appendLine(this.mimeBoundary);
/*     */ 
/* 351 */     if (this.message.isHtml()) {
/* 352 */       response.append("Content-Type: text/html; charset=\"");
/*     */     }
/*     */     else {
/* 355 */       response.append("Content-Type: text/plain; charset=\"");
/*     */     }
/* 357 */     response.append(this.serverConfig.getMimeCharacterEncoding()).appendLine("\"");
/* 358 */     response.appendLine("Content-Transfer-Encoding: quoted-printable");
/* 359 */     response.endLine();
/* 360 */     String body = this.message.getUnfilteredBody();
/*     */     try {
/* 362 */       ByteArrayOutputStream bout = new ByteArrayOutputStream();
/* 363 */       OutputStream out = MimeUtility.encode(bout, "quoted-printable");
/* 364 */       out.write(body.getBytes(this.serverConfig.getMimeCharacterEncoding()));
/* 365 */       body = new String(bout.toByteArray(), "US-ASCII");
/*     */     }
/*     */     catch (MessagingException e)
/*     */     {
/* 370 */       Log.error("Unable to encode NNTP message body", e);
/*     */     }
/* 372 */     response.appendBulkText(body);
/* 373 */     response.endLine();
/* 374 */     response.endLine();
/* 375 */     response.append("--").append(this.mimeBoundary);
/*     */   }
/*     */ 
/*     */   private void addAttachmentHeaderResponse(NNTPResponseBuffer response, Attachment att)
/*     */     throws IOException
/*     */   {
/* 388 */     response.endLine();
/* 389 */     response.append("Content-Type: ");
/* 390 */     response.append(att.getContentType()).appendLine(";");
/* 391 */     response.append("  name=\"");
/* 392 */     response.append(att.getName()).appendLine("\"");
/* 393 */     response.appendLine("Content-Transfer-Encoding: base64");
/* 394 */     response.appendLine("Content-Disposition: attachment;");
/* 395 */     response.append("  filename=\"").append(att.getName()).appendLine("\"");
/* 396 */     response.endLine();
/*     */   }
/*     */ 
/*     */   public String getHead()
/*     */   {
/* 406 */     StringBuffer hdr = new StringBuffer();
/* 407 */     addHead(hdr, "From", getAuthor());
/* 408 */     addHead(hdr, "Subject", getSubject());
/* 409 */     addHead(hdr, "Newsgroups", getNewsGroups());
/*     */ 
/* 411 */     if ((this.serverConfig.isAttachmentsAllowed()) && (this.message.getAttachmentCount() > 0)) {
/* 412 */       addMIMEMainHeaders(hdr);
/*     */     }
/*     */     else
/*     */     {
/* 417 */       StringBuffer contentTypeBuffer = new StringBuffer();
/* 418 */       if (this.message.isHtml()) {
/* 419 */         contentTypeBuffer.append("text/html;");
/*     */       }
/*     */       else {
/* 422 */         contentTypeBuffer.append("text/plain;");
/*     */       }
/* 424 */       contentTypeBuffer.append(" charset=\"");
/* 425 */       contentTypeBuffer.append(this.serverConfig.getMimeCharacterEncoding());
/* 426 */       contentTypeBuffer.append("\"");
/* 427 */       addHead(hdr, "Content-Type", contentTypeBuffer.toString());
/* 428 */       addHead(hdr, "Content-Transfer-Encoding", "quoted-printable");
/*     */     }
/* 430 */     addHead(hdr, "Message-ID", getMessageID());
/* 431 */     addHead(hdr, "References", getReferences());
/*     */     Iterator iter;
/*     */     try
/*     */     {
/* 437 */       for (iter = this.message.getPropertyNames(); iter.hasNext(); ) {
/* 438 */         String propName = (String)iter.next();
/* 439 */         if (propName.startsWith("nttp.xheader")) {
/* 440 */           String name = propName.substring("nttp.xheader.".length(), propName.length());
/*     */ 
/* 442 */           String value = this.message.getUnfilteredProperty(propName);
/* 443 */           addHead(hdr, name, value);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */ 
/* 451 */     hdr.append("Date: ").append(getDate());
/*     */ 
/* 453 */     return hdr.toString();
/*     */   }
/*     */ 
/*     */   private void addMIMEMainHeaders(StringBuffer hdr)
/*     */   {
/* 462 */     generateBoundary();
/* 463 */     addHead(hdr, "MIME-Version", "1.0");
/* 464 */     StringBuffer line = new StringBuffer("multipart/mixed; boundary=\"");
/* 465 */     line.append(this.mimeBoundary);
/* 466 */     line.append('"');
/* 467 */     addHead(hdr, "Content-Type", line.toString());
/*     */   }
/*     */ 
/*     */   private void addHead(StringBuffer hdr, String name, String value)
/*     */   {
/* 479 */     if (value.length() + name.length() + 2 > this.serverConfig.getMaxHeaderLength()) {
/* 480 */       hdr.append(name).append(":");
/* 481 */       int lineLength = name.length() + 2;
/* 482 */       StringTokenizer tokenizer = new StringTokenizer(value);
/* 483 */       while (tokenizer.hasMoreTokens()) {
/* 484 */         String token = tokenizer.nextToken();
/* 485 */         if (lineLength + token.length() > this.serverConfig.getMaxHeaderLength()) {
/* 486 */           hdr.append("\r\n");
/* 487 */           hdr.append("  ").append(token);
/* 488 */           lineLength = 1 + token.length();
/*     */         }
/*     */         else {
/* 491 */           hdr.append(" ").append(token);
/* 492 */           lineLength += token.length() + 1;
/*     */         }
/*     */       }
/* 495 */       hdr.append("\r\n");
/*     */     }
/*     */     else {
/* 498 */       hdr.append(name).append(": ");
/* 499 */       hdr.append(value).append("\r\n");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void generateBoundary()
/*     */   {
/* 509 */     if (this.mimeBoundary == null) {
/* 510 */       StringBuffer boundary = new StringBuffer("JivePart=_");
/* 511 */       boundary.append(Long.toHexString(this.message.getID()));
/*     */ 
/* 513 */       boundary.append(".zeB8CwDOH5aMJzMl");
/* 514 */       this.mimeBoundary = boundary.toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.FMessageArticleAdapter
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum.nntp;

import com.jivesoftware.forum.net.Monitor;

public abstract interface CommandMonitor extends Monitor
{
  public abstract void addSample(String[] paramArrayOfString, NNTPResponse paramNNTPResponse, long paramLong1, long paramLong2);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.CommandMonitor
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class ArticleNotSelectedException extends NNTPException
/*    */ {
/*    */   private static final int CODE = 420;
/* 25 */   private static final NNTPResponse NOT_SELECTED = new StaticNNTPResponse(420, "no current article has been selected");
/*    */ 
/*    */   public ArticleNotSelectedException()
/*    */   {
/* 32 */     this.response = NOT_SELECTED;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.ArticleNotSelectedException
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.nntp.spi;
/*    */ 
/*    */ import com.jivesoftware.forum.net.spi.BasicTransientMonitor;
/*    */ import com.jivesoftware.forum.nntp.CommandMonitor;
/*    */ import com.jivesoftware.forum.nntp.NNTPResponse;
/*    */ 
/*    */ public class CommandMonitorImpl extends BasicTransientMonitor
/*    */   implements CommandMonitor
/*    */ {
/*    */   public void addSample(String[] cmdParts, NNTPResponse response, long startTime, long stopTime)
/*    */   {
/* 42 */     addSample(1L, startTime, stopTime);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.CommandMonitorImpl
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum.nntp;

public abstract interface NewsGroup
{
  public abstract long getID();

  public abstract String getName();

  public abstract String getDescription();

  public abstract boolean isModerated();

  public abstract int getFirstArticleNumber();

  public abstract int getLastArticleNumber();

  public abstract int getArticleCount();

  public abstract Article getArticle(int paramInt)
    throws ArticleNotFoundException;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NewsGroup
 * JD-Core Version:    0.6.2
 */
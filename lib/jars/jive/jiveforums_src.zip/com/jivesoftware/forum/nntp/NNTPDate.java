/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public class NNTPDate
/*     */ {
/*     */   private static SimpleDateFormat DATE_FORMAT_GMT;
/*  34 */   private static SimpleDateFormat DATE_FORMAT_LOCAL = new SimpleDateFormat("yyMMddHHmmss");
/*     */   private Date date;
/*     */ 
/*     */   public NNTPDate(Date newDate)
/*     */   {
/*  48 */     this.date = newDate;
/*     */   }
/*     */ 
/*     */   public static NNTPDate parseDate(String dateString)
/*     */     throws SyntaxException
/*     */   {
/*     */     try
/*     */     {
/*  61 */       return new NNTPDate(DATE_FORMAT_LOCAL.parse(dateString));
/*     */     } catch (ParseException e) {
/*     */     }
/*  64 */     throw new SyntaxException();
/*     */   }
/*     */ 
/*     */   public static NNTPDate parseGMTDate(String dateString)
/*     */     throws SyntaxException
/*     */   {
/*     */     try
/*     */     {
/*  79 */       return new NNTPDate(DATE_FORMAT_GMT.parse(dateString));
/*     */     } catch (ParseException e) {
/*     */     }
/*  82 */     throw new SyntaxException();
/*     */   }
/*     */ 
/*     */   public static NNTPDate parseDateTimeDist(String[] cmdParts, int index, NewsGroupFilter filter)
/*     */     throws SyntaxException
/*     */   {
/*     */     NNTPDate parsedDate;
/* 103 */     if ((cmdParts.length > index + 2) && ("GMT".equalsIgnoreCase(cmdParts[(index + 2)]))) {
/* 104 */       NNTPDate parsedDate = parseGMTDate(cmdParts[index] + cmdParts[(index + 1)]);
/* 105 */       if (cmdParts.length > index + 3)
/* 106 */         filter.addDistributionList(cmdParts[(index + 3)]);
/*     */     }
/*     */     else
/*     */     {
/* 110 */       parsedDate = parseDate(cmdParts[index] + cmdParts[(index + 1)]);
/* 111 */       if (cmdParts.length > index + 2) {
/* 112 */         filter.addDistributionList(cmdParts[(index + 3)]);
/*     */       }
/*     */     }
/* 115 */     return parsedDate;
/*     */   }
/*     */ 
/*     */   public Date toDate()
/*     */   {
/* 124 */     return this.date;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 133 */     return DATE_FORMAT_LOCAL.format(this.date);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  35 */     DATE_FORMAT_GMT = new SimpleDateFormat("yyMMddHHmmss");
/*  36 */     DATE_FORMAT_GMT.setTimeZone(TimeZone.getTimeZone("GMT"));
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NNTPDate
 * JD-Core Version:    0.6.2
 */
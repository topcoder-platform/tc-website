/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class OverviewFormatResponse
/*    */ {
/* 34 */   public static final NNTPResponse RESPONSE = new StaticNNTPResponse(215, "Order of fields in overview database.\r\nSubject:\r\nFrom:\r\nDate:\r\nMessage-ID:\r\nReferences:\r\nBytes:\r\nLines:\r\n.");
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.OverviewFormatResponse
 * JD-Core Version:    0.6.2
 */
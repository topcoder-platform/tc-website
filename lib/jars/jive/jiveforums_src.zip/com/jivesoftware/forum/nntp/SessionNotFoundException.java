package com.jivesoftware.forum.nntp;

public class SessionNotFoundException extends Exception
{
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.SessionNotFoundException
 * JD-Core Version:    0.6.2
 */
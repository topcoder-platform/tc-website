/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.forum.net.Connection;
/*     */ import com.jivesoftware.forum.nntp.spi.DotIterator;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class NNTPParser
/*     */ {
/*  32 */   public static final NNTPResponse WELCOME_POST = new StaticNNTPResponse(200, "Jive News: server ready - posting allowed");
/*     */ 
/*  35 */   public static final NNTPResponse WELCOME_NO_POST = new StaticNNTPResponse(201, "Jive News: server ready - no posting allowed");
/*     */ 
/*  39 */   private static final NNTPResponse QUIT = new StaticNNTPResponse(205, "Jive NNTP/Forums closing connection. Goodbye.");
/*     */ 
/*  41 */   private static final NNTPResponse SLAVE = new StaticNNTPResponse(202, "slave status noted");
/*     */ 
/*  43 */   private static final NNTPResponse AUTH_REQUIRED = new StaticNNTPResponse(480, "Authentication required");
/*     */ 
/*  45 */   private static final NNTPResponse AUTH_MORE = new StaticNNTPResponse(381, "More authentication information required");
/*     */ 
/*  47 */   private static final NNTPResponse AUTH_ACCEPTED = new StaticNNTPResponse(281, "Authentication accepted");
/*     */ 
/*  49 */   private static final NNTPResponse AUTH_REJECTED = new StaticNNTPResponse(482, "authentication rejected");
/*     */ 
/*  51 */   private static final NNTPResponse NOT_RECOGNIZED = new StaticNNTPResponse(500, "command not recognized");
/*     */ 
/*  54 */   private static final NNTPResponse IHAVE_NOT_WANTED = new StaticNNTPResponse(435, "article not wanted - do not send it");
/*     */ 
/*  56 */   private static final NNTPResponse POST_OK = new StaticNNTPResponse(240, "article posted ok");
/*     */ 
/*  60 */   private static final NNTPResponse POST_SEND = new StaticNNTPResponse(340, "send article to be posted. End with <CR-LF>.<CR-LF>");
/*     */ 
/*  64 */   private static final NNTPResponse POST_NOT_ALLOWED = new StaticNNTPResponse(440, "posting not allowed");
/*     */ 
/*  67 */   private static final NNTPResponse NO_NEXT_ARTICLE = new StaticNNTPResponse(421, "no next article in this group");
/*     */ 
/*  69 */   private static final NNTPResponse NO_PREVIOUS_ARTICLE = new StaticNNTPResponse(422, "no previous article in this group");
/*     */ 
/*  73 */   private static Pattern splitter = Pattern.compile("\\s");
/*     */   private Session session;
/*     */   private SessionManager sessionManager;
/*     */   private Connection connection;
/*     */   private ArticlePointer artPointer;
/*     */   private ArticleResponder articleResponder;
/*     */   private CommandMonitor cmdMonitor;
/*  88 */   private PostIterator postIterator = null;
/*     */ 
/*  90 */   private BufferedReader reader = null;
/*     */ 
/*     */   public NNTPParser(SessionManager manager, Session owner, Connection conn)
/*     */   {
/* 103 */     this.sessionManager = manager;
/* 104 */     this.session = owner;
/* 105 */     this.connection = conn;
/* 106 */     this.reader = ((BufferedReader)conn.getReader());
/* 107 */     this.articleResponder = new ArticleResponder(this.connection);
/* 108 */     this.artPointer = this.session.getArticlePointer();
/* 109 */     this.cmdMonitor = this.session.getCommandMonitor();
/*     */   }
/*     */ 
/*     */   public boolean parse()
/*     */     throws IOException
/*     */   {
/* 121 */     long start = System.currentTimeMillis();
/*     */ 
/* 123 */     String line = readLine();
/*     */ 
/* 125 */     if (line == null) {
/* 126 */       if (!this.connection.isClosed()) {
/* 127 */         return false;
/*     */       }
/*     */ 
/* 130 */       return true;
/*     */     }
/*     */ 
/* 133 */     String[] cmdParts = null;
/* 134 */     cmdParts = splitter.split(line.trim());
/*     */ 
/* 136 */     cmdParts[0] = cmdParts[0].toUpperCase().intern();
/*     */     try
/*     */     {
/* 139 */       if (!"".equals(line)) {
/* 140 */         if ((this.session.isAuthenticated()) || (this.sessionManager.isAnonymousReadAllowed()) || ("AUTHINFO" == cmdParts[0]))
/*     */         {
/* 143 */           respond(cmdParts, parseCommand(cmdParts), start);
/*     */         }
/*     */         else
/* 146 */           respond(cmdParts, NoPermissionException.RESPONSE, start);
/*     */       }
/*     */     }
/*     */     catch (NNTPException e)
/*     */     {
/* 151 */       respond(cmdParts, e.getErrorResponse(), start);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 166 */       respond(cmdParts, NOT_RECOGNIZED, start);
/* 167 */       Log.error("Unknown error encountered while parsing", e);
/* 168 */       return false;
/*     */     }
/* 170 */     return true;
/*     */   }
/*     */ 
/*     */   private String readLine()
/*     */     throws IOException
/*     */   {
/* 185 */     StringBuffer command = new StringBuffer();
/*     */     while (true)
/*     */     {
/* 188 */       int c = this.reader.read();
/* 189 */       if (c != 13)
/*     */       {
/* 195 */         if (c == 10) {
/*     */           break;
/*     */         }
/* 198 */         if (c == -1) {
/* 199 */           return null;
/*     */         }
/*     */ 
/* 202 */         command.append((char)c);
/*     */       }
/*     */     }
/* 205 */     return command.toString();
/*     */   }
/*     */ 
/*     */   private void respond(String[] cmdParts, NNTPResponse response, long start)
/*     */     throws IOException
/*     */   {
/* 220 */     if (response != null) {
/* 221 */       response.send(this.connection);
/* 222 */       this.cmdMonitor.addSample(cmdParts, response, start, System.currentTimeMillis());
/*     */     }
/*     */   }
/*     */ 
/*     */   private NNTPResponse parseCommand(String[] cmdParts)
/*     */     throws IOException, NNTPException
/*     */   {
/*     */     NNTPResponse response;
/*     */     NNTPResponse response;
/* 239 */     if ((cmdParts.length == 0) || (cmdParts[0].length() == 0)) {
/* 240 */       response = NOT_RECOGNIZED;
/*     */     }
/*     */     else
/*     */     {
/*     */       NNTPResponse response;
/* 242 */       if ("ARTICLE" == cmdParts[0]) {
/* 243 */         ArticleCommand cmd = ArticleCommand.getCommand(cmdParts, this.artPointer);
/* 244 */         response = this.articleResponder.sendArticle(cmd);
/*     */       }
/*     */       else
/*     */       {
/*     */         NNTPResponse response;
/* 246 */         if ("HEAD" == cmdParts[0]) {
/* 247 */           ArticleCommand cmd = ArticleCommand.getCommand(cmdParts, this.artPointer);
/* 248 */           response = this.articleResponder.sendHead(cmd);
/*     */         }
/*     */         else
/*     */         {
/*     */           NNTPResponse response;
/* 250 */           if ("BODY" == cmdParts[0]) {
/* 251 */             ArticleCommand cmd = ArticleCommand.getCommand(cmdParts, this.artPointer);
/* 252 */             response = this.articleResponder.sendBody(cmd);
/*     */           }
/*     */           else
/*     */           {
/*     */             NNTPResponse response;
/* 254 */             if ("STAT" == cmdParts[0]) {
/* 255 */               ArticleCommand cmd = ArticleCommand.getCommand(cmdParts, this.artPointer);
/* 256 */               response = this.articleResponder.sendStat(cmd);
/*     */             }
/* 258 */             else if ("LAST" == cmdParts[0]) {
/*     */               try {
/* 260 */                 Article last = this.artPointer.last();
/* 261 */                 response = this.articleResponder.sendStat(last.getNumber(), last);
/*     */               }
/*     */               catch (ArticleNotFoundException anfe) {
/* 264 */                 NNTPResponse response = NO_PREVIOUS_ARTICLE;
/*     */               }
/*     */             }
/* 267 */             else if ("NEXT" == cmdParts[0]) {
/*     */               try {
/* 269 */                 Article next = this.artPointer.next();
/* 270 */                 response = this.articleResponder.sendStat(next.getNumber(), next);
/*     */               }
/*     */               catch (ArticleNotFoundException anfe) {
/* 273 */                 NNTPResponse response = NO_NEXT_ARTICLE;
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*     */               NNTPResponse response;
/* 276 */               if (cmdParts[0].charAt(0) == 'X') {
/* 277 */                 response = parseXCommands(cmdParts);
/*     */               }
/* 279 */               else if ("GROUP" == cmdParts[0])
/*     */               {
/*     */                 NNTPResponse response;
/* 280 */                 if (cmdParts.length > 1) {
/* 281 */                   response = NewsGroupSelectedResponse.getResponse(this.artPointer.setGroup(cmdParts[1]));
/*     */                 }
/*     */                 else
/*     */                 {
/* 285 */                   throw new SyntaxException();
/*     */                 }
/*     */               }
/* 288 */               else if ("POST" == cmdParts[0])
/*     */               {
/*     */                 NNTPResponse response;
/* 289 */                 if ((!this.session.isAuthenticated()) && (this.sessionManager.getPostPermissionMode() == 0))
/*     */                 {
/* 292 */                   response = AUTH_REQUIRED;
/*     */                 }
/*     */                 else
/*     */                 {
/*     */                   NNTPResponse response;
/* 294 */                   if (this.session.isPostingOK()) {
/* 295 */                     respond(cmdParts, POST_SEND, 1L);
/* 296 */                     if (this.postIterator == null) {
/* 297 */                       this.postIterator = new PostIterator(null);
/*     */                     }
/*     */                     try
/*     */                     {
/* 301 */                       Iterator dotPostIterator = new DotIterator(this.postIterator);
/* 302 */                       this.session.postArticle(dotPostIterator);
/* 303 */                       response = POST_OK;
/*     */                     }
/*     */                     catch (NoSuchElementException nsee) {
/* 306 */                       if ((nsee.getCause() instanceof IOException)) {
/* 307 */                         throw ((IOException)nsee.getCause());
/*     */                       }
/*     */ 
/* 310 */                       throw nsee;
/*     */                     }
/*     */                   }
/*     */                   else
/*     */                   {
/* 315 */                     response = POST_NOT_ALLOWED;
/*     */                   }
/*     */                 }
/*     */               } else {
/* 319 */                 response = parseRareCommand(cmdParts);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 321 */     return response;
/*     */   }
/*     */ 
/*     */   private NNTPResponse parseXCommands(String[] cmdParts)
/*     */     throws NNTPException, IOException
/*     */   {
/*     */     NNTPResponse response;
/*     */     ArticleFilter filter;
/*     */     NNTPResponse response;
/* 389 */     if ("XHDR" == cmdParts[0]) {
/* 390 */       switch (cmdParts.length) {
/*     */       case 2:
/* 392 */         response = XHDRResponse.getXHDR(this.connection, cmdParts[1], this.artPointer, ArticleFilter.CURRENT_ARTICLE_FILTER);
/*     */ 
/* 394 */         break;
/*     */       case 3:
/* 396 */         filter = new ArticleFilter(cmdParts[2]);
/* 397 */         response = XHDRResponse.getXHDR(this.connection, cmdParts[1], this.artPointer, filter);
/*     */ 
/* 399 */         break;
/*     */       default:
/* 401 */         throw new SyntaxException();
/*     */       }
/*     */     }
/* 404 */     else if ("XOVER" == cmdParts[0]) {
/* 405 */       switch (cmdParts.length) {
/*     */       case 1:
/* 407 */         response = XOverResponse.sendXOver(this.artPointer, ArticleFilter.CURRENT_ARTICLE_FILTER, this.connection);
/*     */ 
/* 409 */         break;
/*     */       case 2:
/* 411 */         filter = new ArticleFilter(cmdParts[1]);
/* 412 */         response = XOverResponse.sendXOver(this.artPointer, filter, this.connection);
/* 413 */         break;
/*     */       default:
/* 415 */         throw new SyntaxException();
/*     */       }
/*     */     }
/* 418 */     else if ("XPAT" == cmdParts[0]) {
/* 419 */       Log.error("******* Notify Jive Software, XPAT being used (not implemented)");
/* 420 */       response = NOT_RECOGNIZED;
/* 421 */       if (cmdParts.length < 4) {
/* 422 */         throw new SyntaxException();
/*     */       }
/*     */ 
/* 425 */       StringBuffer wildmat = new StringBuffer(cmdParts[3]);
/* 426 */       for (int i = 4; i < cmdParts.length; i++) {
/* 427 */         wildmat.append(cmdParts[i]);
/*     */       }
/* 429 */       filter = new ArticleHeaderFilter(cmdParts[1], cmdParts[2], new Wildmat(wildmat.toString()));
/*     */     }
/*     */     else
/*     */     {
/* 435 */       response = NOT_RECOGNIZED;
/*     */     }
/*     */ 
/* 439 */     return response;
/*     */   }
/*     */ 
/*     */   private NNTPResponse parseRareCommand(String[] cmdParts)
/*     */     throws IOException, NNTPException
/*     */   {
/*     */     NNTPResponse response;
/*     */     NNTPResponse response;
/* 453 */     if ("DATE" == cmdParts[0]) {
/* 454 */       response = new NNTPDateResponse();
/*     */     }
/*     */     else
/*     */     {
/*     */       NNTPResponse response;
/* 459 */       if ("QUIT" == cmdParts[0]) {
/* 460 */         respond(cmdParts, QUIT, System.currentTimeMillis());
/* 461 */         this.session.quit();
/* 462 */         response = null;
/*     */       }
/*     */       else
/*     */       {
/*     */         NNTPResponse response;
/* 464 */         if ("AUTHINFO" == cmdParts[0]) {
/* 465 */           response = parseAuth(cmdParts);
/*     */         }
/*     */         else
/*     */         {
/*     */           NNTPResponse response;
/* 467 */           if ("NEWNEWS" == cmdParts[0])
/*     */           {
/* 469 */             if (cmdParts.length < 4) {
/* 470 */               throw new SyntaxException();
/*     */             }
/*     */ 
/* 473 */             NewsGroupFilter filter = new NewsGroupFilter();
/* 474 */             filter.addFilterList(cmdParts[1]);
/* 475 */             NNTPDate date = NNTPDate.parseDateTimeDist(cmdParts, 2, filter);
/* 476 */             filter.setStartDate(date);
/* 477 */             response = NewNewsResponse.getList(this.connection, this.session.getNewNews(filter));
/*     */           }
/*     */           else
/*     */           {
/*     */             NNTPResponse response;
/* 480 */             if ("NEWGROUPS" == cmdParts[0])
/*     */             {
/* 482 */               if (cmdParts.length < 3) {
/* 483 */                 throw new SyntaxException();
/*     */               }
/*     */ 
/* 486 */               NewsGroupFilter filter = new NewsGroupFilter();
/* 487 */               NNTPDate date = NNTPDate.parseDateTimeDist(cmdParts, 1, filter);
/* 488 */               filter.setStartDate(date);
/* 489 */               response = NewsGroupListResponse.sendNewGroupList(this.connection, this.session.getList(filter));
/*     */             }
/*     */             else
/*     */             {
/*     */               NNTPResponse response;
/* 492 */               if ("LIST" == cmdParts[0]) {
/* 493 */                 response = parseList(cmdParts);
/*     */               }
/*     */               else
/*     */               {
/*     */                 NNTPResponse response;
/* 495 */                 if ("LISTGROUP" == cmdParts[0]) {
/* 496 */                   response = parseListGroup(cmdParts);
/*     */                 }
/*     */                 else
/*     */                 {
/*     */                   NNTPResponse response;
/* 498 */                   if ("MODE" == cmdParts[0])
/*     */                   {
/*     */                     NNTPResponse response;
/* 499 */                     if (this.session.isPostingOK()) {
/* 500 */                       response = WELCOME_POST;
/*     */                     }
/*     */                     else
/* 503 */                       response = WELCOME_NO_POST;
/*     */                   }
/*     */                   else
/*     */                   {
/*     */                     NNTPResponse response;
/* 506 */                     if ("HELP" == cmdParts[0]) {
/* 507 */                       response = HelpResponse.RESPONSE;
/*     */                     }
/*     */                     else
/*     */                     {
/*     */                       NNTPResponse response;
/* 509 */                       if ("SLAVE" == cmdParts[0]) {
/* 510 */                         response = SLAVE;
/*     */                       }
/*     */                       else
/*     */                       {
/*     */                         NNTPResponse response;
/* 512 */                         if ("IHAVE" == cmdParts[0])
/*     */                         {
/* 514 */                           response = IHAVE_NOT_WANTED;
/*     */                         }
/*     */                         else
/* 517 */                           response = NOT_RECOGNIZED; 
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 519 */     return response;
/*     */   }
/*     */ 
/*     */   private NNTPResponse parseList(String[] cmdParts)
/*     */     throws NNTPException, IOException
/*     */   {
/*     */     NNTPResponse response;
/*     */     NNTPResponse response;
/* 535 */     switch (cmdParts.length) {
/*     */     case 1:
/* 537 */       response = NewsGroupListResponse.sendList(this.connection, this.session.getList(NewsGroupFilter.MATCH_ALL), false);
/*     */ 
/* 539 */       break;
/*     */     case 2:
/* 541 */       if ("NEWSGROUPS".equalsIgnoreCase(cmdParts[1])) {
/* 542 */         response = NewsGroupListResponse.sendList(this.connection, this.session.getList(NewsGroupFilter.MATCH_ALL), true);
/*     */       }
/*     */       else
/*     */       {
/*     */         NNTPResponse response;
/* 545 */         if ("OVERVIEW.FMT".equalsIgnoreCase(cmdParts[1])) {
/* 546 */           response = OverviewFormatResponse.RESPONSE;
/*     */         }
/*     */         else
/* 549 */           response = NOT_RECOGNIZED;
/*     */       }
/* 551 */       break;
/*     */     default:
/* 553 */       response = NOT_RECOGNIZED;
/*     */     }
/* 555 */     return response;
/*     */   }
/*     */ 
/*     */   private NNTPResponse parseListGroup(String[] cmdParts)
/*     */     throws NNTPException, IOException
/*     */   {
/* 570 */     if (cmdParts.length > 1) {
/* 571 */       this.artPointer.setGroup(cmdParts[1]);
/*     */     }
/* 573 */     Iterator artIter = this.artPointer.getArticles(ArticleFilter.ALL_ARTICLE_FILTER);
/* 574 */     return NewsGroupListResponse.sendListGroup(this.connection, artIter);
/*     */   }
/*     */ 
/*     */   private NNTPResponse parseAuth(String[] cmdParts)
/*     */     throws SyntaxException
/*     */   {
/* 591 */     if (cmdParts.length == 3)
/*     */     {
/*     */       NNTPResponse response;
/* 592 */       if ("USER".equalsIgnoreCase(cmdParts[1])) {
/* 593 */         this.session.setUser(cmdParts[2]);
/* 594 */         response = AUTH_MORE;
/*     */       }
/*     */       else
/*     */       {
/*     */         NNTPResponse response;
/* 596 */         if ("PASS".equalsIgnoreCase(cmdParts[1]))
/*     */         {
/*     */           NNTPResponse response;
/* 597 */           if (this.session.setPassword(cmdParts[2])) {
/* 598 */             response = AUTH_ACCEPTED;
/*     */           }
/*     */           else
/* 601 */             response = AUTH_REJECTED;
/*     */         }
/*     */         else
/*     */         {
/* 605 */           throw new SyntaxException();
/*     */         }
/*     */       }
/*     */     } else {
/* 609 */       throw new SyntaxException();
/*     */     }
/*     */     NNTPResponse response;
/* 611 */     return response;
/*     */   }
/*     */ 
/*     */   private class PostIterator
/*     */     implements Iterator
/*     */   {
/*     */     private PostIterator()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void remove()
/*     */     {
/* 337 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public boolean hasNext()
/*     */     {
/* 347 */       return true;
/*     */     }
/*     */ 
/*     */     public Object next()
/*     */     {
/*     */       try
/*     */       {
/* 358 */         String line = NNTPParser.this.readLine();
/*     */ 
/* 363 */         if ((line.startsWith("..")) && (line.length() > 2));
/* 364 */         return line.substring(1);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 369 */         NoSuchElementException nsee = new NoSuchElementException();
/* 370 */         nsee.initCause(e);
/* 371 */         throw nsee;
/*     */       }
/*     */     }
/*     */ 
/*     */     PostIterator(NNTPParser.1 x1)
/*     */     {
/* 330 */       this();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NNTPParser
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class NoPreviousArticleException extends NNTPException
/*    */ {
/*    */   private static final int CODE = 422;
/* 22 */   private static final NNTPResponse RESPONSE = new StaticNNTPResponse(422, "no previous article in this group");
/*    */ 
/*    */   public NoPreviousArticleException()
/*    */   {
/* 29 */     this.response = RESPONSE;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NoPreviousArticleException
 * JD-Core Version:    0.6.2
 */
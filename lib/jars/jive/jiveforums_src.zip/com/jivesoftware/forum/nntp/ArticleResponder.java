/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import com.jivesoftware.forum.net.Connection;
/*     */ import java.io.IOException;
/*     */ 
/*     */ public class ArticleResponder
/*     */ {
/*     */   private static final int ARTICLE_CODE = 220;
/*     */   private static final int HEAD_CODE = 221;
/*     */   private static final int BODY_CODE = 222;
/*     */   private static final int STAT_CODE = 223;
/*     */   private Connection connection;
/*     */ 
/*     */   public ArticleResponder(Connection conn)
/*     */   {
/*  52 */     this.connection = conn;
/*     */   }
/*     */ 
/*     */   public NNTPResponse sendStat(ArticleCommand cmd)
/*     */     throws IOException
/*     */   {
/*  64 */     return sendStat(cmd.getNumber(), cmd.getArticle());
/*     */   }
/*     */ 
/*     */   public NNTPResponse sendStat(long number, Article art)
/*     */     throws IOException
/*     */   {
/*  75 */     NNTPResponseBuffer response = new NNTPResponseBuffer(this.connection, 223);
/*  76 */     addParameters(response, number, art, " - request text separately");
/*  77 */     return response;
/*     */   }
/*     */ 
/*     */   public NNTPResponse sendBody(ArticleCommand cmd)
/*     */     throws IOException
/*     */   {
/*  87 */     NNTPResponseBuffer response = new NNTPResponseBuffer(this.connection, 222);
/*  88 */     addParameters(response, cmd.getNumber(), cmd.getArticle(), " - body follows");
/*  89 */     cmd.getArticle().sendBody(response);
/*  90 */     return response;
/*     */   }
/*     */ 
/*     */   public NNTPResponse sendHead(ArticleCommand cmd)
/*     */     throws IOException
/*     */   {
/* 100 */     NNTPResponseBuffer response = new NNTPResponseBuffer(this.connection, 221);
/* 101 */     addParameters(response, cmd.getNumber(), cmd.getArticle(), " - head follows");
/* 102 */     response.appendBulkText(cmd.getArticle().getHead());
/* 103 */     return response;
/*     */   }
/*     */ 
/*     */   public NNTPResponse sendArticle(ArticleCommand cmd)
/*     */     throws IOException
/*     */   {
/* 113 */     NNTPResponseBuffer response = new NNTPResponseBuffer(this.connection, 220);
/* 114 */     Article art = cmd.getArticle();
/* 115 */     addParameters(response, cmd.getNumber(), art, " - head and body follow");
/* 116 */     art.sendArticle(response);
/* 117 */     return response;
/*     */   }
/*     */ 
/*     */   private void addParameters(NNTPResponseBuffer response, long number, Article article, String description)
/*     */     throws IOException
/*     */   {
/* 133 */     if (number > 0L) {
/* 134 */       response.appendParameter(Long.toString(number));
/*     */     }
/* 136 */     response.appendParameter(article.getMessageID());
/* 137 */     response.appendLine(description);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.ArticleResponder
 * JD-Core Version:    0.6.2
 */
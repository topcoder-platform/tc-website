/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class ArticleFilter
/*     */ {
/*  31 */   private int mode = -1;
/*  32 */   private String id = null;
/*  33 */   private int startIndex = -1;
/*  34 */   private int endIndex = -1;
/*  35 */   private int articleNumber = -1;
/*     */   public static final int ALL = -1;
/*     */   public static final int CURRENT_ARTICLE = 0;
/*     */   public static final int MESSAGE_ID = 1;
/*     */   public static final int NUMBER = 2;
/*     */   public static final int RANGE = 3;
/*     */   public static final int OPEN_RANGE = 4;
/*  54 */   public static final ArticleFilter CURRENT_ARTICLE_FILTER = new ArticleFilter();
/*     */ 
/*  57 */   public static final ArticleFilter ALL_ARTICLE_FILTER = new ArticleFilter();
/*     */ 
/*     */   private ArticleFilter()
/*     */   {
/*  67 */     this.mode = 0;
/*     */   }
/*     */ 
/*     */   public ArticleFilter(String range)
/*     */   {
/*  76 */     setRange(range);
/*     */   }
/*     */ 
/*     */   public int getMode()
/*     */   {
/*  85 */     return this.mode;
/*     */   }
/*     */ 
/*     */   public void setRange(String range)
/*     */   {
/*  95 */     if (MessageID.isMessageID(range)) {
/*  96 */       this.mode = 1;
/*  97 */       this.id = range;
/*     */     }
/*     */     else {
/* 100 */       range = range.trim();
/*     */ 
/* 103 */       if (range.equals("-")) {
/* 104 */         this.articleNumber = 1;
/* 105 */         this.mode = 4;
/* 106 */         return;
/*     */       }
/*     */ 
/* 109 */       StringTokenizer tokenizer = new StringTokenizer(range, "-", true);
/* 110 */       this.mode = 2;
/* 111 */       this.articleNumber = Integer.parseInt(tokenizer.nextToken());
/* 112 */       if (tokenizer.hasMoreTokens())
/*     */       {
/* 114 */         if (!"-".equals(tokenizer.nextToken())) {
/* 115 */           throw new NumberFormatException();
/*     */         }
/* 117 */         this.mode = 4;
/* 118 */         this.startIndex = this.articleNumber;
/* 119 */         if (tokenizer.hasMoreTokens()) {
/* 120 */           this.mode = 3;
/* 121 */           this.endIndex = Integer.parseInt(tokenizer.nextToken());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getMessageID()
/*     */     throws IllegalStateException
/*     */   {
/* 136 */     if (this.mode != 1) {
/* 137 */       throw new IllegalStateException();
/*     */     }
/* 139 */     return this.id;
/*     */   }
/*     */ 
/*     */   public int getArticleNumber()
/*     */     throws IllegalStateException
/*     */   {
/* 151 */     if (this.mode != 2) {
/* 152 */       throw new IllegalStateException();
/*     */     }
/* 154 */     return this.articleNumber;
/*     */   }
/*     */ 
/*     */   public int getStartIndex()
/*     */     throws IllegalStateException
/*     */   {
/* 168 */     if ((this.mode == 0) || (this.mode == 1) || (this.mode == 2)) {
/* 169 */       throw new IllegalStateException();
/*     */     }
/* 171 */     return this.startIndex;
/*     */   }
/*     */ 
/*     */   public int getEndIndex()
/*     */     throws IllegalStateException
/*     */   {
/* 184 */     if (this.mode != 3) {
/* 185 */       throw new IllegalStateException();
/*     */     }
/* 187 */     return this.endIndex;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  60 */     ALL_ARTICLE_FILTER.mode = -1;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.ArticleFilter
 * JD-Core Version:    0.6.2
 */
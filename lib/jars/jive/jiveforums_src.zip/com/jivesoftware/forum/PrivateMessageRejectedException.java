/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ public class PrivateMessageRejectedException extends Exception
/*    */ {
/* 29 */   public static int RECIPIENT_MAILBOX_FULL = 0;
/* 30 */   public static int SENDER_MAILBOX_FULL = 1;
/* 31 */   public static int NOT_ALLOWED = 2;
/*    */   private int rejectionType;
/*    */ 
/*    */   public PrivateMessageRejectedException(int rejectionType)
/*    */   {
/* 42 */     this.rejectionType = rejectionType;
/*    */   }
/*    */ 
/*    */   public int getRejectionType()
/*    */   {
/* 51 */     return this.rejectionType;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.PrivateMessageRejectedException
 * JD-Core Version:    0.6.2
 */
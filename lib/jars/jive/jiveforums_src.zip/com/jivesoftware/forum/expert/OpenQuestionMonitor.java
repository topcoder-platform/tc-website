/*     */ package com.jivesoftware.forum.expert;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.log.JiveLogImpl;
/*     */ import com.jivesoftware.base.stats.util.DateFormatter;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.Question;
/*     */ import com.jivesoftware.forum.Question.State;
/*     */ import com.jivesoftware.forum.QuestionFilter;
/*     */ import com.jivesoftware.forum.QuestionManager;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.EmailTask;
/*     */ import com.jivesoftware.util.JiveVelocityResourceLoader;
/*     */ import com.jivesoftware.util.LocaleUtils;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ 
/*     */ public class OpenQuestionMonitor
/*     */ {
/*  36 */   private static DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */ 
/*  38 */   private static OpenQuestionMonitor instance = new OpenQuestionMonitor();
/*     */   private boolean enabled;
/*     */   private boolean emailPerForum;
/*     */   private int maxOpenHours;
/*  47 */   private List emailList = null;
/*  48 */   private String emailName = null;
/*  49 */   private String emailAddress = null;
/*  50 */   private String emailSubject = null;
/*  51 */   private String textEmailBody = null;
/*  52 */   private String htmlEmailBody = null;
/*     */   private static FindOpenQuestionTask task;
/*     */ 
/*     */   public static OpenQuestionMonitor getInstance()
/*     */   {
/*  41 */     return instance;
/*     */   }
/*     */ 
/*     */   private OpenQuestionMonitor()
/*     */   {
/*  57 */     this.enabled = JiveGlobals.getJiveBooleanProperty("question.monitor.enabled");
/*  58 */     this.emailPerForum = JiveGlobals.getJiveBooleanProperty("question.monitor.emailPerForum");
/*  59 */     this.maxOpenHours = JiveGlobals.getJiveIntProperty("question.monitor.maxOpenHours", 24);
/*  60 */     String notifyList = JiveGlobals.getJiveProperty("question.monitor.emailList");
/*  61 */     if (notifyList == null) {
/*  62 */       this.emailList = null;
/*     */     }
/*     */     else {
/*  65 */       this.emailList = new ArrayList();
/*  66 */       StringTokenizer tokenizer = new StringTokenizer(notifyList, ",;");
/*  67 */       while (tokenizer.hasMoreTokens()) {
/*  68 */         String emailAddress = tokenizer.nextToken().trim();
/*  69 */         this.emailList.add(emailAddress);
/*     */       }
/*     */     }
/*  72 */     this.emailName = JiveGlobals.getJiveProperty("question.monitor.emailName");
/*  73 */     this.emailAddress = JiveGlobals.getJiveProperty("question.monitor.emailAddress");
/*     */ 
/*  75 */     this.emailSubject = JiveGlobals.getJiveProperty("question.monitor.emailSubject");
/*  76 */     this.textEmailBody = JiveGlobals.getJiveProperty("question.monitor.emailTextBody");
/*  77 */     this.htmlEmailBody = JiveGlobals.getJiveProperty("question.monitor.emailHTMLBody");
/*     */ 
/*  80 */     if ((this.emailSubject == null) || (this.textEmailBody == null) || (this.htmlEmailBody == null)) {
/*  81 */       resetDefaultTemplates();
/*     */     }
/*     */ 
/*  85 */     if (this.enabled)
/*     */     {
/*  88 */       task = new FindOpenQuestionTask();
/*  89 */       TaskEngine.scheduleTask(task, 900000L, 14400000L);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isEnabled()
/*     */   {
/*  99 */     return this.enabled;
/*     */   }
/*     */ 
/*     */   public void setEnabled(boolean enabled)
/*     */   {
/* 108 */     this.enabled = enabled;
/* 109 */     JiveGlobals.setJiveProperty("question.monitor.enabled", String.valueOf(enabled));
/*     */   }
/*     */ 
/*     */   public int getMaxOpenHours()
/*     */   {
/* 119 */     return this.maxOpenHours;
/*     */   }
/*     */ 
/*     */   public void setMaxOpenHours(int maxOpenHours)
/*     */   {
/* 129 */     this.maxOpenHours = maxOpenHours;
/* 130 */     JiveGlobals.setJiveProperty("question.monitor.maxOpenHours", String.valueOf(maxOpenHours));
/*     */   }
/*     */ 
/*     */   public boolean isEmailPerForum()
/*     */   {
/* 140 */     return this.emailPerForum;
/*     */   }
/*     */ 
/*     */   public void setEmailPerforum(boolean emailPerForum)
/*     */   {
/* 150 */     this.emailPerForum = emailPerForum;
/* 151 */     JiveGlobals.setJiveProperty("question.monitor.emailPerForum", String.valueOf(emailPerForum));
/*     */   }
/*     */ 
/*     */   public String getEmailNotifyList()
/*     */   {
/* 161 */     if ((this.emailList == null) || (this.emailList.isEmpty())) {
/* 162 */       return "";
/*     */     }
/* 164 */     StringBuffer buf = new StringBuffer();
/* 165 */     buf.append(this.emailList.get(0));
/* 166 */     for (int i = 1; i < this.emailList.size(); i++) {
/* 167 */       buf.append(", ");
/* 168 */       buf.append(this.emailList.get(i));
/*     */     }
/* 170 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public void setEmailNotifyList(String notifyList)
/*     */   {
/* 180 */     if ((notifyList == null) || (notifyList.equals(""))) {
/* 181 */       this.emailList = null;
/*     */     }
/*     */     else {
/* 184 */       this.emailList = new ArrayList();
/* 185 */       StringTokenizer tokenizer = new StringTokenizer(notifyList, ",");
/* 186 */       while (tokenizer.hasMoreTokens()) {
/* 187 */         String emailAddress = tokenizer.nextToken().trim();
/* 188 */         this.emailList.add(emailAddress);
/*     */       }
/*     */     }
/* 191 */     JiveGlobals.setJiveProperty("question.monitor.emailList", notifyList);
/*     */   }
/*     */ 
/*     */   public String getEmailName()
/*     */   {
/* 200 */     return this.emailName;
/*     */   }
/*     */ 
/*     */   public void setEmailName(String emailName)
/*     */   {
/* 209 */     this.emailName = emailName;
/* 210 */     JiveGlobals.setJiveProperty("question.monitor.emailName", emailName);
/*     */   }
/*     */ 
/*     */   public String getEmailAddress()
/*     */   {
/* 219 */     return this.emailAddress;
/*     */   }
/*     */ 
/*     */   public void setEmailAddress(String emailAddress)
/*     */   {
/* 228 */     this.emailAddress = emailAddress;
/* 229 */     JiveGlobals.setJiveProperty("question.monitor.emailAddress", emailAddress);
/*     */   }
/*     */ 
/*     */   public String getEmailSubject()
/*     */   {
/* 238 */     return this.emailSubject;
/*     */   }
/*     */ 
/*     */   public void setEmailSubject(String emailSubject)
/*     */   {
/* 247 */     this.emailSubject = emailSubject;
/* 248 */     JiveGlobals.setJiveProperty("question.monitor.emailSubject", emailSubject);
/*     */   }
/*     */ 
/*     */   public String getTextEmailBody()
/*     */   {
/* 259 */     return this.textEmailBody;
/*     */   }
/*     */ 
/*     */   public void setTextEmailBody(String textEmailBody)
/*     */   {
/* 278 */     this.textEmailBody = textEmailBody;
/* 279 */     JiveGlobals.setJiveProperty("question.monitor.emailTextBody", textEmailBody);
/*     */   }
/*     */ 
/*     */   public String getHTMLEmailBody()
/*     */   {
/* 290 */     return this.htmlEmailBody;
/*     */   }
/*     */ 
/*     */   public void setHTMLEmailBody(String htmlEmailBody)
/*     */   {
/* 309 */     this.htmlEmailBody = htmlEmailBody;
/* 310 */     JiveGlobals.setJiveProperty("question.monitor.emailHTMLBody", htmlEmailBody);
/*     */   }
/*     */ 
/*     */   public void resetDefaultTemplates()
/*     */   {
/* 317 */     this.emailSubject = LocaleUtils.getLocalizedString("expert.emailalert.subject");
/* 318 */     this.textEmailBody = LocaleUtils.getLocalizedString("expert.emailalert.textBody");
/* 319 */     this.htmlEmailBody = LocaleUtils.getLocalizedString("expert.emailalert.htmlBody");
/*     */   }
/*     */ 
/*     */   FindOpenQuestionTask getTask()
/*     */   {
/* 326 */     return task;
/*     */   }
/*     */ 
/*     */   class FindOpenQuestionTask implements Runnable
/*     */   {
/*     */     FindOpenQuestionTask()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 337 */       if (!CacheFactory.isSeniorClusterMember()) {
/* 338 */         return;
/*     */       }
/*     */ 
/* 341 */       if ((OpenQuestionMonitor.this.emailList == null) || (OpenQuestionMonitor.this.emailList.isEmpty())) {
/* 342 */         return;
/*     */       }
/* 344 */       long date = System.currentTimeMillis();
/* 345 */       int max = OpenQuestionMonitor.instance.getMaxOpenHours();
/* 346 */       date -= max * 3600000L;
/* 347 */       QuestionFilter filter = new QuestionFilter();
/* 348 */       filter.clearResolutionStates();
/* 349 */       filter.addResolutionState(Question.State.open);
/* 350 */       filter.setCreationDateRangeMax(new Date(date));
/* 351 */       filter.setGroupByForum(OpenQuestionMonitor.this.emailPerForum);
/*     */ 
/* 353 */       Iterator questions = OpenQuestionMonitor.FACTORY.getQuestionManager().getQuestions(filter);
/*     */ 
/* 355 */       List allQuestions = new ArrayList();
/* 356 */       Map questionMap = new HashMap();
/* 357 */       List sublist = new ArrayList();
/* 358 */       Question question = null;
/* 359 */       long forumID = -1L;
/* 360 */       if (questions.hasNext()) {
/* 361 */         question = (Question)questions.next();
/* 362 */         sublist.add(question);
/* 363 */         allQuestions.add(question);
/* 364 */         forumID = question.getForumThread().getForum().getID();
/*     */       }
/* 366 */       while (questions.hasNext()) {
/* 367 */         Question q = (Question)questions.next();
/* 368 */         allQuestions.add(q);
/* 369 */         long fid = q.getForumThread().getForum().getID();
/* 370 */         if ((forumID != fid) || (!questions.hasNext())) {
/* 371 */           if (!questions.hasNext()) {
/* 372 */             sublist.add(q);
/*     */           }
/* 374 */           questionMap.put(new Long(forumID), sublist);
/* 375 */           sublist = new ArrayList();
/* 376 */           sublist.add(q);
/* 377 */           forumID = fid;
/*     */         }
/*     */         else {
/* 380 */           sublist.add(q);
/*     */         }
/*     */       }
/*     */       Iterator i;
/* 383 */       if (!OpenQuestionMonitor.this.emailPerForum) {
/* 384 */         sendMessage(allQuestions, -1L);
/*     */       }
/*     */       else
/* 387 */         for (i = questionMap.keySet().iterator(); i.hasNext(); ) {
/* 388 */           Long fid = (Long)i.next();
/* 389 */           List list = (List)questionMap.get(fid);
/* 390 */           sendMessage(list, fid.longValue());
/*     */         }
/*     */     }
/*     */ 
/*     */     private void sendMessage(List questions, long forumID)
/*     */     {
/* 396 */       String subject = generateString(OpenQuestionMonitor.instance.getEmailSubject(), questions, forumID);
/* 397 */       String textBody = generateString(OpenQuestionMonitor.instance.getTextEmailBody(), questions, forumID);
/* 398 */       String htmlBody = generateString(OpenQuestionMonitor.instance.getHTMLEmailBody(), questions, forumID);
/* 399 */       EmailTask emailTask = new EmailTask();
/* 400 */       for (int j = 0; j < OpenQuestionMonitor.this.emailList.size(); j++) {
/* 401 */         emailTask.addMessage(null, (String)OpenQuestionMonitor.this.emailList.get(j), OpenQuestionMonitor.instance.getEmailName(), OpenQuestionMonitor.instance.getEmailAddress(), subject, textBody, htmlBody);
/*     */       }
/*     */ 
/* 404 */       TaskEngine.addTask(emailTask);
/*     */     }
/*     */ 
/*     */     private String generateString(String string, List questions, long forumID)
/*     */     {
/* 414 */       Map context = new HashMap();
/*     */ 
/* 417 */       context.put("jiveURL", JiveGlobals.getJiveProperty("jiveURL"));
/* 418 */       context.put("dateFormatter", new DateFormatter());
/* 419 */       context.put("maxOpenHours", String.valueOf(OpenQuestionMonitor.instance.getMaxOpenHours()));
/* 420 */       if (forumID > 0L) {
/* 421 */         context.put("forumID", String.valueOf(forumID));
/*     */       }
/* 423 */       context.put("questions", questions);
/*     */       try
/*     */       {
/* 427 */         VelocityContext velContext = new VelocityContext(context);
/* 428 */         Writer sw = new StringWriter();
/* 429 */         VelocityEngine ve = new VelocityEngine();
/* 430 */         ve.setProperty("resource.loader", "jive");
/* 431 */         ve.setProperty("jive.resource.loader.public.name", "Jive");
/* 432 */         ve.setProperty("jive.resource.loader.description", " Jive Velocity Resource Loader");
/* 433 */         ve.setProperty("jive.resource.loader.class", JiveVelocityResourceLoader.class.getName());
/* 434 */         ve.setProperty("velocimacro.library", "");
/* 435 */         ve.setProperty("runtime.log.logsystem.class", JiveLogImpl.class.getName());
/* 436 */         ve.init();
/* 437 */         ve.evaluate(velContext, sw, "questionMonitor", string);
/* 438 */         return sw.toString();
/*     */       }
/*     */       catch (Exception e) {
/* 441 */         Log.error(e);
/* 442 */       }return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.expert.OpenQuestionMonitor
 * JD-Core Version:    0.6.2
 */
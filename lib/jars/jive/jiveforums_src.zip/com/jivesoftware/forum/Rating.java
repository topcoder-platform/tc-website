package com.jivesoftware.forum;

public abstract interface Rating
{
  public abstract int getScore();

  public abstract String getDescription();

  public abstract boolean equals(Rating paramRating);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.Rating
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.moderation.action;
/*     */ 
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.action.ForumActionSupport;
/*     */ import com.jivesoftware.forum.moderation.ModerationManager;
/*     */ import com.jivesoftware.forum.moderation.ModerationManagerImpl;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class BulkModerateAction extends ForumActionSupport
/*     */ {
/*     */   private static final int TYPE_APPROVE = 1;
/*     */   private static final int TYPE_EDIT = 2;
/*     */   private static final int TYPE_REJECT = 3;
/*  25 */   private static ModerationManager moderationManager = ModerationManagerImpl.getInstance();
/*     */   List actions;
/*     */   long buttonID;
/*     */   long forumID;
/*     */ 
/*     */   public String execute()
/*     */     throws Exception
/*     */   {
/*  34 */     if (this.buttonID != 0L) {
/*  35 */       ModAction action = null;
/*  36 */       int validMessageCount = 0;
/*  37 */       for (Iterator iterator = this.actions.iterator(); iterator.hasNext(); ) {
/*  38 */         action = (ModAction)iterator.next();
/*  39 */         if (action.getMessageID() != 0L) {
/*  40 */           validMessageCount++;
/*  41 */           if ((action.getMessageID() == this.buttonID) && (action.getType() == 2)) {
/*  42 */             ForumMessage message = getForumFactory().getMessage(action.getMessageID());
/*  43 */             if ((action.isShowEditStamp()) && (action.getEditStamp() != null)) {
/*  44 */               action.setBody(action.getBody() + "\n\n" + action.getEditStamp());
/*     */             }
/*  46 */             int modValue = message.getModerationValue();
/*  47 */             moderationManager.editAndApprove(getAuthToken(), message, action.getSubject(), action.getBody());
/*     */ 
/*  49 */             if ((modValue == -5) || (modValue != 5));
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  57 */       if (validMessageCount <= 1) {
/*  58 */         return "success-reload";
/*     */       }
/*     */ 
/*  61 */       return "success";
/*     */     }
/*     */     Iterator iterator;
/*  65 */     if (this.actions != null) {
/*  66 */       for (iterator = this.actions.iterator(); iterator.hasNext(); ) {
/*  67 */         ModAction action = (ModAction)iterator.next();
/*  68 */         if (action.getMessageID() != 0L) {
/*  69 */           ForumMessage message = getForumFactory().getMessage(action.getMessageID());
/*  70 */           int modValue = message.getModerationValue();
/*  71 */           switch (action.getType()) {
/*     */           case 1:
/*  73 */             moderationManager.approve(getAuthToken(), message);
/*  74 */             break;
/*     */           case 2:
/*  76 */             if ((action.isShowEditStamp()) && (action.getEditStamp() != null)) {
/*  77 */               action.setBody(action.getBody() + "\n\n" + action.getEditStamp());
/*     */             }
/*     */ 
/*  80 */             moderationManager.editAndApprove(getAuthToken(), message, action.getSubject(), action.getBody());
/*     */ 
/*  82 */             break;
/*     */           case 3:
/*  84 */             moderationManager.reject(getAuthToken(), message);
/*  85 */             break;
/*     */           }
/*     */ 
/*  89 */           if ((modValue == -5) || (modValue != 5));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  95 */     return "success-reload";
/*     */   }
/*     */ 
/*     */   public List getActions()
/*     */   {
/* 100 */     return this.actions;
/*     */   }
/*     */ 
/*     */   public void setActions(List actions) {
/* 104 */     this.actions = actions;
/*     */   }
/*     */ 
/*     */   public long getButtonID() {
/* 108 */     return this.buttonID;
/*     */   }
/*     */ 
/*     */   public void setButtonID(long buttonID) {
/* 112 */     this.buttonID = buttonID;
/*     */   }
/*     */ 
/*     */   public static ModerationManager getModerationManager() {
/* 116 */     return moderationManager;
/*     */   }
/*     */ 
/*     */   public static void setModerationManager(ModerationManager moderationManager) {
/* 120 */     moderationManager = moderationManager;
/*     */   }
/*     */ 
/*     */   public long getForumID() {
/* 124 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID) {
/* 128 */     this.forumID = forumID;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.moderation.action.BulkModerateAction
 * JD-Core Version:    0.6.2
 */
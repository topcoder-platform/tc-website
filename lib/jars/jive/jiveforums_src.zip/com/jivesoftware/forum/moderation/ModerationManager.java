package com.jivesoftware.forum.moderation;

import com.jivesoftware.base.AuthToken;
import com.jivesoftware.base.UnauthorizedException;
import com.jivesoftware.forum.Forum;
import com.jivesoftware.forum.ForumMessage;
import com.jivesoftware.forum.ForumMessageIterator;
import java.util.List;

public abstract interface ModerationManager
{
  public static final String PROPERTY_EMAIL_ENABLED = "moderation.emailalert.enabled";
  public static final String PROPERTY_EMAIL_NAME = "moderation.emailalert.name";
  public static final String PROPERTY_EMAIL_ADDRESS = "moderation.emailalert.address";
  public static final String PROPERTY_EMAIL_SUBJECT = "moderation.emailalert.subject";
  public static final String PROPERTY_EMAIL_BODY_TEXT = "moderation.emailalert.textBody";
  public static final String PROPERTY_EMAIL_BODY_HTML = "moderation.emailalert.htmlBody";
  public static final String PROPERTY_MESSAGE_TIME_APPROVED = "moderation.timeApproved";

  public abstract List getForums(AuthToken paramAuthToken);

  public abstract List getMessages(AuthToken paramAuthToken);

  public abstract List getMessages(ModerationFilter paramModerationFilter, AuthToken paramAuthToken);

  public abstract ForumMessageIterator getMessages(AuthToken paramAuthToken, Forum paramForum)
    throws UnauthorizedException;

  public abstract ForumMessageIterator getMessages(ModerationFilter paramModerationFilter, AuthToken paramAuthToken, Forum paramForum)
    throws UnauthorizedException;

  public abstract int getMessageCount(Forum paramForum);

  public abstract int getMessageCount(ModerationFilter paramModerationFilter, Forum paramForum);

  public abstract void approve(AuthToken paramAuthToken, ForumMessage paramForumMessage)
    throws UnauthorizedException;

  public abstract void editAndApprove(AuthToken paramAuthToken, ForumMessage paramForumMessage, String paramString1, String paramString2)
    throws UnauthorizedException;

  public abstract void reject(AuthToken paramAuthToken, ForumMessage paramForumMessage)
    throws UnauthorizedException;

  public abstract boolean isEmailAlertEnabled();

  public abstract void setEmailAlertEnabled(boolean paramBoolean);

  public abstract String getEmailName();

  public abstract void setEmailName(String paramString);

  public abstract String getEmailAddress();

  public abstract void setEmailAddress(String paramString);

  public abstract String getEmailSubject();

  public abstract void setEmailSubject(String paramString);

  public abstract String getEmailBodyText();

  public abstract void setEmailBodyText(String paramString);

  public abstract String getEmailBodyHtml();

  public abstract void setEmailBodyHtml(String paramString);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.moderation.ModerationManager
 * JD-Core Version:    0.6.2
 */
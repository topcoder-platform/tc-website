/*     */ package com.jivesoftware.forum.moderation.action;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.action.ForumActionSupport;
/*     */ import com.jivesoftware.forum.moderation.ModerationFilter;
/*     */ import com.jivesoftware.forum.moderation.ModerationManager;
/*     */ import com.jivesoftware.forum.moderation.ModerationManagerImpl;
/*     */ import com.jivesoftware.util.RelativeDateRange;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ViewModerateAction extends ForumActionSupport
/*     */ {
/*  22 */   private static ModerationManager moderationManager = ModerationManagerImpl.getInstance();
/*     */ 
/*  24 */   public static final RelativeDateRange DEFAULT_DATE_RANGE = RelativeDateRange.ALL;
/*  25 */   public static final RelativeDateRange[] DATE_RANGES = { RelativeDateRange.ALL, RelativeDateRange.YESTERDAY, RelativeDateRange.LAST_7_DAYS, RelativeDateRange.LAST_30_DAYS, RelativeDateRange.LAST_90_DAYS, RelativeDateRange.THIS_YEAR, RelativeDateRange.LAST_YEAR };
/*     */   private long forumID;
/*     */   private List forumList;
/*     */   private Iterator messages;
/*  37 */   private int modValue = 2147483524;
/*     */   private User searchedUser;
/*     */   private String userID;
/*     */   private String dateRange;
/*     */ 
/*     */   public List getForumList()
/*     */   {
/*  45 */     return this.forumList;
/*     */   }
/*     */ 
/*     */   public Iterator getMessages() {
/*  49 */     return this.messages;
/*     */   }
/*     */ 
/*     */   public long getForumID() {
/*  53 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID) {
/*  57 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public ModerationManager getModerationManager() {
/*  61 */     return moderationManager;
/*     */   }
/*     */ 
/*     */   public int getModValue() {
/*  65 */     return this.modValue;
/*     */   }
/*     */ 
/*     */   public void setModValue(int modValue) {
/*  69 */     this.modValue = modValue;
/*     */   }
/*     */ 
/*     */   public User getSearchedUser() {
/*  73 */     return this.searchedUser;
/*     */   }
/*     */ 
/*     */   public void setSearchedUser(User searchedUser) {
/*  77 */     this.searchedUser = searchedUser;
/*     */   }
/*     */ 
/*     */   public String getUserID() {
/*  81 */     return this.userID;
/*     */   }
/*     */ 
/*     */   public void setUserID(String userID) {
/*  85 */     if ((userID != null) && (!"".equals(userID.trim())))
/*  86 */       this.userID = userID.trim();
/*     */   }
/*     */ 
/*     */   public String getDateRange()
/*     */   {
/*  91 */     return this.dateRange;
/*     */   }
/*     */ 
/*     */   public void setDateRange(String dateRange) {
/*  95 */     this.dateRange = dateRange;
/*     */   }
/*     */ 
/*     */   public RelativeDateRange[] getDateRanges()
/*     */   {
/* 104 */     return DATE_RANGES;
/*     */   }
/*     */ 
/*     */   public String execute() throws Exception {
/*     */     try {
/* 109 */       if (!loadJiveObjects())
/* 110 */         if (this.forumList.size() == 0) {
/* 111 */           addActionMessage("There are currently no forums setup for moderation.");
/*     */         }
/*     */         else {
/* 114 */           addActionError("moderation.invalid_params");
/* 115 */           return "error";
/*     */         }
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 120 */       addActionError(getText("moderation.unauthorized"));
/* 121 */       return "error";
/*     */     }
/* 123 */     return "success";
/*     */   }
/*     */ 
/*     */   protected boolean loadJiveObjects() throws UnauthorizedException {
/* 127 */     boolean success = true;
/* 128 */     this.forumList = moderationManager.getForums(getAuthToken());
/*     */ 
/* 130 */     if (this.forumList.size() == 0) {
/* 131 */       return false;
/*     */     }
/*     */ 
/* 134 */     Collections.sort(this.forumList, new Comparator() {
/*     */       public int compare(Object o1, Object o2) {
/* 136 */         Forum f1 = (Forum)o1;
/* 137 */         Forum f2 = (Forum)o2;
/* 138 */         Integer f1_count = new Integer(ViewModerateAction.moderationManager.getMessageCount(f1));
/* 139 */         Integer f2_count = new Integer(ViewModerateAction.moderationManager.getMessageCount(f2));
/* 140 */         return f2_count.compareTo(f1_count);
/*     */       }
/*     */     });
/* 145 */     ModerationFilter modMessageFilter = new ModerationFilter();
/*     */ 
/* 148 */     if (this.modValue == 0) {
/* 149 */       modMessageFilter = ModerationFilter.createModerationOnlyFilter();
/*     */     }
/* 151 */     else if ((this.modValue == 5) || (this.modValue == -5))
/*     */     {
/* 153 */       modMessageFilter = ModerationFilter.createAbuseOnlyFilter();
/*     */     }
/*     */     else {
/* 156 */       modMessageFilter = ModerationFilter.createDefaultModerationFilter();
/*     */     }
/*     */ 
/* 160 */     if (this.userID != null) {
/*     */       try {
/* 162 */         this.searchedUser = getForumFactory().getUserManager().getUser(Integer.parseInt(this.userID));
/*     */       }
/*     */       catch (Exception ignored) {
/*     */         try {
/* 166 */           this.searchedUser = getForumFactory().getUserManager().getUser(this.userID);
/*     */         }
/*     */         catch (Exception ignored2) {
/* 169 */           addFieldError("userID", getText("search.error_not_find_user"));
/*     */         }
/*     */       }
/* 172 */       if (this.searchedUser != null) {
/* 173 */         modMessageFilter.setUserID(this.searchedUser.getID());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 178 */     if ((this.dateRange != null) && (!"all".equals(this.dateRange))) {
/* 179 */       RelativeDateRange range = null;
/* 180 */       for (int i = 0; i < DATE_RANGES.length; i++) {
/* 181 */         if (DATE_RANGES[i].getID().equals(this.dateRange)) {
/* 182 */           range = DATE_RANGES[i];
/* 183 */           break;
/*     */         }
/*     */       }
/* 186 */       if (range != null) {
/* 187 */         modMessageFilter.setCreationDateRangeMin(range.getStartDate(new Date()));
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 192 */       Forum forum = null;
/* 193 */       if (this.forumID == 0L) {
/* 194 */         this.messages = moderationManager.getMessages(modMessageFilter, getAuthToken()).iterator();
/*     */       }
/*     */       else
/*     */       {
/* 198 */         forum = getForumFactory().getForum(this.forumID);
/* 199 */         this.messages = moderationManager.getMessages(modMessageFilter, getAuthToken(), forum);
/*     */       }
/*     */     }
/*     */     catch (ForumNotFoundException fnfe) {
/* 203 */       success = false;
/* 204 */       addActionError(fnfe.getMessage());
/*     */     }
/* 206 */     return success;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.moderation.action.ViewModerateAction
 * JD-Core Version:    0.6.2
 */
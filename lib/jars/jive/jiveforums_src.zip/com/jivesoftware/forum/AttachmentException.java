/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ public class AttachmentException extends Exception
/*    */ {
/*    */   public static final int TOO_LARGE = 0;
/*    */   public static final int TOO_MANY_ATTACHMENTS = 1;
/*    */   public static final int BAD_CONTENT_TYPE = 2;
/*    */   public static final int GENERAL_ERROR = 3;
/* 27 */   public static final String[] messages = { "Attachment too large", "Message has too many attachments", "Content type not allowed", "General error" };
/*    */ 
/* 34 */   private Throwable nestedThrowable = null;
/*    */   private int errorType;
/* 36 */   private String attachmentName = null;
/*    */ 
/*    */   public AttachmentException(int errorType, String name) {
/* 39 */     super(messages[errorType]);
/* 40 */     this.errorType = errorType;
/* 41 */     this.attachmentName = name;
/*    */   }
/*    */ 
/*    */   public AttachmentException(int errorType, Throwable nestedThrowable, String name) {
/* 45 */     this.errorType = errorType;
/* 46 */     this.nestedThrowable = nestedThrowable;
/* 47 */     this.attachmentName = name;
/*    */   }
/*    */ 
/*    */   public int getErrorType() {
/* 51 */     return this.errorType;
/*    */   }
/*    */ 
/*    */   public String getAttachmentName() {
/* 55 */     return this.attachmentName;
/*    */   }
/*    */ 
/*    */   public void printStackTrace() {
/* 59 */     super.printStackTrace();
/* 60 */     if (this.nestedThrowable != null)
/* 61 */       this.nestedThrowable.printStackTrace();
/*    */   }
/*    */ 
/*    */   public void printStackTrace(PrintStream ps)
/*    */   {
/* 66 */     super.printStackTrace(ps);
/* 67 */     if (this.nestedThrowable != null)
/* 68 */       this.nestedThrowable.printStackTrace(ps);
/*    */   }
/*    */ 
/*    */   public void printStackTrace(PrintWriter pw)
/*    */   {
/* 73 */     super.printStackTrace(pw);
/* 74 */     if (this.nestedThrowable != null)
/* 75 */       this.nestedThrowable.printStackTrace(pw);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.AttachmentException
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum;

import com.jivesoftware.base.NotFoundException;
import com.jivesoftware.base.UnauthorizedException;
import com.jivesoftware.base.User;
import java.util.Iterator;
import java.util.Map;

public abstract interface QueryLogger
{
  public abstract int getQueryCount()
    throws UnauthorizedException;

  public abstract int getQueryCount(User paramUser)
    throws UnauthorizedException;

  public abstract Iterator getQueries()
    throws UnauthorizedException;

  public abstract Iterator getQueries(User paramUser)
    throws UnauthorizedException;

  public abstract Query getQuery(long paramLong)
    throws NotFoundException, UnauthorizedException;

  public abstract Map getLoggedQueryInfo(Query paramQuery);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.QueryLogger
 * JD-Core Version:    0.6.2
 */
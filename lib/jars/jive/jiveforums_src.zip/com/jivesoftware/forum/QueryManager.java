package com.jivesoftware.forum;

public abstract interface QueryManager
{
  public abstract Query createQuery();

  public abstract Query createQuery(Forum[] paramArrayOfForum);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.QueryManager
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.event;
/*    */ 
/*    */ import com.jivesoftware.base.JiveGlobals;
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.util.ClassUtils;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class PrivateMessageEventDispatcher
/*    */ {
/* 29 */   private static PrivateMessageEventDispatcher instance = new PrivateMessageEventDispatcher();
/*    */ 
/* 35 */   private ArrayList listeners = new ArrayList();
/*    */ 
/*    */   public static PrivateMessageEventDispatcher getInstance()
/*    */   {
/* 32 */     return instance;
/*    */   }
/*    */ 
/*    */   private PrivateMessageEventDispatcher()
/*    */   {
/* 39 */     List listenerList = JiveGlobals.getJiveProperties("eventListeners.PrivateMessageListener");
/* 40 */     for (int i = 0; i < listenerList.size(); i++) {
/* 41 */       String listenerStr = (String)listenerList.get(i);
/*    */       try {
/* 43 */         PrivateMessageListener listener = (PrivateMessageListener)ClassUtils.forName(listenerStr).newInstance();
/*    */ 
/* 45 */         this.listeners.add(listener);
/*    */       }
/*    */       catch (Exception e) {
/* 48 */         Log.error("Error loading MessageListener", e);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public synchronized void addListener(PrivateMessageListener listener) {
/* 54 */     if (listener == null) {
/* 55 */       throw new NullPointerException();
/*    */     }
/*    */ 
/* 58 */     this.listeners.add(listener);
/*    */   }
/*    */ 
/*    */   public synchronized void removeListener(PrivateMessageListener listener) {
/* 62 */     this.listeners.remove(listener);
/*    */   }
/*    */ 
/*    */   public void dispatchEvent(PrivateMessageEvent event) {
/* 66 */     int eventType = event.getEventType();
/*    */ 
/* 68 */     for (int i = 0; i < this.listeners.size(); i++)
/*    */       try {
/* 70 */         PrivateMessageListener listener = (PrivateMessageListener)this.listeners.get(i);
/* 71 */         switch (eventType) {
/*    */         case 140:
/* 73 */           listener.privateMessageSent(event);
/*    */         }
/*    */ 
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 81 */         Log.error(e);
/*    */       }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.PrivateMessageEventDispatcher
 * JD-Core Version:    0.6.2
 */
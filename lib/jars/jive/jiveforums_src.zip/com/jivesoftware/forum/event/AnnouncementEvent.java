/*    */ package com.jivesoftware.forum.event;
/*    */ 
/*    */ import com.jivesoftware.base.JiveEvent;
/*    */ import com.jivesoftware.forum.Announcement;
/*    */ import java.util.Collections;
/*    */ import java.util.Date;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class AnnouncementEvent
/*    */   implements JiveEvent
/*    */ {
/*    */   public static final int ANNOUNCEMENT_CREATED = 150;
/*    */   public static final int ANNOUNCEMENT_DELETED = 151;
/*    */   public static final int ANNOUNCEMENT_MODIFIED = 152;
/*    */   private int eventType;
/*    */   private Announcement announcement;
/*    */   private Date date;
/*    */   private Map params;
/*    */ 
/*    */   public AnnouncementEvent(int eventType, Announcement announcement, Map params)
/*    */   {
/* 67 */     this.eventType = eventType;
/* 68 */     this.announcement = announcement;
/* 69 */     this.params = (params == null ? null : Collections.unmodifiableMap(params));
/* 70 */     this.date = new Date();
/*    */   }
/*    */ 
/*    */   public int getEventType() {
/* 74 */     return this.eventType;
/*    */   }
/*    */ 
/*    */   public Announcement getAnnouncment()
/*    */   {
/* 83 */     return this.announcement;
/*    */   }
/*    */ 
/*    */   public Map getParams() {
/* 87 */     return this.params;
/*    */   }
/*    */ 
/*    */   public Date getDate() {
/* 91 */     return this.date;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.AnnouncementEvent
 * JD-Core Version:    0.6.2
 */
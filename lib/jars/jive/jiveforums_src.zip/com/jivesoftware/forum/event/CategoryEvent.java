/*    */ package com.jivesoftware.forum.event;
/*    */ 
/*    */ import com.jivesoftware.base.JiveEvent;
/*    */ import com.jivesoftware.forum.ForumCategory;
/*    */ import java.util.Collections;
/*    */ import java.util.Date;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class CategoryEvent
/*    */   implements JiveEvent
/*    */ {
/*    */   public static final int CATEGORY_ADDED = 130;
/*    */   public static final int CATEGORY_DELETING = 131;
/*    */   public static final int CATEGORY_MOVED = 132;
/*    */   private int eventType;
/*    */   private ForumCategory category;
/*    */   private Date date;
/*    */   private Map params;
/*    */ 
/*    */   public CategoryEvent(int eventType, ForumCategory category, Map params)
/*    */   {
/* 67 */     this.eventType = eventType;
/* 68 */     this.category = category;
/* 69 */     this.params = (params == null ? null : Collections.unmodifiableMap(params));
/* 70 */     this.date = new Date();
/*    */   }
/*    */ 
/*    */   public int getEventType() {
/* 74 */     return this.eventType;
/*    */   }
/*    */ 
/*    */   public ForumCategory getCategory()
/*    */   {
/* 83 */     return this.category;
/*    */   }
/*    */ 
/*    */   public Map getParams() {
/* 87 */     return this.params;
/*    */   }
/*    */ 
/*    */   public Date getDate() {
/* 91 */     return this.date;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.CategoryEvent
 * JD-Core Version:    0.6.2
 */
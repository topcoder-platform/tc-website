package com.jivesoftware.forum.event;

public abstract interface ThreadListener
{
  public abstract void threadAdded(ThreadEvent paramThreadEvent);

  public abstract void threadDeleted(ThreadEvent paramThreadEvent);

  public abstract void threadMoved(ThreadEvent paramThreadEvent);

  public abstract void threadModerationModified(ThreadEvent paramThreadEvent);

  public abstract void threadRated(ThreadEvent paramThreadEvent);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.ThreadListener
 * JD-Core Version:    0.6.2
 */
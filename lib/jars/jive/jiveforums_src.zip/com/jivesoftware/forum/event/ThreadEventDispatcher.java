/*     */ package com.jivesoftware.forum.event;
/*     */ 
/*     */ import com.jivesoftware.base.JiveEvent;
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.util.ClassUtils;
/*     */ import com.jivesoftware.util.profile.Profiler;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ThreadEventDispatcher
/*     */ {
/*  29 */   private static ThreadEventDispatcher instance = new ThreadEventDispatcher();
/*     */ 
/*  35 */   private ArrayList listeners = new ArrayList();
/*     */ 
/*     */   public static ThreadEventDispatcher getInstance()
/*     */   {
/*  32 */     return instance;
/*     */   }
/*     */ 
/*     */   private ThreadEventDispatcher()
/*     */   {
/*  39 */     List listenerList = JiveGlobals.getJiveProperties("eventListeners.ThreadListener");
/*  40 */     for (int i = 0; i < listenerList.size(); i++) {
/*  41 */       String listenerStr = (String)listenerList.get(i);
/*     */       try {
/*  43 */         ThreadListener listener = (ThreadListener)ClassUtils.forName(listenerStr).newInstance();
/*  44 */         this.listeners.add(listener);
/*     */       }
/*     */       catch (Exception e) {
/*  47 */         Log.error("Error loading ThreadListener", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void addListener(ThreadListener listener) {
/*  53 */     if (listener == null) {
/*  54 */       throw new NullPointerException();
/*     */     }
/*     */ 
/*  57 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */   public synchronized void removeListener(MessageListener listener) {
/*  61 */     this.listeners.remove(listener);
/*     */   }
/*     */ 
/*     */   public void dispatchEvent(JiveEvent event) {
/*  65 */     Profiler.begin("threadDispatchEvent");
/*  66 */     if (!(event instanceof ThreadEvent)) {
/*  67 */       return;
/*     */     }
/*  69 */     ThreadEvent threadEvent = (ThreadEvent)event;
/*  70 */     int eventType = event.getEventType();
/*     */ 
/*  72 */     for (int i = 0; i < this.listeners.size(); i++) {
/*     */       try {
/*  74 */         ThreadListener listener = (ThreadListener)this.listeners.get(i);
/*  75 */         String name = listener.getClass().getName();
/*  76 */         name = name.substring(name.lastIndexOf('.') + 1);
/*  77 */         Profiler.begin(name);
/*     */ 
/*  79 */         switch (eventType) {
/*     */         case 110:
/*  81 */           listener.threadAdded(threadEvent);
/*  82 */           break;
/*     */         case 111:
/*  85 */           listener.threadDeleted(threadEvent);
/*  86 */           break;
/*     */         case 112:
/*  89 */           listener.threadMoved(threadEvent);
/*  90 */           break;
/*     */         case 113:
/*  93 */           listener.threadModerationModified(threadEvent);
/*  94 */           break;
/*     */         case 114:
/*  97 */           listener.threadRated(threadEvent);
/*  98 */           break;
/*     */         }
/*     */ 
/* 104 */         Profiler.end(name);
/*     */       }
/*     */       catch (Exception e) {
/* 107 */         Log.error(e);
/*     */       }
/*     */     }
/* 110 */     Profiler.end("threadDispatchEvent");
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.ThreadEventDispatcher
 * JD-Core Version:    0.6.2
 */
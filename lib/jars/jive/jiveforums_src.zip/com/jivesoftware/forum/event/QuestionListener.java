package com.jivesoftware.forum.event;

public abstract interface QuestionListener
{
  public abstract void questionAdded(QuestionEvent paramQuestionEvent);

  public abstract void questionDeleted(QuestionEvent paramQuestionEvent);

  public abstract void questionStateModified(QuestionEvent paramQuestionEvent);

  public abstract void correctAnswerAdded(QuestionEvent paramQuestionEvent);

  public abstract void helpfulAnswerAdded(QuestionEvent paramQuestionEvent);

  public abstract void propertyModified(QuestionEvent paramQuestionEvent);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.QuestionListener
 * JD-Core Version:    0.6.2
 */
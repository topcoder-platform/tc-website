/*    */ package com.jivesoftware.forum.event;
/*    */ 
/*    */ import com.jivesoftware.base.JiveGlobals;
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.util.ClassUtils;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class AnnouncementEventDispatcher
/*    */ {
/* 29 */   private static AnnouncementEventDispatcher instance = new AnnouncementEventDispatcher();
/*    */ 
/* 35 */   private ArrayList listeners = new ArrayList();
/*    */ 
/*    */   public static AnnouncementEventDispatcher getInstance()
/*    */   {
/* 32 */     return instance;
/*    */   }
/*    */ 
/*    */   private AnnouncementEventDispatcher()
/*    */   {
/* 39 */     List listenerList = JiveGlobals.getJiveProperties("eventListeners.AnnouncementListener");
/* 40 */     for (int i = 0; i < listenerList.size(); i++) {
/* 41 */       String listenerStr = (String)listenerList.get(i);
/*    */       try {
/* 43 */         AnnouncementListener listener = (AnnouncementListener)ClassUtils.forName(listenerStr).newInstance();
/* 44 */         this.listeners.add(listener);
/*    */       }
/*    */       catch (Exception e) {
/* 47 */         Log.error("Error loading AnnouncementListener", e);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public synchronized void addListener(AnnouncementListener listener) {
/* 53 */     if (listener == null) {
/* 54 */       throw new NullPointerException();
/*    */     }
/*    */ 
/* 57 */     this.listeners.add(listener);
/*    */   }
/*    */ 
/*    */   public synchronized void removeListener(AnnouncementListener listener) {
/* 61 */     this.listeners.remove(listener);
/*    */   }
/*    */ 
/*    */   public void dispatchEvent(AnnouncementEvent event) {
/* 65 */     int eventType = event.getEventType();
/*    */ 
/* 67 */     for (int i = 0; i < this.listeners.size(); i++)
/*    */       try {
/* 69 */         AnnouncementListener listener = (AnnouncementListener)this.listeners.get(i);
/* 70 */         switch (eventType) {
/*    */         case 150:
/* 72 */           listener.announcementCreated(event);
/* 73 */           break;
/*    */         case 151:
/* 76 */           listener.announcementDeleted(event);
/* 77 */           break;
/*    */         case 152:
/* 80 */           listener.announcementModified(event);
/*    */         }
/*    */ 
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 88 */         Log.error(e);
/*    */       }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.AnnouncementEventDispatcher
 * JD-Core Version:    0.6.2
 */
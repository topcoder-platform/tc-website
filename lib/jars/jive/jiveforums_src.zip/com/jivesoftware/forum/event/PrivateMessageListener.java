package com.jivesoftware.forum.event;

public abstract interface PrivateMessageListener
{
  public abstract void privateMessageSent(PrivateMessageEvent paramPrivateMessageEvent);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.PrivateMessageListener
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum.event;

public abstract interface CategoryListener
{
  public abstract void categoryAdded(CategoryEvent paramCategoryEvent);

  public abstract void categoryDeleted(CategoryEvent paramCategoryEvent);

  public abstract void categoryMoved(CategoryEvent paramCategoryEvent);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.CategoryListener
 * JD-Core Version:    0.6.2
 */
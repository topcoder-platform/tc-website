package com.jivesoftware.forum.event;

public abstract interface AnnouncementListener
{
  public abstract void announcementCreated(AnnouncementEvent paramAnnouncementEvent);

  public abstract void announcementDeleted(AnnouncementEvent paramAnnouncementEvent);

  public abstract void announcementModified(AnnouncementEvent paramAnnouncementEvent);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.AnnouncementListener
 * JD-Core Version:    0.6.2
 */
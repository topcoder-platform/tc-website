package com.jivesoftware.forum.event;

public abstract class CategoryListenerAdapter
  implements CategoryListener
{
  public void categoryAdded(CategoryEvent event)
  {
  }

  public void categoryDeleted(CategoryEvent event)
  {
  }

  public void categoryMoved(CategoryEvent event)
  {
  }
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.CategoryListenerAdapter
 * JD-Core Version:    0.6.2
 */
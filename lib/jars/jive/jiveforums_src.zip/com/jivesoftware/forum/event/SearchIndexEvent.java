/*    */ package com.jivesoftware.forum.event;
/*    */ 
/*    */ import com.jivesoftware.base.JiveEvent;
/*    */ import java.util.Collections;
/*    */ import java.util.Date;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class SearchIndexEvent
/*    */   implements JiveEvent
/*    */ {
/*    */   public static final int MESSAGE_ADDED = 140;
/*    */   public static final int MESSAGE_DELETED = 141;
/*    */   public static final int REBUILD_STARTED = 142;
/*    */   public static final int REBUILD_COMPLETED = 143;
/*    */   public static final int UPDATE_STARTED = 144;
/*    */   public static final int UPDATE_COMPLETED = 145;
/*    */   public static final int OPTIMIZE_STARTED = 146;
/*    */   public static final int OPTIMIZE_COMPLETED = 147;
/* 67 */   private int eventType = -1;
/* 68 */   private Map params = new HashMap();
/* 69 */   private Date date = null;
/*    */ 
/*    */   public SearchIndexEvent(int eventType, Map params) {
/* 72 */     this.eventType = eventType;
/* 73 */     this.params = (params == null ? null : Collections.unmodifiableMap(params));
/* 74 */     this.date = new Date();
/*    */   }
/*    */ 
/*    */   public int getEventType() {
/* 78 */     return this.eventType;
/*    */   }
/*    */ 
/*    */   public Map getParams() {
/* 82 */     return this.params;
/*    */   }
/*    */ 
/*    */   public Date getDate() {
/* 86 */     return this.date;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.SearchIndexEvent
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum.event;

public abstract class ForumListenerAdapter
  implements ForumListener
{
  public void forumAdded(ForumEvent event)
  {
  }

  public void forumDeleted(ForumEvent event)
  {
  }

  public void forumMoved(ForumEvent event)
  {
  }

  public void forumMerged(ForumEvent event)
  {
  }
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.ForumListenerAdapter
 * JD-Core Version:    0.6.2
 */
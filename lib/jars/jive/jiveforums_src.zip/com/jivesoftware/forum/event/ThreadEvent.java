/*     */ package com.jivesoftware.forum.event;
/*     */ 
/*     */ import com.jivesoftware.base.JiveEvent;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ThreadEvent
/*     */   implements JiveEvent
/*     */ {
/*     */   public static final int THREAD_ADDED = 110;
/*     */   public static final int THREAD_DELETING = 111;
/*     */   public static final int THREAD_MOVED = 112;
/*     */   public static final int THREAD_MODERATION_MODIFIED = 113;
/*     */   public static final int THREAD_RATED = 114;
/*     */   private int eventType;
/*     */   private ForumThread thread;
/*     */   private Date date;
/*     */   private Map params;
/*     */ 
/*     */   public ThreadEvent(int eventType, ForumThread thread, Map params)
/*     */   {
/*  79 */     this.eventType = eventType;
/*  80 */     this.thread = thread;
/*  81 */     this.params = (params == null ? null : Collections.unmodifiableMap(params));
/*  82 */     this.date = new Date();
/*     */   }
/*     */ 
/*     */   public int getEventType() {
/*  86 */     return this.eventType;
/*     */   }
/*     */ 
/*     */   public ForumThread getThread()
/*     */   {
/*  95 */     return this.thread;
/*     */   }
/*     */ 
/*     */   public Map getParams() {
/*  99 */     return this.params;
/*     */   }
/*     */ 
/*     */   public Date getDate() {
/* 103 */     return this.date;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.ThreadEvent
 * JD-Core Version:    0.6.2
 */
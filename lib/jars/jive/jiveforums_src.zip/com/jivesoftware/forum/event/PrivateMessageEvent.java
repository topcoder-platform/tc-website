/*    */ package com.jivesoftware.forum.event;
/*    */ 
/*    */ import com.jivesoftware.base.JiveEvent;
/*    */ import com.jivesoftware.forum.PrivateMessage;
/*    */ import java.util.Collections;
/*    */ import java.util.Date;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class PrivateMessageEvent
/*    */   implements JiveEvent
/*    */ {
/*    */   public static final int PRIVATE_MESSAGE_SENT = 140;
/*    */   private int eventType;
/*    */   private PrivateMessage privateMessage;
/*    */   private Date date;
/*    */   private Map params;
/*    */ 
/*    */   public PrivateMessageEvent(int eventType, PrivateMessage privateMessage, Map params)
/*    */   {
/* 53 */     this.eventType = eventType;
/* 54 */     this.privateMessage = privateMessage;
/* 55 */     this.params = (params == null ? null : Collections.unmodifiableMap(params));
/* 56 */     this.date = new Date();
/*    */   }
/*    */ 
/*    */   public int getEventType() {
/* 60 */     return this.eventType;
/*    */   }
/*    */ 
/*    */   public PrivateMessage getPrivateMessage()
/*    */   {
/* 69 */     return this.privateMessage;
/*    */   }
/*    */ 
/*    */   public Map getParams() {
/* 73 */     return this.params;
/*    */   }
/*    */ 
/*    */   public Date getDate() {
/* 77 */     return this.date;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.PrivateMessageEvent
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.event;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.util.ClassUtils;
/*     */ import com.jivesoftware.util.profile.Profiler;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class MessageEventDispatcher
/*     */ {
/*  29 */   private static MessageEventDispatcher instance = new MessageEventDispatcher();
/*     */ 
/*  35 */   private ArrayList listeners = new ArrayList();
/*     */ 
/*     */   public static MessageEventDispatcher getInstance()
/*     */   {
/*  32 */     return instance;
/*     */   }
/*     */ 
/*     */   private MessageEventDispatcher()
/*     */   {
/*  39 */     List listenerList = JiveGlobals.getJiveProperties("eventListeners.MessageListener");
/*  40 */     for (int i = 0; i < listenerList.size(); i++) {
/*  41 */       String listenerStr = (String)listenerList.get(i);
/*     */       try {
/*  43 */         MessageListener listener = (MessageListener)ClassUtils.forName(listenerStr).newInstance();
/*  44 */         this.listeners.add(listener);
/*     */       }
/*     */       catch (Exception e) {
/*  47 */         Log.error("Error loading MessageListener", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void addListener(MessageListener listener) {
/*  53 */     if (listener == null) {
/*  54 */       throw new NullPointerException();
/*     */     }
/*     */ 
/*  57 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */   public synchronized void removeListener(MessageListener listener) {
/*  61 */     this.listeners.remove(listener);
/*     */   }
/*     */ 
/*     */   public void dispatchEvent(MessageEvent event) {
/*  65 */     Profiler.begin("msgDispatchEvent");
/*  66 */     int eventType = event.getEventType();
/*     */ 
/*  68 */     for (int i = 0; i < this.listeners.size(); i++) {
/*     */       try {
/*  70 */         MessageListener listener = (MessageListener)this.listeners.get(i);
/*  71 */         String name = listener.getClass().getName();
/*  72 */         name = name.substring(name.lastIndexOf('.') + 1);
/*  73 */         Profiler.begin(name);
/*     */ 
/*  75 */         switch (eventType) {
/*     */         case 100:
/*  77 */           listener.messageAdded(event);
/*  78 */           break;
/*     */         case 101:
/*  81 */           listener.messageDeleted(event);
/*  82 */           break;
/*     */         case 102:
/*  85 */           listener.messageModified(event);
/*  86 */           break;
/*     */         case 103:
/*  89 */           listener.messageModerationModified(event);
/*  90 */           break;
/*     */         case 104:
/*  93 */           listener.messageRated(event);
/*  94 */           break;
/*     */         case 105:
/*  97 */           listener.messageMoved(event);
/*     */         }
/*     */ 
/* 103 */         Profiler.end(name);
/*     */       }
/*     */       catch (Exception e) {
/* 106 */         Log.error(e);
/*     */       }
/*     */     }
/* 109 */     Profiler.end("msgDispatchEvent");
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.MessageEventDispatcher
 * JD-Core Version:    0.6.2
 */
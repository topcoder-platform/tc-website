package com.jivesoftware.forum.event;

public abstract interface MessageListener
{
  public abstract void messageAdded(MessageEvent paramMessageEvent);

  public abstract void messageDeleted(MessageEvent paramMessageEvent);

  public abstract void messageMoved(MessageEvent paramMessageEvent);

  public abstract void messageModified(MessageEvent paramMessageEvent);

  public abstract void messageModerationModified(MessageEvent paramMessageEvent);

  public abstract void messageRated(MessageEvent paramMessageEvent);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.MessageListener
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.event;
/*     */ 
/*     */ import com.jivesoftware.base.JiveEvent;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class MessageEvent
/*     */   implements JiveEvent
/*     */ {
/*     */   public static final int MESSAGE_ADDED = 100;
/*     */   public static final int MESSAGE_DELETED = 101;
/*     */   public static final int MESSAGE_MODIFIED = 102;
/*     */   public static final int MESSAGE_MODERATION_MODIFIED = 103;
/*     */   public static final int MESSAGE_RATED = 104;
/*     */   public static final int MESSAGE_MOVED = 105;
/*     */   private int eventType;
/*     */   private ForumMessage message;
/*     */   private Date date;
/*     */   private Map params;
/*     */ 
/*     */   public MessageEvent(int eventType, ForumMessage message, Map params)
/*     */   {
/*  88 */     this.eventType = eventType;
/*  89 */     this.message = message;
/*  90 */     this.params = (params == null ? null : Collections.unmodifiableMap(params));
/*  91 */     this.date = new Date();
/*     */   }
/*     */ 
/*     */   public int getEventType() {
/*  95 */     return this.eventType;
/*     */   }
/*     */ 
/*     */   public ForumMessage getMessage()
/*     */   {
/* 104 */     return this.message;
/*     */   }
/*     */ 
/*     */   public Map getParams() {
/* 108 */     return this.params;
/*     */   }
/*     */ 
/*     */   public Date getDate() {
/* 112 */     return this.date;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.MessageEvent
 * JD-Core Version:    0.6.2
 */
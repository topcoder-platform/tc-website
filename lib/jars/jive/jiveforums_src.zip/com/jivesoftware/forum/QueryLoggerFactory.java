/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.JiveGlobals;
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.forum.database.DbQueryLogger;
/*    */ import com.jivesoftware.forum.proxy.QueryLoggerProxy;
/*    */ import com.jivesoftware.util.ClassUtils;
/*    */ 
/*    */ public class QueryLoggerFactory
/*    */ {
/*    */   private static QueryLogger queryLogger;
/*    */ 
/*    */   public static QueryLogger getInstance(AuthToken authToken)
/*    */   {
/* 41 */     if (queryLogger != null) {
/* 42 */       return new QueryLoggerProxy(queryLogger, authToken, ForumFactory.getInstance(authToken).getPermissions(authToken));
/*    */     }
/*    */ 
/* 48 */     String className = JiveGlobals.getJiveProperty("QueryLogger.className");
/* 49 */     if (className != null) {
/*    */       try {
/* 51 */         Class c = ClassUtils.forName(className);
/* 52 */         queryLogger = (QueryLogger)c.newInstance();
/*    */       }
/*    */       catch (Exception e) {
/* 55 */         Log.fatal("Error loading custom QueryLogger " + className, e);
/* 56 */         queryLogger = DbQueryLogger.getInstance();
/*    */       }
/*    */     }
/*    */     else {
/* 60 */       queryLogger = DbQueryLogger.getInstance();
/*    */     }
/*    */ 
/* 63 */     return new QueryLoggerProxy(queryLogger, authToken, ForumFactory.getInstance(authToken).getPermissions(authToken));
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.QueryLoggerFactory
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.ArchiveManager;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class ArchiveManagerProxy
/*     */   implements ArchiveManager
/*     */ {
/*     */   private ArchiveManager archiveManager;
/*     */   private AuthToken authToken;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public ArchiveManagerProxy(ArchiveManager archiveManager, AuthToken authToken, Permissions permissions)
/*     */   {
/*  32 */     this.archiveManager = archiveManager;
/*  33 */     this.authToken = authToken;
/*  34 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public boolean isArchivingEnabled(Forum forum) {
/*  38 */     return this.archiveManager.isArchivingEnabled(forum);
/*     */   }
/*     */ 
/*     */   public void setArchivingEnabled(Forum forum, boolean enabled) throws UnauthorizedException {
/*  42 */     if (isAdmin(forum)) {
/*  43 */       this.archiveManager.setArchivingEnabled(forum, enabled);
/*     */     }
/*     */     else
/*  46 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getArchiveDays(Forum forum)
/*     */   {
/*  51 */     return this.archiveManager.getArchiveDays(forum);
/*     */   }
/*     */ 
/*     */   public void setArchiveDays(Forum forum, int days) throws UnauthorizedException {
/*  55 */     if (isAdmin(forum)) {
/*  56 */       this.archiveManager.setArchiveDays(forum, days);
/*     */     }
/*     */     else
/*  59 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getArchiveMode(Forum forum)
/*     */   {
/*  64 */     return this.archiveManager.getArchiveMode(forum);
/*     */   }
/*     */ 
/*     */   public void setArchiveMode(Forum forum, int mode) throws UnauthorizedException {
/*  68 */     if (isAdmin(forum)) {
/*  69 */       this.archiveManager.setArchiveMode(forum, mode);
/*     */     }
/*     */     else
/*  72 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Forum getArchiveForum(Forum forum) throws UnauthorizedException
/*     */   {
/*  77 */     if (isAdmin(forum)) {
/*  78 */       Forum archiveForum = this.archiveManager.getArchiveForum(forum);
/*     */ 
/*  81 */       if (archiveForum == null) {
/*  82 */         return null;
/*     */       }
/*     */ 
/*  85 */       Permissions forumPermissions = archiveForum.getPermissions(this.authToken);
/*     */ 
/*  88 */       Permissions newPermissions = new Permissions(this.permissions, forumPermissions);
/*     */ 
/*  91 */       if (!newPermissions.hasPermission(576460752303424385L))
/*     */       {
/*  95 */         throw new UnauthorizedException();
/*     */       }
/*  97 */       return new ForumProxy(archiveForum, this.authToken, newPermissions);
/*     */     }
/*     */ 
/* 100 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void setArchiveForum(Forum forum, Forum archiveForum) throws UnauthorizedException
/*     */   {
/* 105 */     if ((isAdmin(forum)) && (isAdmin(archiveForum))) {
/* 106 */       this.archiveManager.setArchiveForum(forum, archiveForum);
/*     */     }
/*     */     else
/* 109 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean isAutoArchiveEnabled()
/*     */     throws UnauthorizedException
/*     */   {
/* 115 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 116 */       return this.archiveManager.isAutoArchiveEnabled();
/*     */     }
/*     */ 
/* 119 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void setAutoArchiveEnabled(boolean enabled) throws UnauthorizedException
/*     */   {
/* 124 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 125 */       this.archiveManager.setAutoArchiveEnabled(enabled);
/*     */     }
/*     */     else
/* 128 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getAutoArchiveInterval() throws UnauthorizedException
/*     */   {
/* 133 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 134 */       return this.archiveManager.getAutoArchiveInterval();
/*     */     }
/*     */ 
/* 137 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void setAutoArchiveInterval(int interval) throws UnauthorizedException
/*     */   {
/* 142 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 143 */       this.archiveManager.setAutoArchiveInterval(interval);
/*     */     }
/*     */     else
/* 146 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean isBusy() throws UnauthorizedException
/*     */   {
/* 151 */     return this.archiveManager.isBusy();
/*     */   }
/*     */ 
/*     */   public Date getLastArchivedDate() throws UnauthorizedException {
/* 155 */     return this.archiveManager.getLastArchivedDate();
/*     */   }
/*     */ 
/*     */   public void runArchiver() throws UnauthorizedException {
/* 159 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 160 */       this.archiveManager.runArchiver();
/*     */     }
/*     */     else
/* 163 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   private boolean isAdmin(Forum forum)
/*     */   {
/* 168 */     return (this.permissions.hasPermission(576460752303423488L)) || (forum.isAuthorized(512L)) || (forum.isAuthorized(256L));
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.ArchiveManagerProxy
 * JD-Core Version:    0.6.2
 */
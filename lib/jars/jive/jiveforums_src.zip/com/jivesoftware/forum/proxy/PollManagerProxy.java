/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.Poll;
/*     */ import com.jivesoftware.base.PollException;
/*     */ import com.jivesoftware.base.PollManager;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class PollManagerProxy
/*     */   implements PollManager
/*     */ {
/*     */   private PollManager manager;
/*     */   private AuthToken authToken;
/*     */ 
/*     */   public PollManagerProxy(PollManager manager, AuthToken authToken, Permissions permissions)
/*     */   {
/*  41 */     this.manager = manager;
/*  42 */     this.authToken = authToken;
/*     */   }
/*     */ 
/*     */   public Poll createPoll(int objectType, long objectID, User user, String name) throws UnauthorizedException {
/*  46 */     if (isAuthorized(objectType, objectID)) {
/*  47 */       return this.manager.createPoll(objectType, objectID, user, name);
/*     */     }
/*     */ 
/*  50 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deletePoll(Poll poll) throws UnauthorizedException, PollException
/*     */   {
/*  55 */     if (isAuthorized(poll.getObjectType(), poll.getObjectID())) {
/*  56 */       this.manager.deletePoll(poll);
/*     */     }
/*     */     else
/*  59 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getPollCount()
/*     */   {
/*  64 */     return this.manager.getPollCount();
/*     */   }
/*     */ 
/*     */   public Iterator getPolls() {
/*  68 */     return new IteratorProxy(18, this.manager.getPolls(), this.authToken);
/*     */   }
/*     */ 
/*     */   public int getPollCount(int objectType, long objectID) throws UnauthorizedException {
/*  72 */     if (getPermissions(objectType, objectID).value() != 0L) {
/*  73 */       return this.manager.getPollCount(objectType, objectID);
/*     */     }
/*     */ 
/*  76 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getPolls(int objectType, long objectID) throws UnauthorizedException
/*     */   {
/*  81 */     if (getPermissions(objectType, objectID).value() != 0L) {
/*  82 */       return new IteratorProxy(18, this.manager.getPolls(objectType, objectID), this.authToken);
/*     */     }
/*     */ 
/*  85 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getActivePolls()
/*     */   {
/*  90 */     return new IteratorProxy(18, this.manager.getActivePolls(), this.authToken);
/*     */   }
/*     */ 
/*     */   public int getActivePollCount() {
/*  94 */     return this.manager.getActivePollCount();
/*     */   }
/*     */ 
/*     */   public Iterator getActivePolls(int objectType, long objectID) throws UnauthorizedException {
/*  98 */     if (getPermissions(objectType, objectID).value() != 0L) {
/*  99 */       return new IteratorProxy(18, this.manager.getActivePolls(objectType, objectID), this.authToken);
/*     */     }
/*     */ 
/* 102 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getActivePollCount(int objectType, long objectID)
/*     */   {
/* 107 */     return this.manager.getActivePollCount(objectType, objectID);
/*     */   }
/*     */ 
/*     */   public Poll getPoll(long pollID) throws UnauthorizedException, NotFoundException {
/* 111 */     Poll poll = this.manager.getPoll(pollID);
/* 112 */     int objectType = poll.getObjectType();
/* 113 */     long objectID = poll.getObjectID();
/*     */ 
/* 115 */     Permissions perms = getPermissions(objectType, objectID);
/* 116 */     if (perms.value() != 0L) {
/* 117 */       return new PollProxy(poll, perms);
/*     */     }
/*     */ 
/* 120 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   private Permissions getPermissions(int objectType, long objectID) throws UnauthorizedException
/*     */   {
/* 125 */     Permissions perms = null;
/* 126 */     ForumFactory factory = ForumFactory.getInstance(this.authToken);
/*     */ 
/* 128 */     switch (objectType)
/*     */     {
/*     */     case 3:
/*     */       try {
/* 132 */         perms = factory.getUserManager().getUser(objectID).getPermissions(this.authToken);
/*     */       }
/*     */       catch (UserNotFoundException e)
/*     */       {
/* 136 */         return new Permissions(0L);
/*     */       }
/*     */     case 14:
/*     */       try
/*     */       {
/* 141 */         perms = factory.getForumCategory(objectID).getPermissions(this.authToken);
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e) {
/* 144 */         return new Permissions(0L);
/*     */       }
/*     */ 
/*     */     case 0:
/*     */       try
/*     */       {
/* 150 */         perms = factory.getForum(objectID).getPermissions(this.authToken);
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 153 */         return new Permissions(0L);
/*     */       }
/*     */ 
/*     */     case 1:
/*     */       try
/*     */       {
/* 159 */         perms = factory.getForumThread(objectID).getForum().getPermissions(this.authToken);
/*     */       }
/*     */       catch (ForumThreadNotFoundException e) {
/* 162 */         return new Permissions(0L);
/*     */       }
/*     */ 
/*     */     case 2:
/*     */       try
/*     */       {
/* 168 */         perms = factory.getMessage(objectID).getForumThread().getForum().getPermissions(this.authToken);
/*     */       }
/*     */       catch (ForumMessageNotFoundException e) {
/* 171 */         return new Permissions(0L);
/*     */       }
/*     */ 
/*     */     case 17:
/* 176 */       perms = factory.getPermissions(this.authToken);
/* 177 */       break;
/*     */     case 4:
/*     */     case 5:
/*     */     case 6:
/*     */     case 7:
/*     */     case 8:
/*     */     case 9:
/*     */     case 10:
/*     */     case 11:
/*     */     case 12:
/*     */     case 13:
/*     */     case 15:
/* 180 */     case 16: } throw new UnauthorizedException();
/*     */ 
/* 183 */     if (perms.hasPermission(576460752303424385L))
/*     */     {
/* 190 */       return perms;
/*     */     }
/*     */ 
/* 193 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   private boolean isAuthorized(int objectType, long objectID)
/*     */   {
/* 198 */     ForumFactory factory = ForumFactory.getInstance(this.authToken);
/*     */ 
/* 201 */     if (factory.isAuthorized(576460752303423616L)) {
/* 202 */       return true;
/*     */     }
/*     */ 
/* 205 */     switch (objectType)
/*     */     {
/*     */     case 3:
/* 208 */       if ((factory.isAuthorized(144115188075855872L)) || (this.authToken.getUserID() == objectID)) {
/* 209 */         return true;
/*     */       }
/*     */ 
/*     */       break;
/*     */     case 14:
/*     */       try
/*     */       {
/* 216 */         if (factory.getForumCategory(objectID).isAuthorized(528L))
/*     */         {
/* 220 */           return true;
/*     */         }
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e) {
/* 224 */         Log.error(e);
/*     */       }
/*     */ 
/*     */     case 0:
/*     */       try
/*     */       {
/* 231 */         if (factory.getForum(objectID).isAuthorized(784L))
/*     */         {
/* 236 */           return true;
/*     */         }
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 240 */         Log.error(e);
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 243 */         return false;
/*     */       }
/*     */ 
/*     */     case 1:
/*     */       try
/*     */       {
/* 249 */         if (factory.getForumThread(objectID).isAuthorized(784L))
/*     */         {
/* 254 */           return true;
/*     */         }
/*     */       }
/*     */       catch (ForumThreadNotFoundException e) {
/* 258 */         Log.error(e);
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 261 */         return false;
/*     */       }
/*     */ 
/*     */     case 2:
/*     */       try
/*     */       {
/* 267 */         ForumMessage message = factory.getMessage(objectID);
/* 268 */         if (message.isAuthorized(784L))
/*     */         {
/* 273 */           return true;
/*     */         }
/*     */       }
/*     */       catch (ForumMessageNotFoundException e) {
/* 277 */         Log.error(e);
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 280 */         return false; } case 4:
/*     */     case 5:
/*     */     case 6:
/*     */     case 7:
/*     */     case 8:
/*     */     case 9:
/*     */     case 10:
/*     */     case 11:
/*     */     case 12:
/*     */     case 13:
/*     */     default:
/* 285 */       return false;
/*     */     }
/*     */ 
/* 288 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.PollManagerProxy
 * JD-Core Version:    0.6.2
 */
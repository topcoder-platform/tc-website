/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Announcement;
/*     */ import com.jivesoftware.forum.AnnouncementManager;
/*     */ import com.jivesoftware.forum.AnnouncementNotFoundException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class AnnouncementManagerProxy
/*     */   implements AnnouncementManager
/*     */ {
/*     */   private AnnouncementManager manager;
/*     */   private AuthToken authToken;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public AnnouncementManagerProxy(AnnouncementManager manager, AuthToken authToken, Permissions permissions)
/*     */   {
/*  39 */     this.manager = manager;
/*  40 */     this.authToken = authToken;
/*  41 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public Announcement createAnnouncement(User user)
/*     */     throws UnauthorizedException
/*     */   {
/*  47 */     if ((!this.permissions.hasPermission(576460752303423488L)) && (user.getID() != this.authToken.getUserID()))
/*     */     {
/*  50 */       throw new UnauthorizedException("Not allowed to create an announcement as user " + user);
/*     */     }
/*  52 */     if (isAdmin(this.permissions)) {
/*  53 */       return new AnnouncementProxy(this.manager.createAnnouncement(user), this.authToken, this.permissions);
/*     */     }
/*     */ 
/*  56 */     throw new UnauthorizedException("Not allowed to create a system announcement.");
/*     */   }
/*     */ 
/*     */   public Announcement createAnnouncement(User user, ForumCategory category)
/*     */     throws UnauthorizedException
/*     */   {
/*  63 */     if ((!this.permissions.hasPermission(576460752303423488L)) && (user.getID() != this.authToken.getUserID()))
/*     */     {
/*  66 */       throw new UnauthorizedException("Not allowed to create an announcement as user " + user);
/*     */     }
/*  68 */     Permissions permissions = category.getPermissions(this.authToken);
/*  69 */     if (isAdmin(permissions)) {
/*  70 */       return new AnnouncementProxy(this.manager.createAnnouncement(user, category), this.authToken, permissions);
/*     */     }
/*     */ 
/*  74 */     throw new UnauthorizedException("Not allowed to create an announcement in category " + category);
/*     */   }
/*     */ 
/*     */   public Announcement createAnnouncement(User user, Forum forum)
/*     */     throws UnauthorizedException
/*     */   {
/*  82 */     if ((!this.permissions.hasPermission(576460752303423488L)) && (user.getID() != this.authToken.getUserID()))
/*     */     {
/*  85 */       throw new UnauthorizedException("Not allowed to create an announcement as user " + user);
/*     */     }
/*  87 */     Permissions permissions = forum.getPermissions(this.authToken);
/*  88 */     if (isAdmin(permissions)) {
/*  89 */       return new AnnouncementProxy(this.manager.createAnnouncement(user, forum), this.authToken, permissions);
/*     */     }
/*     */ 
/*  93 */     throw new UnauthorizedException("Not allowed to create an announcement in forum " + forum);
/*     */   }
/*     */ 
/*     */   public void addAnnouncement(Announcement announcement)
/*     */     throws UnauthorizedException
/*     */   {
/* 101 */     if ((this.permissions.hasPermission(576460752303423488L)) || (this.authToken.getUserID() == announcement.getUser().getID()))
/*     */     {
/* 104 */       this.manager.addAnnouncement(announcement);
/*     */     }
/*     */     else
/* 107 */       throw new UnauthorizedException("Not allowed to add announcement.");
/*     */   }
/*     */ 
/*     */   public Announcement getAnnouncement(long announcementID)
/*     */     throws AnnouncementNotFoundException, UnauthorizedException
/*     */   {
/* 114 */     Announcement announcement = this.manager.getAnnouncement(announcementID);
/*     */ 
/* 116 */     if (announcement.getContainerObjectType() == 17) {
/* 117 */       return new AnnouncementProxy(announcement, this.authToken, this.permissions);
/*     */     }
/* 119 */     if (announcement.getContainerObjectType() == 14) {
/* 120 */       DbForumFactory factory = DbForumFactory.getInstance();
/*     */       try {
/* 122 */         ForumCategory category = factory.getForumCategory(announcement.getContainerObjectID());
/*     */ 
/* 124 */         Permissions catPermissions = category.getPermissions(this.authToken);
/* 125 */         if ((isAdmin(catPermissions)) || (catPermissions.hasPermission(1L)))
/*     */         {
/* 128 */           return new AnnouncementProxy(announcement, this.authToken, catPermissions);
/*     */         }
/*     */ 
/* 131 */         throw new UnauthorizedException();
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e)
/*     */       {
/* 135 */         Log.error(e);
/* 136 */         throw new AnnouncementNotFoundException();
/*     */       }
/*     */     }
/* 139 */     if (announcement.getContainerObjectType() == 0) {
/* 140 */       DbForumFactory factory = DbForumFactory.getInstance();
/*     */       try {
/* 142 */         Forum forum = factory.getForum(announcement.getContainerObjectID());
/*     */ 
/* 144 */         Permissions forumPermissions = forum.getPermissions(this.authToken);
/* 145 */         if ((isAdmin(forumPermissions)) || (forumPermissions.hasPermission(1L)))
/*     */         {
/* 148 */           return new AnnouncementProxy(announcement, this.authToken, forumPermissions);
/*     */         }
/*     */ 
/* 151 */         throw new UnauthorizedException();
/*     */       }
/*     */       catch (ForumNotFoundException e)
/*     */       {
/* 155 */         Log.error(e);
/* 156 */         throw new AnnouncementNotFoundException();
/*     */       }
/*     */     }
/* 159 */     throw new AnnouncementNotFoundException();
/*     */   }
/*     */ 
/*     */   public int getAnnouncementCount(Object container) {
/* 163 */     if (container == null) {
/* 164 */       return this.manager.getAnnouncementCount(null);
/*     */     }
/*     */ 
/* 167 */     return this.manager.getAnnouncementCount(container);
/*     */   }
/*     */ 
/*     */   public int getAnnouncementCount(Object container, Date startDate, Date endDate)
/*     */   {
/* 172 */     if (container == null) {
/* 173 */       return this.manager.getAnnouncementCount(null, startDate, endDate);
/*     */     }
/*     */ 
/* 176 */     return this.manager.getAnnouncementCount(container, startDate, endDate);
/*     */   }
/*     */ 
/*     */   public Iterator getAnnouncements(Object container)
/*     */   {
/* 181 */     if (container == null) {
/* 182 */       return this.manager.getAnnouncements(null);
/*     */     }
/* 184 */     Permissions permissions = null;
/* 185 */     if ((container instanceof ForumCategory)) {
/* 186 */       permissions = ((ForumCategory)container).getPermissions(this.authToken);
/*     */     }
/* 188 */     else if ((container instanceof Forum)) {
/* 189 */       permissions = ((Forum)container).getPermissions(this.authToken);
/*     */     }
/* 191 */     return new AnnouncementIteratorProxy(this.manager.getAnnouncements(container), this.authToken, permissions);
/*     */   }
/*     */ 
/*     */   public Iterator getAnnouncements(Object container, Date startDate, Date endDate) {
/* 195 */     if (container == null) {
/* 196 */       return this.manager.getAnnouncements(null, startDate, endDate);
/*     */     }
/* 198 */     Permissions permissions = null;
/* 199 */     if ((container instanceof ForumCategory)) {
/* 200 */       permissions = ((ForumCategory)container).getPermissions(this.authToken);
/*     */     }
/* 202 */     else if ((container instanceof Forum)) {
/* 203 */       permissions = ((Forum)container).getPermissions(this.authToken);
/*     */     }
/* 205 */     return new AnnouncementIteratorProxy(this.manager.getAnnouncements(container, startDate, endDate), this.authToken, permissions);
/*     */   }
/*     */ 
/*     */   public void deleteAnnouncement(Announcement announcement) throws UnauthorizedException
/*     */   {
/* 210 */     Permissions permissions = null;
/*     */ 
/* 212 */     if (announcement.getContainerObjectType() == 17) {
/* 213 */       permissions = this.permissions;
/*     */     }
/* 215 */     else if (announcement.getContainerObjectType() == 14) {
/* 216 */       DbForumFactory factory = DbForumFactory.getInstance();
/*     */       try {
/* 218 */         ForumCategory category = factory.getForumCategory(announcement.getContainerObjectID());
/*     */ 
/* 220 */         permissions = category.getPermissions(this.authToken);
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e) {
/* 223 */         Log.error(e);
/*     */       }
/*     */     }
/* 226 */     else if (announcement.getContainerObjectType() == 0) {
/* 227 */       DbForumFactory factory = DbForumFactory.getInstance();
/*     */       try {
/* 229 */         Forum forum = factory.getForum(announcement.getContainerObjectID());
/* 230 */         permissions = forum.getPermissions(this.authToken);
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 233 */         Log.error(e);
/*     */       }
/*     */     }
/* 236 */     if (isAdmin(permissions)) {
/* 237 */       this.manager.deleteAnnouncement(announcement);
/*     */     }
/*     */     else
/* 240 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   private boolean isAdmin(Permissions permissions)
/*     */   {
/* 245 */     return permissions.hasPermission(576460752303428480L);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.AnnouncementManagerProxy
 * JD-Core Version:    0.6.2
 */
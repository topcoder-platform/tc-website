/*    */ package com.jivesoftware.forum.proxy;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.Permissions;
/*    */ import com.jivesoftware.forum.ForumMessage;
/*    */ import com.jivesoftware.forum.ForumMessageIterator;
/*    */ 
/*    */ public class ForumMessageIteratorProxy extends ForumMessageIterator
/*    */ {
/*    */   ForumMessageIterator iterator;
/*    */   AuthToken authToken;
/*    */   Permissions permissions;
/*    */ 
/*    */   public ForumMessageIteratorProxy(ForumMessageIterator iterator, AuthToken authToken, Permissions permissions)
/*    */   {
/* 17 */     this.iterator = iterator;
/* 18 */     this.authToken = authToken;
/* 19 */     this.permissions = permissions;
/*    */   }
/*    */ 
/*    */   public boolean hasNext() {
/* 23 */     return this.iterator.hasNext();
/*    */   }
/*    */ 
/*    */   public Object next() {
/* 27 */     return new ForumMessageProxy((ForumMessage)this.iterator.next(), this.authToken, this.permissions);
/*    */   }
/*    */ 
/*    */   public boolean hasPrevious() {
/* 31 */     return this.iterator.hasPrevious();
/*    */   }
/*    */ 
/*    */   public Object previous() {
/* 35 */     return new ForumMessageProxy((ForumMessage)this.iterator.previous(), this.authToken, this.permissions);
/*    */   }
/*    */ 
/*    */   public void setIndex(long messageID) {
/* 39 */     this.iterator.setIndex(messageID);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.ForumMessageIteratorProxy
 * JD-Core Version:    0.6.2
 */
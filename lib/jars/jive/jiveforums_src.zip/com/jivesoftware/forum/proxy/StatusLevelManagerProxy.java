/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Group;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserGroupIteratorProxy;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.StatusLevel;
/*     */ import com.jivesoftware.forum.StatusLevelAlreadyExistsException;
/*     */ import com.jivesoftware.forum.StatusLevelException;
/*     */ import com.jivesoftware.forum.StatusLevelManager;
/*     */ import com.jivesoftware.forum.StatusLevelNotFoundException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class StatusLevelManagerProxy
/*     */   implements StatusLevelManager
/*     */ {
/*     */   private StatusLevelManager statusLevelManager;
/*     */   private AuthToken authToken;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public StatusLevelManagerProxy(StatusLevelManager statusLevelManager, AuthToken authToken, Permissions permissions)
/*     */   {
/*  31 */     this.statusLevelManager = statusLevelManager;
/*  32 */     this.authToken = authToken;
/*  33 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public StatusLevel createStatusLevel(String name, String imagePath, int minPoints, int maxPoints)
/*     */     throws UnauthorizedException, StatusLevelException, StatusLevelAlreadyExistsException
/*     */   {
/*  43 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/*  44 */       throw new UnauthorizedException("Requires SYSTEM_ADMIN privilege!");
/*     */     }
/*     */ 
/*  47 */     return this.statusLevelManager.createStatusLevel(name, imagePath, minPoints, maxPoints);
/*     */   }
/*     */ 
/*     */   public StatusLevel createStatusLevel(String name, String imagePath, Group group)
/*     */     throws UnauthorizedException, StatusLevelException, StatusLevelAlreadyExistsException
/*     */   {
/*  53 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/*  54 */       throw new UnauthorizedException("Requires SYSTEM_ADMIN privilege!");
/*     */     }
/*     */ 
/*  57 */     return this.statusLevelManager.createStatusLevel(name, imagePath, group);
/*     */   }
/*     */ 
/*     */   public void deleteStatusLevel(StatusLevel statusLevel) throws UnauthorizedException {
/*  61 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/*  62 */       throw new UnauthorizedException("Requires SYSTEM_ADMIN privilege!");
/*     */     }
/*     */ 
/*  65 */     this.statusLevelManager.deleteStatusLevel(statusLevel);
/*     */   }
/*     */ 
/*     */   public Iterator getGroupStatusLevels() {
/*  69 */     return new StatusLevelIteratorProxy(this.statusLevelManager.getGroupStatusLevels(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public Iterator getPointStatusLevels()
/*     */   {
/*  74 */     return new StatusLevelIteratorProxy(this.statusLevelManager.getPointStatusLevels(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public Iterator getLeaders()
/*     */   {
/*  79 */     return new UserGroupIteratorProxy(3, this.statusLevelManager.getLeaders(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public Iterator getLeaders(int startIndex, int numResults)
/*     */   {
/*  85 */     return new UserGroupIteratorProxy(3, this.statusLevelManager.getLeaders(startIndex, numResults), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public Iterator getLeaders(Forum forum)
/*     */   {
/*  90 */     return new UserGroupIteratorProxy(3, this.statusLevelManager.getLeaders(forum), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public Iterator getLeaders(Forum forum, int startIndex, int numResults)
/*     */   {
/*  95 */     return new UserGroupIteratorProxy(3, this.statusLevelManager.getLeaders(forum, startIndex, numResults), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public Iterator getLeaders(ForumCategory category)
/*     */   {
/* 101 */     return new UserGroupIteratorProxy(3, this.statusLevelManager.getLeaders(category), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public Iterator getLeaders(ForumCategory category, int startIndex, int numResults)
/*     */   {
/* 106 */     return new UserGroupIteratorProxy(3, this.statusLevelManager.getLeaders(category, startIndex, numResults), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevel(long statusLevelID)
/*     */     throws StatusLevelNotFoundException
/*     */   {
/* 112 */     return new StatusLevelProxy(this.statusLevelManager.getStatusLevel(statusLevelID), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevel(String name) throws StatusLevelNotFoundException
/*     */   {
/* 117 */     return new StatusLevelProxy(this.statusLevelManager.getStatusLevel(name), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevel(User user)
/*     */   {
/* 122 */     StatusLevel statusLevel = this.statusLevelManager.getStatusLevel(user);
/* 123 */     if (statusLevel == null) {
/* 124 */       return null;
/*     */     }
/* 126 */     return new StatusLevelProxy(statusLevel, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevel(User user, Forum forum) {
/* 130 */     StatusLevel statusLevel = this.statusLevelManager.getStatusLevel(user, forum);
/* 131 */     if (statusLevel == null) {
/* 132 */       return null;
/*     */     }
/* 134 */     return new StatusLevelProxy(statusLevel, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevel(User user, ForumCategory category) {
/* 138 */     StatusLevel statusLevel = this.statusLevelManager.getStatusLevel(user, category);
/* 139 */     if (statusLevel == null) {
/* 140 */       return null;
/*     */     }
/* 142 */     return new StatusLevelProxy(statusLevel, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public void setStatusLevelsEnabled(boolean statusLevelEnabled) throws UnauthorizedException {
/* 146 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/* 147 */       throw new UnauthorizedException("Requires SYSTEM_ADMIN privilege!");
/*     */     }
/* 149 */     this.statusLevelManager.setStatusLevelsEnabled(statusLevelEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isStatusLevelsEnabled()
/*     */   {
/* 154 */     return this.statusLevelManager.isStatusLevelsEnabled();
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevelByPoints(int points) {
/* 158 */     StatusLevel statusLevel = this.statusLevelManager.getStatusLevelByPoints(points);
/* 159 */     if (statusLevel == null) {
/* 160 */       return null;
/*     */     }
/* 162 */     return new StatusLevelProxy(statusLevel, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public int getPointLevel(User user) {
/* 166 */     return this.statusLevelManager.getPointLevel(user);
/*     */   }
/*     */ 
/*     */   public int getPointLevel(User user, Forum forum) {
/* 170 */     return this.statusLevelManager.getPointLevel(user, forum);
/*     */   }
/*     */ 
/*     */   public int getPointLevel(User user, ForumCategory category) {
/* 174 */     return this.statusLevelManager.getPointLevel(user, category);
/*     */   }
/*     */ 
/*     */   public StatusLevel getStatusLevel(Group group) {
/* 178 */     StatusLevel statusLevel = this.statusLevelManager.getStatusLevel(group);
/* 179 */     if (statusLevel == null) {
/* 180 */       return null;
/*     */     }
/* 182 */     return new StatusLevelProxy(statusLevel, this.authToken, this.permissions);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.StatusLevelManagerProxy
 * JD-Core Version:    0.6.2
 */
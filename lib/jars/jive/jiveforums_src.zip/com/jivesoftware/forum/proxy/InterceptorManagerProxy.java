/*    */ package com.jivesoftware.forum.proxy;
/*    */ 
/*    */ import com.jivesoftware.base.Permissions;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.InterceptorManager;
/*    */ import com.jivesoftware.forum.MessageInterceptor;
/*    */ 
/*    */ public class InterceptorManagerProxy
/*    */   implements InterceptorManager
/*    */ {
/*    */   private InterceptorManager interceptorManager;
/*    */   private Permissions permissions;
/*    */ 
/*    */   public InterceptorManagerProxy(InterceptorManager interceptorManager, Permissions permissions)
/*    */   {
/* 27 */     this.interceptorManager = interceptorManager;
/* 28 */     this.permissions = permissions;
/*    */   }
/*    */ 
/*    */   public int getInterceptorCount() {
/* 32 */     return this.interceptorManager.getInterceptorCount();
/*    */   }
/*    */ 
/*    */   public MessageInterceptor getInterceptor(int index) {
/* 36 */     return this.interceptorManager.getInterceptor(index);
/*    */   }
/*    */ 
/*    */   public void addInterceptor(int index, MessageInterceptor interceptor) {
/* 40 */     this.interceptorManager.addInterceptor(index, interceptor);
/*    */   }
/*    */ 
/*    */   public void removeInterceptor(int index) {
/* 44 */     this.interceptorManager.removeInterceptor(index);
/*    */   }
/*    */ 
/*    */   public void saveInterceptors() {
/* 48 */     this.interceptorManager.saveInterceptors();
/*    */   }
/*    */ 
/*    */   public MessageInterceptor[] getAvailableInterceptors() {
/* 52 */     return this.interceptorManager.getAvailableInterceptors();
/*    */   }
/*    */ 
/*    */   public void addInterceptorClass(String className)
/*    */     throws UnauthorizedException, ClassNotFoundException, IllegalArgumentException
/*    */   {
/* 58 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/* 59 */       throw new UnauthorizedException();
/*    */     }
/* 61 */     this.interceptorManager.addInterceptorClass(className);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.InterceptorManagerProxy
 * JD-Core Version:    0.6.2
 */
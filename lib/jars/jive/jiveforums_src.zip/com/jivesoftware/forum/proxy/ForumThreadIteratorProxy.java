/*    */ package com.jivesoftware.forum.proxy;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.Permissions;
/*    */ import com.jivesoftware.forum.ForumThread;
/*    */ import com.jivesoftware.forum.ForumThreadIterator;
/*    */ 
/*    */ public class ForumThreadIteratorProxy extends ForumThreadIterator
/*    */ {
/*    */   ForumThreadIterator iterator;
/*    */   AuthToken authToken;
/*    */   Permissions permissions;
/*    */ 
/*    */   public ForumThreadIteratorProxy(ForumThreadIterator iterator, AuthToken authToken, Permissions permissions)
/*    */   {
/* 14 */     this.iterator = iterator;
/* 15 */     this.authToken = authToken;
/* 16 */     this.permissions = permissions;
/*    */   }
/*    */ 
/*    */   public boolean hasNext() {
/* 20 */     return this.iterator.hasNext();
/*    */   }
/*    */ 
/*    */   public Object next() {
/* 24 */     return new ForumThreadProxy((ForumThread)this.iterator.next(), this.authToken, this.permissions);
/*    */   }
/*    */ 
/*    */   public boolean hasPrevious() {
/* 28 */     return this.iterator.hasPrevious();
/*    */   }
/*    */ 
/*    */   public Object previous() {
/* 32 */     return new ForumThreadProxy((ForumThread)this.iterator.previous(), this.authToken, this.permissions);
/*    */   }
/*    */ 
/*    */   public void setIndex(ForumThread thread) {
/* 36 */     this.iterator.setIndex(thread);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.ForumThreadIteratorProxy
 * JD-Core Version:    0.6.2
 */
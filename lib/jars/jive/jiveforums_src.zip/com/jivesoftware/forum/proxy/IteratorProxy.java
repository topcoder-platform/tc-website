/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.Poll;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.PrivateMessage;
/*     */ import com.jivesoftware.forum.PrivateMessageFolder;
/*     */ import com.jivesoftware.forum.Question;
/*     */ import com.jivesoftware.forum.database.DbAttachment;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class IteratorProxy
/*     */   implements Iterator
/*     */ {
/*     */   private Iterator iterator;
/*  43 */   private Object nextElement = null;
/*     */   private AuthToken authToken;
/*     */   private ProxyFactory proxyFactory;
/*     */ 
/*     */   public IteratorProxy(int type, Iterator iterator, AuthToken authToken)
/*     */   {
/*  57 */     this.iterator = iterator;
/*  58 */     this.authToken = authToken;
/*     */ 
/*  64 */     switch (type)
/*     */     {
/*     */     case 14:
/*  68 */       this.proxyFactory = new ProxyFactory() {
/*     */         public Object createProxy(Object obj, AuthToken authToken) {
/*  70 */           ForumCategory category = (ForumCategory)obj;
/*  71 */           Permissions categoryPerms = category.getPermissions(authToken);
/*     */ 
/*  73 */           if (categoryPerms.hasPermission(576460752303424391L))
/*     */           {
/*  81 */             return new ForumCategoryProxy(category, authToken, categoryPerms);
/*     */           }
/*     */ 
/*  90 */           if (category.getForumCount() > 0)
/*     */           {
/*  92 */             ForumCategoryProxy catProxy = new ForumCategoryProxy(category, authToken, categoryPerms);
/*     */ 
/*  96 */             if (catProxy.getForums().hasNext()) {
/*  97 */               return catProxy;
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 102 */           if (category.getCategoryCount() > 0)
/*     */           {
/* 104 */             ForumCategoryProxy catProxy = new ForumCategoryProxy(category, authToken, categoryPerms);
/*     */ 
/* 108 */             if (catProxy.getCategories().hasNext()) {
/* 109 */               return catProxy;
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 114 */           return null;
/*     */         }
/*     */       };
/* 118 */       break;
/*     */     case 0:
/* 122 */       this.proxyFactory = new ProxyFactory() {
/*     */         public Object createProxy(Object obj, AuthToken authToken) {
/* 124 */           Forum forum = (Forum)obj;
/* 125 */           Permissions forumPerms = forum.getPermissions(authToken);
/*     */ 
/* 127 */           if (forumPerms.hasPermission(576460752303424391L))
/*     */           {
/* 135 */             return new ForumProxy(forum, authToken, forumPerms);
/*     */           }
/*     */ 
/* 139 */           return null;
/*     */         }
/*     */       };
/* 143 */       break;
/*     */     case 1:
/* 147 */       this.proxyFactory = new ProxyFactory()
/*     */       {
/* 157 */         long forumID = -1L;
/* 158 */         Permissions forumPerms = null;
/*     */ 
/*     */         public Object createProxy(Object obj, AuthToken authToken) {
/* 161 */           ForumThread thread = (ForumThread)obj;
/*     */ 
/* 164 */           Forum forum = thread.getForum();
/* 165 */           if (forum.getID() != this.forumID) {
/* 166 */             this.forumPerms = forum.getPermissions(authToken);
/*     */           }
/*     */ 
/* 169 */           thread = new ForumThreadProxy(thread, authToken, this.forumPerms);
/*     */ 
/* 171 */           if (thread.isAuthorized(576460752303424385L))
/*     */           {
/* 177 */             return thread;
/*     */           }
/*     */ 
/* 180 */           return null;
/*     */         }
/*     */       };
/* 184 */       break;
/*     */     case 2:
/* 188 */       this.proxyFactory = new ProxyFactory()
/*     */       {
/* 198 */         long forumID = -1L;
/* 199 */         Permissions forumPerms = null;
/*     */ 
/*     */         public Object createProxy(Object obj, AuthToken authToken) {
/* 202 */           ForumMessage message = (ForumMessage)obj;
/*     */ 
/* 205 */           Forum forum = message.getForumThread().getForum();
/* 206 */           if (forum.getID() != this.forumID) {
/* 207 */             this.forumPerms = forum.getPermissions(authToken);
/*     */           }
/*     */ 
/* 210 */           message = new ForumMessageProxy(message, authToken, this.forumPerms);
/*     */ 
/* 212 */           if (message.isAuthorized(576460752303424385L))
/*     */           {
/* 218 */             return message;
/*     */           }
/*     */ 
/* 221 */           return null;
/*     */         }
/*     */       };
/* 225 */       break;
/*     */     case 20:
/* 229 */       this.proxyFactory = new ProxyFactory() {
/*     */         public Object createProxy(Object obj, AuthToken authToken) {
/* 231 */           PrivateMessage privateMessage = (PrivateMessage)obj;
/* 232 */           ForumFactory factory = ForumFactory.getInstance(authToken);
/* 233 */           Permissions permissions = factory.getPermissions(authToken);
/*     */ 
/* 235 */           if ((permissions.hasPermission(576460752303423488L)) || (privateMessage.getFolder().getOwner().getID() == authToken.getUserID()))
/*     */           {
/* 238 */             return new PrivateMessageProxy(privateMessage, permissions);
/*     */           }
/*     */ 
/* 242 */           return null;
/*     */         }
/*     */       };
/* 246 */       break;
/*     */     case 21:
/* 250 */       this.proxyFactory = new ProxyFactory() {
/*     */         public Object createProxy(Object obj, AuthToken authToken) {
/* 252 */           PrivateMessageFolder folder = (PrivateMessageFolder)obj;
/* 253 */           ForumFactory factory = ForumFactory.getInstance(authToken);
/*     */ 
/* 255 */           if ((factory.isAuthorized(576460752303423488L)) || (folder.getOwner().getID() == authToken.getUserID()))
/*     */           {
/* 258 */             return new PrivateMessageFolderProxy(folder, authToken);
/*     */           }
/*     */ 
/* 262 */           return null;
/*     */         }
/*     */       };
/* 266 */       break;
/*     */     case 27:
/* 270 */       this.proxyFactory = new ProxyFactory() {
/*     */         public Object createProxy(Object obj, AuthToken authToken) {
/* 272 */           Question question = (Question)obj;
/* 273 */           ForumFactory factory = ForumFactory.getInstance(authToken);
/* 274 */           Permissions permissions = factory.getPermissions(authToken);
/* 275 */           return new QuestionProxy(question, authToken, permissions);
/*     */         }
/*     */       };
/* 278 */       break;
/*     */     case 18:
/* 282 */       this.proxyFactory = new ProxyFactory() {
/*     */         public Object createProxy(Object obj, AuthToken authToken) {
/* 284 */           Poll poll = (Poll)obj;
/* 285 */           ForumFactory factory = ForumFactory.getInstance(authToken);
/* 286 */           int objectType = poll.getObjectType();
/* 287 */           long objectID = poll.getObjectID();
/* 288 */           Permissions perms = null;
/*     */ 
/* 290 */           switch (objectType)
/*     */           {
/*     */           case 3:
/*     */             try {
/* 294 */               perms = factory.getUserManager().getUser(objectID).getPermissions(authToken);
/* 295 */               return new PollProxy(poll, perms);
/*     */             }
/*     */             catch (UserNotFoundException e) {
/* 298 */               return null;
/*     */             }
/*     */           case 14:
/*     */             try
/*     */             {
/* 303 */               perms = factory.getForumCategory(objectID).getPermissions(authToken);
/*     */             }
/*     */             catch (ForumCategoryNotFoundException e) {
/* 306 */               Log.error(e);
/* 307 */               return null;
/*     */             }
/*     */ 
/*     */           case 0:
/*     */             try
/*     */             {
/* 313 */               perms = factory.getForum(objectID).getPermissions(authToken);
/*     */             }
/*     */             catch (ForumNotFoundException e) {
/* 316 */               Log.error(e);
/* 317 */               return null;
/*     */             }
/*     */             catch (UnauthorizedException e) {
/* 320 */               return null;
/*     */             }
/*     */ 
/*     */           case 1:
/*     */             try
/*     */             {
/* 326 */               perms = factory.getForumThread(objectID).getForum().getPermissions(authToken);
/*     */             }
/*     */             catch (ForumThreadNotFoundException e) {
/* 329 */               Log.error(e);
/* 330 */               return null;
/*     */             }
/*     */             catch (UnauthorizedException e) {
/* 333 */               return null;
/*     */             }
/*     */ 
/*     */           case 2:
/*     */             try
/*     */             {
/* 339 */               perms = factory.getMessage(objectID).getForumThread().getForum().getPermissions(authToken);
/*     */             }
/*     */             catch (ForumMessageNotFoundException e) {
/* 342 */               Log.error(e);
/* 343 */               return null;
/*     */             }
/*     */             catch (UnauthorizedException e) {
/* 346 */               return null;
/*     */             }
/*     */ 
/*     */           case 17:
/* 351 */             perms = factory.getPermissions(authToken);
/* 352 */             break;
/*     */           case 4:
/*     */           case 5:
/*     */           case 6:
/*     */           case 7:
/*     */           case 8:
/*     */           case 9:
/*     */           case 10:
/*     */           case 11:
/*     */           case 12:
/*     */           case 13:
/*     */           case 15:
/* 355 */           case 16: } return null;
/*     */ 
/* 358 */           if (perms.hasPermission(576460752303424385L))
/*     */           {
/* 365 */             return new PollProxy(poll, perms);
/*     */           }
/*     */ 
/* 368 */           return null;
/*     */         }
/*     */       };
/* 372 */       break;
/*     */     case 13:
/* 376 */       this.proxyFactory = new ProxyFactory()
/*     */       {
/*     */         public Object createProxy(Object obj, AuthToken auth) {
/* 379 */           DbAttachment attachment = (DbAttachment)obj;
/*     */ 
/* 382 */           if (attachment.getObjectType() == 2) {
/* 383 */             ForumMessageProxy message = null;
/*     */             try
/*     */             {
/* 386 */               if (attachment.getObjectID() != -1L) {
/* 387 */                 message = (ForumMessageProxy)ForumFactory.getInstance(auth).getMessage(attachment.getObjectID());
/*     */               }
/*     */             }
/*     */             catch (ForumMessageNotFoundException e1)
/*     */             {
/* 392 */               Log.error(e1);
/* 393 */               return null;
/*     */             }
/*     */             catch (UnauthorizedException e1) {
/* 396 */               Log.error(e1);
/* 397 */               return null;
/*     */             }
/*     */ 
/* 400 */             if (message == null) {
/* 401 */               return new AttachmentProxy(attachment, message, auth, new Permissions(0L));
/*     */             }
/*     */ 
/* 404 */             return new AttachmentProxy(attachment, message, auth, message.permissions);
/*     */           }
/*     */ 
/* 409 */           return null;
/*     */         }
/*     */       };
/* 413 */       break;
/*     */     case 3:
/*     */     case 4:
/*     */     case 5:
/*     */     case 6:
/*     */     case 7:
/*     */     case 8:
/*     */     case 9:
/*     */     case 10:
/*     */     case 11:
/*     */     case 12:
/*     */     case 15:
/*     */     case 16:
/*     */     case 17:
/*     */     case 19:
/*     */     case 22:
/*     */     case 23:
/*     */     case 24:
/*     */     case 25:
/*     */     case 26:
/*     */     default:
/* 416 */       throw new IllegalArgumentException();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/* 428 */     if ((!this.iterator.hasNext()) && (this.nextElement == null)) {
/* 429 */       return false;
/*     */     }
/*     */ 
/* 433 */     if (this.nextElement == null) {
/* 434 */       this.nextElement = getNextElement();
/* 435 */       if (this.nextElement == null) {
/* 436 */         return false;
/*     */       }
/*     */     }
/* 439 */     return true;
/*     */   }
/*     */ 
/*     */   public Object next()
/*     */     throws NoSuchElementException
/*     */   {
/* 449 */     Object element = null;
/* 450 */     if (this.nextElement != null) {
/* 451 */       element = this.nextElement;
/* 452 */       this.nextElement = null;
/*     */     }
/*     */     else {
/* 455 */       element = getNextElement();
/* 456 */       if (element == null) {
/* 457 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/* 460 */     return element;
/*     */   }
/*     */ 
/*     */   public void remove()
/*     */     throws UnsupportedOperationException
/*     */   {
/* 467 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Object getNextElement()
/*     */   {
/* 477 */     while (this.iterator.hasNext()) {
/* 478 */       Object element = this.proxyFactory.createProxy(this.iterator.next(), this.authToken);
/* 479 */       if (element != null) {
/* 480 */         return element;
/*     */       }
/*     */     }
/* 483 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.IteratorProxy
 * JD-Core Version:    0.6.2
 */
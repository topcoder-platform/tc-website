/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.FilterManager;
/*     */ import com.jivesoftware.base.GroupManager;
/*     */ import com.jivesoftware.base.GroupManagerProxy;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.PermissionsManager;
/*     */ import com.jivesoftware.base.PollManager;
/*     */ import com.jivesoftware.base.PresenceManager;
/*     */ import com.jivesoftware.base.PresenceManagerProxy;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserManagerProxy;
/*     */ import com.jivesoftware.forum.AnnouncementManager;
/*     */ import com.jivesoftware.forum.ArchiveManager;
/*     */ import com.jivesoftware.forum.AttachmentManager;
/*     */ import com.jivesoftware.forum.AvatarManager;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.InterceptorManager;
/*     */ import com.jivesoftware.forum.PrivateMessageManager;
/*     */ import com.jivesoftware.forum.Query;
/*     */ import com.jivesoftware.forum.QueryManager;
/*     */ import com.jivesoftware.forum.QuestionManager;
/*     */ import com.jivesoftware.forum.ReadTracker;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.RewardManager;
/*     */ import com.jivesoftware.forum.SearchManager;
/*     */ import com.jivesoftware.forum.StatusLevelManager;
/*     */ import com.jivesoftware.forum.WatchManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class ForumFactoryProxy extends ForumFactory
/*     */ {
/*     */   protected ForumFactory factory;
/*     */   protected AuthToken authToken;
/*     */   protected Permissions permissions;
/*     */ 
/*     */   public ForumFactoryProxy(AuthToken authToken, ForumFactory factory, Permissions permissions)
/*     */   {
/*  30 */     this.factory = factory;
/*  31 */     this.authToken = authToken;
/*  32 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public Forum createForum(String name, String description)
/*     */     throws UnauthorizedException
/*     */   {
/*  38 */     if ((this.permissions.hasPermission(576460752303423488L)) || (getRootForumCategory().isAuthorized(512L)))
/*     */     {
/*  40 */       Forum newForum = this.factory.createForum(name, description);
/*     */ 
/*  43 */       Forum forum = null;
/*     */       try {
/*  45 */         forum = getForum(newForum.getID());
/*     */       }
/*     */       catch (ForumNotFoundException fnfe) {
/*  48 */         Log.error(fnfe);
/*     */       }
/*  50 */       return forum;
/*     */     }
/*     */ 
/*  53 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Forum createForum(String name, String description, ForumCategory category)
/*     */     throws UnauthorizedException
/*     */   {
/*  60 */     if ((this.permissions.hasPermission(576460752303423488L)) || (category.isAuthorized(512L)))
/*     */     {
/*  62 */       Forum newForum = this.factory.createForum(name, description, category);
/*     */ 
/*  65 */       Forum forum = null;
/*     */       try {
/*  67 */         forum = getForum(newForum.getID());
/*     */       }
/*     */       catch (ForumNotFoundException fnfe) {
/*  70 */         Log.error(fnfe);
/*     */       }
/*  72 */       return forum;
/*     */     }
/*     */ 
/*  75 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteForum(Forum forum) throws UnauthorizedException
/*     */   {
/*  80 */     if ((this.permissions.hasPermission(576460752303423488L)) || (forum.getForumCategory().isAuthorized(512L)))
/*     */     {
/*  82 */       this.factory.deleteForum(forum);
/*     */     }
/*     */     else
/*  85 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void mergeForums(Forum forum1, Forum forum2) throws UnauthorizedException
/*     */   {
/*  90 */     boolean admin1 = forum1.isAuthorized(768L);
/*     */ 
/*  92 */     boolean admin2 = forum2.isAuthorized(768L);
/*     */ 
/*  94 */     if ((this.permissions.hasPermission(576460752303423488L)) || ((admin1) && (admin2))) {
/*  95 */       this.factory.mergeForums(forum1, forum2);
/*     */     }
/*     */     else
/*  98 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public ForumCategory getForumCategory(long categoryID) throws ForumCategoryNotFoundException
/*     */   {
/* 103 */     ForumCategory category = this.factory.getForumCategory(categoryID);
/* 104 */     return new ForumCategoryProxy(category, this.authToken, category.getPermissions(this.authToken));
/*     */   }
/*     */ 
/*     */   public ForumCategory getRootForumCategory() {
/* 108 */     ForumCategory category = this.factory.getRootForumCategory();
/* 109 */     return new ForumCategoryProxy(category, this.authToken, category.getPermissions(this.authToken));
/*     */   }
/*     */ 
/*     */   public Forum getForum(long forumID) throws ForumNotFoundException, UnauthorizedException {
/* 113 */     Forum forum = this.factory.getForum(forumID);
/*     */ 
/* 116 */     Permissions forumPerms = forum.getPermissions(this.authToken);
/*     */ 
/* 119 */     if (!forumPerms.hasPermission(576460752303424389L))
/*     */     {
/* 126 */       throw new UnauthorizedException();
/*     */     }
/* 128 */     return new ForumProxy(forum, this.authToken, forumPerms);
/*     */   }
/*     */ 
/*     */   public Forum getForum(String nntpName) throws ForumNotFoundException, UnauthorizedException {
/* 132 */     Forum forum = this.factory.getForum(nntpName);
/*     */ 
/* 135 */     Permissions forumPerms = forum.getPermissions(this.authToken);
/*     */ 
/* 138 */     if (!forumPerms.hasPermission(576460752303424385L))
/*     */     {
/* 144 */       throw new UnauthorizedException();
/*     */     }
/* 146 */     return new ForumProxy(forum, this.authToken, forumPerms);
/*     */   }
/*     */ 
/*     */   public ForumThread getForumThread(long threadID) throws ForumThreadNotFoundException, UnauthorizedException
/*     */   {
/* 151 */     ForumThread thread = this.factory.getForumThread(threadID);
/*     */ 
/* 154 */     Permissions forumPerms = thread.getForum().getPermissions(this.authToken);
/*     */ 
/* 157 */     if (!forumPerms.hasPermission(576460752303424385L))
/*     */     {
/* 163 */       throw new UnauthorizedException();
/*     */     }
/* 165 */     return new ForumThreadProxy(thread, this.authToken, forumPerms);
/*     */   }
/*     */ 
/*     */   public ForumMessage getMessage(long messageID) throws ForumMessageNotFoundException, UnauthorizedException
/*     */   {
/* 170 */     ForumMessage message = this.factory.getMessage(messageID);
/*     */ 
/* 173 */     Permissions forumPerms = message.getForumThread().getForum().getPermissions(this.authToken);
/*     */ 
/* 176 */     if (!forumPerms.hasPermission(576460752303424385L))
/*     */     {
/* 182 */       throw new UnauthorizedException();
/*     */     }
/* 184 */     return new ForumMessageProxy(message, this.authToken, forumPerms);
/*     */   }
/*     */ 
/*     */   public long getMessageID(long forumID, int forumIndex) {
/* 188 */     return this.factory.getMessageID(forumID, forumIndex);
/*     */   }
/*     */ 
/*     */   public int getForumCount() {
/* 192 */     return this.factory.getForumCount();
/*     */   }
/*     */ 
/*     */   public int getForumCount(ResultFilter resultFilter) {
/* 196 */     return this.factory.getForumCount(resultFilter);
/*     */   }
/*     */ 
/*     */   public Iterator getForums() {
/* 200 */     return new IteratorProxy(0, this.factory.getForums(), this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getForums(ResultFilter resultFilter) {
/* 204 */     return new IteratorProxy(0, this.factory.getForums(resultFilter), this.authToken);
/*     */   }
/*     */ 
/*     */   public Query createQuery()
/*     */   {
/* 210 */     ArrayList forumList = new ArrayList();
/* 211 */     for (Iterator iter = getForums(); iter.hasNext(); ) {
/* 212 */       forumList.add(iter.next());
/*     */     }
/*     */ 
/* 215 */     Forum[] forums = (Forum[])forumList.toArray(new Forum[forumList.size()]);
/* 216 */     return createQuery(forums);
/*     */   }
/*     */ 
/*     */   public Query createQuery(Forum[] forums) {
/* 220 */     if (forums == null) {
/* 221 */       return new QueryProxy(this.factory.createQuery(new Forum[0]), this.authToken);
/*     */     }
/*     */ 
/* 226 */     ArrayList forumList = new ArrayList();
/* 227 */     for (int i = 0; i < forums.length; i++) {
/* 228 */       Forum forum = forums[i];
/* 229 */       ForumProxy proxy = null;
/*     */       try {
/* 231 */         proxy = (ForumProxy)getForum(forum.getID()); } catch (ForumNotFoundException e) {
/* 232 */         Log.error(e);
/*     */       } catch (UnauthorizedException e) {
/*     */       }
/* 235 */       if ((proxy != null) && (proxy.isAuthorized(576460752303424385L)))
/*     */       {
/* 240 */         forumList.add(forum);
/*     */       }
/*     */     }
/*     */ 
/* 244 */     Forum[] f = (Forum[])forumList.toArray(new Forum[forumList.size()]);
/* 245 */     return new QueryProxy(this.factory.createQuery(f), this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getPopularForums() {
/* 249 */     return new IteratorProxy(0, this.factory.getPopularForums(), this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getPopularThreads() {
/* 253 */     return new IteratorProxy(1, this.factory.getPopularThreads(), this.authToken);
/*     */   }
/*     */ 
/*     */   public int getUserMessageCount(User user)
/*     */   {
/* 258 */     return this.factory.getUserMessageCount(user);
/*     */   }
/*     */ 
/*     */   public int getUserMessageCount(User user, ResultFilter resultFilter) {
/* 262 */     return this.factory.getUserMessageCount(user, resultFilter);
/*     */   }
/*     */ 
/*     */   public Iterator getUserMessages(User user) {
/* 266 */     return new IteratorProxy(2, this.factory.getUserMessages(user), this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getUserMessages(User user, ResultFilter resultFilter) {
/* 270 */     return new IteratorProxy(2, this.factory.getUserMessages(user, resultFilter), this.authToken);
/*     */   }
/*     */ 
/*     */   public UserManager getUserManager()
/*     */   {
/* 275 */     UserManager userManager = this.factory.getUserManager();
/* 276 */     return new UserManagerProxy(userManager, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public GroupManager getGroupManager() {
/* 280 */     GroupManager groupManager = this.factory.getGroupManager();
/* 281 */     return new GroupManagerProxy(groupManager, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public SearchManager getSearchManager() throws UnauthorizedException {
/* 285 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 286 */       return this.factory.getSearchManager();
/*     */     }
/*     */ 
/* 289 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public FilterManager getFilterManager()
/*     */   {
/* 294 */     return new FilterManagerProxy(this.factory.getFilterManager(), 17, this.permissions);
/*     */   }
/*     */ 
/*     */   public InterceptorManager getInterceptorManager() throws UnauthorizedException
/*     */   {
/* 299 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 300 */       return new InterceptorManagerProxy(this.factory.getInterceptorManager(), this.permissions);
/*     */     }
/*     */ 
/* 303 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public WatchManager getWatchManager()
/*     */   {
/* 308 */     return new WatchManagerProxy(this.factory.getWatchManager(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public RewardManager getRewardManager() {
/* 312 */     return new RewardManagerProxy(this.factory.getRewardManager(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public AttachmentManager getAttachmentManager() {
/* 316 */     return new AttachmentManagerProxy(this.factory.getAttachmentManager(), this.permissions);
/*     */   }
/*     */ 
/*     */   public ArchiveManager getArchiveManager() {
/* 320 */     return new ArchiveManagerProxy(this.factory.getArchiveManager(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public StatusLevelManager getStatusLevelManager() {
/* 324 */     return new StatusLevelManagerProxy(this.factory.getStatusLevelManager(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public AvatarManager getAvatarManager() {
/* 328 */     return new AvatarManagerProxy(this.factory.getAvatarManager(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public PresenceManager getPresenceManager() {
/* 332 */     return new PresenceManagerProxy(this.factory.getPresenceManager(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public ReadTracker getReadTracker() {
/* 336 */     return new ReadTrackerProxy(this.factory.getReadTracker(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public PollManager getPollManager() {
/* 340 */     return new PollManagerProxy(this.factory.getPollManager(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public PrivateMessageManager getPrivateMessageManager() {
/* 344 */     return new PrivateMessageManagerProxy(this.factory.getPrivateMessageManager(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public QuestionManager getQuestionManager()
/*     */   {
/* 349 */     return new QuestionManagerProxy(this.factory.getQuestionManager(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public AnnouncementManager getAnnouncementManager() {
/* 353 */     return new AnnouncementManagerProxy(this.factory.getAnnouncementManager(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public PermissionsManager getPermissionsManager() throws UnauthorizedException
/*     */   {
/* 358 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 359 */       return new PermissionsManagerProxy(17, -1L, this.permissions);
/*     */     }
/*     */ 
/* 362 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public QueryManager getQueryManager()
/*     */   {
/* 367 */     return new QueryManagerProxy(this.factory.getQueryManager(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public Permissions getPermissions(AuthToken authToken) {
/* 371 */     return this.factory.getPermissions(authToken);
/*     */   }
/*     */ 
/*     */   public boolean isAuthorized(long type) {
/* 375 */     return this.permissions.hasPermission(type);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.ForumFactoryProxy
 * JD-Core Version:    0.6.2
 */
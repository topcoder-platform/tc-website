/*    */ package com.jivesoftware.forum.proxy;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.Permissions;
/*    */ import com.jivesoftware.forum.Announcement;
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ public class AnnouncementIteratorProxy
/*    */   implements Iterator
/*    */ {
/*    */   private Iterator iterator;
/* 28 */   private Object nextElement = null;
/*    */   private AuthToken authToken;
/*    */   private Permissions permissions;
/*    */ 
/*    */   public AnnouncementIteratorProxy(Iterator iterator, AuthToken authToken, Permissions permissions)
/*    */   {
/* 36 */     this.iterator = iterator;
/* 37 */     this.authToken = authToken;
/* 38 */     this.permissions = permissions;
/*    */   }
/*    */ 
/*    */   public boolean hasNext()
/*    */   {
/* 44 */     if ((!this.iterator.hasNext()) && (this.nextElement == null)) {
/* 45 */       return false;
/*    */     }
/*    */ 
/* 49 */     if (this.nextElement == null) {
/* 50 */       this.nextElement = getNextElement();
/* 51 */       if (this.nextElement == null) {
/* 52 */         return false;
/*    */       }
/*    */     }
/* 55 */     return true;
/*    */   }
/*    */ 
/*    */   public Object next() throws NoSuchElementException {
/* 59 */     Object element = null;
/* 60 */     if (this.nextElement != null) {
/* 61 */       element = this.nextElement;
/* 62 */       this.nextElement = null;
/*    */     }
/*    */     else {
/* 65 */       element = getNextElement();
/* 66 */       if (element == null) {
/* 67 */         throw new NoSuchElementException();
/*    */       }
/*    */     }
/* 70 */     return element;
/*    */   }
/*    */ 
/*    */   public void remove() throws UnsupportedOperationException {
/* 74 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public Announcement getNextElement()
/*    */   {
/* 84 */     while (this.iterator.hasNext()) {
/* 85 */       Announcement element = (Announcement)this.iterator.next();
/* 86 */       if (element != null) {
/* 87 */         return new AnnouncementProxy(element, this.authToken, this.permissions);
/*    */       }
/*    */     }
/* 90 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.AnnouncementIteratorProxy
 * JD-Core Version:    0.6.2
 */
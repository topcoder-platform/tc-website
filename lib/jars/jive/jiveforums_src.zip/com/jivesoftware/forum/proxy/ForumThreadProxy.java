/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.MessageRejectedException;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.TreeWalker;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class ForumThreadProxy
/*     */   implements ForumThread
/*     */ {
/*     */   private ForumThread thread;
/*     */   private AuthToken authToken;
/*     */   protected Permissions permissions;
/*     */ 
/*     */   public ForumThreadProxy(ForumThread thread, AuthToken authToken, Permissions permissions)
/*     */   {
/*  36 */     this.thread = thread;
/*  37 */     this.authToken = authToken;
/*  38 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public long getID() {
/*  42 */     return this.thread.getID();
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  46 */     return this.thread.getName();
/*     */   }
/*     */ 
/*     */   public Date getCreationDate() {
/*  50 */     return this.thread.getCreationDate();
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Date creationDate) throws UnauthorizedException {
/*  54 */     if (isAdmin())
/*  55 */       this.thread.setCreationDate(creationDate);
/*     */     else
/*  57 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Date getModificationDate() {
/*  61 */     return this.thread.getModificationDate();
/*     */   }
/*     */ 
/*     */   public void setModificationDate(Date modificationDate) throws UnauthorizedException {
/*  65 */     if (isAdmin())
/*  66 */       this.thread.setModificationDate(modificationDate);
/*     */     else
/*  68 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getModerationValue() {
/*  72 */     return this.thread.getModerationValue();
/*     */   }
/*     */ 
/*     */   public void setModerationValue(int value, AuthToken authToken)
/*     */     throws UnauthorizedException
/*     */   {
/*  78 */     if ((isAdmin()) || (this.permissions.hasPermission(128L))) {
/*  79 */       this.thread.setModerationValue(value, authToken);
/*     */     }
/*     */     else
/*  82 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public String getProperty(String name)
/*     */   {
/*  87 */     return this.thread.getProperty(name);
/*     */   }
/*     */ 
/*     */   public Collection getProperties(String parentName) {
/*  91 */     return this.thread.getProperties(parentName);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value) throws UnauthorizedException {
/*  95 */     if (isAllowedToEdit()) {
/*  96 */       this.thread.setProperty(name, value);
/*     */     }
/*     */     else
/*  99 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) throws UnauthorizedException
/*     */   {
/* 104 */     if (isAllowedToEdit()) {
/* 105 */       this.thread.deleteProperty(name);
/*     */     }
/*     */     else
/* 108 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames()
/*     */   {
/* 113 */     return this.thread.getPropertyNames();
/*     */   }
/*     */ 
/*     */   public Forum getForum() {
/* 117 */     Forum forum = this.thread.getForum();
/* 118 */     if (forum == null) {
/* 119 */       return null;
/*     */     }
/*     */ 
/* 122 */     return new ForumProxy(forum, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public int getMessageCount()
/*     */   {
/* 127 */     return this.thread.getMessageCount();
/*     */   }
/*     */ 
/*     */   public int getMessageCount(ResultFilter resultFilter) {
/* 131 */     return this.thread.getMessageCount(resultFilter);
/*     */   }
/*     */ 
/*     */   public ForumMessage getRootMessage() {
/* 135 */     ForumMessage message = this.thread.getRootMessage();
/* 136 */     return new ForumMessageProxy(message, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public void addMessage(ForumMessage parentMessage, ForumMessage newMessage)
/*     */     throws MessageRejectedException, UnauthorizedException
/*     */   {
/* 142 */     if ((isAdmin()) || (this.permissions.hasPermission(130L)))
/*     */     {
/* 145 */       this.thread.addMessage(parentMessage, newMessage);
/*     */ 
/* 148 */       if ((newMessage instanceof ForumMessageProxy)) {
/* 149 */         Permissions msgPerms = ((ForumMessageProxy)newMessage).permissions;
/* 150 */         msgPerms = new Permissions(msgPerms, this.permissions);
/* 151 */         ((ForumMessageProxy)newMessage).permissions = msgPerms;
/*     */       }
/*     */     }
/*     */     else {
/* 155 */       throw new UnauthorizedException();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteMessage(ForumMessage message) throws UnauthorizedException {
/* 160 */     if ((isAdmin()) || (this.permissions.hasPermission(128L)))
/*     */     {
/* 162 */       this.thread.deleteMessage(message);
/*     */     }
/*     */     else
/* 165 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteMessage(ForumMessage message, boolean deleteChildren)
/*     */     throws UnauthorizedException
/*     */   {
/* 172 */     if ((isAdmin()) || (this.permissions.hasPermission(128L)))
/*     */     {
/* 174 */       this.thread.deleteMessage(message, deleteChildren);
/*     */     }
/*     */     else
/* 177 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public ForumMessage getMessage(long messageID) throws ForumMessageNotFoundException
/*     */   {
/* 182 */     ForumMessage message = this.thread.getMessage(messageID);
/*     */ 
/* 184 */     return new ForumMessageProxy(message, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public ForumMessage getLatestMessage() {
/* 188 */     return new ForumMessageProxy(this.thread.getLatestMessage(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public TreeWalker getTreeWalker() {
/* 192 */     return new TreeWalkerProxy(this.thread.getTreeWalker(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public Iterator getMessages() {
/* 196 */     Iterator iterator = this.thread.getMessages();
/* 197 */     return new IteratorProxy(2, iterator, this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getMessages(ResultFilter resultFilter) {
/* 201 */     Iterator iterator = this.thread.getMessages(resultFilter);
/* 202 */     return new IteratorProxy(2, iterator, this.authToken);
/*     */   }
/*     */ 
/*     */   public boolean isAuthorized(long type) {
/* 206 */     return this.permissions.hasPermission(type);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 210 */     return this.thread.toString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object) {
/* 214 */     return this.thread.equals(object);
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 218 */     return this.thread.hashCode();
/*     */   }
/*     */ 
/*     */   public ForumThread getProxiedForumThread()
/*     */     throws UnauthorizedException
/*     */   {
/* 225 */     return this.thread;
/*     */   }
/*     */ 
/*     */   private boolean isAllowedToEdit()
/*     */   {
/* 235 */     if ((isAdmin()) || (this.permissions.hasPermission(128L))) {
/* 236 */       return true;
/*     */     }
/*     */ 
/* 240 */     if (getID() == -1L) {
/* 241 */       return true;
/*     */     }
/* 243 */     ForumMessage rootMessage = getRootMessage();
/*     */ 
/* 245 */     if ((!rootMessage.isAnonymous()) && (rootMessage.getUser().getID() == this.authToken.getUserID()))
/*     */     {
/* 248 */       return true;
/*     */     }
/*     */ 
/* 251 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean isAdmin()
/*     */   {
/* 260 */     return this.permissions.hasPermission(576460752303424256L);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.ForumThreadProxy
 * JD-Core Version:    0.6.2
 */
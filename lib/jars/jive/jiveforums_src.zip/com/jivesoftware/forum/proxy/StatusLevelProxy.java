/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Group;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.StatusLevel;
/*     */ import com.jivesoftware.forum.StatusLevelException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class StatusLevelProxy
/*     */   implements StatusLevel
/*     */ {
/*     */   private StatusLevel statusLevel;
/*     */   private AuthToken authToken;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public StatusLevelProxy(StatusLevel statusLevel, AuthToken authToken, Permissions permissions)
/*     */   {
/*  31 */     this.statusLevel = statusLevel;
/*  32 */     this.authToken = authToken;
/*  33 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public long getID() {
/*  37 */     return this.statusLevel.getID();
/*     */   }
/*     */ 
/*     */   public void setName(String name) throws UnauthorizedException, StatusLevelException {
/*  41 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/*  42 */       throw new UnauthorizedException("Requires SYSTEM_ADMIN privilege!");
/*     */     }
/*     */ 
/*  45 */     this.statusLevel.setName(name);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  49 */     return this.statusLevel.getName();
/*     */   }
/*     */ 
/*     */   public void setDescription(String description) throws UnauthorizedException {
/*  53 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/*  54 */       throw new UnauthorizedException("Requires SYSTEM_ADMIN privilege!");
/*     */     }
/*  56 */     this.statusLevel.setDescription(description);
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/*  60 */     return this.statusLevel.getDescription();
/*     */   }
/*     */ 
/*     */   public void setImagePath(String imagePath) throws UnauthorizedException, StatusLevelException {
/*  64 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/*  65 */       throw new UnauthorizedException("Requires SYSTEM_ADMIN privilege!");
/*     */     }
/*  67 */     this.statusLevel.setImagePath(imagePath);
/*     */   }
/*     */ 
/*     */   public String getImagePath() {
/*  71 */     return this.statusLevel.getImagePath();
/*     */   }
/*     */ 
/*     */   public String getLargeImagePath() {
/*  75 */     return this.statusLevel.getLargeImagePath();
/*     */   }
/*     */ 
/*     */   public void setLargeImagePath(String largeImagePath) throws UnauthorizedException {
/*  79 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/*  80 */       throw new UnauthorizedException("Requires SYSTEM_ADMIN privilege!");
/*     */     }
/*  82 */     this.statusLevel.setLargeImagePath(largeImagePath);
/*     */   }
/*     */ 
/*     */   public int getMinPoints() {
/*  86 */     return this.statusLevel.getMinPoints();
/*     */   }
/*     */ 
/*     */   public int getMaxPoints() {
/*  90 */     return this.statusLevel.getMaxPoints();
/*     */   }
/*     */ 
/*     */   public void setGroup(Group group) throws UnauthorizedException, StatusLevelException {
/*  94 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/*  95 */       throw new UnauthorizedException("Requires SYSTEM_ADMIN privilege!");
/*     */     }
/*  97 */     this.statusLevel.setGroup(group);
/*     */   }
/*     */ 
/*     */   public Group getGroup() {
/* 101 */     return this.statusLevel.getGroup();
/*     */   }
/*     */ 
/*     */   public String getProperty(String name) {
/* 105 */     return this.statusLevel.getProperty(name);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value) throws UnauthorizedException {
/* 109 */     this.statusLevel.setProperty(name, value);
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) throws UnauthorizedException {
/* 113 */     this.statusLevel.deleteProperty(name);
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames() {
/* 117 */     return this.statusLevel.getPropertyNames();
/*     */   }
/*     */ 
/*     */   public boolean isInRange(int pointValue) {
/* 121 */     return this.statusLevel.isInRange(pointValue);
/*     */   }
/*     */ 
/*     */   public void setPointRange(int minPoints, int maxPoints) throws UnauthorizedException, StatusLevelException
/*     */   {
/* 126 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/* 127 */       throw new UnauthorizedException("Requires SYSTEM_ADMIN privilege!");
/*     */     }
/* 129 */     this.statusLevel.setPointRange(minPoints, maxPoints);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.StatusLevelProxy
 * JD-Core Version:    0.6.2
 */
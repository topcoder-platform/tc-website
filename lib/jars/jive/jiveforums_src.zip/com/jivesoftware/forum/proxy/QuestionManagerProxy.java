/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.Question;
/*     */ import com.jivesoftware.forum.QuestionFilter;
/*     */ import com.jivesoftware.forum.QuestionManager;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class QuestionManagerProxy
/*     */   implements QuestionManager
/*     */ {
/*     */   private QuestionManager manager;
/*     */   private AuthToken authToken;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public QuestionManagerProxy(QuestionManager manager, AuthToken authToken, Permissions permissions)
/*     */   {
/*  34 */     this.manager = manager;
/*  35 */     this.authToken = authToken;
/*  36 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public int getHelpfulAnswersPerThread() {
/*  40 */     return this.manager.getHelpfulAnswersPerThread();
/*     */   }
/*     */ 
/*     */   public void setHelpfulAnswersPerThread(int count) throws UnauthorizedException {
/*  44 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  45 */       this.manager.setHelpfulAnswersPerThread(count);
/*     */     }
/*     */     else
/*  48 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Question getQuestion(ForumThread thread) throws NotFoundException
/*     */   {
/*  53 */     return new QuestionProxy(this.manager.getQuestion(thread), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public boolean hasQuestion(ForumThread thread) {
/*  57 */     return this.manager.hasQuestion(thread);
/*     */   }
/*     */ 
/*     */   public Question createQuestion(ForumThread thread) throws UnauthorizedException
/*     */   {
/*  62 */     User user = thread.getRootMessage().getUser();
/*  63 */     if (((user != null) && (user.getID() == this.authToken.getUserID())) || (this.permissions.hasPermission(576460752303423488L)))
/*     */     {
/*  66 */       return new QuestionProxy(this.manager.createQuestion(thread), this.authToken, this.permissions);
/*     */     }
/*  68 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteQuestion(Question question) throws UnauthorizedException {
/*  72 */     User user = question.getForumThread().getRootMessage().getUser();
/*  73 */     if (((user != null) && (user.getID() == this.authToken.getUserID())) || (this.permissions.hasPermission(576460752303423488L)))
/*     */     {
/*  76 */       this.manager.deleteQuestion(question);
/*     */     }
/*     */     else
/*  79 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getQuestionCount()
/*     */   {
/*  84 */     return this.manager.getQuestionCount();
/*     */   }
/*     */ 
/*     */   public int getQuestionCount(QuestionFilter questionFilter) {
/*  88 */     return this.manager.getQuestionCount(questionFilter);
/*     */   }
/*     */ 
/*     */   public int getQuestionCount(ForumCategory category) {
/*  92 */     return this.manager.getQuestionCount(category);
/*     */   }
/*     */ 
/*     */   public int getQuestionCount(ForumCategory category, QuestionFilter questionFilter) {
/*  96 */     return this.manager.getQuestionCount(category, questionFilter);
/*     */   }
/*     */ 
/*     */   public int getQuestionCount(Forum forum) {
/* 100 */     return this.manager.getQuestionCount(forum);
/*     */   }
/*     */ 
/*     */   public int getQuestionCount(Forum forum, QuestionFilter questionFilter) {
/* 104 */     return this.manager.getQuestionCount(forum, questionFilter);
/*     */   }
/*     */ 
/*     */   public Iterator getQuestions() {
/* 108 */     Iterator questions = this.manager.getQuestions();
/* 109 */     return new IteratorProxy(27, questions, this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getQuestions(QuestionFilter questionFilter) {
/* 113 */     Iterator questions = this.manager.getQuestions(questionFilter);
/* 114 */     return new IteratorProxy(27, questions, this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getQuestions(ForumCategory category) {
/* 118 */     Iterator questions = this.manager.getQuestions(category);
/* 119 */     return new IteratorProxy(27, questions, this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getQuestions(ForumCategory category, QuestionFilter questionFilter) {
/* 123 */     Iterator questions = this.manager.getQuestions(category, questionFilter);
/* 124 */     return new IteratorProxy(27, questions, this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getQuestions(Forum forum) {
/* 128 */     Iterator questions = this.manager.getQuestions(forum);
/* 129 */     return new IteratorProxy(27, questions, this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getQuestions(Forum forum, QuestionFilter questionFilter) {
/* 133 */     Iterator questions = this.manager.getQuestions(forum, questionFilter);
/* 134 */     return new IteratorProxy(27, questions, this.authToken);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.QuestionManagerProxy
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.proxy;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.User;
/*    */ import com.jivesoftware.forum.PrivateMessage;
/*    */ import com.jivesoftware.forum.PrivateMessageFolder;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class PrivateMessageFolderProxy
/*    */   implements PrivateMessageFolder
/*    */ {
/*    */   private PrivateMessageFolder folder;
/*    */   private AuthToken authToken;
/*    */ 
/*    */   public PrivateMessageFolderProxy(PrivateMessageFolder folder, AuthToken authToken)
/*    */   {
/* 35 */     this.folder = folder;
/* 36 */     this.authToken = authToken;
/*    */   }
/*    */ 
/*    */   public int getID() {
/* 40 */     return this.folder.getID();
/*    */   }
/*    */ 
/*    */   public User getOwner() {
/* 44 */     return this.folder.getOwner();
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 48 */     return this.folder.getName();
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 52 */     this.folder.setName(name);
/*    */   }
/*    */ 
/*    */   public Iterator getMessages() {
/* 56 */     return new IteratorProxy(20, this.folder.getMessages(), this.authToken);
/*    */   }
/*    */ 
/*    */   public Iterator getMessages(int startIndex, int count, int sortField, boolean sortDescending)
/*    */   {
/* 61 */     return new IteratorProxy(20, this.folder.getMessages(startIndex, count, sortField, sortDescending), this.authToken);
/*    */   }
/*    */ 
/*    */   public int getMessageCount()
/*    */   {
/* 66 */     return this.folder.getMessageCount();
/*    */   }
/*    */ 
/*    */   public int getUnreadMessageCount() {
/* 70 */     return this.folder.getUnreadMessageCount();
/*    */   }
/*    */ 
/*    */   public void deleteMessage(PrivateMessage privateMessage) {
/* 74 */     this.folder.deleteMessage(privateMessage);
/*    */   }
/*    */ 
/*    */   public void moveMessage(PrivateMessage privateMessage, PrivateMessageFolder destinationFolder) {
/* 78 */     this.folder.moveMessage(privateMessage, destinationFolder);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.PrivateMessageFolderProxy
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.FilterManager;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.PrivateMessage;
/*     */ import com.jivesoftware.forum.PrivateMessageFolder;
/*     */ import com.jivesoftware.forum.PrivateMessageFolderNotFoundException;
/*     */ import com.jivesoftware.forum.PrivateMessageManager;
/*     */ import com.jivesoftware.forum.PrivateMessageNotFoundException;
/*     */ import com.jivesoftware.forum.PrivateMessageRejectedException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class PrivateMessageManagerProxy
/*     */   implements PrivateMessageManager
/*     */ {
/*     */   private PrivateMessageManager manager;
/*     */   private AuthToken authToken;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public PrivateMessageManagerProxy(PrivateMessageManager manager, AuthToken authToken, Permissions permissions)
/*     */   {
/*  37 */     this.manager = manager;
/*  38 */     this.authToken = authToken;
/*  39 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public boolean isPrivateMessagesEnabled() {
/*  43 */     return this.manager.isPrivateMessagesEnabled();
/*     */   }
/*     */ 
/*     */   public void setPrivateMessagesEnabled(boolean enabled) throws UnauthorizedException {
/*  47 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  48 */       this.manager.setPrivateMessagesEnabled(enabled);
/*     */     }
/*     */     else
/*  51 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public FilterManager getFilterManager()
/*     */   {
/*  56 */     return this.manager.getFilterManager();
/*     */   }
/*     */ 
/*     */   public int getMaxMessagesPerUser() {
/*  60 */     return this.manager.getMaxMessagesPerUser();
/*     */   }
/*     */ 
/*     */   public void setMaxMessagesPerUser(int maxMessages) throws UnauthorizedException {
/*  64 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  65 */       this.manager.setMaxMessagesPerUser(maxMessages);
/*     */     }
/*     */     else
/*  68 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getMessageCount(User user) throws UnauthorizedException
/*     */   {
/*  73 */     if ((this.permissions.hasPermission(576460752303423488L)) || (user.getID() == this.authToken.getUserID()))
/*     */     {
/*  76 */       return this.manager.getMessageCount(user);
/*     */     }
/*     */ 
/*  79 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getUnreadMessageCount(User user) throws UnauthorizedException
/*     */   {
/*  84 */     if ((this.permissions.hasPermission(576460752303423488L)) || (user.getID() == this.authToken.getUserID()))
/*     */     {
/*  87 */       return this.manager.getUnreadMessageCount(user);
/*     */     }
/*     */ 
/*  90 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getFolderCount(User user) throws UnauthorizedException
/*     */   {
/*  95 */     if ((this.permissions.hasPermission(576460752303423488L)) || (user.getID() == this.authToken.getUserID()))
/*     */     {
/*  98 */       return this.manager.getFolderCount(user);
/*     */     }
/*     */ 
/* 101 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getFolders(User user) throws UnauthorizedException
/*     */   {
/* 106 */     if ((this.permissions.hasPermission(576460752303423488L)) || (user.getID() == this.authToken.getUserID()))
/*     */     {
/* 109 */       return new IteratorProxy(21, this.manager.getFolders(user), this.authToken);
/*     */     }
/*     */ 
/* 113 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public PrivateMessageFolder getFolder(User user, int folderID)
/*     */     throws PrivateMessageFolderNotFoundException, UnauthorizedException
/*     */   {
/* 120 */     if ((this.permissions.hasPermission(576460752303423488L)) || (user.getID() == this.authToken.getUserID()))
/*     */     {
/* 123 */       PrivateMessageFolder folder = this.manager.getFolder(user, folderID);
/* 124 */       return new PrivateMessageFolderProxy(folder, this.authToken);
/*     */     }
/*     */ 
/* 127 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public PrivateMessageFolder createFolder(User user, String name) throws UnauthorizedException
/*     */   {
/* 132 */     if ((this.permissions.hasPermission(576460752303423488L)) || (user.getID() == this.authToken.getUserID()))
/*     */     {
/* 135 */       PrivateMessageFolder folder = this.manager.createFolder(user, name);
/* 136 */       return new PrivateMessageFolderProxy(folder, this.authToken);
/*     */     }
/*     */ 
/* 139 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteFolder(PrivateMessageFolder folder) throws UnauthorizedException
/*     */   {
/* 144 */     if ((this.permissions.hasPermission(576460752303423488L)) || (folder.getOwner().getID() == this.authToken.getUserID()))
/*     */     {
/* 147 */       this.manager.deleteFolder(folder);
/*     */     }
/*     */     else
/* 150 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public PrivateMessage getMessage(long privateMessageID)
/*     */     throws UnauthorizedException, PrivateMessageNotFoundException
/*     */   {
/* 157 */     PrivateMessage privateMessage = this.manager.getMessage(privateMessageID);
/* 158 */     if ((this.permissions.hasPermission(576460752303423488L)) || (privateMessage.getFolder().getOwner().getID() == this.authToken.getUserID()))
/*     */     {
/* 161 */       return new PrivateMessageProxy(privateMessage, this.permissions);
/*     */     }
/*     */ 
/* 164 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public PrivateMessage createMessage(User sender) throws UnauthorizedException
/*     */   {
/* 169 */     if ((this.permissions.hasPermission(576460752303423488L)) || (sender.getID() == this.authToken.getUserID()))
/*     */     {
/* 172 */       PrivateMessage privateMessage = this.manager.createMessage(sender);
/* 173 */       return new PrivateMessageProxy(privateMessage, this.permissions);
/*     */     }
/*     */ 
/* 176 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void saveMessageAsDraft(PrivateMessage privateMessage)
/*     */     throws UnauthorizedException, PrivateMessageRejectedException
/*     */   {
/* 183 */     if ((this.permissions.hasPermission(576460752303423488L)) || (privateMessage.getSender().getID() == this.authToken.getUserID()))
/*     */     {
/* 186 */       this.manager.saveMessageAsDraft(privateMessage);
/*     */     }
/*     */     else
/* 189 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void sendMessage(PrivateMessage privateMessage, User recipient, boolean copyToSentFolder)
/*     */     throws UnauthorizedException, PrivateMessageRejectedException
/*     */   {
/* 196 */     if ((this.permissions.hasPermission(576460752303423488L)) || (privateMessage.getSender().getID() == this.authToken.getUserID()))
/*     */     {
/* 199 */       this.manager.sendMessage(privateMessage, recipient, copyToSentFolder);
/*     */     }
/*     */     else
/* 202 */       throw new UnauthorizedException();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.PrivateMessageManagerProxy
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.FilterManager;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.PermissionsManager;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageIterator;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadIterator;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.InterceptorManager;
/*     */ import com.jivesoftware.forum.MessageRejectedException;
/*     */ import com.jivesoftware.forum.NameAlreadyExistsException;
/*     */ import com.jivesoftware.forum.Query;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.gateway.GatewayManager;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ForumProxy
/*     */   implements Forum
/*     */ {
/*     */   private Forum forum;
/*     */   private AuthToken authToken;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public ForumProxy(Forum forum, AuthToken authToken, Permissions permissions)
/*     */   {
/*  44 */     this.forum = forum;
/*  45 */     this.authToken = authToken;
/*  46 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public long getID()
/*     */   {
/*  52 */     return this.forum.getID();
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  56 */     return this.forum.getName();
/*     */   }
/*     */ 
/*     */   public void setName(String name) throws UnauthorizedException {
/*  60 */     if (isAdmin()) {
/*  61 */       this.forum.setName(name);
/*     */     }
/*     */     else
/*  64 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public String getNNTPName()
/*     */   {
/*  69 */     return this.forum.getNNTPName();
/*     */   }
/*     */ 
/*     */   public void setNNTPName(String nntpName)
/*     */     throws UnauthorizedException, NameAlreadyExistsException
/*     */   {
/*  75 */     if (isAdmin()) {
/*  76 */       this.forum.setNNTPName(nntpName);
/*     */     }
/*     */     else
/*  79 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  84 */     return this.forum.getDescription();
/*     */   }
/*     */ 
/*     */   public void setDescription(String description) throws UnauthorizedException {
/*  88 */     if (isAdmin()) {
/*  89 */       this.forum.setDescription(description);
/*     */     }
/*     */     else
/*  92 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Date getCreationDate()
/*     */   {
/*  97 */     return this.forum.getCreationDate();
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Date creationDate) throws UnauthorizedException {
/* 101 */     if (isAdmin()) {
/* 102 */       this.forum.setCreationDate(creationDate);
/*     */     }
/*     */     else
/* 105 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Date getModificationDate()
/*     */   {
/* 110 */     return this.forum.getModificationDate();
/*     */   }
/*     */ 
/*     */   public void setModificationDate(Date modificationDate) throws UnauthorizedException {
/* 114 */     if (isAdmin()) {
/* 115 */       this.forum.setModificationDate(modificationDate);
/*     */     }
/*     */     else
/* 118 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getModerationDefaultThreadValue()
/*     */   {
/* 123 */     return this.forum.getModerationDefaultThreadValue();
/*     */   }
/*     */ 
/*     */   public void setModerationDefaultThreadValue(int value) throws UnauthorizedException {
/* 127 */     if ((isAdmin()) || (this.permissions.hasPermission(128L))) {
/* 128 */       this.forum.setModerationDefaultThreadValue(value);
/*     */     }
/*     */     else
/* 131 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getModerationDefaultMessageValue()
/*     */   {
/* 136 */     return this.forum.getModerationDefaultMessageValue();
/*     */   }
/*     */ 
/*     */   public void setModerationDefaultMessageValue(int value) throws UnauthorizedException {
/* 140 */     if ((isAdmin()) || (this.permissions.hasPermission(128L))) {
/* 141 */       this.forum.setModerationDefaultMessageValue(value);
/*     */     }
/*     */     else
/* 144 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getMinForumIndex()
/*     */   {
/* 149 */     if ((this.permissions.hasPermission(1L) | isAdmin() | this.permissions.hasPermission(128L)))
/*     */     {
/* 152 */       return this.forum.getMinForumIndex();
/*     */     }
/*     */ 
/* 155 */     return 0;
/*     */   }
/*     */ 
/*     */   public int getMaxForumIndex()
/*     */   {
/* 160 */     if ((this.permissions.hasPermission(1L) | isAdmin() | this.permissions.hasPermission(128L)))
/*     */     {
/* 163 */       return this.forum.getMaxForumIndex();
/*     */     }
/*     */ 
/* 166 */     return 0;
/*     */   }
/*     */ 
/*     */   public String getProperty(String name)
/*     */   {
/* 171 */     return this.forum.getProperty(name);
/*     */   }
/*     */ 
/*     */   public Collection getProperties(String parentName) {
/* 175 */     return this.forum.getProperties(parentName);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value) throws UnauthorizedException {
/* 179 */     if (isAdmin()) {
/* 180 */       this.forum.setProperty(name, value);
/*     */     }
/*     */     else
/* 183 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) throws UnauthorizedException
/*     */   {
/* 188 */     if (isAdmin()) {
/* 189 */       this.forum.deleteProperty(name);
/*     */     }
/*     */     else
/* 192 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames()
/*     */   {
/* 197 */     return this.forum.getPropertyNames();
/*     */   }
/*     */ 
/*     */   public void deleteThread(ForumThread thread) throws UnauthorizedException {
/* 201 */     if ((isAdmin()) || (this.permissions.hasPermission(128L))) {
/* 202 */       this.forum.deleteThread(thread);
/*     */     }
/*     */     else
/* 205 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void moveThread(ForumThread thread, Forum newForum)
/*     */     throws UnauthorizedException, IllegalArgumentException
/*     */   {
/* 213 */     boolean forum1Perm = (isAdmin()) || (this.permissions.hasPermission(128L));
/*     */ 
/* 215 */     boolean forum2Perm = newForum.isAuthorized(576460752303424384L);
/*     */ 
/* 219 */     if ((forum1Perm) && (forum2Perm)) {
/* 220 */       this.forum.moveThread(thread, newForum);
/*     */     }
/*     */     else
/* 223 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void addThread(ForumThread thread)
/*     */     throws MessageRejectedException, UnauthorizedException
/*     */   {
/* 230 */     if ((isAdmin()) || (this.permissions.hasPermission(132L)))
/*     */     {
/* 233 */       this.forum.addThread(thread);
/*     */ 
/* 236 */       Permissions threadPerms = ((ForumThreadProxy)thread).permissions;
/* 237 */       threadPerms = new Permissions(threadPerms, this.permissions);
/* 238 */       ((ForumThreadProxy)thread).permissions = threadPerms;
/*     */     }
/*     */     else {
/* 241 */       throw new UnauthorizedException("Create thread permissions are necessary to perform this task");
/*     */     }
/*     */   }
/*     */ 
/*     */   public ForumThread createThread(ForumMessage rootMessage)
/*     */     throws UnauthorizedException
/*     */   {
/* 250 */     if (rootMessage.getForumThread() != null) {
/* 251 */       Forum otherForum = rootMessage.getForumThread().getForum();
/* 252 */       if (!otherForum.isAuthorized(576460752303424384L))
/*     */       {
/* 256 */         throw new UnauthorizedException();
/*     */       }
/*     */     }
/* 259 */     ForumThread thread = this.forum.createThread(rootMessage);
/* 260 */     return new ForumThreadProxy(thread, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public ForumMessage createMessage() {
/* 264 */     ForumMessage message = this.forum.createMessage();
/* 265 */     return new ForumMessageProxy(message, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public ForumMessage createMessage(User user)
/*     */     throws UnauthorizedException
/*     */   {
/* 271 */     if ((this.permissions.hasPermission(576460752303423488L)) || (user.getID() == this.authToken.getUserID()))
/*     */     {
/* 274 */       ForumMessage message = this.forum.createMessage(user);
/* 275 */       return new ForumMessageProxy(message, this.authToken, this.permissions);
/*     */     }
/*     */ 
/* 278 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public ForumCategory getForumCategory()
/*     */   {
/* 283 */     ForumCategory category = this.forum.getForumCategory();
/* 284 */     return new ForumCategoryProxy(category, this.authToken, category.getPermissions(this.authToken));
/*     */   }
/*     */ 
/*     */   public ForumThread getThread(long threadID) throws ForumThreadNotFoundException
/*     */   {
/* 289 */     if ((this.permissions.hasPermission(1L) | isAdmin() | this.permissions.hasPermission(128L)))
/*     */     {
/* 292 */       ForumThread thread = this.forum.getThread(threadID);
/*     */ 
/* 294 */       return new ForumThreadProxy(thread, this.authToken, this.permissions);
/*     */     }
/*     */ 
/* 297 */     throw new ForumThreadNotFoundException();
/*     */   }
/*     */ 
/*     */   public ForumThreadIterator getThreads()
/*     */   {
/* 302 */     if ((this.permissions.hasPermission(1L) | isAdmin() | this.permissions.hasPermission(128L)))
/*     */     {
/* 305 */       ForumThreadIterator iterator = this.forum.getThreads();
/* 306 */       return new ForumThreadIteratorProxy(iterator, this.authToken, this.permissions);
/*     */     }
/*     */ 
/* 309 */     return ForumThreadIterator.EMPTY_ITERATOR;
/*     */   }
/*     */ 
/*     */   public ForumThreadIterator getThreads(ResultFilter resultFilter)
/*     */   {
/* 314 */     if ((this.permissions.hasPermission(1L) | isAdmin() | this.permissions.hasPermission(128L)))
/*     */     {
/* 317 */       ForumThreadIterator iterator = this.forum.getThreads(resultFilter);
/* 318 */       return new ForumThreadIteratorProxy(iterator, this.authToken, this.permissions);
/*     */     }
/*     */ 
/* 321 */     return ForumThreadIterator.EMPTY_ITERATOR;
/*     */   }
/*     */ 
/*     */   public Iterator getPopularThreads()
/*     */   {
/* 326 */     if ((this.permissions.hasPermission(1L) | isAdmin() | this.permissions.hasPermission(128L)))
/*     */     {
/* 329 */       Iterator iterator = this.forum.getPopularThreads();
/* 330 */       return new IteratorProxy(1, iterator, this.authToken);
/*     */     }
/*     */ 
/* 333 */     return Collections.EMPTY_LIST.iterator();
/*     */   }
/*     */ 
/*     */   public ForumMessageIterator getMessages()
/*     */   {
/* 338 */     if ((this.permissions.hasPermission(1L) | isAdmin() | this.permissions.hasPermission(128L)))
/*     */     {
/* 341 */       ForumMessageIterator iterator = this.forum.getMessages();
/* 342 */       return new ForumMessageIteratorProxy(iterator, this.authToken, this.permissions);
/*     */     }
/*     */ 
/* 345 */     return ForumMessageIterator.EMPTY_ITERATOR;
/*     */   }
/*     */ 
/*     */   public ForumMessageIterator getMessages(ResultFilter resultFilter)
/*     */   {
/* 350 */     if ((this.permissions.hasPermission(1L) | isAdmin() | this.permissions.hasPermission(128L)))
/*     */     {
/* 353 */       ForumMessageIterator iterator = this.forum.getMessages(resultFilter);
/* 354 */       return new ForumMessageIteratorProxy(iterator, this.authToken, this.permissions);
/*     */     }
/*     */ 
/* 357 */     return ForumMessageIterator.EMPTY_ITERATOR;
/*     */   }
/*     */ 
/*     */   public int getThreadCount()
/*     */   {
/* 362 */     if ((this.permissions.hasPermission(1L) | isAdmin() | this.permissions.hasPermission(128L)))
/*     */     {
/* 365 */       return this.forum.getThreadCount();
/*     */     }
/*     */ 
/* 368 */     return 0;
/*     */   }
/*     */ 
/*     */   public int getThreadCount(ResultFilter resultFilter)
/*     */   {
/* 373 */     if ((this.permissions.hasPermission(1L) | isAdmin() | this.permissions.hasPermission(128L)))
/*     */     {
/* 376 */       return this.forum.getThreadCount(resultFilter);
/*     */     }
/*     */ 
/* 379 */     return 0;
/*     */   }
/*     */ 
/*     */   public int getMessageCount()
/*     */   {
/* 384 */     if ((this.permissions.hasPermission(1L) | isAdmin() | this.permissions.hasPermission(128L)))
/*     */     {
/* 387 */       return this.forum.getMessageCount();
/*     */     }
/*     */ 
/* 390 */     return 0;
/*     */   }
/*     */ 
/*     */   public int getMessageCount(ResultFilter resultFilter)
/*     */   {
/* 395 */     if ((this.permissions.hasPermission(1L) | isAdmin() | this.permissions.hasPermission(128L)))
/*     */     {
/* 398 */       return this.forum.getMessageCount(resultFilter);
/*     */     }
/*     */ 
/* 401 */     return 0;
/*     */   }
/*     */ 
/*     */   public ForumMessage getLatestMessage()
/*     */   {
/* 406 */     if ((this.permissions.hasPermission(1L) | isAdmin() | this.permissions.hasPermission(128L)))
/*     */     {
/* 409 */       ForumMessage message = this.forum.getLatestMessage();
/* 410 */       if (message == null) {
/* 411 */         return null;
/*     */       }
/*     */ 
/* 414 */       return new ForumMessageProxy(message, this.authToken, this.permissions);
/*     */     }
/*     */ 
/* 417 */     return null;
/*     */   }
/*     */ 
/*     */   public Query createQuery()
/*     */   {
/* 422 */     return new QueryProxy(this.forum.createQuery(), this.authToken);
/*     */   }
/*     */ 
/*     */   public FilterManager getFilterManager() {
/* 426 */     return new FilterManagerProxy(this.forum.getFilterManager(), 0, this.permissions);
/*     */   }
/*     */ 
/*     */   public InterceptorManager getInterceptorManager() throws UnauthorizedException {
/* 430 */     if (isAdmin()) {
/* 431 */       return new InterceptorManagerProxy(this.forum.getInterceptorManager(), this.permissions);
/*     */     }
/*     */ 
/* 434 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public GatewayManager getGatewayManager() throws UnauthorizedException
/*     */   {
/* 439 */     if (isAdmin()) {
/* 440 */       return this.forum.getGatewayManager();
/*     */     }
/*     */ 
/* 443 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public PermissionsManager getPermissionsManager() throws UnauthorizedException
/*     */   {
/* 448 */     if (isAdmin()) {
/* 449 */       return new PermissionsManagerProxy(0, this.forum.getID(), this.permissions);
/*     */     }
/*     */ 
/* 452 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Permissions getPermissions(AuthToken authToken)
/*     */   {
/* 457 */     return this.forum.getPermissions(authToken);
/*     */   }
/*     */ 
/*     */   public boolean isAuthorized(long type) {
/* 461 */     return this.permissions.hasPermission(type);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 465 */     return this.forum.toString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object) {
/* 469 */     return this.forum.equals(object);
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 473 */     return this.forum.hashCode();
/*     */   }
/*     */ 
/*     */   public Forum getProxiedForum()
/*     */     throws UnauthorizedException
/*     */   {
/* 488 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 489 */       return this.forum;
/*     */     }
/*     */ 
/* 492 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   private boolean isAdmin()
/*     */   {
/* 497 */     return this.permissions.hasPermission(576460752303424256L);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.ForumProxy
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserProxy;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.AttachmentException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import java.io.InputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class ForumMessageProxy
/*     */   implements ForumMessage, Serializable
/*     */ {
/*     */   private ForumMessage message;
/*     */   private AuthToken authToken;
/*     */   protected Permissions permissions;
/*     */ 
/*     */   public ForumMessageProxy(ForumMessage message, AuthToken authToken, Permissions permissions)
/*     */   {
/*  41 */     this.message = message;
/*  42 */     this.authToken = authToken;
/*  43 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public long getID()
/*     */   {
/*  49 */     return this.message.getID();
/*     */   }
/*     */ 
/*     */   public int getForumIndex() {
/*  53 */     return this.message.getForumIndex();
/*     */   }
/*     */ 
/*     */   public Date getCreationDate() {
/*  57 */     return this.message.getCreationDate();
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Date creationDate)
/*     */     throws UnauthorizedException
/*     */   {
/*  63 */     if (isAdmin()) {
/*  64 */       this.message.setCreationDate(creationDate);
/*     */     }
/*     */     else
/*  67 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Date getModificationDate()
/*     */   {
/*  72 */     return this.message.getModificationDate();
/*     */   }
/*     */ 
/*     */   public void setModificationDate(Date modificationDate)
/*     */     throws UnauthorizedException
/*     */   {
/*  78 */     if (isAdmin()) {
/*  79 */       this.message.setModificationDate(modificationDate);
/*     */     }
/*     */     else
/*  82 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public String getSubject()
/*     */   {
/*  87 */     return this.message.getSubject();
/*     */   }
/*     */ 
/*     */   public String getUnfilteredSubject() {
/*  91 */     return this.message.getUnfilteredSubject();
/*     */   }
/*     */ 
/*     */   public void setSubject(String subject) throws UnauthorizedException {
/*  95 */     if (isAllowedToEdit()) {
/*  96 */       this.message.setSubject(subject);
/*     */     }
/*     */     else
/*  99 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public String getBody()
/*     */   {
/* 104 */     return this.message.getBody();
/*     */   }
/*     */ 
/*     */   public String getUnfilteredBody() {
/* 108 */     return this.message.getUnfilteredBody();
/*     */   }
/*     */ 
/*     */   public void setBody(String body) throws UnauthorizedException {
/* 112 */     if (isAllowedToEdit()) {
/* 113 */       this.message.setBody(body);
/*     */     }
/*     */     else
/* 116 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public User getUser()
/*     */   {
/* 121 */     User user = this.message.getUser();
/* 122 */     if (user == null) {
/* 123 */       return null;
/*     */     }
/* 125 */     Permissions userPermissions = new Permissions(this.permissions, user.getPermissions(this.authToken));
/* 126 */     return new UserProxy(user, this.authToken, userPermissions);
/*     */   }
/*     */ 
/*     */   public ForumMessage getParentMessage() {
/* 130 */     return this.message.getParentMessage();
/*     */   }
/*     */ 
/*     */   public Attachment createAttachment(String name, String contentType, InputStream data)
/*     */     throws IllegalStateException, AttachmentException, UnauthorizedException
/*     */   {
/* 137 */     if ((isAdmin()) || (this.permissions.hasPermission(128L)) || (this.permissions.hasPermission(8L)))
/*     */     {
/* 140 */       return this.message.createAttachment(name, contentType, data);
/*     */     }
/*     */ 
/* 143 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getAttachmentCount()
/*     */   {
/* 148 */     return this.message.getAttachmentCount();
/*     */   }
/*     */ 
/*     */   public void deleteAttachment(Attachment attachment)
/*     */     throws AttachmentException, UnauthorizedException
/*     */   {
/* 154 */     if (isAllowedToEdit()) {
/* 155 */       this.message.deleteAttachment(attachment);
/*     */     }
/*     */     else
/* 158 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getAttachments()
/*     */   {
/* 163 */     return new IteratorProxy(13, this.message.getAttachments(), this.authToken);
/*     */   }
/*     */ 
/*     */   public int getModerationValue() {
/* 167 */     return this.message.getModerationValue();
/*     */   }
/*     */ 
/*     */   public void setModerationValue(int value, AuthToken authToken) throws UnauthorizedException {
/* 171 */     if ((isAdmin()) || (this.permissions.hasPermission(128L))) {
/* 172 */       this.message.setModerationValue(value, authToken);
/*     */     }
/*     */     else
/* 175 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public String getProperty(String name)
/*     */   {
/* 180 */     return this.message.getProperty(name);
/*     */   }
/*     */ 
/*     */   public String getUnfilteredProperty(String name) {
/* 184 */     return this.message.getUnfilteredProperty(name);
/*     */   }
/*     */ 
/*     */   public Collection getProperties(String parentName) {
/* 188 */     return this.message.getProperties(parentName);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value)
/*     */     throws UnauthorizedException
/*     */   {
/* 194 */     if (isAllowedToEdit()) {
/* 195 */       this.message.setProperty(name, value);
/*     */     }
/*     */     else
/* 198 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) throws UnauthorizedException
/*     */   {
/* 203 */     if (isAllowedToEdit()) {
/* 204 */       this.message.deleteProperty(name);
/*     */     }
/*     */     else
/* 207 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames()
/*     */   {
/* 212 */     return this.message.getPropertyNames();
/*     */   }
/*     */ 
/*     */   public boolean isAnonymous() {
/* 216 */     return this.message.isAnonymous();
/*     */   }
/*     */ 
/*     */   public ForumThread getForumThread() {
/* 220 */     ForumThread thread = this.message.getForumThread();
/* 221 */     if (thread == null) {
/* 222 */       return null;
/*     */     }
/*     */ 
/* 225 */     return new ForumThreadProxy(thread, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public Forum getForum()
/*     */   {
/* 230 */     Forum forum = this.message.getForum();
/* 231 */     if (forum == null) {
/* 232 */       return null;
/*     */     }
/*     */ 
/* 235 */     return new ForumProxy(forum, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public boolean isAuthorized(long type)
/*     */   {
/* 240 */     return this.permissions.hasPermission(type);
/*     */   }
/*     */ 
/*     */   public boolean isHtml() {
/* 244 */     return this.message.isHtml();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 250 */     return this.message.toString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object) {
/* 254 */     return this.message.equals(object);
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 258 */     return this.message.hashCode();
/*     */   }
/*     */ 
/*     */   public ForumMessage getProxiedForumMessage()
/*     */     throws UnauthorizedException
/*     */   {
/* 266 */     if ((isAdmin()) || (getID() == -1L)) {
/* 267 */       return this.message;
/*     */     }
/*     */ 
/* 270 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   private boolean isAdmin()
/*     */   {
/* 275 */     return this.permissions.hasPermission(576460752303424256L);
/*     */   }
/*     */ 
/*     */   private boolean isAllowedToEdit()
/*     */   {
/* 286 */     if ((isAdmin()) || (this.permissions.hasPermission(128L)))
/*     */     {
/* 288 */       return true;
/*     */     }
/*     */ 
/* 291 */     if ((!isAnonymous()) && (getUser().getID() == this.authToken.getUserID())) {
/* 292 */       return true;
/*     */     }
/*     */ 
/* 295 */     if ((getUser() == null) && (getID() == -1L)) {
/* 296 */       return true;
/*     */     }
/*     */ 
/* 299 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.ForumMessageProxy
 * JD-Core Version:    0.6.2
 */
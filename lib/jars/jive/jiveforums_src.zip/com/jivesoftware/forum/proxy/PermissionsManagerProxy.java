/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.Group;
/*     */ import com.jivesoftware.base.PermissionType;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.PermissionsManager;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.database.DbPermissionsManager;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class PermissionsManagerProxy
/*     */   implements PermissionsManager
/*     */ {
/*     */   int objectType;
/*     */   long objectID;
/*     */   private Permissions permissions;
/*  13 */   private DbPermissionsManager permManager = DbPermissionsManager.getInstance();
/*     */ 
/*     */   public PermissionsManagerProxy(int objectType, long objectID, Permissions permissions)
/*     */   {
/*  17 */     this.objectType = objectType;
/*  18 */     this.objectID = objectID;
/*  19 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public void addUserPermission(User user, PermissionType permissionType, long permission)
/*     */     throws UnauthorizedException
/*     */   {
/*  25 */     if (isAdmin()) {
/*  26 */       this.permManager.addUserPermission(this.objectType, this.objectID, user, permissionType, permission);
/*     */     }
/*     */     else
/*  29 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void addAnonymousUserPermission(PermissionType permissionType, long permission)
/*     */     throws UnauthorizedException
/*     */   {
/*  36 */     if (isAdmin()) {
/*  37 */       this.permManager.addAnonymousUserPermission(this.objectType, this.objectID, permissionType, permission);
/*     */     }
/*     */     else
/*  40 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void addRegisteredUserPermission(PermissionType permissionType, long permission)
/*     */     throws UnauthorizedException
/*     */   {
/*  47 */     if (isAdmin()) {
/*  48 */       this.permManager.addRegisteredUserPermission(this.objectType, this.objectID, permissionType, permission);
/*     */     }
/*     */     else
/*  51 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void removeUserPermission(User user, PermissionType permissionType, long permission)
/*     */     throws UnauthorizedException
/*     */   {
/*  58 */     if (isAdmin()) {
/*  59 */       this.permManager.removeUserPermission(this.objectType, this.objectID, user, permissionType, permission);
/*     */     }
/*     */     else
/*  62 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void removeAnonymousUserPermission(PermissionType permissionType, long permission)
/*     */     throws UnauthorizedException
/*     */   {
/*  69 */     if (isAdmin()) {
/*  70 */       this.permManager.removeAnonymousUserPermission(this.objectType, this.objectID, permissionType, permission);
/*     */     }
/*     */     else
/*  73 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void removeRegisteredUserPermission(PermissionType permissionType, long permission)
/*     */     throws UnauthorizedException
/*     */   {
/*  80 */     if (isAdmin()) {
/*  81 */       this.permManager.removeRegisteredUserPermission(this.objectType, this.objectID, permissionType, permission);
/*     */     }
/*     */     else
/*  84 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void removeAllUserPermissions(PermissionType permissionType) throws UnauthorizedException
/*     */   {
/*  89 */     if (isAdmin()) {
/*  90 */       this.permManager.removeAllUserPermissions(this.objectType, this.objectID, permissionType);
/*     */     }
/*     */     else
/*  93 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean anonymousUserHasPermission(PermissionType permissionType, long permission)
/*     */   {
/*  98 */     return this.permManager.anonymousUserHasPermission(this.objectType, this.objectID, permissionType, permission);
/*     */   }
/*     */ 
/*     */   public boolean registeredUserHasPermission(PermissionType permissionType, long permission) {
/* 102 */     return this.permManager.registeredUserHasPermission(this.objectType, this.objectID, permissionType, permission);
/*     */   }
/*     */ 
/*     */   public Iterator usersWithPermission(PermissionType permissionType, long permission) {
/* 106 */     return this.permManager.usersWithPermission(this.objectType, this.objectID, permissionType, permission);
/*     */   }
/*     */ 
/*     */   public int usersWithPermissionCount(PermissionType permissionType, long permission) {
/* 110 */     return this.permManager.usersWithPermissionCount(this.objectType, this.objectID, permissionType, permission);
/*     */   }
/*     */ 
/*     */   public void addGroupPermission(Group group, PermissionType permissionType, long permission)
/*     */     throws UnauthorizedException
/*     */   {
/* 116 */     if (isAdmin()) {
/* 117 */       this.permManager.addGroupPermission(this.objectType, this.objectID, group, permissionType, permission);
/*     */     }
/*     */     else
/* 120 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void removeGroupPermission(Group group, PermissionType permissionType, long permission)
/*     */     throws UnauthorizedException
/*     */   {
/* 127 */     if (isAdmin()) {
/* 128 */       this.permManager.removeGroupPermission(this.objectType, this.objectID, group, permissionType, permission);
/*     */     }
/*     */     else
/* 131 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void removeAllGroupPermissions(PermissionType permissionType) throws UnauthorizedException
/*     */   {
/* 136 */     if (isAdmin()) {
/* 137 */       this.permManager.removeAllGroupPermissions(this.objectType, this.objectID, permissionType);
/*     */     }
/*     */     else
/* 140 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator groupsWithPermission(PermissionType permissionType, long permission)
/*     */   {
/* 145 */     return this.permManager.groupsWithPermission(this.objectType, this.objectID, permissionType, permission);
/*     */   }
/*     */ 
/*     */   public int groupsWithPermissionCount(PermissionType permissionType, long permission) {
/* 149 */     return this.permManager.groupsWithPermissionCount(this.objectType, this.objectID, permissionType, permission);
/*     */   }
/*     */ 
/*     */   private boolean isAdmin()
/*     */   {
/* 158 */     if (this.objectType == 17) {
/* 159 */       return this.permissions.hasPermission(576460752303423488L);
/*     */     }
/* 161 */     if (this.objectType == 14) {
/* 162 */       return this.permissions.hasPermission(576460752303424000L);
/*     */     }
/*     */ 
/* 165 */     if (this.objectType == 0) {
/* 166 */       return this.permissions.hasPermission(576460752303424256L);
/*     */     }
/*     */ 
/* 170 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.PermissionsManagerProxy
 * JD-Core Version:    0.6.2
 */
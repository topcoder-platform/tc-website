/*     */ package com.jivesoftware.forum.filter;
/*     */ 
/*     */ import com.jivesoftware.base.AuthFactory;
/*     */ import com.jivesoftware.base.Filter;
/*     */ import com.jivesoftware.base.FilterChain;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.util.LocaleUtils;
/*     */ 
/*     */ public class ForumMessageIDFilter
/*     */   implements Filter
/*     */ {
/*  23 */   private String startTag = "<a href=\"thread.jspa?";
/*  24 */   private String midTag = "\">";
/*  25 */   private String endTag = "</a>";
/*  26 */   private boolean showTitle = true;
/*     */ 
/*     */   public String getName() {
/*  29 */     return "ForumMessageID";
/*     */   }
/*     */ 
/*     */   public String applyFilter(String string, int currentIndex, FilterChain chain) {
/*  33 */     if ((string == null) || (string.length() == 0)) {
/*  34 */       return string;
/*     */     }
/*     */ 
/*  37 */     int length = string.length();
/*  38 */     StringBuffer filtered = new StringBuffer((int)(length * 1.1D));
/*  39 */     String lc = string.toLowerCase();
/*     */ 
/*  42 */     int oldEnd = 0;
/*  43 */     int start = lc.indexOf("[messageid]");
/*     */ 
/*  45 */     while ((start != -1) && (start + 23 < length)) {
/*  46 */       int end = lc.indexOf("[/messageid]", start + 12);
/*     */ 
/*  48 */       if ((end == -1) || (end >= length))
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/*  53 */       String tag = string.substring(start + 11, end);
/*  54 */       long messageID = -1L;
/*     */       try
/*     */       {
/*  57 */         messageID = Long.parseLong(tag);
/*     */       }
/*     */       catch (NumberFormatException e) {
/*     */       }
/*  61 */       ForumMessage message = null;
/*     */ 
/*  63 */       if (messageID != -1L) {
/*  64 */         ForumFactory.getInstance(AuthFactory.getAnonymousAuthToken());
/*     */         try {
/*  66 */           message = DbForumFactory.getInstance().getMessage(messageID);
/*     */         }
/*     */         catch (ForumMessageNotFoundException e) {
/*  69 */           Log.error(e);
/*     */         }
/*     */       }
/*     */ 
/*  73 */       if (message != null) {
/*  74 */         filtered.append(string.substring(oldEnd, start));
/*  75 */         filtered.append(this.startTag).append(message.getID());
/*  76 */         filtered.append(this.midTag);
/*     */ 
/*  78 */         if (this.showTitle) {
/*  79 */           filtered.append(message.getSubject());
/*     */         }
/*     */         else {
/*  82 */           filtered.append(messageID);
/*     */         }
/*  84 */         filtered.append(this.endTag);
/*     */       }
/*     */       else {
/*  87 */         filtered.append(string.substring(oldEnd, start));
/*  88 */         filtered.append(LocaleUtils.getLocalizedString("thread.error_messageid_not_found"));
/*     */       }
/*     */ 
/*  91 */       oldEnd = end + 12;
/*  92 */       start = lc.indexOf("[messageid]", oldEnd);
/*     */     }
/*     */ 
/*  96 */     if (oldEnd == 0) {
/*  97 */       return chain.applyFilters(currentIndex, string);
/*     */     }
/*     */ 
/* 100 */     if (oldEnd < length) {
/* 101 */       filtered.append(string.substring(oldEnd));
/*     */     }
/*     */ 
/* 104 */     return chain.applyFilters(currentIndex, filtered.toString());
/*     */   }
/*     */ 
/*     */   public String getStartTag() {
/* 108 */     return this.startTag;
/*     */   }
/*     */ 
/*     */   public void setStartTag(String startTag) {
/* 112 */     this.startTag = startTag;
/*     */   }
/*     */ 
/*     */   public String getMidTag() {
/* 116 */     return this.midTag;
/*     */   }
/*     */ 
/*     */   public void setMidTag(String midTag) {
/* 120 */     this.midTag = midTag;
/*     */   }
/*     */ 
/*     */   public String getEndTag() {
/* 124 */     return this.endTag;
/*     */   }
/*     */ 
/*     */   public void setEndTag(String endTag) {
/* 128 */     this.endTag = endTag;
/*     */   }
/*     */ 
/*     */   public boolean isShowTitle() {
/* 132 */     return this.showTitle;
/*     */   }
/*     */ 
/*     */   public void setShowTitle(boolean showTitle) {
/* 136 */     this.showTitle = showTitle;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.filter.ForumMessageIDFilter
 * JD-Core Version:    0.6.2
 */
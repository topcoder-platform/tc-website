/*    */ package com.jivesoftware.forum.filter;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class ForumMessageIDFilterBeanInfo extends JiveBeanInfo
/*    */ {
/* 20 */   public static final String[] PROPERTY_NAMES = { "startTag", "midTag", "endTag", "showTitle" };
/*    */ 
/*    */   public Class getBeanClass()
/*    */   {
/* 32 */     return ForumMessageIDFilter.class;
/*    */   }
/*    */ 
/*    */   public String[] getPropertyNames() {
/* 36 */     return PROPERTY_NAMES;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 40 */     return "ForumMessageIDFilter";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.filter.ForumMessageIDFilterBeanInfo
 * JD-Core Version:    0.6.2
 */
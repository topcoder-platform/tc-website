/*    */ package com.jivesoftware.forum.filter;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class JIRAFilterBeanInfo extends JiveBeanInfo
/*    */ {
/*  9 */   public static final String[] PROPERTY_NAMES = { "projectNames", "jiraInstance", "username", "password", "trackbackEnabled", "openWindow" };
/*    */ 
/*    */   public Class getBeanClass()
/*    */   {
/* 23 */     return JIRAFilter.class;
/*    */   }
/*    */ 
/*    */   public String[] getPropertyNames() {
/* 27 */     return PROPERTY_NAMES;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 31 */     return "JIRAFilter";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.filter.JIRAFilterBeanInfo
 * JD-Core Version:    0.6.2
 */
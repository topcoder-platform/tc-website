/*   */ package com.jivesoftware.forum.filter;
/*   */ 
/*   */ import com.jivesoftware.base.filter.HTMLFilter;
/*   */ import com.jivesoftware.forum.ForumMessage;
/*   */ 
/*   */ public class ForumHTMLFilter extends HTMLFilter
/*   */ {
/*   */   protected boolean contentIsHtml(Object sourceObject)
/*   */   {
/* 8 */     ForumMessage message = (ForumMessage)sourceObject;
/* 9 */     return message.isHtml();
/*   */   }
/*   */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.filter.ForumHTMLFilter
 * JD-Core Version:    0.6.2
 */
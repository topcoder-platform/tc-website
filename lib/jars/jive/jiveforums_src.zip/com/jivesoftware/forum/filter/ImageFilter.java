/*     */ package com.jivesoftware.forum.filter;
/*     */ 
/*     */ import com.jivesoftware.base.Filter;
/*     */ import com.jivesoftware.base.FilterChain;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class ImageFilter
/*     */   implements Filter
/*     */ {
/*  19 */   private static Pattern MARKUP = Pattern.compile("\\[img src=\"\\@(\\d+)\"]", 2);
/*     */ 
/*  21 */   private static Pattern HTML_TO_MARKUP = Pattern.compile("\\Q<img\\E\\s[^>]*\\Qsrc=\"servlet/JiveServlet/download/\\E\\d+-\\d+-\\d+-(\\d+)\\/[^\"]+\"[^/>]*/?>", 34);
/*     */ 
/*  24 */   private static Pattern NNTP_TO_MARKUP = Pattern.compile("\\Q<img\\E\\s[^>]*src=\"cid:([^\"]+)\"[^/>]*/?>", 2);
/*     */ 
/*     */   public String getName()
/*     */   {
/*  28 */     return "ImageFilter";
/*     */   }
/*     */ 
/*     */   public String applyFilter(String string, int currentIndex, FilterChain chain) {
/*  32 */     if ((chain.getSourceObject() instanceof ForumMessage)) {
/*  33 */       ForumMessage msg = (ForumMessage)chain.getSourceObject();
/*  34 */       return chain.applyFilters(currentIndex, convertMarkupToHtml(msg, string));
/*     */     }
/*     */ 
/*  37 */     return chain.applyFilters(currentIndex, string);
/*     */   }
/*     */ 
/*     */   public static String convertHtmlToMarkup(String html)
/*     */   {
/*  42 */     return HTML_TO_MARKUP.matcher(html).replaceAll("[img src=\"@$1\"]");
/*     */   }
/*     */ 
/*     */   public static String convertMarkupToHtml(ForumMessage msg, String markup) {
/*  46 */     long forumID = msg.getForum().getID();
/*     */ 
/*  48 */     if (msg.getForumThread() == null)
/*     */     {
/*  50 */       return markup;
/*     */     }
/*     */ 
/*  53 */     long threadID = msg.getForumThread().getID();
/*  54 */     long id = msg.getID();
/*     */ 
/*  56 */     String base = forumID + "-" + threadID + "-" + id + "-";
/*     */ 
/*  58 */     StringBuffer output = new StringBuffer(markup.length());
/*  59 */     Matcher matcher = MARKUP.matcher(markup);
/*  60 */     while (matcher.find()) {
/*  61 */       String attachmentID = matcher.group(1);
/*     */ 
/*  64 */       Attachment attachment = getAttachment(msg, Long.parseLong(attachmentID));
/*  65 */       if (attachment != null) {
/*  66 */         String name = attachment.getName();
/*  67 */         matcher.appendReplacement(output, "<img src=\"servlet/JiveServlet/download/" + base + attachmentID + "/" + name + "\"/>");
/*     */       }
/*     */       else
/*     */       {
/*  71 */         matcher.appendReplacement(output, "");
/*     */       }
/*     */     }
/*  74 */     matcher.appendTail(output);
/*     */ 
/*  76 */     return output.toString();
/*     */   }
/*     */ 
/*     */   private static Attachment getAttachment(ForumMessage msg, long attachmentID) {
/*  80 */     Iterator attachments = msg.getAttachments();
/*  81 */     while (attachments.hasNext()) {
/*  82 */       Attachment a = (Attachment)attachments.next();
/*  83 */       if (a.getID() == attachmentID) {
/*  84 */         return a;
/*     */       }
/*     */     }
/*     */ 
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */   public static NntpImageResult convertMarkupToNntp(ForumMessage msg, String source)
/*     */   {
/* 103 */     Map cidMap = null;
/* 104 */     StringBuffer output = new StringBuffer(source.length());
/* 105 */     Matcher matcher = MARKUP.matcher(source);
/* 106 */     while (matcher.find()) {
/* 107 */       String attachmentID = matcher.group(1);
/*     */ 
/* 110 */       Attachment attachment = getAttachment(msg, Long.parseLong(attachmentID));
/*     */ 
/* 112 */       if (attachment != null) {
/* 113 */         if (cidMap == null) {
/* 114 */           cidMap = new HashMap();
/*     */         }
/*     */ 
/* 118 */         cidMap.put(attachmentID, attachment);
/*     */ 
/* 121 */         matcher.appendReplacement(output, "<img src=\"cid:" + attachmentID + "\"/>");
/*     */       }
/*     */       else {
/* 124 */         matcher.appendReplacement(output, "");
/*     */       }
/*     */     }
/* 127 */     matcher.appendTail(output);
/*     */ 
/* 129 */     if (cidMap == null) {
/* 130 */       cidMap = Collections.EMPTY_MAP;
/*     */     }
/*     */ 
/* 133 */     return new NntpImageResult(output.toString(), cidMap);
/*     */   }
/*     */ 
/*     */   public static String convertNntpToMarkup(Map cidMap, String nntp)
/*     */   {
/* 144 */     StringBuffer output = new StringBuffer(nntp.length());
/* 145 */     Matcher matcher = NNTP_TO_MARKUP.matcher(nntp);
/* 146 */     while (matcher.find()) {
/* 147 */       String cidKey = matcher.group(1);
/* 148 */       Long attachmentID = (Long)cidMap.get(cidKey);
/*     */ 
/* 150 */       if (attachmentID != null) {
/* 151 */         matcher.appendReplacement(output, "[img src=\"@" + attachmentID + "\"]");
/*     */       }
/*     */       else {
/* 154 */         matcher.appendReplacement(output, "");
/*     */       }
/*     */     }
/* 157 */     matcher.appendTail(output);
/*     */ 
/* 159 */     return output.toString();
/*     */   }
/*     */ 
/*     */   public static List getAttachmentsFromNntp(ForumMessage msg, String source)
/*     */   {
/* 164 */     ArrayList list = null;
/* 165 */     HashSet ids = null;
/* 166 */     Matcher matcher = MARKUP.matcher(source);
/* 167 */     while (matcher.find()) {
/* 168 */       if (list == null) {
/* 169 */         list = new ArrayList(3);
/* 170 */         ids = new HashSet(3);
/*     */       }
/*     */ 
/* 173 */       String id = matcher.group(1);
/* 174 */       if (ids.add(id)) {
/* 175 */         Attachment attachment = getAttachment(msg, Long.parseLong(id));
/* 176 */         if (attachment != null) {
/* 177 */           list.add(attachment);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 182 */     if (list == null) {
/* 183 */       return Collections.EMPTY_LIST;
/*     */     }
/* 185 */     return list;
/*     */   }
/*     */ 
/*     */   public static class NntpImageResult
/*     */   {
/*     */     String result;
/*     */     Map cidMap;
/*     */ 
/*     */     public NntpImageResult(String result, Map cidMap)
/*     */     {
/* 199 */       this.result = result;
/* 200 */       this.cidMap = cidMap;
/*     */     }
/*     */ 
/*     */     public String getResult() {
/* 204 */       return this.result;
/*     */     }
/*     */ 
/*     */     public Map getCidMap() {
/* 208 */       return this.cidMap;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.filter.ImageFilter
 * JD-Core Version:    0.6.2
 */
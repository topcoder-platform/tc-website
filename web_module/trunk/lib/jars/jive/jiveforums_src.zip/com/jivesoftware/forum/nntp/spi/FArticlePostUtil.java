/*     */ package com.jivesoftware.forum.nntp.spi;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.AttachmentException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.MessageRejectedException;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.forum.filter.ImageFilter;
/*     */ import com.jivesoftware.forum.gateway.JavaMailGateway;
/*     */ import com.jivesoftware.forum.nntp.MessageID;
/*     */ import com.jivesoftware.forum.nntp.NNTPServer;
/*     */ import com.jivesoftware.forum.nntp.NNTPServerConfig;
/*     */ import com.jivesoftware.forum.nntp.NewsGroupNotFoundException;
/*     */ import com.jivesoftware.forum.nntp.NoPermissionException;
/*     */ import com.jivesoftware.forum.nntp.PostFailedException;
/*     */ import com.jivesoftware.forum.nntp.PostRejectedException;
/*     */ import com.jivesoftware.forum.nntp.SessionManager;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.activation.MimetypesFileTypeMap;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ 
/*     */ public final class FArticlePostUtil
/*     */ {
/*     */   public static final String TEXT_PLAIN = "text/plain";
/*     */   public static final String TEXT_HTML = "text/html";
/*     */   public static final String MULTIPART_MIXED = "multipart/mixed";
/*     */   public static final String MULTIPART_RELATED = "multipart/related";
/*     */   public static final String MULTIPART_ALTERNATIVE = "multipart/alternative";
/*     */ 
/*     */   public static void post(Iterator rawArticle, ForumSession session)
/*     */     throws PostRejectedException, PostFailedException, NoPermissionException
/*     */   {
/*     */     try
/*     */     {
/*  66 */       MimeTools.Headers headers = MimeTools.parseHeaders(rawArticle);
/*     */ 
/*  70 */       if ((!NNTPServerConfig.getInstance().isCrossPostingAllowed()) && 
/*  71 */         (new StringTokenizer(headers.groups.toString(), ",").countTokens() > 1)) {
/*  72 */         throw new PostRejectedException();
/*     */       }
/*     */ 
/*  76 */       if (JiveGlobals.getJiveBooleanProperty("nntp.enable.cancellation", false))
/*     */       {
/*  79 */         Iterator iter = headers.getExtraHeaders().iterator();
/*  80 */         while (iter.hasNext()) {
/*  81 */           MimeTools.Header header = (MimeTools.Header)iter.next();
/*  82 */           if ("Control".equals(header.name)) {
/*  83 */             String controlHdr = header.value;
/*  84 */             if (controlHdr.toLowerCase().startsWith("cancel")) {
/*  85 */               if (!session.isAuthenticated()) {
/*  86 */                 throw new PostRejectedException("Message cancellation failed - anonymous users cannot cancel posts.");
/*     */               }
/*  88 */               long msgId = MessageID.parseMessageID(controlHdr);
/*     */               try {
/*  90 */                 ForumMessage message = DbForumFactory.getInstance().getMessage(msgId);
/*     */ 
/*  92 */                 if (message.getUser().getID() == session.getUser().getID()) {
/*  93 */                   ForumThread thread = message.getForumThread();
/*     */ 
/*  95 */                   if (message.getID() == thread.getRootMessage().getID())
/*     */                   {
/*  97 */                     Forum forum = thread.getForum();
/*  98 */                     forum.deleteThread(thread);
/*     */                   }
/*     */                   else
/*     */                   {
/* 102 */                     thread.deleteMessage(message, false);
/*     */                   }
/*     */                   return;
/*     */                 }
/*     */ 
/* 107 */                 throw new PostFailedException("Message deletion failed - message with id " + message.getID() + " not owned by user with id " + session.getUser().getID());
/*     */               }
/*     */               catch (UnauthorizedException e)
/*     */               {
/* 113 */                 throw new PostFailedException("Message deletion failed - user with id " + session.getUser().getID() + " has insufficient permissions.", e);
/*     */               }
/*     */               catch (ForumMessageNotFoundException e)
/*     */               {
/* 117 */                 throw new PostFailedException("Message deletion failed - Message with id " + msgId + " not found", e);
/*     */               }
/*     */             }
/* 120 */             throw new PostRejectedException("Unhandled control header: " + controlHdr);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 127 */       String contentType = null;
/* 128 */       if (headers.contentType != null) {
/* 129 */         contentType = headers.contentType.toString();
/*     */       }
/*     */       else {
/* 132 */         headers.contentType = new StringBuffer("text/plain; charset=ISO-8859-1;");
/*     */       }
/* 134 */       String type = MimeTools.getMIMEType(contentType);
/*     */ 
/* 137 */       if (("text/plain".equals(type)) || ("text/html".equals(type))) {
/* 138 */         String encoding = null;
/* 139 */         if (headers.contentEncoding != null) {
/* 140 */           encoding = headers.contentEncoding.toString();
/*     */         }
/* 142 */         ForumMessage[] messages = parseBody(session, headers, null, MimeTools.getMIMECharset(contentType), rawArticle, encoding, type);
/*     */ 
/* 145 */         postMessages(messages, session, headers);
/*     */       }
/* 147 */       else if (("multipart/mixed".equals(type)) || ("multipart/related".equals(type))) {
/* 148 */         String boundary = MimeTools.getMIMEBoundary(contentType);
/* 149 */         parseMultipart(rawArticle, headers, boundary, session);
/*     */       }
/* 151 */       else if ("multipart/alternative".equals(type)) {
/* 152 */         String boundary = MimeTools.getMIMEBoundary(contentType);
/* 153 */         ForumMessage[] messages = parseAlternative(session, headers, rawArticle, boundary);
/*     */ 
/* 155 */         postMessages(messages, session, headers);
/*     */       }
/*     */       else {
/* 158 */         throw new PostFailedException("Unsupported content type: " + type);
/*     */       }
/*     */     }
/*     */     catch (NoPermissionException ue) {
/* 162 */       throw ue;
/*     */     }
/*     */     catch (PostRejectedException pre) {
/* 165 */       throw pre;
/*     */     }
/*     */     catch (PostFailedException pfe) {
/* 168 */       Log.error("Could not post message", pfe);
/* 169 */       throw pfe;
/*     */     }
/*     */     catch (IOException ioe) {
/* 172 */       Log.error("Could not post message", ioe);
/* 173 */       throw new PostFailedException(ioe);
/*     */     }
/*     */     finally
/*     */     {
/* 177 */       while (rawArticle.hasNext())
/* 178 */         rawArticle.next();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void postMessages(ForumMessage[] messages, ForumSession session, MimeTools.Headers headers)
/*     */     throws PostRejectedException, NoPermissionException
/*     */   {
/* 196 */     if (messages == null)
/* 197 */       return;
/*     */     try
/*     */     {
/* 200 */       for (int i = 0; i < messages.length; i++) {
/* 201 */         ForumMessage message = messages[i];
/*     */ 
/* 204 */         for (Iterator iter = headers.getExtraHeaders().iterator(); iter.hasNext(); ) {
/* 205 */           MimeTools.Header header = (MimeTools.Header)iter.next();
/* 206 */           message.setProperty("nttp.xheader." + header.name, header.value);
/*     */         }
/* 208 */         Forum forum = message.getForum();
/* 209 */         if ((headers.refs == null) || (headers.refs.toString().trim().length() == 0)) {
/* 210 */           ForumThread thread = forum.createThread(message);
/* 211 */           forum.addThread(thread);
/*     */         }
/*     */         else {
/* 214 */           String references = headers.refs.toString();
/* 215 */           int refsIndex = headers.refs.lastIndexOf(" ");
/* 216 */           if ((refsIndex != -1) && (refsIndex + 1 != references.length())) {
/* 217 */             references = headers.refs.substring(refsIndex + 1);
/*     */           }
/* 219 */           ForumFactory factory = session.getForumFactory();
/*     */ 
/* 223 */           SessionManager sessionManager = NNTPServer.getInstance().getSessionManager();
/* 224 */           if (sessionManager.getPostPermissionMode() == 2)
/*     */           {
/* 227 */             factory = DbForumFactory.getInstance();
/*     */           }
/*     */           try {
/* 230 */             long parentID = MessageID.parseMessageID(references);
/* 231 */             ForumMessage parentMsg = factory.getMessage(parentID);
/*     */ 
/* 233 */             if (parentMsg.getForum().equals(forum)) {
/* 234 */               ForumThread thread = parentMsg.getForumThread();
/*     */ 
/* 237 */               if (("true".equals(thread.getProperty("jive.archived"))) || ("true".equals(thread.getProperty("jive.locked"))))
/*     */               {
/* 240 */                 throw new MessageRejectedException("Thread is archived or locked", message);
/*     */               }
/*     */ 
/* 243 */               parentMsg.getForumThread().addMessage(parentMsg, message);
/*     */             }
/*     */             else
/*     */             {
/* 247 */               ForumThread thread = forum.createThread(message);
/* 248 */               forum.addThread(thread);
/*     */             }
/*     */ 
/*     */           }
/*     */           catch (ForumMessageNotFoundException fe)
/*     */           {
/* 258 */             ForumThread thread = forum.createThread(message);
/* 259 */             forum.addThread(thread);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 265 */       throw new NoPermissionException();
/*     */     }
/*     */     catch (MessageRejectedException mre) {
/* 268 */       throw new PostRejectedException(mre);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static ForumMessage[] createMessages(ForumSession session, MimeTools.Headers mainHeaders, MimeTools.Headers headers, String body)
/*     */     throws PostFailedException, NoPermissionException
/*     */   {
/*     */     try
/*     */     {
/* 286 */       if (mainHeaders.groups == null) {
/* 287 */         throw new PostFailedException();
/*     */       }
/* 289 */       StringTokenizer groupTokenizer = new StringTokenizer(mainHeaders.groups.toString(), ",");
/* 290 */       if (!groupTokenizer.hasMoreTokens()) {
/* 291 */         throw new PostFailedException();
/*     */       }
/*     */ 
/* 294 */       String userAgent = getUserAgent(mainHeaders);
/* 295 */       if ((userAgent == null) && (headers != null)) {
/* 296 */         userAgent = getUserAgent(headers);
/*     */       }
/*     */ 
/* 299 */       ForumMessage[] messages = new ForumMessage[groupTokenizer.countTokens()];
/* 300 */       for (int i = 0; i < messages.length; i++) {
/* 301 */         String group = groupTokenizer.nextToken();
/*     */         try {
/* 303 */           Forum forum = session.getForum(group);
/*     */ 
/* 305 */           SessionManager sessionManager = NNTPServer.getInstance().getSessionManager();
/*     */ 
/* 309 */           if (sessionManager.getPostPermissionMode() == 2)
/*     */           {
/*     */             try
/*     */             {
/* 313 */               forum = DbForumFactory.getInstance().getForum(forum.getID());
/*     */             }
/*     */             catch (Exception e)
/*     */             {
/*     */             }
/*     */           }
/*     */           ForumMessage message;
/* 317 */           if (!session.isAuthenticated()) {
/* 318 */             ForumMessage message = forum.createMessage();
/* 319 */             String from = mainHeaders.from.toString();
/* 320 */             if (from != null) {
/* 321 */               String name = JavaMailGateway.getFromName(from);
/* 322 */               if ((name != null) && (!"".equals(name))) {
/* 323 */                 message.setProperty("name", name);
/*     */               }
/* 325 */               String email = JavaMailGateway.getFromEmail(from);
/* 326 */               if ((email != null) && (!"".equals(email)))
/* 327 */                 message.setProperty("email", email);
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 332 */             message = forum.createMessage(session.getUser());
/*     */           }
/*     */ 
/* 335 */           message.setProperty("source", "nntp");
/* 336 */           if (userAgent != null) {
/* 337 */             message.setProperty("User-Agent", userAgent);
/*     */           }
/* 339 */           message.setBody(body);
/* 340 */           String subject = null;
/*     */ 
/* 342 */           if ((mainHeaders.subject == null) || (mainHeaders.subject.toString().equals(""))) {
/* 343 */             subject = NNTPServerConfig.getInstance().getDefaultSubject();
/*     */           }
/*     */           else {
/* 346 */             subject = MimeUtility.decodeText(mainHeaders.subject.toString());
/*     */           }
/* 348 */           message.setSubject(subject);
/* 349 */           messages[i] = message;
/*     */         }
/*     */         catch (NewsGroupNotFoundException e)
/*     */         {
/*     */         }
/*     */       }
/* 355 */       return messages;
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 358 */       throw new NoPermissionException();
/*     */     }
/*     */     catch (UnsupportedEncodingException uee) {
/* 361 */       throw new PostFailedException(uee);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String getUserAgent(MimeTools.Headers headers)
/*     */   {
/* 372 */     if (headers == null) {
/* 373 */       return null;
/*     */     }
/* 375 */     for (Iterator iter = headers.getExtraHeaders().iterator(); iter.hasNext(); ) {
/* 376 */       MimeTools.Header header = (MimeTools.Header)iter.next();
/* 377 */       for (int i = 0; i < JavaMailGateway.AGENT_HEADER_NAMES.length; i++) {
/* 378 */         if (JavaMailGateway.AGENT_HEADER_NAMES[i].equalsIgnoreCase(header.name)) {
/* 379 */           return header.value;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 384 */     return null;
/*     */   }
/*     */ 
/*     */   public static void parseMultipart(Iterator rawArticle, MimeTools.Headers mainHeaders, String mimeBoundary, ForumSession session)
/*     */     throws PostFailedException, PostRejectedException, NoPermissionException, IOException
/*     */   {
/*     */     try
/*     */     {
/* 404 */       HashMap cidMap = null;
/*     */ 
/* 407 */       while (rawArticle.hasNext()) {
/* 408 */         String line = (String)rawArticle.next();
/* 409 */         if (line.indexOf(mimeBoundary) != -1)
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/* 414 */       ForumMessage[] messages = null;
/*     */ 
/* 416 */       while (rawArticle.hasNext()) {
/* 417 */         MimeBodyPartIterator bodyIterator = new MimeBodyPartIterator(rawArticle, mimeBoundary);
/*     */ 
/* 419 */         MimeTools.Headers headers = MimeTools.parseHeaders(bodyIterator);
/* 420 */         String contentType = headers.contentType.toString();
/* 421 */         String encoding = null;
/* 422 */         if (headers.contentEncoding != null) {
/* 423 */           encoding = headers.contentEncoding.toString();
/*     */         }
/* 425 */         String type = MimeTools.getMIMEType(contentType);
/*     */ 
/* 428 */         if ((("text/plain".equals(type)) || ("text/html".equals(type))) && (messages == null)) {
/* 429 */           messages = parseBody(session, mainHeaders, headers, MimeTools.getMIMECharset(contentType), bodyIterator, encoding, type);
/*     */         }
/*     */         else {
/* 432 */           if ("multipart/mixed".equals(type))
/*     */           {
/* 434 */             throw new PostFailedException();
/*     */           }
/* 436 */           if ((("multipart/alternative".equals(type)) || ("multipart/related".equals(type))) && (messages == null))
/*     */           {
/* 438 */             String boundary = MimeTools.getMIMEBoundary(contentType);
/* 439 */             messages = parseAlternative(session, mainHeaders, bodyIterator, boundary);
/*     */           }
/*     */           else {
/* 442 */             if ((messages == null) || (messages.length == 0));
/* 444 */             while (bodyIterator.hasNext()) {
/* 445 */               bodyIterator.next();
/* 446 */               continue;
/*     */ 
/* 450 */               InputStream stream = new StringIteratorInputStream(bodyIterator);
/*     */               try
/*     */               {
/* 453 */                 if (encoding != null) {
/* 454 */                   stream = MimeUtility.decode(stream, encoding);
/*     */                 }
/*     */                 else {
/* 457 */                   stream = MimeUtility.decode(stream, "base64");
/*     */                 }
/*     */ 
/* 460 */                 long attachmentId = addAttachment(messages, MimeTools.getMIMEName(contentType), type, stream);
/* 461 */                 String cId = null;
/* 462 */                 for (Iterator iterator = headers.getExtraHeaders().iterator(); iterator.hasNext(); ) {
/* 463 */                   MimeTools.Header header = (MimeTools.Header)iterator.next();
/* 464 */                   if ("Content-ID".equals(header.name)) {
/* 465 */                     cId = header.value.substring(1, header.value.length() - 1);
/* 466 */                     break;
/*     */                   }
/*     */                 }
/*     */ 
/* 470 */                 if (cId != null) {
/* 471 */                   if (cidMap == null) {
/* 472 */                     cidMap = new HashMap(2);
/*     */                   }
/*     */ 
/* 475 */                   cidMap.put(cId, new Long(attachmentId));
/*     */                 }
/*     */               }
/*     */               finally {
/* 479 */                 stream.close();
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 485 */         while (bodyIterator.hasNext()) {
/* 486 */           bodyIterator.next();
/*     */         }
/*     */ 
/* 489 */         if (!bodyIterator.hasNextBodyPart())
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/* 494 */       if (cidMap != null) {
/* 495 */         for (int i = 0; i < messages.length; i++) {
/* 496 */           ForumMessage message = messages[i];
/* 497 */           String newBody = ImageFilter.convertNntpToMarkup(cidMap, message.getBody());
/* 498 */           message.setBody(newBody);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 503 */       postMessages(messages, session, mainHeaders);
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 506 */       throw new NoPermissionException();
/*     */     }
/*     */     catch (MessagingException me) {
/* 509 */       throw new PostFailedException(me);
/*     */     }
/*     */     catch (AttachmentException ae) {
/* 512 */       if (ae.getErrorType() == 0) {
/* 513 */         throw new PostRejectedException(ae);
/*     */       }
/* 515 */       if (ae.getErrorType() == 1) {
/* 516 */         throw new PostRejectedException(ae);
/*     */       }
/*     */ 
/* 519 */       throw new PostFailedException(ae);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static long addAttachment(ForumMessage[] messages, String name, String type, InputStream in)
/*     */     throws AttachmentException, UnauthorizedException, IOException
/*     */   {
/* 541 */     ForumMessage message = messages[0];
/* 542 */     Attachment attachment = message.createAttachment(name, type, in);
/*     */ 
/* 544 */     for (int i = 1; i < messages.length; i++) {
/* 545 */       messages[i].createAttachment(attachment.getName(), attachment.getContentType(), attachment.getData());
/*     */     }
/*     */ 
/* 549 */     return attachment.getID();
/*     */   }
/*     */ 
/*     */   public static ForumMessage[] parseBody(ForumSession session, MimeTools.Headers mainHeaders, MimeTools.Headers headers, Charset charset, Iterator rawArticle, String encoding, String type)
/*     */     throws IOException, PostFailedException, PostRejectedException, NoPermissionException
/*     */   {
/*     */     try
/*     */     {
/* 580 */       UUBeginIterator beginIterator = new UUBeginIterator(rawArticle);
/* 581 */       InputStream in = new StringIteratorInputStream(beginIterator, "\r\n");
/*     */ 
/* 583 */       if (encoding != null) {
/* 584 */         in = MimeUtility.decode(in, encoding);
/*     */       }
/* 586 */       InputStreamReader reader = new InputStreamReader(in, charset);
/* 587 */       StringBuffer body = new StringBuffer();
/* 588 */       for (int b = reader.read(); b != -1; b = reader.read()) {
/* 589 */         body.append((char)b);
/*     */       }
/*     */ 
/* 594 */       if (type.equals("text/html")) {
/* 595 */         body = new StringBuffer(JavaMailGateway.cleanseHTMLForImport(body.toString()));
/*     */       }
/*     */ 
/* 604 */       ForumMessage[] messages = createMessages(session, mainHeaders, headers, body.toString().trim());
/*     */ 
/* 607 */       if (type.equals("text/html")) {
/* 608 */         for (int i = 0; i < messages.length; i++) {
/* 609 */           messages[i].setProperty("jive.contentType", "text/html");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 617 */       while (rawArticle.hasNext())
/*     */       {
/* 622 */         String name = beginIterator.getName();
/*     */ 
/* 624 */         MimetypesFileTypeMap typeMap = new MimetypesFileTypeMap();
/* 625 */         String mimeType = typeMap.getContentType(name);
/*     */ 
/* 630 */         UUEndIterator endIterator = new UUEndIterator(rawArticle, beginIterator.getHeader());
/* 631 */         in = new StringIteratorInputStream(endIterator, "\r\n");
/* 632 */         in = MimeUtility.decode(in, "uuencode");
/* 633 */         addAttachment(messages, name, mimeType, in);
/*     */ 
/* 640 */         beginIterator = new UUBeginIterator(rawArticle);
/* 641 */         while (beginIterator.hasNext()) {
/* 642 */           beginIterator.next();
/*     */         }
/*     */       }
/*     */ 
/* 646 */       return messages;
/*     */     }
/*     */     catch (MessagingException me) {
/* 649 */       throw new PostFailedException(me);
/*     */     }
/*     */     catch (AttachmentException ae) {
/* 652 */       if (ae.getErrorType() == 0) {
/* 653 */         throw new PostRejectedException(ae);
/*     */       }
/* 655 */       if (ae.getErrorType() == 1) {
/* 656 */         throw new PostRejectedException(ae);
/*     */       }
/*     */ 
/* 659 */       throw new PostFailedException(ae);
/*     */     }
/*     */     catch (UnauthorizedException ue)
/*     */     {
/* 663 */       ue.printStackTrace();
/* 664 */     }throw new NoPermissionException();
/*     */   }
/*     */ 
/*     */   public static ForumMessage[] parseAlternative(ForumSession session, MimeTools.Headers mainHeaders, Iterator rawArticle, String mimeBoundary)
/*     */     throws IOException, PostFailedException, PostRejectedException, NoPermissionException
/*     */   {
/* 688 */     ForumMessage[] messages = null;
/*     */ 
/* 690 */     while (rawArticle.hasNext()) {
/* 691 */       String line = (String)rawArticle.next();
/* 692 */       if (line.indexOf(mimeBoundary) >= 0)
/*     */       {
/*     */         break;
/*     */       }
/*     */     }
/* 697 */     while (rawArticle.hasNext()) {
/* 698 */       MimeBodyPartIterator bodyIterator = new MimeBodyPartIterator(rawArticle, mimeBoundary);
/* 699 */       MimeTools.Headers headers = MimeTools.parseHeaders(bodyIterator);
/* 700 */       String contentType = headers.contentType.toString();
/* 701 */       String type = MimeTools.getMIMEType(contentType);
/*     */ 
/* 703 */       if (("text/plain".equals(type)) || ("text/html".equals(type))) {
/* 704 */         String encoding = null;
/* 705 */         if (headers.contentEncoding != null) {
/* 706 */           encoding = headers.contentEncoding.toString();
/*     */         }
/* 708 */         messages = parseBody(session, mainHeaders, headers, MimeTools.getMIMECharset(contentType), bodyIterator, encoding, type);
/*     */       }
/*     */       else
/*     */       {
/* 713 */         while (bodyIterator.hasNext()) {
/* 714 */           bodyIterator.next();
/*     */         }
/*     */       }
/* 717 */       if (!bodyIterator.hasNextBodyPart()) {
/*     */         break;
/*     */       }
/*     */     }
/* 721 */     return messages;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.FArticlePostUtil
 * JD-Core Version:    0.6.2
 */
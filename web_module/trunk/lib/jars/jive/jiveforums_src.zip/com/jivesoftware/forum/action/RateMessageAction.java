/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.action.JiveObjectLoader;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.Question;
/*     */ import com.jivesoftware.forum.Question.State;
/*     */ import com.jivesoftware.forum.QuestionManager;
/*     */ 
/*     */ public class RateMessageAction extends ForumActionSupport
/*     */   implements JiveObjectLoader
/*     */ {
/*     */   public static final String HELPFUL = "helpful";
/*     */   public static final String CORRECT = "correct";
/*  27 */   private long messageID = 0L;
/*     */   private String rating;
/*     */   private String cancel;
/*     */   private Boolean ansQuestion;
/*     */   private ForumMessage message;
/*     */   private ForumThread thread;
/*     */   private Question question;
/*     */ 
/*     */   public long getMessageID()
/*     */   {
/*  39 */     return this.messageID;
/*     */   }
/*     */ 
/*     */   public void setMessageID(long messageID) {
/*  43 */     this.messageID = messageID;
/*     */   }
/*     */ 
/*     */   public String getRating() {
/*  47 */     return this.rating;
/*     */   }
/*     */ 
/*     */   public void setRating(String rating) {
/*  51 */     this.rating = rating;
/*     */   }
/*     */ 
/*     */   public String getCancel() {
/*  55 */     return this.cancel;
/*     */   }
/*     */ 
/*     */   public void setCancel(String cancel) {
/*  59 */     this.cancel = "true";
/*     */   }
/*     */ 
/*     */   public Boolean getAnsQuestion() {
/*  63 */     return this.ansQuestion;
/*     */   }
/*     */ 
/*     */   public void setAnsQuestion(Boolean ansQuestion) {
/*  67 */     this.ansQuestion = ansQuestion;
/*     */   }
/*     */ 
/*     */   public ForumMessage getMessage()
/*     */   {
/*  73 */     return this.message;
/*     */   }
/*     */ 
/*     */   public ForumThread getThread() {
/*  77 */     return this.thread;
/*     */   }
/*     */ 
/*     */   public Question getQuestion() {
/*  81 */     return this.question;
/*     */   }
/*     */ 
/*     */   public boolean isHelpful() {
/*  85 */     return "helpful".equals(this.rating);
/*     */   }
/*     */ 
/*     */   public boolean isCorrect() {
/*  89 */     return "correct".equals(this.rating);
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*  95 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute() {
/*  99 */     if ("true".equals(getCancel())) {
/* 100 */       return "cancel";
/*     */     }
/*     */     try
/*     */     {
/* 104 */       User pageUser = getPageUser();
/* 105 */       if (pageUser.getID() != this.thread.getRootMessage().getUser().getID()) {
/* 106 */         addActionError(getText("question.markas.error_not_thread_author"));
/* 107 */         return "error";
/*     */       }
/*     */ 
/* 110 */       if ("helpful".equals(this.rating)) {
/* 111 */         this.question.addHelpfulAnswer(this.message);
/*     */       }
/* 113 */       else if ("correct".equals(this.rating)) {
/* 114 */         this.question.setCorrectAnswer(this.message);
/*     */       }
/* 116 */       if (this.ansQuestion != null) {
/* 117 */         Question.State currentState = this.question.getState();
/*     */ 
/* 119 */         if (Boolean.TRUE == getAnsQuestion()) {
/* 120 */           if (currentState != Question.State.resolved) {
/* 121 */             this.question.setState(Question.State.resolved);
/*     */           }
/*     */         }
/* 124 */         else if ((Boolean.FALSE == getAnsQuestion()) && 
/* 125 */           (currentState != Question.State.open)) {
/* 126 */           this.question.setState(Question.State.open);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 132 */       return "unauthorized";
/*     */     }
/*     */ 
/* 135 */     return "success";
/*     */   }
/*     */ 
/*     */   public String loadObjects() throws Exception {
/*     */     try {
/* 140 */       this.message = getForumFactory().getMessage(this.messageID);
/* 141 */       this.thread = this.message.getForumThread();
/* 142 */       QuestionManager qman = getForumFactory().getQuestionManager();
/*     */       try {
/* 144 */         this.question = qman.getQuestion(this.thread);
/*     */       }
/*     */       catch (NotFoundException nfe) {
/* 147 */         addFieldError("threadID", String.valueOf(this.thread.getID()));
/* 148 */         return "notfound";
/*     */       }
/*     */     }
/*     */     catch (ForumMessageNotFoundException fnfe) {
/* 152 */       addFieldError("messageID", String.valueOf(this.messageID));
/* 153 */       return "notfound";
/*     */     }
/* 155 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.RateMessageAction
 * JD-Core Version:    0.6.2
 */
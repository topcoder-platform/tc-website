/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.Poll;
/*     */ import com.jivesoftware.base.PollException;
/*     */ import com.jivesoftware.base.PollManager;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.action.JiveObjectLoader;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ 
/*     */ public class PollVoteAction extends ForumActionSupport
/*     */   implements Validateable, JiveObjectLoader
/*     */ {
/*  26 */   private long pollID = 0L;
/*  27 */   private int option = -1;
/*     */   private Poll poll;
/*     */ 
/*     */   public long getPollID()
/*     */   {
/*  35 */     return this.pollID;
/*     */   }
/*     */ 
/*     */   public void setPollID(long pollID)
/*     */   {
/*  42 */     this.pollID = pollID;
/*     */   }
/*     */ 
/*     */   public int getOption()
/*     */   {
/*  49 */     return this.option;
/*     */   }
/*     */ 
/*     */   public void setOption(int option)
/*     */   {
/*  56 */     this.option = option;
/*     */   }
/*     */ 
/*     */   public Poll getPoll()
/*     */   {
/*  63 */     return this.poll;
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/*  71 */     int optionCount = this.poll.getOptionCount();
/*  72 */     if ((this.option < 0) || (this.option >= optionCount))
/*  73 */       addFieldError("option", "");
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*  81 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/*  90 */     User user = getPageUser();
/*     */ 
/*  92 */     if (user == null)
/*  93 */       return "login";
/*     */     try
/*     */     {
/*  96 */       this.poll.addUserVote(this.option, user);
/*     */     }
/*     */     catch (PollException e) {
/*  99 */       addFieldError("alreadyVoted", "");
/* 100 */       return "error";
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 103 */       return "unauthorized";
/*     */     }
/* 105 */     return "success";
/*     */   }
/*     */ 
/*     */   public String loadObjects()
/*     */     throws Exception
/*     */   {
/* 117 */     PollManager manager = getForumFactory().getPollManager();
/*     */     try {
/* 119 */       this.poll = manager.getPoll(this.pollID);
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 122 */       return "unauthorized";
/*     */     }
/*     */     catch (NotFoundException e) {
/* 125 */       addFieldError("pollID", String.valueOf(this.pollID));
/* 126 */       return "notfound";
/*     */     }
/* 128 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PollVoteAction
 * JD-Core Version:    0.6.2
 */
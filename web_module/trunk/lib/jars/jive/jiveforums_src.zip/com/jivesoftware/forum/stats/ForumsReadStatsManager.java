/*     */ package com.jivesoftware.forum.stats;
/*     */ 
/*     */ import com.jivesoftware.base.LicenseException;
/*     */ import com.jivesoftware.base.LicenseManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.ReadStatSession;
/*     */ import com.jivesoftware.base.stats.ReadStatsManager;
/*     */ import com.jivesoftware.base.stats.ReadStatsManager.BytesTask;
/*     */ import com.jivesoftware.base.stats.ReadStatsManager.PersistenceTask;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ForumsReadStatsManager extends ReadStatsManager
/*     */ {
/*     */   private static final String INSERT_NNTP_READ_STAT_SESSION = "INSERT INTO jiveNNTPReadStatSession(creationDate, endDate, bytesReceived, bytesSent, IP, country, sessionID) VALUES(?,?,?,?,?,?,?)";
/*     */   private static final String UPDATE_NNTP_SESSION = "UPDATE jiveNNTPReadStatSession SET bytesSent=?, bytesReceived=?, endDate=? WHERE sessionID=?";
/*     */ 
/*     */   protected void validateLicense()
/*     */   {
/*     */     try
/*     */     {
/*  39 */       LicenseManager.validateLicense("Jive Forums Enterprise", "4.2");
/*     */     }
/*     */     catch (LicenseException le) {
/*  42 */       Log.info("Not licensed to use read stats. The read stats feature requires Jive Forums Enterprise or better license.");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ReadStatsManager.BytesTask createBytesTask()
/*     */   {
/*  48 */     return new ForumsBytesTask(this.updatedSessions);
/*     */   }
/*     */ 
/*     */   protected ReadStatsManager.PersistenceTask createPersistenceTask() {
/*  52 */     return new ForumsPersistenceTask(this.sessions, this.readStats);
/*     */   }
/*     */ 
/*     */   static class ForumsPersistenceTask extends ReadStatsManager.PersistenceTask
/*     */   {
/*     */     public ForumsPersistenceTask(List sessions, List readStats)
/*     */     {
/* 100 */       super(readStats);
/*     */     }
/*     */ 
/*     */     protected void insertExtraSessions(ReadStatSession[] rsSessions, boolean canBatch) {
/* 104 */       Connection con = null;
/* 105 */       PreparedStatement pstmt = null;
/*     */       try {
/* 107 */         for (int i = 0; i < rsSessions.length; i++) {
/* 108 */           ReadStatSession rsSession = rsSessions[i];
/* 109 */           if ((rsSession instanceof NNTPReadStatSession))
/*     */           {
/* 111 */             if ((con == null) && (pstmt == null)) {
/* 112 */               con = ConnectionManager.getConnection();
/* 113 */               pstmt = con.prepareStatement("INSERT INTO jiveNNTPReadStatSession(creationDate, endDate, bytesReceived, bytesSent, IP, country, sessionID) VALUES(?,?,?,?,?,?,?)");
/*     */             }
/* 115 */             NNTPReadStatSession nntpRS = (NNTPReadStatSession)rsSession;
/* 116 */             pstmt.setLong(1, nntpRS.getCreationDate().getTime());
/* 117 */             if (nntpRS.getEndDate() == null) {
/* 118 */               pstmt.setNull(2, 2);
/*     */             }
/*     */             else {
/* 121 */               pstmt.setLong(2, nntpRS.getEndDate().getTime());
/*     */             }
/* 123 */             if (nntpRS.getBytesReceived() < 0L) {
/* 124 */               pstmt.setLong(3, 0L);
/*     */             }
/*     */             else {
/* 127 */               pstmt.setLong(3, nntpRS.getBytesReceived());
/*     */             }
/* 129 */             if (nntpRS.getBytesSent() < 0L) {
/* 130 */               pstmt.setLong(4, 0L);
/*     */             }
/*     */             else {
/* 133 */               pstmt.setLong(4, nntpRS.getBytesSent());
/*     */             }
/* 135 */             if (nntpRS.getIP() != null) {
/* 136 */               pstmt.setString(5, nntpRS.getIP());
/*     */             }
/*     */             else {
/* 139 */               pstmt.setNull(5, 12);
/*     */             }
/* 141 */             if (nntpRS.getCountry() != null) {
/* 142 */               pstmt.setString(6, nntpRS.getCountry());
/*     */             }
/*     */             else {
/* 145 */               pstmt.setNull(6, 12);
/*     */             }
/* 147 */             pstmt.setLong(7, rsSession.getSessionID());
/*     */ 
/* 149 */             if (canBatch) {
/* 150 */               pstmt.addBatch();
/*     */             }
/*     */             else {
/* 153 */               pstmt.executeUpdate();
/*     */             }
/*     */           }
/*     */         }
/* 157 */         if ((canBatch) && (pstmt != null))
/* 158 */           pstmt.executeBatch();
/*     */       }
/*     */       catch (SQLException sqle)
/*     */       {
/* 162 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 165 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static class ForumsBytesTask extends ReadStatsManager.BytesTask
/*     */   {
/*     */     public ForumsBytesTask(Map updatedSessions)
/*     */     {
/*  57 */       super();
/*     */     }
/*     */ 
/*     */     protected void storeExtraSessions(ReadStatSession[] rsSessions, Connection con, PreparedStatement pstmt, boolean canBatch)
/*     */     {
/*     */       try
/*     */       {
/*  64 */         for (int i = 0; i < rsSessions.length; i++) {
/*  65 */           if ((rsSessions[i] instanceof NNTPReadStatSession)) {
/*  66 */             if ((con == null) && (pstmt == null)) {
/*  67 */               con = ConnectionManager.getConnection();
/*  68 */               pstmt = con.prepareStatement("UPDATE jiveNNTPReadStatSession SET bytesSent=?, bytesReceived=?, endDate=? WHERE sessionID=?");
/*     */             }
/*  70 */             NNTPReadStatSession rsSession = (NNTPReadStatSession)rsSessions[i];
/*  71 */             if (rsSession.getSessionID() != -1L) {
/*  72 */               pstmt.setLong(1, rsSession.getBytesSent());
/*  73 */               pstmt.setLong(2, rsSession.getBytesReceived());
/*  74 */               pstmt.setLong(3, rsSession.getEndDate().getTime());
/*  75 */               pstmt.setLong(4, rsSession.getSessionID());
/*  76 */               if (canBatch) {
/*  77 */                 pstmt.addBatch();
/*     */               }
/*     */               else {
/*  80 */                 pstmt.executeUpdate();
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*  85 */         if ((canBatch) && (pstmt != null))
/*  86 */           pstmt.executeBatch();
/*     */       }
/*     */       catch (SQLException sqle)
/*     */       {
/*  90 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/*  93 */         ConnectionManager.closeConnection(pstmt, con);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.ForumsReadStatsManager
 * JD-Core Version:    0.6.2
 */
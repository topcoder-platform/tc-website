/*     */ package com.jivesoftware.forum.gateway;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.database.DbForum;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.forum.database.DbForumMessage;
/*     */ import com.jivesoftware.forum.event.MessageEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ThreadEventDispatcher;
/*     */ import com.jivesoftware.util.BeanUtils;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.ClassUtils;
/*     */ import com.jivesoftware.util.LongHashMap;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import com.jivesoftware.util.StringUtils;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TimerTask;
/*     */ 
/*     */ public class GatewayManager
/*     */ {
/*  44 */   public static final String[] DEFAULT_GATEWAY_CLASSES = { "com.jivesoftware.forum.gateway.EmailGateway", "com.jivesoftware.forum.gateway.NewsgroupGateway" };
/*     */   public static final String GATEWAY_EXPORT_RETRY = "jiveGatewayRetryExport";
/* 116 */   private Gateway[] gateways = null;
/*     */ 
/* 119 */   private String context = null;
/*     */ 
/* 122 */   private TimerTask timerTask = null;
/* 123 */   private long lastImport = CacheFactory.currentTime;
/*     */ 
/* 126 */   private TimerTask reexportTask = null;
/*     */ 
/* 128 */   private boolean importLock = false;
/*     */ 
/* 130 */   private boolean importEnabled = true;
/* 131 */   private boolean exportEnabled = true;
/* 132 */   private boolean disableCutOffDate = false;
/* 133 */   private String exportFooter = null;
/* 134 */   private int importInterval = 15;
/* 135 */   private long forumID = -1L;
/*     */ 
/*     */   public static long[] getForumsWithGateways()
/*     */   {
/*  72 */     Log.debug("Retrieving list of forums with gateways");
/*  73 */     LongList forums = new LongList();
/*  74 */     List props = JiveGlobals.getJivePropertyNames("gateway");
/*     */ 
/*  77 */     for (int i = 0; i < props.size(); i++) {
/*  78 */       String prop = (String)props.get(i);
/*  79 */       String forumID = prop.substring(13);
/*  80 */       Log.debug("Checking property " + prop + ", parsed forumID is " + forumID);
/*     */       try {
/*  82 */         if (!forums.contains(Long.parseLong(forumID)))
/*  83 */           forums.add(Long.parseLong(forumID));
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*  87 */         Log.error(e);
/*     */       }
/*     */     }
/*  90 */     return forums.toArray();
/*     */   }
/*     */ 
/*     */   public static void exportData(Forum forum, ForumMessage message)
/*     */   {
/* 102 */     DbForumFactory factory = DbForumFactory.getInstance();
/* 103 */     GatewayManager manager = null;
/*     */ 
/* 105 */     synchronized (factory) {
/* 106 */       manager = (GatewayManager)factory.gatewayManagers.get(forum.getID());
/*     */     }
/*     */ 
/* 111 */     if (manager != null)
/* 112 */       manager.exportData(message);
/*     */   }
/*     */ 
/*     */   public GatewayManager(ForumFactory factory, Forum forum)
/*     */   {
/* 142 */     Log.debug("Creating a gateway manager for forum " + forum.getName());
/* 143 */     this.forumID = forum.getID();
/*     */ 
/* 145 */     this.context = ("gateway.forum" + forum.getID() + ".");
/*     */     try
/*     */     {
/* 149 */       String propValue = JiveGlobals.getJiveProperty(this.context + "importEnabled");
/* 150 */       if (propValue != null) {
/* 151 */         this.importEnabled = Boolean.valueOf(propValue).booleanValue();
/*     */       }
/* 153 */       propValue = JiveGlobals.getJiveProperty(this.context + "exportEnabled");
/* 154 */       if (propValue != null) {
/* 155 */         this.exportEnabled = Boolean.valueOf(propValue).booleanValue();
/*     */       }
/* 157 */       propValue = JiveGlobals.getJiveProperty(this.context + "importInterval");
/* 158 */       if (propValue != null) {
/* 159 */         this.importInterval = Integer.parseInt(propValue);
/*     */       }
/* 161 */       this.exportFooter = JiveGlobals.getJiveProperty(this.context + "exportFooter");
/* 162 */       propValue = JiveGlobals.getJiveProperty(this.context + "disableCutOffDate");
/* 163 */       if (propValue != null) {
/* 164 */         this.disableCutOffDate = Boolean.valueOf(propValue).booleanValue();
/*     */       }
/*     */     }
/*     */     catch (NumberFormatException nfe)
/*     */     {
/*     */     }
/* 170 */     Log.debug("GatewayManager for forum " + forum.getName() + ", import enabled: " + this.importEnabled);
/* 171 */     Log.debug("GatewayManager for forum " + forum.getName() + ", import interval: " + this.importInterval);
/*     */ 
/* 174 */     int gatewayCount = 0;
/* 175 */     String gCount = JiveGlobals.getJiveProperty(this.context + "gatewayCount");
/* 176 */     if (gCount != null) {
/*     */       try {
/* 178 */         gatewayCount = Integer.parseInt(gCount);
/*     */       }
/*     */       catch (NumberFormatException nfe) {
/* 181 */         return;
/*     */       }
/*     */     }
/*     */     else {
/* 185 */       Log.debug("GatewayManager for forum " + forum.getName() + ", no gateways defined");
/*     */ 
/* 188 */       return;
/*     */     }
/*     */ 
/* 192 */     String importTimestamp = JiveGlobals.getJiveProperty(this.context + "lastImport");
/* 193 */     if (importTimestamp != null) {
/*     */       try {
/* 195 */         this.lastImport = Long.parseLong(importTimestamp);
/*     */       }
/*     */       catch (NumberFormatException nfe)
/*     */       {
/*     */       }
/*     */     }
/* 201 */     Log.debug("GatewayManager for forum " + forum.getName() + ", last import: " + this.lastImport);
/*     */ 
/* 204 */     this.gateways = new Gateway[gatewayCount];
/*     */ 
/* 206 */     for (int i = 0; i < gatewayCount; i++) {
/*     */       try {
/* 208 */         String gatewayContext = this.context + "gateway" + i + ".";
/*     */ 
/* 210 */         String className = JiveGlobals.getJiveProperty(gatewayContext + "className");
/* 211 */         Log.debug("GatewayManager for forum " + forum.getName() + ", loading gateway: " + className);
/* 212 */         Class gClass = ClassUtils.forName(className);
/*     */         try
/*     */         {
/* 217 */           Class[] params = { ForumFactory.class, Forum.class };
/* 218 */           Constructor constructor = gClass.getConstructor(params);
/* 219 */           this.gateways[i] = ((Gateway)constructor.newInstance(new Object[] { factory, forum }));
/*     */         }
/*     */         catch (NoSuchMethodException e)
/*     */         {
/* 223 */           this.gateways[i] = ((Gateway)gClass.newInstance());
/*     */         }
/*     */ 
/* 227 */         String importContext = gatewayContext + "gatewayImporter.";
/* 228 */         List importPropNames = JiveGlobals.getJivePropertyNames(importContext + "properties");
/* 229 */         Map importGatewayProps = new HashMap();
/* 230 */         for (int j = 0; j < importPropNames.size(); j++)
/*     */         {
/* 233 */           String key = (String)importPropNames.get(j);
/* 234 */           key = key.indexOf(".") == -1 ? key : key.substring(key.lastIndexOf(".") + 1);
/* 235 */           Log.debug("loading property " + key + "=" + JiveGlobals.getJiveProperty((String)importPropNames.get(j)));
/*     */ 
/* 237 */           importGatewayProps.put(key, JiveGlobals.getJiveProperty((String)importPropNames.get(j)));
/*     */         }
/*     */ 
/* 240 */         GatewayImporter gatewayImporter = this.gateways[i].getGatewayImporter();
/* 241 */         BeanUtils.setProperties(gatewayImporter, importGatewayProps);
/*     */ 
/* 244 */         String exportContext = gatewayContext + "gatewayExporter.";
/*     */ 
/* 246 */         List exportPropNames = JiveGlobals.getJivePropertyNames(exportContext + "properties");
/* 247 */         Map exportGatewayProps = new HashMap();
/* 248 */         for (int j = 0; j < exportPropNames.size(); j++)
/*     */         {
/* 251 */           String key = (String)exportPropNames.get(j);
/* 252 */           key = key.indexOf(".") == -1 ? key : key.substring(key.lastIndexOf(".") + 1);
/* 253 */           Log.debug("loading property " + key + "=" + JiveGlobals.getJiveProperty((String)exportPropNames.get(j)));
/*     */ 
/* 255 */           exportGatewayProps.put(key, JiveGlobals.getJiveProperty((String)exportPropNames.get(j)));
/*     */         }
/*     */ 
/* 258 */         GatewayExporter gatewayExporter = this.gateways[i].getGatewayExporter();
/* 259 */         BeanUtils.setProperties(gatewayExporter, exportGatewayProps);
/*     */       }
/*     */       catch (Exception e) {
/* 262 */         Log.error("Error loading gateway " + i + " for context " + this.context, e);
/*     */       }
/*     */     }
/*     */ 
/* 266 */     if (this.exportEnabled)
/*     */     {
/* 269 */       Runnable task = new GatewayReExportTask(forum.getID());
/* 270 */       this.reexportTask = TaskEngine.scheduleTask(0, task, 300000L, 300000L);
/*     */     }
/*     */ 
/* 274 */     startImportTask();
/*     */   }
/*     */ 
/*     */   public boolean isImportEnabled()
/*     */   {
/* 285 */     return this.importEnabled;
/*     */   }
/*     */ 
/*     */   public void setImportEnabled(boolean importEnabled)
/*     */   {
/* 296 */     this.importEnabled = importEnabled;
/* 297 */     JiveGlobals.setJiveProperty(this.context + "importEnabled", "" + importEnabled);
/* 298 */     startImportTask();
/*     */   }
/*     */ 
/*     */   public boolean isExportEnabled()
/*     */   {
/* 310 */     return this.exportEnabled;
/*     */   }
/*     */ 
/*     */   public void setExportEnabled(boolean exportEnabled)
/*     */   {
/* 322 */     this.exportEnabled = exportEnabled;
/* 323 */     JiveGlobals.setJiveProperty(this.context + "exportEnabled", "" + exportEnabled);
/*     */ 
/* 326 */     if ((!exportEnabled) && (this.reexportTask != null)) {
/* 327 */       this.reexportTask.cancel();
/* 328 */       this.reexportTask = null;
/*     */     }
/* 331 */     else if ((exportEnabled) && (this.reexportTask == null)) {
/* 332 */       Runnable task = new GatewayReExportTask(this.forumID);
/* 333 */       this.reexportTask = TaskEngine.scheduleTask(0, task, 300000L, 300000L);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getExportFooter()
/*     */   {
/* 352 */     return this.exportFooter;
/*     */   }
/*     */ 
/*     */   public void setExportFooter(String exportFooter)
/*     */   {
/* 370 */     this.exportFooter = exportFooter;
/*     */ 
/* 372 */     if (exportFooter == null) {
/* 373 */       JiveGlobals.deleteJiveProperty(this.context + "exportFooter");
/*     */     }
/* 377 */     else if ((exportFooter != null) && (!"".equals(exportFooter.trim())))
/* 378 */       JiveGlobals.setJiveProperty(this.context + "exportFooter", exportFooter);
/*     */   }
/*     */ 
/*     */   public int getImportInterval()
/*     */   {
/* 390 */     return this.importInterval;
/*     */   }
/*     */ 
/*     */   public void setImportInterval(int importInterval)
/*     */   {
/* 398 */     this.importInterval = importInterval;
/* 399 */     JiveGlobals.setJiveProperty(this.context + "importInterval", "" + importInterval);
/* 400 */     startImportTask();
/*     */   }
/*     */ 
/*     */   public boolean isDisableCutOffDate()
/*     */   {
/* 409 */     return this.disableCutOffDate;
/*     */   }
/*     */ 
/*     */   public void setDisableCutOffDate(boolean disableCutOffDate)
/*     */   {
/* 420 */     this.disableCutOffDate = disableCutOffDate;
/* 421 */     JiveGlobals.setJiveProperty(this.context + "disableCutOffDate", "" + disableCutOffDate);
/*     */   }
/*     */ 
/*     */   public Gateway getGateway(int index)
/*     */   {
/* 430 */     if ((index < 0) || (index > getGatewayCount() - 1)) {
/* 431 */       throw new IllegalArgumentException("Index " + index + " is not valid.");
/*     */     }
/* 433 */     return this.gateways[index];
/*     */   }
/*     */ 
/*     */   public int getGatewayCount()
/*     */   {
/* 442 */     if (this.gateways == null) {
/* 443 */       return 0;
/*     */     }
/*     */ 
/* 446 */     return this.gateways.length;
/*     */   }
/*     */ 
/*     */   public void addGateway(Gateway gateway)
/*     */   {
/* 456 */     addGateway(gateway, getGatewayCount());
/*     */   }
/*     */ 
/*     */   public synchronized void addGateway(Gateway gateway, int index)
/*     */   {
/* 466 */     ArrayList newGateways = new ArrayList(getGatewayCount() + 1);
/* 467 */     for (int i = 0; i < getGatewayCount(); i++) {
/* 468 */       newGateways.add(this.gateways[i]);
/*     */     }
/* 470 */     newGateways.add(index, gateway);
/* 471 */     Gateway[] newArray = new Gateway[newGateways.size()];
/* 472 */     for (int i = 0; i < newArray.length; i++) {
/* 473 */       newArray[i] = ((Gateway)newGateways.get(i));
/*     */     }
/*     */ 
/* 476 */     this.gateways = newArray;
/* 477 */     saveGateways(true);
/*     */   }
/*     */ 
/*     */   public synchronized void removeGateway(int index)
/*     */   {
/* 486 */     ArrayList newGateways = new ArrayList(getGatewayCount());
/* 487 */     for (int i = 0; i < getGatewayCount(); i++) {
/* 488 */       newGateways.add(this.gateways[i]);
/*     */     }
/* 490 */     newGateways.remove(index);
/* 491 */     Gateway[] newArray = new Gateway[newGateways.size()];
/* 492 */     for (int i = 0; i < newArray.length; i++) {
/* 493 */       newArray[i] = ((Gateway)newGateways.get(i));
/*     */     }
/*     */ 
/* 496 */     this.gateways = newArray;
/* 497 */     saveGateways();
/*     */ 
/* 499 */     if ((getGatewayCount() == 0) && (this.timerTask != null)) {
/* 500 */       this.timerTask.cancel();
/* 501 */       this.timerTask = null;
/*     */     }
/*     */ 
/* 504 */     if (this.reexportTask != null) {
/* 505 */       this.reexportTask.cancel();
/* 506 */       this.reexportTask = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveGateways()
/*     */   {
/* 516 */     saveGateways(true);
/*     */   }
/*     */ 
/*     */   public synchronized void saveGateways(boolean restartImports)
/*     */   {
/* 526 */     JiveGlobals.deleteJiveProperty(this.context.substring(0, this.context.length() - 1));
/*     */ 
/* 529 */     Map propertyMap = new HashMap();
/*     */ 
/* 532 */     propertyMap.put(this.context + "importEnabled", "" + this.importEnabled);
/* 533 */     propertyMap.put(this.context + "importEnabled", "" + this.importEnabled);
/* 534 */     propertyMap.put(this.context + "exportEnabled", "" + this.exportEnabled);
/* 535 */     propertyMap.put(this.context + "importInterval", "" + this.importInterval);
/* 536 */     propertyMap.put(this.context + "disableCutOffDate", "" + this.disableCutOffDate);
/*     */ 
/* 538 */     if (this.exportFooter != null) {
/* 539 */       propertyMap.put(this.context + "exportFooter", this.exportFooter);
/*     */     }
/*     */ 
/* 543 */     if (getGatewayCount() > 0) {
/* 544 */       propertyMap.put(this.context + "gatewayCount", Integer.toString(getGatewayCount()));
/*     */ 
/* 547 */       if (this.importEnabled)
/* 548 */         propertyMap.put(this.context + "lastImport", String.valueOf(this.lastImport));
/*     */     }
/*     */     else
/*     */     {
/* 552 */       JiveGlobals.setJiveProperties(propertyMap);
/*     */       return;
/*     */     }
/*     */     Map exportGatewayProps;
/*     */     String exportContext;
/*     */     Iterator iter;
/* 557 */     for (int i = 0; i < getGatewayCount(); i++) {
/* 558 */       String gatewayContext = this.context + "gateway" + i + ".";
/*     */ 
/* 560 */       propertyMap.put(gatewayContext + "className", this.gateways[i].getClass().getName());
/*     */ 
/* 563 */       GatewayImporter gatewayImporter = this.gateways[i].getGatewayImporter();
/* 564 */       Map importGatewayProps = BeanUtils.getProperties(gatewayImporter);
/* 565 */       String importContext = gatewayContext + "gatewayImporter.";
/* 566 */       for (Iterator iter = importGatewayProps.keySet().iterator(); iter.hasNext(); ) {
/* 567 */         String name = (String)iter.next();
/* 568 */         String value = (String)importGatewayProps.get(name);
/* 569 */         if ((name != null) && (value != null)) {
/* 570 */           propertyMap.put(importContext + "properties." + name, value);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 575 */       GatewayExporter gatewayExporter = this.gateways[i].getGatewayExporter();
/* 576 */       exportGatewayProps = BeanUtils.getProperties(gatewayExporter);
/* 577 */       exportContext = gatewayContext + "gatewayExporter.";
/* 578 */       for (iter = exportGatewayProps.keySet().iterator(); iter.hasNext(); ) {
/* 579 */         String name = (String)iter.next();
/* 580 */         String value = (String)exportGatewayProps.get(name);
/* 581 */         if ((name != null) && (value != null)) {
/* 582 */           propertyMap.put(exportContext + "properties." + name, value);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 588 */     JiveGlobals.setJiveProperties(propertyMap);
/*     */ 
/* 591 */     if (restartImports)
/* 592 */       startImportTask();
/*     */   }
/*     */ 
/*     */   public void delete()
/*     */   {
/* 602 */     JiveGlobals.deleteJiveProperty(this.context.substring(0, this.context.length() - 1));
/*     */ 
/* 604 */     if (this.timerTask != null) {
/* 605 */       this.timerTask.cancel();
/* 606 */       this.timerTask = null;
/*     */     }
/* 608 */     if (this.reexportTask != null) {
/* 609 */       this.reexportTask.cancel();
/* 610 */       this.reexportTask = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getTranslatedFooter(ForumMessage message)
/*     */   {
/* 619 */     if (this.exportFooter == null) {
/* 620 */       return "";
/*     */     }
/*     */ 
/* 623 */     String result = this.exportFooter;
/* 624 */     ForumThread thread = message.getForumThread();
/* 625 */     Forum forum = thread.getForum();
/* 626 */     result = StringUtils.replace(result, "{threadID}", "" + thread.getID());
/* 627 */     result = StringUtils.replace(result, "{threadName}", thread.getName());
/* 628 */     result = StringUtils.replace(result, "{forumID}", "" + forum.getID());
/* 629 */     result = StringUtils.replace(result, "{forumName}", forum.getName());
/* 630 */     result = StringUtils.replace(result, "{messageID}", "" + message.getID());
/*     */ 
/* 632 */     String userID = "-1";
/* 633 */     String username = "Anonymous";
/* 634 */     String name = "Anonymous";
/* 635 */     if (!message.isAnonymous()) {
/* 636 */       User user = message.getUser();
/* 637 */       userID = Long.toString(user.getID());
/* 638 */       username = user.getUsername();
/* 639 */       name = user.getName();
/* 640 */       if (name == null) {
/* 641 */         name = username;
/*     */       }
/*     */ 
/*     */     }
/* 647 */     else if (message.getUnfilteredProperty("name") != null) {
/* 648 */       name = message.getUnfilteredProperty("name");
/*     */     }
/*     */ 
/* 651 */     result = StringUtils.replace(result, "{messageUserID}", userID);
/* 652 */     result = StringUtils.replace(result, "{messageUsername}", username);
/* 653 */     result = StringUtils.replace(result, "{messageName}", name);
/* 654 */     return "\n" + result;
/*     */   }
/*     */ 
/*     */   private void exportData(ForumMessage message)
/*     */   {
/* 663 */     if ((getGatewayCount() == 0) || (!this.exportEnabled) || (message == null)) {
/* 664 */       return;
/*     */     }
/*     */ 
/* 667 */     Date exportTime = new Date(System.currentTimeMillis() + 30000L);
/* 668 */     TaskEngine.scheduleTask(0, new GatewayExportTask(message), exportTime);
/*     */   }
/*     */ 
/*     */   private void startImportTask()
/*     */   {
/* 677 */     Log.debug("GatewayManager for forum " + this.forumID + ", startImportTask called");
/*     */ 
/* 679 */     if ((!this.importEnabled) && (this.timerTask != null)) {
/* 680 */       Log.debug("GatewayManager for forum " + this.forumID + ", import canceled");
/* 681 */       this.timerTask.cancel();
/* 682 */       return;
/*     */     }
/* 684 */     if (!this.importEnabled) {
/* 685 */       Log.debug("GatewayManager for forum " + this.forumID + ", import disabled");
/* 686 */       return;
/*     */     }
/*     */ 
/* 690 */     if (this.timerTask != null) {
/* 691 */       this.timerTask.cancel();
/*     */     }
/*     */ 
/* 694 */     Log.debug("GatewayManager for forum " + this.forumID + ", creating timer task for import");
/*     */ 
/* 696 */     this.timerTask = TaskEngine.scheduleTask(new GatewayImportTask(null), this.importInterval * 60000L, this.importInterval * 60000L);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  55 */     GatewayListener listener = new GatewayListener();
/*  56 */     ThreadEventDispatcher.getInstance().addListener(listener);
/*  57 */     MessageEventDispatcher.getInstance().addListener(listener);
/*     */   }
/*     */ 
/*     */   private class GatewayReExportTask
/*     */     implements Runnable
/*     */   {
/* 846 */     long forumID = -1L;
/*     */ 
/*     */     GatewayReExportTask(long forumID) {
/* 849 */       this.forumID = forumID;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 854 */       if (!GatewayManager.this.exportEnabled) {
/* 855 */         return;
/*     */       }
/*     */ 
/* 858 */       DbForum forum = null;
/*     */       try
/*     */       {
/* 861 */         forum = (DbForum)DbForumFactory.getInstance().getForum(this.forumID);
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 864 */         Log.error(e);
/* 865 */         return;
/*     */       }
/*     */ 
/* 869 */       ResultFilter filter = ResultFilter.createDefaultMessageFilter();
/* 870 */       filter.addProperty("jiveGatewayRetryExport", "true");
/* 871 */       Iterator messages = forum.getMessages(filter);
/* 872 */       while (messages.hasNext()) {
/* 873 */         DbForumMessage message = (DbForumMessage)messages.next();
/*     */ 
/* 875 */         for (int i = 0; i < GatewayManager.this.getGatewayCount(); i++)
/*     */           try {
/* 877 */             GatewayManager.this.gateways[i].exportData(message);
/* 878 */             message.deleteProperty("jiveGatewayRetryExport");
/*     */           }
/*     */           catch (GatewayException ge) {
/* 881 */             Log.error(ge);
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class GatewayExportTask
/*     */     implements Runnable
/*     */   {
/*     */     ForumMessage message;
/*     */ 
/*     */     GatewayExportTask(ForumMessage message)
/*     */     {
/* 821 */       this.message = message;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 826 */       if (!GatewayManager.this.exportEnabled) {
/* 827 */         return;
/*     */       }
/*     */ 
/* 830 */       for (int i = 0; i < GatewayManager.this.getGatewayCount(); i++)
/*     */         try {
/* 832 */           GatewayManager.this.gateways[i].exportData(this.message);
/*     */         }
/*     */         catch (GatewayException ge) {
/* 835 */           Log.error(ge);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class GatewayImportTask
/*     */     implements Runnable
/*     */   {
/*     */     private GatewayImportTask()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 755 */       if (GatewayManager.this.importLock) {
/* 756 */         return;
/*     */       }
/*     */ 
/* 759 */       GatewayManager.this.importLock = true;
/*     */       try {
/* 761 */         Log.debug("GatewayImportTask for forum " + GatewayManager.this.forumID + " running");
/*     */ 
/* 763 */         if ((!GatewayManager.this.importEnabled) || (GatewayManager.this.getGatewayCount() < 1)) {
/* 764 */           Log.debug("GatewayImportTask for forum " + GatewayManager.this.forumID + " returning because imports are disabled or no gateways");
/*     */         }
/* 769 */         else if (!CacheFactory.isSeniorClusterMember()) {
/* 770 */           Log.debug("GatewayImportTask for forum " + GatewayManager.this.forumID + " returning because task not running on the senior cluster member");
/*     */         }
/*     */         else
/*     */         {
/* 775 */           long now = System.currentTimeMillis();
/*     */ 
/* 782 */           Date cutoffDate = null;
/*     */ 
/* 784 */           if (!GatewayManager.this.disableCutOffDate) {
/* 785 */             cutoffDate = new Date(GatewayManager.this.lastImport - 86400000L);
/*     */           }
/*     */           else {
/* 788 */             cutoffDate = new Date(0L);
/*     */           }
/*     */ 
/* 791 */           for (int i = 0; i < GatewayManager.this.getGatewayCount(); i++) {
/*     */             try {
/* 793 */               Log.debug("GatewayImportTask for forum " + GatewayManager.this.forumID + " importing via gateway " + GatewayManager.this.gateways[i].getClass().toString());
/* 794 */               GatewayManager.this.gateways[i].importData(cutoffDate);
/*     */             }
/*     */             catch (Exception e) {
/* 797 */               Log.debug("GatewayImportTask for forum " + GatewayManager.this.forumID + " encountered an exception", e);
/* 798 */               Log.error(e);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 803 */           GatewayManager.this.lastImport = now;
/*     */ 
/* 805 */           JiveGlobals.setJiveProperty(GatewayManager.this.context + "lastImport", String.valueOf(GatewayManager.this.lastImport));
/*     */         }
/*     */       } finally {
/* 808 */         GatewayManager.this.importLock = false;
/*     */       }
/*     */     }
/*     */ 
/*     */     GatewayImportTask(GatewayManager.1 x1)
/*     */     {
/* 752 */       this();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.GatewayManager
 * JD-Core Version:    0.6.2
 */
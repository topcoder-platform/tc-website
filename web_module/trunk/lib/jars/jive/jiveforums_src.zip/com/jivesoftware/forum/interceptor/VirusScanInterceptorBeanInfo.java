/*    */ package com.jivesoftware.forum.interceptor;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class VirusScanInterceptorBeanInfo extends JiveBeanInfo
/*    */ {
/* 23 */   public static final String[] PROPERTY_NAMES = new String[0];
/*    */ 
/*    */   public String[] getPropertyNames()
/*    */   {
/* 32 */     return PROPERTY_NAMES;
/*    */   }
/*    */ 
/*    */   public Class getBeanClass() {
/* 36 */     return VirusScanInterceptor.class;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 40 */     return "VirusScanInterceptor";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.VirusScanInterceptorBeanInfo
 * JD-Core Version:    0.6.2
 */
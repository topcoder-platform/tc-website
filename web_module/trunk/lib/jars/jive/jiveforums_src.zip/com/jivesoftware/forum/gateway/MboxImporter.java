/*     */ package com.jivesoftware.forum.gateway;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import dog.mail.mbox.MboxStore;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.mail.Folder;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Store;
/*     */ import javax.mail.URLName;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ 
/*     */ public class MboxImporter
/*     */   implements GatewayImporter
/*     */ {
/*  34 */   private boolean isBusy = false;
/*     */   private MboxImportGateway gateway;
/*  36 */   private static Map forumLock = Collections.synchronizedMap(new HashMap());
/*     */ 
/*     */   public MboxImporter(ForumFactory factory, Forum forum)
/*     */   {
/*  42 */     this.gateway = new MboxImportGateway(factory, forum);
/*     */ 
/*  44 */     synchronized (forumLock) {
/*  45 */       if (forumLock.get(new Long(this.gateway.forumID)) == null)
/*  46 */         forumLock.put(new Long(this.gateway.forumID), new Long(this.gateway.forumID));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void importData(Date afterDate)
/*     */     throws GatewayException
/*     */   {
/*  56 */     synchronized (forumLock.get(new Long(this.gateway.forumID))) {
/*  57 */       this.gateway.importData(afterDate);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */     throws GatewayException
/*     */   {
/*  64 */     if (Log.isDebugEnabled()) {
/*  65 */       Log.debug("stoping mbox gateway run");
/*     */     }
/*  67 */     this.gateway.stop();
/*     */   }
/*     */ 
/*     */   public String getMboxFile()
/*     */   {
/*  73 */     return this.gateway.getMboxFile();
/*     */   }
/*     */ 
/*     */   public void setMboxFile(String file) {
/*  77 */     if (Log.isDebugEnabled()) {
/*  78 */       Log.debug("Setting mbox file to " + file);
/*     */     }
/*  80 */     this.gateway.setMboxFile(file);
/*     */   }
/*     */ 
/*     */   public boolean isDebugEnabled()
/*     */   {
/*  90 */     return this.gateway.isDebugEnabled();
/*     */   }
/*     */ 
/*     */   public void setDebugEnabled(boolean debugEnabled)
/*     */   {
/* 100 */     if (Log.isDebugEnabled()) {
/* 101 */       Log.debug("Setting JavaMail debugging: " + debugEnabled);
/*     */     }
/* 103 */     this.gateway.setDebugEnabled(debugEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isAttachmentsEnabled()
/*     */   {
/* 112 */     return this.gateway.isAttachmentsEnabled();
/*     */   }
/*     */ 
/*     */   public void setAttachmentsEnabled(boolean attachmentEnabled)
/*     */   {
/* 121 */     if (Log.isDebugEnabled()) {
/* 122 */       Log.debug("Setting attachments enabled: " + attachmentEnabled);
/*     */     }
/* 124 */     this.gateway.setAttachmentsEnabled(attachmentEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isEmailToUserMappingEnabled()
/*     */   {
/* 133 */     return this.gateway.isEmailToUserMappingEnabled();
/*     */   }
/*     */ 
/*     */   public void setEmailToUserMappingEnabled(boolean emailToUserMappingEnabled)
/*     */   {
/* 143 */     if (Log.isDebugEnabled()) {
/* 144 */       Log.debug("Setting email address - > user mapping enabled: " + emailToUserMappingEnabled);
/*     */     }
/* 146 */     this.gateway.setEmailToUserMappingEnabled(emailToUserMappingEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isImportHtmlEnabled()
/*     */   {
/* 155 */     return this.gateway.isImportHtmlEnabled();
/*     */   }
/*     */ 
/*     */   public void setImportHtmlEnabled(boolean importHtmlEnabled)
/*     */   {
/* 166 */     this.gateway.setImportHtmlEnabled(importHtmlEnabled);
/*     */   }
/*     */ 
/*     */   public String getDefaultCharacterSet()
/*     */   {
/* 177 */     return this.gateway.defaultCharacterSet;
/*     */   }
/*     */ 
/*     */   public void setDefaultCharacterSet(String defaultCharacterSet)
/*     */   {
/* 188 */     if (defaultCharacterSet != null) {
/* 189 */       if (Log.isDebugEnabled()) {
/* 190 */         Log.debug("Setting default character set to " + defaultCharacterSet);
/*     */       }
/* 192 */       this.gateway.setDefaultCharacterSet(defaultCharacterSet);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getReplyPrefixes()
/*     */   {
/* 205 */     String prefixes = "";
/* 206 */     String delim = "";
/* 207 */     for (int i = 0; i < this.gateway.replyPrefixes.length; i++) {
/* 208 */       prefixes = prefixes + delim;
/* 209 */       prefixes = prefixes + this.gateway.replyPrefixes[i];
/* 210 */       delim = ",";
/*     */     }
/*     */ 
/* 213 */     return prefixes;
/*     */   }
/*     */ 
/*     */   public void setReplyPrefixes(String replyPrefixes)
/*     */   {
/* 224 */     if (Log.isDebugEnabled()) {
/* 225 */       Log.debug("Setting reply prefixes to " + replyPrefixes);
/*     */     }
/*     */ 
/* 228 */     if (replyPrefixes == null) {
/* 229 */       return;
/*     */     }
/*     */ 
/* 232 */     StringTokenizer st = new StringTokenizer(replyPrefixes, ",");
/* 233 */     ArrayList prefixes = new ArrayList();
/* 234 */     while (st.hasMoreElements()) {
/* 235 */       String prefix = (String)st.nextElement();
/* 236 */       prefixes.add(prefix);
/*     */     }
/*     */ 
/* 239 */     this.gateway.replyPrefixes = ((String[])prefixes.toArray(new String[prefixes.size()]));
/*     */   }
/*     */ 
/*     */   public boolean isSubjectParentageCheckEnabled()
/*     */   {
/* 248 */     return this.gateway.subjectParentageCheckEnabled;
/*     */   }
/*     */ 
/*     */   public void setSubjectParentageCheckEnabled(boolean subjectParentageCheckEnabled)
/*     */   {
/* 258 */     if (Log.isDebugEnabled()) {
/* 259 */       Log.debug("Setting subject parentage check to " + subjectParentageCheckEnabled);
/*     */     }
/* 261 */     this.gateway.subjectParentageCheckEnabled = subjectParentageCheckEnabled;
/*     */   }
/*     */ 
/*     */   public int getPercentComplete()
/*     */   {
/* 267 */     if (!this.isBusy) {
/* 268 */       return 0;
/*     */     }
/*     */ 
/* 271 */     if ((this.gateway.totalMsgCount == -1) || (this.gateway.totalMsgCount == 0)) {
/* 272 */       return 0;
/*     */     }
/*     */ 
/* 275 */     int percentage = (int)(this.gateway.currentMsgCount / this.gateway.totalMsgCount * 100.0D);
/*     */ 
/* 277 */     return percentage < 0 ? 0 : percentage;
/*     */   }
/*     */ 
/*     */   public int getTotalMessageCount()
/*     */   {
/* 282 */     return this.gateway.totalMsgCount;
/*     */   }
/*     */ 
/*     */   public int getCurrentMessageCount() {
/* 286 */     return this.gateway.currentMsgCount;
/*     */   }
/*     */ 
/*     */   private class MboxImportGateway extends JavaMailGateway
/*     */   {
/* 293 */     protected int totalMsgCount = 0;
/* 294 */     protected int currentMsgCount = 1;
/* 295 */     private String mboxFile = null;
/*     */ 
/*     */     public MboxImportGateway(ForumFactory factory, Forum forum) {
/* 298 */       super(forum);
/* 299 */       setProtocol("mbox");
/*     */ 
/* 301 */       this.gatewayMessageId = "Email-Message-ID";
/* 302 */       this.gatewayParentId = "Email-Parent-ID";
/*     */     }
/*     */ 
/*     */     public String getMboxFile() {
/* 306 */       return this.mboxFile;
/*     */     }
/*     */ 
/*     */     public void setMboxFile(String file) {
/* 310 */       this.mboxFile = file;
/*     */     }
/*     */ 
/*     */     public synchronized void importData(Date afterDate) throws GatewayException
/*     */     {
/* 315 */       MboxImporter.this.isBusy = true;
/*     */ 
/* 318 */       if (this.mboxFile == null) {
/* 319 */         throw new GatewayException("Required properties are not all set.");
/*     */       }
/* 321 */       if (!new File(this.mboxFile).exists()) {
/* 322 */         throw new GatewayException("Mbox file can't be found.");
/*     */       }
/* 324 */       if (!new File(this.mboxFile).canRead()) {
/* 325 */         throw new GatewayException("Gateway is unable to read mbox file, permissions problem?");
/*     */       }
/*     */ 
/* 329 */       Store store = null;
/* 330 */       Folder folder = null;
/*     */       try
/*     */       {
/* 333 */         store = getStore(afterDate);
/*     */ 
/* 335 */         if ((folder = store.getFolder("INBOX")) == null) {
/* 336 */           throw new MessagingException("No folder found");
/*     */         }
/*     */ 
/* 339 */         if (Log.isDebugEnabled()) {
/* 340 */           Log.debug("Starting import of messages from mbox file " + this.mboxFile);
/*     */         }
/* 342 */         folder.open(1);
/* 343 */         retrieveMessages(folder, afterDate);
/*     */ 
/* 345 */         if (Log.isDebugEnabled())
/* 346 */           Log.debug("Finished import of messages from mbox file " + this.mboxFile);
/*     */       }
/*     */       catch (MessagingException e)
/*     */       {
/* 350 */         if (Log.isDebugEnabled()) {
/* 351 */           Log.debug("An exception occurred importing messages from mbox file " + this.mboxFile, e);
/*     */         }
/* 353 */         throw new GatewayException(e);
/*     */       } finally {
/*     */         try {
/* 356 */           folder.close(this.deleteEnabled); } catch (Exception e) {
/*     */         }try {
/* 358 */           store.close();
/*     */         } catch (Exception e) {
/*     */         }
/*     */       }
/* 362 */       MboxImporter.this.isBusy = false;
/* 363 */       this.parentMessageIDs.clear();
/*     */     }
/*     */ 
/*     */     protected Store getStore(Date afterDate)
/*     */       throws MessagingException
/*     */     {
/* 375 */       if (Log.isDebugEnabled()) {
/* 376 */         Log.debug("Retrieving javamail store object for mbox file " + this.mboxFile);
/*     */       }
/* 378 */       Properties props = new Properties();
/* 379 */       props.put("mail.store.protocol", "mbox");
/* 380 */       props.put("mail.mbox.fetchsize", "4096");
/* 381 */       props.put("mail.mbox.inbox", this.mboxFile);
/* 382 */       props.put("mail.mbox.attemptFallback", "false");
/*     */ 
/* 384 */       Session session = Session.getInstance(props, null);
/* 385 */       session.setDebug(this.debugEnabled);
/* 386 */       URLName url = new URLName("");
/* 387 */       Store store = new MboxStore(session, url);
/* 388 */       store.connect();
/*     */ 
/* 390 */       return store;
/*     */     }
/*     */ 
/*     */     protected void retrieveMessages(Folder folder, Date afterDate)
/*     */       throws MessagingException, GatewayException
/*     */     {
/* 405 */       if (Log.isDebugEnabled()) {
/* 406 */         Log.debug("Retrieving messages from mbox file " + this.mboxFile);
/*     */       }
/* 408 */       List messages = new ArrayList(Math.min(500, this.totalMsgCount));
/* 409 */       this.totalMsgCount = folder.getMessageCount();
/*     */ 
/* 411 */       if (Log.isDebugEnabled())
/* 412 */         Log.debug("Javamail believes there is " + this.totalMsgCount + " in mbox");
/*     */       try
/*     */       {
/* 415 */         while (this.currentMsgCount <= this.totalMsgCount) {
/* 416 */           if (Log.isDebugEnabled()) {
/* 417 */             Log.debug("Retrieving message #" + this.currentMsgCount);
/*     */           }
/*     */           try
/*     */           {
/* 421 */             if (this.stopFlag) {
/* 582 */               this.currentMsgCount += 1;
/*     */               return;
/* 425 */             }MimeMessage message = (MimeMessage)folder.getMessage(this.currentMsgCount - 1);
/*     */             try
/*     */             {
/* 438 */               if (Log.isDebugEnabled()) {
/* 439 */                 Log.debug("Attempting to retrieve messageID for message #" + this.currentMsgCount);
/*     */               }
/* 441 */               getMessageID(message);
/*     */             }
/*     */             catch (MessagingException e) {
/* 444 */               if (Log.isDebugEnabled()) {
/* 445 */                 Log.debug("MessageID not found for message #" + this.currentMsgCount);
/*     */               }
/*     */ 
/* 448 */               if (messages.size() > 0) {
/* 449 */                 if (Log.isDebugEnabled()) {
/* 450 */                   Log.debug("Appending what Javamail thinks is the current message to the previously retrieved message");
/*     */                 }
/* 452 */                 ForumMessage previous = (ForumMessage)messages.get(messages.size() - 1);
/*     */                 try {
/* 454 */                   Enumeration headers = message.getAllHeaderLines();
/* 455 */                   if (headers.hasMoreElements()) {
/* 456 */                     String h = (String)headers.nextElement();
/* 457 */                     previous.setBody(previous.getBody() + h + "\n" + message.getContent());
/*     */                   }
/*     */                   else {
/* 460 */                     previous.setBody(previous.getBody() + message.getContent());
/*     */                   }
/*     */                 }
/*     */                 catch (IOException e1) {
/* 464 */                   Log.error("Error reading message body");
/*     */                 }
/* 466 */                 messages.set(messages.size() - 1, previous);
/*     */ 
/* 582 */                 this.currentMsgCount += 1;
/* 583 */                 continue;
/*     */               }
/* 470 */               if (Log.isDebugEnabled()) {
/* 471 */                 Log.debug("First message being inserted has no message-id? Broken body?");
/*     */               }
/*     */ 
/* 474 */               Log.warn("First message being inserted has no message-id? Broken body?");
/* 475 */               if (this.debugEnabled) {
/* 476 */                 Log.warn("Content of message was:\n");
/*     */                 try {
/* 478 */                   Log.warn(message.getContent().toString());
/*     */                 }
/*     */                 catch (IOException e1)
/*     */                 {
/*     */                 }
/*     */                 catch (MessagingException e1)
/*     */                 {
/*     */                 }
/*     */ 
/*     */               }
/*     */ 
/* 582 */               this.currentMsgCount += 1;
/* 583 */             }continue;
/*     */ 
/* 487 */             if (Log.isDebugEnabled()) {
/* 488 */               Log.debug("Creating forum message object from message #" + this.currentMsgCount + " with messageID " + getMessageID(message));
/*     */             }
/*     */ 
/* 492 */             if ("true".equals(JiveGlobals.getJiveProperty("log.debug.extreme"))) {
/* 493 */               Log.debug("Message headers: ");
/* 494 */               Enumeration e = message.getAllHeaderLines();
/* 495 */               while (e.hasMoreElements()) {
/* 496 */                 Log.debug((String)e.nextElement());
/*     */               }
/*     */             }
/*     */ 
/* 500 */             ForumMessage forumMessage = parseMessage(message, afterDate);
/*     */ 
/* 502 */             if (forumMessage == null) {
/* 503 */               if (Log.isDebugEnabled()) {
/* 504 */                 Log.debug("Unable to parse message #" + this.currentMsgCount + ", skipping message");
/*     */               }
/*     */ 
/* 582 */               this.currentMsgCount += 1;
/*     */             }
/*     */             else
/*     */             {
/* 510 */               if (Log.isDebugEnabled()) {
/* 511 */                 Log.debug("Checking to see if message # " + this.currentMsgCount + " is already in the database");
/*     */               }
/*     */ 
/* 517 */               Forum forum = this.factory.getForum(this.forumID);
/* 518 */               String messageID = getMessageID(message);
/* 519 */               ForumMessage dbMessage = lookupMessageByID(forum, messageID, true);
/*     */ 
/* 521 */               if ((dbMessage != null) && (!"true".equals(dbMessage.getProperty("Jive-Created-Message"))))
/*     */               {
/* 524 */                 if (Log.isDebugEnabled()) {
/* 525 */                   Log.debug("Message #" + this.currentMsgCount + " is already in the database, skipping");
/*     */                 }
/*     */ 
/* 582 */                 this.currentMsgCount += 1;
/*     */               }
/*     */               else
/*     */               {
/* 531 */                 if (Log.isDebugEnabled()) {
/* 532 */                   Log.debug("Adding message #" + this.currentMsgCount + " to batch import list");
/*     */                 }
/* 534 */                 messages.add(forumMessage);
/*     */ 
/* 536 */                 if (Log.isDebugEnabled()) {
/* 537 */                   Log.debug("Checking to see if message # " + this.currentMsgCount + " has attachments");
/*     */                 }
/*     */ 
/* 540 */                 boolean hasAttachments = isMessageWithAttachments(message);
/*     */ 
/* 544 */                 if ((this.currentMsgCount % 500 == 0) || ((hasAttachments) && (this.attachmentsEnabled)))
/*     */                 {
/* 549 */                   ForumMessage last = (ForumMessage)messages.get(messages.size() - 1);
/* 550 */                   processMessagesAndImport(messages);
/* 551 */                   messages.add(last);
/*     */ 
/* 553 */                   if ((hasAttachments) && (this.attachmentsEnabled))
/*     */                   {
/* 557 */                     forumMessage = lookupMessageByID(forum, messageID, false);
/*     */ 
/* 559 */                     if (forumMessage != null) {
/* 560 */                       addAttachments(forumMessage, message);
/*     */                     }
/*     */                     else {
/* 563 */                       Log.error("Message which should be in the db wasn't: " + getMessageID(message));
/*     */                     }
/*     */ 
/*     */                   }
/*     */ 
/* 569 */                   if (this.currentMsgCount % 1000 == 0) {
/* 570 */                     folder.expunge();
/* 571 */                     System.gc();
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           } catch (MessagingException e) { if (Log.isDebugEnabled()) {
/* 577 */               Log.debug("An error occurred importing message #" + this.currentMsgCount, e);
/*     */             }
/* 579 */             Log.error(e);
/*     */           } finally
/*     */           {
/* 582 */             this.currentMsgCount += 1;
/*     */           }
/*     */         }
/*     */ 
/* 586 */         if (Log.isDebugEnabled()) {
/* 587 */           Log.debug("Importing remaining messages in batch import list into Jive");
/*     */         }
/*     */ 
/* 590 */         processMessagesAndImport(messages);
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 593 */         throw new GatewayException(e);
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 596 */         throw new GatewayException(e);
/*     */       }
/*     */       finally {
/* 599 */         if (!messages.isEmpty())
/* 600 */           Log.error("Unable to import " + messages.size() + " messages because of errors.");
/*     */       }
/*     */     }
/*     */ 
/*     */     protected String getFromName(Message message) throws MessagingException
/*     */     {
/* 606 */       String[] fromAddresses = message.getHeader("From");
/*     */ 
/* 608 */       if (fromAddresses == null) {
/* 609 */         if (Log.isDebugEnabled()) {
/* 610 */           Log.debug("No From name found for message with subject " + message.getSubject() + ", returning empty string");
/*     */         }
/*     */ 
/* 613 */         Log.warn("No From name found for message with subject " + message.getSubject() + ", returning empty string");
/*     */ 
/* 615 */         return "";
/*     */       }
/*     */ 
/* 618 */       String[] fromHeader = message.getHeader("From");
/* 619 */       if (fromHeader != null) {
/* 620 */         return getFromName(fromHeader[0]);
/*     */       }
/*     */ 
/* 623 */       return "";
/*     */     }
/*     */ 
/*     */     protected String getFromEmail(Message message)
/*     */       throws MessagingException
/*     */     {
/* 629 */       if (Log.isDebugEnabled()) {
/* 630 */         Log.debug("Retrieve from address for message with subject " + message.getSubject());
/*     */       }
/* 632 */       String[] fromAddresses = message.getHeader("From");
/*     */ 
/* 634 */       if (fromAddresses == null) {
/* 635 */         if (Log.isDebugEnabled()) {
/* 636 */           Log.warn("No From address found for message with subject " + message.getSubject() + ", returning empty string");
/*     */         }
/*     */ 
/* 639 */         Log.warn("No From address found for message with subject " + message.getSubject() + ", returning empty string");
/*     */ 
/* 641 */         return "";
/*     */       }
/*     */ 
/* 644 */       String[] fromHeader = message.getHeader("From");
/* 645 */       if (fromHeader != null) {
/* 646 */         return getFromEmail(fromHeader[0]);
/*     */       }
/*     */ 
/* 649 */       return "";
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.MboxImporter
 * JD-Core Version:    0.6.2
 */
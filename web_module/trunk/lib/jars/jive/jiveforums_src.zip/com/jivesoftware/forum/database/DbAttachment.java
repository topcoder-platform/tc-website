/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.database.ConnectionManager.DatabaseType;
/*     */ import com.jivesoftware.base.database.sequence.SequenceManager;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.AttachmentException;
/*     */ import com.jivesoftware.forum.AttachmentManager;
/*     */ import com.jivesoftware.forum.AttachmentNotFoundException;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheSizes;
/*     */ import com.jivesoftware.util.Cacheable;
/*     */ import com.jivesoftware.util.ClassUtils;
/*     */ import com.jivesoftware.util.ExtendedPropertyUtils;
/*     */ import com.jivesoftware.util.ExternalizableLiteUtil;
/*     */ import com.tangosol.io.ExternalizableLite;
/*     */ import com.tangosol.util.ExternalizableHelper;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DbAttachment
/*     */   implements Attachment, Cacheable, ExternalizableLite
/*     */ {
/*     */   private static final String LOAD_ATTACHMENT = "SELECT objectType, objectID, fileName, fileSize, contentType, creationDate, modificationDate FROM jiveAttachment WHERE attachmentID=?";
/*     */   private static final String INSERT_ATTACHMENT = "INSERT INTO jiveAttachment (attachmentID, objectType, objectID, fileName, fileSize, contentType, creationDate, modificationDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
/*     */   protected static final String INSERT_ATTACHMENT_DATA = "INSERT INTO jiveAttachData (attachmentID, attachmentData) VALUES (?, ?)";
/*     */   protected static final String INSERT_ATTACHMENT_DATA_ORACLE = "INSERT INTO jiveAttachData (attachmentID, attachmentData) VALUES (?, EMPTY_BLOB())";
/*     */   static final String LOAD_ATTACHMENT_DATA = "SELECT attachmentData FROM jiveAttachData WHERE attachmentID=?";
/*     */   private static final String DELETE_ATTACHMENT = "DELETE FROM jiveAttachment WHERE attachmentID=?";
/*     */   private static final String DELETE_ATTACHMENT_DATA = "DELETE FROM jiveAttachData WHERE attachmentID=?";
/*     */   private static final String SET_OBJECT_ID = "UPDATE jiveAttachment SET objectID=? WHERE attachmentID=?";
/*     */   private static final String SET_NAME = "UPDATE jiveAttachment SET fileName=?, modificationDate=? WHERE attachmentID=?";
/*     */   private static final String LOAD_PROPERTIES = "SELECT name, propValue FROM jiveAttachmentProp WHERE attachmentID=?";
/*     */   private static final String DELETE_PROPERTY = "DELETE FROM jiveAttachmentProp WHERE attachmentID=? AND name=?";
/*     */   private static final String INSERT_PROPERTY = "INSERT INTO jiveAttachmentProp (attachmentID, name, propValue) VALUES (?, ?, ?)";
/*     */   private static final String UPDATE_PROPERTY = "UPDATE jiveAttachmentProp SET propValue=? WHERE name=? AND attachmentID=?";
/*  70 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */ 
/*  72 */   private long id = -1L;
/*     */   private int objectType;
/*     */   private long objectID;
/*  75 */   private String name = null;
/*     */   private int size;
/*  77 */   private String contentType = null;
/*     */   private Date creationDate;
/*     */   private Date modificationDate;
/*     */   private Map properties;
/*     */ 
/*     */   public DbAttachment(long attachmentID)
/*     */     throws AttachmentNotFoundException
/*     */   {
/*  90 */     this.id = attachmentID;
/*     */     try
/*     */     {
/*  93 */       if (!FACTORY.getAttachmentManager().isDatabaseModeEnabled()) {
/*  94 */         File attachmentFile = new File(DbAttachmentManager.getAttachmentDir(), attachmentID + ".bin");
/*     */ 
/*  96 */         if (!attachmentFile.exists()) {
/*  97 */           throw new AttachmentNotFoundException("The attachment data was not found on the filesystem.");
/*     */         }
/*     */ 
/* 100 */         attachmentFile = null;
/*     */       }
/* 102 */       loadInfoFromDb();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 105 */       Log.error(sqle);
/* 106 */       throw new AttachmentNotFoundException("Exception loading attachment information from database.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public DbAttachment(int objectType, long objectID, String name, String contentType, InputStream data)
/*     */     throws AttachmentException
/*     */   {
/* 114 */     this.objectType = objectType;
/* 115 */     this.objectID = objectID;
/*     */ 
/* 117 */     if (!FACTORY.getAttachmentManager().isValidType(contentType)) {
/* 118 */       throw new AttachmentException(2, name);
/*     */     }
/*     */ 
/* 121 */     this.id = SequenceManager.nextID(13);
/*     */ 
/* 123 */     this.name = name;
/* 124 */     this.contentType = contentType;
/* 125 */     this.creationDate = new Date(System.currentTimeMillis());
/* 126 */     this.modificationDate = new Date(this.creationDate.getTime());
/*     */     try {
/* 128 */       insert(data);
/*     */     }
/*     */     catch (IOException ioe) {
/* 131 */       throw new AttachmentException(3, ioe, name);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DbAttachment()
/*     */   {
/*     */   }
/*     */ 
/*     */   public long getID()
/*     */   {
/* 145 */     return this.id;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 149 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) throws UnauthorizedException {
/* 153 */     if ((name == null) || ("".equals(name.trim()))) {
/* 154 */       throw new IllegalArgumentException("Cannot set name with empty or null value.");
/*     */     }
/*     */ 
/* 157 */     this.name = name;
/* 158 */     this.modificationDate = new Date();
/*     */ 
/* 160 */     Connection con = null;
/* 161 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 164 */       con = ConnectionManager.getConnection();
/* 165 */       pstmt = con.prepareStatement("UPDATE jiveAttachment SET fileName=?, modificationDate=? WHERE attachmentID=?");
/* 166 */       pstmt.setString(1, name);
/* 167 */       pstmt.setLong(2, this.modificationDate.getTime());
/* 168 */       pstmt.setLong(3, this.id);
/* 169 */       pstmt.execute();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 172 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 175 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 179 */     FACTORY.cacheManager.attachmentCache.put(new Long(this.id), this);
/*     */   }
/*     */ 
/*     */   public long getSize() {
/* 183 */     return this.size;
/*     */   }
/*     */ 
/*     */   public String getContentType() {
/* 187 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   public Date getCreationDate() {
/* 191 */     return this.creationDate;
/*     */   }
/*     */ 
/*     */   public Date getModificationDate() {
/* 195 */     return this.modificationDate;
/*     */   }
/*     */ 
/*     */   public InputStream getData() throws IOException {
/* 199 */     File attachmentFile = new File(DbAttachmentManager.getAttachmentDir(), this.id + ".bin");
/* 200 */     if (!attachmentFile.exists()) {
/*     */       try {
/* 202 */         loadDataFromDb();
/*     */       }
/*     */       catch (Exception e) {
/* 205 */         Log.error(e);
/*     */       }
/*     */     }
/* 208 */     BufferedInputStream data = new BufferedInputStream(new FileInputStream(attachmentFile));
/*     */ 
/* 210 */     return data;
/*     */   }
/*     */ 
/*     */   public String getProperty(String name) {
/* 214 */     if (this.properties == null) {
/* 215 */       loadPropertiesFromDb();
/*     */     }
/* 217 */     return (String)this.properties.get(name);
/*     */   }
/*     */ 
/*     */   public Collection getProperties(String parentName) {
/* 221 */     Object[] keys = this.properties.keySet().toArray();
/* 222 */     ArrayList results = new ArrayList();
/* 223 */     int i = 0; for (int n = keys.length; i < n; i++) {
/* 224 */       String key = (String)keys[i];
/* 225 */       if ((key.startsWith(parentName)) && 
/* 226 */         (!key.equals(parentName)))
/*     */       {
/* 229 */         if (key.substring(parentName.length()).lastIndexOf(".") == 0) {
/* 230 */           results.add(this.properties.get(key));
/*     */         }
/*     */       }
/*     */     }
/* 234 */     return Collections.unmodifiableCollection(results);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value) {
/* 238 */     if (this.properties == null) {
/* 239 */       loadPropertiesFromDb();
/*     */     }
/*     */ 
/* 242 */     value = ExtendedPropertyUtils.validateExtendedProperty(name, value);
/*     */ 
/* 244 */     if (this.properties.containsKey(name))
/*     */     {
/* 247 */       if (!value.equals(this.properties.get(name))) {
/* 248 */         this.properties.put(name, value);
/* 249 */         updatePropertyInDb(name, value);
/*     */ 
/* 251 */         FACTORY.cacheManager.attachmentCache.put(new Long(this.id), this);
/*     */       }
/*     */     } else {
/* 254 */       this.properties.put(name, value);
/* 255 */       insertPropertyIntoDb(name, value);
/*     */ 
/* 257 */       FACTORY.cacheManager.attachmentCache.put(new Long(this.id), this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) {
/* 262 */     if (this.properties == null) {
/* 263 */       loadPropertiesFromDb();
/*     */     }
/*     */ 
/* 266 */     if (this.properties.containsKey(name)) {
/* 267 */       this.properties.remove(name);
/* 268 */       deletePropertyFromDb(name);
/*     */ 
/* 270 */       FACTORY.cacheManager.attachmentCache.put(new Long(this.id), this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames() {
/* 275 */     if (this.properties == null) {
/* 276 */       loadPropertiesFromDb();
/*     */     }
/* 278 */     return Collections.unmodifiableSet(this.properties.keySet()).iterator();
/*     */   }
/*     */ 
/*     */   public int getCachedSize()
/*     */   {
/* 286 */     int size = 0;
/* 287 */     size += CacheSizes.sizeOfObject();
/* 288 */     size += CacheSizes.sizeOfObject();
/* 289 */     size += CacheSizes.sizeOfInt();
/* 290 */     size += CacheSizes.sizeOfLong();
/* 291 */     size += CacheSizes.sizeOfString(this.name);
/* 292 */     size += CacheSizes.sizeOfString(this.contentType);
/* 293 */     size += CacheSizes.sizeOfDate();
/* 294 */     size += CacheSizes.sizeOfDate();
/* 295 */     size += CacheSizes.sizeOfMap(this.properties);
/* 296 */     return size;
/*     */   }
/*     */ 
/*     */   public void readExternal(DataInput in) throws IOException {
/* 300 */     this.id = ExternalizableHelper.readLong(in);
/* 301 */     this.objectType = ExternalizableHelper.readInt(in);
/* 302 */     this.objectID = ExternalizableHelper.readLong(in);
/* 303 */     this.name = ExternalizableHelper.readSafeUTF(in);
/* 304 */     this.size = ExternalizableHelper.readInt(in);
/* 305 */     this.contentType = ExternalizableHelper.readSafeUTF(in);
/* 306 */     this.creationDate = new Date(in.readLong());
/* 307 */     this.modificationDate = new Date(in.readLong());
/* 308 */     this.properties = ExternalizableLiteUtil.readStringMap(in);
/*     */   }
/*     */ 
/*     */   public void writeExternal(DataOutput out) throws IOException {
/* 312 */     ExternalizableHelper.writeLong(out, this.id);
/* 313 */     ExternalizableHelper.writeInt(out, this.objectType);
/* 314 */     ExternalizableHelper.writeLong(out, this.objectID);
/* 315 */     ExternalizableHelper.writeSafeUTF(out, this.name);
/* 316 */     ExternalizableHelper.writeInt(out, this.size);
/* 317 */     ExternalizableHelper.writeSafeUTF(out, this.contentType);
/* 318 */     out.writeLong(this.creationDate.getTime());
/* 319 */     out.writeLong(this.modificationDate.getTime());
/* 320 */     ExternalizableLiteUtil.writeStringMap(out, this.properties);
/*     */   }
/*     */ 
/*     */   public int getObjectType()
/*     */   {
/* 329 */     return this.objectType;
/*     */   }
/*     */ 
/*     */   public long getObjectID()
/*     */   {
/* 339 */     return this.objectID;
/*     */   }
/*     */ 
/*     */   public static void setObjectID(long attachmentID, long objectID, Connection con)
/*     */     throws SQLException
/*     */   {
/* 350 */     DbAttachment attachment = (DbAttachment)FACTORY.cacheManager.attachmentCache.get(new Long(attachmentID));
/*     */ 
/* 353 */     if (attachment != null) {
/* 354 */       attachment.objectID = objectID;
/*     */     }
/*     */ 
/* 357 */     PreparedStatement pstmt = null;
/*     */     try {
/* 359 */       pstmt = con.prepareStatement("UPDATE jiveAttachment SET objectID=? WHERE attachmentID=?");
/* 360 */       pstmt.setLong(1, objectID);
/* 361 */       pstmt.setLong(2, attachmentID);
/* 362 */       pstmt.execute();
/*     */     }
/*     */     finally {
/* 365 */       ConnectionManager.closePreparedStatement(pstmt);
/*     */     }
/*     */ 
/* 368 */     if (attachment != null)
/* 369 */       FACTORY.cacheManager.attachmentCache.put(new Long(attachmentID), attachment);
/*     */   }
/*     */ 
/*     */   protected void delete(Connection con)
/*     */     throws SQLException
/*     */   {
/* 378 */     PreparedStatement pstmt = null;
/*     */     try {
/* 380 */       if (FACTORY.getAttachmentManager().isDatabaseModeEnabled()) {
/* 381 */         pstmt = con.prepareStatement("DELETE FROM jiveAttachData WHERE attachmentID=?");
/* 382 */         pstmt.setLong(1, this.id);
/* 383 */         pstmt.execute();
/* 384 */         pstmt.close();
/*     */       }
/* 386 */       pstmt = con.prepareStatement("DELETE FROM jiveAttachment WHERE attachmentID=?");
/* 387 */       pstmt.setLong(1, this.id);
/* 388 */       pstmt.execute();
/*     */     }
/*     */     finally {
/* 391 */       ConnectionManager.closePreparedStatement(pstmt);
/*     */     }
/*     */ 
/* 394 */     File attachmentFile = new File(DbAttachmentManager.getAttachmentDir(), this.id + ".bin");
/* 395 */     if (attachmentFile.exists())
/*     */     {
/* 397 */       DbAttachmentManager.getInstance().addToAttachDirSize(-attachmentFile.length());
/* 398 */       attachmentFile.delete();
/* 399 */       attachmentFile = null;
/*     */     }
/*     */ 
/* 403 */     File attachmentTextFile = new File(DbAttachmentManager.getAttachmentDir(), this.id + ".txt");
/* 404 */     if (attachmentTextFile.exists()) {
/* 405 */       attachmentTextFile.delete();
/* 406 */       attachmentTextFile = null;
/*     */     }
/*     */ 
/* 410 */     FACTORY.cacheManager.attachmentCache.remove(new Long(this.id));
/*     */   }
/*     */ 
/*     */   private void insert(InputStream data)
/*     */     throws IOException, AttachmentException
/*     */   {
/* 422 */     File attachmentFile = new File(DbAttachmentManager.getAttachmentDir(), this.id + ".bin");
/* 423 */     if (attachmentFile.exists()) {
/* 424 */       Log.warn("Warning, attachment file with id " + this.id + " already exists; overwriting.");
/* 425 */       attachmentFile.delete(); } OutputStream out = new BufferedOutputStream(new FileOutputStream(attachmentFile));
/* 428 */     byte[] buf = new byte[1024];
/* 429 */     int fileSize = 0;
/* 430 */     int maxAttachmentSize = FACTORY.getAttachmentManager().getMaxAttachmentSize() * 1024;
/*     */     int len;
/*     */     try { while ((len = data.read(buf)) >= 0) {
/* 433 */         fileSize += len;
/*     */ 
/* 436 */         if (fileSize > maxAttachmentSize) {
/* 437 */           out.close();
/* 438 */           out = null;
/* 439 */           attachmentFile.delete();
/* 440 */           throw new AttachmentException(0, this.name);
/*     */         }
/* 442 */         out.write(buf, 0, len);
/*     */       }
/*     */     } finally
/*     */     {
/* 446 */       if (out != null) {
/* 447 */         out.close();
/*     */       }
/*     */     }
/*     */ 
/* 451 */     this.size = fileSize;
/*     */ 
/* 453 */     DbAttachmentManager.getInstance().addToAttachDirSize(this.size);
/*     */ 
/* 455 */     Connection con = null;
/* 456 */     PreparedStatement pstmt = null;
/* 457 */     boolean abortTransaction = false;
/*     */     try {
/* 459 */       con = ConnectionManager.getTransactionConnection();
/*     */ 
/* 462 */       pstmt = con.prepareStatement("INSERT INTO jiveAttachment (attachmentID, objectType, objectID, fileName, fileSize, contentType, creationDate, modificationDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
/* 463 */       pstmt.setLong(1, this.id);
/* 464 */       pstmt.setInt(2, this.objectType);
/* 465 */       if (this.objectID == -1L) {
/* 466 */         pstmt.setNull(3, 2);
/*     */       }
/*     */       else {
/* 469 */         pstmt.setLong(3, this.objectID);
/*     */       }
/* 471 */       pstmt.setString(4, this.name);
/* 472 */       pstmt.setInt(5, this.size);
/* 473 */       pstmt.setString(6, this.contentType);
/* 474 */       pstmt.setLong(7, this.creationDate.getTime());
/* 475 */       pstmt.setLong(8, this.modificationDate.getTime());
/* 476 */       pstmt.execute();
/* 477 */       pstmt.close();
/*     */ 
/* 480 */       if (FACTORY.getAttachmentManager().isDatabaseModeEnabled())
/*     */       {
/* 482 */         boolean isOracle = ConnectionManager.getDatabaseType() == ConnectionManager.DatabaseType.ORACLE;
/*     */ 
/* 484 */         if (isOracle) {
/*     */           try
/*     */           {
/* 487 */             ClassUtils.forName("oracle.sql.BLOB");
/*     */           }
/*     */           catch (ClassNotFoundException cnfe)
/*     */           {
/* 491 */             isOracle = false;
/*     */           }
/*     */         }
/*     */ 
/* 495 */         if (isOracle) {
/* 496 */           pstmt = con.prepareStatement("INSERT INTO jiveAttachData (attachmentID, attachmentData) VALUES (?, EMPTY_BLOB())");
/* 497 */           pstmt.setLong(1, this.id);
/* 498 */           pstmt.execute();
/* 499 */           pstmt.close();
/* 500 */           pstmt = con.prepareStatement("SELECT attachmentData FROM jiveAttachData WHERE attachmentID=?");
/* 501 */           pstmt.setLong(1, this.id);
/* 502 */           ResultSet rs = pstmt.executeQuery();
/* 503 */           rs.next();
/* 504 */           Object blobObject = rs.getBlob(1);
/* 505 */           InputStream in = null;
/*     */           try
/*     */           {
/* 508 */             out = null;
/* 509 */             int bufSize = 0;
/*     */             try
/*     */             {
/* 513 */               Class blobClass = ClassUtils.forName("oracle.sql.BLOB");
/*     */ 
/* 515 */               out = (OutputStream)blobClass.getMethod("getBinaryOutputStream", (Class[])null).invoke(blobObject, (Object[])null);
/*     */ 
/* 518 */               bufSize = ((Integer)blobClass.getMethod("getBufferSize", (Class[])null).invoke(blobObject, (Object[])null)).intValue();
/*     */             }
/*     */             catch (Exception e)
/*     */             {
/* 522 */               Log.error("Failed to load Oracle JDK 1.4 JDBC drivers.", e);
/*     */             }
/*     */ 
/* 525 */             buf = new byte[bufSize];
/* 526 */             in = new BufferedInputStream(new FileInputStream(attachmentFile));
/*     */ 
/* 528 */             len = 0;
/* 529 */             while ((len = in.read(buf)) >= 0) {
/* 530 */               fileSize += len;
/* 531 */               out.write(buf, 0, len);
/*     */             }
/* 533 */             rs.close();
/*     */           }
/*     */           finally {
/* 536 */             if (in != null) try { in.close(); } catch (Exception e) {
/*     */               } if (out != null) try { out.close(); } catch (Exception e) {  }
/*     */  
/*     */           }
/* 539 */           pstmt.close();
/*     */         }
/*     */         else
/*     */         {
/* 543 */           InputStream in = null;
/*     */           try {
/* 545 */             in = new BufferedInputStream(new FileInputStream(attachmentFile));
/*     */ 
/* 547 */             pstmt = con.prepareStatement("INSERT INTO jiveAttachData (attachmentID, attachmentData) VALUES (?, ?)");
/* 548 */             pstmt.setLong(1, this.id);
/* 549 */             pstmt.setBinaryStream(2, in, this.size);
/* 550 */             pstmt.execute();
/* 551 */             pstmt.close();
/*     */           }
/*     */           finally {
/* 554 */             if (in != null) try { in.close(); } catch (Exception e) {
/*     */               } 
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 560 */     catch (SQLException sqle) { abortTransaction = true;
/* 561 */       Log.error(sqle);
/*     */     } finally
/*     */     {
/* 564 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadInfoFromDb() throws SQLException, AttachmentNotFoundException {
/* 569 */     Connection con = null;
/* 570 */     PreparedStatement pstmt = null;
/*     */     try {
/* 572 */       con = ConnectionManager.getConnection();
/* 573 */       pstmt = con.prepareStatement("SELECT objectType, objectID, fileName, fileSize, contentType, creationDate, modificationDate FROM jiveAttachment WHERE attachmentID=?");
/* 574 */       pstmt.setLong(1, this.id);
/* 575 */       ResultSet rs = pstmt.executeQuery();
/* 576 */       if (!rs.next()) {
/* 577 */         throw new AttachmentNotFoundException("Attachment " + this.id + " not found in the database.");
/*     */       }
/*     */ 
/* 580 */       this.objectType = rs.getInt(1);
/* 581 */       this.objectID = rs.getLong(2);
/* 582 */       if (rs.wasNull()) {
/* 583 */         this.objectID = -1L;
/*     */       }
/* 585 */       this.name = rs.getString(3);
/* 586 */       this.size = rs.getInt(4);
/* 587 */       this.contentType = rs.getString(5);
/* 588 */       this.creationDate = new Date(rs.getLong(6));
/* 589 */       this.modificationDate = new Date(rs.getLong(7));
/* 590 */       rs.close();
/*     */     }
/*     */     finally {
/* 593 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadDataFromDb() throws SQLException, AttachmentNotFoundException {
/* 598 */     Connection con = null;
/* 599 */     PreparedStatement pstmt = null;
/*     */     try {
/* 601 */       con = ConnectionManager.getConnection();
/* 602 */       pstmt = con.prepareStatement("SELECT attachmentData FROM jiveAttachData WHERE attachmentID=?");
/* 603 */       pstmt.setLong(1, this.id);
/* 604 */       ResultSet rs = pstmt.executeQuery();
/* 605 */       if (!rs.next()) {
/* 606 */         throw new AttachmentNotFoundException("Attachment " + this.id + " not found in the database.");
/*     */       }
/*     */ 
/* 610 */       InputStream in = null;
/* 611 */       OutputStream out = null;
/*     */       try {
/* 613 */         in = ConnectionManager.getBlob(rs, 1);
/* 614 */         out = new BufferedOutputStream(new FileOutputStream(new File(DbAttachmentManager.getAttachmentDir(), this.id + ".bin")));
/*     */ 
/* 616 */         byte[] buf = new byte[1024];
/*     */         int len;
/* 618 */         while ((len = in.read(buf)) >= 0) {
/* 619 */           out.write(buf, 0, len);
/*     */         }
/* 621 */         out.flush();
/*     */       }
/*     */       catch (IOException ioe) {
/* 624 */         Log.error(ioe);
/*     */       } finally {
/*     */         try {
/* 627 */           if (in != null) in.close();  } catch (Exception e) {
/*     */         }try { if (out != null) out.close();  } catch (Exception e) {  }
/*     */ 
/*     */       }
/* 630 */       rs.close();
/*     */     }
/*     */     finally {
/* 633 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void loadPropertiesFromDb()
/*     */   {
/* 641 */     this.properties = new Hashtable();
/* 642 */     Connection con = null;
/* 643 */     PreparedStatement pstmt = null;
/*     */     try {
/* 645 */       con = ConnectionManager.getConnection();
/* 646 */       pstmt = con.prepareStatement("SELECT name, propValue FROM jiveAttachmentProp WHERE attachmentID=?");
/* 647 */       pstmt.setLong(1, this.id);
/* 648 */       ResultSet rs = pstmt.executeQuery();
/* 649 */       while (rs.next()) {
/* 650 */         String name = rs.getString(1);
/* 651 */         String value = rs.getString(2);
/* 652 */         this.properties.put(name, value);
/*     */       }
/* 654 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 657 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 660 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void insertPropertyIntoDb(String name, String value)
/*     */   {
/* 668 */     Connection con = null;
/* 669 */     PreparedStatement pstmt = null;
/* 670 */     boolean abortTransaction = false;
/*     */     try {
/* 672 */       con = ConnectionManager.getTransactionConnection();
/* 673 */       pstmt = con.prepareStatement("INSERT INTO jiveAttachmentProp (attachmentID, name, propValue) VALUES (?, ?, ?)");
/* 674 */       pstmt.setLong(1, this.id);
/* 675 */       pstmt.setString(2, name);
/* 676 */       pstmt.setString(3, value);
/* 677 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 680 */       Log.error(sqle);
/* 681 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 684 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updatePropertyInDb(String name, String value)
/*     */   {
/* 692 */     Connection con = null;
/* 693 */     PreparedStatement pstmt = null;
/* 694 */     boolean abortTransaction = false;
/*     */     try {
/* 696 */       con = ConnectionManager.getTransactionConnection();
/* 697 */       pstmt = con.prepareStatement("UPDATE jiveAttachmentProp SET propValue=? WHERE name=? AND attachmentID=?");
/* 698 */       pstmt.setString(1, value);
/* 699 */       pstmt.setString(2, name);
/* 700 */       pstmt.setLong(3, this.id);
/* 701 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 704 */       Log.error(sqle);
/* 705 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 708 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void deletePropertyFromDb(String name)
/*     */   {
/* 716 */     Connection con = null;
/* 717 */     PreparedStatement pstmt = null;
/* 718 */     boolean abortTransaction = false;
/*     */     try {
/* 720 */       con = ConnectionManager.getTransactionConnection();
/* 721 */       pstmt = con.prepareStatement("DELETE FROM jiveAttachmentProp WHERE attachmentID=? AND name=?");
/* 722 */       pstmt.setLong(1, this.id);
/* 723 */       pstmt.setString(2, name);
/* 724 */       pstmt.execute();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 727 */       Log.error(sqle);
/* 728 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 731 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbAttachment
 * JD-Core Version:    0.6.2
 */
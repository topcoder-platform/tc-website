package com.jivesoftware.forum;

import com.jivesoftware.base.UnauthorizedException;
import java.util.Date;

public abstract interface ArchiveManager
{
  public static final int MARK_THREADS = 0;
  public static final int DELETE_THREADS = 1;
  public static final int MOVE_THREADS = 2;

  public abstract boolean isArchivingEnabled(Forum paramForum);

  public abstract void setArchivingEnabled(Forum paramForum, boolean paramBoolean)
    throws UnauthorizedException;

  public abstract int getArchiveDays(Forum paramForum);

  public abstract void setArchiveDays(Forum paramForum, int paramInt)
    throws UnauthorizedException;

  public abstract int getArchiveMode(Forum paramForum);

  public abstract void setArchiveMode(Forum paramForum, int paramInt)
    throws UnauthorizedException;

  public abstract Forum getArchiveForum(Forum paramForum)
    throws UnauthorizedException;

  public abstract void setArchiveForum(Forum paramForum1, Forum paramForum2)
    throws UnauthorizedException;

  public abstract boolean isAutoArchiveEnabled()
    throws UnauthorizedException;

  public abstract void setAutoArchiveEnabled(boolean paramBoolean)
    throws UnauthorizedException;

  public abstract int getAutoArchiveInterval()
    throws UnauthorizedException;

  public abstract void setAutoArchiveInterval(int paramInt)
    throws UnauthorizedException;

  public abstract boolean isBusy()
    throws UnauthorizedException;

  public abstract Date getLastArchivedDate()
    throws UnauthorizedException;

  public abstract void runArchiver()
    throws UnauthorizedException;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.ArchiveManager
 * JD-Core Version:    0.6.2
 */
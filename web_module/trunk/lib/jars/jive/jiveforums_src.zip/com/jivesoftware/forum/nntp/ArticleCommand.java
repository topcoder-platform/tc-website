/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class ArticleCommand
/*    */ {
/* 21 */   private int number = -1;
/* 22 */   private Article article = null;
/* 23 */   private String messageid = null;
/*    */ 
/*    */   public static ArticleCommand getCommand(String[] cmdParts, ArticlePointer pointer)
/*    */     throws ArticleNotFoundException, NoGroupSelectedException, NoPermissionException, ArticleNotSelectedException
/*    */   {
/* 48 */     ArticleCommand cmd = new ArticleCommand();
/* 49 */     if (cmdParts.length == 1) {
/* 50 */       cmd.article = pointer.getCurrentArticle();
/* 51 */       cmd.number = pointer.getCurrentArticleNumber();
/*    */     } else {
/* 53 */       if (cmdParts.length != 2) {
/* 54 */         throw new NumberFormatException();
/*    */       }
/* 56 */       if (MessageID.isMessageID(cmdParts[1])) {
/* 57 */         cmd.messageid = cmdParts[1];
/* 58 */         cmd.article = pointer.getArticle(cmd.messageid);
/*    */       }
/*    */       else {
/*    */         try {
/* 62 */           cmd.number = Integer.parseInt(cmdParts[1]);
/*    */         }
/*    */         catch (NumberFormatException nfe) {
/* 65 */           throw new ArticleNotFoundException("article number " + cmdParts[1] + " is not valid");
/*    */         }
/* 67 */         cmd.article = pointer.getArticle(cmd.number);
/*    */       }
/*    */     }
/* 69 */     return cmd;
/*    */   }
/*    */ 
/*    */   public Article getArticle()
/*    */   {
/* 78 */     return this.article;
/*    */   }
/*    */ 
/*    */   public long getNumber()
/*    */   {
/* 87 */     return this.number;
/*    */   }
/*    */ 
/*    */   public String getMessageID()
/*    */   {
/* 96 */     return this.messageid;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.ArticleCommand
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.action.rss;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.action.rss.RSSActionSupport;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.util.SkinUtils;
/*     */ import com.jivesoftware.util.LocaleUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class RSSPopularThreads extends RSSActionSupport
/*     */ {
/*  30 */   private long categoryID = 0L;
/*  31 */   private long forumID = 0L;
/*     */   private boolean full;
/*  34 */   private ForumCategory category = null;
/*  35 */   private Forum forum = null;
/*     */   private Iterator threads;
/*     */ 
/*     */   public long getCategoryID()
/*     */   {
/*  40 */     return this.categoryID;
/*     */   }
/*     */ 
/*     */   public void setCategoryID(long categoryID) {
/*  44 */     this.categoryID = categoryID;
/*     */   }
/*     */ 
/*     */   public long getForumID() {
/*  48 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID) {
/*  52 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public boolean isFull()
/*     */   {
/*  59 */     return this.full;
/*     */   }
/*     */ 
/*     */   public boolean getFull()
/*     */   {
/*  66 */     return this.full;
/*     */   }
/*     */ 
/*     */   public void setFull(boolean full)
/*     */   {
/*  73 */     this.full = full;
/*     */   }
/*     */ 
/*     */   public Iterator getThreads()
/*     */   {
/*  80 */     if (this.threads == null) {
/*  81 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/*  83 */     return this.threads;
/*     */   }
/*     */ 
/*     */   public String getFeedTitle()
/*     */   {
/*  90 */     List args = new ArrayList();
/*  91 */     args.add(SkinUtils.getCommunityName());
/*  92 */     if (this.category != null) {
/*  93 */       args.add(this.category.getName());
/*  94 */       return LocaleUtils.getLocalizedString("rss.popularthreads_category", getLocale(), args);
/*     */     }
/*  96 */     if (this.forum != null) {
/*  97 */       args.add(this.forum.getName());
/*  98 */       return LocaleUtils.getLocalizedString("rss.popularthreads_forum", getLocale(), args);
/*     */     }
/*     */ 
/* 101 */     return LocaleUtils.getLocalizedString("rss.popularthreads", getLocale(), args);
/*     */   }
/*     */ 
/*     */   public String executeRSS()
/*     */   {
/* 106 */     ForumFactory forumFactory = ForumFactory.getInstance(getAuthToken());
/* 107 */     if (this.categoryID > 0L) {
/*     */       try {
/* 109 */         this.category = forumFactory.getForumCategory(this.categoryID);
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e) {
/* 112 */         addFieldError("categoryNotFound", "" + this.categoryID);
/* 113 */         return "error";
/*     */       }
/*     */     }
/* 116 */     if (this.forumID > 0L) {
/*     */       try {
/* 118 */         this.forum = forumFactory.getForum(this.forumID);
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 121 */         addFieldError("forumNotFound", "" + this.forumID);
/* 122 */         return "error";
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 125 */         addFieldError("unauthorized", "");
/* 126 */         return "unauthorized";
/*     */       }
/*     */     }
/*     */ 
/* 130 */     if (this.forum != null) {
/* 131 */       this.threads = this.forum.getPopularThreads();
/*     */     }
/* 133 */     else if (this.category != null) {
/* 134 */       this.threads = this.category.getPopularThreads();
/*     */     }
/*     */     else {
/* 137 */       this.threads = forumFactory.getPopularThreads();
/*     */     }
/*     */ 
/* 140 */     if (hasErrors()) {
/* 141 */       return "error";
/*     */     }
/* 143 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.rss.RSSPopularThreads
 * JD-Core Version:    0.6.2
 */
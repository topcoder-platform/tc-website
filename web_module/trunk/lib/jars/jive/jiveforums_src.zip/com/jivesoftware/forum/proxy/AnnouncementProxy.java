/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserProxy;
/*     */ import com.jivesoftware.forum.Announcement;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.AttachmentException;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class AnnouncementProxy
/*     */   implements Announcement
/*     */ {
/*     */   private Announcement announcement;
/*     */   private AuthToken authToken;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public AnnouncementProxy(Announcement announcement, AuthToken authToken, Permissions permissions)
/*     */   {
/*  38 */     this.announcement = announcement;
/*  39 */     this.authToken = authToken;
/*  40 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public long getID() {
/*  44 */     return this.announcement.getID();
/*     */   }
/*     */ 
/*     */   public int getContainerObjectType() {
/*  48 */     return this.announcement.getContainerObjectType();
/*     */   }
/*     */ 
/*     */   public long getContainerObjectID() {
/*  52 */     return this.announcement.getContainerObjectID();
/*     */   }
/*     */ 
/*     */   public User getUser() {
/*  56 */     User user = this.announcement.getUser();
/*  57 */     if (user == null) {
/*  58 */       return null;
/*     */     }
/*  60 */     Permissions userPermissions = new Permissions(this.permissions, user.getPermissions(this.authToken));
/*  61 */     return new UserProxy(user, this.authToken, userPermissions);
/*     */   }
/*     */ 
/*     */   public Date getStartDate() {
/*  65 */     return this.announcement.getStartDate();
/*     */   }
/*     */ 
/*     */   public void setStartDate(Date startDate) throws UnauthorizedException {
/*  69 */     if (isAllowedToEdit()) {
/*  70 */       this.announcement.setStartDate(startDate);
/*     */     }
/*     */     else
/*  73 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Date getEndDate()
/*     */   {
/*  78 */     return this.announcement.getEndDate();
/*     */   }
/*     */ 
/*     */   public void setEndDate(Date endDate) throws UnauthorizedException {
/*  82 */     if (isAllowedToEdit()) {
/*  83 */       this.announcement.setEndDate(endDate);
/*     */     }
/*     */     else
/*  86 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public String getSubject()
/*     */   {
/*  91 */     return this.announcement.getSubject();
/*     */   }
/*     */ 
/*     */   public void setSubject(String subject) throws UnauthorizedException {
/*  95 */     if (isAllowedToEdit()) {
/*  96 */       this.announcement.setSubject(subject);
/*     */     }
/*     */     else
/*  99 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public String getUnfilteredSubject()
/*     */   {
/* 104 */     return this.announcement.getUnfilteredSubject();
/*     */   }
/*     */ 
/*     */   public String getBody() {
/* 108 */     return this.announcement.getBody();
/*     */   }
/*     */ 
/*     */   public void setBody(String body) throws UnauthorizedException {
/* 112 */     if (isAllowedToEdit()) {
/* 113 */       this.announcement.setBody(body);
/*     */     }
/*     */     else
/* 116 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public String getUnfilteredBody()
/*     */   {
/* 121 */     return this.announcement.getUnfilteredBody();
/*     */   }
/*     */ 
/*     */   public int getAttachmentCount() {
/* 125 */     return this.announcement.getAttachmentCount();
/*     */   }
/*     */ 
/*     */   public void deleteAttachment(Attachment attachment)
/*     */     throws AttachmentException, UnauthorizedException
/*     */   {
/* 131 */     if (isAllowedToEdit()) {
/* 132 */       this.announcement.deleteAttachment(attachment);
/*     */     }
/*     */     else
/* 135 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getAttachments()
/*     */   {
/* 140 */     return this.announcement.getAttachments();
/*     */   }
/*     */ 
/*     */   public String getProperty(String name) {
/* 144 */     return this.announcement.getProperty(name);
/*     */   }
/*     */ 
/*     */   public String getUnfilteredProperty(String name) {
/* 148 */     return this.announcement.getUnfilteredProperty(name);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value) throws UnauthorizedException {
/* 152 */     if (isAllowedToEdit()) {
/* 153 */       this.announcement.setProperty(name, value);
/*     */     }
/*     */     else
/* 156 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) throws UnauthorizedException
/*     */   {
/* 161 */     if (isAllowedToEdit()) {
/* 162 */       this.announcement.deleteProperty(name);
/*     */     }
/*     */     else
/* 165 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames()
/*     */   {
/* 170 */     return this.announcement.getPropertyNames();
/*     */   }
/*     */ 
/*     */   public Announcement getProxiedAnnouncement()
/*     */     throws UnauthorizedException
/*     */   {
/* 178 */     if ((isAllowedToEdit()) || (getID() == -1L)) {
/* 179 */       return this.announcement;
/*     */     }
/*     */ 
/* 182 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   private boolean isAllowedToEdit()
/*     */   {
/* 187 */     return (this.permissions.hasPermission(576460752303424384L)) || (getUser().getID() == this.authToken.getUserID());
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.AnnouncementProxy
 * JD-Core Version:    0.6.2
 */
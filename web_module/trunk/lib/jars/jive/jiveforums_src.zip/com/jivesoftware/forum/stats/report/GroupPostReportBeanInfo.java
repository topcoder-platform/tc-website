/*    */ package com.jivesoftware.forum.stats.report;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class GroupPostReportBeanInfo extends JiveBeanInfo
/*    */ {
/*    */   public String[] getPropertyNames()
/*    */   {
/* 14 */     return new String[] { "group", "stepSize" };
/*    */   }
/*    */   public Class getBeanClass() {
/* 17 */     return GroupPostReport.class;
/*    */   }
/*    */   public String getName() {
/* 20 */     return "GroupPostReport";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.GroupPostReportBeanInfo
 * JD-Core Version:    0.6.2
 */
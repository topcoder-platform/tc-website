/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.BinFormat;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.Report.ExtraInfo;
/*     */ import com.jivesoftware.base.stats.bin.CyclicSequence;
/*     */ import com.jivesoftware.base.stats.element.CyclicElement;
/*     */ import com.jivesoftware.base.stats.element.DayOfWeekElementFormat;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class DayOfWeekReport extends AbstractForumReport
/*     */ {
/*     */   private static final String NEW_MESSAGES_BY_DATE = "SELECT creationDate FROM jiveMessage WHERE creationDate >= ? AND creationDate < ?";
/*     */   private static final String NEW_MESSAGES_BY_FORUM_AND_DATE = "SELECT creationDate FROM jiveMessage WHERE forumID = ? AND creationDate >= ? AND creationDate < ?";
/*  49 */   private int firstDayOfWeek = Calendar.getInstance(JiveGlobals.getLocale()).getFirstDayOfWeek();
/*  50 */   private BinFormat labelFormatter = new BinFormat(new DayOfWeekElementFormat("EEE"), "$1");
/*     */ 
/*     */   public void execute()
/*     */     throws Exception
/*     */   {
/*  55 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  56 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  59 */     Histogram hist = new Histogram(new CyclicSequence(7L), new CyclicElement(7L, this.firstDayOfWeek, this.firstDayOfWeek), new CyclicElement(7L, this.firstDayOfWeek, this.firstDayOfWeek - 1));
/*     */ 
/*  62 */     addHistogram(hist);
/*     */ 
/*  64 */     Connection con = null;
/*  65 */     PreparedStatement pstmt = null;
/*  66 */     Calendar cal = Calendar.getInstance(JiveGlobals.getTimeZone(), JiveGlobals.getLocale());
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/*  72 */         con = ConnectionManager.getConnection();
/*  73 */         pstmt = con.prepareStatement("SELECT creationDate FROM jiveMessage WHERE creationDate >= ? AND creationDate < ?");
/*  74 */         pstmt.setLong(1, start.getTime());
/*  75 */         pstmt.setLong(2, end.getTime());
/*  76 */         ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  78 */         while (rs.next()) {
/*  79 */           cal.setTime(new Date(rs.getLong(1)));
/*  80 */           hist.add(new CyclicElement(7L, this.firstDayOfWeek, cal.get(7)));
/*     */         }
/*  82 */         rs.close();
/*  83 */         pstmt.close();
/*     */       }
/*     */       catch (SQLException sqle)
/*     */       {
/*     */       }
/*     */ 
/*  91 */       List forums = getObjects();
/*  92 */       for (iter = forums.iterator(); iter.hasNext(); ) {
/*  93 */         Forum forum = (Forum)iter.next();
/*  94 */         long forumID = forum.getID();
/*  95 */         hist = new Histogram(new CyclicSequence(7L), new CyclicElement(7L, this.firstDayOfWeek, this.firstDayOfWeek), new CyclicElement(7L, this.firstDayOfWeek, this.firstDayOfWeek - 1));
/*     */ 
/*  98 */         addHistogram(hist);
/*     */         try {
/* 100 */           pstmt = con.prepareStatement("SELECT creationDate FROM jiveMessage WHERE forumID = ? AND creationDate >= ? AND creationDate < ?");
/* 101 */           pstmt.setLong(1, forumID);
/* 102 */           pstmt.setLong(2, start.getTime());
/* 103 */           pstmt.setLong(3, end.getTime());
/* 104 */           ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 106 */           while (rs.next()) {
/* 107 */             cal.setTime(new Date(rs.getLong(1)));
/* 108 */             hist.add(new CyclicElement(7L, this.firstDayOfWeek, cal.get(7)));
/*     */           }
/* 110 */           rs.close();
/* 111 */           pstmt.close();
/*     */         }
/*     */         catch (SQLException sqle)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       Iterator iter;
/* 119 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/* 124 */     Histogram[] histograms = getHistograms();
/* 125 */     if (histograms.length == 0) {
/* 126 */       return new DataTable[0];
/*     */     }
/* 128 */     List tables = new ArrayList(histograms.length);
/* 129 */     for (int i = 0; i < histograms.length; i++) {
/* 130 */       Histogram hist = histograms[i];
/* 131 */       DataTable data = new DataTable(getName());
/* 132 */       data.setColumns(new String[] { "Day of the Week", "Messages" });
/* 133 */       Bin[] bins = hist.getBins();
/* 134 */       for (int j = 0; j < bins.length; j++) {
/* 135 */         Bin bin = bins[j];
/* 136 */         long count = hist.getCount(bin);
/* 137 */         data.addRow(new Object[] { this.labelFormatter.format(bin), new Long(count) });
/*     */       }
/* 139 */       tables.add(data);
/*     */     }
/* 141 */     return (DataTable[])tables.toArray(new DataTable[0]);
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 145 */     Histogram[] histograms = getHistograms();
/* 146 */     if (histograms.length == 0) {
/* 147 */       return new Chart[0];
/*     */     }
/* 149 */     List charts = new ArrayList(histograms.length);
/* 150 */     for (int i = 0; i < histograms.length; i++) {
/* 151 */       Histogram hist = histograms[i];
/* 152 */       String name = getName();
/* 153 */       if (i == 0) {
/* 154 */         name = name + " - All forums";
/*     */       }
/*     */       else {
/* 157 */         name = name + " - " + getObjects().get(i - 1);
/*     */       }
/* 159 */       Chart chart = new Chart(name);
/* 160 */       chart.setXaxisLabel("Messages");
/* 161 */       chart.setYaxisLabel("Day of the Week");
/* 162 */       chart.setType(1);
/* 163 */       Bin[] bins = hist.getBins();
/* 164 */       String[] labels = new String[bins.length];
/* 165 */       for (int j = 0; j < bins.length; j++) {
/* 166 */         Bin bin = bins[j];
/* 167 */         labels[j] = this.labelFormatter.format(bin);
/*     */       }
/* 169 */       chart.setLabels(labels);
/* 170 */       charts.add(chart);
/*     */     }
/* 172 */     return (Chart[])charts.toArray(new Chart[0]);
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 176 */     Histogram[] histograms = getHistograms();
/* 177 */     if (histograms.length == 0) {
/* 178 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/* 180 */     List lists = new ArrayList(histograms.length);
/* 181 */     for (int i = 0; i < histograms.length; i++) {
/* 182 */       List extraInfo = new ArrayList(4);
/* 183 */       Histogram hist = histograms[i];
/* 184 */       if (hist.getNElement() > 0L)
/*     */       {
/* 186 */         extraInfo.add(new Report.ExtraInfo("Median messages/day", new Long(hist.getMedianCount())));
/*     */ 
/* 188 */         BinFormat dataFormat = new BinFormat(new DayOfWeekElementFormat("EEEE"), "$1");
/* 189 */         String day = dataFormat.format(hist.getMaxCountBin());
/* 190 */         extraInfo.add(new Report.ExtraInfo("Peak Day", day));
/*     */       }
/*     */ 
/* 194 */       extraInfo.add(getDateRange());
/*     */ 
/* 196 */       lists.add(extraInfo);
/*     */     }
/* 198 */     return (List[])lists.toArray(new List[0]);
/*     */   }
/*     */ 
/*     */   public List getForums() {
/* 202 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.DayOfWeekReport
 * JD-Core Version:    0.6.2
 */
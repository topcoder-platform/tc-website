/*    */ package com.jivesoftware.forum.nntp.spi;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ public class DotIterator extends PeekIterator
/*    */ {
/*    */   public DotIterator(Iterator itr)
/*    */   {
/* 30 */     super(itr);
/*    */   }
/*    */ 
/*    */   public boolean hasNext()
/*    */   {
/* 41 */     boolean next = super.hasNext();
/* 42 */     if (next) {
/* 43 */       String line = (String)super.peek();
/* 44 */       if (".".equals(line)) {
/* 45 */         next = false;
/*    */       }
/*    */     }
/* 48 */     return next;
/*    */   }
/*    */ 
/*    */   public Object next() {
/* 52 */     Object next = super.next();
/* 53 */     if (".".equals(next)) {
/* 54 */       throw new NoSuchElementException();
/*    */     }
/* 56 */     return next;
/*    */   }
/*    */ 
/*    */   public Object peek() {
/* 60 */     String line = (String)super.peek();
/* 61 */     if (".".equals(line)) {
/* 62 */       throw new NoSuchElementException();
/*    */     }
/* 64 */     return line;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.DotIterator
 * JD-Core Version:    0.6.2
 */
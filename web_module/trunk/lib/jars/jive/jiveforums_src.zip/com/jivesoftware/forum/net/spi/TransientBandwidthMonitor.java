package com.jivesoftware.forum.net.spi;

import com.jivesoftware.forum.net.BandwidthMonitor;

public class TransientBandwidthMonitor extends BasicTransientMonitor
  implements BandwidthMonitor
{
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.spi.TransientBandwidthMonitor
 * JD-Core Version:    0.6.2
 */
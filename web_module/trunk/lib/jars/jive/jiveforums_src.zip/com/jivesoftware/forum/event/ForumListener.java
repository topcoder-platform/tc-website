package com.jivesoftware.forum.event;

public abstract interface ForumListener
{
  public abstract void forumAdded(ForumEvent paramForumEvent);

  public abstract void forumDeleted(ForumEvent paramForumEvent);

  public abstract void forumMoved(ForumEvent paramForumEvent);

  public abstract void forumMerged(ForumEvent paramForumEvent);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.ForumListener
 * JD-Core Version:    0.6.2
 */
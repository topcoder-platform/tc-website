/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class QuestionResolutionTime extends AbstractForumReport
/*     */ {
/*     */   private static final String RESOLVED_QUESTIONS = "SELECT forumID, AVG(resolutionDate - creationDate) AS time FROM jiveQuestion WHERE resolutionDate IS NOT NULL GROUP BY forumID ORDER by time";
/*     */   private static final String UNRESOLVED_QUESTIONS = "SELECT forumID, AVG(? - creationDate) AS time FROM jiveQuestion WHERE resolutionDate IS NULL GROUP BY forumID ORDER by time";
/*     */   DataTable data;
/*     */   HashMap results;
/*     */ 
/*     */   public QuestionResolutionTime()
/*     */   {
/*  40 */     this.results = new HashMap();
/*     */   }
/*     */   public void execute() throws Exception {
/*  43 */     DbForumFactory ff = DbForumFactory.getInstance();
/*     */ 
/*  45 */     this.data = new DataTable("Forum Resolution Time");
/*  46 */     String[] cols = { "Category", "Forum", "Avg Resolution Time", "Avg Open Question Time" };
/*  47 */     this.data.setColumns(cols);
/*     */ 
/*  49 */     Connection conn = null;
/*  50 */     PreparedStatement ps = null;
/*  51 */     ResultSet rs = null;
/*     */     try {
/*  53 */       conn = ConnectionManager.getConnection();
/*     */ 
/*  56 */       ps = conn.prepareStatement("SELECT forumID, AVG(resolutionDate - creationDate) AS time FROM jiveQuestion WHERE resolutionDate IS NOT NULL GROUP BY forumID ORDER by time");
/*  57 */       rs = ps.executeQuery();
/*  58 */       while (rs.next()) {
/*  59 */         int forumID = rs.getInt(1);
/*  60 */         double time = rs.getDouble(2);
/*  61 */         Forum forum = ff.getForum(forumID);
/*     */ 
/*  63 */         DataHolder dh = new DataHolder(forum);
/*  64 */         dh.resolvedTime = time;
/*  65 */         this.results.put(forum, dh);
/*     */       }
/*     */ 
/*  68 */       rs.close();
/*  69 */       ps.close();
/*     */ 
/*  72 */       ps = conn.prepareStatement("SELECT forumID, AVG(? - creationDate) AS time FROM jiveQuestion WHERE resolutionDate IS NULL GROUP BY forumID ORDER by time");
/*  73 */       ps.setLong(1, System.currentTimeMillis());
/*  74 */       rs = ps.executeQuery();
/*  75 */       while (rs.next()) {
/*  76 */         int forumID = rs.getInt(1);
/*  77 */         double time = rs.getDouble(2);
/*  78 */         Forum forum = ff.getForum(forumID);
/*     */ 
/*  80 */         DataHolder dh = null;
/*  81 */         if (this.results.containsKey(forum)) {
/*  82 */           dh = (DataHolder)this.results.get(forum);
/*     */         }
/*     */         else {
/*  85 */           dh = new DataHolder(forum);
/*     */         }
/*     */ 
/*  88 */         dh.unresolvedTime = time;
/*  89 */         this.results.put(forum, dh);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  93 */       throw new RuntimeException(e);
/*     */     }
/*     */     finally {
/*  96 */       if (rs != null) {
/*  97 */         rs.close();
/*     */       }
/*     */ 
/* 100 */       if (ps != null) {
/* 101 */         ps.close();
/*     */       }
/*     */ 
/* 104 */       if (conn != null) {
/* 105 */         conn.close();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 111 */     for (Iterator iterator = this.results.values().iterator(); iterator.hasNext(); ) {
/* 112 */       DataHolder dataHolder = (DataHolder)iterator.next();
/* 113 */       this.data.addRow(dataHolder.getRow());
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getLenth(double time) {
/* 118 */     String s = null;
/* 119 */     int minutes = (int)(time / 60000.0D);
/* 120 */     int hours = minutes / 60;
/* 121 */     if (hours > 0) {
/* 122 */       minutes %= hours;
/* 123 */       s = hours + " " + pluralize("hour", hours) + ", " + minutes + " " + pluralize("minute", minutes);
/*     */     }
/*     */     else
/*     */     {
/* 127 */       s = minutes + " " + pluralize("minute", minutes);
/*     */     }
/*     */ 
/* 130 */     return s;
/*     */   }
/*     */ 
/*     */   private String pluralize(String s, int value) {
/* 134 */     if (value > 1) {
/* 135 */       return s + "s";
/*     */     }
/*     */ 
/* 138 */     return s;
/*     */   }
/*     */ 
/*     */   public DataTable[] getDataTables()
/*     */   {
/* 143 */     return new DataTable[] { this.data };
/*     */   }
/*     */ 
/*     */   public DataTable[] getDataTableCSVs() {
/* 147 */     return new DataTable[] { this.data };
/*     */   }
/*     */ 
/*     */   class DataHolder
/*     */   {
/*     */     Forum forum;
/* 153 */     double resolvedTime = -1.0D;
/* 154 */     double unresolvedTime = -1.0D;
/*     */ 
/*     */     public DataHolder(Forum forum) {
/* 157 */       this.forum = forum;
/*     */     }
/*     */ 
/*     */     public Object[] getRow() {
/* 161 */       String resolved = "-";
/* 162 */       if (this.resolvedTime > -1.0D) {
/* 163 */         resolved = QuestionResolutionTime.this.getLenth(this.resolvedTime);
/*     */       }
/*     */ 
/* 166 */       String unresolved = "-";
/* 167 */       if (this.unresolvedTime > -1.0D) {
/* 168 */         unresolved = QuestionResolutionTime.this.getLenth(this.unresolvedTime);
/*     */       }
/*     */ 
/* 171 */       return new Object[] { this.forum.getForumCategory().getName(), this.forum.getName(), resolved, unresolved };
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.QuestionResolutionTime
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.interceptor;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class UserInterceptorBeanInfo extends JiveBeanInfo
/*    */ {
/* 21 */   public static final String[] PROPERTY_NAMES = { "banList", "notificationEnabled", "fromEmail", "fromName", "emailSubject", "emailBodyTemplate" };
/*    */ 
/*    */   public Class getBeanClass()
/*    */   {
/* 29 */     return UserInterceptor.class;
/*    */   }
/*    */ 
/*    */   public String[] getPropertyNames() {
/* 33 */     return PROPERTY_NAMES;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 37 */     return "UserInterceptor";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.UserInterceptorBeanInfo
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.TreeWalker;
/*     */ import com.jivesoftware.util.CacheSizes;
/*     */ import com.jivesoftware.util.LongTree;
/*     */ import com.tangosol.io.ExternalizableLite;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class DbTreeWalker
/*     */   implements TreeWalker, Serializable, ExternalizableLite
/*     */ {
/*     */   private static final String MESSAGE_COUNT = "SELECT count(*) FROM jiveMessage WHERE threadID=?";
/*     */   private static final String GET_MESSAGES = "SELECT messageID, parentMessageID, creationDate FROM jiveMessage WHERE threadID=? AND parentMessageID IS NOT NULL ORDER BY creationDate ASC";
/*  50 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */   private long threadID;
/*     */   private LongTree tree;
/*     */ 
/*     */   public DbTreeWalker(DbForumThread thread)
/*     */   {
/*  59 */     this.threadID = thread.getID();
/*     */ 
/*  62 */     Connection con = null;
/*  63 */     PreparedStatement pstmt = null;
/*     */     try {
/*  65 */       con = ConnectionManager.getConnection();
/*     */ 
/*  67 */       pstmt = con.prepareStatement("SELECT count(*) FROM jiveMessage WHERE threadID=?");
/*  68 */       pstmt.setLong(1, thread.getID());
/*  69 */       ResultSet rs = pstmt.executeQuery();
/*  70 */       rs.next();
/*  71 */       int numMessages = rs.getInt(1);
/*  72 */       rs.close();
/*  73 */       pstmt.close();
/*     */ 
/*  75 */       this.tree = new LongTree(thread.rootMessageID, numMessages);
/*     */ 
/*  78 */       pstmt = con.prepareStatement("SELECT messageID, parentMessageID, creationDate FROM jiveMessage WHERE threadID=? AND parentMessageID IS NOT NULL ORDER BY creationDate ASC");
/*  79 */       pstmt.setLong(1, thread.getID());
/*  80 */       rs = pstmt.executeQuery();
/*  81 */       int count = 1;
/*     */ 
/*  86 */       while ((rs.next()) && (count < numMessages)) {
/*  87 */         count++;
/*  88 */         long messageID = rs.getLong(1);
/*  89 */         long parentMessageID = rs.getLong(2);
/*  90 */         this.tree.addChild(parentMessageID, messageID);
/*     */       }
/*  92 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/*  95 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/*  98 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DbTreeWalker()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ForumMessage getRoot()
/*     */   {
/* 112 */     ForumThread thread = null;
/*     */     try {
/* 114 */       thread = FACTORY.cacheManager.getForumThread(this.threadID);
/*     */     }
/*     */     catch (Exception e) {
/* 117 */       return null;
/*     */     }
/* 119 */     return thread.getRootMessage();
/*     */   }
/*     */ 
/*     */   public int getChildCount(ForumMessage parent) {
/* 123 */     return this.tree.getChildCount(parent.getID());
/*     */   }
/*     */ 
/*     */   public boolean hasParent(ForumMessage message) {
/* 127 */     long parentID = this.tree.getParent(message.getID());
/* 128 */     return parentID != -1L;
/*     */   }
/*     */ 
/*     */   public ForumMessage getParent(ForumMessage message)
/*     */     throws ForumMessageNotFoundException
/*     */   {
/* 134 */     long parentID = this.tree.getParent(message.getID());
/* 135 */     if (parentID == -1L) {
/* 136 */       throw new ForumMessageNotFoundException();
/*     */     }
/*     */ 
/* 139 */     ForumThread thread = null;
/*     */     try {
/* 141 */       thread = FACTORY.cacheManager.getForumThread(this.threadID);
/*     */     }
/*     */     catch (Exception e) {
/* 144 */       throw new ForumMessageNotFoundException();
/*     */     }
/* 146 */     return thread.getMessage(parentID);
/*     */   }
/*     */ 
/*     */   public ForumMessage getChild(ForumMessage message, int index)
/*     */     throws ForumMessageNotFoundException
/*     */   {
/* 153 */     long childID = this.tree.getChild(message.getID(), index);
/* 154 */     if (childID == -1L) {
/* 155 */       throw new ForumMessageNotFoundException();
/*     */     }
/*     */ 
/* 158 */     ForumThread thread = null;
/*     */     try {
/* 160 */       thread = FACTORY.cacheManager.getForumThread(this.threadID);
/*     */     }
/*     */     catch (Exception e) {
/* 163 */       throw new ForumMessageNotFoundException();
/*     */     }
/* 165 */     return thread.getMessage(childID);
/*     */   }
/*     */ 
/*     */   public Iterator getChildren(ForumMessage parent)
/*     */   {
/* 170 */     long[] children = this.tree.getChildren(parent.getID());
/* 171 */     return new DatabaseObjectIterator(2, children, parent.getForumThread());
/*     */   }
/*     */ 
/*     */   public Iterator getRecursiveMessages()
/*     */   {
/* 176 */     long[] messages = this.tree.getRecursiveKeys();
/* 177 */     ForumThread thread = null;
/*     */     try {
/* 179 */       thread = FACTORY.cacheManager.getForumThread(this.threadID);
/*     */     } catch (Exception e) {
/*     */     }
/* 182 */     return new DatabaseObjectIterator(2, messages, thread);
/*     */   }
/*     */ 
/*     */   public Iterator getRecursiveChildren(ForumMessage parent) {
/* 186 */     long[] messages = this.tree.getRecursiveChildren(parent.getID());
/* 187 */     return new DatabaseObjectIterator(2, messages, parent.getForumThread());
/*     */   }
/*     */ 
/*     */   public int getMessageDepth(ForumMessage message)
/*     */   {
/* 192 */     int depth = this.tree.getDepth(message.getID());
/* 193 */     if (depth == -1) {
/* 194 */       throw new IllegalArgumentException("Message " + message.getID() + " does not belong to this thread.");
/*     */     }
/*     */ 
/* 197 */     return depth;
/*     */   }
/*     */ 
/*     */   public int getRecursiveChildCount(ForumMessage parent)
/*     */   {
/* 202 */     return getRecursiveChildCount(parent.getID());
/*     */   }
/*     */ 
/*     */   public int getIndexOfChild(ForumMessage parent, ForumMessage child) {
/* 206 */     return this.tree.getIndexOfChild(parent.getID(), child.getID());
/*     */   }
/*     */ 
/*     */   public boolean isLeaf(ForumMessage message) {
/* 210 */     return this.tree.isLeaf(message.getID());
/*     */   }
/*     */ 
/*     */   public void readExternal(DataInput in)
/*     */     throws IOException
/*     */   {
/* 216 */     this.threadID = in.readLong();
/* 217 */     this.tree = new LongTree();
/* 218 */     this.tree.readExternal(in);
/*     */   }
/*     */ 
/*     */   public void writeExternal(DataOutput out) throws IOException {
/* 222 */     out.writeLong(this.threadID);
/* 223 */     this.tree.writeExternal(out);
/*     */   }
/*     */ 
/*     */   public void addChild(ForumMessage parent, ForumMessage child)
/*     */   {
/* 233 */     this.tree.addChild(parent.getID(), child.getID());
/*     */   }
/*     */ 
/*     */   public int getSize() {
/* 237 */     int size = 0;
/* 238 */     size += CacheSizes.sizeOfObject();
/* 239 */     size += this.tree.getCachedSize();
/* 240 */     size += CacheSizes.sizeOfLong();
/* 241 */     size += CacheSizes.sizeOfLong();
/* 242 */     size += CacheSizes.sizeOfObject();
/* 243 */     return size;
/*     */   }
/*     */ 
/*     */   private int getRecursiveChildCount(long parentID) {
/* 247 */     int numChildren = 0;
/* 248 */     int num = this.tree.getChildCount(parentID);
/* 249 */     numChildren += num;
/* 250 */     for (int i = 0; i < num; i++) {
/* 251 */       long childID = this.tree.getChild(parentID, i);
/* 252 */       if (childID != -1L) {
/* 253 */         numChildren += getRecursiveChildCount(childID);
/*     */       }
/*     */     }
/* 256 */     return numChildren;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbTreeWalker
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.nntp.spi;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class MimeTools
/*     */ {
/*  28 */   private static final Pattern HEADER_PATTERN = Pattern.compile("^([^:]+): (.*)");
/*     */ 
/*  31 */   private static final Pattern MIME_TYPE_PATTERN = Pattern.compile("^([^;]+);");
/*     */ 
/*  34 */   private static final Pattern MIME_NAME_PATTERN = Pattern.compile("name=\"([^\"]+)\"");
/*     */ 
/*  37 */   private static final Pattern ALT_MIME_NAME_PATTERN = Pattern.compile("name=([^\"]+)");
/*     */ 
/*  40 */   private static final Pattern MIME_BOUNDARY_PATTERN = Pattern.compile("boundary=\"([^\"]+)\"");
/*     */ 
/*  43 */   private static final Pattern MIME_CHARSET_PATTERN = Pattern.compile("charset=\"?([^\"|^;]+)\"?");
/*     */ 
/*  46 */   private static final Pattern UUENCODE_START_PATTERN = Pattern.compile("^begin [640]{3} (.*)");
/*     */   public static final String EXTRA_HEADER_PROP_PREFIX = "nttp.xheader";
/*     */ 
/*     */   public static final String getMIMEType(String contentType)
/*     */   {
/*  65 */     String type = "text/plain";
/*  66 */     if (contentType != null) {
/*  67 */       Matcher matcher = MIME_TYPE_PATTERN.matcher(contentType);
/*  68 */       if (matcher.find()) {
/*  69 */         type = matcher.group(1);
/*     */       }
/*     */     }
/*  72 */     return type;
/*     */   }
/*     */ 
/*     */   public static final String getMIMEName(String contentType)
/*     */   {
/*  83 */     String name = "";
/*  84 */     if (contentType != null) {
/*  85 */       Matcher matcher = MIME_NAME_PATTERN.matcher(contentType);
/*  86 */       if (matcher.find()) {
/*  87 */         name = matcher.group(1);
/*     */       }
/*     */       else {
/*  90 */         matcher = ALT_MIME_NAME_PATTERN.matcher(contentType);
/*  91 */         if (matcher.find()) {
/*  92 */           name = matcher.group(1);
/*     */         }
/*     */       }
/*     */     }
/*  96 */     return name;
/*     */   }
/*     */ 
/*     */   public static final String getMIMEBoundary(String contentType)
/*     */   {
/* 107 */     String boundary = null;
/* 108 */     if (contentType != null) {
/* 109 */       Matcher matcher = MIME_BOUNDARY_PATTERN.matcher(contentType);
/* 110 */       if (matcher.find()) {
/* 111 */         boundary = matcher.group(1);
/*     */       }
/*     */     }
/* 114 */     return boundary;
/*     */   }
/*     */ 
/*     */   public static final Charset getMIMECharset(String contentType)
/*     */   {
/* 125 */     String charset = "ISO-8859-1";
/* 126 */     if (contentType != null) {
/* 127 */       Matcher matcher = MIME_CHARSET_PATTERN.matcher(contentType);
/* 128 */       if (matcher.find()) {
/* 129 */         charset = matcher.group(1);
/*     */       }
/*     */     }
/* 132 */     return Charset.forName(charset);
/*     */   }
/*     */ 
/*     */   public static final Headers parseHeaders(Iterator headIter)
/*     */   {
/* 161 */     Headers parseInfo = new Headers();
/* 162 */     StringBuffer currentHeaderValue = null;
/* 163 */     while (headIter.hasNext()) {
/* 164 */       String headerString = (String)headIter.next();
/* 165 */       if ((headerString == null) || (headerString.equals("")))
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 170 */       char c = headerString.charAt(0);
/* 171 */       if ((c == '\t') || (c == ' '))
/*     */       {
/* 173 */         if (currentHeaderValue != null)
/* 174 */           currentHeaderValue.append(" ").append(headerString.trim());
/*     */       }
/*     */       else
/*     */       {
/* 178 */         Header head = parseHeader(headerString);
/* 179 */         if ("Subject".equalsIgnoreCase(head.name)) {
/* 180 */           currentHeaderValue = new StringBuffer(head.value);
/* 181 */           parseInfo.subject = currentHeaderValue;
/*     */         }
/* 183 */         else if ("Newsgroups".equalsIgnoreCase(head.name)) {
/* 184 */           currentHeaderValue = new StringBuffer(head.value);
/* 185 */           parseInfo.groups = currentHeaderValue;
/*     */         }
/* 187 */         else if ("References".equalsIgnoreCase(head.name)) {
/* 188 */           currentHeaderValue = new StringBuffer(head.value);
/* 189 */           parseInfo.refs = currentHeaderValue;
/*     */         }
/* 191 */         else if ("Content-Type".equalsIgnoreCase(head.name)) {
/* 192 */           currentHeaderValue = new StringBuffer(head.value);
/* 193 */           parseInfo.contentType = currentHeaderValue;
/*     */         }
/* 195 */         else if ("Content-Transfer-Encoding".equalsIgnoreCase(head.name)) {
/* 196 */           currentHeaderValue = new StringBuffer(head.value);
/* 197 */           parseInfo.contentEncoding = currentHeaderValue;
/*     */         }
/* 199 */         else if ("From".equalsIgnoreCase(head.name)) {
/* 200 */           currentHeaderValue = new StringBuffer(head.value);
/* 201 */           parseInfo.from = currentHeaderValue;
/*     */         }
/*     */         else
/*     */         {
/* 206 */           if ((!"Cc".equalsIgnoreCase(head.name)) && (!"Bcc".equalsIgnoreCase(head.name)) && (!"From".equalsIgnoreCase(head.name)) && (!"Date".equalsIgnoreCase(head.name)) && (!"Message-ID".equalsIgnoreCase(head.name)))
/*     */           {
/* 212 */             parseInfo.getExtraHeaders().add(head);
/*     */           }
/* 214 */           currentHeaderValue = null;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 219 */     return parseInfo;
/*     */   }
/*     */ 
/*     */   public static String detectUuencodedStart(String line)
/*     */   {
/* 231 */     Matcher matcher = UUENCODE_START_PATTERN.matcher(line);
/* 232 */     String name = null;
/* 233 */     if (matcher.find()) {
/* 234 */       name = matcher.group(1);
/*     */     }
/* 236 */     return name;
/*     */   }
/*     */ 
/*     */   public static final Header parseHeader(String header)
/*     */   {
/* 248 */     Header head = new Header();
/* 249 */     Matcher matcher = HEADER_PATTERN.matcher(header);
/* 250 */     if (matcher.matches()) {
/* 251 */       head.name = matcher.group(1);
/* 252 */       head.value = matcher.group(2);
/*     */     }
/* 254 */     return head;
/*     */   }
/*     */ 
/*     */   public static final class Headers
/*     */   {
/* 284 */     StringBuffer subject = null;
/*     */ 
/* 289 */     StringBuffer contentType = null;
/*     */ 
/* 294 */     StringBuffer contentEncoding = null;
/*     */ 
/* 299 */     StringBuffer groups = null;
/*     */ 
/* 304 */     StringBuffer refs = null;
/*     */ 
/* 309 */     StringBuffer from = null;
/*     */     private Collection extraHeaders;
/*     */ 
/*     */     public Headers()
/*     */     {
/* 317 */       this.extraHeaders = new ArrayList(5);
/*     */     }
/*     */ 
/*     */     public Collection getExtraHeaders() {
/* 321 */       return this.extraHeaders;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 328 */       return "Headers{subject=" + this.subject + ", contentType=" + this.contentType + ", contentEncoding=" + this.contentEncoding + ", groups=" + this.groups + ", refs=" + this.refs + ", from=" + this.from + "}";
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Header
/*     */   {
/*     */     String name;
/*     */     String value;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.MimeTools
 * JD-Core Version:    0.6.2
 */
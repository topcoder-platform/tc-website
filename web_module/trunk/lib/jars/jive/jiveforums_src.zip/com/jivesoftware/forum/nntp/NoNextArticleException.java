/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class NoNextArticleException extends NNTPException
/*    */ {
/*    */   private static final int CODE = 421;
/* 23 */   private static final NNTPResponse RESPONSE = new StaticNNTPResponse(421, "no next article in this group");
/*    */ 
/*    */   public NoNextArticleException()
/*    */   {
/* 30 */     this.response = RESPONSE;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NoNextArticleException
 * JD-Core Version:    0.6.2
 */
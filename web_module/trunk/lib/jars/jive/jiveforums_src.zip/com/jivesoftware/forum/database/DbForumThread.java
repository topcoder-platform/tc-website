/*      */ package com.jivesoftware.forum.database;
/*      */ 
/*      */ import com.jivesoftware.base.AuthFactory;
/*      */ import com.jivesoftware.base.AuthToken;
/*      */ import com.jivesoftware.base.Log;
/*      */ import com.jivesoftware.base.UnauthorizedException;
/*      */ import com.jivesoftware.base.database.CachedPreparedStatement;
/*      */ import com.jivesoftware.base.database.ConnectionManager;
/*      */ import com.jivesoftware.base.database.sequence.SequenceManager;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*      */ import com.jivesoftware.forum.ForumNotFoundException;
/*      */ import com.jivesoftware.forum.ForumThread;
/*      */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*      */ import com.jivesoftware.forum.MessageRejectedException;
/*      */ import com.jivesoftware.forum.ResultFilter;
/*      */ import com.jivesoftware.forum.TreeWalker;
/*      */ import com.jivesoftware.forum.event.MessageEvent;
/*      */ import com.jivesoftware.forum.event.MessageEventDispatcher;
/*      */ import com.jivesoftware.forum.event.ThreadEvent;
/*      */ import com.jivesoftware.forum.event.ThreadEventDispatcher;
/*      */ import com.jivesoftware.forum.proxy.ForumMessageProxy;
/*      */ import com.jivesoftware.util.Cache;
/*      */ import com.jivesoftware.util.CacheFactory;
/*      */ import com.jivesoftware.util.CacheSizes;
/*      */ import com.jivesoftware.util.Cacheable;
/*      */ import com.jivesoftware.util.ExtendedPropertyUtils;
/*      */ import com.jivesoftware.util.ExternalizableLiteUtil;
/*      */ import com.jivesoftware.util.profile.Profiler;
/*      */ import com.tangosol.io.ExternalizableLite;
/*      */ import com.tangosol.util.ConcurrentMap;
/*      */ import com.tangosol.util.ExternalizableHelper;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.IOException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ public class DbForumThread
/*      */   implements ForumThread, Cacheable, ExternalizableLite
/*      */ {
/*      */   private static final String UPDATE_THREAD_MODIFIED_DATE = "UPDATE jiveThread SET modificationDate=? WHERE threadID=?";
/*      */   private static final String NEWEST_MESSAGE_DATE = "SELECT max(modificationDate) FROM jiveMessage WHERE threadID=?";
/*      */   private static final String DELETE_MESSAGE = "DELETE FROM jiveMessage WHERE messageID=?";
/*      */   private static final String UPDATE_PARENT_MESSAGE = "UPDATE jiveMessage SET parentMessageID=? WHERE parentMessageID=?";
/*      */   private static final String DELETE_MESSAGE_PROPERTIES = "DELETE FROM jiveMessageProp WHERE messageID=?";
/*      */   private static final String LOAD_THREAD = "SELECT forumID, rootMessageID, modValue, rewardPoints, creationDate, modificationDate FROM jiveThread WHERE threadID=?";
/*      */   private static final String INSERT_THREAD = "INSERT INTO jiveThread(threadID,forumID,rootMessageID,modValue, rewardPoints,creationDate,modificationDate) VALUES(?,?,?,?,?,?,?)";
/*      */   private static final String SAVE_THREAD = "UPDATE jiveThread SET rootMessageID=?, modValue=?, rewardPoints=?, creationDate=?, modificationDate=? WHERE threadID=?";
/*      */   private static final String LOAD_PROPERTIES = "SELECT name, propValue FROM jiveThreadProp WHERE threadID=?";
/*      */   private static final String INSERT_PROPERTY = "INSERT INTO jiveThreadProp(threadID,name,propValue) VALUES(?,?,?)";
/*      */   private static final String UPDATE_PROPERTY = "UPDATE jiveThreadProp SET propValue=? WHERE name=? AND threadID=?";
/*      */   private static final String DELETE_PROPERTY = "DELETE FROM jiveThreadProp WHERE threadID=? AND name=?";
/*      */   private static final String INSERT_MODERATION_ENTRY = "INSERT INTO jiveModeration(objectID, objectType, userID, modDate, modValue) VALUES(?,?,?,?,?)";
/*      */   private static final boolean LAZY_PROP_LOADING = true;
/*   86 */   private static final ResultFilter DEFAULT_MESSAGE_FILTER = ResultFilter.createDefaultMessageFilter();
/*      */   private static final long serialVersionUID = 1L;
/*   91 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*      */ 
/*   93 */   private long id = -1L;
/*      */   protected long rootMessageID;
/*   95 */   protected long forumID = -1L;
/*      */   private Date creationDate;
/*      */   private Date modificationDate;
/*  100 */   protected int moderationValue = -2147483648;
/*  101 */   private int rewardPoints = 0;
/*      */   private Map properties;
/*  109 */   private boolean readyToSave = false;
/*      */ 
/*  115 */   private transient ForumMessage rootMessage = null;
/*      */ 
/*      */   protected DbForumThread(Forum forum, ForumMessage rootMessage)
/*      */   {
/*  125 */     this.forumID = forum.getID();
/*      */ 
/*  128 */     boolean newMessage = rootMessage.getForumThread() == null;
/*  129 */     if (newMessage) {
/*  130 */       if ((rootMessage instanceof ForumMessageProxy)) {
/*      */         try {
/*  132 */           ForumMessageProxy proxyMessage = (ForumMessageProxy)rootMessage;
/*  133 */           this.rootMessage = proxyMessage.getProxiedForumMessage();
/*      */         }
/*      */         catch (UnauthorizedException ue) {
/*  136 */           Log.error(ue);
/*      */         }
/*      */       }
/*      */       else
/*  140 */         this.rootMessage = rootMessage;
/*      */     }
/*      */     else {
/*      */       try
/*      */       {
/*  145 */         this.rootMessage = FACTORY.cacheManager.getMessage(rootMessage.getID());
/*      */       }
/*      */       catch (Exception e) {
/*  148 */         Log.error(e);
/*      */       }
/*      */     }
/*      */ 
/*  152 */     this.rootMessageID = rootMessage.getID();
/*      */ 
/*  156 */     long rootMessageTime = rootMessage.getCreationDate().getTime();
/*  157 */     this.creationDate = new Date(rootMessageTime);
/*  158 */     if (newMessage) {
/*  159 */       this.modificationDate = new Date(rootMessageTime);
/*      */     }
/*      */     else
/*      */     {
/*  164 */       this.modificationDate = rootMessage.getModificationDate();
/*      */       try {
/*  166 */         Iterator i = rootMessage.getForumThread().getTreeWalker().getChildren(rootMessage);
/*  167 */         while (i.hasNext())
/*      */         {
/*  169 */           ForumMessage message = (ForumMessage)i.next();
/*  170 */           if (message.getModificationDate().after(this.modificationDate))
/*  171 */             this.modificationDate = message.getModificationDate();
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  176 */         Log.error(e);
/*      */       }
/*      */     }
/*  179 */     this.properties = new Hashtable();
/*      */   }
/*      */ 
/*      */   protected DbForumThread(long id)
/*      */     throws ForumThreadNotFoundException
/*      */   {
/*  188 */     if (id < 0L) {
/*  189 */       throw new ForumThreadNotFoundException("ID " + id + " is not valid.");
/*      */     }
/*  191 */     this.id = id;
/*  192 */     loadFromDb();
/*  193 */     this.readyToSave = true;
/*      */   }
/*      */ 
/*      */   public DbForumThread()
/*      */   {
/*      */   }
/*      */ 
/*      */   public long getID()
/*      */   {
/*  204 */     return this.id;
/*      */   }
/*      */ 
/*      */   public String getName() {
/*  208 */     String name = null;
/*      */     try {
/*  210 */       name = getMessage(this.rootMessageID).getSubject();
/*      */     } catch (Exception e) {
/*      */     }
/*  213 */     return name;
/*      */   }
/*      */ 
/*      */   public Date getCreationDate() {
/*  217 */     return new Date(this.creationDate.getTime());
/*      */   }
/*      */ 
/*      */   public void setCreationDate(Date creationDate) {
/*  221 */     this.creationDate = new Date(creationDate.getTime());
/*      */ 
/*  223 */     if (!this.readyToSave) {
/*  224 */       return;
/*      */     }
/*  226 */     saveToDb();
/*      */ 
/*  228 */     FACTORY.cacheManager.threadPut(this.id, this);
/*      */   }
/*      */ 
/*      */   public Date getModificationDate() {
/*  232 */     return new Date(this.modificationDate.getTime());
/*      */   }
/*      */ 
/*      */   public void setModificationDate(Date modificationDate) {
/*  236 */     this.modificationDate = new Date(modificationDate.getTime());
/*      */ 
/*  238 */     if (!this.readyToSave) {
/*  239 */       return;
/*      */     }
/*  241 */     saveToDb();
/*      */ 
/*  243 */     FACTORY.cacheManager.threadPut(this.id, this);
/*      */   }
/*      */ 
/*      */   public int getModerationValue() {
/*  247 */     return this.moderationValue;
/*      */   }
/*      */ 
/*      */   public void setModerationValue(int value, AuthToken authToken)
/*      */   {
/*  252 */     if (this.moderationValue == value) {
/*  253 */       return;
/*      */     }
/*  255 */     setModValue(value, authToken);
/*      */ 
/*  261 */     DbForumMessage message = null;
/*  262 */     if (this.readyToSave) {
/*  263 */       message = (DbForumMessage)getRootMessage();
/*      */     }
/*  267 */     else if ((this.rootMessage instanceof ForumMessageProxy)) {
/*  268 */       ForumMessageProxy proxyMsg = (ForumMessageProxy)this.rootMessage;
/*      */       try {
/*  270 */         message = (DbForumMessage)proxyMsg.getProxiedForumMessage();
/*      */       }
/*      */       catch (UnauthorizedException ue)
/*      */       {
/*  275 */         Log.error(ue);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  280 */       message = (DbForumMessage)this.rootMessage;
/*      */     }
/*      */ 
/*  283 */     message.setModValue(value, authToken);
/*      */   }
/*      */ 
/*      */   public String getProperty(String name) {
/*  287 */     if (this.properties == null) {
/*  288 */       loadPropertiesFromDb();
/*      */     }
/*  290 */     return (String)this.properties.get(name);
/*      */   }
/*      */ 
/*      */   public Collection getProperties(String parentName) {
/*  294 */     Object[] keys = this.properties.keySet().toArray();
/*  295 */     ArrayList results = new ArrayList();
/*  296 */     int i = 0; for (int n = keys.length; i < n; i++) {
/*  297 */       String key = (String)keys[i];
/*  298 */       if ((key.startsWith(parentName)) && 
/*  299 */         (!key.equals(parentName)))
/*      */       {
/*  302 */         if (key.substring(parentName.length()).lastIndexOf(".") == 0) {
/*  303 */           results.add(this.properties.get(key));
/*      */         }
/*      */       }
/*      */     }
/*  307 */     return Collections.unmodifiableCollection(results);
/*      */   }
/*      */ 
/*      */   public void setProperty(String name, String value) {
/*  311 */     if (this.properties == null) {
/*  312 */       loadPropertiesFromDb();
/*      */     }
/*      */ 
/*  315 */     value = ExtendedPropertyUtils.validateExtendedProperty(name, value);
/*      */ 
/*  317 */     if (this.properties.containsKey(name))
/*      */     {
/*  320 */       if (!value.equals(this.properties.get(name))) {
/*  321 */         this.properties.put(name, value);
/*  322 */         if (this.readyToSave) {
/*  323 */           updatePropertyInDb(name, value);
/*      */ 
/*  325 */           FACTORY.cacheManager.threadPut(this.id, this);
/*      */           try
/*      */           {
/*  328 */             DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  329 */             dbForum.clearCache();
/*      */           }
/*      */           catch (Exception e) {
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/*  337 */       this.properties.put(name, value);
/*  338 */       if (this.readyToSave) {
/*  339 */         Connection con = null;
/*  340 */         boolean abortTransaction = false;
/*      */         try {
/*  342 */           con = ConnectionManager.getTransactionConnection();
/*  343 */           insertPropertyIntoDb(name, value, con);
/*      */         }
/*      */         catch (SQLException sqle) {
/*  346 */           Log.error(sqle);
/*  347 */           abortTransaction = true;
/*      */         }
/*      */         finally {
/*  350 */           ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*      */         }
/*      */ 
/*  353 */         FACTORY.cacheManager.threadPut(this.id, this);
/*      */         try
/*      */         {
/*  356 */           DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  357 */           dbForum.clearCache();
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteProperty(String name) {
/*  367 */     if (this.properties == null) {
/*  368 */       loadPropertiesFromDb();
/*      */     }
/*      */ 
/*  371 */     if (this.properties.containsKey(name)) {
/*  372 */       this.properties.remove(name);
/*      */ 
/*  374 */       if (this.readyToSave) {
/*  375 */         deletePropertyFromDb(name);
/*      */ 
/*  377 */         FACTORY.cacheManager.threadPut(this.id, this);
/*      */         try
/*      */         {
/*  380 */           DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  381 */           dbForum.clearCache();
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public Iterator getPropertyNames() {
/*  391 */     if (this.properties == null) {
/*  392 */       loadPropertiesFromDb();
/*      */     }
/*  394 */     return Collections.unmodifiableSet(this.properties.keySet()).iterator();
/*      */   }
/*      */ 
/*      */   public Forum getForum()
/*      */   {
/*  399 */     if (this.forumID == -1L)
/*  400 */       return null;
/*      */     try
/*      */     {
/*  403 */       return FACTORY.getForum(this.forumID);
/*      */     }
/*      */     catch (Exception e) {
/*  406 */       Log.error(e);
/*  407 */     }return null;
/*      */   }
/*      */ 
/*      */   public ForumMessage getMessage(long messageID) throws ForumMessageNotFoundException
/*      */   {
/*  412 */     ForumMessage message = FACTORY.getMessage(messageID);
/*  413 */     if (!message.getForumThread().equals(this)) {
/*  414 */       throw new ForumMessageNotFoundException("Message with ID " + messageID + " not in thread " + getID());
/*      */     }
/*      */ 
/*  417 */     return message;
/*      */   }
/*      */ 
/*      */   public ForumMessage getLatestMessage()
/*      */   {
/*  422 */     ForumMessage lastPost = null;
/*  423 */     int messageCount = getMessageCount();
/*  424 */     if (messageCount == 1) {
/*  425 */       lastPost = getRootMessage();
/*      */     }
/*  430 */     else if (messageCount < 400) {

                 ResultFilter filter = new ResultFilter();
                 filter.setSortOrder(0);
                 filter.setSortField(9);
                 filter.setNumResults(1);

/*  431 */       DbForumFactory dbFactory = DbForumFactory.getInstance();
/*      */       try {
/*  433 */         DbForumThread dbThread = (DbForumThread)dbFactory.getForumThread(getID());
/*  434 */         QueryCacheKey key = new QueryCacheKey(1, getID(), dbThread.getMessageListSQL(filter, false), 0);
/*      */ 
/*  437 */         boolean shortTermEnabled = dbFactory.cacheManager.isShortTermQueryCacheEnabled();
/*  438 */         if (!dbFactory.cacheManager.queryCache.containsKey(key))
/*      */         {
/*  440 */           if ((shortTermEnabled) && (!dbFactory.cacheManager.shortTermQueryCache.containsKey(key)))
/*      */           {
/*  442 */             dbThread.getMessages(filter);
/*      */           }
/*      */           else
/*      */           {
/*  446 */             dbThread.getMessages(filter);
/*      */           }
/*      */         }
/*  449 */         long[] messageIDs = (long[])dbFactory.cacheManager.queryGet(key);
/*      */ 
/*  451 */         if ((messageIDs == null) && (shortTermEnabled)) {
/*  452 */           messageIDs = (long[])dbFactory.cacheManager.shortTermQueryCache.get(key);
/*      */         }
/*      */ 
/*  455 */         if (messageIDs != null && messageIDs.length > 0)
/*  456 */           lastPost = dbFactory.getMessage(messageIDs[0]);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  460 */         Log.error(e);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  466 */     if (lastPost == null) {
/*  467 */       ResultFilter filter = new ResultFilter();
/*  468 */       filter.setSortOrder(0);
/*  469 */       filter.setSortField(9);
/*      */ 
/*  471 */       filter.setModificationDateRangeMin(ResultFilter.roundDate(this.modificationDate, 86400));
/*  472 */       filter.setNumResults(1);
/*  473 */       Iterator messages = getMessages(filter);
/*  474 */       if (messages.hasNext()) {
/*  475 */         lastPost = (ForumMessage)messages.next();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  481 */     if (lastPost == null) {
/*  482 */       ResultFilter filter = new ResultFilter();
/*  483 */       filter.setSortOrder(0);
/*  484 */       filter.setSortField(9);
/*  485 */       filter.setNumResults(1);
/*  486 */       Iterator messages = getMessages(filter);
/*  487 */       if (messages.hasNext()) {
/*  488 */         lastPost = (ForumMessage)messages.next();
/*      */       }
/*      */     }
/*      */ 
/*  492 */     return lastPost;
/*      */   }
/*      */ 
/*      */   public ForumMessage getRootMessage()
/*      */   {
/*  499 */     if (this.rootMessage != null) {
/*  500 */       return this.rootMessage;
/*      */     }
/*      */ 
/*  503 */     ForumMessage message = null;
/*      */     try {
/*  505 */       if (message == null) {
/*  506 */         for (int i = 0; i < 4; i++)
/*      */           try {
/*  508 */             message = getMessage(this.rootMessageID);
/*      */           } catch (ForumMessageNotFoundException e) {
/*  510 */             Log.warn("Couldn't get root msg (" + this.rootMessageID + ") for thread " + this.id + ", waiting 50 ms and trying again. (thread: " + Thread.currentThread().getName() + ")");
/*  511 */             FACTORY.cacheManager.messageRemove(this.rootMessageID);
/*  512 */             Thread.sleep(50L);
/*      */           }
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  518 */       Log.error(e);
/*      */     }
/*  520 */     return message;
/*      */   }
/*      */ 
/*      */   public int getMessageCount() {
/*  524 */     return getMessageCount(DEFAULT_MESSAGE_FILTER);
/*      */   }
/*      */ 
/*      */   public int getMessageCount(ResultFilter resultFilter) {
/*  528 */     CachedPreparedStatement sql = getMessageListSQL(resultFilter, true);
/*  529 */     QueryCacheKey key = new QueryCacheKey(1, this.id, sql, -1);
/*  530 */     return QueryCache.getCount(key, true);
/*      */   }
/*      */ 
/*      */   public synchronized void addMessage(ForumMessage parentMessage, ForumMessage newMessage)
/*      */     throws MessageRejectedException, UnauthorizedException
/*      */   {
/*  537 */     if ("true".equals(getProperty("locked"))) {
/*  538 */       throw new MessageRejectedException("Message " + newMessage.getID() + " could not be added to thread " + getID() + " because the thread is locked.", newMessage);
/*      */     }
/*      */ 
/*  543 */     DbForumMessage dbMessage = null;
/*  544 */     if ((newMessage instanceof ForumMessageProxy)) {
/*  545 */       ForumMessageProxy proxyMessage = (ForumMessageProxy)newMessage;
/*  546 */       dbMessage = (DbForumMessage)proxyMessage.getProxiedForumMessage();
/*      */     }
/*      */     else {
/*  549 */       dbMessage = (DbForumMessage)newMessage;
/*      */     }
/*      */ 
/*  554 */     long parentCDate = parentMessage.getCreationDate().getTime();
/*  555 */     if (dbMessage.getCreationDate().getTime() < parentCDate) {
/*  556 */       Log.warn("Attempting to add message with creation date younger than it's parent's creation date, correcting dates.");
/*      */ 
/*  558 */       Log.debug("Creation date of new message: " + dbMessage.getCreationDate() + ", creation date of parent message: " + parentMessage.getCreationDate(), new Exception());
/*      */ 
/*  562 */       Date newDate = new Date(parentCDate + 1L);
/*  563 */       dbMessage.setCreationDate(newDate);
/*      */ 
/*  565 */       if (dbMessage.getModificationDate().getTime() < parentCDate) {
/*  566 */         dbMessage.setModificationDate(newDate);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  571 */     if (dbMessage.getModerationValue() == -2147483648) {
/*  572 */       dbMessage.setModerationValue(getForum().getModerationDefaultMessageValue(), null);
/*      */     }
/*      */ 
/*  576 */     if (this.id != -1L) {
/*  577 */       dbMessage.threadID = this.id;
/*      */     }
/*      */ 
/*  581 */     DbInterceptorManager manager = (DbInterceptorManager)getForum().getInterceptorManager();
/*  582 */     manager.invokeInterceptors(dbMessage, 0);
/*      */     try
/*      */     {
/*  586 */       dbMessage.prepareInsertIntoDb(this);
/*      */     }
/*      */     catch (SQLException sqle) {
/*  589 */       Log.error(sqle);
/*      */     }
/*      */ 
/*  593 */     boolean abortTransaction = false;
/*  594 */     Connection con = null;
/*      */     try {
/*  596 */       con = ConnectionManager.getTransactionConnection();
/*  597 */       dbMessage.insertIntoDb(this, parentMessage.getID(), con);
/*      */     }
/*      */     catch (Exception e) {
/*  600 */       Log.error(e);
/*  601 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/*  604 */       ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*      */     }
/*      */ 
/*  609 */     Long cacheKey = new Long(this.id);
/*      */ 
/*  611 */     if (FACTORY.cacheManager.treeWalkerCache.containsKey(cacheKey)) {
/*      */       try {
/*  613 */         CacheFactory.lockingMap.lock("treeWalker-" + this.id, -1L);
/*  614 */         DbTreeWalker treeWalker = (DbTreeWalker)FACTORY.cacheManager.treeWalkerCache.get(cacheKey);
/*      */ 
/*  616 */         if (treeWalker != null) {
/*  617 */           treeWalker.addChild(parentMessage, newMessage);
/*  618 */           FACTORY.cacheManager.treeWalkerCache.put(cacheKey, treeWalker);
/*      */         }
/*      */       }
/*      */       finally {
/*  622 */         CacheFactory.lockingMap.unlock("treeWalker-" + this.id);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  627 */     manager.invokeInterceptors(dbMessage, 1);
/*      */ 
/*  630 */     clearCache();
/*      */     try {
/*  632 */       DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  633 */       dbForum.clearCache();
/*      */     }
/*      */     catch (ForumNotFoundException fnfe) {
/*  636 */       Log.error(fnfe);
/*      */     }
/*      */ 
/*  643 */     if (dbMessage.getModerationValue() >= 1) {
/*  644 */       con = null;
/*      */       try {
/*  646 */         con = ConnectionManager.getConnection();
/*  647 */         updateModifiedDate(newMessage.getModificationDate().getTime(), con);
/*      */       }
/*      */       catch (Exception e) {
/*  650 */         Log.error(e);
/*      */       }
/*      */       finally {
/*  653 */         ConnectionManager.closeConnection(con);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  658 */     FACTORY.cacheManager.threadPut(this.id, this);
/*      */ 
/*  661 */     FACTORY.expirePopularObjects(false);
/*      */ 
/*  665 */     FACTORY.cacheManager.messagePut(dbMessage.getID(), dbMessage);
/*      */ 
/*  668 */     MessageEvent event = new MessageEvent(100, dbMessage, Collections.EMPTY_MAP);
/*      */ 
/*  670 */     MessageEventDispatcher.getInstance().dispatchEvent(event);
/*      */   }
/*      */ 
/*      */   public synchronized void deleteMessage(ForumMessage message)
/*      */   {
/*  675 */     if (message.getForumThread().getID() != this.id) {
/*  676 */       throw new IllegalArgumentException("Message " + message.getID() + " could not be deleted. It belongs to thread " + message.getForumThread().getID() + ", and not thread " + this.id + ".");
/*      */     }
/*      */ 
/*  684 */     if (message.getID() == getRootMessage().getID()) {
/*      */       try {
/*  686 */         DbForum forum = FACTORY.cacheManager.getForum(this.forumID);
/*  687 */         forum.deleteThread(this);
/*  688 */         return;
/*      */       }
/*      */       catch (Exception e) {
/*  691 */         Log.error(e);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  696 */       boolean abortTransaction = false;
/*  697 */       Connection con = null;
/*      */       try {
/*  699 */         DbForumMessage dbMessage = FACTORY.cacheManager.getMessage(message.getID());
/*  700 */         con = ConnectionManager.getTransactionConnection();
/*      */ 
/*  702 */         deleteMessage(dbMessage, con, true);
/*      */       } catch (Exception e) { Log.error(e);
/*  706 */         abortTransaction = true;
/*      */         return;
/*      */       }
/*      */       finally {
/*  710 */         ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  715 */     Long cacheKey = new Long(this.id);
/*      */ 
/*  717 */     if (FACTORY.cacheManager.treeWalkerCache.containsKey(cacheKey)) {
/*      */       try {
/*  719 */         CacheFactory.lockingMap.lock("treeWalker-" + this.id, -1L);
/*  720 */         FACTORY.cacheManager.treeWalkerCache.remove(cacheKey);
/*      */       }
/*      */       finally {
/*  723 */         CacheFactory.lockingMap.unlock("treeWalker-" + this.id);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  728 */     FACTORY.cacheManager.threadPut(this.id, this);
/*  729 */     clearCache();
/*      */     try
/*      */     {
/*  732 */       DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  733 */       dbForum.clearCache();
/*      */     }
/*      */     catch (ForumNotFoundException fnfe)
/*      */     {
/*      */     }
/*      */ 
/*  739 */     fixModificationDate();
/*      */   }
/*      */ 
/*      */   public synchronized void deleteMessage(ForumMessage message, boolean deleteChildren) {
/*  743 */     if (deleteChildren) {
/*  744 */       deleteMessage(message);
/*  745 */       return;
/*      */     }
/*      */ 
/*  749 */     if (message.getForumThread().getID() != this.id) {
/*  750 */       throw new IllegalArgumentException("Message " + message.getID() + " could not be deleted. It belongs to thread " + message.getForumThread().getID() + ", and not thread " + this.id + ".");
/*      */     }
/*      */ 
/*  757 */     if (this.rootMessageID == message.getID()) {
/*  758 */       throw new IllegalArgumentException("Cannot delete the root message using this delete mode.");
/*      */     }
/*      */ 
/*  763 */     boolean abortTransaction = false;
/*  764 */     Connection con = null;
/*      */     try {
/*  766 */       DbForumMessage dbMessage = FACTORY.cacheManager.getMessage(message.getID());
/*  767 */       con = ConnectionManager.getTransactionConnection();
/*      */ 
/*  770 */       long parentID = getTreeWalker().getParent(message).getID();
/*  771 */       PreparedStatement pstmt = con.prepareStatement("UPDATE jiveMessage SET parentMessageID=? WHERE parentMessageID=?");
/*  772 */       pstmt.setLong(1, parentID);
/*  773 */       pstmt.setLong(2, message.getID());
/*  774 */       pstmt.executeUpdate();
/*  775 */       pstmt.close();
/*      */ 
/*  778 */       deleteMessage(dbMessage, con, false);
/*      */     } catch (Exception e) { Log.error(e);
/*  782 */       abortTransaction = true;
/*      */       return;
/*      */     }
/*      */     finally {
/*  786 */       ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*      */     }
/*      */ 
/*  790 */     Long cacheKey = new Long(this.id);
/*      */ 
/*  792 */     if (FACTORY.cacheManager.treeWalkerCache.containsKey(cacheKey)) {
/*      */       try {
/*  794 */         CacheFactory.lockingMap.lock("treeWalker-" + this.id, -1L);
/*  795 */         FACTORY.cacheManager.treeWalkerCache.remove(cacheKey);
/*      */       }
/*      */       finally {
/*  798 */         CacheFactory.lockingMap.unlock("treeWalker-" + this.id);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  803 */     FACTORY.cacheManager.threadPut(this.id, this);
/*  804 */     clearCache();
/*      */     try
/*      */     {
/*  807 */       DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  808 */       dbForum.clearCache();
/*      */     }
/*      */     catch (ForumNotFoundException fnfe)
/*      */     {
/*      */     }
/*  813 */     fixModificationDate();
/*      */   }
/*      */ 
/*      */   public TreeWalker getTreeWalker() {
/*  817 */     TreeWalker treeWalker = (TreeWalker)FACTORY.cacheManager.treeWalkerCache.get(new Long(this.id));
/*  818 */     if (treeWalker == null) {
/*  819 */       treeWalker = new DbTreeWalker(this);
/*  820 */       FACTORY.cacheManager.treeWalkerCache.put(new Long(this.id), treeWalker);
/*      */     }
/*  822 */     return treeWalker;
/*      */   }
/*      */ 
/*      */   public Iterator getMessages() {
/*  826 */     return getMessages(DEFAULT_MESSAGE_FILTER);
/*      */   }
/*      */ 
/*      */   public Iterator getMessages(ResultFilter resultFilter) {
/*  830 */     CachedPreparedStatement query = getMessageListSQL(resultFilter, false);
/*  831 */     long[] messageBlock = QueryCache.getBlock(query, 1, this.id, resultFilter.getStartIndex(), true);
/*      */ 
/*  833 */     int startIndex = resultFilter.getStartIndex();
/*      */     int endIndex;
/*  837 */     if (resultFilter.getNumResults() == 2147483524) {
/*  838 */       endIndex = getMessageCount(resultFilter);
/*      */     }
/*      */     else {
/*  841 */       endIndex = resultFilter.getNumResults() + startIndex;
/*      */     }
/*  843 */     return new ForumMessageBlockIterator(messageBlock, query, startIndex, endIndex, 1, this.id);
/*      */   }
/*      */ 
/*      */   public boolean isAuthorized(long type)
/*      */   {
/*  848 */     return true;
/*      */   }
/*      */ 
/*      */   public static int getObjectType()
/*      */   {
/*  854 */     return 1;
/*      */   }
/*      */ 
/*      */   public int getCachedSize()
/*      */   {
/*  862 */     int size = 0;
/*  863 */     size += CacheSizes.sizeOfObject();
/*  864 */     size += CacheSizes.sizeOfLong();
/*  865 */     size += CacheSizes.sizeOfDate();
/*  866 */     size += CacheSizes.sizeOfDate();
/*  867 */     size += CacheSizes.sizeOfObject();
/*  868 */     size += CacheSizes.sizeOfObject();
/*  869 */     size += CacheSizes.sizeOfObject();
/*  870 */     size += CacheSizes.sizeOfBoolean();
/*  871 */     size += CacheSizes.sizeOfBoolean();
/*  872 */     return size;
/*      */   }
/*      */ 
/*      */   public void readExternal(DataInput in)
/*      */     throws IOException
/*      */   {
/*  878 */     this.id = ExternalizableHelper.readLong(in);
/*  879 */     this.rootMessageID = ExternalizableHelper.readLong(in);
/*  880 */     this.forumID = ExternalizableHelper.readLong(in);
/*  881 */     this.creationDate = new Date(in.readLong());
/*  882 */     this.modificationDate = new Date(in.readLong());
/*  883 */     this.moderationValue = ExternalizableHelper.readInt(in);
/*  884 */     this.rewardPoints = ExternalizableHelper.readInt(in);
/*  885 */     this.properties = ExternalizableLiteUtil.readStringMap(in);
/*  886 */     this.readyToSave = in.readBoolean();
/*      */   }
/*      */ 
/*      */   public void writeExternal(DataOutput out) throws IOException {
/*  890 */     ExternalizableHelper.writeLong(out, this.id);
/*  891 */     ExternalizableHelper.writeLong(out, this.rootMessageID);
/*  892 */     ExternalizableHelper.writeLong(out, this.forumID);
/*  893 */     out.writeLong(this.creationDate.getTime());
/*  894 */     out.writeLong(this.modificationDate.getTime());
/*  895 */     ExternalizableHelper.writeInt(out, this.moderationValue);
/*  896 */     ExternalizableHelper.writeInt(out, this.rewardPoints);
/*  897 */     ExternalizableLiteUtil.writeStringMap(out, this.properties);
/*  898 */     out.writeBoolean(this.readyToSave);
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  909 */     return "[" + this.id + "] " + getName();
/*      */   }
/*      */ 
/*      */   public int hashCode() {
/*  913 */     return (int)this.id;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object object) {
/*  917 */     if (this == object) {
/*  918 */       return true;
/*      */     }
/*  920 */     if ((object != null) && ((object instanceof DbForumThread))) {
/*  921 */       return this.id == ((DbForumThread)object).getID();
/*      */     }
/*      */ 
/*  924 */     return false;
/*      */   }
/*      */ 
/*      */   protected void updateModifiedDate(long date, Connection con)
/*      */     throws SQLException
/*      */   {
/*  934 */     if (date > this.modificationDate.getTime()) {
/*  935 */       this.modificationDate.setTime(date);
/*  936 */       PreparedStatement pstmt = null;
/*      */       try {
/*  938 */         pstmt = con.prepareStatement("UPDATE jiveThread SET modificationDate=? WHERE threadID=?");
/*  939 */         pstmt.setLong(1, this.modificationDate.getTime());
/*  940 */         pstmt.setLong(2, this.id);
/*  941 */         pstmt.executeUpdate();
/*      */       }
/*      */       finally {
/*  944 */         ConnectionManager.closePreparedStatement(pstmt);
/*      */       }
/*      */ 
/*  947 */       ((DbForum)getForum()).updateModifiedDate(date, con);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void setModValue(int value, AuthToken authToken) {
/*  952 */     if (this.moderationValue == value) {
/*  953 */       return;
/*      */     }
/*      */ 
/*  956 */     if (authToken == null) {
/*  957 */       authToken = AuthFactory.getAnonymousAuthToken();
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  963 */       Forum forum = FACTORY.getForum(this.forumID);
/*  964 */       if ((this.moderationValue < 1) && (value >= 1))
/*      */       {
/*  967 */         forum.setModificationDate(this.modificationDate);
/*      */       }
/*      */     }
/*      */     catch (ForumNotFoundException fnfe) {
/*      */     }
/*      */     catch (UnauthorizedException ue) {
/*      */     }
/*  974 */     int oldModerationValue = this.moderationValue;
/*  975 */     this.moderationValue = value;
/*      */ 
/*  977 */     if (!this.readyToSave) {
/*  978 */       return;
/*      */     }
/*  980 */     saveToDb();
/*      */ 
/*  982 */     FACTORY.cacheManager.threadPut(this.id, this);
/*      */     try
/*      */     {
/*  986 */       DbForum dbForum = FACTORY.cacheManager.getForum(this.forumID);
/*  987 */       dbForum.clearCache();
/*      */     }
/*      */     catch (ForumNotFoundException fnfe)
/*      */     {
/*      */     }
/*      */ 
/*  995 */     Connection con = null;
/*  996 */     PreparedStatement pstmt = null;
/*      */     try {
/*  998 */       con = ConnectionManager.getConnection();
/*  999 */       pstmt = con.prepareStatement("INSERT INTO jiveModeration(objectID, objectType, userID, modDate, modValue) VALUES(?,?,?,?,?)");
/* 1000 */       pstmt.setLong(1, this.id);
/* 1001 */       pstmt.setInt(2, 1);
/* 1002 */       if (authToken.isAnonymous()) {
/* 1003 */         pstmt.setNull(3, -5);
/*      */       }
/*      */       else {
/* 1006 */         pstmt.setLong(3, authToken.getUserID());
/*      */       }
/* 1008 */       pstmt.setLong(4, this.modificationDate.getTime());
/* 1009 */       pstmt.setInt(5, this.moderationValue);
/* 1010 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (Exception e) {
/* 1013 */       Log.error(e);
/*      */     }
/*      */     finally {
/* 1016 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/* 1020 */     Map params = new HashMap();
/* 1021 */     params.put("oldModerationValue", new Integer(oldModerationValue));
/* 1022 */     if (authToken != null) {
/* 1023 */       params.put("moderatorID", new Long(authToken.getUserID()));
/*      */     }
/*      */     else {
/* 1026 */       params.put("moderatorID", new Long(-1L));
/*      */     }
/* 1028 */     ThreadEvent event = new ThreadEvent(113, this, params);
/* 1029 */     ThreadEventDispatcher.getInstance().dispatchEvent(event);
/*      */   }
/*      */ 
/*      */   protected void deleteMessage(DbForumMessage message, Connection con, boolean recursiveDelete)
/*      */     throws SQLException, ForumMessageNotFoundException
/*      */   {
/* 1040 */     if (message == null) {
/* 1041 */       return;
/*      */     }
/*      */ 
/* 1045 */     if (recursiveDelete) {
/* 1046 */       Iterator iter = getTreeWalker().getRecursiveChildren(message);
/* 1047 */       while (iter.hasNext()) {
/* 1048 */         deleteMessage((DbForumMessage)iter.next(), con, false);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1053 */     MessageEvent event = new MessageEvent(101, message, Collections.EMPTY_MAP);
/*      */ 
/* 1055 */     MessageEventDispatcher.getInstance().dispatchEvent(event);
/*      */ 
/* 1057 */     PreparedStatement pstmt = null;
/*      */     try
/*      */     {
/* 1060 */       pstmt = con.prepareStatement("DELETE FROM jiveMessageProp WHERE messageID=?");
/* 1061 */       pstmt.setLong(1, message.getID());
/* 1062 */       pstmt.execute();
/* 1063 */       pstmt.close();
/*      */ 
/* 1066 */       for (Iterator i = message.getAttachments(); i.hasNext(); ) {
/* 1067 */         DbAttachment attachment = (DbAttachment)i.next();
/* 1068 */         attachment.delete(con);
/*      */       }
/*      */ 
/* 1072 */       pstmt = con.prepareStatement("DELETE FROM jiveMessage WHERE messageID=?");
/* 1073 */       pstmt.setLong(1, message.getID());
/* 1074 */       pstmt.execute();
/*      */     }
/*      */     finally {
/* 1077 */       ConnectionManager.closePreparedStatement(pstmt);
/*      */     }
/*      */ 
/* 1081 */     FACTORY.cacheManager.messageRemove(message.getID());
/* 1082 */     String key = "" + this.forumID + "-" + String.valueOf(message.getForumIndex());
/*      */ 
/* 1084 */     FACTORY.cacheManager.forumIndexRemove(key);
/*      */   }
/*      */ 
/*      */   protected int getRewardPoints()
/*      */   {
/* 1091 */     return this.rewardPoints;
/*      */   }
/*      */ 
/*      */   protected void setRewardPoints(int rewardPoints, Connection con)
/*      */     throws SQLException
/*      */   {
/* 1099 */     int oldPoints = this.rewardPoints;
/* 1100 */     this.rewardPoints = rewardPoints;
/*      */     try {
/* 1102 */       saveToDb(con);
/*      */     }
/*      */     catch (SQLException sqle)
/*      */     {
/* 1106 */       this.rewardPoints = oldPoints;
/* 1107 */       throw sqle;
/*      */     }
/*      */ 
/* 1110 */     FACTORY.cacheManager.threadPut(this.id, this);
/*      */   }
/*      */ 
/*      */   protected CachedPreparedStatement getMessageListSQL(ResultFilter resultFilter, boolean countQuery)
/*      */   {
/* 1117 */     int sortField = resultFilter.getSortField();
/*      */ 
/* 1119 */     if ((!countQuery) && (sortField != 9) && (sortField != 8) && (sortField != 6) && ((sortField != 10) || (resultFilter.getSortPropertyName() == null)))
/*      */     {
/* 1128 */       throw new IllegalArgumentException("The specified sort field is not valid.");
/*      */     }
/*      */ 
/* 1131 */     CachedPreparedStatement pstmt = new CachedPreparedStatement();
/*      */ 
/* 1133 */     StringBuffer query = new StringBuffer(160);
/* 1134 */     if (!countQuery) {
/* 1135 */       query.append("SELECT jiveMessage.messageID");
/*      */     }
/*      */     else {
/* 1138 */       query.append("SELECT count(*)");
/*      */     }
/*      */ 
/* 1141 */     boolean filterUser = resultFilter.getUserID() != 2147483524L;
/* 1142 */     boolean filterCreationDate = (resultFilter.getCreationDateRangeMin() != null) || (resultFilter.getCreationDateRangeMax() != null);
/*      */ 
/* 1144 */     boolean filterModifiedDate = (resultFilter.getModificationDateRangeMin() != null) || (resultFilter.getModificationDateRangeMax() != null);
/*      */ 
/* 1146 */     int propertyCount = resultFilter.getPropertyCount();
/*      */ 
/* 1149 */     if (!countQuery) {
/* 1150 */       switch (sortField) {
/*      */       case 6:
/* 1152 */         query.append(", jiveMessage.subject");
/* 1153 */         break;
/*      */       case 9:
/* 1155 */         query.append(", jiveMessage.modificationDate");
/* 1156 */         break;
/*      */       case 8:
/* 1158 */         query.append(", jiveMessage.creationDate");
/* 1159 */         break;
/*      */       case 10:
/* 1161 */         query.append(", propTable.propValue");
/*      */       case 7:
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1167 */     query.append(" FROM jiveMessage");
/* 1168 */     for (int i = 0; i < propertyCount; i++) {
/* 1169 */       query.append(", jiveMessageProp p").append(i);
/*      */     }
/* 1171 */     if (resultFilter.getSortField() == 10) {
/* 1172 */       query.append(", jiveMessageProp propTable");
/*      */     }
/*      */ 
/* 1176 */     query.append(" WHERE jiveMessage.threadID=?");
/* 1177 */     pstmt.addLong(this.id);
/*      */ 
/* 1179 */     if (filterUser) {
/* 1180 */       query.append(" AND jiveMessage.userID=?");
/* 1181 */       pstmt.addLong(resultFilter.getUserID());
/*      */     }
/*      */ 
/* 1184 */     for (int i = 0; i < propertyCount; i++) {
/* 1185 */       query.append(" AND jiveMessage.messageID=p").append(i).append(".messageID");
/* 1186 */       query.append(" AND p").append(i).append(".name=?");
/* 1187 */       pstmt.addString(resultFilter.getPropertyName(i));
/* 1188 */       query.append(" AND p").append(i).append(".propValue=?");
/* 1189 */       pstmt.addString(resultFilter.getPropertyValue(i));
/*      */     }
/*      */ 
/* 1192 */     if (sortField == 10) {
/* 1193 */       query.append(" AND jiveMessage.messageID=propTable.messageID");
/* 1194 */       query.append(" AND propTable.name=?");
/* 1195 */       pstmt.addString(resultFilter.getSortPropertyName());
/*      */     }
/*      */ 
/* 1199 */     if (filterCreationDate) {
/* 1200 */       if (resultFilter.getCreationDateRangeMin() != null) {
/* 1201 */         query.append(" AND jiveMessage.creationDate >= ?");
/* 1202 */         pstmt.addLong(resultFilter.getCreationDateRangeMin().getTime());
/*      */       }
/* 1204 */       if (resultFilter.getCreationDateRangeMax() != null) {
/* 1205 */         query.append(" AND jiveMessage.creationDate <= ?");
/* 1206 */         pstmt.addLong(resultFilter.getCreationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1211 */     if (filterModifiedDate) {
/* 1212 */       if (resultFilter.getModificationDateRangeMin() != null) {
/* 1213 */         query.append(" AND jiveMessage.modificationDate >= ?");
/* 1214 */         pstmt.addLong(resultFilter.getModificationDateRangeMin().getTime());
/*      */       }
/* 1216 */       if (resultFilter.getModificationDateRangeMax() != null) {
/* 1217 */         query.append(" AND jiveMessage.modificationDate <= ?");
/* 1218 */         pstmt.addLong(resultFilter.getModificationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1224 */     if (!FACTORY.moderationDisabled()) {
/* 1225 */       int moderationRangeMin = resultFilter.getModerationRangeMin();
/*      */ 
/* 1228 */       if (moderationRangeMin == 2147483524) {
/* 1229 */         moderationRangeMin = 1;
/*      */       }
/* 1231 */       int moderationRangeMax = resultFilter.getModerationRangeMax();
/* 1232 */       if (moderationRangeMin == moderationRangeMax) {
/* 1233 */         query.append(" AND jiveMessage.modValue = ?");
/* 1234 */         pstmt.addLong(moderationRangeMin);
/*      */       }
/*      */       else
/*      */       {
/* 1238 */         if (moderationRangeMin > -1000000) {
/* 1239 */           query.append(" AND jiveMessage.modValue >= ?");
/* 1240 */           pstmt.addLong(moderationRangeMin);
/*      */         }
/*      */ 
/* 1243 */         if (moderationRangeMax != 2147483524) {
/* 1244 */           query.append(" AND jiveMessage.modValue <= ?");
/* 1245 */           pstmt.addLong(moderationRangeMax);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1251 */     if (!countQuery) {
/* 1252 */       switch (sortField) {
/*      */       case 6:
/* 1254 */         query.append(" ORDER BY jiveMessage.subject");
/* 1255 */         break;
/*      */       case 9:
/* 1257 */         query.append(" ORDER BY jiveMessage.modificationDate");
/* 1258 */         break;
/*      */       case 8:
/* 1260 */         query.append(" ORDER BY jiveMessage.creationDate");
/* 1261 */         break;
/*      */       case 10:
/* 1263 */         query.append(" ORDER BY propTable.propValue");
/*      */       case 7:
/*      */       }
/* 1266 */       if (resultFilter.getSortOrder() == 0) {
/* 1267 */         query.append(" DESC");
/*      */       }
/*      */       else {
/* 1270 */         query.append(" ASC");
/*      */       }
/*      */     }
/*      */ 
/* 1274 */     pstmt.setSQL(query.toString());
/* 1275 */     return pstmt;
/*      */   }
/*      */ 
/*      */   protected void clearCache()
/*      */   {
/* 1282 */     FACTORY.cacheManager.queryRemove(1, this.id);
/*      */   }
/*      */ 
/*      */   private void fixModificationDate()
/*      */   {
/* 1292 */     Connection con = null;
/*      */     try {
/* 1294 */       con = ConnectionManager.getConnection();
/* 1295 */       fixModificationDate(con);
/*      */     }
/*      */     catch (Exception e) {
/* 1298 */       Log.error(e);
/*      */     }
/*      */     finally {
/* 1301 */       ConnectionManager.closeConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void fixModificationDate(Connection con)
/*      */     throws SQLException
/*      */   {
/* 1312 */     Profiler.begin("fixModificationDate");
/* 1313 */     PreparedStatement pstmt = null;
/*      */     try
/*      */     {
/* 1316 */       pstmt = con.prepareStatement("SELECT max(modificationDate) FROM jiveMessage WHERE threadID=?");
/* 1317 */       pstmt.setLong(1, this.id);
/* 1318 */       ResultSet rs = pstmt.executeQuery();
/* 1319 */       rs.next();
/* 1320 */       long newestMsg = Long.parseLong(rs.getString(1).trim());
/* 1321 */       rs.close();
/* 1322 */       if (this.modificationDate.getTime() != newestMsg) {
/* 1323 */         this.modificationDate.setTime(newestMsg);
/* 1324 */         pstmt.close();
/* 1325 */         pstmt = con.prepareStatement("UPDATE jiveThread SET modificationDate=? WHERE threadID=?");
/* 1326 */         pstmt.setLong(1, this.modificationDate.getTime());
/* 1327 */         pstmt.setLong(2, this.id);
/* 1328 */         pstmt.executeUpdate();
/*      */       }
/*      */     }
/*      */     finally {
/* 1332 */       ConnectionManager.closePreparedStatement(pstmt);
/*      */     }
/*      */ 
/* 1336 */     FACTORY.cacheManager.threadPut(this.id, this);
/* 1337 */     Profiler.end("fixModificationDate");
/*      */   }
/*      */ 
/*      */   private void loadFromDb()
/*      */     throws ForumThreadNotFoundException
/*      */   {
/* 1344 */     Profiler.begin("threadLoadFromDb");
/* 1345 */     if (this.id < 0L) {
/* 1346 */       throw new ForumThreadNotFoundException("Thread " + this.id + " is not valid.");
/*      */     }
/* 1348 */     Connection con = null;
/* 1349 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1351 */       con = ConnectionManager.getConnection();
/*      */ 
/* 1353 */       pstmt = con.prepareStatement("SELECT forumID, rootMessageID, modValue, rewardPoints, creationDate, modificationDate FROM jiveThread WHERE threadID=?");
/* 1354 */       pstmt.setLong(1, this.id);
/* 1355 */       ResultSet rs = pstmt.executeQuery();
/* 1356 */       if (!rs.next()) {
/* 1357 */         rs.close();
/* 1358 */         throw new ForumThreadNotFoundException("Thread " + this.id + " could not be loaded from the database.");
/*      */       }
/*      */ 
/* 1361 */       this.forumID = rs.getLong(1);
/* 1362 */       this.rootMessageID = rs.getLong(2);
/* 1363 */       this.moderationValue = rs.getInt(3);
/* 1364 */       this.rewardPoints = rs.getInt(4);
/* 1365 */       this.creationDate = new Date(rs.getLong(5));
/* 1366 */       this.modificationDate = new Date(rs.getLong(6));
/* 1367 */       rs.close();
/*      */     }
/*      */     catch (SQLException sqle)
/*      */     {
/* 1383 */       Log.error(sqle);
/* 1384 */       throw new ForumThreadNotFoundException("Thread " + this.id + " could not be loaded from the database.");
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/* 1388 */       Log.warn("WARNING: In DbForumThread.loadFromDb() -- there was an error parsing the dates returned from the database. Ensure that they're being stored correctly.");
/*      */     }
/*      */     finally
/*      */     {
/* 1393 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/* 1395 */     Profiler.end("threadLoadFromDb");
/*      */   }
/*      */ 
/*      */   protected void prepareInsertIntoDb(DbForum forum)
/*      */     throws SQLException, UnauthorizedException
/*      */   {
/* 1411 */     if (this.forumID != forum.getID()) {
/* 1412 */       throw new UnauthorizedException("Thread created in forum " + this.forumID + " cannot be added to forum " + forum.getID());
/*      */     }
/*      */ 
/* 1416 */     this.id = SequenceManager.nextID(1);
/*      */   }
/*      */ 
/*      */   protected void insertIntoDb(DbForum forum, Connection con)
/*      */     throws SQLException, UnauthorizedException
/*      */   {
/* 1430 */     Profiler.begin("insertThread");
/*      */ 
/* 1432 */     if (this.forumID != forum.getID()) {
/* 1433 */       throw new UnauthorizedException("Thread created in forum " + this.forumID + " cannot be added to forum " + forum.getID());
/*      */     }
/*      */ 
/* 1440 */     boolean newMessage = this.rootMessage.getForumThread() == null;
/*      */ 
/* 1443 */     DbForumMessage dbMessage = (DbForumMessage)this.rootMessage;
/*      */ 
/* 1446 */     this.rootMessageID = dbMessage.getID();
/*      */ 
/* 1450 */     DbForumThread oldThread = (DbForumThread)dbMessage.getForumThread();
/*      */ 
/* 1452 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1454 */       Profiler.begin("insertSql");
/* 1455 */       pstmt = con.prepareStatement("INSERT INTO jiveThread(threadID,forumID,rootMessageID,modValue, rewardPoints,creationDate,modificationDate) VALUES(?,?,?,?,?,?,?)");
/* 1456 */       pstmt.setLong(1, this.id);
/* 1457 */       pstmt.setLong(2, forum.getID());
/* 1458 */       pstmt.setLong(3, this.rootMessageID);
/* 1459 */       pstmt.setInt(4, this.moderationValue);
/* 1460 */       pstmt.setInt(5, this.rewardPoints);
/* 1461 */       pstmt.setLong(6, this.creationDate.getTime());
/* 1462 */       pstmt.setLong(7, this.modificationDate.getTime());
/* 1463 */       pstmt.executeUpdate();
/*      */     }
/*      */     finally {
/* 1466 */       ConnectionManager.closePreparedStatement(pstmt);
/* 1467 */       Profiler.end("insertSql");
/*      */     }
/*      */ 
/* 1470 */     if (newMessage)
/*      */     {
/* 1472 */       dbMessage.insertIntoDb(this, -1L, con);
/*      */     }
/*      */     else
/*      */     {
/* 1477 */       dbMessage.moveMessage(this, -1L, con);
/*      */ 
/* 1481 */       oldThread.fixModificationDate(con);
/*      */     }
/*      */ 
/* 1485 */     for (Iterator i = this.properties.keySet().iterator(); i.hasNext(); ) {
/* 1486 */       String name = (String)i.next();
/* 1487 */       String value = (String)this.properties.get(name);
/* 1488 */       insertPropertyIntoDb(name, value, con);
/*      */     }
/*      */ 
/* 1492 */     this.rootMessage = null;
/*      */ 
/* 1496 */     this.readyToSave = true;
/* 1497 */     Profiler.end("insertThread");
/*      */   }
/*      */ 
/*      */   private synchronized void saveToDb()
/*      */   {
/* 1504 */     Connection con = null;
/*      */     try {
/* 1506 */       con = ConnectionManager.getConnection();
/* 1507 */       saveToDb(con);
/*      */     }
/*      */     catch (SQLException sqle) {
/* 1510 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/* 1513 */       ConnectionManager.closeConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void saveToDb(Connection con)
/*      */     throws SQLException
/*      */   {
/* 1522 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1524 */       pstmt = con.prepareStatement("UPDATE jiveThread SET rootMessageID=?, modValue=?, rewardPoints=?, creationDate=?, modificationDate=? WHERE threadID=?");
/* 1525 */       pstmt.setLong(1, getRootMessage().getID());
/* 1526 */       pstmt.setInt(2, this.moderationValue);
/* 1527 */       pstmt.setInt(3, this.rewardPoints);
/* 1528 */       pstmt.setLong(4, this.creationDate.getTime());
/* 1529 */       pstmt.setLong(5, this.modificationDate.getTime());
/* 1530 */       pstmt.setLong(6, this.id);
/* 1531 */       pstmt.executeUpdate();
/*      */     }
/*      */     finally {
/* 1534 */       ConnectionManager.closePreparedStatement(pstmt);
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void loadPropertiesFromDb()
/*      */   {
/* 1542 */     this.properties = new Hashtable();
/* 1543 */     Connection con = null;
/* 1544 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1546 */       con = ConnectionManager.getConnection();
/* 1547 */       pstmt = con.prepareStatement("SELECT name, propValue FROM jiveThreadProp WHERE threadID=?");
/* 1548 */       pstmt.setLong(1, this.id);
/* 1549 */       ResultSet rs = pstmt.executeQuery();
/* 1550 */       while (rs.next()) {
/* 1551 */         this.properties.put(rs.getString(1), rs.getString(2));
/*      */       }
/* 1553 */       rs.close();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 1556 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/* 1559 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/* 1563 */     FACTORY.cacheManager.threadPut(this.id, this);
/*      */   }
/*      */ 
/*      */   private void insertPropertyIntoDb(String name, String value, Connection con)
/*      */     throws SQLException
/*      */   {
/* 1570 */     Profiler.begin("propInsert");
/* 1571 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1573 */       pstmt = con.prepareStatement("INSERT INTO jiveThreadProp(threadID,name,propValue) VALUES(?,?,?)");
/* 1574 */       pstmt.setLong(1, this.id);
/* 1575 */       pstmt.setString(2, name);
/* 1576 */       pstmt.setString(3, value);
/* 1577 */       pstmt.executeUpdate();
/*      */     }
/*      */     finally {
/* 1580 */       ConnectionManager.closePreparedStatement(pstmt);
/* 1581 */       Profiler.end("propInsert");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void updatePropertyInDb(String name, String value)
/*      */   {
/* 1589 */     Connection con = null;
/* 1590 */     PreparedStatement pstmt = null;
/* 1591 */     boolean abortTransaction = false;
/*      */     try {
/* 1593 */       con = ConnectionManager.getTransactionConnection();
/* 1594 */       pstmt = con.prepareStatement("UPDATE jiveThreadProp SET propValue=? WHERE name=? AND threadID=?");
/* 1595 */       pstmt.setString(1, value);
/* 1596 */       pstmt.setString(2, name);
/* 1597 */       pstmt.setLong(3, this.id);
/* 1598 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 1601 */       Log.error(sqle);
/* 1602 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/* 1605 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void deletePropertyFromDb(String name)
/*      */   {
/* 1613 */     Connection con = null;
/* 1614 */     PreparedStatement pstmt = null;
/* 1615 */     boolean abortTransaction = false;
/*      */     try {
/* 1617 */       con = ConnectionManager.getTransactionConnection();
/* 1618 */       pstmt = con.prepareStatement("DELETE FROM jiveThreadProp WHERE threadID=? AND name=?");
/* 1619 */       pstmt.setLong(1, this.id);
/* 1620 */       pstmt.setString(2, name);
/* 1621 */       pstmt.execute();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 1624 */       Log.error(sqle);
/* 1625 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/* 1628 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbForumThread
 * JD-Core Version:    0.6.2
 */
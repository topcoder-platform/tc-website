/*     */ package com.jivesoftware.forum.stats;
/*     */ 
/*     */ import com.jivesoftware.base.stats.ReadStatSession;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class NNTPReadStatSession extends ReadStatSession
/*     */ {
/*     */   private Date endDate;
/*  27 */   private long bytesReceived = -1L;
/*  28 */   private long bytesSent = -1L;
/*     */   private String ip;
/*     */   private String country;
/*     */ 
/*     */   public NNTPReadStatSession()
/*     */   {
/*     */   }
/*     */ 
/*     */   public NNTPReadStatSession(String visitorID, Date creationDate, String ip, String country)
/*     */   {
/*  35 */     super(visitorID, creationDate);
/*  36 */     this.ip = ip;
/*  37 */     this.country = country;
/*     */   }
/*     */ 
/*     */   public NNTPReadStatSession(String visitorID, Date creationDate, Date endDate, String ip, String country) {
/*  41 */     super(visitorID, creationDate);
/*  42 */     this.endDate = endDate;
/*  43 */     this.ip = ip;
/*  44 */     this.country = country;
/*     */   }
/*     */ 
/*     */   public Date getEndDate()
/*     */   {
/*  52 */     return this.endDate;
/*     */   }
/*     */ 
/*     */   public void setEndDate(Date endDate) {
/*  56 */     this.endDate = endDate;
/*     */   }
/*     */ 
/*     */   public long getBytesReceived()
/*     */   {
/*  64 */     return this.bytesReceived;
/*     */   }
/*     */ 
/*     */   public String getIP()
/*     */   {
/*  72 */     return this.ip;
/*     */   }
/*     */ 
/*     */   public String getCountry()
/*     */   {
/*  80 */     if ((this.country != null) && ("--".equals(this.country))) {
/*  81 */       return null;
/*     */     }
/*  83 */     return this.country;
/*     */   }
/*     */ 
/*     */   public void updateBytesReceived(long newBytesReceived)
/*     */   {
/*  91 */     if (newBytesReceived > 0L) {
/*  92 */       if (this.bytesReceived == -1L) {
/*  93 */         this.bytesReceived = 0L;
/*     */       }
/*  95 */       this.bytesReceived += newBytesReceived;
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getBytesSent()
/*     */   {
/* 104 */     return this.bytesSent;
/*     */   }
/*     */ 
/*     */   public void updateBytesSent(long newBytesSent)
/*     */   {
/* 112 */     if (newBytesSent > 0L) {
/* 113 */       if (this.bytesSent == -1L) {
/* 114 */         this.bytesSent = 0L;
/*     */       }
/* 116 */       this.bytesSent += newBytesSent;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.NNTPReadStatSession
 * JD-Core Version:    0.6.2
 */
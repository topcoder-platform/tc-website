/*    */ package com.jivesoftware.forum.action.rss;
/*    */ 
/*    */ import com.jivesoftware.base.action.rss.RSSActionSupport;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.util.SkinUtils;
/*    */ import com.jivesoftware.util.LocaleUtils;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class RSSPopularForums extends RSSActionSupport
/*    */ {
/*    */   private Iterator forums;
/*    */ 
/*    */   public Iterator getForums()
/*    */   {
/* 36 */     if (this.forums == null) {
/* 37 */       return Collections.EMPTY_LIST.iterator();
/*    */     }
/* 39 */     return this.forums;
/*    */   }
/*    */ 
/*    */   public String getFeedTitle() {
/* 43 */     List args = new ArrayList();
/* 44 */     args.add(SkinUtils.getCommunityName());
/* 45 */     return LocaleUtils.getLocalizedString("rss.popularforums", getLocale(), args);
/*    */   }
/*    */ 
/*    */   public String executeRSS()
/*    */   {
/* 50 */     ForumFactory forumFactory = ForumFactory.getInstance(getAuthToken());
/* 51 */     this.forums = forumFactory.getPopularForums();
/*    */ 
/* 53 */     if (hasErrors()) {
/* 54 */       return "error";
/*    */     }
/* 56 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.rss.RSSPopularForums
 * JD-Core Version:    0.6.2
 */
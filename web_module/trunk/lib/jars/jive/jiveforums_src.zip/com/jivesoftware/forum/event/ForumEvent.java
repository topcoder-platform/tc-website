/*    */ package com.jivesoftware.forum.event;
/*    */ 
/*    */ import com.jivesoftware.base.JiveEvent;
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import java.util.Collections;
/*    */ import java.util.Date;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ForumEvent
/*    */   implements JiveEvent
/*    */ {
/*    */   public static final int FORUM_ADDED = 120;
/*    */   public static final int FORUM_DELETING = 121;
/*    */   public static final int FORUM_MOVED = 122;
/*    */   public static final int FORUM_MERGED = 123;
/*    */   private int eventType;
/*    */   private Forum forum;
/*    */   private Date date;
/*    */   private Map params;
/*    */ 
/*    */   public ForumEvent(int eventType, Forum forum, Map params)
/*    */   {
/* 75 */     this.eventType = eventType;
/* 76 */     this.forum = forum;
/* 77 */     this.params = (params == null ? null : Collections.unmodifiableMap(params));
/* 78 */     this.date = new Date();
/*    */   }
/*    */ 
/*    */   public int getEventType() {
/* 82 */     return this.eventType;
/*    */   }
/*    */ 
/*    */   public Forum getForum()
/*    */   {
/* 91 */     return this.forum;
/*    */   }
/*    */ 
/*    */   public Map getParams() {
/* 95 */     return this.params;
/*    */   }
/*    */ 
/*    */   public Date getDate() {
/* 99 */     return this.date;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.ForumEvent
 * JD-Core Version:    0.6.2
 */
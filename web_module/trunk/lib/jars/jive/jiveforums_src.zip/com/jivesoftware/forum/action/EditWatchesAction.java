/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.Watch;
/*     */ import com.jivesoftware.forum.WatchManager;
/*     */ import com.opensymphony.webwork.ServletActionContext;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class EditWatchesAction extends ForumActionSupport
/*     */ {
/*  27 */   private boolean updateCatWatch = false;
/*  28 */   private boolean deleteCatWatch = false;
/*  29 */   private boolean updateForumWatch = false;
/*  30 */   private boolean deleteForumWatch = false;
/*  31 */   private boolean updateThreadWatch = false;
/*  32 */   private boolean deleteThreadWatch = false;
/*  33 */   private boolean updateUserWatch = false;
/*  34 */   private boolean deleteUserWatch = false;
/*     */   private WatchManager manager;
/*     */ 
/*     */   public void setUpdateCatWatch(String updateCatWatch)
/*     */   {
/*  43 */     this.updateCatWatch = true;
/*     */   }
/*     */ 
/*     */   public void setDeleteCatWatch(String deleteCatWatch) {
/*  47 */     this.deleteCatWatch = true;
/*     */   }
/*     */ 
/*     */   public void setUpdateForumWatch(String updateForumWatch) {
/*  51 */     this.updateForumWatch = true;
/*     */   }
/*     */ 
/*     */   public void setDeleteForumWatch(String deleteForumWatch) {
/*  55 */     this.deleteForumWatch = true;
/*     */   }
/*     */ 
/*     */   public void setUpdateThreadWatch(String updateThreadWatch) {
/*  59 */     this.updateThreadWatch = true;
/*     */   }
/*     */ 
/*     */   public void setDeleteThreadWatch(String deleteThreadWatch) {
/*  63 */     this.deleteThreadWatch = true;
/*     */   }
/*     */ 
/*     */   public void setUpdateUserWatch(String updateUserWatch) {
/*  67 */     this.updateUserWatch = true;
/*     */   }
/*     */ 
/*     */   public void setDeleteUserWatch(String deleteUserWatch) {
/*  71 */     this.deleteUserWatch = true;
/*     */   }
/*     */ 
/*     */   public WatchManager getWatchManager()
/*     */   {
/*  77 */     return this.manager;
/*     */   }
/*     */ 
/*     */   protected void setWatchManager(WatchManager manager) {
/*  81 */     this.manager = manager;
/*     */   }
/*     */ 
/*     */   public Iterator getWatchedCategories()
/*     */   {
/*     */     try
/*     */     {
/*  88 */       return this.manager.getAllWatches(getPageUser(), 14);
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/*  91 */       Log.error(ue);
/*  92 */     }return Collections.EMPTY_LIST.iterator();
/*     */   }
/*     */ 
/*     */   public int getWatchedCategoryCount()
/*     */   {
/*     */     try {
/*  98 */       return this.manager.getTotalWatchCount(getPageUser(), 14);
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 101 */       Log.error(ue);
/* 102 */     }return 0;
/*     */   }
/*     */ 
/*     */   public Iterator getWatchedForums()
/*     */   {
/*     */     try {
/* 108 */       return this.manager.getAllWatches(getPageUser(), 0);
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 111 */       Log.error(ue);
/* 112 */     }return Collections.EMPTY_LIST.iterator();
/*     */   }
/*     */ 
/*     */   public int getWatchedForumCount()
/*     */   {
/*     */     try {
/* 118 */       return this.manager.getTotalWatchCount(getPageUser(), 0);
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 121 */       Log.error(ue);
/* 122 */     }return 0;
/*     */   }
/*     */ 
/*     */   public Iterator getWatchedThreads()
/*     */   {
/*     */     try {
/* 128 */       return this.manager.getAllWatches(getPageUser(), 1);
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 131 */       Log.error(ue);
/* 132 */     }return Collections.EMPTY_LIST.iterator();
/*     */   }
/*     */ 
/*     */   public int getWatchedThreadCount()
/*     */   {
/*     */     try {
/* 138 */       return this.manager.getTotalWatchCount(getPageUser(), 1);
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 141 */       Log.error(ue);
/* 142 */     }return 0;
/*     */   }
/*     */ 
/*     */   public Iterator getWatchedUsers()
/*     */   {
/*     */     try {
/* 148 */       return this.manager.getAllWatches(getPageUser(), 3);
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 151 */       Log.error(ue);
/* 152 */     }return Collections.EMPTY_LIST.iterator();
/*     */   }
/*     */ 
/*     */   public int getWatchedUserCount()
/*     */   {
/*     */     try {
/* 158 */       return this.manager.getTotalWatchCount(getPageUser(), 3);
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 161 */       Log.error(ue);
/* 162 */     }return 0;
/*     */   }
/*     */ 
/*     */   public boolean getHasEmailWatch(Object obj)
/*     */   {
/*     */     try {
/* 168 */       Watch watch = null;
/* 169 */       if ((obj instanceof ForumCategory)) {
/* 170 */         watch = this.manager.getWatch(getPageUser(), (ForumCategory)obj);
/*     */       }
/* 172 */       else if ((obj instanceof Forum)) {
/* 173 */         watch = this.manager.getWatch(getPageUser(), (Forum)obj);
/*     */       }
/* 175 */       else if ((obj instanceof ForumThread)) {
/* 176 */         watch = this.manager.getWatch(getPageUser(), (ForumThread)obj);
/*     */       }
/* 178 */       else if ((obj instanceof User)) {
/* 179 */         watch = this.manager.getWatch(getPageUser(), (User)obj);
/*     */       }
/* 181 */       return (watch.getWatchType() == 1) || (watch.getWatchType() == 2);
/*     */     }
/*     */     catch (UnauthorizedException ue)
/*     */     {
/* 185 */       Log.error(ue);
/*     */     }
/* 187 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean getIsExpirableWatch(Object obj) {
/*     */     try {
/* 192 */       Watch watch = null;
/* 193 */       if ((obj instanceof ForumCategory)) {
/* 194 */         watch = this.manager.getWatch(getPageUser(), (ForumCategory)obj);
/*     */       }
/* 196 */       else if ((obj instanceof Forum)) {
/* 197 */         watch = this.manager.getWatch(getPageUser(), (Forum)obj);
/*     */       }
/* 199 */       else if ((obj instanceof ForumThread)) {
/* 200 */         watch = this.manager.getWatch(getPageUser(), (ForumThread)obj);
/*     */       }
/* 202 */       else if ((obj instanceof User)) {
/* 203 */         watch = this.manager.getWatch(getPageUser(), (User)obj);
/*     */       }
/* 205 */       return watch.isExpirable();
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 208 */       Log.error(ue);
/*     */     }
/* 210 */     return false;
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/* 221 */     if (!loadJiveObjects()) {
/* 222 */       return "error";
/*     */     }
/*     */ 
/* 226 */     if (getPageUser() == null) {
/* 227 */       setLoginAttributes();
/* 228 */       addActionError(getText("watches.error_unauth"));
/* 229 */       return "login";
/*     */     }
/*     */ 
/* 233 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 241 */     if (!loadJiveObjects()) {
/* 242 */       return "error";
/*     */     }
/*     */ 
/* 246 */     if (getPageUser() == null) {
/* 247 */       setLoginAttributes();
/* 248 */       addActionError(getText("watches.error_unauth"));
/* 249 */       return "login";
/*     */     }
/*     */ 
/* 253 */     if (this.deleteCatWatch)
/*     */     {
/* 255 */       List catIDs = getIDs("delete", "cat");
/* 256 */       for (int i = 0; i < catIDs.size(); i++) {
/* 257 */         long catID = ((Long)catIDs.get(i)).longValue();
/*     */         try {
/* 259 */           ForumCategory cat = getForumFactory().getForumCategory(catID);
/* 260 */           Watch watch = this.manager.getWatch(getPageUser(), cat);
/* 261 */           this.manager.deleteWatch(watch);
/*     */         } catch (ForumCategoryNotFoundException e) {
/* 263 */           Log.error(e);
/*     */         } catch (UnauthorizedException e) {
/* 265 */           setLoginAttributes();
/* 266 */           addActionError(getText("watches.error_unauth"));
/* 267 */           return "login";
/*     */         }
/*     */       }
/*     */ 
/* 271 */       return "success";
/*     */     }
/* 273 */     if (this.deleteForumWatch)
/*     */     {
/* 275 */       List forumIDs = getIDs("delete", "forum");
/* 276 */       for (int i = 0; i < forumIDs.size(); i++) {
/* 277 */         long forumID = ((Long)forumIDs.get(i)).longValue();
/*     */         try {
/* 279 */           Forum forum = getForumFactory().getForum(forumID);
/* 280 */           Watch watch = this.manager.getWatch(getPageUser(), forum);
/* 281 */           this.manager.deleteWatch(watch);
/*     */         } catch (ForumNotFoundException e) {
/* 283 */           Log.error(e);
/*     */         } catch (UnauthorizedException e) {
/* 285 */           setLoginAttributes();
/* 286 */           addActionError(getText("watches.error_unauth"));
/* 287 */           return "login";
/*     */         }
/*     */       }
/* 290 */       return "success";
/*     */     }
/* 292 */     if (this.deleteThreadWatch)
/*     */     {
/* 294 */       List IDs = getIDs("delete", "thread");
/* 295 */       for (int i = 0; i < IDs.size(); i++) {
/* 296 */         long threadID = ((Long)IDs.get(i)).longValue();
/*     */         try {
/* 298 */           ForumThread thread = getForumFactory().getForumThread(threadID);
/* 299 */           Watch watch = this.manager.getWatch(getPageUser(), thread);
/* 300 */           this.manager.deleteWatch(watch);
/*     */         } catch (ForumThreadNotFoundException e) {
/* 302 */           Log.error(e);
/*     */         } catch (UnauthorizedException e) {
/* 304 */           setLoginAttributes();
/* 305 */           addActionError(getText("watches.error_unauth"));
/* 306 */           return "login";
/*     */         }
/*     */       }
/*     */ 
/* 310 */       return "success";
/*     */     }
/* 312 */     if (this.deleteUserWatch)
/*     */     {
/* 314 */       List userIDs = getIDs("delete", "user");
/* 315 */       for (int i = 0; i < userIDs.size(); i++) {
/* 316 */         long userID = ((Long)userIDs.get(i)).longValue();
/*     */         try {
/* 318 */           User user = getForumFactory().getUserManager().getUser(userID);
/* 319 */           Watch watch = this.manager.getWatch(getPageUser(), user);
/* 320 */           this.manager.deleteWatch(watch);
/*     */         } catch (UserNotFoundException e) {
/* 322 */           Log.error(e);
/*     */         } catch (UnauthorizedException e) {
/* 324 */           setLoginAttributes();
/* 325 */           addActionError(getText("watches.error_unauth"));
/* 326 */           return "login";
/*     */         }
/*     */       }
/*     */ 
/* 330 */       return "success";
/*     */     }
/*     */ 
/* 333 */     boolean batch = false;
/*     */     try
/*     */     {
/* 336 */       batch = getForumFactory().getWatchManager().getBatchTimer(getPageUser()) != null;
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 340 */       Log.error(e);
/*     */     }
/*     */ 
/* 345 */     if (this.updateCatWatch) {
/* 346 */       List catIDs = getIDs("email", "cat");
/* 347 */       for (int i = 0; i < catIDs.size(); i++) {
/* 348 */         long catID = ((Long)catIDs.get(i)).longValue();
/*     */         try {
/* 350 */           ForumCategory cat = getForumFactory().getForumCategory(catID);
/* 351 */           Watch watch = this.manager.getWatch(getPageUser(), cat);
/* 352 */           if ((!batch) && (watch.getWatchType() != 1)) {
/* 353 */             watch.setWatchType(1);
/*     */           }
/* 355 */           else if ((batch) && (watch.getWatchType() != 2))
/* 356 */             watch.setWatchType(2);
/*     */         }
/*     */         catch (ForumCategoryNotFoundException e) {
/* 359 */           Log.error(e);
/*     */         } catch (UnauthorizedException e) {
/* 361 */           setLoginAttributes();
/* 362 */           addActionError(getText("watches.error_unauth"));
/* 363 */           return "login";
/*     */         }
/*     */       }
/* 366 */       catIDs = getIDs("save", "cat");
/*     */       try {
/* 368 */         for (iter = this.manager.getAllWatches(getPageUser(), 14); iter.hasNext(); ) {
/* 369 */           Watch watch = this.manager.getWatch(getPageUser(), (ForumCategory)iter.next());
/* 370 */           if (!catIDs.contains(new Long(watch.getObjectID())))
/* 371 */             watch.setExpirable(true);
/*     */         }
/*     */       }
/*     */       catch (UnauthorizedException e)
/*     */       {
/*     */         Iterator iter;
/* 376 */         setLoginAttributes();
/* 377 */         addActionError(getText("watches.error_unauth"));
/* 378 */         return "login";
/*     */       }
/*     */ 
/* 381 */       for (int i = 0; i < catIDs.size(); i++) {
/* 382 */         long catID = ((Long)catIDs.get(i)).longValue();
/*     */         try {
/* 384 */           ForumCategory cat = getForumFactory().getForumCategory(catID);
/* 385 */           Watch watch = this.manager.getWatch(getPageUser(), cat);
/* 386 */           watch.setExpirable(false);
/*     */         } catch (Exception ignored) {
/*     */         }
/*     */       }
/* 390 */       return "success";
/*     */     }
/* 392 */     if (this.updateForumWatch) {
/* 393 */       List forumIDs = getIDs("email", "forum");
/* 394 */       for (int i = 0; i < forumIDs.size(); i++) {
/* 395 */         long forumID = ((Long)forumIDs.get(i)).longValue();
/*     */         try {
/* 397 */           Forum forum = getForumFactory().getForum(forumID);
/* 398 */           Watch watch = this.manager.getWatch(getPageUser(), forum);
/* 399 */           if ((!batch) && (watch.getWatchType() != 1)) {
/* 400 */             watch.setWatchType(1);
/*     */           }
/* 402 */           else if ((batch) && (watch.getWatchType() != 2))
/* 403 */             watch.setWatchType(2);
/*     */         }
/*     */         catch (ForumNotFoundException e) {
/* 406 */           Log.error(e);
/*     */         } catch (UnauthorizedException e) {
/* 408 */           setLoginAttributes();
/* 409 */           addActionError(getText("watches.error_unauth"));
/* 410 */           return "login";
/*     */         }
/*     */       }
/*     */ 
/* 414 */       forumIDs = getIDs("save", "forum");
/*     */       try {
/* 416 */         for (iter = this.manager.getAllWatches(getPageUser(), 0); iter.hasNext(); ) {
/* 417 */           Watch watch = this.manager.getWatch(getPageUser(), (Forum)iter.next());
/* 418 */           if (!forumIDs.contains(new Long(watch.getObjectID())))
/* 419 */             watch.setExpirable(true);
/*     */         }
/*     */       }
/*     */       catch (UnauthorizedException e)
/*     */       {
/*     */         Iterator iter;
/* 424 */         setLoginAttributes();
/* 425 */         addActionError(getText("watches.error_unauth"));
/* 426 */         return "login";
/*     */       }
/*     */ 
/* 429 */       for (int i = 0; i < forumIDs.size(); i++) {
/* 430 */         long forumID = ((Long)forumIDs.get(i)).longValue();
/*     */         try {
/* 432 */           Forum forum = getForumFactory().getForum(forumID);
/* 433 */           Watch watch = this.manager.getWatch(getPageUser(), forum);
/* 434 */           watch.setExpirable(false);
/*     */         } catch (ForumNotFoundException e) {
/* 436 */           Log.error(e);
/*     */         } catch (UnauthorizedException e) {
/* 438 */           setLoginAttributes();
/* 439 */           addActionError(getText("watches.error_unauth"));
/* 440 */           return "login";
/*     */         }
/*     */       }
/* 443 */       return "success";
/*     */     }
/* 445 */     if (this.updateThreadWatch) {
/* 446 */       List IDs = getIDs("email", "thread");
/* 447 */       for (int i = 0; i < IDs.size(); i++) {
/* 448 */         long threadID = ((Long)IDs.get(i)).longValue();
/*     */         try {
/* 450 */           ForumThread thread = getForumFactory().getForumThread(threadID);
/* 451 */           Watch watch = this.manager.getWatch(getPageUser(), thread);
/* 452 */           if ((!batch) && (watch.getWatchType() != 1)) {
/* 453 */             watch.setWatchType(1);
/*     */           }
/* 455 */           else if ((batch) && (watch.getWatchType() != 2))
/* 456 */             watch.setWatchType(2);
/*     */         }
/*     */         catch (ForumThreadNotFoundException e) {
/* 459 */           Log.error(e);
/*     */         } catch (UnauthorizedException e) {
/* 461 */           setLoginAttributes();
/* 462 */           addActionError(getText("watches.error_unauth"));
/* 463 */           return "login";
/*     */         }
/*     */       }
/*     */ 
/* 467 */       IDs = getIDs("save", "thread");
/*     */       try {
/* 469 */         for (iter = this.manager.getAllWatches(getPageUser(), 1); iter.hasNext(); ) {
/* 470 */           Watch watch = this.manager.getWatch(getPageUser(), (ForumThread)iter.next());
/* 471 */           if (!IDs.contains(new Long(watch.getObjectID())))
/* 472 */             watch.setExpirable(true);
/*     */         }
/*     */       }
/*     */       catch (UnauthorizedException e)
/*     */       {
/*     */         Iterator iter;
/* 477 */         setLoginAttributes();
/* 478 */         addActionError(getText("watches.error_unauth"));
/* 479 */         return "login";
/*     */       }
/*     */ 
/* 482 */       for (int i = 0; i < IDs.size(); i++) {
/* 483 */         long threadID = ((Long)IDs.get(i)).longValue();
/*     */         try {
/* 485 */           ForumThread thread = getForumFactory().getForumThread(threadID);
/* 486 */           Watch watch = this.manager.getWatch(getPageUser(), thread);
/* 487 */           watch.setExpirable(false);
/*     */         } catch (ForumThreadNotFoundException e) {
/* 489 */           Log.error(e);
/*     */         } catch (UnauthorizedException e) {
/* 491 */           setLoginAttributes();
/* 492 */           addActionError(getText("watches.error_unauth"));
/* 493 */           return "login";
/*     */         }
/*     */       }
/* 496 */       return "success";
/*     */     }
/* 498 */     if (this.updateUserWatch) {
/* 499 */       List userIDs = getIDs("email", "user");
/* 500 */       for (int i = 0; i < userIDs.size(); i++) {
/* 501 */         long userID = ((Long)userIDs.get(i)).longValue();
/*     */         try {
/* 503 */           User user = getForumFactory().getUserManager().getUser(userID);
/* 504 */           Watch watch = this.manager.getWatch(getPageUser(), user);
/* 505 */           if ((!batch) && (watch.getWatchType() != 1)) {
/* 506 */             watch.setWatchType(1);
/*     */           }
/* 508 */           else if ((batch) && (watch.getWatchType() != 2))
/* 509 */             watch.setWatchType(2);
/*     */         }
/*     */         catch (UserNotFoundException e) {
/* 512 */           Log.error(e);
/*     */         } catch (UnauthorizedException e) {
/* 514 */           setLoginAttributes();
/* 515 */           addActionError(getText("watches.error_unauth"));
/* 516 */           return "login";
/*     */         }
/*     */       }
/*     */ 
/* 520 */       userIDs = getIDs("save", "user");
/*     */       try {
/* 522 */         for (iter = this.manager.getAllWatches(getPageUser(), 3); iter.hasNext(); ) {
/* 523 */           Watch watch = this.manager.getWatch(getPageUser(), (User)iter.next());
/* 524 */           if (!userIDs.contains(new Long(watch.getObjectID())))
/* 525 */             watch.setExpirable(true);
/*     */         }
/*     */       }
/*     */       catch (UnauthorizedException e)
/*     */       {
/*     */         Iterator iter;
/* 530 */         setLoginAttributes();
/* 531 */         addActionError(getText("watches.error_unauth"));
/* 532 */         return "login";
/*     */       }
/* 534 */       for (int i = 0; i < userIDs.size(); i++) {
/* 535 */         long userID = ((Long)userIDs.get(i)).longValue();
/*     */         try {
/* 537 */           User user = getForumFactory().getUserManager().getUser(userID);
/* 538 */           Watch watch = this.manager.getWatch(getPageUser(), user);
/* 539 */           watch.setExpirable(false);
/*     */         } catch (UserNotFoundException e) {
/* 541 */           Log.error(e);
/*     */         } catch (UnauthorizedException e) {
/* 543 */           setLoginAttributes();
/* 544 */           addActionError(getText("watches.error_unauth"));
/* 545 */           return "login";
/*     */         }
/*     */       }
/* 548 */       return "success";
/*     */     }
/*     */ 
/* 551 */     return "input";
/*     */   }
/*     */ 
/*     */   private boolean loadJiveObjects()
/*     */   {
/* 557 */     boolean success = true;
/* 558 */     this.manager = getForumFactory().getWatchManager();
/* 559 */     return success;
/*     */   }
/*     */ 
/*     */   protected List getIDs(String type, String objectType) {
/* 563 */     String key = type + "-" + objectType + "-";
/* 564 */     List ids = new ArrayList(5);
/* 565 */     for (Enumeration e = ServletActionContext.getRequest().getParameterNames(); e.hasMoreElements(); ) {
/* 566 */       String paramName = (String)e.nextElement();
/* 567 */       if (paramName.startsWith(key)) {
/* 568 */         String paramValue = ServletActionContext.getRequest().getParameter(paramName);
/*     */         try {
/* 570 */           ids.add(new Long(Long.parseLong(paramValue)));
/*     */         } catch (Exception ignored) {
/*     */         }
/*     */       }
/*     */     }
/* 575 */     return ids;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.EditWatchesAction
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class NewsGroupNotFoundException extends NNTPException
/*    */ {
/*    */   private static final int NOT_FOUND_CODE = 411;
/* 29 */   private static final NNTPResponse NG_NOT_FOUND = new StaticNNTPResponse(411, "no such news group");
/*    */ 
/*    */   public NewsGroupNotFoundException()
/*    */   {
/* 38 */     this.response = NG_NOT_FOUND;
/*    */   }
/*    */ 
/*    */   public NewsGroupNotFoundException(String message)
/*    */   {
/* 50 */     super(message);
/* 51 */     this.response = new StaticNNTPResponse(411, message);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NewsGroupNotFoundException
 * JD-Core Version:    0.6.2
 */
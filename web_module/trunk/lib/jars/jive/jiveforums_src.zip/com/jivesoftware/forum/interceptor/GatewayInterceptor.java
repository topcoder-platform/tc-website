/*     */ package com.jivesoftware.forum.interceptor;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.MessageInterceptor;
/*     */ import com.jivesoftware.forum.MessageRejectedException;
/*     */ 
/*     */ public class GatewayInterceptor
/*     */   implements MessageInterceptor
/*     */ {
/*     */   private boolean hideName;
/*     */   private boolean hideEmail;
/*     */   private boolean storeNameAsProp;
/*     */   private boolean storeEmailAsProp;
/*     */   private String nameProp;
/*     */   private String emailProp;
/*     */ 
/*     */   public GatewayInterceptor()
/*     */   {
/*     */   }
/*     */ 
/*     */   public GatewayInterceptor(int type, long objectID)
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean isHideName()
/*     */   {
/*  46 */     return this.hideName;
/*     */   }
/*     */ 
/*     */   public void setHideName(boolean hideName)
/*     */   {
/*  55 */     this.hideName = hideName;
/*     */   }
/*     */ 
/*     */   public boolean isHideEmail()
/*     */   {
/*  66 */     return this.hideEmail;
/*     */   }
/*     */ 
/*     */   public void setHideEmail(boolean hideEmail)
/*     */   {
/*  75 */     this.hideEmail = hideEmail;
/*     */   }
/*     */ 
/*     */   public boolean isStoreNameAsProp()
/*     */   {
/*  85 */     return this.storeNameAsProp;
/*     */   }
/*     */ 
/*     */   public void setStoreNameAsProp(boolean storeNameAsProp)
/*     */   {
/*  96 */     this.storeNameAsProp = storeNameAsProp;
/*     */   }
/*     */ 
/*     */   public boolean isStoreEmailAsProp()
/*     */   {
/* 106 */     return this.storeEmailAsProp;
/*     */   }
/*     */ 
/*     */   public void setStoreEmailAsProp(boolean storeEmailAsProp)
/*     */   {
/* 117 */     this.storeEmailAsProp = storeEmailAsProp;
/*     */   }
/*     */ 
/*     */   public String getNameProp()
/*     */   {
/* 127 */     return this.nameProp;
/*     */   }
/*     */ 
/*     */   public void setNameProp(String nameProp)
/*     */   {
/* 137 */     this.nameProp = nameProp;
/*     */   }
/*     */ 
/*     */   public String getEmailProp()
/*     */   {
/* 147 */     return this.emailProp;
/*     */   }
/*     */ 
/*     */   public void setEmailProp(String emailProp)
/*     */   {
/* 157 */     this.emailProp = emailProp;
/*     */   }
/*     */ 
/*     */   public int getType() {
/* 161 */     return 0;
/*     */   }
/*     */ 
/*     */   public void invokeInterceptor(ForumMessage message, int type)
/*     */     throws MessageRejectedException
/*     */   {
/* 168 */     if (message.getProperty("Subject-Hash") == null) {
/* 169 */       return;
/*     */     }
/*     */ 
/* 172 */     if (this.hideName) {
/* 173 */       if ((this.storeNameAsProp) && (this.nameProp != null) && (!"".equals(this.nameProp.trim()))) {
/* 174 */         String name = message.getProperty("name");
/*     */         try {
/* 176 */           message.deleteProperty("name");
/* 177 */           message.setProperty(this.nameProp, name);
/*     */         }
/*     */         catch (UnauthorizedException ue)
/*     */         {
/* 181 */           Log.error(ue);
/*     */         }
/*     */       }
/* 184 */       else if (message.getProperty("name") != null) {
/*     */         try {
/* 186 */           message.deleteProperty("name");
/*     */         }
/*     */         catch (UnauthorizedException ue)
/*     */         {
/* 190 */           Log.error(ue);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 195 */     if (this.hideEmail)
/* 196 */       if ((this.storeEmailAsProp) && (this.emailProp != null) && (!"".equals(this.emailProp.trim()))) {
/* 197 */         String email = message.getProperty("email");
/*     */         try {
/* 199 */           message.deleteProperty("email");
/* 200 */           message.setProperty(this.emailProp, email);
/*     */         }
/*     */         catch (UnauthorizedException ue)
/*     */         {
/* 204 */           Log.error(ue);
/*     */         }
/*     */       }
/* 207 */       else if (message.getProperty("email") != null) {
/*     */         try {
/* 209 */           message.deleteProperty("email");
/*     */         }
/*     */         catch (UnauthorizedException ue)
/*     */         {
/* 213 */           Log.error(ue);
/*     */         }
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.GatewayInterceptor
 * JD-Core Version:    0.6.2
 */
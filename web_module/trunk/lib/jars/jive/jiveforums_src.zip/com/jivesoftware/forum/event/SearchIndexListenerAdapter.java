package com.jivesoftware.forum.event;

public class SearchIndexListenerAdapter
  implements SearchIndexListener
{
  public void messageAdded(SearchIndexEvent event)
  {
  }

  public void messageDeleted(SearchIndexEvent event)
  {
  }

  public void rebuildStarted(SearchIndexEvent event)
  {
  }

  public void rebuildCompleted(SearchIndexEvent event)
  {
  }

  public void updateStarted(SearchIndexEvent event)
  {
  }

  public void updateCompleted(SearchIndexEvent event)
  {
  }

  public void optimizeStarted(SearchIndexEvent event)
  {
  }

  public void optimizeCompleted(SearchIndexEvent event)
  {
  }
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.SearchIndexListenerAdapter
 * JD-Core Version:    0.6.2
 */
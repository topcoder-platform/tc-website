/*     */ package com.jivesoftware.forum.net;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ public class BasicResultFilter
/*     */ {
/*     */   public static final int NO_RESULT_LIMIT = -1;
/*  49 */   private int startIndex = 0;
/*     */ 
/*  55 */   private int numResults = -1;
/*     */ 
/*     */   public BasicResultFilter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BasicResultFilter(int start, int maxResults)
/*     */   {
/*  42 */     this.startIndex = start;
/*  43 */     this.numResults = maxResults;
/*     */   }
/*     */ 
/*     */   public int getNumResults()
/*     */   {
/*  66 */     return this.numResults;
/*     */   }
/*     */ 
/*     */   public void setNumResults(int num)
/*     */   {
/*  76 */     if ((num != -1) && (num < 0)) {
/*  77 */       throw new IllegalArgumentException("numResults cannot be less than 0.");
/*     */     }
/*  79 */     this.numResults = num;
/*     */   }
/*     */ 
/*     */   public int getStartIndex()
/*     */   {
/*  88 */     return this.startIndex;
/*     */   }
/*     */ 
/*     */   public void setStartIndex(int start)
/*     */   {
/* 100 */     if (start < 0) {
/* 101 */       throw new IllegalArgumentException("A start index less than 0 is not valid.");
/*     */     }
/* 103 */     this.startIndex = start;
/*     */   }
/*     */ 
/*     */   public synchronized Iterator filter(Iterator rawResults)
/*     */   {
/* 113 */     Iterator result = null;
/* 114 */     if ((this.startIndex == 0) && (this.numResults == -1)) {
/* 115 */       result = rawResults;
/*     */     }
/*     */     else {
/* 118 */       LinkedList list = new LinkedList();
/* 119 */       while ((rawResults.hasNext()) && (this.startIndex-- > 0)) {
/* 120 */         rawResults.next();
/*     */       }
/* 122 */       if (this.numResults == -1) {
/* 123 */         while (rawResults.hasNext()) {
/* 124 */           list.add(rawResults.next());
/*     */         }
/*     */       }
/*     */ 
/* 128 */       for (int i = 0; (rawResults.hasNext()) && (i < this.numResults); i++) {
/* 129 */         list.add(rawResults.next());
/*     */       }
/*     */ 
/* 132 */       result = list.iterator();
/*     */     }
/* 134 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.BasicResultFilter
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.forum.Attachment;
/*    */ import com.jivesoftware.forum.Avatar;
/*    */ import com.jivesoftware.forum.AvatarManager;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public class AvatarDisplayAction extends ForumActionSupport
/*    */ {
/*    */   private long avatarID;
/*    */   private InputStream imageStream;
/*    */ 
/*    */   public void setAvatarID(long avatarID)
/*    */   {
/* 27 */     this.avatarID = avatarID;
/*    */   }
/*    */ 
/*    */   public InputStream getImageStream() {
/* 31 */     return this.imageStream;
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */     throws Exception
/*    */   {
/* 37 */     AvatarManager avatarManager = getForumFactory().getAvatarManager();
/*    */ 
/* 39 */     Avatar avatar = avatarManager.getAvatar(this.avatarID);
/*    */ 
/* 41 */     Attachment attachment = avatar.getAttachment();
/*    */ 
/* 43 */     this.imageStream = attachment.getData();
/*    */ 
/* 45 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AvatarDisplayAction
 * JD-Core Version:    0.6.2
 */
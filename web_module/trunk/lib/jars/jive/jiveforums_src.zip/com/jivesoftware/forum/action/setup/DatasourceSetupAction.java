/*     */ package com.jivesoftware.forum.action.setup;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.database.ConnectionProvider;
/*     */ import com.jivesoftware.base.database.EmbeddedConnectionProvider;
/*     */ import com.jivesoftware.util.JiveProperties;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import com.opensymphony.xwork.Preparable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class DatasourceSetupAction extends SetupActionSupport
/*     */   implements Preparable
/*     */ {
/*     */   public static final String CONNECTION_FAILED = "connection.failed";
/*     */   public static final String NO_JIVE_TABLES = "no.jive.tables";
/*     */   public static final String EMBEDDED_MODE = "embedded";
/*     */   public static final String THIRD_PARTY_MODE = "thirdparty";
/*     */   public static final String DATASOURCE_MODE = "datasource";
/*  34 */   private String mode = "thirdparty";
/*     */ 
/*     */   public String getMode()
/*     */   {
/*  39 */     return this.mode;
/*     */   }
/*     */ 
/*     */   public void setMode(String mode) {
/*  43 */     this.mode = mode;
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */     throws Exception
/*     */   {
/*  49 */     String prop = JiveGlobals.getJiveProperty("connectionProvider.className");
/*  50 */     if ("com.jivesoftware.base.database.EmbeddedConnectionProvider".equals(prop)) {
/*  51 */       this.mode = "embedded";
/*     */     }
/*  53 */     else if ("com.jivesoftware.base.database.JNDIDataSourceProvider".equals(prop))
/*  54 */       this.mode = "datasource";
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*  59 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/*  60 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "in_progress");
/*  61 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "incomplete");
/*  62 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "incomplete");
/*  63 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "incomplete");
/*  64 */     return "input";
/*     */   }
/*     */ 
/*     */   public String doContinue()
/*     */   {
/*  70 */     JiveProperties.getInstance().init();
/*     */ 
/*  72 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/*  73 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/*  74 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "in_progress");
/*  75 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "incomplete");
/*  76 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "incomplete");
/*  77 */     return "next";
/*     */   }
/*     */ 
/*     */   public String execute() {
/*  81 */     if ("embedded".equals(this.mode))
/*     */     {
/*  83 */       JiveGlobals.setLocalProperty("connectionProvider.className", "com.jivesoftware.base.database.EmbeddedConnectionProvider");
/*     */ 
/*  85 */       ConnectionProvider conProvider = new EmbeddedConnectionProvider();
/*  86 */       ConnectionManager.setConnectionProvider(conProvider);
/*     */ 
/*  89 */       return "embedded";
/*     */     }
/*  91 */     if ("thirdparty".equals(this.mode)) {
/*  92 */       return "thirdparty";
/*     */     }
/*  94 */     if ("datasource".equals(this.mode)) {
/*  95 */       return "datasource";
/*     */     }
/*     */ 
/*  98 */     return "error";
/*     */   }
/*     */ 
/*     */   protected boolean testConnection()
/*     */   {
/* 104 */     if (Log.isDebugEnabled()) {
/* 105 */       Log.debug("Testing database connection");
/*     */     }
/* 107 */     boolean success = true;
/* 108 */     Connection con = null;
/*     */     try {
/* 110 */       con = ConnectionManager.getConnection();
/* 111 */       if (con == null) {
/* 112 */         success = false;
/* 113 */         addActionError(getText("setup.error.datasource.connect_failed"));
/* 114 */         if (Log.isDebugEnabled())
/* 115 */           Log.debug("Unable to retrieve database connection");
/*     */       }
/*     */       else
/*     */       {
/*     */         try
/*     */         {
/* 121 */           Statement stmt = con.createStatement();
/*     */ 
/* 123 */           stmt.executeQuery("SELECT * FROM jiveID");
/* 124 */           stmt.close();
/*     */         }
/*     */         catch (SQLException sqle) {
/* 127 */           success = false;
/* 128 */           addActionError(getText("setup.error.datasource.not_installed"));
/* 129 */           if (Log.isDebugEnabled())
/* 130 */             Log.debug("Unable to retrieve database connection");
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 136 */       success = false;
/* 137 */       addActionError(getText("setup.error.datasource.connect_failed"));
/* 138 */       if (Log.isDebugEnabled())
/* 139 */         Log.debug("Unable to retrieve database connection");
/*     */     }
/*     */     finally
/*     */     {
/* 143 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */ 
/* 146 */     return success;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.DatasourceSetupAction
 * JD-Core Version:    0.6.2
 */
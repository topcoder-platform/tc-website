/*    */ package com.jivesoftware.forum.database;
/*    */ 
/*    */ import com.jivesoftware.base.User;
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import com.jivesoftware.forum.ForumCategory;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.RewardManager;
/*    */ import com.jivesoftware.forum.StatusLevelCalculator;
/*    */ import com.jivesoftware.util.LongList;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class RewardStatusLevelCalculator
/*    */   implements StatusLevelCalculator
/*    */ {
/* 25 */   private static final ForumFactory FACTORY = DbForumFactory.getInstance();
/*    */ 
/*    */   public int getPointLevel(User user)
/*    */   {
/* 29 */     RewardManager rewardManager = FACTORY.getRewardManager();
/* 30 */     return rewardManager.getPointsEarned(user);
/*    */   }
/*    */ 
/*    */   public int getPointLevel(User user, Forum forum) {
/* 34 */     RewardManager rewardManager = FACTORY.getRewardManager();
/* 35 */     return rewardManager.getPointsEarned(user, forum);
/*    */   }
/*    */ 
/*    */   public int getPointLevel(User user, ForumCategory category) {
/* 39 */     RewardManager rewardManager = FACTORY.getRewardManager();
/* 40 */     return rewardManager.getPointsEarned(user, category);
/*    */   }
/*    */ 
/*    */   public long[] getLeaderIds(int startIndex, int numResults) {
/* 44 */     LongList userIDs = new LongList();
/* 45 */     RewardManager rewardManager = FACTORY.getRewardManager();
/* 46 */     for (Iterator i = rewardManager.getTopUsers(startIndex, numResults); i.hasNext(); ) {
/* 47 */       userIDs.add(((User)i.next()).getID());
/*    */     }
/* 49 */     return userIDs.toArray();
/*    */   }
/*    */ 
/*    */   public long[] getLeaderIds(ForumCategory category, int startIndex, int numResults) {
/* 53 */     LongList userIDs = new LongList();
/* 54 */     RewardManager rewardManager = FACTORY.getRewardManager();
/* 55 */     for (Iterator i = rewardManager.getTopUsers(startIndex, numResults, category); i.hasNext(); ) {
/* 56 */       userIDs.add(((User)i.next()).getID());
/*    */     }
/* 58 */     return userIDs.toArray();
/*    */   }
/*    */ 
/*    */   public long[] getLeaderIds(Forum forum, int startIndex, int numResults) {
/* 62 */     LongList userIDs = new LongList();
/* 63 */     RewardManager rewardManager = FACTORY.getRewardManager();
/* 64 */     for (Iterator i = rewardManager.getTopUsers(startIndex, numResults, forum); i.hasNext(); ) {
/* 65 */       userIDs.add(((User)i.next()).getID());
/*    */     }
/* 67 */     return userIDs.toArray();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.RewardStatusLevelCalculator
 * JD-Core Version:    0.6.2
 */
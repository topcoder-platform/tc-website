/*    */ package com.jivesoftware.forum.action.setup;
/*    */ 
/*    */ import com.opensymphony.xwork.validator.ValidationException;
/*    */ import com.opensymphony.xwork.validator.ValidatorContext;
/*    */ import com.opensymphony.xwork.validator.validators.FieldValidatorSupport;
/*    */ 
/*    */ public class DatasourceSetupActionValidator extends FieldValidatorSupport
/*    */ {
/*    */   public void validate(Object object)
/*    */     throws ValidationException
/*    */   {
/* 22 */     String fieldName = getFieldName();
/* 23 */     ValidatorContext context = getValidatorContext();
/* 24 */     String mode = (String)getFieldValue(fieldName, object);
/*    */ 
/* 26 */     if ((!"embedded".equals(mode)) && (!"thirdparty".equals(mode)) && (!"datasource".equals(mode)))
/*    */     {
/* 30 */       context.addFieldError(fieldName, context.getText("setup.error.datasource.invalid_mode"));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.DatasourceSetupActionValidator
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.nntp.spi;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ public class UUEndIterator extends PeekIterator
/*    */ {
/* 25 */   private boolean seenEnd = false;
/*    */ 
/* 27 */   private boolean sentEnd = false;
/*    */ 
/*    */   public UUEndIterator(Iterator itr, String headerLine)
/*    */   {
/* 37 */     super(itr, headerLine);
/*    */   }
/*    */ 
/*    */   public boolean hasNext() {
/* 41 */     boolean next = false;
/* 42 */     if (!this.seenEnd) {
/* 43 */       next = super.hasNext();
/* 44 */       String line = (String)super.peek();
/* 45 */       if ("end".equals(line)) {
/* 46 */         this.seenEnd = true;
/*    */       }
/*    */     }
/* 49 */     return next;
/*    */   }
/*    */ 
/*    */   public Object next()
/*    */   {
/*    */     Object next;
/* 54 */     if (this.seenEnd) {
/* 55 */       if (this.sentEnd) {
/* 56 */         throw new NoSuchElementException();
/*    */       }
/*    */ 
/* 59 */       this.sentEnd = true;
/* 60 */       next = "end";
/*    */     }
/*    */     else
/*    */     {
/*    */       Object next;
/* 64 */       if (hasNext()) {
/* 65 */         next = super.next();
/*    */       }
/*    */       else
/* 68 */         throw new NoSuchElementException();
/*    */     }
/*    */     Object next;
/* 71 */     return next;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.UUEndIterator
 * JD-Core Version:    0.6.2
 */
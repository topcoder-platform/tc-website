/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.FilterManager;
/*    */ import com.jivesoftware.base.GroupManager;
/*    */ import com.jivesoftware.base.LicenseManager;
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.base.Permissions;
/*    */ import com.jivesoftware.base.PermissionsManager;
/*    */ import com.jivesoftware.base.PollManager;
/*    */ import com.jivesoftware.base.PresenceManager;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.base.User;
/*    */ import com.jivesoftware.base.UserManager;
/*    */ import com.jivesoftware.forum.database.DbForumFactory;
/*    */ import com.jivesoftware.forum.proxy.ForumFactoryProxy;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public abstract class ForumFactory
/*    */ {
/* 51 */   private static Object initLock = new Object();
/* 52 */   private static ForumFactory factory = null;
/*    */ 
/*    */   public static ForumFactory getInstance(AuthToken authToken)
/*    */   {
/* 64 */     if (authToken == null) {
/* 65 */       return null;
/*    */     }
/* 67 */     if (factory == null) {
/* 68 */       synchronized (initLock) {
/* 69 */         if (factory == null)
/*    */         {
/* 72 */           if (Version.getEdition().equals(Version.Edition.LITE)) {
/* 73 */             LicenseManager.validateLicense("Jive Forums Lite", "4.2");
/*    */           }
/* 75 */           else if (Version.getEdition().equals(Version.Edition.PROFESSIONAL)) {
/* 76 */             LicenseManager.validateLicense("Jive Forums Professional", "4.2");
/*    */           }
/* 78 */           else if (Version.getEdition().equals(Version.Edition.ENTERPRISE)) {
/* 79 */             LicenseManager.validateLicense("Jive Forums Enterprise", "4.2");
/*    */           }
/*    */           else {
/* 82 */             LicenseManager.validateLicense("Jive Forums Expert Edition", "4.2");
/*    */           }
/*    */           try
/*    */           {
/* 86 */             factory = DbForumFactory.getInstance();
/*    */           }
/*    */           catch (Exception e) {
/* 89 */             Log.error(e);
/* 90 */             return null;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 96 */     return new ForumFactoryProxy(authToken, factory, factory.getPermissions(authToken));
/*    */   }
/*    */ 
/*    */   public abstract Forum createForum(String paramString1, String paramString2)
/*    */     throws UnauthorizedException;
/*    */ 
/*    */   public abstract Forum createForum(String paramString1, String paramString2, ForumCategory paramForumCategory)
/*    */     throws UnauthorizedException;
/*    */ 
/*    */   public abstract ForumCategory getForumCategory(long paramLong)
/*    */     throws ForumCategoryNotFoundException;
/*    */ 
/*    */   public abstract ForumCategory getRootForumCategory();
/*    */ 
/*    */   public abstract Forum getForum(long paramLong)
/*    */     throws ForumNotFoundException, UnauthorizedException;
/*    */ 
/*    */   public abstract Forum getForum(String paramString)
/*    */     throws ForumNotFoundException, UnauthorizedException;
/*    */ 
/*    */   public abstract ForumThread getForumThread(long paramLong)
/*    */     throws ForumThreadNotFoundException, UnauthorizedException;
/*    */ 
/*    */   public abstract ForumMessage getMessage(long paramLong)
/*    */     throws ForumMessageNotFoundException, UnauthorizedException;
/*    */ 
/*    */   public abstract long getMessageID(long paramLong, int paramInt);
/*    */ 
/*    */   public abstract int getForumCount();
/*    */ 
/*    */   public abstract int getForumCount(ResultFilter paramResultFilter);
/*    */ 
/*    */   public abstract Iterator getForums();
/*    */ 
/*    */   public abstract Iterator getForums(ResultFilter paramResultFilter);
/*    */ 
/*    */   public abstract Query createQuery();
/*    */ 
/*    */   public abstract Query createQuery(Forum[] paramArrayOfForum);
/*    */ 
/*    */   public abstract Iterator getPopularForums();
/*    */ 
/*    */   public abstract Iterator getPopularThreads();
/*    */ 
/*    */   /** @deprecated */
/*    */   public abstract void deleteForum(Forum paramForum)
/*    */     throws UnauthorizedException;
/*    */ 
/*    */   public abstract void mergeForums(Forum paramForum1, Forum paramForum2)
/*    */     throws UnauthorizedException;
/*    */ 
/*    */   public abstract int getUserMessageCount(User paramUser);
/*    */ 
/*    */   public abstract int getUserMessageCount(User paramUser, ResultFilter paramResultFilter);
/*    */ 
/*    */   public abstract Iterator getUserMessages(User paramUser);
/*    */ 
/*    */   public abstract Iterator getUserMessages(User paramUser, ResultFilter paramResultFilter);
/*    */ 
/*    */   public abstract UserManager getUserManager();
/*    */ 
/*    */   public abstract GroupManager getGroupManager();
/*    */ 
/*    */   public abstract SearchManager getSearchManager()
/*    */     throws UnauthorizedException;
/*    */ 
/*    */   public abstract FilterManager getFilterManager();
/*    */ 
/*    */   public abstract InterceptorManager getInterceptorManager()
/*    */     throws UnauthorizedException;
/*    */ 
/*    */   public abstract WatchManager getWatchManager();
/*    */ 
/*    */   public abstract RewardManager getRewardManager();
/*    */ 
/*    */   public abstract AttachmentManager getAttachmentManager();
/*    */ 
/*    */   public abstract ArchiveManager getArchiveManager();
/*    */ 
/*    */   public abstract PresenceManager getPresenceManager();
/*    */ 
/*    */   public abstract ReadTracker getReadTracker();
/*    */ 
/*    */   public abstract PollManager getPollManager();
/*    */ 
/*    */   public abstract PrivateMessageManager getPrivateMessageManager();
/*    */ 
/*    */   public abstract AnnouncementManager getAnnouncementManager();
/*    */ 
/*    */   public abstract PermissionsManager getPermissionsManager()
/*    */     throws UnauthorizedException;
/*    */ 
/*    */   public abstract StatusLevelManager getStatusLevelManager();
/*    */ 
/*    */   public abstract AvatarManager getAvatarManager();
/*    */ 
/*    */   public abstract QuestionManager getQuestionManager();
/*    */ 
/*    */   public abstract QueryManager getQueryManager();
/*    */ 
/*    */   public abstract Permissions getPermissions(AuthToken paramAuthToken);
/*    */ 
/*    */   public abstract boolean isAuthorized(long paramLong);
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.ForumFactory
 * JD-Core Version:    0.6.2
 */
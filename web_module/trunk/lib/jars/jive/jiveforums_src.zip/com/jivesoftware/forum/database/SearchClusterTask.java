/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.tangosol.net.Invocable;
/*     */ import com.tangosol.net.InvocationService;
/*     */ 
/*     */ public class SearchClusterTask
/*     */   implements Invocable
/*     */ {
/*     */   private DbForumMessage message;
/*     */   private DbForumThread thread;
/*     */   private DbForum forum;
/*  28 */   private boolean add = false;
/*  29 */   private boolean update = false;
/*  30 */   private boolean delete = false;
/*  31 */   private boolean rebuild = false;
/*     */ 
/*     */   public void init(InvocationService service)
/*     */   {
/*     */   }
/*     */ 
/*     */   public DbForumMessage getMessage()
/*     */   {
/*  42 */     return this.message;
/*     */   }
/*     */ 
/*     */   public void setMessage(DbForumMessage message) {
/*  46 */     this.message = message;
/*     */   }
/*     */ 
/*     */   public DbForumThread getThread() {
/*  50 */     return this.thread;
/*     */   }
/*     */ 
/*     */   public void setThread(DbForumThread thread) {
/*  54 */     this.thread = thread;
/*     */   }
/*     */ 
/*     */   public DbForum getForum() {
/*  58 */     return this.forum;
/*     */   }
/*     */ 
/*     */   public void setForum(DbForum forum) {
/*  62 */     this.forum = forum;
/*     */   }
/*     */ 
/*     */   public boolean isAdd() {
/*  66 */     return this.add;
/*     */   }
/*     */ 
/*     */   public void setAdd(boolean add) {
/*  70 */     this.add = add;
/*     */   }
/*     */ 
/*     */   public boolean isUpdate() {
/*  74 */     return this.update;
/*     */   }
/*     */ 
/*     */   public void setUpdate(boolean update) {
/*  78 */     this.update = update;
/*     */   }
/*     */ 
/*     */   public boolean isDelete() {
/*  82 */     return this.delete;
/*     */   }
/*     */ 
/*     */   public void setDelete(boolean delete) {
/*  86 */     this.delete = delete;
/*     */   }
/*     */ 
/*     */   public boolean isRebuild() {
/*  90 */     return this.rebuild;
/*     */   }
/*     */ 
/*     */   public void setRebuild(boolean rebuild) {
/*  94 */     this.rebuild = rebuild;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/* 102 */       DbSearchManager manager = (DbSearchManager)DbForumFactory.getInstance().getSearchManager();
/*     */ 
/* 104 */       if ((this.forum == null) || (!this.add))
/*     */       {
/* 107 */         if ((this.forum == null) || (!this.update))
/*     */         {
/* 110 */           if ((this.forum != null) && (this.delete)) {
/* 111 */             manager.removeFromIndex(this.forum, false);
/*     */           }
/* 113 */           else if ((this.thread == null) || (!this.add))
/*     */           {
/* 116 */             if ((this.thread == null) || (!this.update))
/*     */             {
/* 119 */               if ((this.thread != null) && (this.delete)) {
/* 120 */                 manager.removeFromIndex(this.thread, false);
/*     */               }
/* 122 */               else if ((this.message != null) && (this.add)) {
/* 123 */                 manager.addToIndex(this.message, false);
/*     */               }
/* 125 */               else if ((this.message != null) && (this.update)) {
/* 126 */                 manager.removeFromIndex(this.message, false);
/* 127 */                 manager.addToIndex(this.message, false);
/*     */               }
/* 129 */               else if ((this.message != null) && (this.delete)) {
/* 130 */                 manager.removeFromIndex(this.message, false);
/*     */               }
/* 132 */               else if (this.rebuild) {
/* 133 */                 manager.rebuildIndex(); }  } 
/*     */           }
/*     */         }
/*     */       } } catch (Exception e) { Log.error(e); }
/*     */ 
/*     */   }
/*     */ 
/*     */   public Object getResult()
/*     */   {
/* 143 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.SearchClusterTask
 * JD-Core Version:    0.6.2
 */
/*      */ package com.jivesoftware.forum.nntp.spi;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.FilterInputStream;
/*      */ import java.io.FilterOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Serializable;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.zip.GZIPInputStream;
/*      */ import java.util.zip.GZIPOutputStream;
/*      */ 
/*      */ public class Base64
/*      */ {
/*      */   public static final int NO_OPTIONS = 0;
/*      */   public static final int ENCODE = 1;
/*      */   public static final int DECODE = 0;
/*      */   public static final int GZIP = 2;
/*      */   public static final int DONT_BREAK_LINES = 8;
/*      */   private static final int MAX_LINE_LENGTH = 76;
/*      */   private static final byte EQUALS_SIGN = 61;
/*      */   private static final byte NEW_LINE = 10;
/*      */   private static final String PREFERRED_ENCODING = "UTF-8";
/*  130 */   private static final byte[] ALPHABET = __bytes;
/*      */ 
/*  104 */   private static final byte[] _NATIVE_ALPHABET = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*      */ 
/*  138 */   private static final byte[] DECODABET = { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, -9, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -9, -9, -9, -1, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, -9, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9 };
/*      */   private static final byte BAD_ENCODING = -9;
/*      */   private static final byte WHITE_SPACE_ENC = -5;
/*      */   private static final byte EQUALS_SIGN_ENC = -1;
/*      */ 
/*      */   private static byte[] encode3to4(byte[] threeBytes)
/*      */   {
/*  196 */     return encode3to4(threeBytes, 3);
/*      */   }
/*      */ 
/*      */   private static byte[] encode3to4(byte[] threeBytes, int numSigBytes)
/*      */   {
/*  216 */     byte[] dest = new byte[4];
/*  217 */     encode3to4(threeBytes, 0, numSigBytes, dest, 0);
/*  218 */     return dest;
/*      */   }
/*      */ 
/*      */   private static byte[] encode3to4(byte[] b4, byte[] threeBytes, int numSigBytes)
/*      */   {
/*  238 */     encode3to4(threeBytes, 0, numSigBytes, b4, 0);
/*  239 */     return b4;
/*      */   }
/*      */ 
/*      */   private static byte[] encode3to4(byte[] source, int srcOffset, int numSigBytes, byte[] destination, int destOffset)
/*      */   {
/*  279 */     int inBuff = (numSigBytes > 0 ? source[srcOffset] << 24 >>> 8 : 0) | (numSigBytes > 1 ? source[(srcOffset + 1)] << 24 >>> 16 : 0) | (numSigBytes > 2 ? source[(srcOffset + 2)] << 24 >>> 24 : 0);
/*      */ 
/*  283 */     switch (numSigBytes)
/*      */     {
/*      */     case 3:
/*  286 */       destination[destOffset] = ALPHABET[(inBuff >>> 18)];
/*  287 */       destination[(destOffset + 1)] = ALPHABET[(inBuff >>> 12 & 0x3F)];
/*  288 */       destination[(destOffset + 2)] = ALPHABET[(inBuff >>> 6 & 0x3F)];
/*  289 */       destination[(destOffset + 3)] = ALPHABET[(inBuff & 0x3F)];
/*  290 */       return destination;
/*      */     case 2:
/*  293 */       destination[destOffset] = ALPHABET[(inBuff >>> 18)];
/*  294 */       destination[(destOffset + 1)] = ALPHABET[(inBuff >>> 12 & 0x3F)];
/*  295 */       destination[(destOffset + 2)] = ALPHABET[(inBuff >>> 6 & 0x3F)];
/*  296 */       destination[(destOffset + 3)] = 61;
/*  297 */       return destination;
/*      */     case 1:
/*  300 */       destination[destOffset] = ALPHABET[(inBuff >>> 18)];
/*  301 */       destination[(destOffset + 1)] = ALPHABET[(inBuff >>> 12 & 0x3F)];
/*  302 */       destination[(destOffset + 2)] = 61;
/*  303 */       destination[(destOffset + 3)] = 61;
/*  304 */       return destination;
/*      */     }
/*      */ 
/*  307 */     return destination;
/*      */   }
/*      */ 
/*      */   public static String encodeObject(Serializable serializableObject)
/*      */   {
/*  326 */     return encodeObject(serializableObject, 0);
/*      */   }
/*      */ 
/*      */   public static String encodeObject(Serializable serializableObject, int options)
/*      */   {
/*  357 */     ByteArrayOutputStream baos = null;
/*  358 */     OutputStream b64os = null;
/*  359 */     ObjectOutputStream oos = null;
/*  360 */     GZIPOutputStream gzos = null;
/*      */ 
/*  363 */     int gzip = options & 0x2;
/*  364 */     int dontBreakLines = options & 0x8;
/*      */     try
/*      */     {
/*  369 */       baos = new ByteArrayOutputStream();
/*  370 */       b64os = new OutputStream(baos, 0x1 | dontBreakLines);
/*      */ 
/*  373 */       if (gzip == 2)
/*      */       {
/*  375 */         gzos = new GZIPOutputStream(b64os);
/*  376 */         oos = new ObjectOutputStream(gzos);
/*      */       }
/*      */       else {
/*  379 */         oos = new ObjectOutputStream(b64os);
/*      */       }
/*  381 */       oos.writeObject(serializableObject);
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  385 */       e.printStackTrace();
/*  386 */       return null;
/*      */     }
/*      */     finally {
/*      */       try {
/*  390 */         oos.close(); } catch (Exception e) {
/*      */       }try { gzos.close(); } catch (Exception e) {
/*      */       }try { b64os.close(); } catch (Exception e) {
/*      */       }try { baos.close();
/*      */       } catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */     try {
/*  399 */       return new String(baos.toByteArray(), "UTF-8");
/*      */     }
/*      */     catch (UnsupportedEncodingException uue) {
/*      */     }
/*  403 */     return new String(baos.toByteArray());
/*      */   }
/*      */ 
/*      */   public static String encodeBytes(byte[] source)
/*      */   {
/*  419 */     return encodeBytes(source, 0, source.length, 0);
/*      */   }
/*      */ 
/*      */   public static String encodeBytes(byte[] source, int options)
/*      */   {
/*  446 */     return encodeBytes(source, 0, source.length, options);
/*      */   }
/*      */ 
/*      */   public static String encodeBytes(byte[] source, int off, int len)
/*      */   {
/*  461 */     return encodeBytes(source, off, len, 0);
/*      */   }
/*      */ 
/*      */   public static String encodeBytes(byte[] source, int off, int len, int options)
/*      */   {
/*  491 */     int dontBreakLines = options & 0x8;
/*  492 */     int gzip = options & 0x2;
/*      */ 
/*  495 */     if (gzip == 2)
/*      */     {
/*  497 */       ByteArrayOutputStream baos = null;
/*  498 */       GZIPOutputStream gzos = null;
/*  499 */       OutputStream b64os = null;
/*      */       try
/*      */       {
/*  505 */         baos = new ByteArrayOutputStream();
/*  506 */         b64os = new OutputStream(baos, 0x1 | dontBreakLines);
/*  507 */         gzos = new GZIPOutputStream(b64os);
/*      */ 
/*  509 */         gzos.write(source, off, len);
/*  510 */         gzos.close();
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*  514 */         e.printStackTrace();
/*  515 */         return null;
/*      */       }
/*      */       finally {
/*      */         try {
/*  519 */           gzos.close(); } catch (Exception e) {
/*      */         }try { b64os.close(); } catch (Exception e) {
/*      */         }try { baos.close();
/*      */         } catch (Exception e)
/*      */         {
/*      */         }
/*      */       }
/*      */       try {
/*  527 */         return new String(baos.toByteArray(), "UTF-8");
/*      */       }
/*      */       catch (UnsupportedEncodingException uue)
/*      */       {
/*  531 */         return new String(baos.toByteArray());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  539 */     boolean breakLines = dontBreakLines == 0;
/*      */ 
/*  541 */     int len43 = len * 4 / 3;
/*  542 */     byte[] outBuff = new byte[len43 + (len % 3 > 0 ? 4 : 0) + (breakLines ? len43 / 76 : 0)];
/*      */ 
/*  545 */     int d = 0;
/*  546 */     int e = 0;
/*  547 */     int len2 = len - 2;
/*  548 */     int lineLength = 0;
/*  549 */     for (; d < len2; e += 4)
/*      */     {
/*  551 */       encode3to4(source, d + off, 3, outBuff, e);
/*      */ 
/*  553 */       lineLength += 4;
/*  554 */       if ((breakLines) && (lineLength == 76))
/*      */       {
/*  556 */         outBuff[(e + 4)] = 10;
/*  557 */         e++;
/*  558 */         lineLength = 0;
/*      */       }
/*  549 */       d += 3;
/*      */     }
/*      */ 
/*  562 */     if (d < len)
/*      */     {
/*  564 */       encode3to4(source, d + off, len - d, outBuff, e);
/*  565 */       e += 4;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  572 */       return new String(outBuff, 0, e, "UTF-8");
/*      */     }
/*      */     catch (UnsupportedEncodingException uue) {
/*      */     }
/*  576 */     return new String(outBuff, 0, e);
/*      */   }
/*      */ 
/*      */   private static byte[] decode4to3(byte[] fourBytes)
/*      */   {
/*  601 */     byte[] outBuff1 = new byte[3];
/*  602 */     int count = decode4to3(fourBytes, 0, outBuff1, 0);
/*  603 */     byte[] outBuff2 = new byte[count];
/*      */ 
/*  605 */     for (int i = 0; i < count; i++) {
/*  606 */       outBuff2[i] = outBuff1[i];
/*      */     }
/*  608 */     return outBuff2;
/*      */   }
/*      */ 
/*      */   private static int decode4to3(byte[] source, int srcOffset, byte[] destination, int destOffset)
/*      */   {
/*  636 */     if (source[(srcOffset + 2)] == 61)
/*      */     {
/*  641 */       int outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[(srcOffset + 1)]] & 0xFF) << 12;
/*      */ 
/*  644 */       destination[destOffset] = ((byte)(outBuff >>> 16));
/*  645 */       return 1;
/*      */     }
/*      */ 
/*  649 */     if (source[(srcOffset + 3)] == 61)
/*      */     {
/*  655 */       int outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[(srcOffset + 1)]] & 0xFF) << 12 | (DECODABET[source[(srcOffset + 2)]] & 0xFF) << 6;
/*      */ 
/*  659 */       destination[destOffset] = ((byte)(outBuff >>> 16));
/*  660 */       destination[(destOffset + 1)] = ((byte)(outBuff >>> 8));
/*  661 */       return 2;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  673 */       int outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[(srcOffset + 1)]] & 0xFF) << 12 | (DECODABET[source[(srcOffset + 2)]] & 0xFF) << 6 | DECODABET[source[(srcOffset + 3)]] & 0xFF;
/*      */ 
/*  679 */       destination[destOffset] = ((byte)(outBuff >> 16));
/*  680 */       destination[(destOffset + 1)] = ((byte)(outBuff >> 8));
/*  681 */       destination[(destOffset + 2)] = ((byte)outBuff);
/*      */ 
/*  683 */       return 3;
/*      */     } catch (Exception e) {
/*  685 */       System.out.println("" + source[srcOffset] + ": " + DECODABET[source[srcOffset]]);
/*  686 */       System.out.println("" + source[(srcOffset + 1)] + ": " + DECODABET[source[(srcOffset + 1)]]);
/*  687 */       System.out.println("" + source[(srcOffset + 2)] + ": " + DECODABET[source[(srcOffset + 2)]]);
/*  688 */       System.out.println("" + source[(srcOffset + 3)] + ": " + DECODABET[source[(srcOffset + 3)]]);
/*  689 */     }return -1;
/*      */   }
/*      */ 
/*      */   public static byte[] decode(byte[] source, int off, int len)
/*      */   {
/*  710 */     int len34 = len * 3 / 4;
/*  711 */     byte[] outBuff = new byte[len34];
/*  712 */     int outBuffPosn = 0;
/*      */ 
/*  714 */     byte[] b4 = new byte[4];
/*  715 */     int b4Posn = 0;
/*  716 */     int i = 0;
/*  717 */     byte sbiCrop = 0;
/*  718 */     byte sbiDecode = 0;
/*  719 */     for (i = off; i < off + len; i++)
/*      */     {
/*  721 */       sbiCrop = (byte)(source[i] & 0x7F);
/*  722 */       sbiDecode = DECODABET[sbiCrop];
/*      */ 
/*  724 */       if (sbiDecode >= -5)
/*      */       {
/*      */         byte[] out;
/*  726 */         if (sbiDecode >= -1)
/*      */         {
/*  728 */           b4[(b4Posn++)] = sbiCrop;
/*  729 */           if (b4Posn > 3)
/*      */           {
/*  731 */             outBuffPosn += decode4to3(b4, 0, outBuff, outBuffPosn);
/*  732 */             b4Posn = 0;
/*      */ 
/*  735 */             if (sbiCrop == 61) {
/*  736 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  744 */         System.err.println("Bad Base64 input character at " + i + ": " + source[i] + "(decimal)");
/*  745 */         return null;
/*      */       }
/*      */     }
/*      */ 
/*  749 */     out = new byte[outBuffPosn];
/*  750 */     System.arraycopy(outBuff, 0, out, 0, outBuffPosn);
/*  751 */     return out;
/*      */   }
/*      */ 
/*      */   public static byte[] decode(String s)
/*      */   {
/*      */     try
/*      */     {
/*  770 */       bytes = s.getBytes("UTF-8");
/*      */     }
/*      */     catch (UnsupportedEncodingException uee)
/*      */     {
/*  774 */       bytes = s.getBytes();
/*      */     }
/*      */ 
/*  779 */     byte[] bytes = decode(bytes, 0, bytes.length);
/*      */ 
/*  784 */     if (bytes.length >= 2)
/*      */     {
/*  787 */       int head = bytes[0] & 0xFF | bytes[1] << 8 & 0xFF00;
/*  788 */       if ((bytes != null) && (bytes.length >= 4) && (35615 == head))
/*      */       {
/*  793 */         ByteArrayInputStream bais = null;
/*  794 */         GZIPInputStream gzis = null;
/*  795 */         ByteArrayOutputStream baos = null;
/*  796 */         byte[] buffer = new byte[2048];
/*  797 */         int length = 0;
/*      */         try
/*      */         {
/*  801 */           baos = new ByteArrayOutputStream();
/*  802 */           bais = new ByteArrayInputStream(bytes);
/*  803 */           gzis = new GZIPInputStream(bais);
/*      */ 
/*  805 */           while ((length = gzis.read(buffer)) >= 0)
/*      */           {
/*  807 */             baos.write(buffer, 0, length);
/*      */           }
/*      */ 
/*  811 */           bytes = baos.toByteArray();
/*      */         }
/*      */         catch (IOException e)
/*      */         {
/*      */         }
/*      */         finally
/*      */         {
/*      */           try
/*      */           {
/*  820 */             baos.close(); } catch (Exception e) {
/*      */           }try { gzis.close(); } catch (Exception e) {
/*      */           }try { bais.close();
/*      */           } catch (Exception e) {
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  828 */     return bytes;
/*      */   }
/*      */ 
/*      */   public static Object decodeToObject(String encodedObject)
/*      */   {
/*  845 */     byte[] objBytes = decode(encodedObject);
/*      */ 
/*  847 */     ByteArrayInputStream bais = null;
/*  848 */     ObjectInputStream ois = null;
/*  849 */     Object obj = null;
/*      */     try
/*      */     {
/*  853 */       bais = new ByteArrayInputStream(objBytes);
/*  854 */       ois = new ObjectInputStream(bais);
/*      */ 
/*  856 */       obj = ois.readObject();
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  860 */       e.printStackTrace();
/*  861 */       obj = null;
/*      */     }
/*      */     catch (ClassNotFoundException e)
/*      */     {
/*  865 */       e.printStackTrace();
/*  866 */       obj = null;
/*      */     }
/*      */     finally {
/*      */       try {
/*  870 */         bais.close(); } catch (Exception e) {
/*      */       }try { ois.close(); } catch (Exception e) {
/*      */       }
/*      */     }
/*  874 */     return obj;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*      */     byte[] __bytes;
/*      */     try
/*      */     {
/*  124 */       __bytes = new String("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/").getBytes("UTF-8");
/*      */     }
/*      */     catch (UnsupportedEncodingException use)
/*      */     {
/*  128 */       __bytes = _NATIVE_ALPHABET;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class OutputStream extends FilterOutputStream
/*      */   {
/*      */     private int options;
/*      */     private boolean encode;
/*      */     private int position;
/*      */     private byte[] buffer;
/*      */     private int bufferLength;
/*      */     private int lineLength;
/*      */     private boolean breakLines;
/*      */     private byte[] b4;
/*      */     private boolean suspendEncoding;
/*      */ 
/*      */     public OutputStream(OutputStream out)
/*      */     {
/* 1146 */       this(out, 1);
/*      */     }
/*      */ 
/*      */     public OutputStream(OutputStream out, int options)
/*      */     {
/* 1172 */       super();
/* 1173 */       this.options = options;
/* 1174 */       this.breakLines = ((options & 0x8) != 8);
/* 1175 */       this.encode = ((options & 0x1) == 1);
/* 1176 */       this.bufferLength = (this.encode ? 3 : 4);
/* 1177 */       this.buffer = new byte[this.bufferLength];
/* 1178 */       this.position = 0;
/* 1179 */       this.lineLength = 0;
/* 1180 */       this.suspendEncoding = false;
/* 1181 */       this.b4 = new byte[4];
/*      */     }
/*      */ 
/*      */     public void write(int theByte)
/*      */       throws IOException
/*      */     {
/* 1200 */       if (this.suspendEncoding)
/*      */       {
/* 1202 */         this.out.write(theByte);
/* 1203 */         return;
/*      */       }
/*      */ 
/* 1207 */       if (this.encode)
/*      */       {
/* 1209 */         this.buffer[(this.position++)] = ((byte)theByte);
/* 1210 */         if (this.position >= this.bufferLength)
/*      */         {
/* 1212 */           this.out.write(Base64.encode3to4(this.b4, this.buffer, this.bufferLength));
/*      */ 
/* 1214 */           this.lineLength += 4;
/* 1215 */           if ((this.breakLines) && (this.lineLength >= 76))
/*      */           {
/* 1217 */             this.out.write(10);
/* 1218 */             this.lineLength = 0;
/*      */           }
/*      */ 
/* 1221 */           this.position = 0;
/*      */         }
/*      */ 
/*      */       }
/* 1229 */       else if (Base64.DECODABET[(theByte & 0x7F)] > -5)
/*      */       {
/* 1231 */         this.buffer[(this.position++)] = ((byte)theByte);
/* 1232 */         if (this.position >= this.bufferLength)
/*      */         {
/* 1234 */           int len = Base64.decode4to3(this.buffer, 0, this.b4, 0);
/* 1235 */           this.out.write(this.b4, 0, len);
/*      */ 
/* 1237 */           this.position = 0;
/*      */         }
/*      */       }
/* 1240 */       else if (Base64.DECODABET[(theByte & 0x7F)] != -5)
/*      */       {
/* 1242 */         throw new IOException("Invalid character in Base64 data.");
/*      */       }
/*      */     }
/*      */ 
/*      */     public void write(byte[] theBytes, int off, int len)
/*      */       throws IOException
/*      */     {
/* 1261 */       if (this.suspendEncoding)
/*      */       {
/* 1263 */         this.out.write(theBytes, off, len);
/* 1264 */         return;
/*      */       }
/*      */ 
/* 1267 */       for (int i = 0; i < len; i++)
/*      */       {
/* 1269 */         write(theBytes[(off + i)]);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void flushBase64()
/*      */       throws IOException
/*      */     {
/* 1282 */       if (this.position > 0)
/*      */       {
/* 1284 */         if (this.encode)
/*      */         {
/* 1286 */           this.out.write(Base64.encode3to4(this.b4, this.buffer, this.position));
/* 1287 */           this.position = 0;
/*      */         }
/*      */         else
/*      */         {
/* 1291 */           throw new IOException("Base64 input not properly padded.");
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void close()
/*      */       throws IOException
/*      */     {
/* 1306 */       flushBase64();
/*      */ 
/* 1310 */       super.close();
/*      */ 
/* 1312 */       this.buffer = null;
/* 1313 */       this.out = null;
/*      */     }
/*      */ 
/*      */     public void suspendEncoding()
/*      */       throws IOException
/*      */     {
/* 1327 */       flushBase64();
/* 1328 */       this.suspendEncoding = true;
/*      */     }
/*      */ 
/*      */     public void resumeEncoding()
/*      */     {
/* 1341 */       this.suspendEncoding = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class InputStream extends FilterInputStream
/*      */   {
/*      */     private int options;
/*      */     private boolean encode;
/*      */     private int position;
/*      */     private byte[] buffer;
/*      */     private int bufferLength;
/*      */     private int numSigBytes;
/*      */     private int lineLength;
/*      */     private boolean breakLines;
/*      */ 
/*      */     public InputStream(InputStream in)
/*      */     {
/*  911 */       this(in, 0);
/*      */     }
/*      */ 
/*      */     public InputStream(InputStream in, int options)
/*      */     {
/*  938 */       super();
/*  939 */       this.options = options;
/*  940 */       this.breakLines = ((options & 0x8) != 8);
/*  941 */       this.encode = ((options & 0x1) == 1);
/*  942 */       this.breakLines = this.breakLines;
/*  943 */       this.encode = this.encode;
/*  944 */       this.bufferLength = (this.encode ? 4 : 3);
/*  945 */       this.buffer = new byte[this.bufferLength];
/*  946 */       this.position = -1;
/*  947 */       this.lineLength = 0;
/*      */     }
/*      */ 
/*      */     public int read()
/*      */       throws IOException
/*      */     {
/*  960 */       if (this.position < 0)
/*      */       {
/*  962 */         if (this.encode)
/*      */         {
/*  964 */           byte[] b3 = new byte[3];
/*  965 */           int numBinaryBytes = 0;
/*  966 */           for (int i = 0; i < 3; i++)
/*      */           {
/*      */             try
/*      */             {
/*  970 */               int b = this.in.read();
/*      */ 
/*  973 */               if (b >= 0)
/*      */               {
/*  975 */                 b3[i] = ((byte)b);
/*  976 */                 numBinaryBytes++;
/*      */               }
/*      */ 
/*      */             }
/*      */             catch (IOException e)
/*      */             {
/*  983 */               if (i == 0) {
/*  984 */                 throw e;
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*  989 */           if (numBinaryBytes > 0)
/*      */           {
/*  991 */             Base64.encode3to4(b3, 0, numBinaryBytes, this.buffer, 0);
/*  992 */             this.position = 0;
/*  993 */             this.numSigBytes = 4;
/*      */           }
/*      */           else
/*      */           {
/*  997 */             return -1;
/*      */           }
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1004 */           byte[] b4 = new byte[4];
/* 1005 */           int i = 0;
/* 1006 */           for (i = 0; i < 4; i++)
/*      */           {
/* 1009 */             int b = 0;
/*      */             do b = this.in.read();
/* 1011 */             while ((b >= 0) && (Base64.DECODABET[(b & 0x7F)] <= -5));
/*      */ 
/* 1013 */             if (b < 0) {
/*      */               break;
/*      */             }
/* 1016 */             b4[i] = ((byte)b);
/*      */           }
/*      */ 
/* 1019 */           if (i == 4)
/*      */           {
/* 1021 */             this.numSigBytes = Base64.decode4to3(b4, 0, this.buffer, 0);
/* 1022 */             this.position = 0;
/*      */           } else {
/* 1024 */             if (i == 0) {
/* 1025 */               return -1;
/*      */             }
/*      */ 
/* 1030 */             throw new IOException("Improperly padded Base64 input.");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1037 */       if (this.position >= 0)
/*      */       {
/* 1040 */         if (this.position >= this.numSigBytes) {
/* 1041 */           return -1;
/*      */         }
/* 1043 */         if ((this.encode) && (this.breakLines) && (this.lineLength >= 76))
/*      */         {
/* 1045 */           this.lineLength = 0;
/* 1046 */           return 10;
/*      */         }
/*      */ 
/* 1050 */         this.lineLength += 1;
/*      */ 
/* 1054 */         int b = this.buffer[(this.position++)];
/*      */ 
/* 1056 */         if (this.position >= this.bufferLength) {
/* 1057 */           this.position = -1;
/*      */         }
/* 1059 */         return b & 0xFF;
/*      */       }
/*      */ 
/* 1068 */       throw new IOException("Error in Base64 code reading stream.");
/*      */     }
/*      */ 
/*      */     public int read(byte[] dest, int off, int len)
/*      */       throws IOException
/*      */     {
/* 1089 */       for (int i = 0; i < len; i++)
/*      */       {
/* 1091 */         int b = read();
/*      */ 
/* 1096 */         if (b >= 0) {
/* 1097 */           dest[(off + i)] = ((byte)b); } else {
/* 1098 */           if (i != 0) break;
/* 1099 */           return -1;
/*      */         }
/*      */       }
/*      */ 
/* 1103 */       return i;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.Base64
 * JD-Core Version:    0.6.2
 */
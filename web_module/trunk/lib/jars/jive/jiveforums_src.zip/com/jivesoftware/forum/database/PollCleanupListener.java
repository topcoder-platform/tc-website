/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.Poll;
/*     */ import com.jivesoftware.base.PollException;
/*     */ import com.jivesoftware.base.PollManager;
/*     */ import com.jivesoftware.base.PollManagerFactory;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.event.UserEvent;
/*     */ import com.jivesoftware.base.event.UserListener;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.event.ForumEvent;
/*     */ import com.jivesoftware.forum.event.ForumListener;
/*     */ import com.jivesoftware.forum.event.MessageEvent;
/*     */ import com.jivesoftware.forum.event.MessageListener;
/*     */ import com.jivesoftware.forum.event.ThreadEvent;
/*     */ import com.jivesoftware.forum.event.ThreadListener;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class PollCleanupListener
/*     */   implements ForumListener, ThreadListener, MessageListener, UserListener
/*     */ {
/*     */   public void forumAdded(ForumEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void forumDeleted(ForumEvent event)
/*     */   {
/*     */     try
/*     */     {
/*  35 */       Iterator polls = PollManagerFactory.getInstance().getPolls(0, event.getForum().getID());
/*     */ 
/*  37 */       while (polls.hasNext()) {
/*  38 */         Poll poll = (Poll)polls.next();
/*  39 */         PollManagerFactory.getInstance().deletePoll(poll);
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e) {
/*  43 */       Log.error(e);
/*     */     }
/*     */     catch (PollException e) {
/*  46 */       Log.error(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void forumMoved(ForumEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void forumMerged(ForumEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadAdded(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadDeleted(ThreadEvent event) {
/*     */     try {
/*  64 */       Iterator polls = PollManagerFactory.getInstance().getPolls(1, event.getThread().getID());
/*     */ 
/*  66 */       while (polls.hasNext()) {
/*  67 */         Poll poll = (Poll)polls.next();
/*  68 */         PollManagerFactory.getInstance().deletePoll(poll);
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e) {
/*  72 */       Log.error(e);
/*     */     }
/*     */     catch (PollException e) {
/*  75 */       Log.error(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void threadMoved(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadModerationModified(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadRated(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageAdded(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageDeleted(MessageEvent event) {
/*     */     try {
/*  97 */       Iterator polls = PollManagerFactory.getInstance().getPolls(2, event.getMessage().getID());
/*     */ 
/*  99 */       while (polls.hasNext()) {
/* 100 */         Poll poll = (Poll)polls.next();
/* 101 */         PollManagerFactory.getInstance().deletePoll(poll);
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 105 */       Log.error(e);
/*     */     }
/*     */     catch (PollException e) {
/* 108 */       Log.error(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void messageModified(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageModerationModified(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageRated(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageMoved(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void userCreated(UserEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void userDeleted(UserEvent event) {
/*     */     try {
/* 134 */       if (event.getUser() == null) {
/* 135 */         Log.warn("Unable to run poll deletion for deleted user: unable to determine userID");
/* 136 */         return;
/*     */       }
/* 138 */       Iterator polls = PollManagerFactory.getInstance().getPolls(3, event.getUser().getID());
/*     */ 
/* 140 */       while (polls.hasNext()) {
/* 141 */         Poll poll = (Poll)polls.next();
/* 142 */         PollManagerFactory.getInstance().deletePoll(poll);
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 146 */       Log.error(e);
/*     */     }
/*     */     catch (PollException e) {
/* 149 */       Log.error(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void userModified(UserEvent event)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.PollCleanupListener
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.JiveManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.forum.Announcement;
/*     */ import com.jivesoftware.forum.AnnouncementManager;
/*     */ import com.jivesoftware.forum.AnnouncementNotFoundException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.event.AnnouncementEvent;
/*     */ import com.jivesoftware.forum.event.AnnouncementEventDispatcher;
/*     */ import com.jivesoftware.forum.event.CategoryEvent;
/*     */ import com.jivesoftware.forum.event.CategoryEventDispatcher;
/*     */ import com.jivesoftware.forum.event.CategoryListener;
/*     */ import com.jivesoftware.forum.event.ForumEvent;
/*     */ import com.jivesoftware.forum.event.ForumEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ForumListener;
/*     */ import com.jivesoftware.forum.proxy.AnnouncementProxy;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class DbAnnouncementManager
/*     */   implements AnnouncementManager, JiveManager, CategoryListener, ForumListener
/*     */ {
/*     */   private static final String GET_ANNOUNCEMENTS = "SELECT announcementID, startDate FROM jiveAnnounce WHERE objectType=? AND objectID=? ORDER BY startDate DESC";
/*     */   private static final String GET_GLOBAL_ANNOUNCEMENTS = "SELECT announcementID, startDate FROM jiveAnnounce WHERE objectType=? AND objectID IS NULL ORDER BY startDate DESC";
/*     */   private static final String DELETE_ANNOUNCEMENT = "DELETE FROM jiveAnnounce WHERE announcementID=?";
/*     */   private static final String DELETE_ANNOUNCEMENT_PROPS = "DELETE FROM jiveAnnounceProp WHERE announcementID=?";
/*     */   private static final String MOVE_ANNOUNCEMENTS = "UPDATE jiveAnnounce SET objectID=? WHERE objectType=? AND objectID=?";
/*     */   private static DbForumFactory FACTORY;
/*  49 */   private static DbAnnouncementManager instance = new DbAnnouncementManager();
/*  50 */   private static boolean initialized = false;
/*     */ 
/*     */   public static DbAnnouncementManager getInstance() {
/*  53 */     return instance;
/*     */   }
/*     */ 
/*     */   public synchronized void initialize()
/*     */   {
/*  59 */     if (!initialized) {
/*  60 */       FACTORY = DbForumFactory.getInstance();
/*     */ 
/*  62 */       CategoryEventDispatcher.getInstance().addListener(this);
/*  63 */       ForumEventDispatcher.getInstance().addListener(this);
/*  64 */       initialized = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Announcement createAnnouncement(User user) throws UnauthorizedException {
/*  69 */     return new DbAnnouncement(17, -1L, user.getID());
/*     */   }
/*     */ 
/*     */   public Announcement createAnnouncement(User user, ForumCategory category) throws UnauthorizedException {
/*  73 */     return new DbAnnouncement(14, category.getID(), user.getID());
/*     */   }
/*     */ 
/*     */   public Announcement createAnnouncement(User user, Forum forum) throws UnauthorizedException {
/*  77 */     return new DbAnnouncement(0, forum.getID(), user.getID());
/*     */   }
/*     */ 
/*     */   public void addAnnouncement(Announcement announcement) throws UnauthorizedException {
/*  81 */     DbAnnouncement dbAnnouncement = null;
/*  82 */     if ((announcement instanceof AnnouncementProxy)) {
/*  83 */       AnnouncementProxy proxyAnnouncement = (AnnouncementProxy)announcement;
/*  84 */       dbAnnouncement = (DbAnnouncement)proxyAnnouncement.getProxiedAnnouncement();
/*     */     }
/*     */     else {
/*  87 */       dbAnnouncement = (DbAnnouncement)announcement;
/*     */     }
/*  89 */     if (dbAnnouncement.getID() != -1L) {
/*  90 */       throw new IllegalStateException("Announcement already added: " + announcement);
/*     */     }
/*  92 */     dbAnnouncement.insertIntoDb();
/*     */ 
/*  96 */     FACTORY.cacheManager.announcementPut(dbAnnouncement.getID(), dbAnnouncement);
/*     */ 
/*  99 */     String key = announcement.getContainerObjectType() + "-" + announcement.getContainerObjectID();
/*     */ 
/* 101 */     FACTORY.cacheManager.announcementRemove(key);
/*     */ 
/* 104 */     AnnouncementEvent event = new AnnouncementEvent(150, announcement, Collections.EMPTY_MAP);
/*     */ 
/* 106 */     AnnouncementEventDispatcher.getInstance().dispatchEvent(event);
/*     */   }
/*     */ 
/*     */   public Announcement getAnnouncement(long announcementID) throws AnnouncementNotFoundException
/*     */   {
/* 111 */     return FACTORY.cacheManager.getAnnouncement(announcementID);
/*     */   }
/*     */ 
/*     */   public int getAnnouncementCount(Object container) {
/* 115 */     long[] announcementIDs = null;
/* 116 */     if (container == null) {
/* 117 */       announcementIDs = getAnnouncements(17, -1L);
/*     */     }
/* 119 */     else if ((container instanceof ForumCategory)) {
/* 120 */       announcementIDs = getAnnouncements(14, ((ForumCategory)container).getID());
/*     */     }
/* 123 */     else if ((container instanceof Forum)) {
/* 124 */       announcementIDs = getAnnouncements(0, ((Forum)container).getID());
/*     */     }
/*     */     else
/*     */     {
/* 128 */       throw new IllegalArgumentException("Invalid container object: " + container);
/*     */     }
/*     */ 
/* 131 */     if (announcementIDs.length == 0) {
/* 132 */       return 0;
/*     */     }
/*     */ 
/* 135 */     LongList results = new LongList();
/* 136 */     Date currentDate = new Date(CacheFactory.currentTime);
/* 137 */     for (int i = 0; i < announcementIDs.length; i++)
/*     */       try {
/* 139 */         Announcement announce = getAnnouncement(announcementIDs[i]);
/* 140 */         if (announce.getEndDate() == null) {
/* 141 */           if (!announce.getStartDate().before(currentDate)) {
/* 142 */             results.add(announcementIDs[i]);
/*     */           }
/*     */         }
/* 145 */         else if ((!announce.getEndDate().after(currentDate)) && (!announce.getStartDate().before(currentDate)))
/*     */         {
/* 148 */           results.add(announcementIDs[i]);
/*     */         }
/*     */       }
/*     */       catch (AnnouncementNotFoundException anfe) {
/*     */       }
/* 153 */     return results.size();
/*     */   }
/*     */ 
/*     */   public int getAnnouncementCount(Object container, Date startDate, Date endDate)
/*     */   {
/* 159 */     if ((startDate != null) && (endDate != null) && (startDate.getTime() > endDate.getTime())) {
/* 160 */       throw new IllegalArgumentException("Start date may not be greater than end date");
/*     */     }
/*     */ 
/* 164 */     long[] announcementIDs = null;
/* 165 */     if (container == null) {
/* 166 */       announcementIDs = getAnnouncements(17, -1L);
/*     */     }
/* 168 */     else if ((container instanceof ForumCategory)) {
/* 169 */       announcementIDs = getAnnouncements(14, ((ForumCategory)container).getID());
/*     */     }
/* 172 */     else if ((container instanceof Forum)) {
/* 173 */       announcementIDs = getAnnouncements(0, ((Forum)container).getID());
/*     */     }
/*     */     else
/*     */     {
/* 177 */       throw new IllegalArgumentException("Invalid container object: " + container);
/*     */     }
/*     */ 
/* 181 */     if (announcementIDs.length == 0) {
/* 182 */       return 0;
/*     */     }
/*     */ 
/* 187 */     if ((startDate == null) && (endDate == null)) {
/* 188 */       return announcementIDs.length;
/*     */     }
/*     */ 
/* 191 */     if (startDate == null) {
/* 192 */       startDate = new Date(-9223372036854775808L);
/*     */     }
/* 194 */     if (endDate == null) {
/* 195 */       endDate = new Date(9223372036854775807L);
/*     */     }
/*     */ 
/* 199 */     int count = 0;
/* 200 */     for (int i = 0; i < announcementIDs.length; i++)
/*     */       try {
/* 202 */         Announcement announce = getAnnouncement(announcementIDs[i]);
/* 203 */         Date announceStart = announce.getStartDate();
/* 204 */         Date announceEnd = announce.getEndDate();
/*     */ 
/* 207 */         if ((announceStart == null) && (announceEnd == null)) {
/* 208 */           count++;
/*     */         }
/*     */         else {
/* 211 */           if (announceStart == null) {
/* 212 */             announceStart = new Date(-9223372036854775808L);
/*     */           }
/* 214 */           if (announceEnd == null) {
/* 215 */             announceEnd = new Date(9223372036854775807L);
/*     */           }
/* 217 */           if ((announceStart.getTime() >= startDate.getTime()) || (announceEnd.getTime() <= endDate.getTime()))
/*     */           {
/* 219 */             if ((announceStart.getTime() <= endDate.getTime()) && (announceEnd.getTime() >= startDate.getTime()))
/*     */             {
/* 221 */               count++;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (AnnouncementNotFoundException anfe) {
/*     */       }
/* 228 */     return count;
/*     */   }
/*     */ 
/*     */   public Iterator getAnnouncements(Object container) {
/* 232 */     long[] announcementIDs = null;
/* 233 */     if (container == null) {
/* 234 */       announcementIDs = getAnnouncements(17, -1L);
/*     */     }
/* 236 */     else if ((container instanceof ForumCategory)) {
/* 237 */       announcementIDs = getAnnouncements(14, ((ForumCategory)container).getID());
/*     */     }
/* 240 */     else if ((container instanceof Forum)) {
/* 241 */       announcementIDs = getAnnouncements(0, ((Forum)container).getID());
/*     */     }
/*     */     else
/*     */     {
/* 245 */       throw new IllegalArgumentException("Invalid container object: " + container);
/*     */     }
/* 247 */     if (announcementIDs.length == 0) {
/* 248 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/*     */ 
/* 251 */     LongList results = new LongList();
/* 252 */     Date currentDate = new Date();
/* 253 */     for (int i = 0; i < announcementIDs.length; i++)
/*     */       try {
/* 255 */         Announcement announce = getAnnouncement(announcementIDs[i]);
/* 256 */         if (announce.getEndDate() == null) {
/* 257 */           if (announce.getStartDate().before(currentDate)) {
/* 258 */             results.add(announcementIDs[i]);
/*     */           }
/*     */         }
/* 261 */         else if ((announce.getEndDate().after(currentDate)) && (announce.getStartDate().before(currentDate)))
/*     */         {
/* 264 */           results.add(announcementIDs[i]);
/*     */         }
/*     */       }
/*     */       catch (AnnouncementNotFoundException anfe) {
/*     */       }
/* 269 */     return new DatabaseObjectIterator(22, results.toArray(), this);
/*     */   }
/*     */ 
/*     */   public Iterator getAnnouncements(Object container, Date startDate, Date endDate) {
/* 273 */     long[] announcementIDs = null;
/* 274 */     if (container == null) {
/* 275 */       announcementIDs = getAnnouncements(17, -1L);
/*     */     }
/* 277 */     else if ((container instanceof ForumCategory)) {
/* 278 */       announcementIDs = getAnnouncements(14, ((ForumCategory)container).getID());
/*     */     }
/* 281 */     else if ((container instanceof Forum)) {
/* 282 */       announcementIDs = getAnnouncements(0, ((Forum)container).getID());
/*     */     }
/*     */     else
/*     */     {
/* 286 */       throw new IllegalArgumentException("Invalid container object: " + container);
/*     */     }
/* 288 */     if (announcementIDs.length == 0) {
/* 289 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/* 291 */     if (startDate == null) {
/* 292 */       startDate = new Date(-9223372036854775808L);
/*     */     }
/* 294 */     if (endDate == null) {
/* 295 */       endDate = new Date(9223372036854775807L);
/*     */     }
/*     */ 
/* 298 */     LongList results = new LongList();
/* 299 */     for (int i = 0; i < announcementIDs.length; i++)
/*     */       try {
/* 301 */         Announcement announce = getAnnouncement(announcementIDs[i]);
/* 302 */         if (announce.getEndDate() == null) {
/* 303 */           if (!announce.getStartDate().before(startDate)) {
/* 304 */             results.add(announcementIDs[i]);
/*     */           }
/*     */         }
/* 307 */         else if ((!announce.getEndDate().after(endDate)) && (!announce.getStartDate().before(startDate)))
/*     */         {
/* 310 */           results.add(announcementIDs[i]);
/*     */         }
/*     */       }
/*     */       catch (AnnouncementNotFoundException anfe) {
/*     */       }
/* 315 */     return new DatabaseObjectIterator(22, results.toArray(), this);
/*     */   }
/*     */ 
/*     */   public void deleteAnnouncement(Announcement announcement) {
/*     */     try {
/* 320 */       announcement = getAnnouncement(announcement.getID());
/*     */     }
/*     */     catch (AnnouncementNotFoundException e) {
/*     */     }
/* 324 */     AnnouncementEvent event = new AnnouncementEvent(151, announcement, Collections.EMPTY_MAP);
/*     */ 
/* 326 */     AnnouncementEventDispatcher.getInstance().dispatchEvent(event);
/*     */ 
/* 329 */     Connection con = null;
/* 330 */     PreparedStatement pstmt = null;
/*     */     try {
/* 332 */       con = ConnectionManager.getConnection();
/*     */ 
/* 334 */       pstmt = con.prepareStatement("DELETE FROM jiveAnnounceProp WHERE announcementID=?");
/* 335 */       pstmt.setLong(1, announcement.getID());
/* 336 */       pstmt.execute();
/* 337 */       pstmt.close();
/*     */ 
/* 340 */       for (Iterator i = announcement.getAttachments(); i.hasNext(); ) {
/* 341 */         DbAttachment attachment = (DbAttachment)i.next();
/* 342 */         attachment.delete(con);
/*     */       }
/*     */ 
/* 346 */       pstmt = con.prepareStatement("DELETE FROM jiveAnnounce WHERE announcementID=?");
/* 347 */       pstmt.setLong(1, announcement.getID());
/* 348 */       pstmt.execute();
/*     */     }
/*     */     catch (SQLException sqle)
/*     */     {
/* 352 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 355 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 357 */     FACTORY.cacheManager.announcementRemove(announcement.getID());
/*     */ 
/* 360 */     String key = announcement.getContainerObjectType() + "-" + announcement.getContainerObjectID();
/*     */ 
/* 362 */     FACTORY.cacheManager.announcementRemove(key);
/*     */   }
/*     */ 
/*     */   public void categoryAdded(CategoryEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void categoryDeleted(CategoryEvent event)
/*     */   {
/* 372 */     ForumCategory category = event.getCategory();
/*     */ 
/* 374 */     long[] announcements = getAnnouncements(14, category.getID());
/* 375 */     for (int i = 0; i < announcements.length; i++)
/*     */       try {
/* 377 */         deleteAnnouncement(getAnnouncement(announcements[i]));
/*     */       }
/*     */       catch (AnnouncementNotFoundException anfe)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   public void categoryMoved(CategoryEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void forumAdded(ForumEvent event) {
/*     */   }
/*     */ 
/*     */   public void forumDeleted(ForumEvent event) {
/* 392 */     Forum forum = event.getForum();
/*     */ 
/* 394 */     long[] announcements = getAnnouncements(0, forum.getID());
/* 395 */     for (int i = 0; i < announcements.length; i++)
/*     */       try {
/* 397 */         deleteAnnouncement(getAnnouncement(announcements[i]));
/*     */       }
/*     */       catch (AnnouncementNotFoundException anfe)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   public void forumMoved(ForumEvent event) {
/*     */   }
/*     */ 
/*     */   public void forumMerged(ForumEvent event) {
/* 408 */     long oldForumID = ((Long)event.getParams().get("mergedForumID")).longValue();
/* 409 */     long newForumID = event.getForum().getID();
/* 410 */     Connection con = null;
/* 411 */     PreparedStatement pstmt = null;
/*     */     try {
/* 413 */       con = ConnectionManager.getConnection();
/* 414 */       pstmt = con.prepareStatement("UPDATE jiveAnnounce SET objectID=? WHERE objectType=? AND objectID=?");
/* 415 */       pstmt.setLong(1, newForumID);
/* 416 */       pstmt.setInt(2, 0);
/* 417 */       pstmt.setLong(3, oldForumID);
/* 418 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 421 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 424 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 428 */     FACTORY.cacheManager.announcementRemove("0-" + oldForumID);
/* 429 */     FACTORY.cacheManager.announcementRemove("0-" + newForumID);
/*     */   }
/*     */ 
/*     */   private long[] getAnnouncements(int objectType, long objectID)
/*     */   {
/* 435 */     String key = (objectType + "-" + objectID).intern();
/* 436 */     if (!FACTORY.cacheManager.announcementCache.containsKey(key)) {
/* 437 */       synchronized (key)
/*     */       {
/* 440 */         if (FACTORY.cacheManager.announcementCache.containsKey(key)) {
/* 441 */           return (long[])FACTORY.cacheManager.announcementCache.get(key);
/*     */         }
/*     */ 
/* 444 */         LongList announcements = new LongList();
/* 445 */         Connection con = null;
/* 446 */         PreparedStatement pstmt = null;
/*     */         try {
/* 448 */           con = ConnectionManager.getConnection();
/* 449 */           if (objectID != -1L) {
/* 450 */             pstmt = con.prepareStatement("SELECT announcementID, startDate FROM jiveAnnounce WHERE objectType=? AND objectID=? ORDER BY startDate DESC");
/*     */           }
/*     */           else {
/* 453 */             pstmt = con.prepareStatement("SELECT announcementID, startDate FROM jiveAnnounce WHERE objectType=? AND objectID IS NULL ORDER BY startDate DESC");
/*     */           }
/* 455 */           pstmt.setInt(1, objectType);
/* 456 */           if (objectID != -1L) {
/* 457 */             pstmt.setLong(2, objectID);
/*     */           }
/* 459 */           ResultSet rs = pstmt.executeQuery();
/* 460 */           while (rs.next()) {
/* 461 */             announcements.add(rs.getLong(1));
/*     */           }
/* 463 */           rs.close();
/*     */         }
/*     */         catch (SQLException sqle) {
/* 466 */           Log.error(sqle);
/*     */         }
/*     */         finally {
/* 469 */           ConnectionManager.closeConnection(pstmt, con);
/*     */         }
/* 471 */         FACTORY.cacheManager.announcementPut(key, announcements.toArray());
/*     */       }
/*     */     }
/*     */ 
/* 475 */     return (long[])FACTORY.cacheManager.announcementCache.get(key);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbAnnouncementManager
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.FilterManager;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.PermissionsManager;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.InterceptorManager;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class ForumCategoryProxy
/*     */   implements ForumCategory
/*     */ {
/*     */   private ForumCategory category;
/*     */   private AuthToken authToken;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public ForumCategoryProxy(ForumCategory category, AuthToken authToken, Permissions permissions)
/*     */   {
/*  47 */     this.category = category;
/*  48 */     this.authToken = authToken;
/*  49 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public long getID()
/*     */   {
/*  55 */     return this.category.getID();
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  59 */     return this.category.getName();
/*     */   }
/*     */ 
/*     */   public void setName(String name) throws UnauthorizedException {
/*  63 */     if (isAdmin()) {
/*  64 */       this.category.setName(name);
/*     */     }
/*     */     else
/*  67 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  72 */     return this.category.getDescription();
/*     */   }
/*     */ 
/*     */   public void setDescription(String description) throws UnauthorizedException {
/*  76 */     if (isAdmin()) {
/*  77 */       this.category.setDescription(description);
/*     */     }
/*     */     else
/*  80 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Date getCreationDate()
/*     */   {
/*  85 */     return this.category.getCreationDate();
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Date creationDate) throws UnauthorizedException {
/*  89 */     if (isAdmin()) {
/*  90 */       this.category.setCreationDate(creationDate);
/*     */     }
/*     */     else
/*  93 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Date getModificationDate()
/*     */   {
/*  98 */     return this.category.getModificationDate();
/*     */   }
/*     */ 
/*     */   public void setModificationDate(Date modificationDate) throws UnauthorizedException {
/* 102 */     if (isAdmin()) {
/* 103 */       this.category.setModificationDate(modificationDate);
/*     */     }
/*     */     else
/* 106 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public String getProperty(String name)
/*     */   {
/* 111 */     return this.category.getProperty(name);
/*     */   }
/*     */ 
/*     */   public Collection getProperties(String parentName) {
/* 115 */     return this.category.getProperties(parentName);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value) throws UnauthorizedException {
/* 119 */     if (isAdmin()) {
/* 120 */       this.category.setProperty(name, value);
/*     */     }
/*     */     else
/* 123 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) throws UnauthorizedException
/*     */   {
/* 128 */     if (isAdmin()) {
/* 129 */       this.category.deleteProperty(name);
/*     */     }
/*     */     else
/* 132 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames()
/*     */   {
/* 137 */     return this.category.getPropertyNames();
/*     */   }
/*     */ 
/*     */   public int getForumCount() {
/* 141 */     return this.category.getForumCount();
/*     */   }
/*     */ 
/*     */   public int getForumCount(ResultFilter resultFilter) {
/* 145 */     return this.category.getForumCount(resultFilter);
/*     */   }
/*     */ 
/*     */   public int getRecursiveForumCount() {
/* 149 */     return this.category.getRecursiveForumCount();
/*     */   }
/*     */ 
/*     */   public int getRecursiveForumCount(ResultFilter resultFilter) {
/* 153 */     return this.category.getRecursiveForumCount(resultFilter);
/*     */   }
/*     */ 
/*     */   public Iterator getForums() {
/* 157 */     return new IteratorProxy(0, this.category.getForums(), this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getForums(ResultFilter resultFilter) {
/* 161 */     return new IteratorProxy(0, this.category.getForums(resultFilter), this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getRecursiveForums()
/*     */   {
/* 166 */     return new IteratorProxy(0, this.category.getRecursiveForums(), this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getRecursiveForums(ResultFilter resultFilter)
/*     */   {
/* 171 */     return new IteratorProxy(0, this.category.getRecursiveForums(resultFilter), this.authToken);
/*     */   }
/*     */ 
/*     */   public void setForumIndex(Forum forum, int newIndex)
/*     */     throws UnauthorizedException
/*     */   {
/* 178 */     if (isAdmin()) {
/* 179 */       this.category.setForumIndex(forum, newIndex);
/*     */     }
/*     */     else
/* 182 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void moveForum(Forum forum, ForumCategory destinationCategory)
/*     */     throws UnauthorizedException
/*     */   {
/* 190 */     if ((isAdmin()) && (destinationCategory.isAuthorized(576460752303424000L)))
/*     */     {
/* 194 */       this.category.moveForum(forum, destinationCategory);
/*     */     }
/*     */     else
/* 197 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public ForumCategory getParentCategory()
/*     */   {
/* 202 */     ForumCategory parentCategory = this.category.getParentCategory();
/* 203 */     if (parentCategory == null) {
/* 204 */       return null;
/*     */     }
/*     */ 
/* 207 */     return new ForumCategoryProxy(parentCategory, this.authToken, parentCategory.getPermissions(this.authToken));
/*     */   }
/*     */ 
/*     */   public int getCategoryCount()
/*     */   {
/* 213 */     return this.category.getCategoryCount();
/*     */   }
/*     */ 
/*     */   public Iterator getCategories() {
/* 217 */     return new IteratorProxy(14, this.category.getCategories(), this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getCategories(int startIndex, int numResults) {
/* 221 */     return new IteratorProxy(14, this.category.getCategories(startIndex, numResults), this.authToken);
/*     */   }
/*     */ 
/*     */   public int getRecursiveCategoryCount()
/*     */   {
/* 226 */     return this.category.getRecursiveCategoryCount();
/*     */   }
/*     */ 
/*     */   public Iterator getRecursiveCategories() {
/* 230 */     return new IteratorProxy(14, this.category.getRecursiveCategories(), this.authToken);
/*     */   }
/*     */ 
/*     */   public int getCategoryDepth() {
/* 234 */     return this.category.getCategoryDepth();
/*     */   }
/*     */ 
/*     */   public void setCategoryIndex(ForumCategory forumCategory, int newIndex) throws UnauthorizedException {
/* 238 */     if (isAdmin()) {
/* 239 */       this.category.setCategoryIndex(forumCategory, newIndex);
/*     */     }
/*     */     else
/* 242 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void moveCategory(ForumCategory forumCategory, ForumCategory destinationCategory)
/*     */     throws UnauthorizedException
/*     */   {
/* 249 */     if ((isAdmin()) && (destinationCategory.isAuthorized(576460752303424000L)))
/*     */     {
/* 253 */       this.category.moveCategory(forumCategory, destinationCategory);
/*     */     }
/*     */     else
/* 256 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public ForumCategory createCategory(String name, String description) throws UnauthorizedException
/*     */   {
/* 261 */     if (isAdmin()) {
/* 262 */       ForumCategory newCategory = this.category.createCategory(name, description);
/* 263 */       return new ForumCategoryProxy(newCategory, this.authToken, newCategory.getPermissions(this.authToken));
/*     */     }
/*     */ 
/* 266 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteCategory(ForumCategory forumCategory) throws UnauthorizedException
/*     */   {
/* 271 */     if (isAdmin()) {
/* 272 */       this.category.deleteCategory(forumCategory);
/*     */     }
/*     */     else
/* 275 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteForum(Forum forum) throws UnauthorizedException
/*     */   {
/* 280 */     if (isAdmin()) {
/* 281 */       this.category.deleteForum(forum);
/*     */     }
/*     */     else
/* 284 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getPopularThreads()
/*     */   {
/* 289 */     Iterator iterator = this.category.getPopularThreads();
/* 290 */     return new IteratorProxy(1, iterator, this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getThreads() {
/* 294 */     return new IteratorProxy(1, this.category.getThreads(), this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getThreads(ResultFilter resultFilter) {
/* 298 */     return new IteratorProxy(1, this.category.getThreads(resultFilter), this.authToken);
/*     */   }
/*     */ 
/*     */   public int getThreadCount()
/*     */   {
/* 303 */     return this.category.getThreadCount();
/*     */   }
/*     */ 
/*     */   public int getThreadCount(ResultFilter resultFilter) {
/* 307 */     return this.category.getThreadCount(resultFilter);
/*     */   }
/*     */ 
/*     */   public int getMessageCount() {
/* 311 */     return this.category.getMessageCount();
/*     */   }
/*     */ 
/*     */   public int getMessageCount(ResultFilter resultFilter) {
/* 315 */     return this.category.getMessageCount(resultFilter);
/*     */   }
/*     */ 
/*     */   public Iterator getMessages() {
/* 319 */     return new IteratorProxy(2, this.category.getMessages(), this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getMessages(ResultFilter resultFilter) {
/* 323 */     return new IteratorProxy(2, this.category.getMessages(resultFilter), this.authToken);
/*     */   }
/*     */ 
/*     */   public ForumMessage getLatestMessage()
/*     */   {
/* 328 */     if (getMessageCount() == 0) {
/* 329 */       return null;
/*     */     }
/* 331 */     ResultFilter filter = new ResultFilter();
/* 332 */     filter.setSortOrder(0);
/* 333 */     filter.setSortField(9);
/*     */ 
/* 335 */     filter.setModificationDateRangeMin(ResultFilter.roundDate(this.category.getModificationDate(), 86400));
/*     */ 
/* 337 */     filter.setNumResults(10);
/* 338 */     Iterator messages = getMessages(filter);
/* 339 */     if (messages.hasNext()) {
/* 340 */       return new ForumMessageProxy((ForumMessage)messages.next(), this.authToken, this.permissions);
/*     */     }
/*     */ 
/* 343 */     return null;
/*     */   }
/*     */ 
/*     */   public PermissionsManager getPermissionsManager() throws UnauthorizedException
/*     */   {
/* 348 */     if (isAdmin()) {
/* 349 */       return new PermissionsManagerProxy(14, this.category.getID(), this.permissions);
/*     */     }
/*     */ 
/* 353 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public FilterManager getFilterManager()
/*     */   {
/* 358 */     return new FilterManagerProxy(this.category.getFilterManager(), 14, this.permissions);
/*     */   }
/*     */ 
/*     */   public InterceptorManager getInterceptorManager() throws UnauthorizedException
/*     */   {
/* 363 */     if (isAdmin()) {
/* 364 */       return new InterceptorManagerProxy(this.category.getInterceptorManager(), this.permissions);
/*     */     }
/*     */ 
/* 367 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Permissions getPermissions(AuthToken authToken)
/*     */   {
/* 372 */     return this.category.getPermissions(authToken);
/*     */   }
/*     */ 
/*     */   public boolean isAuthorized(long type) {
/* 376 */     return this.permissions.hasPermission(type);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 380 */     return this.category.toString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object) {
/* 384 */     return this.category.equals(object);
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 388 */     return this.category.hashCode();
/*     */   }
/*     */ 
/*     */   private boolean isAdmin() {
/* 392 */     return this.permissions.hasPermission(576460752303424000L);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.ForumCategoryProxy
 * JD-Core Version:    0.6.2
 */
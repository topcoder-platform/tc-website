/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.database.CachedPreparedStatement;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class ForumBlockIterator
/*     */   implements Iterator
/*     */ {
/*     */   private long[] forumBlock;
/*     */   private int blockID;
/*     */   private int blockStart;
/*     */   private CachedPreparedStatement query;
/*     */   private int startIndex;
/*     */   private int currentIndex;
/*     */   private int endIndex;
/*     */   private long categoryID;
/*     */   private DbForumFactory factory;
/*  39 */   private Object previousElement = null;
/*  40 */   private Object nextElement = null;
/*     */ 
/*     */   protected ForumBlockIterator(long[] forumBlock, CachedPreparedStatement query, int startIndex, int endIndex, long categoryID, DbForumFactory factory)
/*     */   {
/*  56 */     this.forumBlock = forumBlock;
/*  57 */     this.blockID = (startIndex / 400);
/*  58 */     this.blockStart = (this.blockID * 400);
/*  59 */     this.query = query;
/*  60 */     this.currentIndex = (startIndex - 1);
/*  61 */     this.startIndex = startIndex;
/*  62 */     this.endIndex = endIndex;
/*     */ 
/*  64 */     this.categoryID = categoryID;
/*  65 */     this.factory = factory;
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/*  70 */     if (this.currentIndex == this.endIndex) {
/*  71 */       return false;
/*     */     }
/*     */ 
/*  76 */     if (this.nextElement == null) {
/*  77 */       this.nextElement = getNextElement();
/*     */ 
/*  79 */       if (this.nextElement == null) {
/*  80 */         return false;
/*     */       }
/*     */     }
/*  83 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean hasPrevious()
/*     */   {
/*  88 */     if (this.currentIndex == this.startIndex) {
/*  89 */       return false;
/*     */     }
/*     */ 
/*  93 */     if (this.previousElement == null) {
/*  94 */       this.previousElement = getPreviousElement();
/*     */ 
/*  96 */       if (this.previousElement == null) {
/*  97 */         return false;
/*     */       }
/*     */     }
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */   public Object next() throws NoSuchElementException {
/* 104 */     Object element = null;
/* 105 */     if (this.nextElement != null) {
/* 106 */       element = this.nextElement;
/* 107 */       this.nextElement = null;
/*     */     }
/*     */     else {
/* 110 */       element = getNextElement();
/* 111 */       if (element == null) {
/* 112 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/* 115 */     return element;
/*     */   }
/*     */ 
/*     */   public Object previous() {
/* 119 */     Object element = null;
/* 120 */     if (this.previousElement != null) {
/* 121 */       element = this.previousElement;
/* 122 */       this.previousElement = null;
/*     */     }
/*     */     else {
/* 125 */       element = getPreviousElement();
/* 126 */       if (element == null) {
/* 127 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/* 130 */     return element;
/*     */   }
/*     */ 
/*     */   public void remove() {
/* 134 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void setIndex(Forum forum)
/*     */   {
/* 140 */     this.nextElement = null;
/* 141 */     this.previousElement = null;
/*     */ 
/* 145 */     long forumID = forum.getID();
/*     */ 
/* 147 */     for (int i = this.startIndex; i < this.endIndex; i++) {
/* 148 */       long[] currentBlock = QueryCache.getBlock(this.query, 14, this.categoryID, i, true);
/*     */ 
/* 150 */       if (currentBlock.length == 0) {
/* 151 */         throw new NoSuchElementException("Forum with id " + forumID + " is not a valid index in the iteration.");
/*     */       }
/*     */ 
/* 154 */       int blockID = i / 400;
/* 155 */       int blockEnd = blockID * 400 + 400;
/*     */ 
/* 158 */       if (this.startIndex < blockEnd)
/*     */       {
/* 161 */         int j = this.startIndex % 400;
/* 162 */         for (; j < currentBlock.length; i++)
/*     */         {
/* 164 */           if (currentBlock[j] == forumID) {
/* 165 */             this.currentIndex = i;
/*     */             return;
/*     */           }
/* 162 */           j++;
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 172 */         for (int j = 0; j < currentBlock.length; i++) {
/* 173 */           if (currentBlock[j] == forumID) {
/* 174 */             this.currentIndex = i;
/*     */             return;
/*     */           }
/* 172 */           j++;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object getNextElement()
/*     */   {
/* 189 */     this.previousElement = null;
/* 190 */     Object element = null;
/* 191 */     while ((this.currentIndex + 1 < this.endIndex) && (element == null)) {
/* 192 */       this.currentIndex += 1;
/* 193 */       element = getElement(this.currentIndex);
/*     */     }
/* 195 */     return element;
/*     */   }
/*     */ 
/*     */   private Object getPreviousElement()
/*     */   {
/* 205 */     this.nextElement = null;
/*     */ 
/* 207 */     Object element = null;
/* 208 */     while ((this.currentIndex >= this.startIndex) && (element == null)) {
/* 209 */       this.currentIndex -= 1;
/* 210 */       element = getElement(this.currentIndex);
/*     */     }
/* 212 */     return element;
/*     */   }
/*     */ 
/*     */   private Object getElement(int index) {
/* 216 */     if (index < 0) {
/* 217 */       return null;
/*     */     }
/*     */ 
/* 220 */     if ((index < this.blockStart) || (index >= this.blockStart + 400))
/*     */     {
/* 222 */       this.forumBlock = QueryCache.getBlock(this.query, 14, this.categoryID, index, true);
/*     */ 
/* 224 */       this.blockID = (index / 400);
/* 225 */       this.blockStart = (this.blockID * 400);
/*     */     }
/* 227 */     Object element = null;
/*     */ 
/* 230 */     int relativeIndex = index % 400;
/*     */ 
/* 232 */     if (relativeIndex < this.forumBlock.length)
/*     */       try
/*     */       {
/* 235 */         element = this.factory.cacheManager.getForum(this.forumBlock[relativeIndex]);
/*     */       }
/*     */       catch (ForumNotFoundException fnfe) {
/*     */       }
/* 239 */     return element;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.ForumBlockIterator
 * JD-Core Version:    0.6.2
 */
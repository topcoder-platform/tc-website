/*    */ package com.jivesoftware.forum.nntp.spi;
/*    */ 
/*    */ import com.jivesoftware.forum.database.DbForumMessage;
/*    */ import com.jivesoftware.util.MultiIterator;
/*    */ 
/*    */ public class MultiArticleIterator extends MultiIterator
/*    */ {
/*    */   public Object next()
/*    */   {
/* 24 */     return new FMessageArticleAdapter((DbForumMessage)super.next());
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.MultiArticleIterator
 * JD-Core Version:    0.6.2
 */
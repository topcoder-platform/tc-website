/*     */ package com.jivesoftware.forum.action.rss;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.base.action.rss.RSSActionSupport;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.util.SkinUtils;
/*     */ import com.jivesoftware.util.LocaleUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class RSSMessages extends RSSActionSupport
/*     */ {
/*  32 */   private long categoryID = 0L;
/*  33 */   private long forumID = 0L;
/*  34 */   private long threadID = 0L;
/*     */   private String rssUsername;
/*     */   private boolean full;
/*     */   private ForumCategory category;
/*     */   private Forum forum;
/*     */   private ForumThread thread;
/*     */   private User rssUser;
/*     */   private Iterator messages;
/*     */ 
/*     */   public long getCategoryID()
/*     */   {
/*  46 */     return this.categoryID;
/*     */   }
/*     */ 
/*     */   public void setCategoryID(long categoryID) {
/*  50 */     this.categoryID = categoryID;
/*     */   }
/*     */ 
/*     */   public long getForumID() {
/*  54 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID) {
/*  58 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public long getThreadID() {
/*  62 */     return this.threadID;
/*     */   }
/*     */ 
/*     */   public void setThreadID(long threadID) {
/*  66 */     this.threadID = threadID;
/*     */   }
/*     */ 
/*     */   public ForumCategory getCategory() {
/*  70 */     return this.category;
/*     */   }
/*     */ 
/*     */   public Forum getForum() {
/*  74 */     return this.forum;
/*     */   }
/*     */ 
/*     */   public ForumThread getThread() {
/*  78 */     return this.thread;
/*     */   }
/*     */ 
/*     */   public User getRssUser() {
/*  82 */     return this.rssUser;
/*     */   }
/*     */ 
/*     */   public void setRssUsername(String rssUsername) {
/*  86 */     this.rssUsername = rssUsername;
/*     */   }
/*     */ 
/*     */   public boolean isFull()
/*     */   {
/*  93 */     return this.full;
/*     */   }
/*     */ 
/*     */   public boolean getFull()
/*     */   {
/* 100 */     return this.full;
/*     */   }
/*     */ 
/*     */   public void setFull(boolean full)
/*     */   {
/* 107 */     this.full = full;
/*     */   }
/*     */ 
/*     */   public Iterator getMessages()
/*     */   {
/* 115 */     if (this.messages == null) {
/* 116 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/* 118 */     return this.messages;
/*     */   }
/*     */ 
/*     */   public String getFeedTitle()
/*     */   {
/* 125 */     List args = new ArrayList();
/* 126 */     args.add(SkinUtils.getCommunityName());
/*     */ 
/* 128 */     if (this.rssUsername != null) {
/* 129 */       args.add(this.rssUsername);
/* 130 */       return LocaleUtils.getLocalizedString("rss.messages_by_user", getLocale(), args);
/*     */     }
/* 132 */     if (this.category != null) {
/* 133 */       args.add(this.category.getName());
/* 134 */       return LocaleUtils.getLocalizedString("rss.messages_in_category", getLocale(), args);
/*     */     }
/* 136 */     if (this.forum != null) {
/* 137 */       args.add(this.forum.getName());
/* 138 */       return LocaleUtils.getLocalizedString("rss.messages_in_forum", getLocale(), args);
/*     */     }
/* 140 */     if (this.thread != null) {
/* 141 */       args.add(this.thread.getName());
/* 142 */       return LocaleUtils.getLocalizedString("rss.messages_in_thread", getLocale(), args);
/*     */     }
/*     */ 
/* 145 */     return LocaleUtils.getLocalizedString("rss.messages", getLocale(), args);
/*     */   }
/*     */ 
/*     */   public String executeRSS()
/*     */   {
/* 151 */     ForumFactory forumFactory = ForumFactory.getInstance(getAuthToken());
/*     */ 
/* 153 */     if (this.rssUsername != null) {
/*     */       try {
/* 155 */         this.rssUser = forumFactory.getUserManager().getUser(this.rssUsername);
/*     */       } catch (UserNotFoundException e) {
/* 157 */         addFieldError("rssUserNotFound", this.rssUsername);
/* 158 */         return "error";
/*     */       }
/*     */     }
/* 161 */     if (this.categoryID > 0L) {
/*     */       try {
/* 163 */         this.category = forumFactory.getForumCategory(this.categoryID);
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e) {
/* 166 */         addFieldError("categoryNotFound", String.valueOf(this.categoryID));
/* 167 */         return "error";
/*     */       }
/*     */     }
/* 170 */     if (this.forumID > 0L) {
/*     */       try {
/* 172 */         this.forum = forumFactory.getForum(this.forumID);
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 175 */         addFieldError("forumNotFound", String.valueOf(this.forumID));
/* 176 */         return "error";
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 179 */         addFieldError("unauthorized", "");
/* 180 */         return "unauthorized";
/*     */       }
/*     */     }
/* 183 */     if (this.threadID > 0L) {
/*     */       try {
/* 185 */         this.thread = forumFactory.getForumThread(this.threadID);
/*     */       }
/*     */       catch (ForumThreadNotFoundException e) {
/* 188 */         addFieldError("threadNotFound", String.valueOf(this.threadID));
/* 189 */         return "error";
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 192 */         addFieldError("unauthorized", "");
/* 193 */         return "unauthorized";
/*     */       }
/*     */     }
/*     */ 
/* 197 */     int numItems = getNumItems();
/* 198 */     if (numItems > 0) {
/* 199 */       ResultFilter filter = ResultFilter.createDefaultMessageFilter();
/* 200 */       filter.setSortField(9);
/* 201 */       filter.setSortOrder(0);
/* 202 */       filter.setNumResults(numItems);
/*     */ 
/* 206 */       if ((this.rssUser != null) && ((this.thread != null) || (this.forum != null) || (this.category != null))) {
/* 207 */         filter.setUserID(this.rssUser.getID());
/*     */       }
/*     */ 
/* 210 */       if (this.thread != null) {
/* 211 */         this.messages = this.thread.getMessages(filter);
/*     */       }
/* 213 */       else if (this.forum != null) {
/* 214 */         this.messages = this.forum.getMessages(filter);
/*     */       }
/* 216 */       else if (this.category != null) {
/* 217 */         this.messages = this.category.getMessages(filter);
/*     */       }
/* 221 */       else if (this.rssUser != null) {
/* 222 */         this.messages = forumFactory.getUserMessages(this.rssUser, filter);
/*     */       }
/*     */     }
/*     */ 
/* 226 */     if (hasErrors()) {
/* 227 */       return "error";
/*     */     }
/* 229 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.rss.RSSMessages
 * JD-Core Version:    0.6.2
 */
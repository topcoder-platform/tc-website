/*     */ package com.jivesoftware.forum.action.util;
/*     */ 
/*     */ public class Page
/*     */ {
/*  30 */   public static final Page FIRST = new Page(1, 0);
/*     */   private int number;
/*     */   private int start;
/*     */ 
/*     */   private Page(int number, int start)
/*     */   {
/*  37 */     this.number = number;
/*  38 */     this.start = start;
/*     */   }
/*     */ 
/*     */   public Page()
/*     */   {
/*     */   }
/*     */ 
/*     */   public int getNumber()
/*     */   {
/*  53 */     return this.number;
/*     */   }
/*     */ 
/*     */   public void setNumber(int number)
/*     */   {
/*  62 */     this.number = number;
/*     */   }
/*     */ 
/*     */   public int getStart()
/*     */   {
/*  73 */     return this.start;
/*     */   }
/*     */ 
/*     */   public void setStart(int start)
/*     */   {
/*  82 */     this.start = start;
/*     */   }
/*     */ 
/*     */   public static Page getPrev(Page page, int range)
/*     */   {
/*  93 */     return new Page(page.getNumber() - 1, page.getStart() - range);
/*     */   }
/*     */ 
/*     */   public static Page getNext(Page page, int range)
/*     */   {
/* 104 */     return new Page(page.getNumber() + 1, page.getStart() + range);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.util.Page
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum;

import com.jivesoftware.base.UnauthorizedException;
import com.jivesoftware.base.User;
import java.util.Iterator;

public abstract interface RewardManager
{
  public abstract boolean isRewardsEnabled();

  public abstract void setRewardsEnabled(boolean paramBoolean)
    throws UnauthorizedException;

  public abstract int getMaxThreadPoints();

  public abstract void setMaxThreadPoints(int paramInt)
    throws UnauthorizedException;

  public abstract int getMaxMessagePoints();

  public abstract void setMaxMessagePoints(int paramInt)
    throws UnauthorizedException;

  public abstract void transferPoints(ForumThread paramForumThread, int paramInt)
    throws UnauthorizedException, RewardException;

  public abstract void rewardPoints(ForumMessage paramForumMessage, int paramInt)
    throws UnauthorizedException, RewardException;

  public abstract int getPoints(ForumThread paramForumThread);

  public abstract int getPointsRewarded(ForumThread paramForumThread);

  public abstract int getPoints(ForumMessage paramForumMessage);

  public abstract boolean isBankEnabled();

  public abstract void setBankEnabled(boolean paramBoolean)
    throws UnauthorizedException;

  public abstract int getBankPoints(User paramUser);

  public abstract void addBankPoints(User paramUser, int paramInt)
    throws UnauthorizedException;

  public abstract void addBankPoints(int paramInt)
    throws UnauthorizedException;

  public abstract int getInitialBankPoints();

  public abstract void setInitialBankPoints(int paramInt)
    throws UnauthorizedException;

  public abstract int getMaxBankPoints();

  public abstract void setMaxBankPoints(int paramInt)
    throws UnauthorizedException;

  public abstract int getPendingRewardThreadsCount(User paramUser);

  public abstract Iterator getPendingRewardThreads(User paramUser);

  public abstract int getPointsRewarded(User paramUser);

  public abstract int getPointsEarned(User paramUser);

  public abstract int getPointsEarned(User paramUser, ForumCategory paramForumCategory);

  public abstract int getPointsEarned(User paramUser, Forum paramForum);

  public abstract Iterator getTopUsers(int paramInt1, int paramInt2);

  public abstract Iterator getTopUsers(int paramInt1, int paramInt2, ForumCategory paramForumCategory);

  public abstract Iterator getTopUsers(int paramInt1, int paramInt2, Forum paramForum);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.RewardManager
 * JD-Core Version:    0.6.2
 */
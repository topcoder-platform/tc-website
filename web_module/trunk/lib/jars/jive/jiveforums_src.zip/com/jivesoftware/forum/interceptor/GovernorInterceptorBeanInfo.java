/*    */ package com.jivesoftware.forum.interceptor;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class GovernorInterceptorBeanInfo extends JiveBeanInfo
/*    */ {
/* 23 */   public static final String[] PROPERTY_NAMES = { "postInterval", "rejectionMessage" };
/*    */ 
/*    */   public Class getBeanClass()
/*    */   {
/* 30 */     return GovernorInterceptor.class;
/*    */   }
/*    */ 
/*    */   public String[] getPropertyNames() {
/* 34 */     return PROPERTY_NAMES;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 38 */     return "GovernorInterceptor";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.GovernorInterceptorBeanInfo
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Element;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.bin.DateSequence;
/*     */ import com.jivesoftware.base.stats.element.DateElement;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.base.stats.util.DateFormatter;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class SearchQuerySearchTimeReport extends AbstractForumReport
/*     */ {
/*     */   private static final String EARLIEST_SEARCH_DATE = "SELECT min(searchDate) FROM jiveSearch WHERE searchType=19";
/*     */   private static final String SEARCH_QUERIES = "SELECT searchDate, searchDuration from jiveSearch WHERE searchDate >= ? AND searchDate <= ? AND searchType=19";
/*  43 */   private Bin[] bins = null;
/*  44 */   private Map searchDurations = new HashMap();
/*     */ 
/*     */   public void execute()
/*     */   {
/*  50 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  51 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  53 */     if (end.compareTo(start) < 0)
/*     */     {
/*  55 */       start = end;
/*     */     }
/*     */ 
/*  58 */     Histogram hist = null;
/*     */ 
/*  61 */     if (end.getTime() - start.getTime() <= 90000000L) {
/*  62 */       hist = new Histogram(new DateSequence(start, 3600000L), new DateElement(start), new DateElement(end));
/*     */     }
/*  65 */     else if (end.getTime() - start.getTime() <= 2678400000L) {
/*  66 */       hist = new Histogram(new DateSequence(start, 86400000L), new DateElement(start), new DateElement(end));
/*     */     }
/*     */     else
/*     */     {
/*  70 */       hist = new Histogram(new DateSequence(start, 604800000L), new DateElement(start), new DateElement(end));
/*     */     }
/*     */ 
/*  74 */     addHistogram(hist);
/*     */ 
/*  76 */     Connection con = null;
/*  77 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/*  80 */       con = ConnectionManager.getConnection();
/*  81 */       pstmt = con.prepareStatement("SELECT searchDate, searchDuration from jiveSearch WHERE searchDate >= ? AND searchDate <= ? AND searchType=19");
/*  82 */       pstmt.setLong(1, start.getTime());
/*  83 */       pstmt.setLong(2, end.getTime());
/*  84 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  86 */       while (rs.next()) {
/*  87 */         hist.add(new DateElement(new Date(rs.getLong(1))));
/*     */ 
/*  91 */         this.searchDurations.put(new Date(rs.getLong(1)), new Long(rs.getLong(2)));
/*     */       }
/*  93 */       rs.close();
/*     */     } catch (SQLException e) {
/*  95 */       Log.error(e);
/*     */     } finally {
/*  97 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/* 102 */     Histogram[] histograms = getHistograms();
/* 103 */     if (histograms.length == 0) {
/* 104 */       return new DataTable[0];
/*     */     }
/* 106 */     DataTable data = new DataTable(getName());
/* 107 */     data.setColumns(new String[] { "Date", "Mean Search Execution Time (ms)" });
/* 108 */     Histogram hist = histograms[0];
/* 109 */     Bin[] bins = getBins();
/* 110 */     for (int i = 0; i < bins.length; i++) {
/* 111 */       Bin bin = bins[i];
/* 112 */       String week = DateFormatter.format("M/dd/yyyy", new Date(bin.getBegin().toLong().longValue()));
/*     */ 
/* 114 */       long count = hist.getCount(bin);
/* 115 */       data.addRow(new Object[] { week, new Long(count) });
/*     */     }
/* 117 */     return new DataTable[] { data };
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 121 */     Histogram[] histograms = getHistograms();
/* 122 */     Chart[] charts = new Chart[histograms.length];
/* 123 */     for (int i = 0; i < histograms.length; i++) {
/* 124 */       String name = getName();
/* 125 */       Chart chart = new Chart(name);
/* 126 */       chart.setXaxisLabel("Date");
/* 127 */       chart.setYaxisLabel("Mean Search Execution Time (ms)");
/* 128 */       chart.setType(2);
/* 129 */       Bin[] bins = getBins();
/* 130 */       String[] labels = new String[bins.length];
/* 131 */       for (int j = 0; j < bins.length; j++) {
/* 132 */         Bin bin = bins[j];
/* 133 */         Date begin = new Date(bin.getBegin().toLong().longValue());
/* 134 */         Date end = new Date(bin.getEnd().toLong().longValue());
/* 135 */         Date mid = new Date((begin.getTime() + end.getTime()) / 2L);
/* 136 */         labels[j] = DateFormatter.format("M/dd/yy", mid);
/*     */       }
/* 138 */       chart.setLabels(labels);
/* 139 */       charts[i] = chart;
/*     */     }
/* 141 */     return charts;
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 145 */     Histogram[] histograms = getHistograms();
/* 146 */     if (histograms.length == 0) {
/* 147 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/*     */ 
/* 150 */     List extraInfo = new ArrayList(4);
/*     */ 
/* 153 */     extraInfo.add(getDateRange());
/*     */ 
/* 155 */     return new List[] { extraInfo };
/*     */   }
/*     */ 
/*     */   protected Date calculateStartDate()
/*     */   {
/* 160 */     Connection con = null;
/* 161 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 164 */       con = ConnectionManager.getConnection();
/* 165 */       pstmt = con.prepareStatement("SELECT min(searchDate) FROM jiveSearch WHERE searchType=19");
/* 166 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 168 */       if (rs.next()) {
/* 169 */         return new Date(rs.getLong(1));
/*     */       }
/* 171 */       rs.close();
/*     */     } catch (SQLException e) {
/* 173 */       Log.error(e);
/*     */     } finally {
/* 175 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 178 */     return super.calculateStartDate();
/*     */   }
/*     */ 
/*     */   private Bin[] getBins()
/*     */   {
/* 190 */     if (this.bins != null) {
/* 191 */       return this.bins;
/*     */     }
/*     */ 
/* 194 */     Histogram hist = getHistograms()[0];
/* 195 */     this.bins = hist.getBins();
/* 196 */     for (int i = 0; i < this.bins.length; i++) {
/* 197 */       DateElement begin = (DateElement)this.bins[i].getBegin();
/* 198 */       DateElement end = (DateElement)this.bins[i].getEnd();
/* 199 */       Date start = (Date)begin.getValue();
/* 200 */       Date finish = (Date)end.getValue();
/*     */ 
/* 202 */       Iterator keys = this.searchDurations.keySet().iterator();
/* 203 */       int count = 0;
/* 204 */       double sumLog = 0.0D;
/* 205 */       while (keys.hasNext()) {
/* 206 */         Date searchDate = (Date)keys.next();
/* 207 */         if ((searchDate.compareTo(start) >= 0) && (searchDate.compareTo(finish) < 0)) {
/* 208 */           long searchDuration = ((Long)this.searchDurations.get(searchDate)).longValue();
/* 209 */           if (searchDuration > 0L) {
/* 210 */             sumLog += Math.log(searchDuration);
/*     */           }
/* 212 */           count++;
/*     */         }
/*     */       }
/*     */ 
/* 216 */       if (count > 0) {
/* 217 */         long mean = ()Math.exp(sumLog / count);
/* 218 */         hist.setCount(this.bins[i], mean);
/*     */       }
/*     */       else {
/* 221 */         hist.setCount(this.bins[i], 0L);
/*     */       }
/*     */     }
/*     */ 
/* 225 */     return this.bins;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.SearchQuerySearchTimeReport
 * JD-Core Version:    0.6.2
 */
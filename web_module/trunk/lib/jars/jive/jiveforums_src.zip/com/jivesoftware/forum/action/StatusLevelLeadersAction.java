/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.StatusLevelManager;
/*     */ import com.opensymphony.xwork.Preparable;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class StatusLevelLeadersAction extends ForumActionSupport
/*     */   implements Preparable
/*     */ {
/*  31 */   private long categoryID = -1L;
/*  32 */   private long forumID = -1L;
/*  33 */   private Iterator leaders = null;
/*  34 */   private int startIndex = -1;
/*  35 */   private int numResults = -1;
/*     */   private ForumCategory category;
/*     */   private Forum forum;
/*     */ 
/*     */   public long getCategoryID()
/*     */   {
/*  44 */     return this.categoryID;
/*     */   }
/*     */ 
/*     */   public void setCategoryID(long categoryID)
/*     */   {
/*  51 */     this.categoryID = categoryID;
/*     */   }
/*     */ 
/*     */   public long getForumID()
/*     */   {
/*  58 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID)
/*     */   {
/*  65 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public void setStartIndex(int startIndex)
/*     */   {
/*  75 */     this.startIndex = startIndex;
/*     */   }
/*     */ 
/*     */   public void setNumResults(int numResults)
/*     */   {
/*  85 */     this.numResults = numResults;
/*     */   }
/*     */ 
/*     */   public Iterator getLeaders()
/*     */   {
/*  94 */     return this.leaders;
/*     */   }
/*     */ 
/*     */   public ForumCategory getCategory()
/*     */   {
/* 102 */     return this.category;
/*     */   }
/*     */ 
/*     */   public Forum getForum()
/*     */   {
/* 110 */     return this.forum;
/*     */   }
/*     */ 
/*     */   public boolean isRootCategory()
/*     */   {
/* 117 */     return (this.category != null) && (this.category.getID() == getForumFactory().getRootForumCategory().getID());
/*     */   }
/*     */ 
/*     */   public String execute() throws Exception
/*     */   {
/* 122 */     ForumFactory forumFactory = getForumFactory();
/*     */ 
/* 124 */     StatusLevelManager manager = forumFactory.getStatusLevelManager();
/*     */ 
/* 126 */     if (manager.isStatusLevelsEnabled())
/*     */     {
/* 128 */       if (this.category != null) {
/* 129 */         if ((this.startIndex > -1) && (this.numResults > 0)) {
/* 130 */           this.leaders = manager.getLeaders(this.category, this.startIndex, this.numResults);
/*     */         }
/*     */         else {
/* 133 */           this.leaders = manager.getLeaders(this.category);
/*     */         }
/*     */       }
/* 136 */       else if (this.forum != null) {
/* 137 */         if ((this.startIndex > -1) && (this.numResults > 0)) {
/* 138 */           this.leaders = manager.getLeaders(this.forum, this.startIndex, this.numResults);
/*     */         }
/*     */         else {
/* 141 */           this.leaders = manager.getLeaders(this.forum);
/*     */         }
/*     */ 
/*     */       }
/* 145 */       else if ((this.startIndex > -1) && (this.numResults > 0)) {
/* 146 */         this.leaders = manager.getLeaders(this.startIndex, this.numResults);
/*     */       }
/*     */       else {
/* 149 */         this.leaders = manager.getLeaders();
/*     */       }
/*     */ 
/* 152 */       return "success";
/*     */     }
/* 154 */     return "none";
/*     */   }
/*     */ 
/*     */   public void prepare() throws Exception {
/* 158 */     if (this.categoryID > 0L) {
/* 159 */       this.category = getForumFactory().getForumCategory(this.categoryID);
/* 160 */       if (this.category.getID() == getForumFactory().getRootForumCategory().getID()) {
/* 161 */         this.category = null;
/*     */       }
/*     */     }
/* 164 */     if (this.forumID > 0L)
/*     */       try {
/* 166 */         this.forum = getForumFactory().getForum(this.forumID);
/*     */       }
/*     */       catch (UnauthorizedException e)
/*     */       {
/* 171 */         Log.debug("User does not have access to read forum " + this.forumID, e);
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.StatusLevelLeadersAction
 * JD-Core Version:    0.6.2
 */
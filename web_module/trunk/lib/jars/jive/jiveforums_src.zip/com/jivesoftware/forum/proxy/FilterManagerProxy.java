/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.Filter;
/*     */ import com.jivesoftware.base.FilterManager;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ 
/*     */ public class FilterManagerProxy
/*     */   implements FilterManager
/*     */ {
/*     */   private FilterManager filterManager;
/*     */   private Permissions permissions;
/*     */   private int objectType;
/*     */ 
/*     */   public FilterManagerProxy(FilterManager filterManager, int objectType, Permissions permissions)
/*     */   {
/*  29 */     this.filterManager = filterManager;
/*  30 */     this.objectType = objectType;
/*  31 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public Filter[] getAvailableFilters() throws UnauthorizedException {
/*  35 */     if (isAdmin()) {
/*  36 */       return this.filterManager.getAvailableFilters();
/*     */     }
/*     */ 
/*  39 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void addFilterClass(String className)
/*     */     throws UnauthorizedException, ClassNotFoundException
/*     */   {
/*  45 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  46 */       this.filterManager.addFilterClass(className);
/*     */     }
/*     */     else
/*  49 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public String applyFilters(Object source, long filterType, String string)
/*     */   {
/*  54 */     return this.filterManager.applyFilters(source, filterType, string);
/*     */   }
/*     */ 
/*     */   public int getFilterCount()
/*     */     throws UnauthorizedException
/*     */   {
/*  62 */     if (isAdmin()) {
/*  63 */       return this.filterManager.getFilterCount();
/*     */     }
/*     */ 
/*  66 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Filter getFilter(int index)
/*     */     throws UnauthorizedException
/*     */   {
/*  82 */     if (isAdmin()) {
/*  83 */       return this.filterManager.getFilter(index);
/*     */     }
/*     */ 
/*  86 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Filter[] getFilters() throws UnauthorizedException
/*     */   {
/*  91 */     if (isAdmin()) {
/*  92 */       return this.filterManager.getFilters();
/*     */     }
/*     */ 
/*  95 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void addFilter(int index, Filter filter) throws UnauthorizedException
/*     */   {
/* 100 */     if (isAdmin()) {
/* 101 */       this.filterManager.addFilter(index, filter);
/*     */     }
/*     */     else
/* 104 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void addFilter(Filter filter)
/*     */     throws UnauthorizedException
/*     */   {
/* 118 */     if (isAdmin()) {
/* 119 */       this.filterManager.addFilter(filter);
/*     */     }
/*     */     else
/* 122 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void removeFilter(int index)
/*     */     throws UnauthorizedException
/*     */   {
/* 136 */     if (isAdmin()) {
/* 137 */       this.filterManager.removeFilter(index);
/*     */     }
/*     */     else
/* 140 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public long getFilterTypes(int index)
/*     */     throws UnauthorizedException
/*     */   {
/* 154 */     if (isAdmin()) {
/* 155 */       return this.filterManager.getFilterTypes(index);
/*     */     }
/*     */ 
/* 158 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void addFilterTypes(int index, long filterTypes)
/*     */     throws UnauthorizedException
/*     */   {
/* 172 */     if (isAdmin()) {
/* 173 */       this.filterManager.addFilterTypes(index, filterTypes);
/*     */     }
/*     */     else
/* 176 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void removeFilterTypes(int index, long filterTypes)
/*     */     throws UnauthorizedException
/*     */   {
/* 190 */     if (isAdmin()) {
/* 191 */       this.filterManager.removeFilterTypes(index, filterTypes);
/*     */     }
/*     */     else
/* 194 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void saveFilters()
/*     */     throws UnauthorizedException
/*     */   {
/* 208 */     if (isAdmin()) {
/* 209 */       this.filterManager.saveFilters();
/*     */     }
/*     */     else
/* 212 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean isAdmin()
/*     */   {
/* 217 */     if (this.objectType == 17) {
/* 218 */       return this.permissions.hasPermission(576460752303423488L);
/*     */     }
/* 220 */     if (this.objectType == 14) {
/* 221 */       return this.permissions.hasPermission(576460752303424000L);
/*     */     }
/*     */ 
/* 224 */     if (this.objectType == 0) {
/* 225 */       return this.permissions.hasPermission(576460752303424256L);
/*     */     }
/*     */ 
/* 229 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.FilterManagerProxy
 * JD-Core Version:    0.6.2
 */
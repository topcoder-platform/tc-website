package com.jivesoftware.forum.net;

public abstract interface ConnectionCloseListener
{
  public abstract void onConnectionClose(Object paramObject);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.ConnectionCloseListener
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.Group;
/*     */ import com.jivesoftware.base.GroupManager;
/*     */ import com.jivesoftware.base.GroupManagerFactory;
/*     */ import com.jivesoftware.base.GroupNotFoundException;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserManagerFactory;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.BinFormat;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Element;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.Report.ExtraInfo;
/*     */ import com.jivesoftware.base.stats.bin.DateSequence;
/*     */ import com.jivesoftware.base.stats.element.DateElement;
/*     */ import com.jivesoftware.base.stats.element.DayOfWeekElementFormat;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.base.stats.util.DateFormatter;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class GroupPostReport extends AbstractForumReport
/*     */ {
/*     */   private static final String NEW_MESSAGES_BY_DATE = "SELECT userID, creationDate FROM jiveMessage WHERE creationDate >= ? AND creationDate < ?";
/*     */   private static final String NEW_MESSAGES_BY_FORUM_AND_DATE = "SELECT userID, creationDate FROM jiveMessage WHERE forumID = ? AND creationDate >= ? AND creationDate < ?";
/*     */   private Group group;
/*  43 */   private long stepSize = 24L;
/*     */ 
/*     */   public long getGroup()
/*     */   {
/*  48 */     return this.group == null ? -1L : this.group.getID();
/*     */   }
/*     */ 
/*     */   public void setGroup(long groupID) {
/*  52 */     if (groupID > 0L)
/*     */       try {
/*  54 */         this.group = GroupManagerFactory.getInstance().getGroup(groupID);
/*     */       }
/*     */       catch (GroupNotFoundException e) {
/*  57 */         Log.error("No group specified for group report -- please set this report property.");
/*  58 */         Log.debug(e);
/*     */       }
/*     */   }
/*     */ 
/*     */   public long getStepSize()
/*     */   {
/*  64 */     return this.stepSize;
/*     */   }
/*     */ 
/*     */   public void setStepSize(long stepSize) {
/*  68 */     this.stepSize = stepSize;
/*     */   }
/*     */ 
/*     */   public void execute() {
/*  72 */     if (this.group == null) {
/*  73 */       return;
/*     */     }
/*     */ 
/*  76 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  77 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  80 */     Histogram hist = new Histogram(new DateSequence(start, getStepSize() * 60L * 60L * 1000L));
/*  81 */     addHistogram(hist);
/*     */ 
/*  83 */     Connection con = null;
/*  84 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/*  91 */         con = ConnectionManager.getConnection();
/*  92 */         pstmt = con.prepareStatement("SELECT userID, creationDate FROM jiveMessage WHERE creationDate >= ? AND creationDate < ?");
/*  93 */         pstmt.setLong(1, start.getTime());
/*  94 */         pstmt.setLong(2, end.getTime());
/*  95 */         ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  97 */         while (rs.next()) {
/*  98 */           User user = null;
/*     */           try {
/* 100 */             long userID = Long.parseLong(rs.getString(1));
/* 101 */             user = UserManagerFactory.getInstance().getUser(userID);
/*     */           } catch (Exception e) {
/*     */           }
/* 104 */           continue;
/*     */ 
/* 106 */           if (this.group.isMember(user)) {
/* 107 */             hist.add(new DateElement(new Date(rs.getLong(2))));
/*     */           }
/*     */         }
/* 110 */         rs.close();
/* 111 */         pstmt.close();
/*     */       }
/*     */       catch (SQLException sqle)
/*     */       {
/*     */       }
/*     */ 
/* 119 */       List forums = getObjects();
/* 120 */       for (iter = forums.iterator(); iter.hasNext(); ) {
/* 121 */         Forum forum = (Forum)iter.next();
/* 122 */         long forumID = forum.getID();
/* 123 */         hist = new Histogram(new DateSequence(start, getStepSize() * 60L * 60L * 1000L));
/* 124 */         addHistogram(hist);
/*     */         try {
/* 126 */           pstmt = con.prepareStatement("SELECT userID, creationDate FROM jiveMessage WHERE forumID = ? AND creationDate >= ? AND creationDate < ?");
/* 127 */           pstmt.setLong(1, forumID);
/* 128 */           pstmt.setLong(2, start.getTime());
/* 129 */           pstmt.setLong(3, end.getTime());
/* 130 */           ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 132 */           while (rs.next()) {
/* 133 */             User user = null;
/*     */             try {
/* 135 */               long userID = Long.parseLong(rs.getString(1));
/* 136 */               user = UserManagerFactory.getInstance().getUser(userID);
/*     */             } catch (Exception e) {
/*     */             }
/* 139 */             continue;
/*     */ 
/* 141 */             if (this.group.isMember(user)) {
/* 142 */               hist.add(new DateElement(new Date(rs.getLong(2))));
/*     */             }
/*     */           }
/* 145 */           rs.close();
/* 146 */           pstmt.close();
/*     */         }
/*     */         catch (SQLException sqle)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       Iterator iter;
/* 154 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/* 159 */     Histogram[] histograms = getHistograms();
/* 160 */     if (histograms.length == 0) {
/* 161 */       return new DataTable[0];
/*     */     }
/* 163 */     List tables = new ArrayList(histograms.length);
/* 164 */     for (int i = 0; i < histograms.length; i++) {
/* 165 */       Histogram hist = histograms[i];
/* 166 */       DataTable data = new DataTable(getName());
/* 167 */       data.setColumns(new String[] { "Week", "Messages" });
/* 168 */       Bin[] bins = hist.getBins();
/* 169 */       for (int j = 0; j < bins.length; j++) {
/* 170 */         Bin bin = bins[j];
/* 171 */         String week = DateFormatter.format("M/dd/yyyy", new Date(bin.getBegin().toLong().longValue()));
/*     */ 
/* 173 */         long count = hist.getCount(bin);
/* 174 */         data.addRow(new Object[] { week, new Long(count) });
/*     */       }
/* 176 */       tables.add(data);
/*     */     }
/* 178 */     return (DataTable[])tables.toArray(new DataTable[0]);
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 182 */     Histogram[] histograms = getHistograms();
/* 183 */     Chart[] charts = new Chart[histograms.length];
/* 184 */     List forums = getObjects();
/* 185 */     for (int i = 0; i < histograms.length; i++) {
/* 186 */       Histogram hist = histograms[i];
/* 187 */       String name = getName();
/* 188 */       if (i == 0) {
/* 189 */         name = name + " - All forums";
/*     */       }
/*     */       else {
/* 192 */         name = name + " - " + forums.get(i - 1);
/*     */       }
/* 194 */       Chart chart = new Chart(name);
/* 195 */       chart.setXaxisLabel("Dates");
/* 196 */       chart.setYaxisLabel("New Messages");
/* 197 */       chart.setType(2);
/* 198 */       Bin[] bins = hist.getBins();
/* 199 */       String[] labels = new String[bins.length];
/* 200 */       for (int j = 0; j < bins.length; j++) {
/* 201 */         Bin bin = bins[j];
/* 202 */         Date begin = new Date(bin.getBegin().toLong().longValue());
/* 203 */         Date end = new Date(bin.getEnd().toLong().longValue());
/* 204 */         Date mid = new Date((begin.getTime() + end.getTime()) / 2L);
/* 205 */         labels[j] = DateFormatter.format("M/dd/yy", mid);
/*     */       }
/* 207 */       chart.setLabels(labels);
/* 208 */       charts[i] = chart;
/*     */     }
/* 210 */     return charts;
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 214 */     Histogram[] histograms = getHistograms();
/* 215 */     if (histograms.length == 0) {
/* 216 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/* 218 */     List lists = new ArrayList(histograms.length);
/* 219 */     for (int i = 0; i < histograms.length; i++) {
/* 220 */       List extraInfo = new ArrayList(4);
/* 221 */       Histogram hist = histograms[i];
/* 222 */       if (hist.getNElement() > 0L) {
/* 223 */         extraInfo.add(new Report.ExtraInfo("Group", this.group.getName()));
/* 224 */         extraInfo.add(new Report.ExtraInfo("Median Messages/Day", new Long(hist.getMedianCount())));
/*     */ 
/* 226 */         BinFormat dataFormat = new BinFormat(new DayOfWeekElementFormat("EEEE"), "$1");
/* 227 */         String day = dataFormat.format(hist.getMaxCountBin());
/* 228 */         extraInfo.add(new Report.ExtraInfo("Peak Day", day));
/*     */       }
/*     */ 
/* 232 */       extraInfo.add(getDateRange());
/*     */ 
/* 234 */       lists.add(extraInfo);
/*     */     }
/* 236 */     return (List[])lists.toArray(new List[0]);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.GroupPostReport
 * JD-Core Version:    0.6.2
 */
/*      */ package com.jivesoftware.forum.database;
/*      */ 
/*      */ import com.jivesoftware.base.AuthToken;
/*      */ import com.jivesoftware.base.FilterManager;
/*      */ import com.jivesoftware.base.JiveGlobals;
/*      */ import com.jivesoftware.base.Log;
/*      */ import com.jivesoftware.base.PermissionType;
/*      */ import com.jivesoftware.base.Permissions;
/*      */ import com.jivesoftware.base.PermissionsManager;
/*      */ import com.jivesoftware.base.UnauthorizedException;
/*      */ import com.jivesoftware.base.database.CachedPreparedStatement;
/*      */ import com.jivesoftware.base.database.ConnectionManager;
/*      */ import com.jivesoftware.base.database.ConnectionManager.DatabaseType;
/*      */ import com.jivesoftware.base.database.DbPermissionsManager;
/*      */ import com.jivesoftware.base.database.sequence.SequenceManager;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumCategory;
/*      */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumNotFoundException;
/*      */ import com.jivesoftware.forum.InterceptorManager;
/*      */ import com.jivesoftware.forum.ResultFilter;
/*      */ import com.jivesoftware.forum.event.CategoryEvent;
/*      */ import com.jivesoftware.forum.event.CategoryEventDispatcher;
/*      */ import com.jivesoftware.forum.event.ForumEvent;
/*      */ import com.jivesoftware.forum.event.ForumEventDispatcher;
/*      */ import com.jivesoftware.forum.gateway.GatewayManager;
/*      */ import com.jivesoftware.util.Cache;
/*      */ import com.jivesoftware.util.CacheFactory;
/*      */ import com.jivesoftware.util.CacheSizes;
/*      */ import com.jivesoftware.util.Cacheable;
/*      */ import com.jivesoftware.util.ExtendedPropertyUtils;
/*      */ import com.jivesoftware.util.ExternalizableLiteUtil;
/*      */ import com.jivesoftware.util.LongHashMap;
/*      */ import com.jivesoftware.util.LongList;
/*      */ import com.jivesoftware.util.LongTree;
/*      */ import com.jivesoftware.util.profile.Profiler;
/*      */ import com.tangosol.io.ExternalizableLite;
/*      */ import com.tangosol.util.ExternalizableHelper;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ public class DbForumCategory
/*      */   implements ForumCategory, Cacheable, ExternalizableLite
/*      */ {
/*      */   protected static final String FIND_FORUM_INDEX = "SELECT categoryIndex FROM jiveForum WHERE forumID=? AND categoryID=?";
/*      */   protected static final String FORUM_IN_CATEGORY_COUNT = "SELECT count(categoryIndex) FROM jiveForum WHERE categoryID=?";
/*      */   protected static final String SHIFT_FORUM_INDEX_1 = "UPDATE jiveForum SET categoryIndex=categoryIndex+1 WHERE categoryID=? AND categoryIndex >= ? AND categoryIndex <?";
/*      */   protected static final String SHIFT_FORUM_INDEX_2 = "UPDATE jiveForum SET categoryIndex=categoryIndex-1 WHERE categoryID=? AND categoryIndex <= ? AND categoryIndex > ?";
/*      */   protected static final String SHIFT_CATEGORY_INDEX_1 = "UPDATE jiveCategory SET lft=lft+?, rgt=rgt+? WHERE lft>=? AND lft<?";
/*      */   protected static final String SHIFT_CATEGORY_INDEX_2 = "UPDATE jiveCategory SET lft=lft+?, rgt=rgt+? WHERE lft>? AND rgt>? AND rgt<=?";
/*      */   private static final String SET_FORUM_INDEX = "UPDATE jiveForum SET categoryIndex=? WHERE forumID=?";
/*      */   private static final String MOVE_FORUM = "UPDATE jiveForum SET categoryID=?, categoryIndex=? WHERE forumID=?";
/*      */   private static final String LOAD_CATEGORY = "SELECT name, description, creationDate, modificationDate FROM jiveCategory WHERE categoryID=?";
/*      */   private static final String FIND_LFT_RGT = "SELECT lft, rgt FROM jiveCategory WHERE categoryID=?";
/*      */   private static final String CHANGE_LFT = "UPDATE jiveCategory SET lft=lft+? WHERE lft > ? AND rgt > ?";
/*      */   private static final String CHANGE_RGT = "UPDATE jiveCategory SET rgt=rgt+? WHERE rgt >= ?";
/*      */   private static final String UPDATE_CATEGORY_MODIFIED_DATE = "UPDATE jiveCategory SET modificationDate=? WHERE lft<=? AND rgt>=?";
/*      */   private static final String INSERT_CATEGORY = "INSERT INTO jiveCategory(categoryID,name,description,creationDate,modificationDate,lft,rgt) VALUES (?,?,?,?,?,?,?)";
/*      */   private static final String SAVE_CATEGORY = "UPDATE jiveCategory SET name=?, description=?, creationDate=?, modificationDate=? WHERE categoryID=?";
/*      */   private static final String DELETE_CATEGORY = "DELETE FROM jiveCategory WHERE categoryID=?";
/*      */   private static final String DELETE_CATEGORY_PROPS = "DELETE FROM jiveCategoryProp WHERE categoryID=?";
/*      */   private static final String LOAD_PROPERTIES = "SELECT name, propValue FROM jiveCategoryProp WHERE categoryID=?";
/*      */   private static final String DELETE_PROPERTY = "DELETE FROM jiveCategoryProp WHERE categoryID=? AND name=?";
/*      */   private static final String UPDATE_PROPERTY = "UPDATE jiveCategoryProp SET propValue=? WHERE name=? AND categoryID=?";
/*      */   private static final String INSERT_PROPERTY = "INSERT INTO jiveCategoryProp(categoryID,name,propValue) VALUES(?,?,?)";
/*      */   private static final String POPULAR_THREADS = "SELECT threadID, count(*) AS msgCount FROM jiveMessage, jiveForum, jiveCategory WHERE jiveMessage.modificationDate > ? AND jiveCategory.lft>=? AND jiveCategory.rgt<=? AND jiveCategory.categoryID=jiveForum.categoryID AND jiveMessage.forumID=jiveForum.forumID AND jiveMessage.modValue >=  1 GROUP BY threadID ORDER BY msgCount DESC";
/*      */   private static final String POPULAR_THREADS_ORACLE = "SELECT /*+ INDEX (jiveMessage jiveMessage_mDate_idx) */ threadID, count(*) AS msgCount FROM jiveMessage, jiveForum, jiveCategory WHERE jiveMessage.modificationDate > ? AND jiveCategory.lft>=? AND jiveCategory.rgt<=? AND jiveCategory.categoryID=jiveForum.categoryID AND jiveMessage.forumID=jiveForum.forumID AND jiveMessage.modValue >= 1 GROUP BY threadID ORDER BY msgCount DESC";
/*      */   private static final String DELETE_FORUM = "DELETE FROM jiveForum WHERE forumID=?";
/*      */   private static final String ALL_MESSAGE_ATTACHMENTS = "SELECT attachmentID FROM jiveAttachment, jiveMessage WHERE jiveAttachment.objectType=2 AND jiveAttachment.objectID=jiveMessage.messageID AND forumID=?";
/*      */   private static final String DELETE_MESSAGE_PROPERTIES = "DELETE FROM jiveMessageProp WHERE messageID IN(SELECT messageID FROM jiveMessage WHERE forumID=?)";
/*      */   private static final String SELECT_MESSAGE_PROPERTIES = "SELECT jiveMessageProp.messageID FROM jiveMessageProp, jiveMessage WHERE jiveMessageProp.messageID=jiveMessage.messageID AND jiveMessage.forumID=?";
/*      */   private static final String DELETE_MESSAGE_PROPERTIES_BATCH = "DELETE FROM jiveMessageProp WHERE messageID IN";
/*      */   private static final String DELETE_THREAD_PROPERTIES = "DELETE FROM jiveThreadProp WHERE threadID IN(SELECT threadID FROM jiveThread WHERE forumID=?)";
/*      */   private static final String SELECT_THREAD_PROPERTIES = "SELECT jiveThreadProp.threadID FROM jiveThreadProp, jiveThread WHERE jiveThreadProp.threadID=jiveThread.threadID AND jiveThread.forumID=?";
/*      */   private static final String DELETE_THREAD_PROPERTIES_BATCH = "DELETE FROM jiveThreadProp WHERE threadID IN";
/*      */   private static final String DELETE_THREADS = "DELETE FROM jiveThread WHERE forumID=?";
/*      */   private static final String DELETE_MESSAGES = "DELETE FROM jiveMessage WHERE forumID=?";
/*      */   private static final String DELETE_FORUM_PROPERTIES = "DELETE FROM jiveForumProp WHERE forumID=?";
/*      */   private static final String ALL_FORUM_MESSAGES = "SELECT messageID, forumIndex, threadID FROM jiveMessage WHERE forumID=?";
/*      */   private static final String CATEGORY_COUNT = "SELECT count(*) FROM jiveCategory";
/*      */   private static final String LOAD_CATEGORY_TREE = "SELECT categoryID, lft, rgt FROM jiveCategory ORDER BY lft ASC";
/*  165 */   public static final boolean ENABLE_DATE_UPDATES = Boolean.valueOf(JiveGlobals.getJiveProperty("category.enableDateUpdates")).booleanValue();
/*      */ 
/*  170 */   private static final ResultFilter DEFAULT_FORUM_FILTER = ResultFilter.createDefaultForumFilter();
/*      */   private static final long serialVersionUID = 1L;
/*      */   private static LongTree categoryTree;
/*      */   private static Map lftRgtCache;
/*  178 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*      */ 
/*  185 */   private static Object lock = new Object();
/*      */ 
/*  189 */   private static final ResultFilter DEFAULT_THREAD_FILTER = ResultFilter.createDefaultThreadFilter();
/*      */ 
/*  191 */   private static final ResultFilter DEFAULT_MESSAGE_FILTER = ResultFilter.createDefaultMessageFilter();
/*      */   private long id;
/*      */   private String name;
/*      */   private String description;
/*      */   private Date creationDate;
/*      */   private Date modificationDate;
/*      */   private Map properties;
/*  201 */   private long[] popularThreads = null;
/*      */   private long popularThreadsTimestamp;
/*      */   private transient DbFilterManager filterManager;
/*      */   private transient DbInterceptorManager interceptorManager;
/*      */ 
/*      */   public DbForumCategory(long id)
/*      */     throws ForumCategoryNotFoundException
/*      */   {
/*  214 */     this.id = id;
/*  215 */     loadFromDb();
/*  216 */     init();
/*      */   }
/*      */ 
/*      */   protected DbForumCategory(long id, Connection con) throws ForumCategoryNotFoundException {
/*  220 */     this.id = id;
/*  221 */     loadFromDb(con);
/*  222 */     init();
/*      */   }
/*      */ 
/*      */   public DbForumCategory(String name, String description, DbForumCategory parentCategory)
/*      */   {
/*  233 */     this.id = SequenceManager.nextID(14);
/*  234 */     this.name = name;
/*  235 */     this.description = description;
/*  236 */     long now = System.currentTimeMillis();
/*  237 */     this.creationDate = new Date(now);
/*  238 */     this.modificationDate = new Date(now);
/*  239 */     insertIntoDb(parentCategory);
/*  240 */     this.properties = new Hashtable();
/*  241 */     init();
/*      */   }
/*      */ 
/*      */   public DbForumCategory()
/*      */   {
/*      */   }
/*      */ 
/*      */   private void init()
/*      */   {
/*  253 */     synchronized (lock)
/*      */     {
/*  256 */       if (lftRgtCache == null) {
/*  257 */         lftRgtCache = CacheFactory.createCache("lftRgtCache", -1, -1L);
/*      */       }
/*  259 */       if (categoryTree == null)
/*  260 */         refreshCategoryTree(true);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void readExternal(DataInput in) throws IOException
/*      */   {
/*  266 */     this.id = ExternalizableHelper.readLong(in);
/*  267 */     this.name = ExternalizableHelper.readSafeUTF(in);
/*  268 */     this.description = ExternalizableHelper.readSafeUTF(in);
/*  269 */     this.creationDate = new Date(in.readLong());
/*  270 */     this.modificationDate = new Date(in.readLong());
/*  271 */     this.properties = ExternalizableLiteUtil.readStringMap(in);
/*  272 */     this.popularThreads = ExternalizableLiteUtil.readLongArray(in);
/*  273 */     this.popularThreadsTimestamp = in.readLong();
/*  274 */     init();
/*      */   }
/*      */ 
/*      */   public void writeExternal(DataOutput out) throws IOException {
/*  278 */     ExternalizableHelper.writeLong(out, this.id);
/*  279 */     ExternalizableHelper.writeSafeUTF(out, this.name);
/*  280 */     ExternalizableHelper.writeSafeUTF(out, this.description);
/*  281 */     out.writeLong(this.creationDate.getTime());
/*  282 */     out.writeLong(this.modificationDate.getTime());
/*  283 */     ExternalizableLiteUtil.writeStringMap(out, this.properties);
/*  284 */     ExternalizableLiteUtil.writeLongArray(out, this.popularThreads);
/*  285 */     out.writeLong(this.popularThreadsTimestamp);
/*      */   }
/*      */ 
/*      */   private void readObject(ObjectInputStream in)
/*      */     throws IOException, ClassNotFoundException
/*      */   {
/*  291 */     in.defaultReadObject();
/*  292 */     init();
/*      */   }
/*      */ 
/*      */   public long getID() {
/*  296 */     return this.id;
/*      */   }
/*      */ 
/*      */   public String getName() {
/*  300 */     return this.name;
/*      */   }
/*      */ 
/*      */   public void setName(String name) {
/*  304 */     this.name = name;
/*  305 */     saveToDb();
/*      */ 
/*  307 */     FACTORY.cacheManager.categoryCache.put(new Long(this.id), this);
/*      */   }
/*      */ 
/*      */   public String getDescription() {
/*  311 */     return this.description;
/*      */   }
/*      */ 
/*      */   public void setDescription(String description) {
/*  315 */     this.description = description;
/*  316 */     saveToDb();
/*      */ 
/*  318 */     FACTORY.cacheManager.categoryCache.put(new Long(this.id), this);
/*      */   }
/*      */ 
/*      */   public Date getCreationDate() {
/*  322 */     return new Date(this.creationDate.getTime());
/*      */   }
/*      */ 
/*      */   public void setCreationDate(Date creationDate) {
/*  326 */     this.creationDate = new Date(creationDate.getTime());
/*  327 */     saveToDb();
/*      */ 
/*  329 */     FACTORY.cacheManager.categoryCache.put(new Long(this.id), this);
/*      */   }
/*      */ 
/*      */   public Date getModificationDate() {
/*  333 */     return new Date(this.modificationDate.getTime());
/*      */   }
/*      */ 
/*      */   public void setModificationDate(Date modificationDate) {
/*  337 */     this.modificationDate = new Date(modificationDate.getTime());
/*  338 */     saveToDb();
/*      */ 
/*  340 */     FACTORY.cacheManager.categoryCache.put(new Long(this.id), this);
/*      */   }
/*      */ 
/*      */   public String getProperty(String name) {
/*  344 */     return (String)this.properties.get(name);
/*      */   }
/*      */ 
/*      */   public Collection getProperties(String parentName) {
/*  348 */     Object[] keys = this.properties.keySet().toArray();
/*  349 */     ArrayList results = new ArrayList();
/*  350 */     int i = 0; for (int n = keys.length; i < n; i++) {
/*  351 */       String key = (String)keys[i];
/*  352 */       if ((key.startsWith(parentName)) && 
/*  353 */         (!key.equals(parentName)))
/*      */       {
/*  356 */         if (key.substring(parentName.length()).lastIndexOf(".") == 0) {
/*  357 */           results.add(this.properties.get(key));
/*      */         }
/*      */       }
/*      */     }
/*  361 */     return Collections.unmodifiableCollection(results);
/*      */   }
/*      */ 
/*      */   public void setProperty(String name, String value)
/*      */   {
/*  366 */     value = ExtendedPropertyUtils.validateExtendedProperty(name, value);
/*      */ 
/*  368 */     if (this.properties.containsKey(name))
/*      */     {
/*  371 */       if (!value.equals(this.properties.get(name))) {
/*  372 */         this.properties.put(name, value);
/*  373 */         updatePropertyInDb(name, value);
/*      */ 
/*  375 */         FACTORY.cacheManager.categoryCache.put(new Long(this.id), this);
/*      */       }
/*      */     } else {
/*  378 */       this.properties.put(name, value);
/*  379 */       insertPropertyIntoDb(name, value);
/*      */ 
/*  381 */       FACTORY.cacheManager.categoryCache.put(new Long(this.id), this);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteProperty(String name)
/*      */   {
/*  387 */     if (this.properties.containsKey(name)) {
/*  388 */       this.properties.remove(name);
/*  389 */       deletePropertyFromDb(name);
/*      */ 
/*  391 */       FACTORY.cacheManager.categoryCache.put(new Long(this.id), this);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Iterator getPropertyNames() {
/*  396 */     return Collections.unmodifiableSet(this.properties.keySet()).iterator();
/*      */   }
/*      */ 
/*      */   public int getForumCount() {
/*  400 */     return getForumCount(DEFAULT_FORUM_FILTER);
/*      */   }
/*      */ 
/*      */   public int getForumCount(ResultFilter resultFilter) {
/*  404 */     CachedPreparedStatement cachedPstmt = getForumListSQL(resultFilter, true, false);
/*  405 */     QueryCacheKey key = new QueryCacheKey(14, this.id, cachedPstmt, -1);
/*  406 */     return QueryCache.getCount(key, true);
/*      */   }
/*      */ 
/*      */   public int getRecursiveForumCount() {
/*  410 */     return getRecursiveForumCount(DEFAULT_FORUM_FILTER);
/*      */   }
/*      */ 
/*      */   public int getRecursiveForumCount(ResultFilter resultFilter) {
/*  414 */     CachedPreparedStatement cachedPstmt = getForumListSQL(resultFilter, true, true);
/*  415 */     QueryCacheKey key = new QueryCacheKey(14, this.id, cachedPstmt, -1);
/*  416 */     return QueryCache.getCount(key, true);
/*      */   }
/*      */ 
/*      */   public Iterator getForums() {
/*  420 */     return getForums(DEFAULT_FORUM_FILTER);
/*      */   }
/*      */ 
/*      */   public Iterator getForums(ResultFilter resultFilter) {
/*  424 */     CachedPreparedStatement cachedPstmt = getForumListSQL(resultFilter, false, false);
/*  425 */     long[] forumBlock = QueryCache.getBlock(cachedPstmt, 14, this.id, resultFilter.getStartIndex(), true);
/*      */ 
/*  427 */     int startIndex = resultFilter.getStartIndex();
/*      */     int endIndex;
/*      */     int endIndex;
/*  431 */     if (resultFilter.getNumResults() == 2147483524) {
/*  432 */       endIndex = getForumCount(resultFilter);
/*      */     }
/*      */     else {
/*  435 */       endIndex = resultFilter.getNumResults() + startIndex;
/*      */     }
/*  437 */     return new ForumBlockIterator(forumBlock, cachedPstmt, startIndex, endIndex, this.id, FACTORY);
/*      */   }
/*      */ 
/*      */   public Iterator getRecursiveForums()
/*      */   {
/*  442 */     return getRecursiveForums(DEFAULT_FORUM_FILTER);
/*      */   }
/*      */ 
/*      */   public Iterator getRecursiveForums(ResultFilter resultFilter) {
/*  446 */     CachedPreparedStatement query = getForumListSQL(resultFilter, false, true);
/*  447 */     long[] forumBlock = QueryCache.getBlock(query, 14, this.id, resultFilter.getStartIndex(), true);
/*      */ 
/*  449 */     int startIndex = resultFilter.getStartIndex();
/*      */     int endIndex;
/*      */     int endIndex;
/*  453 */     if (resultFilter.getNumResults() == 2147483524) {
/*  454 */       endIndex = getRecursiveForumCount(resultFilter);
/*      */     }
/*      */     else {
/*  457 */       endIndex = resultFilter.getNumResults() + startIndex;
/*      */     }
/*  459 */     return new ForumBlockIterator(forumBlock, query, startIndex, endIndex, this.id, FACTORY);
/*      */   }
/*      */ 
/*      */   public void setForumIndex(Forum forum, int newIndex) {
/*  463 */     if ((newIndex < 0) || (newIndex > getForumCount() - 1)) {
/*  464 */       throw new IllegalArgumentException("Invalid index");
/*      */     }
/*  466 */     Connection con = null;
/*  467 */     PreparedStatement pstmt = null;
/*  468 */     boolean abortTransaction = false;
/*      */     try {
/*  470 */       con = ConnectionManager.getTransactionConnection();
/*      */ 
/*  472 */       pstmt = con.prepareStatement("SELECT categoryIndex FROM jiveForum WHERE forumID=? AND categoryID=?");
/*  473 */       pstmt.setLong(1, forum.getID());
/*  474 */       pstmt.setLong(2, this.id);
/*  475 */       ResultSet rs = pstmt.executeQuery();
/*      */ 
/*  478 */       if (!rs.next()) {
/*  479 */         throw new IllegalArgumentException("Forum " + forum.getID() + " is not in category " + this.id);
/*      */       }
/*      */ 
/*  482 */       int oldIndex = rs.getInt(1);
/*  483 */       rs.close();
/*  484 */       pstmt.close();
/*      */ 
/*  488 */       if (newIndex < oldIndex) {
/*  489 */         pstmt = con.prepareStatement("UPDATE jiveForum SET categoryIndex=categoryIndex+1 WHERE categoryID=? AND categoryIndex >= ? AND categoryIndex <?");
/*      */       }
/*      */       else {
/*  492 */         pstmt = con.prepareStatement("UPDATE jiveForum SET categoryIndex=categoryIndex-1 WHERE categoryID=? AND categoryIndex <= ? AND categoryIndex > ?");
/*      */       }
/*  494 */       pstmt.setLong(1, this.id);
/*  495 */       pstmt.setInt(2, newIndex);
/*  496 */       pstmt.setInt(3, oldIndex);
/*  497 */       pstmt.execute();
/*  498 */       pstmt.close();
/*      */ 
/*  501 */       pstmt = con.prepareStatement("UPDATE jiveForum SET categoryIndex=? WHERE forumID=?");
/*  502 */       pstmt.setInt(1, newIndex);
/*  503 */       pstmt.setLong(2, forum.getID());
/*  504 */       pstmt.execute();
/*      */     }
/*      */     catch (SQLException sqle) {
/*  507 */       Log.error(sqle);
/*  508 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/*  511 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */ 
/*  514 */     clearCache();
/*      */   }
/*      */ 
/*      */   public void moveForum(Forum forum, ForumCategory destinationCategory) {
/*  518 */     Connection con = null;
/*  519 */     PreparedStatement pstmt = null;
/*  520 */     boolean abortTransaction = false;
/*      */     try {
/*  522 */       con = ConnectionManager.getTransactionConnection();
/*      */ 
/*  524 */       pstmt = con.prepareStatement("SELECT categoryIndex FROM jiveForum WHERE forumID=? AND categoryID=?");
/*  525 */       pstmt.setLong(1, forum.getID());
/*  526 */       pstmt.setLong(2, this.id);
/*  527 */       ResultSet rs = pstmt.executeQuery();
/*      */ 
/*  530 */       if (!rs.next()) {
/*  531 */         throw new IllegalArgumentException("Forum " + forum.getID() + " is not in category " + this.id);
/*      */       }
/*      */ 
/*  534 */       int oldIndex = rs.getInt(1);
/*  535 */       rs.close();
/*  536 */       pstmt.close();
/*      */ 
/*  539 */       pstmt = con.prepareStatement("SELECT count(categoryIndex) FROM jiveForum WHERE categoryID=?");
/*  540 */       pstmt.setLong(1, this.id);
/*  541 */       rs = pstmt.executeQuery();
/*  542 */       rs.next();
/*  543 */       int count = rs.getInt(1);
/*  544 */       int newIndex = count == 0 ? 0 : count - 1;
/*  545 */       rs.close();
/*  546 */       pstmt.close();
/*      */ 
/*  549 */       if (newIndex < oldIndex) {
/*  550 */         pstmt = con.prepareStatement("UPDATE jiveForum SET categoryIndex=categoryIndex+1 WHERE categoryID=? AND categoryIndex >= ? AND categoryIndex <?");
/*      */       }
/*      */       else {
/*  553 */         pstmt = con.prepareStatement("UPDATE jiveForum SET categoryIndex=categoryIndex-1 WHERE categoryID=? AND categoryIndex <= ? AND categoryIndex > ?");
/*      */       }
/*  555 */       pstmt.setLong(1, this.id);
/*  556 */       pstmt.setInt(2, newIndex);
/*  557 */       pstmt.setInt(3, oldIndex);
/*  558 */       pstmt.execute();
/*  559 */       pstmt.close();
/*      */ 
/*  562 */       pstmt = con.prepareStatement("SELECT count(categoryIndex) FROM jiveForum WHERE categoryID=?");
/*  563 */       pstmt.setLong(1, destinationCategory.getID());
/*  564 */       rs = pstmt.executeQuery();
/*  565 */       rs.next();
/*  566 */       int destinationIndex = rs.getInt(1);
/*  567 */       rs.close();
/*  568 */       pstmt.close();
/*      */ 
/*  571 */       pstmt = con.prepareStatement("UPDATE jiveForum SET categoryID=?, categoryIndex=? WHERE forumID=?");
/*  572 */       pstmt.setLong(1, destinationCategory.getID());
/*  573 */       pstmt.setInt(2, destinationIndex);
/*  574 */       pstmt.setLong(3, forum.getID());
/*  575 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (SQLException sqle) {
/*  578 */       Log.error(sqle);
/*  579 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/*  582 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */     try
/*      */     {
/*  586 */       FACTORY.cacheManager.getForum(forum.getID()).clearCache();
/*      */     }
/*      */     catch (Exception e) {
/*  589 */       Log.error(e);
/*      */     }
/*  591 */     FACTORY.cacheManager.forumCache.remove(new Long(forum.getID()));
/*  592 */     clearCache();
/*      */     try {
/*  594 */       FACTORY.cacheManager.getForumCategory(destinationCategory.getID()).clearCache();
/*      */     }
/*      */     catch (Exception e) {
/*  597 */       Log.error(e);
/*      */     }
/*      */ 
/*  601 */     DbPermissionsManager.userPermsCache.clear();
/*      */     try
/*      */     {
/*  605 */       forum = FACTORY.cacheManager.getForum(forum.getID());
/*      */     }
/*      */     catch (ForumNotFoundException fnfe) {
/*      */     }
/*  609 */     Map params = new TreeMap();
/*  610 */     params.put("oldCategoryID", new Long(this.id));
/*  611 */     ForumEvent event = new ForumEvent(122, forum, params);
/*  612 */     ForumEventDispatcher.getInstance().dispatchEvent(event);
/*      */   }
/*      */ 
/*      */   public ForumCategory getParentCategory() {
/*  616 */     ForumCategory parent = null;
/*      */     try
/*      */     {
/*  619 */       if (this.id != 1L)
/*  620 */         parent = FACTORY.getForumCategory(categoryTree.getParent(this.id));
/*      */     }
/*      */     catch (ForumCategoryNotFoundException fcnfe)
/*      */     {
/*  624 */       Log.error(fcnfe);
/*      */     }
/*  626 */     return parent;
/*      */   }
/*      */ 
/*      */   protected ForumCategory getParentCategory(Connection con) {
/*  630 */     ForumCategory parent = null;
/*      */     try
/*      */     {
/*  633 */       if (this.id != 1L)
/*  634 */         return FACTORY.cacheManager.getForumCategory(categoryTree.getParent(this.id), con);
/*      */     }
/*      */     catch (ForumCategoryNotFoundException fcnfe)
/*      */     {
/*  638 */       Log.error(fcnfe);
/*      */     }
/*  640 */     return parent;
/*      */   }
/*      */ 
/*      */   public int getCategoryCount() {
/*  644 */     return categoryTree.getChildCount(this.id);
/*      */   }
/*      */ 
/*      */   public Iterator getCategories() {
/*  648 */     long[] children = categoryTree.getChildren(this.id);
/*  649 */     return new DatabaseObjectIterator(14, children, FACTORY);
/*      */   }
/*      */ 
/*      */   public Iterator getCategories(int startIndex, int numResults)
/*      */   {
/*  654 */     long[] children = categoryTree.getChildren(this.id);
/*  655 */     if (startIndex < children.length) {
/*  656 */       int size = numResults < children.length - startIndex ? numResults : children.length - startIndex;
/*      */ 
/*  658 */       long[] results = new long[size];
/*  659 */       for (int i = 0; i < size; i++) {
/*  660 */         results[i] = children[(startIndex + i)];
/*      */       }
/*  662 */       return new DatabaseObjectIterator(14, results, FACTORY);
/*      */     }
/*      */ 
/*  666 */     return Collections.EMPTY_LIST.iterator();
/*      */   }
/*      */ 
/*      */   public int getRecursiveCategoryCount()
/*      */   {
/*  671 */     return categoryTree.getRecursiveChildren(this.id).length;
/*      */   }
/*      */ 
/*      */   public Iterator getRecursiveCategories() {
/*  675 */     long[] children = categoryTree.getRecursiveChildren(this.id);
/*  676 */     return new DatabaseObjectIterator(14, children, FACTORY);
/*      */   }
/*      */ 
/*      */   public int getCategoryDepth() {
/*  680 */     return categoryTree.getDepth(this.id);
/*      */   }
/*      */ 
/*      */   public void setCategoryIndex(ForumCategory category, int newIndex) {
/*  684 */     synchronized (lock) {
/*  685 */       long categoryID = category.getID();
/*  686 */       if ((categoryID == 1L) || (category.getParentCategory().getID() != this.id)) {
/*  687 */         throw new IllegalArgumentException("Invalid category argument.");
/*      */       }
/*  689 */       if ((newIndex < 0) || (newIndex >= getCategoryCount())) {
/*  690 */         throw new IllegalArgumentException("Invalid new index: " + newIndex);
/*      */       }
/*      */ 
/*  693 */       Connection con = null;
/*  694 */       PreparedStatement pstmt = null;
/*  695 */       boolean abortTransaction = false;
/*      */       try {
/*  697 */         con = ConnectionManager.getTransactionConnection();
/*      */ 
/*  700 */         pstmt = con.prepareStatement("SELECT lft, rgt FROM jiveCategory WHERE categoryID=?");
/*  701 */         pstmt.setLong(1, categoryID);
/*  702 */         ResultSet rs = pstmt.executeQuery();
/*  703 */         rs.next();
/*  704 */         int currentLft = rs.getInt(1);
/*  705 */         int currentRgt = rs.getInt(2);
/*  706 */         rs.close();
/*      */ 
/*  710 */         long replaceID = categoryTree.getChildren(this.id)[newIndex];
/*  711 */         pstmt.setLong(1, replaceID);
/*  712 */         rs = pstmt.executeQuery();
/*  713 */         rs.next();
/*  714 */         int replaceLft = rs.getInt(1);
/*  715 */         int replaceRgt = rs.getInt(2);
/*  716 */         rs.close();
/*  717 */         pstmt.close();
/*      */         int indexDelta;
/*      */         int indexDelta;
/*  721 */         if (replaceRgt < currentRgt) {
/*  722 */           indexDelta = currentLft - replaceLft;
/*      */         }
/*      */         else {
/*  725 */           indexDelta = Math.abs(currentRgt - replaceRgt);
/*      */         }
/*  727 */         int delta = currentRgt - currentLft;
/*      */ 
/*  730 */         if (replaceRgt < currentRgt) {
/*  731 */           pstmt = con.prepareStatement("UPDATE jiveCategory SET lft=lft+?, rgt=rgt+? WHERE lft>=? AND lft<?");
/*  732 */           pstmt.setInt(1, delta + 1);
/*  733 */           pstmt.setInt(2, delta + 1);
/*  734 */           pstmt.setInt(3, replaceLft);
/*  735 */           pstmt.setInt(4, currentLft);
/*      */         }
/*      */         else {
/*  738 */           pstmt = con.prepareStatement("UPDATE jiveCategory SET lft=lft+?, rgt=rgt+? WHERE lft>? AND rgt>? AND rgt<=?");
/*  739 */           pstmt.setInt(1, 0 - (delta + 1));
/*  740 */           pstmt.setInt(2, 0 - (delta + 1));
/*  741 */           pstmt.setInt(3, currentLft);
/*  742 */           pstmt.setInt(4, currentRgt);
/*  743 */           pstmt.setInt(5, replaceRgt);
/*      */         }
/*  745 */         pstmt.execute();
/*  746 */         pstmt.close();
/*      */ 
/*  749 */         StringBuffer sql = new StringBuffer();
/*  750 */         if (replaceRgt < currentRgt) {
/*  751 */           sql.append("UPDATE jiveCategory SET lft=lft-").append(indexDelta);
/*  752 */           sql.append(", rgt=rgt-").append(indexDelta);
/*      */         }
/*      */         else {
/*  755 */           sql.append("UPDATE jiveCategory SET lft=lft+").append(indexDelta);
/*  756 */           sql.append(", rgt=rgt+").append(indexDelta);
/*      */         }
/*  758 */         sql.append(" WHERE categoryID IN(").append(categoryID);
/*  759 */         long[] childCats = categoryTree.getRecursiveChildren(categoryID);
/*  760 */         for (int i = 0; i < childCats.length; i++) {
/*  761 */           sql.append(",").append(childCats[i]);
/*      */         }
/*  763 */         sql.append(")");
/*  764 */         pstmt = con.prepareStatement(sql.toString());
/*  765 */         pstmt.execute();
/*      */       }
/*      */       catch (Exception e) {
/*  768 */         Log.error(e);
/*  769 */         abortTransaction = true;
/*      */       }
/*      */       finally {
/*  772 */         ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */       }
/*  774 */       refreshCategoryTree(false);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void moveCategory(ForumCategory category, ForumCategory destinationCategory) {
/*  779 */     synchronized (lock)
/*      */     {
/*  781 */       ForumCategory parent = destinationCategory.getParentCategory();
/*  782 */       while (parent != null) {
/*  783 */         if (parent.getID() == category.getID()) {
/*  784 */           throw new IllegalArgumentException("You cannot move a parent category into a child.");
/*      */         }
/*      */ 
/*  787 */         parent = parent.getParentCategory();
/*      */       }
/*      */ 
/*  790 */       Connection con = null;
/*  791 */       PreparedStatement pstmt = null;
/*  792 */       boolean abortTransaction = false;
/*      */       try {
/*  794 */         con = ConnectionManager.getTransactionConnection();
/*      */ 
/*  796 */         pstmt = con.prepareStatement("SELECT lft, rgt FROM jiveCategory WHERE categoryID=?");
/*  797 */         pstmt.setLong(1, category.getID());
/*  798 */         ResultSet rs = pstmt.executeQuery();
/*  799 */         rs.next();
/*  800 */         int lft = rs.getInt(1);
/*  801 */         int rgt = rs.getInt(2);
/*  802 */         int delta = rgt - lft + 1;
/*  803 */         rs.close();
/*  804 */         pstmt.close();
/*      */ 
/*  807 */         long[] childCats = categoryTree.getRecursiveChildren(category.getID());
/*  808 */         StringBuffer sql = new StringBuffer();
/*  809 */         sql.append("UPDATE jiveCategory SET lft=lft+? WHERE lft > ? AND rgt > ?");
/*      */ 
/*  812 */         sql.append(" AND categoryID NOT IN(").append(category.getID());
/*  813 */         for (int i = 0; i < childCats.length; i++) {
/*  814 */           sql.append(",").append(childCats[i]);
/*      */         }
/*  816 */         sql.append(")");
/*  817 */         pstmt = con.prepareStatement(sql.toString());
/*  818 */         pstmt.setInt(1, -delta);
/*  819 */         pstmt.setInt(2, lft);
/*  820 */         pstmt.setInt(3, rgt);
/*  821 */         pstmt.execute();
/*  822 */         pstmt.close();
/*  823 */         sql = new StringBuffer();
/*  824 */         sql.append("UPDATE jiveCategory SET rgt=rgt+? WHERE rgt >= ?");
/*      */ 
/*  827 */         sql.append(" AND categoryID NOT IN(").append(category.getID());
/*  828 */         for (int i = 0; i < childCats.length; i++) {
/*  829 */           sql.append(",").append(childCats[i]);
/*      */         }
/*  831 */         sql.append(")");
/*  832 */         pstmt = con.prepareStatement(sql.toString());
/*  833 */         pstmt.setInt(1, -delta);
/*  834 */         pstmt.setInt(2, rgt);
/*  835 */         pstmt.execute();
/*  836 */         pstmt.close();
/*      */ 
/*  839 */         pstmt = con.prepareStatement("SELECT lft, rgt FROM jiveCategory WHERE categoryID=?");
/*  840 */         pstmt.setLong(1, destinationCategory.getID());
/*  841 */         rs = pstmt.executeQuery();
/*  842 */         rs.next();
/*  843 */         int parentLft = rs.getInt(1);
/*  844 */         int parentRgt = rs.getInt(2);
/*  845 */         rs.close();
/*  846 */         pstmt.close();
/*      */ 
/*  849 */         sql = new StringBuffer();
/*  850 */         sql.append("UPDATE jiveCategory SET lft=lft+? WHERE lft > ? AND rgt > ?");
/*      */ 
/*  853 */         sql.append(" AND categoryID NOT IN(").append(category.getID());
/*  854 */         for (int i = 0; i < childCats.length; i++) {
/*  855 */           sql.append(",").append(childCats[i]);
/*      */         }
/*  857 */         sql.append(")");
/*  858 */         pstmt = con.prepareStatement(sql.toString());
/*  859 */         pstmt.setInt(1, delta);
/*  860 */         pstmt.setInt(2, parentLft);
/*  861 */         pstmt.setInt(3, parentRgt);
/*  862 */         pstmt.execute();
/*  863 */         pstmt.close();
/*  864 */         sql = new StringBuffer();
/*  865 */         sql.append("UPDATE jiveCategory SET rgt=rgt+? WHERE rgt >= ?");
/*      */ 
/*  868 */         sql.append(" AND categoryID NOT IN(").append(category.getID());
/*  869 */         for (int i = 0; i < childCats.length; i++) {
/*  870 */           sql.append(",").append(childCats[i]);
/*      */         }
/*  872 */         sql.append(")");
/*  873 */         pstmt = con.prepareStatement(sql.toString());
/*  874 */         pstmt.setInt(1, delta);
/*  875 */         pstmt.setInt(2, parentRgt);
/*  876 */         pstmt.execute();
/*  877 */         pstmt.close();
/*      */ 
/*  880 */         sql = new StringBuffer();
/*  881 */         sql.append("UPDATE jiveCategory SET lft=lft+?, rgt=rgt+? WHERE ");
/*  882 */         sql.append(" categoryID IN(").append(category.getID());
/*      */ 
/*  884 */         for (int i = 0; i < childCats.length; i++) {
/*  885 */           sql.append(",").append(childCats[i]);
/*      */         }
/*  887 */         sql.append(")");
/*  888 */         pstmt = con.prepareStatement(sql.toString());
/*  889 */         pstmt.setInt(1, parentRgt - lft);
/*  890 */         pstmt.setInt(2, parentRgt - lft);
/*  891 */         pstmt.executeUpdate();
/*      */       }
/*      */       catch (Exception e) {
/*  894 */         Log.error(e);
/*  895 */         abortTransaction = true;
/*      */       }
/*      */       finally {
/*  898 */         ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */       }
/*  900 */       refreshCategoryTree(false);
/*      */     }
/*      */ 
/*  904 */     DbPermissionsManager.userPermsCache.clear();
/*      */ 
/*  907 */     Map params = new TreeMap();
/*  908 */     params.put("oldCategoryID", new Long(this.id));
/*  909 */     CategoryEvent event = new CategoryEvent(132, category, params);
/*  910 */     CategoryEventDispatcher.getInstance().dispatchEvent(event);
/*      */   }
/*      */ 
/*      */   public ForumCategory createCategory(String name, String description) {
/*  914 */     ForumCategory category = null;
/*  915 */     synchronized (lock) {
/*  916 */       category = new DbForumCategory(name, description, this);
/*      */ 
/*  918 */       refreshCategoryTree(false);
/*      */     }
/*      */ 
/*  921 */     CategoryEvent event = new CategoryEvent(130, category, Collections.EMPTY_MAP);
/*      */ 
/*  923 */     CategoryEventDispatcher.getInstance().dispatchEvent(event);
/*      */ 
/*  925 */     return category;
/*      */   }
/*      */ 
/*      */   public void deleteCategory(ForumCategory forumCategory) {
/*  929 */     synchronized (lock) {
/*  930 */       if ((forumCategory.getID() == 1L) || (forumCategory.getParentCategory().getID() != this.id))
/*      */       {
/*  933 */         throw new IllegalArgumentException();
/*      */       }
/*      */ 
/*  937 */       CategoryEvent event = new CategoryEvent(131, forumCategory, Collections.EMPTY_MAP);
/*      */ 
/*  939 */       CategoryEventDispatcher.getInstance().dispatchEvent(event);
/*      */ 
/*  941 */       boolean abortTransaction = false;
/*  942 */       Connection con = null;
/*  943 */       PreparedStatement pstmt = null;
/*      */       try {
/*  945 */         con = ConnectionManager.getTransactionConnection();
/*  946 */         DbForumCategory category = FACTORY.cacheManager.getForumCategory(forumCategory.getID());
/*      */ 
/*  949 */         pstmt = con.prepareStatement("SELECT lft, rgt FROM jiveCategory WHERE categoryID=?");
/*  950 */         pstmt.setLong(1, category.getID());
/*  951 */         ResultSet rs = pstmt.executeQuery();
/*  952 */         rs.next();
/*  953 */         int lft = rs.getInt(1);
/*  954 */         int rgt = rs.getInt(2);
/*  955 */         int delta = 0 - (rgt - lft + 1);
/*  956 */         rs.close();
/*  957 */         pstmt.close();
/*      */ 
/*  960 */         category.deleteFromDb(con);
/*      */ 
/*  963 */         pstmt = con.prepareStatement("UPDATE jiveCategory SET lft=lft+? WHERE lft > ? AND rgt > ?");
/*  964 */         pstmt.setInt(1, delta);
/*  965 */         pstmt.setInt(2, lft);
/*  966 */         pstmt.setInt(3, rgt);
/*  967 */         pstmt.execute();
/*  968 */         pstmt.close();
/*  969 */         pstmt = con.prepareStatement("UPDATE jiveCategory SET rgt=rgt+? WHERE rgt >= ?");
/*  970 */         pstmt.setInt(1, delta);
/*  971 */         pstmt.setInt(2, rgt);
/*  972 */         pstmt.execute();
/*  973 */         pstmt.close();
/*      */       }
/*      */       catch (Exception e) {
/*  976 */         Log.error(e);
/*  977 */         abortTransaction = true;
/*      */       }
/*      */       finally {
/*  980 */         ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */       }
/*  982 */       refreshCategoryTree(false);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteForum(Forum forum) throws UnauthorizedException {
/*  987 */     deleteForum(forum, true);
/*      */   }
/*      */ 
/*      */   public void deleteForum(Forum forum, boolean fireEvent) throws UnauthorizedException
/*      */   {
/*  992 */     ForumEvent event = new ForumEvent(121, forum, Collections.EMPTY_MAP);
/*  993 */     ForumEventDispatcher.getInstance().dispatchEvent(event);
/*      */ 
/*  998 */     boolean largeForum = forum.getMessageCount() > 750;
/*  999 */     LongList messages = new LongList();
/* 1000 */     LongList forumIndexes = new LongList();
/* 1001 */     LongList threads = new LongList();
/* 1002 */     if (!largeForum) {
/* 1003 */       Connection con = null;
/* 1004 */       PreparedStatement pstmt = null;
/*      */       try {
/* 1006 */         con = ConnectionManager.getConnection();
/* 1007 */         pstmt = con.prepareStatement("SELECT messageID, forumIndex, threadID FROM jiveMessage WHERE forumID=?");
/* 1008 */         pstmt.setLong(1, forum.getID());
/* 1009 */         ResultSet rs = pstmt.executeQuery();
/* 1010 */         while (rs.next()) {
/* 1011 */           messages.add(rs.getLong(1));
/* 1012 */           forumIndexes.add(rs.getInt(2));
/* 1013 */           threads.add(rs.getLong(3));
/*      */         }
/* 1015 */         rs.close();
/*      */       }
/*      */       catch (SQLException sqle) {
/* 1018 */         Log.error(sqle);
/*      */       }
/*      */       finally {
/* 1021 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1028 */     FilterManager filterManager = forum.getFilterManager();
/* 1029 */     int filterCount = filterManager.getFilterCount();
/* 1030 */     for (int i = filterCount - 1; i >= 0; i--) {
/* 1031 */       filterManager.removeFilter(i);
/*      */     }
/*      */ 
/* 1035 */     forum.getGatewayManager().delete();
/* 1036 */     FACTORY.gatewayManagers.removeKey(forum.getID());
/*      */ 
/* 1039 */     FACTORY.permissionsManager.removeAllPermissions(0, forum.getID());
/*      */ 
/* 1041 */     DbForumCategory category = null;
/*      */     try {
/* 1043 */       category = FACTORY.cacheManager.getForumCategory(forum.getForumCategory().getID());
/*      */     }
/*      */     catch (ForumCategoryNotFoundException e) {
/* 1046 */       Log.error(e);
/*      */     }
/*      */ 
/* 1050 */     Connection con = null;
/* 1051 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1053 */       con = ConnectionManager.getConnection();
/*      */ 
/* 1057 */       int newIndex = category.getForumCount() - 1;
/* 1058 */       pstmt = con.prepareStatement("SELECT categoryIndex FROM jiveForum WHERE forumID=? AND categoryID=?");
/* 1059 */       pstmt.setLong(1, forum.getID());
/* 1060 */       pstmt.setLong(2, category.getID());
/* 1061 */       ResultSet rs = pstmt.executeQuery();
/*      */ 
/* 1064 */       if (!rs.next()) {
/* 1065 */         throw new IllegalArgumentException("Forum " + forum.getID() + " is not in category " + category.getID());
/*      */       }
/*      */ 
/* 1068 */       int oldIndex = rs.getInt(1);
/* 1069 */       rs.close();
/* 1070 */       pstmt.close();
/*      */ 
/* 1073 */       if (newIndex < oldIndex) {
/* 1074 */         pstmt = con.prepareStatement("UPDATE jiveForum SET categoryIndex=categoryIndex+1 WHERE categoryID=? AND categoryIndex >= ? AND categoryIndex <?");
/*      */       }
/*      */       else {
/* 1077 */         pstmt = con.prepareStatement("UPDATE jiveForum SET categoryIndex=categoryIndex-1 WHERE categoryID=? AND categoryIndex <= ? AND categoryIndex > ?");
/*      */       }
/* 1079 */       pstmt.setLong(1, category.getID());
/* 1080 */       pstmt.setInt(2, newIndex);
/* 1081 */       pstmt.setInt(3, oldIndex);
/* 1082 */       pstmt.execute();
/* 1083 */       pstmt.close();
/*      */ 
/* 1086 */       LongList attachIDs = new LongList();
/* 1087 */       pstmt = con.prepareStatement("SELECT attachmentID FROM jiveAttachment, jiveMessage WHERE jiveAttachment.objectType=2 AND jiveAttachment.objectID=jiveMessage.messageID AND forumID=?");
/* 1088 */       pstmt.setLong(1, forum.getID());
/* 1089 */       rs = pstmt.executeQuery();
/* 1090 */       while (rs.next()) {
/* 1091 */         attachIDs.add(rs.getLong(1));
/*      */       }
/* 1093 */       rs.close();
/* 1094 */       pstmt.close();
/* 1095 */       long[] attachments = attachIDs.toArray();
/* 1096 */       for (int i = 0; i < attachments.length; i++) {
/*      */         try {
/* 1098 */           DbAttachment attachment = FACTORY.cacheManager.getAttachment(attachments[i]);
/* 1099 */           attachment.delete(con);
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1107 */       if (ConnectionManager.isSubqueriesSupported()) {
/* 1108 */         ConnectionManager.disablePostgresTablescan(con);
/*      */         try {
/* 1110 */           pstmt = con.prepareStatement("DELETE FROM jiveMessageProp WHERE messageID IN(SELECT messageID FROM jiveMessage WHERE forumID=?)");
/* 1111 */           pstmt.setLong(1, forum.getID());
/* 1112 */           pstmt.execute();
/* 1113 */           pstmt.close();
/*      */         }
/*      */         finally
/*      */         {
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1121 */         LongList messageIDs = new LongList();
/* 1122 */         pstmt = con.prepareStatement("SELECT jiveMessageProp.messageID FROM jiveMessageProp, jiveMessage WHERE jiveMessageProp.messageID=jiveMessage.messageID AND jiveMessage.forumID=?");
/* 1123 */         pstmt.setLong(1, forum.getID());
/* 1124 */         rs = pstmt.executeQuery();
/* 1125 */         while (rs.next()) {
/* 1126 */           messageIDs.add(rs.getLong(1));
/*      */         }
/* 1128 */         rs.close();
/* 1129 */         pstmt.close();
/*      */ 
/* 1132 */         ConnectionManager.batchDeleteWithoutSubqueries(con, "DELETE FROM jiveMessageProp WHERE messageID IN", messageIDs.toArray());
/*      */       }
/*      */ 
/* 1137 */       if (ConnectionManager.isSubqueriesSupported()) {
/* 1138 */         ConnectionManager.disablePostgresTablescan(con);
/*      */         try {
/* 1140 */           pstmt = con.prepareStatement("DELETE FROM jiveThreadProp WHERE threadID IN(SELECT threadID FROM jiveThread WHERE forumID=?)");
/* 1141 */           pstmt.setLong(1, forum.getID());
/* 1142 */           pstmt.execute();
/* 1143 */           pstmt.close();
/*      */         }
/*      */         finally
/*      */         {
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1151 */         LongList threadIDs = new LongList();
/* 1152 */         pstmt = con.prepareStatement("SELECT jiveThreadProp.threadID FROM jiveThreadProp, jiveThread WHERE jiveThreadProp.threadID=jiveThread.threadID AND jiveThread.forumID=?");
/* 1153 */         pstmt.setLong(1, forum.getID());
/* 1154 */         rs = pstmt.executeQuery();
/* 1155 */         while (rs.next()) {
/* 1156 */           threadIDs.add(rs.getLong(1));
/*      */         }
/* 1158 */         rs.close();
/* 1159 */         pstmt.close();
/*      */ 
/* 1162 */         ConnectionManager.batchDeleteWithoutSubqueries(con, "DELETE FROM jiveThreadProp WHERE threadID IN", threadIDs.toArray());
/*      */       }
/*      */ 
/* 1168 */       if (ConnectionManager.isTransactionsSupported()) {
/* 1169 */         con.setAutoCommit(false);
/*      */       }
/*      */       try
/*      */       {
/* 1173 */         pstmt = con.prepareStatement("DELETE FROM jiveMessage WHERE forumID=?");
/* 1174 */         pstmt.setLong(1, forum.getID());
/* 1175 */         pstmt.execute();
/* 1176 */         pstmt.close();
/*      */ 
/* 1178 */         pstmt = con.prepareStatement("DELETE FROM jiveThread WHERE forumID=?");
/* 1179 */         pstmt.setLong(1, forum.getID());
/* 1180 */         pstmt.execute();
/* 1181 */         pstmt.close();
/* 1182 */         if (ConnectionManager.isTransactionsSupported())
/* 1183 */           con.commit();
/*      */       }
/*      */       finally
/*      */       {
/* 1187 */         if (ConnectionManager.isTransactionsSupported()) {
/* 1188 */           con.setAutoCommit(true);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1193 */       pstmt = con.prepareStatement("DELETE FROM jiveForumProp WHERE forumID=?");
/* 1194 */       pstmt.setLong(1, forum.getID());
/* 1195 */       pstmt.execute();
/* 1196 */       pstmt.close();
/*      */ 
/* 1199 */       pstmt = con.prepareStatement("DELETE FROM jiveForum WHERE forumID=?");
/* 1200 */       pstmt.setLong(1, forum.getID());
/* 1201 */       pstmt.execute();
/* 1202 */       pstmt.close();
/*      */     }
/* 1205 */     catch (Exception e) { Log.error(e);
/*      */       return;
/*      */     }
/*      */     finally {
/* 1209 */       ConnectionManager.closeConnection(con);
/*      */     }
/*      */ 
/* 1213 */     if (largeForum) {
/* 1214 */       FACTORY.cacheManager.messageCache.clear();
/* 1215 */       FACTORY.cacheManager.forumIndexCache.clear();
/* 1216 */       FACTORY.cacheManager.threadCache.clear();
/*      */     }
/*      */     else
/*      */     {
/* 1220 */       for (int i = 0; i < messages.size(); i++) {
/* 1221 */         FACTORY.cacheManager.messageRemove(messages.get(i));
/* 1222 */         String key = forum.getID() + '-' + forumIndexes.get(i);
/*      */ 
/* 1224 */         FACTORY.cacheManager.forumIndexRemove(key);
/* 1225 */         FACTORY.cacheManager.threadRemove(threads.get(i));
/*      */       }
/* 1227 */       messages = null;
/* 1228 */       forumIndexes = null;
/* 1229 */       threads = null;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 1235 */       ForumCategory cat = category;
/* 1236 */       while (cat != null) {
/* 1237 */         FACTORY.cacheManager.getForumCategory(cat.getID()).clearCache();
/* 1238 */         cat = cat.getParentCategory();
/*      */       }
/*      */     }
/*      */     catch (ForumCategoryNotFoundException e)
/*      */     {
/*      */     }
/* 1244 */     if (SequenceManager.isNamedSequencesSupportd()) {
/* 1245 */       SequenceManager.deleteNamedSequence("forumIdx" + forum.getID());
/*      */     }
/*      */ 
/* 1249 */     FACTORY.expirePopularObjects(true);
/*      */ 
/* 1252 */     FACTORY.cacheManager.forumNNTPNameCache.remove(forum.getNNTPName());
/* 1253 */     FACTORY.cacheManager.forumCache.remove(new Long(forum.getID()));
/*      */   }
/*      */ 
/*      */   public Iterator getPopularThreads() {
/* 1257 */     if (this.popularThreads == null)
/*      */     {
/* 1260 */       int threadNumber = JiveGlobals.getJiveIntProperty("popularThreads.number", 4);
/*      */ 
/* 1264 */       int timeWindow = JiveGlobals.getJiveIntProperty("popularThreads.timeWindow", 24);
/*      */ 
/* 1266 */       LongList popThreads = new LongList(threadNumber);
/*      */ 
/* 1268 */       Calendar cal = Calendar.getInstance();
/* 1269 */       cal.add(11, -timeWindow);
/*      */ 
/* 1271 */       Connection con = null;
/* 1272 */       PreparedStatement pstmt = null;
/*      */       try {
/* 1274 */         int[] lftRgtValues = getLftRgtValues(this.id);
/* 1275 */         con = ConnectionManager.getConnection();
/*      */ 
/* 1278 */         if (ConnectionManager.getDatabaseType() == ConnectionManager.DatabaseType.ORACLE)
/*      */         {
/* 1281 */           pstmt = con.prepareStatement("SELECT /*+ INDEX (jiveMessage jiveMessage_mDate_idx) */ threadID, count(*) AS msgCount FROM jiveMessage, jiveForum, jiveCategory WHERE jiveMessage.modificationDate > ? AND jiveCategory.lft>=? AND jiveCategory.rgt<=? AND jiveCategory.categoryID=jiveForum.categoryID AND jiveMessage.forumID=jiveForum.forumID AND jiveMessage.modValue >= 1 GROUP BY threadID ORDER BY msgCount DESC");
/*      */         }
/*      */         else {
/* 1284 */           pstmt = con.prepareStatement("SELECT threadID, count(*) AS msgCount FROM jiveMessage, jiveForum, jiveCategory WHERE jiveMessage.modificationDate > ? AND jiveCategory.lft>=? AND jiveCategory.rgt<=? AND jiveCategory.categoryID=jiveForum.categoryID AND jiveMessage.forumID=jiveForum.forumID AND jiveMessage.modValue >=  1 GROUP BY threadID ORDER BY msgCount DESC");
/*      */         }
/* 1286 */         pstmt.setLong(1, cal.getTime().getTime());
/* 1287 */         pstmt.setInt(2, lftRgtValues[0]);
/* 1288 */         pstmt.setInt(3, lftRgtValues[1]);
/* 1289 */         ResultSet rs = pstmt.executeQuery();
/* 1290 */         for (int i = 0; (i < threadNumber) && 
/* 1291 */           (rs.next()); i++)
/*      */         {
/* 1294 */           popThreads.add(rs.getLong(1));
/*      */         }
/* 1296 */         rs.close();
/* 1297 */         this.popularThreads = popThreads.toArray();
/*      */       }
/*      */       catch (SQLException sqle) {
/* 1300 */         Log.error(sqle);
/*      */       }
/*      */       finally {
/* 1303 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*      */ 
/* 1307 */       this.popularThreadsTimestamp = CacheFactory.currentTime;
/*      */     }
/* 1309 */     return new DatabaseObjectIterator(1, this.popularThreads, FACTORY);
/*      */   }
/*      */ 
/*      */   public Iterator getThreads() {
/* 1313 */     return getThreads(DEFAULT_THREAD_FILTER);
/*      */   }
/*      */ 
/*      */   public Iterator getThreads(ResultFilter resultFilter) {
/* 1317 */     CachedPreparedStatement query = getThreadListSQL(resultFilter, false);
/* 1318 */     long[] threadBlock = QueryCache.getBlock(query, 14, this.id, resultFilter.getStartIndex(), true);
/*      */ 
/* 1320 */     int startIndex = resultFilter.getStartIndex();
/*      */     int endIndex;
/*      */     int endIndex;
/* 1324 */     if (resultFilter.getNumResults() == 2147483524) {
/* 1325 */       endIndex = getThreadCount(resultFilter);
/*      */     }
/*      */     else {
/* 1328 */       endIndex = resultFilter.getNumResults() + startIndex;
/*      */     }
/* 1330 */     return new ForumThreadBlockIterator(threadBlock, query, startIndex, endIndex, 14, this.id, FACTORY);
/*      */   }
/*      */ 
/*      */   public Iterator getMessages()
/*      */   {
/* 1335 */     return getMessages(DEFAULT_MESSAGE_FILTER);
/*      */   }
/*      */ 
/*      */   public Iterator getMessages(ResultFilter resultFilter) {
/* 1339 */     CachedPreparedStatement query = getMessageListSQL(resultFilter, false);
/* 1340 */     long[] messageBlock = QueryCache.getBlock(query, 14, this.id, resultFilter.getStartIndex(), true);
/*      */ 
/* 1342 */     int startIndex = resultFilter.getStartIndex();
/*      */     int endIndex;
/*      */     int endIndex;
/* 1346 */     if (resultFilter.getNumResults() == 2147483524) {
/* 1347 */       endIndex = getMessageCount(resultFilter);
/*      */     }
/*      */     else {
/* 1350 */       endIndex = resultFilter.getNumResults() + startIndex;
/*      */     }
/* 1352 */     return new ForumMessageBlockIterator(messageBlock, query, startIndex, endIndex, 14, this.id);
/*      */   }
/*      */ 
/*      */   public int getThreadCount()
/*      */   {
/* 1357 */     return getThreadCount(DEFAULT_THREAD_FILTER);
/*      */   }
/*      */ 
/*      */   public int getThreadCount(ResultFilter resultFilter) {
/* 1361 */     CachedPreparedStatement sql = getThreadListSQL(resultFilter, true);
/* 1362 */     QueryCacheKey key = new QueryCacheKey(14, this.id, sql, -1);
/* 1363 */     return QueryCache.getCount(key, true);
/*      */   }
/*      */ 
/*      */   public int getMessageCount() {
/* 1367 */     return getMessageCount(DEFAULT_MESSAGE_FILTER);
/*      */   }
/*      */ 
/*      */   public int getMessageCount(ResultFilter resultFilter) {
/* 1371 */     CachedPreparedStatement sql = getMessageListSQL(resultFilter, true);
/* 1372 */     QueryCacheKey key = new QueryCacheKey(14, this.id, sql, -1);
/* 1373 */     return QueryCache.getCount(key, true);
/*      */   }
/*      */ 
/*      */   public ForumMessage getLatestMessage()
/*      */   {
/* 1383 */     if (getMessageCount() == 0) {
/* 1384 */       return null;
/*      */     }
/* 1386 */     ResultFilter filter = new ResultFilter();
/* 1387 */     filter.setSortOrder(0);
/* 1388 */     filter.setSortField(9);
/*      */ 
/* 1390 */     filter.setModificationDateRangeMin(ResultFilter.roundDate(this.modificationDate, 86400));
/* 1391 */     filter.setNumResults(1);
/* 1392 */     Iterator messages = getMessages(filter);
/* 1393 */     if (messages.hasNext()) {
/* 1394 */       return (ForumMessage)messages.next();
/*      */     }
/*      */ 
/* 1397 */     return null;
/*      */   }
/*      */ 
/*      */   public PermissionsManager getPermissionsManager()
/*      */   {
/* 1403 */     return null;
/*      */   }
/*      */ 
/*      */   public FilterManager getFilterManager() {
/* 1407 */     if (this.filterManager == null) {
/* 1408 */       this.filterManager = new DbFilterManager(14, this.id);
/* 1409 */       this.filterManager.initialize();
/*      */     }
/* 1411 */     return this.filterManager;
/*      */   }
/*      */ 
/*      */   public InterceptorManager getInterceptorManager() {
/* 1415 */     if (this.interceptorManager == null) {
/* 1416 */       this.interceptorManager = new DbInterceptorManager(14, this.id);
/* 1417 */       this.interceptorManager.initialize();
/*      */     }
/* 1419 */     return this.interceptorManager;
/*      */   }
/*      */ 
/*      */   public Permissions getPermissions(AuthToken authToken) {
/* 1423 */     long userID = authToken.getUserID();
/* 1424 */     Permissions perms = new Permissions(0L);
/* 1425 */     perms.set(FACTORY.getPermissions(authToken).value(), true);
/*      */ 
/* 1428 */     if (this.id != 1L) {
/* 1429 */       long parentID = categoryTree.getParent(this.id);
/* 1430 */       LongList parents = new LongList(getCategoryDepth());
/*      */       do {
/* 1432 */         parents.add(parentID);
/* 1433 */         parentID = categoryTree.getParent(parentID);
/*      */       }
/* 1435 */       while (parentID != -1L);
/*      */ 
/* 1437 */       for (int i = parents.size() - 1; i >= 0; i--) {
/* 1438 */         parentID = parents.get(i);
/*      */ 
/* 1440 */         Permissions p = DbPermissionsManager.getInstance().getFinalUserPerms(14, parentID, userID, PermissionType.NEGATIVE);
/*      */ 
/* 1442 */         perms.set(p.value(), false);
/*      */ 
/* 1445 */         p = DbPermissionsManager.getInstance().getFinalUserPerms(14, parentID, userID, PermissionType.ADDITIVE);
/*      */ 
/* 1447 */         perms.set(p.value(), true);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1452 */     Permissions p = DbPermissionsManager.getInstance().getFinalUserPerms(14, this.id, userID, PermissionType.NEGATIVE);
/*      */ 
/* 1454 */     perms.set(p.value(), false);
/*      */ 
/* 1457 */     p = DbPermissionsManager.getInstance().getFinalUserPerms(14, this.id, userID, PermissionType.ADDITIVE);
/*      */ 
/* 1459 */     perms.set(p.value(), true);
/*      */ 
/* 1461 */     return perms;
/*      */   }
/*      */ 
/*      */   public boolean isAuthorized(long type) {
/* 1465 */     return true;
/*      */   }
/*      */ 
/*      */   public static int getObjectType()
/*      */   {
/* 1471 */     return 14;
/*      */   }
/*      */ 
/*      */   public int getCachedSize()
/*      */   {
/* 1477 */     int size = 0;
/* 1478 */     size += CacheSizes.sizeOfObject();
/* 1479 */     size += CacheSizes.sizeOfObject();
/* 1480 */     size += CacheSizes.sizeOfObject();
/* 1481 */     size += CacheSizes.sizeOfLong();
/* 1482 */     size += CacheSizes.sizeOfString(this.name);
/* 1483 */     size += CacheSizes.sizeOfString(this.description);
/* 1484 */     size += CacheSizes.sizeOfDate() * 2;
/* 1485 */     size += CacheSizes.sizeOfMap(this.properties);
/* 1486 */     size += CacheSizes.sizeOfLong();
/* 1487 */     if (this.popularThreads != null) {
/* 1488 */       size += CacheSizes.sizeOfLong() * this.popularThreads.length;
/*      */     }
/* 1490 */     return size;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1496 */     return this.name;
/*      */   }
/*      */ 
/*      */   public int hashCode() {
/* 1500 */     return (int)this.id;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object object) {
/* 1504 */     if (this == object) {
/* 1505 */       return true;
/*      */     }
/* 1507 */     if ((object != null) && ((object instanceof ExternalizableLite))) {
/* 1508 */       return this.id == ((ExternalizableLite)object).getID();
/*      */     }
/*      */ 
/* 1511 */     return false;
/*      */   }
/*      */ 
/*      */   protected void clearCache()
/*      */   {
/* 1519 */     Profiler.begin("clearCache");
/* 1520 */     FACTORY.cacheManager.queryRemove(14, this.id);
/*      */ 
/* 1523 */     expirePopularThreads();
/* 1524 */     Profiler.end("clearCache");
/*      */   }
/*      */ 
/*      */   private void expirePopularThreads()
/*      */   {
/* 1533 */     long delta = CacheFactory.currentTime - this.popularThreadsTimestamp;
/*      */ 
/* 1535 */     if (delta > 900000L) {
/* 1536 */       this.popularThreadsTimestamp = CacheFactory.currentTime;
/* 1537 */       this.popularThreads = null;
/*      */ 
/* 1539 */       Profiler.begin("expirePopularThreads");
/* 1540 */       FACTORY.cacheManager.categoryCache.put(new Long(this.id), this);
/* 1541 */       Profiler.end("expirePopularThreads");
/*      */     }
/*      */   }
/*      */ 
/*      */   protected CachedPreparedStatement getThreadListSQL(ResultFilter resultFilter, boolean countQuery)
/*      */   {
/* 1551 */     boolean isMysql = ConnectionManager.getDatabaseType() == ConnectionManager.DatabaseType.MYSQL;
/*      */ 
/* 1553 */     int sortField = resultFilter.getSortField();
/*      */ 
/* 1556 */     if ((!countQuery) && (sortField != 9) && (sortField != 8) && (sortField != 5) && ((sortField != 10) || (resultFilter.getSortPropertyName() == null)))
/*      */     {
/* 1565 */       throw new IllegalArgumentException("The specified sort field is not valid.");
/*      */     }
/*      */ 
/* 1568 */     CachedPreparedStatement pstmt = new CachedPreparedStatement();
/* 1569 */     StringBuffer query = new StringBuffer(80);
/* 1570 */     if ((!countQuery) && (!isMysql)) {
/* 1571 */       query.append("SELECT jiveThread.threadID");
/*      */     }
/* 1573 */     else if ((!countQuery) && (isMysql)) {
/* 1574 */       query.append("SELECT STRAIGHT_JOIN jiveThread.threadID");
/*      */     }
/*      */     else {
/* 1577 */       query.append("SELECT count(*)");
/*      */     }
/*      */ 
/* 1580 */     boolean filterUser = resultFilter.getUserID() != 2147483524L;
/* 1581 */     boolean filterCreationDate = (resultFilter.getCreationDateRangeMin() != null) || (resultFilter.getCreationDateRangeMax() != null);
/*      */ 
/* 1583 */     boolean filterModifiedDate = (resultFilter.getModificationDateRangeMin() != null) || (resultFilter.getModificationDateRangeMax() != null);
/*      */ 
/* 1585 */     int propertyCount = resultFilter.getPropertyCount();
/*      */ 
/* 1588 */     if (!countQuery) {
/* 1589 */       switch (sortField) {
/*      */       case 5:
/* 1591 */         query.append(", jiveMessage.subject");
/* 1592 */         break;
/*      */       case 9:
/* 1594 */         query.append(", jiveThread.modificationDate");
/* 1595 */         break;
/*      */       case 8:
/* 1597 */         query.append(", jiveThread.creationDate");
/* 1598 */         break;
/*      */       case 10:
/* 1600 */         query.append(", propTable.propValue");
/*      */       case 6:
/*      */       case 7:
/*      */       }
/*      */     }
/*      */ 
/* 1606 */     if (isMysql)
/*      */     {
/* 1608 */       boolean isForceIndex = false;
/* 1609 */       query.append(" FROM jiveThread");
/* 1610 */       if (!FACTORY.moderationDisabled()) {
/* 1611 */         query.append(" FORCE INDEX (jiveThread_forumID_modVal_idx");
/* 1612 */         isForceIndex = true;
/*      */       }
/* 1614 */       if ((!countQuery) && (sortField == 9)) {
/* 1615 */         if (isForceIndex) {
/* 1616 */           query.append(", ");
/*      */         }
/*      */         else {
/* 1619 */           query.append(" FORCE INDEX (");
/* 1620 */           isForceIndex = true;
/*      */         }
/* 1622 */         query.append("jiveThread_mDate_idx");
/*      */       }
/* 1624 */       else if ((!countQuery) && (sortField == 8)) {
/* 1625 */         if (isForceIndex) {
/* 1626 */           query.append(", ");
/*      */         }
/*      */         else {
/* 1629 */           query.append(" FORCE INDEX (");
/* 1630 */           isForceIndex = true;
/*      */         }
/* 1632 */         query.append("jiveThread_cDate_idx");
/*      */       }
/*      */ 
/* 1635 */       if (isForceIndex) {
/* 1636 */         query.append(")");
/*      */       }
/* 1638 */       query.append(", jiveForum, jiveCategory");
/*      */     }
/*      */     else {
/* 1641 */       query.append(" FROM jiveThread, jiveForum, jiveCategory");
/*      */     }
/*      */ 
/* 1644 */     if ((filterUser) || ((!countQuery) && (resultFilter.getSortField() == 5)))
/*      */     {
/* 1647 */       query.append(", jiveMessage");
/*      */     }
/* 1649 */     for (int i = 0; i < propertyCount; i++) {
/* 1650 */       query.append(", jiveThreadProp p").append(i);
/*      */     }
/* 1652 */     if (resultFilter.getSortField() == 10) {
/* 1653 */       query.append(", jiveThreadProp propTable");
/*      */     }
/*      */ 
/* 1657 */     query.append(" WHERE jiveThread.forumID=jiveForum.forumID ");
/* 1658 */     query.append(" AND jiveForum.categoryID=jiveCategory.categoryID ");
/* 1659 */     int[] lftRgtValues = getLftRgtValues(this.id);
/* 1660 */     query.append(" AND jiveCategory.lft >= ?");
/* 1661 */     pstmt.addInt(lftRgtValues[0]);
/* 1662 */     query.append(" AND jiveCategory.rgt <= ?");
/* 1663 */     pstmt.addInt(lftRgtValues[1]);
/*      */ 
/* 1665 */     if ((filterUser) || ((!countQuery) && (sortField == 5))) {
/* 1666 */       query.append(" AND jiveThread.threadID=jiveMessage.threadID");
/* 1667 */       query.append(" AND jiveMessage.parentMessageID IS NULL");
/*      */     }
/* 1669 */     if (filterUser) {
/* 1670 */       query.append(" AND jiveMessage.userID=?");
/* 1671 */       pstmt.addLong(resultFilter.getUserID());
/*      */     }
/*      */ 
/* 1674 */     for (int i = 0; i < propertyCount; i++) {
/* 1675 */       query.append(" AND jiveThread.threadID=p").append(i).append(".threadID");
/* 1676 */       query.append(" AND p").append(i).append(".name=?");
/* 1677 */       pstmt.addString(resultFilter.getPropertyName(i));
/* 1678 */       query.append(" AND p").append(i).append(".propValue=?");
/* 1679 */       pstmt.addString(resultFilter.getPropertyValue(i));
/*      */     }
/*      */ 
/* 1682 */     if ((!countQuery) && (sortField == 5)) {
/* 1683 */       query.append(" AND jiveThread.threadID=jiveMessage.threadID");
/*      */     }
/*      */ 
/* 1686 */     if (sortField == 10) {
/* 1687 */       query.append(" AND jiveThread.threadID=propTable.threadID");
/* 1688 */       query.append(" AND propTable.name=?");
/* 1689 */       pstmt.addString(resultFilter.getSortPropertyName());
/*      */     }
/*      */ 
/* 1693 */     if (filterCreationDate) {
/* 1694 */       if (resultFilter.getCreationDateRangeMin() != null) {
/* 1695 */         query.append(" AND jiveThread.creationDate >= ?");
/* 1696 */         pstmt.addLong(resultFilter.getCreationDateRangeMin().getTime());
/*      */       }
/* 1698 */       if (resultFilter.getCreationDateRangeMax() != null) {
/* 1699 */         query.append(" AND jiveThread.creationDate <= ?");
/* 1700 */         pstmt.addLong(resultFilter.getCreationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1705 */     if (filterModifiedDate) {
/* 1706 */       if (resultFilter.getModificationDateRangeMin() != null) {
/* 1707 */         query.append(" AND jiveThread.modificationDate >= ?");
/* 1708 */         pstmt.addLong(resultFilter.getModificationDateRangeMin().getTime());
/*      */       }
/* 1710 */       if (resultFilter.getModificationDateRangeMax() != null) {
/* 1711 */         query.append(" AND jiveThread.modificationDate <= ");
/* 1712 */         pstmt.addLong(resultFilter.getModificationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1718 */     if (!FACTORY.moderationDisabled()) {
/* 1719 */       int moderationRangeMin = resultFilter.getModerationRangeMin();
/* 1720 */       if (moderationRangeMin == 2147483524) {
/* 1721 */         moderationRangeMin = 1;
/*      */       }
/* 1723 */       int moderationRangeMax = resultFilter.getModerationRangeMax();
/* 1724 */       if (moderationRangeMin == moderationRangeMax) {
/* 1725 */         query.append(" AND jiveThread.modValue = ?");
/* 1726 */         pstmt.addInt(moderationRangeMin);
/*      */       }
/*      */       else
/*      */       {
/* 1730 */         if (moderationRangeMin > -1000000) {
/* 1731 */           query.append(" AND jiveThread.modValue >= ?");
/* 1732 */           pstmt.addInt(moderationRangeMin);
/*      */         }
/*      */ 
/* 1735 */         if (moderationRangeMax != 2147483524) {
/* 1736 */           query.append(" AND jiveThread.modValue <= ?");
/* 1737 */           pstmt.addInt(moderationRangeMax);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1743 */     if (!countQuery) {
/* 1744 */       switch (sortField) {
/*      */       case 5:
/* 1746 */         query.append(" ORDER BY jiveMessage.subject");
/* 1747 */         break;
/*      */       case 9:
/* 1749 */         query.append(" ORDER BY jiveThread.modificationDate");
/* 1750 */         break;
/*      */       case 8:
/* 1752 */         query.append(" ORDER BY jiveThread.creationDate");
/* 1753 */         break;
/*      */       case 10:
/* 1755 */         query.append(" ORDER BY propTable.propValue");
/*      */       case 6:
/*      */       case 7:
/* 1758 */       }if (resultFilter.getSortOrder() == 0) {
/* 1759 */         query.append(" DESC");
/*      */       }
/*      */       else {
/* 1762 */         query.append(" ASC");
/*      */       }
/*      */     }
/*      */ 
/* 1766 */     pstmt.setSQL(query.toString());
/* 1767 */     return pstmt;
/*      */   }
/*      */ 
/*      */   protected CachedPreparedStatement getMessageListSQL(ResultFilter resultFilter, boolean countQuery)
/*      */   {
/* 1776 */     boolean isMysql = ConnectionManager.getDatabaseType() == ConnectionManager.DatabaseType.MYSQL;
/* 1777 */     int sortField = resultFilter.getSortField();
/*      */ 
/* 1780 */     if ((!countQuery) && (sortField != 9) && (sortField != 8) && (sortField != 6) && ((sortField != 10) || (resultFilter.getSortPropertyName() == null)))
/*      */     {
/* 1789 */       throw new IllegalArgumentException("The specified sort field is not valid.");
/*      */     }
/*      */ 
/* 1793 */     CachedPreparedStatement pstmt = new CachedPreparedStatement();
/* 1794 */     StringBuffer query = new StringBuffer(80);
/* 1795 */     if ((!countQuery) && (isMysql) && (this.id != 1L)) {
/* 1796 */       query.append("SELECT STRAIGHT_JOIN jiveMessage.messageID");
/*      */     }
/* 1798 */     else if (!countQuery) {
/* 1799 */       query.append("SELECT jiveMessage.messageID");
/*      */     }
/*      */     else {
/* 1802 */       query.append("SELECT count(*)");
/*      */     }
/*      */ 
/* 1805 */     boolean filterUser = resultFilter.getUserID() != 2147483524L;
/* 1806 */     boolean filterCreationDate = (resultFilter.getCreationDateRangeMin() != null) || (resultFilter.getCreationDateRangeMax() != null);
/*      */ 
/* 1808 */     boolean filterModifiedDate = (resultFilter.getModificationDateRangeMin() != null) || (resultFilter.getModificationDateRangeMax() != null);
/*      */ 
/* 1810 */     int propertyCount = resultFilter.getPropertyCount();
/*      */ 
/* 1813 */     if (!countQuery) {
/* 1814 */       switch (sortField) {
/*      */       case 6:
/* 1816 */         query.append(", subject");
/* 1817 */         break;
/*      */       case 9:
/* 1819 */         query.append(", jiveMessage.modificationDate");
/* 1820 */         break;
/*      */       case 8:
/* 1822 */         query.append(", jiveMessage.creationDate");
/* 1823 */         break;
/*      */       case 10:
/* 1825 */         query.append(", propTable.propValue");
/*      */       case 7:
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1831 */     if ((isMysql) && (this.id != 1L))
/*      */     {
/* 1833 */       boolean isForceIndex = false;
/* 1834 */       query.append(" FROM jiveMessage");
/* 1835 */       if (!FACTORY.moderationDisabled()) {
/* 1836 */         query.append(" FORCE INDEX (jiveMessage_forumID_modVal_idx");
/* 1837 */         isForceIndex = true;
/*      */       }
/* 1839 */       if ((!countQuery) && (sortField == 9)) {
/* 1840 */         if (isForceIndex) {
/* 1841 */           query.append(", ");
/*      */         }
/*      */         else {
/* 1844 */           query.append(" FORCE INDEX (");
/* 1845 */           isForceIndex = true;
/*      */         }
/* 1847 */         query.append("jiveMessage_mDate_idx");
/*      */       }
/* 1849 */       else if ((!countQuery) && (sortField == 8)) {
/* 1850 */         if (isForceIndex) {
/* 1851 */           query.append(", ");
/*      */         }
/*      */         else {
/* 1854 */           query.append(" FORCE INDEX (");
/* 1855 */           isForceIndex = true;
/*      */         }
/* 1857 */         query.append("jiveMessage_cDate_idx");
/*      */       }
/* 1859 */       if (isForceIndex) {
/* 1860 */         query.append(")");
/*      */       }
/* 1862 */       query.append(", jiveForum, jiveCategory");
/*      */     }
/* 1867 */     else if (this.id != 1L) {
/* 1868 */       query.append(" FROM jiveMessage, jiveForum, jiveCategory");
/*      */     }
/*      */     else {
/* 1871 */       query.append(" FROM jiveMessage");
/*      */     }
/*      */ 
/* 1875 */     for (int i = 0; i < propertyCount; i++) {
/* 1876 */       query.append(", jiveMessageProp p").append(i);
/*      */     }
/* 1878 */     if (resultFilter.getSortField() == 10) {
/* 1879 */       query.append(", jiveMessageProp propTable");
/*      */     }
/*      */ 
/* 1886 */     if (this.id == 1L) {
/* 1887 */       query.append(" WHERE 1=1");
/*      */     }
/*      */     else {
/* 1890 */       query.append(" WHERE jiveMessage.forumID=jiveForum.forumID ");
/* 1891 */       query.append(" AND jiveForum.categoryID=jiveCategory.categoryID ");
/* 1892 */       int[] lftRgtValues = getLftRgtValues(this.id);
/* 1893 */       query.append(" AND jiveCategory.lft >= ?");
/* 1894 */       pstmt.addInt(lftRgtValues[0]);
/* 1895 */       query.append(" AND jiveCategory.rgt <= ?");
/* 1896 */       pstmt.addInt(lftRgtValues[1]);
/*      */     }
/*      */ 
/* 1900 */     if (filterUser) {
/* 1901 */       query.append(" AND userID=?");
/* 1902 */       pstmt.addLong(resultFilter.getUserID());
/*      */     }
/*      */ 
/* 1905 */     for (int i = 0; i < propertyCount; i++) {
/* 1906 */       query.append(" AND jiveMessage.messageID=p").append(i).append(".messageID");
/* 1907 */       query.append(" AND p").append(i).append(".name=?");
/* 1908 */       pstmt.addString(resultFilter.getPropertyName(i));
/* 1909 */       query.append(" AND p").append(i).append(".propValue=?");
/* 1910 */       pstmt.addString(resultFilter.getPropertyValue(i));
/*      */     }
/*      */ 
/* 1913 */     if (sortField == 10) {
/* 1914 */       query.append(" AND jiveMessage.messageID=propTable.messageID");
/* 1915 */       query.append(" AND propTable.name=?");
/* 1916 */       pstmt.addString(resultFilter.getSortPropertyName());
/*      */     }
/*      */ 
/* 1920 */     if (filterCreationDate) {
/* 1921 */       if (resultFilter.getCreationDateRangeMin() != null) {
/* 1922 */         query.append(" AND jiveMessage.creationDate >= ?");
/* 1923 */         pstmt.addLong(resultFilter.getCreationDateRangeMin().getTime());
/*      */       }
/* 1925 */       if (resultFilter.getCreationDateRangeMax() != null) {
/* 1926 */         query.append(" AND jiveMessage.creationDate <= ?");
/* 1927 */         pstmt.addLong(resultFilter.getCreationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1932 */     if (filterModifiedDate) {
/* 1933 */       if (resultFilter.getModificationDateRangeMin() != null) {
/* 1934 */         query.append(" AND jiveMessage.modificationDate >= ?");
/* 1935 */         pstmt.addLong(resultFilter.getModificationDateRangeMin().getTime());
/*      */       }
/* 1937 */       if (resultFilter.getModificationDateRangeMax() != null) {
/* 1938 */         query.append(" AND jiveMessage.modificationDate <= ?");
/* 1939 */         pstmt.addLong(resultFilter.getModificationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1945 */     if (!FACTORY.moderationDisabled()) {
/* 1946 */       int moderationRangeMin = resultFilter.getModerationRangeMin();
/*      */ 
/* 1949 */       if (moderationRangeMin == 2147483524) {
/* 1950 */         moderationRangeMin = 1;
/*      */       }
/* 1952 */       int moderationRangeMax = resultFilter.getModerationRangeMax();
/* 1953 */       if (moderationRangeMin == moderationRangeMax) {
/* 1954 */         query.append(" AND modValue = ?");
/* 1955 */         pstmt.addInt(moderationRangeMin);
/*      */       }
/*      */       else
/*      */       {
/* 1959 */         if (moderationRangeMin > -1000000) {
/* 1960 */           query.append(" AND modValue >= ?");
/* 1961 */           pstmt.addInt(moderationRangeMin);
/*      */         }
/*      */ 
/* 1964 */         if (moderationRangeMax != 2147483524) {
/* 1965 */           query.append(" AND modValue <= ?");
/* 1966 */           pstmt.addInt(moderationRangeMax);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1972 */     if (!countQuery) {
/* 1973 */       switch (sortField) {
/*      */       case 6:
/* 1975 */         query.append(" ORDER BY subject");
/* 1976 */         break;
/*      */       case 9:
/* 1978 */         query.append(" ORDER BY jiveMessage.modificationDate");
/* 1979 */         break;
/*      */       case 8:
/* 1981 */         query.append(" ORDER BY jiveMessage.creationDate");
/* 1982 */         break;
/*      */       case 10:
/* 1984 */         query.append(" ORDER BY propTable.propValue");
/*      */       case 7:
/*      */       }
/* 1987 */       if (resultFilter.getSortOrder() == 0) {
/* 1988 */         query.append(" DESC");
/*      */       }
/*      */       else {
/* 1991 */         query.append(" ASC");
/*      */       }
/*      */     }
/*      */ 
/* 1995 */     pstmt.setSQL(query.toString());
/* 1996 */     return pstmt;
/*      */   }
/*      */ 
/*      */   static void setCategoryTree(LongTree tree)
/*      */   {
/* 2008 */     synchronized (lock) {
/* 2009 */       categoryTree = tree;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void refreshCategoryTree(boolean startup)
/*      */   {
/* 2022 */     synchronized (lock) {
/* 2023 */       Map lftRgtMap = new HashMap();
/*      */ 
/* 2025 */       Connection con = null;
/* 2026 */       PreparedStatement pstmt = null;
/*      */       try {
/* 2028 */         con = ConnectionManager.getConnection();
/* 2029 */         pstmt = con.prepareStatement("SELECT count(*) FROM jiveCategory");
/* 2030 */         ResultSet rs = pstmt.executeQuery();
/* 2031 */         rs.next();
/* 2032 */         int categoryCount = rs.getInt(1);
/* 2033 */         rs.close();
/* 2034 */         pstmt.close();
/* 2035 */         categoryTree = new LongTree(1L, categoryCount);
/*      */ 
/* 2038 */         pstmt = con.prepareStatement("SELECT categoryID, lft, rgt FROM jiveCategory ORDER BY lft ASC");
/* 2039 */         rs = pstmt.executeQuery();
/* 2040 */         rs.next();
/*      */ 
/* 2042 */         long categoryID = rs.getLong(1);
/* 2043 */         int lft = rs.getInt(2);
/* 2044 */         int rgt = rs.getInt(3);
/*      */ 
/* 2046 */         lftRgtMap.put(new Long(categoryID), new int[] { lft, rgt });
/*      */ 
/* 2052 */         LinkedList categoryStack = new LinkedList();
/* 2053 */         categoryStack.addFirst(new Long(1L));
/* 2054 */         LinkedList lftStack = new LinkedList();
/* 2055 */         lftStack.addFirst(new Integer(rs.getInt(2)));
/* 2056 */         LinkedList rgtStack = new LinkedList();
/* 2057 */         rgtStack.addFirst(new Integer(rs.getInt(3)));
/*      */ 
/* 2059 */         while (rs.next()) {
/* 2060 */           categoryID = rs.getLong(1);
/* 2061 */           lft = rs.getInt(2);
/* 2062 */           rgt = rs.getInt(3);
/*      */ 
/* 2064 */           lftRgtMap.put(new Long(categoryID), new int[] { lft, rgt });
/*      */ 
/* 2066 */           int stackLft = ((Integer)lftStack.getFirst()).intValue();
/* 2067 */           int stackRgt = ((Integer)rgtStack.getFirst()).intValue();
/*      */ 
/* 2075 */           while ((lft <= stackLft) || (rgt >= stackRgt))
/*      */           {
/* 2077 */             categoryStack.removeFirst();
/* 2078 */             lftStack.removeFirst();
/* 2079 */             rgtStack.removeFirst();
/* 2080 */             stackLft = ((Integer)lftStack.getFirst()).intValue();
/* 2081 */             stackRgt = ((Integer)rgtStack.getFirst()).intValue();
/*      */           }
/*      */ 
/* 2084 */           long parent = ((Long)categoryStack.getFirst()).longValue();
/* 2085 */           categoryTree.addChild(parent, categoryID);
/*      */ 
/* 2087 */           categoryStack.addFirst(new Long(categoryID));
/* 2088 */           lftStack.addFirst(new Integer(lft));
/* 2089 */           rgtStack.addFirst(new Integer(rgt));
/*      */         }
/* 2091 */         rs.close();
/*      */       }
/*      */       catch (SQLException sqle) {
/* 2094 */         Log.error(sqle);
/*      */       }
/*      */       finally {
/* 2097 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*      */ 
/* 2102 */       if ((!startup) || (lftRgtCache.isEmpty()))
/*      */       {
/*      */         Iterator i;
/* 2111 */         synchronized (lftRgtCache)
/*      */         {
/* 2114 */           for (i = lftRgtMap.keySet().iterator(); i.hasNext(); ) {
/* 2115 */             Object key = i.next();
/* 2116 */             Object value = lftRgtMap.get(key);
/* 2117 */             lftRgtCache.put(key, value);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2122 */         CacheFactory.doSynchronousClusterTask(new PushCategoryTreeClusterTask(categoryTree), false);
/*      */ 
/* 2125 */         FACTORY.cacheManager.queryCache.clear();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void updateModifiedDate(long date, Connection con)
/*      */     throws SQLException
/*      */   {
/* 2136 */     if (!ENABLE_DATE_UPDATES) {
/* 2137 */       return;
/*      */     }
/*      */ 
/* 2140 */     if (date > this.modificationDate.getTime()) {
/* 2141 */       this.modificationDate.setTime(date);
/* 2142 */       PreparedStatement pstmt = null;
/*      */       try {
/* 2144 */         pstmt = con.prepareStatement("UPDATE jiveCategory SET modificationDate=? WHERE lft<=? AND rgt>=?");
/* 2145 */         pstmt.setLong(1, this.modificationDate.getTime());
/* 2146 */         int[] lftRgtValues = getLftRgtValues(this.id);
/* 2147 */         pstmt.setInt(2, lftRgtValues[0]);
/* 2148 */         pstmt.setInt(3, lftRgtValues[1]);
/* 2149 */         pstmt.executeUpdate();
/*      */       }
/*      */       finally {
/* 2152 */         ConnectionManager.closePreparedStatement(pstmt);
/*      */       }
/* 2154 */       FACTORY.cacheManager.categoryCache.put(new Long(this.id), this);
/*      */ 
/* 2158 */       DbForumCategory parentCategory = (DbForumCategory)getParentCategory();
/* 2159 */       if (parentCategory != null)
/* 2160 */         parentCategory.updateModifiedDate(date, con);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected CachedPreparedStatement getForumListSQL(ResultFilter resultFilter, boolean countQuery, boolean recursiveQuery)
/*      */   {
/* 2176 */     int sortField = resultFilter.getSortField();
/*      */ 
/* 2179 */     if ((!countQuery) && (sortField != 9) && (sortField != 8) && (sortField != 15) && (sortField != 16) && ((sortField != 10) || (resultFilter.getSortPropertyName() == null)))
/*      */     {
/* 2189 */       throw new IllegalArgumentException("The specified sort field is not valid.");
/*      */     }
/*      */ 
/* 2192 */     CachedPreparedStatement pstmt = new CachedPreparedStatement();
/* 2193 */     StringBuffer query = new StringBuffer(80);
/* 2194 */     if (!countQuery) {
/* 2195 */       query.append("SELECT jiveForum.forumID");
/*      */     }
/*      */     else {
/* 2198 */       query.append("SELECT count(*)");
/*      */     }
/*      */ 
/* 2201 */     boolean filterCreationDate = (resultFilter.getCreationDateRangeMin() != null) || (resultFilter.getCreationDateRangeMax() != null);
/*      */ 
/* 2203 */     boolean filterModifiedDate = (resultFilter.getModificationDateRangeMin() != null) || (resultFilter.getModificationDateRangeMax() != null);
/*      */ 
/* 2205 */     int propertyCount = resultFilter.getPropertyCount();
/*      */ 
/* 2208 */     if (!countQuery)
/* 2209 */       switch (sortField) {
/*      */       case 16:
/* 2211 */         query.append(", jiveForum.name");
/* 2212 */         break;
/*      */       case 15:
/* 2214 */         query.append(", jiveForum.categoryIndex");
/* 2215 */         if (recursiveQuery)
/* 2216 */           query.append(", jiveForum.categoryID");
/* 2217 */         break;
/*      */       case 9:
/* 2220 */         query.append(", jiveForum.modificationDate");
/* 2221 */         break;
/*      */       case 8:
/* 2223 */         query.append(", jiveForum.creationDate");
/* 2224 */         break;
/*      */       case 10:
/* 2226 */         query.append(", propTable.propValue");
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*      */       }
/* 2232 */     query.append(" FROM jiveForum");
/* 2233 */     for (int i = 0; i < propertyCount; i++) {
/* 2234 */       query.append(", jiveForumProp p").append(i);
/*      */     }
/* 2236 */     if (resultFilter.getSortField() == 10)
/*      */     {
/* 2238 */       query.append(", jiveForumProp propTable");
/*      */     }
/* 2240 */     if (recursiveQuery) {
/* 2241 */       query.append(", jiveCategory");
/*      */     }
/*      */ 
/* 2245 */     if (!recursiveQuery) {
/* 2246 */       query.append(" WHERE jiveForum.categoryID=?");
/* 2247 */       pstmt.addLong(this.id);
/*      */     }
/*      */     else {
/* 2250 */       query.append(" WHERE jiveForum.categoryID=jiveCategory.categoryID");
/* 2251 */       int[] lftRgtValues = getLftRgtValues(this.id);
/* 2252 */       query.append(" AND lft >= ?");
/* 2253 */       pstmt.addInt(lftRgtValues[0]);
/* 2254 */       query.append(" AND rgt <= ?");
/* 2255 */       pstmt.addInt(lftRgtValues[1]);
/*      */     }
/*      */ 
/* 2258 */     for (int i = 0; i < propertyCount; i++) {
/* 2259 */       query.append(" AND jiveForum.forumID=p").append(i).append(".forumID");
/* 2260 */       query.append(" AND p").append(i).append(".name=?");
/* 2261 */       pstmt.addString(resultFilter.getPropertyName(i));
/* 2262 */       query.append(" AND p").append(i).append(".propValue=?");
/* 2263 */       pstmt.addString(resultFilter.getPropertyValue(i));
/*      */     }
/*      */ 
/* 2266 */     if (sortField == 10) {
/* 2267 */       query.append(" AND jiveForum.forumID=propTable.forumID");
/* 2268 */       query.append(" AND propTable.name=?");
/* 2269 */       pstmt.addString(resultFilter.getSortPropertyName());
/*      */     }
/*      */ 
/* 2273 */     if (filterCreationDate) {
/* 2274 */       if (resultFilter.getCreationDateRangeMin() != null) {
/* 2275 */         query.append(" AND jiveForum.creationDate >= ?");
/* 2276 */         pstmt.addLong(resultFilter.getCreationDateRangeMin().getTime());
/*      */       }
/* 2278 */       if (resultFilter.getCreationDateRangeMax() != null) {
/* 2279 */         query.append(" AND jiveForum.creationDate <= ?");
/* 2280 */         pstmt.addLong(resultFilter.getCreationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2285 */     if (filterModifiedDate) {
/* 2286 */       if (resultFilter.getModificationDateRangeMin() != null) {
/* 2287 */         query.append(" AND jiveForum.modificationDate >= ?");
/* 2288 */         pstmt.addLong(resultFilter.getModificationDateRangeMin().getTime());
/*      */       }
/* 2290 */       if (resultFilter.getModificationDateRangeMax() != null) {
/* 2291 */         query.append(" AND jiveForum.modificationDate <= ?");
/* 2292 */         pstmt.addLong(resultFilter.getModificationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2297 */     if (!countQuery) {
/* 2298 */       switch (sortField) {
/*      */       case 15:
/* 2300 */         if (recursiveQuery) {
/* 2301 */           query.append(" ORDER BY jiveForum.categoryID, jiveForum.categoryIndex");
/*      */         }
/*      */         else {
/* 2304 */           query.append(" ORDER BY jiveForum.categoryIndex");
/*      */         }
/* 2306 */         break;
/*      */       case 16:
/* 2308 */         query.append(" ORDER BY jiveForum.name");
/* 2309 */         break;
/*      */       case 9:
/* 2311 */         query.append(" ORDER BY jiveForum.modificationDate");
/* 2312 */         break;
/*      */       case 8:
/* 2314 */         query.append(" ORDER BY jiveForum.creationDate");
/* 2315 */         break;
/*      */       case 10:
/* 2317 */         query.append(" ORDER BY propTable.propValue");
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/* 2320 */       case 14: } if (resultFilter.getSortOrder() == 0) {
/* 2321 */         query.append(" DESC");
/*      */       }
/*      */       else {
/* 2324 */         query.append(" ASC");
/*      */       }
/*      */     }
/*      */ 
/* 2328 */     pstmt.setSQL(query.toString());
/* 2329 */     return pstmt;
/*      */   }
/*      */ 
/*      */   public static int[] getLftRgtValues(long categoryID)
/*      */   {
/* 2339 */     int[] lftRgtValues = null;
/* 2340 */     synchronized (lftRgtCache) {
/* 2341 */       lftRgtValues = (int[])lftRgtCache.get(new Long(categoryID));
/* 2342 */       if (lftRgtValues == null) {
/* 2343 */         Log.warn("LftRgt cache returned null for categoryID " + categoryID + ". Refreshing LftRgt cache.");
/*      */ 
/* 2345 */         refreshCategoryTree(false);
/* 2346 */         lftRgtValues = (int[])lftRgtCache.get(new Long(categoryID));
/*      */       }
/*      */     }
/* 2349 */     return lftRgtValues;
/*      */   }
/*      */ 
/*      */   private void insertPropertyIntoDb(String name, String value)
/*      */   {
/* 2356 */     Connection con = null;
/* 2357 */     PreparedStatement pstmt = null;
/* 2358 */     boolean abortTransaction = false;
/*      */     try {
/* 2360 */       con = ConnectionManager.getTransactionConnection();
/* 2361 */       pstmt = con.prepareStatement("INSERT INTO jiveCategoryProp(categoryID,name,propValue) VALUES(?,?,?)");
/* 2362 */       pstmt.setLong(1, this.id);
/* 2363 */       pstmt.setString(2, name);
/* 2364 */       pstmt.setString(3, value);
/* 2365 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 2368 */       Log.error(sqle);
/* 2369 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/* 2372 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void updatePropertyInDb(String name, String value)
/*      */   {
/* 2380 */     Connection con = null;
/* 2381 */     PreparedStatement pstmt = null;
/* 2382 */     boolean abortTransaction = false;
/*      */     try {
/* 2384 */       con = ConnectionManager.getTransactionConnection();
/* 2385 */       pstmt = con.prepareStatement("UPDATE jiveCategoryProp SET propValue=? WHERE name=? AND categoryID=?");
/* 2386 */       pstmt.setString(1, value);
/* 2387 */       pstmt.setString(2, name);
/* 2388 */       pstmt.setLong(3, this.id);
/* 2389 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 2392 */       Log.error(sqle);
/* 2393 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/* 2396 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void deletePropertyFromDb(String name)
/*      */   {
/* 2404 */     Connection con = null;
/* 2405 */     PreparedStatement pstmt = null;
/* 2406 */     boolean abortTransaction = false;
/*      */     try {
/* 2408 */       con = ConnectionManager.getTransactionConnection();
/* 2409 */       pstmt = con.prepareStatement("DELETE FROM jiveCategoryProp WHERE categoryID=? AND name=?");
/* 2410 */       pstmt.setLong(1, this.id);
/* 2411 */       pstmt.setString(2, name);
/* 2412 */       pstmt.execute();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 2415 */       Log.error(sqle);
/* 2416 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/* 2419 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void insertIntoDb(DbForumCategory parentCategory)
/*      */   {
/* 2427 */     Connection con = null;
/* 2428 */     PreparedStatement pstmt = null;
/* 2429 */     boolean abortTransaction = false;
/*      */     try {
/* 2431 */       con = ConnectionManager.getTransactionConnection();
/*      */ 
/* 2433 */       pstmt = con.prepareStatement("SELECT lft, rgt FROM jiveCategory WHERE categoryID=?");
/* 2434 */       pstmt.setLong(1, parentCategory.getID());
/* 2435 */       ResultSet rs = pstmt.executeQuery();
/* 2436 */       rs.next();
/* 2437 */       int parentLft = rs.getInt(1);
/* 2438 */       int parentRgt = rs.getInt(2);
/* 2439 */       rs.close();
/* 2440 */       pstmt.close();
/*      */ 
/* 2443 */       pstmt = con.prepareStatement("UPDATE jiveCategory SET lft=lft+? WHERE lft > ? AND rgt > ?");
/* 2444 */       pstmt.setInt(1, 2);
/* 2445 */       pstmt.setInt(2, parentLft);
/* 2446 */       pstmt.setInt(3, parentRgt);
/* 2447 */       pstmt.execute();
/* 2448 */       pstmt.close();
/* 2449 */       pstmt = con.prepareStatement("UPDATE jiveCategory SET rgt=rgt+? WHERE rgt >= ?");
/* 2450 */       pstmt.setInt(1, 2);
/* 2451 */       pstmt.setInt(2, parentRgt);
/* 2452 */       pstmt.execute();
/* 2453 */       pstmt.close();
/*      */ 
/* 2456 */       int lft = parentRgt;
/* 2457 */       int rgt = parentRgt + 1;
/* 2458 */       pstmt = con.prepareStatement("INSERT INTO jiveCategory(categoryID,name,description,creationDate,modificationDate,lft,rgt) VALUES (?,?,?,?,?,?,?)");
/* 2459 */       pstmt.setLong(1, this.id);
/* 2460 */       pstmt.setString(2, this.name);
/* 2461 */       pstmt.setString(3, this.description);
/* 2462 */       pstmt.setLong(4, this.creationDate.getTime());
/* 2463 */       pstmt.setLong(5, this.modificationDate.getTime());
/* 2464 */       pstmt.setInt(6, lft);
/* 2465 */       pstmt.setInt(7, rgt);
/* 2466 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 2469 */       Log.error(sqle);
/* 2470 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/* 2473 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void saveToDb()
/*      */   {
/* 2481 */     Connection con = null;
/* 2482 */     PreparedStatement pstmt = null;
/*      */     try {
/* 2484 */       con = ConnectionManager.getConnection();
/* 2485 */       pstmt = con.prepareStatement("UPDATE jiveCategory SET name=?, description=?, creationDate=?, modificationDate=? WHERE categoryID=?");
/* 2486 */       pstmt.setString(1, this.name);
/* 2487 */       pstmt.setString(2, this.description);
/* 2488 */       pstmt.setLong(3, this.creationDate.getTime());
/* 2489 */       pstmt.setLong(4, this.modificationDate.getTime());
/* 2490 */       pstmt.setLong(5, this.id);
/* 2491 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 2494 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/* 2497 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void loadFromDb()
/*      */     throws ForumCategoryNotFoundException
/*      */   {
/* 2507 */     Connection con = null;
/*      */     try {
/* 2509 */       con = ConnectionManager.getConnection();
/* 2510 */       loadFromDb(con);
/*      */     }
/*      */     catch (SQLException e) {
/* 2513 */       Log.error(e);
/*      */     }
/*      */     finally {
/* 2516 */       ConnectionManager.closeConnection(con);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void loadFromDb(Connection con) throws ForumCategoryNotFoundException {
/* 2521 */     PreparedStatement pstmt = null;
/*      */     try {
/* 2523 */       pstmt = con.prepareStatement("SELECT name, description, creationDate, modificationDate FROM jiveCategory WHERE categoryID=?");
/* 2524 */       pstmt.setLong(1, this.id);
/* 2525 */       ResultSet rs = pstmt.executeQuery();
/* 2526 */       if (!rs.next()) {
/* 2527 */         rs.close();
/* 2528 */         throw new ForumCategoryNotFoundException("Category " + this.id + " could not be loaded.", this.id);
/*      */       }
/*      */ 
/* 2531 */       this.name = rs.getString(1);
/* 2532 */       this.description = rs.getString(2);
/* 2533 */       this.creationDate = new Date(rs.getLong(3));
/* 2534 */       this.modificationDate = new Date(rs.getLong(4));
/* 2535 */       rs.close();
/* 2536 */       pstmt.close();
/*      */ 
/* 2539 */       this.properties = new Hashtable();
/* 2540 */       pstmt = con.prepareStatement("SELECT name, propValue FROM jiveCategoryProp WHERE categoryID=?");
/* 2541 */       pstmt.setLong(1, this.id);
/* 2542 */       rs = pstmt.executeQuery();
/* 2543 */       while (rs.next()) {
/* 2544 */         String name = rs.getString(1);
/* 2545 */         String value = rs.getString(2);
/* 2546 */         this.properties.put(name, value);
/*      */       }
/* 2548 */       rs.close();
/*      */     }
/*      */     catch (SQLException sqle)
/*      */     {
/* 2552 */       throw new ForumCategoryNotFoundException("Category " + this.id + " could not be loaded.", this.id);
/*      */     }
/*      */     finally {
/* 2555 */       ConnectionManager.closePreparedStatement(pstmt);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void deleteFromDb(Connection con) throws SQLException
/*      */   {
/* 2561 */     for (Iterator i = getCategories(); i.hasNext(); ) {
/* 2562 */       DbForumCategory category = (DbForumCategory)i.next();
/* 2563 */       category.deleteFromDb(con);
/*      */     }
/*      */ 
/* 2566 */     for (Iterator i = getForums(); i.hasNext(); ) {
/* 2567 */       DbForum forum = (DbForum)i.next();
/*      */       try {
/* 2569 */         FACTORY.deleteForum(forum);
/*      */       }
/*      */       catch (UnauthorizedException ue) {
/* 2572 */         Log.error(ue);
/*      */       }
/*      */     }
/*      */ 
/* 2576 */     PreparedStatement pstmt = null;
/*      */     try {
/* 2578 */       pstmt = con.prepareStatement("DELETE FROM jiveCategoryProp WHERE categoryID=?");
/* 2579 */       pstmt.setLong(1, this.id);
/* 2580 */       pstmt.execute();
/*      */     }
/*      */     finally {
/* 2583 */       ConnectionManager.closePreparedStatement(pstmt);
/*      */     }
/*      */     try
/*      */     {
/* 2587 */       pstmt = con.prepareStatement("DELETE FROM jiveCategory WHERE categoryID=?");
/* 2588 */       pstmt.setLong(1, this.id);
/* 2589 */       pstmt.execute();
/*      */     }
/*      */     finally {
/* 2592 */       ConnectionManager.closePreparedStatement(pstmt);
/*      */     }
/* 2594 */     FACTORY.cacheManager.categoryCache.remove(new Long(this.id));
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbForumCategory
 * JD-Core Version:    0.6.2
 */
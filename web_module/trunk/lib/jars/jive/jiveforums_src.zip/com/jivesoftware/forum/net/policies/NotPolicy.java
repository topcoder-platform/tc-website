/*    */ package com.jivesoftware.forum.net.policies;
/*    */ 
/*    */ import com.jivesoftware.forum.net.AcceptPolicy;
/*    */ import com.jivesoftware.forum.net.Connection;
/*    */ 
/*    */ public class NotPolicy
/*    */   implements AcceptPolicy
/*    */ {
/*    */   private AcceptPolicy pol;
/*    */ 
/*    */   public NotPolicy(AcceptPolicy policy)
/*    */   {
/* 36 */     this.pol = policy;
/*    */   }
/*    */ 
/*    */   public boolean evaluate(Connection connection)
/*    */   {
/* 46 */     return !this.pol.evaluate(connection);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.policies.NotPolicy
 * JD-Core Version:    0.6.2
 */
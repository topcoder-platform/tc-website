/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.Question.State;
/*     */ import com.jivesoftware.forum.QuestionFilter;
/*     */ import com.jivesoftware.forum.QuestionManager;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.action.util.Pageable;
/*     */ import com.jivesoftware.forum.action.util.Paginator;
/*     */ import com.opensymphony.xwork.Preparable;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class MyQuestionsAction extends ForumActionSupport
/*     */   implements Preparable
/*     */ {
/*     */   public static final int DEFAULT_UNRESOLVED_RANGE = 5;
/*     */   public static final int DEFAULT_RESOLVED_RANGE = 5;
/*     */   private QuestionManager qman;
/*     */   private Iterator unresolvedQuestions;
/*     */   private Iterator resolvedQuestions;
/*     */   private int resolvedQuestionCount;
/*     */   private int unresolvedQuestionCount;
/*     */   private int urange;
/*     */   private int ustart;
/*     */   private int rrange;
/*     */   private int rstart;
/*     */ 
/*     */   public MyQuestionsAction()
/*     */   {
/*  33 */     this.urange = 5;
/*  34 */     this.ustart = 0;
/*  35 */     this.rrange = 5;
/*  36 */     this.rstart = 0;
/*     */   }
/*     */   public QuestionManager getQuestionManager() {
/*  39 */     return this.qman;
/*     */   }
/*     */ 
/*     */   public Iterator getUnresolvedQuestions() {
/*  43 */     return this.unresolvedQuestions;
/*     */   }
/*     */ 
/*     */   public Iterator getResolvedQuestions() {
/*  47 */     return this.resolvedQuestions;
/*     */   }
/*     */ 
/*     */   public int getUnresolvedQuestionCount() {
/*  51 */     return this.unresolvedQuestionCount;
/*     */   }
/*     */ 
/*     */   public int getResolvedQuestionCount() {
/*  55 */     return this.resolvedQuestionCount;
/*     */   }
/*     */ 
/*     */   public int getUrange() {
/*  59 */     return this.urange;
/*     */   }
/*     */ 
/*     */   public void setUrange(int uRange) {
/*  63 */     this.urange = uRange;
/*     */   }
/*     */ 
/*     */   public int getUstart() {
/*  67 */     return this.ustart;
/*     */   }
/*     */ 
/*     */   public void setUstart(int uStart) {
/*  71 */     this.ustart = uStart;
/*     */   }
/*     */ 
/*     */   public int getRrange() {
/*  75 */     return this.rrange;
/*     */   }
/*     */ 
/*     */   public void setRrange(int rRange) {
/*  79 */     this.rrange = rRange;
/*     */   }
/*     */ 
/*     */   public int getRstart() {
/*  83 */     return this.rstart;
/*     */   }
/*     */ 
/*     */   public void setRstart(int rStart) {
/*  87 */     this.rstart = rStart;
/*     */   }
/*     */ 
/*     */   public Paginator getOpenQuestionPaginator() {
/*  91 */     return new Paginator(new QuestionPageable(getUstart(), getUrange(), this.unresolvedQuestionCount));
/*     */   }
/*     */ 
/*     */   public Paginator getClosedQuestionPaginator() {
/*  95 */     return new Paginator(new QuestionPageable(getRstart(), getRrange(), this.resolvedQuestionCount));
/*     */   }
/*     */ 
/*     */   public void prepare() throws Exception {
/*     */   }
/*     */ 
/*     */   public String execute() {
/* 102 */     if (isGuest()) {
/* 103 */       return "unauthorized";
/*     */     }
/* 105 */     this.qman = getForumFactory().getQuestionManager();
/*     */ 
/* 107 */     QuestionFilter unresolvedFilter = new QuestionFilter();
/* 108 */     unresolvedFilter.setStartIndex(this.ustart);
/* 109 */     unresolvedFilter.setNumResults(this.urange);
/*     */ 
/* 111 */     unresolvedFilter.setUserID(getPageUser().getID());
/*     */ 
/* 113 */     unresolvedFilter.clearResolutionStates();
/* 114 */     unresolvedFilter.addResolutionState(Question.State.open);
/* 115 */     unresolvedFilter.addResolutionState(Question.State.possibly_resolved);
/*     */ 
/* 117 */     this.unresolvedQuestions = this.qman.getQuestions(unresolvedFilter);
/* 118 */     this.unresolvedQuestionCount = this.qman.getQuestionCount(unresolvedFilter);
/*     */ 
/* 121 */     QuestionFilter resolvedFilter = new QuestionFilter();
/* 122 */     resolvedFilter.setStartIndex(this.rstart);
/* 123 */     resolvedFilter.setNumResults(this.rrange);
/* 124 */     resolvedFilter.setUserID(getPageUser().getID());
/* 125 */     resolvedFilter.clearResolutionStates();
/* 126 */     resolvedFilter.addResolutionState(Question.State.assumed_resolved);
/* 127 */     resolvedFilter.addResolutionState(Question.State.resolved);
/* 128 */     this.resolvedQuestions = this.qman.getQuestions(resolvedFilter);
/* 129 */     this.resolvedQuestionCount = this.qman.getQuestionCount(resolvedFilter);
/*     */ 
/* 131 */     return "success";
/*     */   }
/*     */   public class QuestionPageable implements Pageable {
/*     */     private int start;
/*     */     private int range;
/*     */     private int totalCount;
/*     */ 
/*     */     public QuestionPageable(int start, int range, int totalCount) {
/* 141 */       this.start = start;
/* 142 */       this.range = range;
/* 143 */       this.totalCount = totalCount;
/*     */     }
/*     */ 
/*     */     public int getStart() {
/* 147 */       return this.start;
/*     */     }
/*     */ 
/*     */     public int getTotalItemCount() {
/* 151 */       return this.totalCount;
/*     */     }
/*     */ 
/*     */     public ResultFilter getResultFilter() {
/* 155 */       ResultFilter filter = new ResultFilter();
/* 156 */       filter.setStartIndex(this.start);
/* 157 */       filter.setNumResults(this.range);
/* 158 */       return filter;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.MyQuestionsAction
 * JD-Core Version:    0.6.2
 */
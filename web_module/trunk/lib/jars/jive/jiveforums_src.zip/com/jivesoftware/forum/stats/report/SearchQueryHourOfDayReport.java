/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.BinFormat;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.Report.ExtraInfo;
/*     */ import com.jivesoftware.base.stats.bin.CyclicSequence;
/*     */ import com.jivesoftware.base.stats.element.CyclicElement;
/*     */ import com.jivesoftware.base.stats.element.HourOfDayElementFormat;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ public class SearchQueryHourOfDayReport extends AbstractForumReport
/*     */ {
/*     */   private static final String EARLIEST_SEARCH_DATE = "SELECT min(searchDate) FROM jiveSearch WHERE searchType=19";
/*     */   private static final String SEARCH_QUERIES = "SELECT searchDate from jiveSearch WHERE searchDate >= ? AND searchDate <= ? AND searchType=19";
/*  42 */   private BinFormat labelFormatter = new BinFormat(new HourOfDayElementFormat("ha"), "$1");
/*     */ 
/*     */   public void execute()
/*     */   {
/*  50 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  51 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  53 */     if (end.compareTo(start) < 0)
/*     */     {
/*  55 */       start = end;
/*     */     }
/*     */ 
/*  59 */     Histogram hist = new Histogram(new CyclicSequence(24L), new CyclicElement(24L, 0L, 0L), new CyclicElement(24L, 23L, 0L));
/*     */ 
/*  62 */     addHistogram(hist);
/*     */ 
/*  64 */     Connection con = null;
/*  65 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/*  68 */       con = ConnectionManager.getConnection();
/*  69 */       pstmt = con.prepareStatement("SELECT searchDate from jiveSearch WHERE searchDate >= ? AND searchDate <= ? AND searchType=19");
/*  70 */       pstmt.setLong(1, start.getTime());
/*  71 */       pstmt.setLong(2, end.getTime());
/*  72 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  74 */       Calendar cal = Calendar.getInstance(JiveGlobals.getTimeZone(), JiveGlobals.getLocale());
/*  75 */       while (rs.next()) {
/*  76 */         cal.setTime(new Date(rs.getLong(1)));
/*  77 */         hist.add(new CyclicElement(24L, 0L, cal.get(11)));
/*     */       }
/*  79 */       rs.close();
/*     */     } catch (SQLException e) {
/*  81 */       Log.error(e);
/*     */     } finally {
/*  83 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/*  88 */     Histogram[] histograms = getHistograms();
/*  89 */     if (histograms.length == 0) {
/*  90 */       return new DataTable[0];
/*     */     }
/*  92 */     DataTable data = new DataTable(getName());
/*  93 */     data.setColumns(new String[] { "Hour of the Day", "Searches" });
/*  94 */     Histogram hist = histograms[0];
/*  95 */     Bin[] bins = hist.getBins();
/*  96 */     for (int i = 0; i < bins.length; i++) {
/*  97 */       Bin bin = bins[i];
/*  98 */       long count = hist.getCount(bin);
/*  99 */       data.addRow(new Object[] { this.labelFormatter.format(bin), new Long(count) });
/*     */     }
/* 101 */     return new DataTable[] { data };
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 105 */     Histogram[] histograms = getHistograms();
/* 106 */     if (histograms.length == 0) {
/* 107 */       return new Chart[0];
/*     */     }
/* 109 */     Chart chart = new Chart(getName());
/* 110 */     chart.setXaxisLabel("Hour of the Day");
/* 111 */     chart.setXaxisLabel("Searches");
/* 112 */     chart.setType(2);
/* 113 */     Histogram hist = histograms[0];
/* 114 */     Bin[] bins = hist.getBins();
/* 115 */     String[] labels = new String[bins.length];
/* 116 */     for (int i = 0; i < bins.length; i++) {
/* 117 */       Bin bin = bins[i];
/* 118 */       labels[i] = this.labelFormatter.format(bin);
/*     */     }
/* 120 */     chart.setLabels(labels);
/*     */ 
/* 122 */     return new Chart[] { chart };
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 126 */     Histogram[] histograms = getHistograms();
/* 127 */     if (histograms.length == 0) {
/* 128 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/* 130 */     List extraInfo = new ArrayList(4);
/* 131 */     Histogram hist = histograms[0];
/* 132 */     if (hist.getNElement() > 0L)
/*     */     {
/* 134 */       extraInfo.add(new Report.ExtraInfo("Median searches/hour", new Long(hist.getMedianCount())));
/*     */ 
/* 136 */       extraInfo.add(new Report.ExtraInfo("Peak Hour", this.labelFormatter.format(hist.getMaxCountBin())));
/*     */     }
/*     */ 
/* 140 */     extraInfo.add(getDateRange());
/*     */ 
/* 142 */     return new List[] { extraInfo };
/*     */   }
/*     */ 
/*     */   protected Date calculateStartDate() {
/* 146 */     Connection con = null;
/* 147 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 150 */       con = ConnectionManager.getConnection();
/* 151 */       pstmt = con.prepareStatement("SELECT min(searchDate) FROM jiveSearch WHERE searchType=19");
/* 152 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 154 */       if (rs.next()) {
/* 155 */         return new Date(rs.getLong(1));
/*     */       }
/* 157 */       rs.close();
/*     */     } catch (SQLException e) {
/* 159 */       Log.error(e);
/*     */     } finally {
/* 161 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 164 */     return super.calculateStartDate();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.SearchQueryHourOfDayReport
 * JD-Core Version:    0.6.2
 */
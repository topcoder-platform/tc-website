/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ public class ForumNotFoundException extends Exception
/*    */ {
/* 19 */   private long forumID = -1L;
/*    */ 
/*    */   public ForumNotFoundException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ForumNotFoundException(String msg) {
/* 26 */     super(msg);
/*    */   }
/*    */ 
/*    */   public ForumNotFoundException(long forumID) {
/* 30 */     this.forumID = forumID;
/*    */   }
/*    */ 
/*    */   public ForumNotFoundException(String s, long forumID) {
/* 34 */     super(s);
/* 35 */     this.forumID = forumID;
/*    */   }
/*    */ 
/*    */   public long getForumID() {
/* 39 */     return this.forumID;
/*    */   }
/*    */ 
/*    */   public void setForumID(long forumID) {
/* 43 */     this.forumID = forumID;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.ForumNotFoundException
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.nntp.spi;
/*    */ 
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import com.jivesoftware.forum.nntp.NewsGroupFilter;
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ public class FNameFilterIterator extends PeekIterator
/*    */ {
/*    */   private NewsGroupFilter filter;
/*    */ 
/*    */   public FNameFilterIterator(Iterator forumIterator, NewsGroupFilter ngFilter)
/*    */   {
/* 38 */     super(forumIterator);
/* 39 */     this.filter = ngFilter;
/*    */   }
/*    */ 
/*    */   public boolean hasNext()
/*    */   {
/* 49 */     boolean hasNext = super.hasNext();
/* 50 */     while (hasNext) {
/* 51 */       Forum forum = (Forum)super.peek();
/* 52 */       String name = forum.getNNTPName();
/* 53 */       if (this.filter.matches(name)) {
/*    */         break;
/*    */       }
/* 56 */       super.next();
/* 57 */       hasNext = super.hasNext();
/*    */     }
/* 59 */     return hasNext;
/*    */   }
/*    */ 
/*    */   public Object next()
/*    */     throws NoSuchElementException
/*    */   {
/* 70 */     if (!hasNext()) {
/* 71 */       throw new NoSuchElementException();
/*    */     }
/* 73 */     return super.next();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.FNameFilterIterator
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.gateway;
/*    */ 
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ 
/*    */ public class NewsgroupGateway extends Gateway
/*    */ {
/*    */   public NewsgroupGateway(ForumFactory factory, Forum forum)
/*    */   {
/* 20 */     super(new NewsgroupImporter(factory, forum), new NewsgroupExporter(factory, forum));
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.NewsgroupGateway
 * JD-Core Version:    0.6.2
 */
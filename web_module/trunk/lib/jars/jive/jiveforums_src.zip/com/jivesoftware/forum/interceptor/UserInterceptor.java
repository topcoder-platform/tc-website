/*     */ package com.jivesoftware.forum.interceptor;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserManagerFactory;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.MessageInterceptor;
/*     */ import com.jivesoftware.forum.MessageRejectedException;
/*     */ import com.jivesoftware.util.EmailTask;
/*     */ import com.jivesoftware.util.StringUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class UserInterceptor
/*     */   implements MessageInterceptor
/*     */ {
/*     */   private Map banMap;
/*     */   private String fromEmail;
/*     */   private String fromName;
/*     */   private String emailSubject;
/*     */   private String emailBodyTemplate;
/*     */   private boolean notificationEnabled;
/*     */ 
/*     */   public UserInterceptor()
/*     */   {
/*     */   }
/*     */ 
/*     */   public UserInterceptor(int objectType, long objectID)
/*     */   {
/*     */   }
/*     */ 
/*     */   public String getEmailBodyTemplate()
/*     */   {
/*  46 */     return this.emailBodyTemplate;
/*     */   }
/*     */ 
/*     */   public void setEmailBodyTemplate(String emailBodyTemplate) {
/*  50 */     this.emailBodyTemplate = emailBodyTemplate;
/*     */   }
/*     */ 
/*     */   public String getEmailSubject() {
/*  54 */     return this.emailSubject;
/*     */   }
/*     */ 
/*     */   public void setEmailSubject(String emailSubject) {
/*  58 */     this.emailSubject = emailSubject;
/*     */   }
/*     */ 
/*     */   public String getFromEmail() {
/*  62 */     return this.fromEmail;
/*     */   }
/*     */ 
/*     */   public void setFromEmail(String fromEmail) {
/*  66 */     this.fromEmail = fromEmail;
/*     */   }
/*     */ 
/*     */   public String getFromName() {
/*  70 */     return this.fromName;
/*     */   }
/*     */ 
/*     */   public void setFromName(String fromName) {
/*  74 */     this.fromName = fromName;
/*     */   }
/*     */ 
/*     */   public boolean isNotificationEnabled() {
/*  78 */     return this.notificationEnabled;
/*     */   }
/*     */ 
/*     */   public void setNotificationEnabled(boolean notificationEnabled) {
/*  82 */     this.notificationEnabled = notificationEnabled;
/*     */   }
/*     */ 
/*     */   public String getBanList()
/*     */   {
/*  92 */     if ((this.banMap == null) || (this.banMap.size() == 0)) {
/*  93 */       return "";
/*     */     }
/*     */ 
/*  96 */     StringBuffer buf = new StringBuffer();
/*  97 */     Iterator iter = this.banMap.keySet().iterator();
/*  98 */     if (iter.hasNext()) {
/*  99 */       buf.append((String)iter.next());
/*     */     }
/* 101 */     while (iter.hasNext()) {
/* 102 */       buf.append(", ").append((String)iter.next());
/*     */     }
/* 104 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public void setBanList(String usernames)
/*     */   {
/* 113 */     Map oldBanMap = null;
/* 114 */     List notifyList = null;
/* 115 */     if (this.notificationEnabled) {
/* 116 */       oldBanMap = this.banMap;
/* 117 */       notifyList = new ArrayList();
/*     */     }
/* 119 */     this.banMap = new HashMap();
/* 120 */     StringTokenizer tokens = new StringTokenizer(usernames, ",");
/* 121 */     while (tokens.hasMoreTokens()) {
/* 122 */       String username = tokens.nextToken().trim();
/* 123 */       this.banMap.put(username, "");
/* 124 */       if ((this.notificationEnabled) && (oldBanMap != null) && (!oldBanMap.containsKey(username)))
/*     */       {
/* 126 */         notifyList.add(username);
/*     */       }
/*     */     }
/* 129 */     if (this.notificationEnabled)
/* 130 */       sendNotifications(notifyList);
/*     */   }
/*     */ 
/*     */   public int getType()
/*     */   {
/* 135 */     return 0;
/*     */   }
/*     */ 
/*     */   public void invokeInterceptor(ForumMessage message, int type)
/*     */     throws MessageRejectedException
/*     */   {
/* 146 */     if ((this.banMap != null) && (!message.isAnonymous())) {
/* 147 */       User author = message.getUser();
/* 148 */       if (this.banMap.containsKey(author.getUsername()))
/* 149 */         throw new MessageRejectedException("User '" + author.getUsername() + "' not allowed to post.", message);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void sendNotifications(List notifyList)
/*     */   {
/* 156 */     EmailTask emailTask = new EmailTask();
/*     */ 
/* 158 */     UserManager userManager = UserManagerFactory.getInstance();
/*     */ 
/* 160 */     for (Iterator users = notifyList.iterator(); users.hasNext(); ) {
/* 161 */       User user = null;
/*     */       try {
/* 163 */         user = userManager.getUser((String)users.next());
/*     */       } catch (UserNotFoundException e) {
/* 165 */         Log.error(e);
/* 166 */       }continue;
/*     */ 
/* 168 */       String emailAddr = user.getEmail();
/* 169 */       if ((emailAddr != null) && (!emailAddr.equals(""))) {
/* 170 */         String toName = user.getName() != null ? user.getName() : emailAddr;
/* 171 */         String toEmail = emailAddr;
/* 172 */         String subject = replaceTokens(this.emailSubject, user);
/* 173 */         String body = replaceTokens(this.emailBodyTemplate, user);
/* 174 */         emailTask.addMessage(toName, toEmail, this.fromName, this.fromEmail, subject, body, null);
/*     */       }
/*     */     }
/* 177 */     emailTask.run();
/*     */   }
/*     */ 
/*     */   private static String replaceTokens(String string, User user) {
/* 181 */     string = StringUtils.replace(string, "{jiveURL}", JiveGlobals.getJiveProperty("jiveURL"));
/* 182 */     string = StringUtils.replace(string, "{email}", user.getEmail());
/* 183 */     string = StringUtils.replace(string, "{username}", user.getUsername());
/* 184 */     string = StringUtils.replace(string, "{ID}", Long.toString(user.getID()));
/* 185 */     string = StringUtils.replace(string, "{name}", user.getName());
/* 186 */     return string;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.UserInterceptor
 * JD-Core Version:    0.6.2
 */
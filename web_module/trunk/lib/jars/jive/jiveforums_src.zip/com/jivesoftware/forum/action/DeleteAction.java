/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ 
/*     */ public class DeleteAction extends ForumThreadAction
/*     */ {
/*  20 */   public static String DELETE_ALL = "all";
/*  21 */   public static String DELETE_SINGLE = "single";
/*     */   private String doCancel;
/*     */   private String deleteMode;
/*  30 */   private boolean isThreadDeletion = false;
/*     */ 
/*     */   public String getDoCancel()
/*     */   {
/*  35 */     return this.doCancel;
/*     */   }
/*     */ 
/*     */   public void setDoCancel(String doCancel) {
/*  39 */     this.doCancel = "true";
/*     */   }
/*     */ 
/*     */   public String getDeleteMode() {
/*  43 */     return this.deleteMode;
/*     */   }
/*     */ 
/*     */   public void setDeleteMode(String deleteMode) {
/*  47 */     this.deleteMode = deleteMode;
/*     */   }
/*     */ 
/*     */   public boolean getIsThreadDeletion()
/*     */   {
/*  59 */     return this.isThreadDeletion;
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*     */     try
/*     */     {
/*  66 */       if (!loadJiveObjects())
/*  67 */         return "error";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/*  71 */       setLoginAttributes();
/*  72 */       if (this.isThreadDeletion) {
/*  73 */         addActionError(getText("delete.error_unauth_topic"));
/*     */       }
/*     */       else {
/*  76 */         addActionError(getText("delete.error_unauth_message"));
/*     */       }
/*     */ 
/*  79 */       if (getDeleteMode() == null) {
/*  80 */         setDeleteMode(DELETE_ALL);
/*     */       }
/*     */ 
/*  83 */       return "login";
/*     */     }
/*     */ 
/*  87 */     if (isRootMessage(getMessage()))
/*     */     {
/*  89 */       this.isThreadDeletion = true;
/*     */     }
/*     */     else
/*     */     {
/*  93 */       this.isThreadDeletion = false;
/*     */     }
/*     */ 
/*  96 */     setDeleteMode(DELETE_ALL);
/*     */ 
/*  98 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute() {
/*     */     try {
/* 103 */       if (!loadJiveObjects())
/* 104 */         return "error";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 108 */       setLoginAttributes();
/* 109 */       if (this.isThreadDeletion) {
/* 110 */         addActionError(getText("delete.error_unauth_topic"));
/*     */       }
/*     */       else {
/* 113 */         addActionError(getText("delete.error_unauth_message"));
/*     */       }
/* 115 */       return "login";
/*     */     }
/*     */ 
/* 118 */     if ("true".equals(getDoCancel()))
/*     */     {
/* 121 */       if (this.isThreadDeletion) {
/* 122 */         return "cancel-deletethread";
/*     */       }
/*     */ 
/* 125 */       return "cancel-deletemessage";
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 131 */       if (isRootMessage(getMessage()))
/*     */       {
/* 133 */         this.isThreadDeletion = true;
/* 134 */         getForum().deleteThread(getThread());
/*     */       }
/*     */       else
/*     */       {
/* 138 */         this.isThreadDeletion = false;
/*     */ 
/* 140 */         if (DELETE_SINGLE.equals(getDeleteMode()))
/*     */         {
/* 142 */           getThread().deleteMessage(getMessage(), false);
/*     */         }
/*     */         else
/*     */         {
/* 146 */           getThread().deleteMessage(getMessage());
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 151 */       setLoginAttributes();
/* 152 */       addActionError(ue.getMessage());
/* 153 */       return "login";
/*     */     }
/*     */ 
/* 157 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.DeleteAction
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.moderation;
/*    */ 
/*    */ import com.jivesoftware.forum.ResultFilter;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ModerationFilter extends ResultFilter
/*    */ {
/* 12 */   private int moderationRangeMin = 2147483524;
/* 13 */   private int moderationRangeMax = 2147483524;
/* 14 */   private List modValueList = Collections.EMPTY_LIST;
/*    */ 
/*    */   public static ModerationFilter createDefaultModerationFilter()
/*    */   {
/* 21 */     ModerationFilter modFilter = new ModerationFilter();
/* 22 */     modFilter.setModerationRangeMin(0);
/* 23 */     modFilter.setModerationRangeMax(0);
/* 24 */     List modValues = new ArrayList(2);
/* 25 */     modValues.add(new Integer(-5));
/* 26 */     modValues.add(new Integer(5));
/* 27 */     modFilter.setModValueList(modValues);
/* 28 */     modFilter.setSortField(8);
/* 29 */     modFilter.setSortOrder(1);
/* 30 */     return modFilter;
/*    */   }
/*    */ 
/*    */   public static ModerationFilter createModerationOnlyFilter()
/*    */   {
/* 38 */     ModerationFilter modFilter = new ModerationFilter();
/* 39 */     modFilter.setModerationRangeMin(0);
/* 40 */     modFilter.setModerationRangeMax(0);
/* 41 */     modFilter.setSortField(8);
/* 42 */     modFilter.setSortOrder(1);
/* 43 */     return modFilter;
/*    */   }
/*    */ 
/*    */   public static ModerationFilter createAbuseOnlyFilter()
/*    */   {
/* 51 */     ModerationFilter modFilter = new ModerationFilter();
/* 52 */     modFilter.setModerationRangeMin(5);
/* 53 */     modFilter.setModerationRangeMax(5);
/* 54 */     List modValues = new ArrayList(1);
/* 55 */     modValues.add(new Integer(-5));
/* 56 */     modFilter.setModValueList(modValues);
/* 57 */     modFilter.setSortField(8);
/* 58 */     modFilter.setSortOrder(1);
/* 59 */     return modFilter;
/*    */   }
/*    */ 
/*    */   public List getModValueList() {
/* 63 */     return this.modValueList;
/*    */   }
/*    */ 
/*    */   public void setModValueList(List modValueList) {
/* 67 */     this.modValueList = modValueList;
/*    */   }
/*    */ 
/*    */   public int getModerationRangeMin()
/*    */   {
/* 73 */     if (this.moderationRangeMin == 2147483524) {
/* 74 */       return 0;
/*    */     }
/* 76 */     return this.moderationRangeMin;
/*    */   }
/*    */ 
/*    */   public void setModerationRangeMin(int moderationRangeMin) {
/* 80 */     this.moderationRangeMin = moderationRangeMin;
/*    */   }
/*    */ 
/*    */   public int getModerationRangeMax() {
/* 84 */     if (this.moderationRangeMax == 2147483524) {
/* 85 */       return 0;
/*    */     }
/* 87 */     return this.moderationRangeMax;
/*    */   }
/*    */ 
/*    */   public void setModerationRangeMax(int moderationRangeMax) {
/* 91 */     this.moderationRangeMax = moderationRangeMax;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.moderation.ModerationFilter
 * JD-Core Version:    0.6.2
 */
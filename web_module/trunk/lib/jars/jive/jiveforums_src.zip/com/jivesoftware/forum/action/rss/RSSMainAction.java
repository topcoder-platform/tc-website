/*    */ package com.jivesoftware.forum.action.rss;
/*    */ 
/*    */ import com.jivesoftware.base.AuthFactory;
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.User;
/*    */ import com.jivesoftware.base.UserManager;
/*    */ import com.jivesoftware.base.action.rss.RSSActionSupport;
/*    */ import com.jivesoftware.forum.ForumCategory;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import java.util.Stack;
/*    */ 
/*    */ public class RSSMainAction extends RSSActionSupport
/*    */ {
/*    */   private String feed;
/*    */   private AuthToken anonAuthToken;
/*    */   private ForumFactory forumFactory;
/*    */   private List categories;
/*    */   private User pageUser;
/*    */ 
/*    */   public String getFeed()
/*    */   {
/* 34 */     return this.feed;
/*    */   }
/*    */ 
/*    */   public void setFeed(String feed) {
/* 38 */     this.feed = feed;
/*    */   }
/*    */ 
/*    */   public AuthToken getAnonymousAuthToken() {
/* 42 */     return this.anonAuthToken;
/*    */   }
/*    */ 
/*    */   public ForumFactory getForumFactory() {
/* 46 */     return this.forumFactory;
/*    */   }
/*    */ 
/*    */   public Iterator getCategories() {
/* 50 */     return this.categories.iterator();
/*    */   }
/*    */ 
/*    */   public User getPageUser() {
/* 54 */     return this.pageUser;
/*    */   }
/*    */ 
/*    */   public String execute() throws Exception {
/* 58 */     this.anonAuthToken = AuthFactory.getAnonymousAuthToken();
/* 59 */     this.forumFactory = ForumFactory.getInstance(this.anonAuthToken);
/* 60 */     ForumCategory rootCat = this.forumFactory.getRootForumCategory();
/*    */ 
/* 62 */     if (!isGuest()) {
/* 63 */       this.pageUser = this.forumFactory.getUserManager().getUser(getAuthToken().getUserID());
/*    */     }
/*    */ 
/* 67 */     this.categories = new LinkedList();
/* 68 */     Stack stack = new Stack();
/* 69 */     for (stack.push(rootCat); stack.size() > 0; ) {
/* 70 */       ForumCategory category = (ForumCategory)stack.pop();
/* 71 */       this.categories.add(category);
/* 72 */       List cats = new ArrayList();
/* 73 */       for (Iterator subCats = category.getCategories(); subCats.hasNext(); ) {
/* 74 */         cats.add(subCats.next());
/*    */       }
/* 76 */       for (int i = cats.size() - 1; i >= 0; i--) {
/* 77 */         ForumCategory cat = (ForumCategory)cats.get(i);
/* 78 */         stack.push(cat);
/*    */       }
/*    */     }
/* 81 */     return "success";
/*    */   }
/*    */ 
/*    */   public static String pad(int num, String padding) {
/* 85 */     StringBuffer buf = new StringBuffer();
/* 86 */     for (int i = 0; i < num; i++) {
/* 87 */       buf.append(padding);
/*    */     }
/* 89 */     return buf.toString();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.rss.RSSMainAction
 * JD-Core Version:    0.6.2
 */
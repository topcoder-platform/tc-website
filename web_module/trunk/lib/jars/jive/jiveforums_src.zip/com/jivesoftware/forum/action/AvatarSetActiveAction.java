/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.User;
/*    */ import com.jivesoftware.base.UserManager;
/*    */ import com.jivesoftware.base.UserNotFoundException;
/*    */ import com.jivesoftware.forum.Avatar;
/*    */ import com.jivesoftware.forum.AvatarManager;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.opensymphony.xwork.Preparable;
/*    */ 
/*    */ public class AvatarSetActiveAction extends ForumActionSupport
/*    */   implements Preparable
/*    */ {
/* 26 */   private long avatarID = -1L;
/*    */   private String type;
/* 28 */   private boolean isCancel = false;
/*    */   private User user;
/*    */ 
/*    */   public void setAvatarID(long avatarID)
/*    */   {
/* 38 */     this.avatarID = avatarID;
/*    */   }
/*    */ 
/*    */   public void setType(String type)
/*    */   {
/* 48 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public void setCancel(String cancel) {
/* 52 */     this.isCancel = true;
/*    */   }
/*    */ 
/*    */   public String execute() throws Exception
/*    */   {
/* 57 */     if (this.isCancel) {
/* 58 */       return "cancel";
/*    */     }
/*    */ 
/* 61 */     Avatar avatar = null;
/* 62 */     AvatarManager avatarManager = getForumFactory().getAvatarManager();
/*    */ 
/* 67 */     if ("choose".equals(this.type)) {
/* 68 */       if (this.avatarID == -1L) {
/* 69 */         addFieldError("avatarID", "");
/* 70 */         return "error";
/*    */       }
/*    */ 
/* 73 */       avatar = avatarManager.getAvatar(this.avatarID);
/*    */     }
/*    */ 
/* 76 */     avatarManager.setActiveAvatar(this.user, avatar);
/*    */ 
/* 78 */     return "success";
/*    */   }
/*    */ 
/*    */   public void prepare() throws Exception
/*    */   {
/* 83 */     AuthToken authToken = getAuthToken();
/* 84 */     if (authToken.isAnonymous()) {
/* 85 */       throw new UserNotFoundException();
/*    */     }
/*    */ 
/* 88 */     long userID = authToken.getUserID();
/*    */ 
/* 91 */     if (userID != -1L) {
/* 92 */       this.user = getForumFactory().getUserManager().getUser(userID);
/*    */     }
/*    */ 
/* 96 */     if (this.user == null)
/* 97 */       throw new UserNotFoundException();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AvatarSetActiveAction
 * JD-Core Version:    0.6.2
 */
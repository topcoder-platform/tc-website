/*      */ package com.jivesoftware.forum.database;
/*      */ 
/*      */ import com.jivesoftware.base.AuthToken;
/*      */ import com.jivesoftware.base.JiveGlobals;
/*      */ import com.jivesoftware.base.JiveManager;
/*      */ import com.jivesoftware.base.Log;
/*      */ import com.jivesoftware.base.Permissions;
/*      */ import com.jivesoftware.base.User;
/*      */ import com.jivesoftware.base.UserManager;
/*      */ import com.jivesoftware.base.database.ConnectionManager;
/*      */ import com.jivesoftware.base.event.UserEventDispatcher;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumCategory;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumNotFoundException;
/*      */ import com.jivesoftware.forum.ForumThread;
/*      */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*      */ import com.jivesoftware.forum.Watch;
/*      */ import com.jivesoftware.forum.WatchManager;
/*      */ import com.jivesoftware.forum.event.CategoryEventDispatcher;
/*      */ import com.jivesoftware.forum.event.ForumEventDispatcher;
/*      */ import com.jivesoftware.forum.event.MessageEventDispatcher;
/*      */ import com.jivesoftware.forum.event.ThreadEventDispatcher;
/*      */ import com.jivesoftware.util.Cache;
/*      */ import com.jivesoftware.util.CronTask;
/*      */ import com.jivesoftware.util.CronTaskManager;
/*      */ import com.jivesoftware.util.CronTimer;
/*      */ import com.jivesoftware.util.LongHashMap;
/*      */ import com.jivesoftware.util.LongList;
/*      */ import com.jivesoftware.util.TaskEngine;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.text.ParseException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ 
/*      */ public class DbWatchManager
/*      */   implements WatchManager, JiveManager
/*      */ {
/*      */   private static final String GET_WATCHES = "SELECT objectID, watchType, expirable FROM jiveWatch WHERE userID=? AND objectType=? ORDER BY objectID DESC";
/*      */   private static final String GET_BATCH_WATCHES = "SELECT userID, objectID, objectType, expirable FROM jiveWatch WHERE watchType=2";
/*      */   private static final String GET_EXPIRED_THREAD_WATCHES = "SELECT jiveWatch.userID, objectType, objectID, watchType FROM jiveWatch, jiveThread WHERE jiveWatch.objectID=jiveThread.threadID AND jiveWatch.objectType=1 AND jiveThread.modificationDate < ? AND jiveWatch.expirable=1";
/*      */   private static final String GET_EXPIRED_FORUM_WATCHES = "SELECT jiveWatch.userID, objectType, objectID, watchType FROM jiveWatch, jiveForum WHERE jiveWatch.objectID=jiveForum.forumID AND jiveWatch.objectType=0 AND jiveForum.modificationDate < ? AND jiveWatch.expirable=1";
/*      */   private static final String GET_EXPIRED_CATEGORY_WATCHES = "SELECT jiveWatch.userID, objectType, objectID, watchType FROM jiveWatch, jiveCategory WHERE jiveWatch.objectID=jiveCategory.categoryID AND jiveWatch.objectType=14 AND jiveCategory.modificationDate < ? AND jiveWatch.expirable=1";
/*      */   private static final String DELETE_WATCHES = "DELETE FROM jiveWatch WHERE objectType=? AND objectID=?";
/*      */   private static final String GET_THREAD_WATCHES = "SELECT DISTINCT objectID FROM jiveWatch, jiveThread WHERE jiveThread.forumID=? AND jiveWatch.objectType=1 AND jiveWatch.objectID=jiveThread.threadID";
/*      */   private static final String DELETE_USER_WATCHES = "DELETE FROM jiveWatch WHERE userID=?";
/*      */   private static final String WATCHERS_ON_OBJECT = "SELECT userID FROM jiveWatch WHERE objectType=? AND objectID=? AND watchType=?";
/*      */   private static final String GET_BATCH_TIMER = "SELECT frequency FROM jiveBatchWatch WHERE userID=?";
/*      */   private static final String INSERT_BATCH_TIMER = "INSERT INTO jiveBatchWatch (userID, frequency, prevEmailDate) VALUES (?, ?, ?)";
/*      */   private static final String UPDATE_BATCH_TIMER = "UPDATE jiveBatchWatch SET frequency=? WHERE userID=?";
/*      */   private static final String DELETE_BATCH_TIMER = "DELETE FROM jiveBatchWatch WHERE userID=?";
/*   94 */   private static final Watch[] EMPTY_WATCH_LIST = new Watch[0];
/*      */   private static DbForumFactory FACTORY;
/*   97 */   private static boolean initialized = false;
/*      */   private int deleteDays;
/*      */ 
/*      */   public DbWatchManager()
/*      */   {
/*  105 */     this.deleteDays = JiveGlobals.getJiveIntProperty("watches.deleteDays", 90);
/*      */   }
/*      */ 
/*      */   public synchronized void initialize() {
/*  109 */     if (!initialized) {
/*  110 */       FACTORY = DbForumFactory.getInstance();
/*      */ 
/*  114 */       WatchListener listener = new WatchListener(this);
/*  115 */       CategoryEventDispatcher.getInstance().addListener(listener);
/*  116 */       ForumEventDispatcher.getInstance().addListener(listener);
/*  117 */       ThreadEventDispatcher.getInstance().addListener(listener);
/*  118 */       MessageEventDispatcher.getInstance().addListener(listener);
/*  119 */       UserEventDispatcher.getInstance().addListener(listener);
/*      */ 
/*  122 */       long period = 43200000L;
/*  123 */       TaskEngine.scheduleTask(new DeleteWatchesTask(), period, period);
/*  124 */       initialized = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getDeleteDays() {
/*  129 */     return this.deleteDays;
/*      */   }
/*      */ 
/*      */   public void setDeleteDays(int deleteDays) {
/*  133 */     this.deleteDays = deleteDays;
/*  134 */     JiveGlobals.setJiveProperty("watches.deleteDays", Integer.toString(deleteDays));
/*      */   }
/*      */ 
/*      */   public CronTimer getBatchTimer(User user) {
/*  138 */     if (user == null) {
/*  139 */       return null;
/*      */     }
/*      */ 
/*  142 */     Connection con = null;
/*  143 */     PreparedStatement pstmt = null;
/*      */     try {
/*  145 */       con = ConnectionManager.getConnection();
/*  146 */       pstmt = con.prepareStatement("SELECT frequency FROM jiveBatchWatch WHERE userID=?");
/*  147 */       pstmt.setLong(1, user.getID());
/*  148 */       ResultSet rs = pstmt.executeQuery();
/*  149 */       if (rs.next()) {
/*  150 */         return new CronTimer(rs.getString(1));
/*      */       }
/*  152 */       rs.close();
/*      */     }
/*      */     catch (ParseException e) {
/*  155 */       Log.error(e);
/*      */     }
/*      */     catch (SQLException e) {
/*  158 */       Log.error(e);
/*      */     }
/*      */     finally {
/*  161 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/*  164 */     return null;
/*      */   }
/*      */ 
/*      */   public void setBatchTimer(User user, CronTimer timer) {
/*  168 */     if (user == null) {
/*  169 */       return;
/*      */     }
/*      */ 
/*  172 */     CronTimer oldTimer = getBatchTimer(user);
/*      */ 
/*  174 */     Connection con = null;
/*  175 */     PreparedStatement pstmt = null;
/*      */     try
/*      */     {
/*  178 */       if (timer == null)
/*      */       {
/*  180 */         con = ConnectionManager.getConnection();
/*  181 */         pstmt = con.prepareStatement("DELETE FROM jiveBatchWatch WHERE userID=?");
/*  182 */         pstmt.setLong(1, user.getID());
/*  183 */         pstmt.execute();
/*      */       }
/*  185 */       else if (oldTimer == null) {
/*  186 */         con = ConnectionManager.getConnection();
/*  187 */         pstmt = con.prepareStatement("INSERT INTO jiveBatchWatch (userID, frequency, prevEmailDate) VALUES (?, ?, ?)");
/*  188 */         pstmt.setLong(1, user.getID());
/*  189 */         pstmt.setString(2, timer.getCronExpression());
/*  190 */         pstmt.setLong(3, System.currentTimeMillis());
/*  191 */         pstmt.execute();
/*      */       }
/*      */       else {
/*  194 */         con = ConnectionManager.getConnection();
/*  195 */         pstmt = con.prepareStatement("UPDATE jiveBatchWatch SET frequency=? WHERE userID=?");
/*  196 */         pstmt.setString(1, timer.getCronExpression());
/*  197 */         pstmt.setLong(2, user.getID());
/*  198 */         pstmt.execute();
/*      */       }
/*      */     }
/*      */     catch (SQLException e) {
/*  202 */       Log.error(e);
/*      */     }
/*      */     finally {
/*  205 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/*  208 */     if (timer == null)
/*      */     {
/*  210 */       Iterator cronTasks = FACTORY.getCronTaskManager().getCronTasks();
/*  211 */       while (cronTasks.hasNext()) {
/*  212 */         CronTask cronTask = (CronTask)cronTasks.next();
/*  213 */         if ((cronTask.getRunnable() instanceof BatchEmailWatchTask)) {
/*  214 */           BatchEmailWatchTask batchTask = (BatchEmailWatchTask)cronTask.getRunnable();
/*  215 */           if (batchTask.getUserID() == user.getID())
/*      */           {
/*  217 */             FACTORY.getCronTaskManager().removeCronTask(cronTask);
/*      */ 
/*  219 */             break;
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  225 */       Watch[] watches = getWatchList(user.getID(), 1);
/*  226 */       for (int i = 0; i < watches.length; i++) {
/*  227 */         Watch watch = watches[i];
/*  228 */         if (watch.getWatchType() == 2) {
/*  229 */           watch.setWatchType(1);
/*      */         }
/*      */       }
/*      */ 
/*  233 */       watches = getWatchList(user.getID(), 0);
/*  234 */       for (int i = 0; i < watches.length; i++) {
/*  235 */         Watch watch = watches[i];
/*  236 */         if (watch.getWatchType() == 2) {
/*  237 */           watch.setWatchType(1);
/*      */         }
/*      */       }
/*      */ 
/*  241 */       watches = getWatchList(user.getID(), 14);
/*  242 */       for (int i = 0; i < watches.length; i++) {
/*  243 */         Watch watch = watches[i];
/*  244 */         if (watch.getWatchType() == 2) {
/*  245 */           watch.setWatchType(1);
/*      */         }
/*      */       }
/*      */ 
/*  249 */       watches = getWatchList(user.getID(), 3);
/*  250 */       for (int i = 0; i < watches.length; i++) {
/*  251 */         Watch watch = watches[i];
/*  252 */         if (watch.getWatchType() == 2) {
/*  253 */           watch.setWatchType(1);
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  259 */       boolean foundTask = false;
/*  260 */       Iterator cronTasks = FACTORY.getCronTaskManager().getCronTasks();
/*  261 */       while (cronTasks.hasNext()) {
/*  262 */         CronTask cronTask = (CronTask)cronTasks.next();
/*      */         Watch[] watches;
/*      */         int i;
/*      */         int i;
/*      */         int i;
/*      */         int i;
/*  263 */         if ((cronTask.getRunnable() instanceof BatchEmailWatchTask)) {
/*  264 */           BatchEmailWatchTask batchTask = (BatchEmailWatchTask)cronTask.getRunnable();
/*  265 */           if (batchTask.getUserID() == user.getID())
/*      */           {
/*  267 */             cronTask.setCronTimer(timer);
/*  268 */             FACTORY.getCronTaskManager().saveCronTask(cronTask);
/*  269 */             foundTask = true;
/*      */ 
/*  271 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  276 */       if (oldTimer == null)
/*      */       {
/*  278 */         watches = getWatchList(user.getID(), 1);
/*  279 */         for (i = 0; i < watches.length; i++) {
/*  280 */           Watch watch = watches[i];
/*  281 */           if (watch.getWatchType() != 2) {
/*  282 */             watch.setWatchType(2);
/*      */           }
/*      */         }
/*      */ 
/*  286 */         watches = getWatchList(user.getID(), 0);
/*  287 */         for (i = 0; i < watches.length; i++) {
/*  288 */           Watch watch = watches[i];
/*  289 */           if (watch.getWatchType() != 2) {
/*  290 */             watch.setWatchType(2);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  295 */         watches = getWatchList(user.getID(), 14);
/*  296 */         for (i = 0; i < watches.length; i++) {
/*  297 */           Watch watch = watches[i];
/*  298 */           if (watch.getWatchType() != 2) {
/*  299 */             watch.setWatchType(2);
/*      */           }
/*      */         }
/*      */ 
/*  303 */         watches = getWatchList(user.getID(), 3);
/*  304 */         for (i = 0; i < watches.length; i++) {
/*  305 */           Watch watch = watches[i];
/*  306 */           if (watch.getWatchType() != 2) {
/*  307 */             watch.setWatchType(2);
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  313 */       if (!foundTask)
/*  314 */         FACTORY.getCronTaskManager().createCronTask(new BatchEmailWatchTask(user.getID()), timer).setBatchWatch(true);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void demoteBatchWatches()
/*      */   {
/*  321 */     Iterator cronTasks = FACTORY.getCronTaskManager().getCronTasks();
/*  322 */     while (cronTasks.hasNext()) {
/*  323 */       CronTask cronTask = (CronTask)cronTasks.next();
/*  324 */       if ((cronTask.getRunnable() instanceof BatchEmailWatchTask)) {
/*  325 */         FACTORY.getCronTaskManager().removeCronTask(cronTask);
/*      */       }
/*      */     }
/*      */ 
/*  329 */     List watches = new ArrayList();
/*  330 */     Connection con = null;
/*  331 */     PreparedStatement pstmt = null;
/*      */     try {
/*  333 */       con = ConnectionManager.getConnection();
/*  334 */       pstmt = con.prepareStatement("SELECT userID, objectID, objectType, expirable FROM jiveWatch WHERE watchType=2");
/*  335 */       ResultSet rs = pstmt.executeQuery();
/*  336 */       while (rs.next()) {
/*  337 */         long userID = rs.getLong(1);
/*  338 */         long objectID = rs.getLong(2);
/*  339 */         int objectType = rs.getInt(3);
/*  340 */         boolean expirable = rs.getInt(4) == 1;
/*  341 */         DbWatch dbWatch = new DbWatch(userID, objectType, objectID, 2, expirable);
/*  342 */         watches.add(dbWatch);
/*      */       }
/*  344 */       rs.close();
/*      */     }
/*      */     catch (SQLException e) {
/*  347 */       Log.error(e);
/*      */     }
/*      */     finally {
/*  350 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/*  353 */     for (int i = 0; i < watches.size(); i++)
/*  354 */       ((Watch)watches.get(i)).setWatchType(1);
/*      */   }
/*      */ 
/*      */   public Watch createWatch(User user, User watchedUser)
/*      */   {
/*  359 */     DbWatch watch = null;
/*      */ 
/*  361 */     if (getBatchTimer(user) != null) {
/*  362 */       watch = new DbWatch(user.getID(), 3, watchedUser.getID(), 2, true);
/*      */     }
/*  365 */     else if (JiveGlobals.getJiveBooleanProperty("watches.email.enabledByDefault", true) ? !"false".equals(user.getProperty("jiveAutoAddEmailWatch")) : "true".equals(user.getProperty("jiveAutoAddEmailWatch")))
/*      */     {
/*  368 */       watch = new DbWatch(user.getID(), 3, watchedUser.getID(), 1, true);
/*      */     }
/*      */     else
/*      */     {
/*  372 */       watch = new DbWatch(user.getID(), 3, watchedUser.getID(), 0, true);
/*      */     }
/*      */ 
/*  375 */     watch.insertIntoDb();
/*      */ 
/*  377 */     String key = getCacheKey(user.getID(), 3);
/*  378 */     FACTORY.cacheManager.watchCache.remove(key);
/*  379 */     key = getCacheKey(3, user.getID(), watch.getWatchType());
/*  380 */     FACTORY.cacheManager.watchCache.remove(key);
/*      */ 
/*  382 */     return watch;
/*      */   }
/*      */ 
/*      */   public Watch createWatch(User user, ForumThread thread) {
/*  386 */     DbWatch watch = null;
/*      */ 
/*  388 */     if (getBatchTimer(user) != null) {
/*  389 */       watch = new DbWatch(user.getID(), 1, thread.getID(), 2, true);
/*      */     }
/*  392 */     else if (JiveGlobals.getJiveBooleanProperty("watches.email.enabledByDefault", true) ? !"false".equals(user.getProperty("jiveAutoAddEmailWatch")) : "true".equals(user.getProperty("jiveAutoAddEmailWatch")))
/*      */     {
/*  395 */       watch = new DbWatch(user.getID(), 1, thread.getID(), 1, true);
/*      */     }
/*      */     else
/*      */     {
/*  399 */       watch = new DbWatch(user.getID(), 1, thread.getID(), 0, true);
/*      */     }
/*      */ 
/*  402 */     watch.insertIntoDb();
/*      */ 
/*  404 */     String key = getCacheKey(user.getID(), 1);
/*  405 */     FACTORY.cacheManager.watchCache.remove(key);
/*      */ 
/*  407 */     key = getCacheKey(1, thread.getID(), watch.getWatchType());
/*  408 */     FACTORY.cacheManager.watchCache.remove(key);
/*      */ 
/*  410 */     return watch;
/*      */   }
/*      */ 
/*      */   public Watch createWatch(User user, Forum forum) {
/*  414 */     DbWatch watch = null;
/*      */ 
/*  416 */     if (getBatchTimer(user) != null) {
/*  417 */       watch = new DbWatch(user.getID(), 0, forum.getID(), 2, true);
/*      */     }
/*  420 */     else if (JiveGlobals.getJiveBooleanProperty("watches.email.enabledByDefault", true) ? !"false".equals(user.getProperty("jiveAutoAddEmailWatch")) : "true".equals(user.getProperty("jiveAutoAddEmailWatch")))
/*      */     {
/*  423 */       watch = new DbWatch(user.getID(), 0, forum.getID(), 1, true);
/*      */     }
/*      */     else
/*      */     {
/*  427 */       watch = new DbWatch(user.getID(), 0, forum.getID(), 0, true);
/*      */     }
/*      */ 
/*  430 */     watch.insertIntoDb();
/*      */ 
/*  432 */     String key = getCacheKey(user.getID(), 0);
/*  433 */     FACTORY.cacheManager.watchCache.remove(key);
/*      */ 
/*  435 */     key = getCacheKey(0, forum.getID(), watch.getWatchType());
/*  436 */     FACTORY.cacheManager.watchCache.remove(key);
/*      */ 
/*  438 */     return watch;
/*      */   }
/*      */ 
/*      */   public Watch createWatch(User user, ForumCategory category) {
/*  442 */     DbWatch watch = null;
/*      */ 
/*  444 */     if (getBatchTimer(user) != null) {
/*  445 */       watch = new DbWatch(user.getID(), 14, category.getID(), 2, true);
/*      */     }
/*  448 */     else if (JiveGlobals.getJiveBooleanProperty("watches.email.enabledByDefault", true) ? !"false".equals(user.getProperty("jiveAutoAddEmailWatch")) : "true".equals(user.getProperty("jiveAutoAddEmailWatch")))
/*      */     {
/*  451 */       watch = new DbWatch(user.getID(), 14, category.getID(), 1, true);
/*      */     }
/*      */     else
/*      */     {
/*  455 */       watch = new DbWatch(user.getID(), 14, category.getID(), 0, true);
/*      */     }
/*      */ 
/*  458 */     watch.insertIntoDb();
/*      */ 
/*  460 */     String key = getCacheKey(user.getID(), 14);
/*  461 */     FACTORY.cacheManager.watchCache.remove(key);
/*      */ 
/*  463 */     key = getCacheKey(14, category.getID(), watch.getWatchType());
/*  464 */     FACTORY.cacheManager.watchCache.remove(key);
/*      */ 
/*  466 */     return watch;
/*      */   }
/*      */ 
/*      */   public int getTotalWatchCount(User user, int objectType) {
/*  470 */     Watch[] watches = getWatchList(user.getID(), objectType);
/*  471 */     return watches.length;
/*      */   }
/*      */ 
/*      */   public Iterator getAllWatches(User user, int objectType) {
/*  475 */     Watch[] watches = getWatchList(user.getID(), objectType);
/*  476 */     LongList ids = new LongList();
/*  477 */     for (int i = 0; i < watches.length; i++) {
/*  478 */       ids.add(watches[i].getObjectID());
/*      */     }
/*  480 */     return new DatabaseObjectIterator(objectType, ids.toArray(), FACTORY);
/*      */   }
/*      */ 
/*      */   public int getWatchCount(User user, Forum forum) {
/*  484 */     Watch[] watches = getWatchList(user.getID(), 1);
/*  485 */     int count = 0;
/*  486 */     for (int i = 0; i < watches.length; i++) {
/*      */       try {
/*  488 */         ForumThread thread = FACTORY.cacheManager.getForumThread(watches[i].getObjectID());
/*  489 */         if (thread.getForum().getID() == forum.getID()) {
/*  490 */           count++;
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (ForumThreadNotFoundException e)
/*      */       {
/*  496 */         FACTORY.cacheManager.watchCache.remove(getCacheKey(user.getID(), 1));
/*      */       }
/*      */     }
/*      */ 
/*  500 */     return count;
/*      */   }
/*      */ 
/*      */   public int getWatchCount(User user, ForumCategory category) {
/*  504 */     Watch[] watches = getWatchList(user.getID(), 0);
/*  505 */     int count = 0;
/*  506 */     for (int i = 0; i < watches.length; i++) {
/*      */       try {
/*  508 */         Forum forum = FACTORY.cacheManager.getForum(watches[i].getObjectID());
/*  509 */         if (forum.getForumCategory().getID() == category.getID()) {
/*  510 */           count++;
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (ForumNotFoundException e)
/*      */       {
/*  516 */         FACTORY.cacheManager.watchCache.remove(getCacheKey(user.getID(), 0));
/*      */       }
/*      */     }
/*      */ 
/*  520 */     return count;
/*      */   }
/*      */ 
/*      */   public Iterator getWatches(User user, Forum forum) {
/*  524 */     Watch[] watches = getWatchList(user.getID(), 1);
/*  525 */     LongList watchList = new LongList();
/*  526 */     for (int i = 0; i < watches.length; i++) {
/*      */       try {
/*  528 */         ForumThread thread = FACTORY.cacheManager.getForumThread(watches[i].getObjectID());
/*  529 */         if (thread.getForum().getID() == forum.getID()) {
/*  530 */           watchList.add(thread.getID());
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (ForumThreadNotFoundException e)
/*      */       {
/*  536 */         FACTORY.cacheManager.watchCache.remove(getCacheKey(user.getID(), 1));
/*      */       }
/*      */     }
/*      */ 
/*  540 */     return new DatabaseObjectIterator(1, watchList.toArray(), FACTORY);
/*      */   }
/*      */ 
/*      */   public Iterator getWatches(User user, ForumCategory category) {
/*  544 */     Watch[] watches = getWatchList(user.getID(), 0);
/*  545 */     LongList watchList = new LongList();
/*  546 */     for (int i = 0; i < watches.length; i++) {
/*      */       try {
/*  548 */         Forum forum = FACTORY.cacheManager.getForum(watches[i].getObjectID());
/*  549 */         if (forum.getForumCategory().getID() == category.getID())
/*  550 */           watchList.add(forum.getID());
/*      */       }
/*      */       catch (ForumNotFoundException e)
/*      */       {
/*  554 */         Log.error(e);
/*      */       }
/*      */     }
/*  557 */     return new DatabaseObjectIterator(0, watchList.toArray(), FACTORY);
/*      */   }
/*      */ 
/*      */   public Watch getWatch(User user, User watchedUser) {
/*  561 */     Watch[] watches = getWatchList(user.getID(), 3);
/*  562 */     for (int i = 0; i < watches.length; i++) {
/*  563 */       if (watches[i].getObjectID() == watchedUser.getID()) {
/*  564 */         return watches[i];
/*      */       }
/*      */     }
/*  567 */     return null;
/*      */   }
/*      */ 
/*      */   public Watch getWatch(User user, ForumThread thread) {
/*  571 */     Watch[] watches = getWatchList(user.getID(), 1);
/*  572 */     for (int i = 0; i < watches.length; i++) {
/*  573 */       if (watches[i].getObjectID() == thread.getID()) {
/*  574 */         return watches[i];
/*      */       }
/*      */     }
/*  577 */     return null;
/*      */   }
/*      */ 
/*      */   public Watch getWatch(User user, Forum forum) {
/*  581 */     Watch[] watches = getWatchList(user.getID(), 0);
/*  582 */     for (int i = 0; i < watches.length; i++) {
/*  583 */       if (watches[i].getObjectID() == forum.getID()) {
/*  584 */         return watches[i];
/*      */       }
/*      */     }
/*  587 */     return null;
/*      */   }
/*      */ 
/*      */   public Watch getWatch(User user, ForumCategory category) {
/*  591 */     Watch[] watches = getWatchList(user.getID(), 14);
/*  592 */     for (int i = 0; i < watches.length; i++) {
/*  593 */       if (watches[i].getObjectID() == category.getID()) {
/*  594 */         return watches[i];
/*      */       }
/*      */     }
/*  597 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean isWatched(User user, ForumCategory category) {
/*  601 */     return getWatch(user, category) != null;
/*      */   }
/*      */ 
/*      */   public boolean isWatched(User user, Forum forum) {
/*  605 */     return getWatch(user, forum) != null;
/*      */   }
/*      */ 
/*      */   public boolean isWatched(User user, ForumThread thread) {
/*  609 */     return getWatch(user, thread) != null;
/*      */   }
/*      */ 
/*      */   public boolean isWatched(User user, User watchedUser) {
/*  613 */     return getWatch(user, watchedUser) != null;
/*      */   }
/*      */ 
/*      */   public void deleteWatch(Watch watch) {
/*  617 */     DbWatch dbWatch = new DbWatch(watch.getUser().getID(), watch.getObjectType(), watch.getObjectID(), watch.getWatchType(), watch.isExpirable());
/*      */ 
/*  619 */     dbWatch.deleteFromDb();
/*      */ 
/*  622 */     if (watch.getWatchType() == 1) {
/*  623 */       FACTORY.cacheManager.watchCache.remove(getCacheKey(watch.getObjectType(), watch.getObjectID(), 1));
/*      */     }
/*  626 */     else if (watch.getWatchType() == 2) {
/*  627 */       FACTORY.cacheManager.watchCache.remove(getCacheKey(watch.getObjectType(), watch.getObjectID(), 2));
/*      */     }
/*      */ 
/*  631 */     FACTORY.cacheManager.watchCache.remove(getCacheKey(watch.getUser().getID(), watch.getObjectType()));
/*      */   }
/*      */ 
/*      */   public void deleteWatches(int objectType, long objectID)
/*      */   {
/*  636 */     Connection con = null;
/*  637 */     PreparedStatement pstmt = null;
/*      */     try {
/*  639 */       con = ConnectionManager.getConnection();
/*  640 */       pstmt = con.prepareStatement("DELETE FROM jiveWatch WHERE objectType=? AND objectID=?");
/*  641 */       pstmt.setInt(1, objectType);
/*  642 */       pstmt.setLong(2, objectID);
/*  643 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (SQLException e) {
/*  646 */       Log.error(e);
/*      */     }
/*      */     finally {
/*  649 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/*  652 */     FACTORY.cacheManager.watchCache.remove(getCacheKey(objectType, objectID, 1));
/*      */   }
/*      */ 
/*      */   public void deleteThreadWatches(long forumID)
/*      */   {
/*  661 */     LongList watches = new LongList();
/*  662 */     Connection con = null;
/*  663 */     PreparedStatement pstmt = null;
/*      */     try {
/*  665 */       con = ConnectionManager.getConnection();
/*  666 */       pstmt = con.prepareStatement("SELECT DISTINCT objectID FROM jiveWatch, jiveThread WHERE jiveThread.forumID=? AND jiveWatch.objectType=1 AND jiveWatch.objectID=jiveThread.threadID");
/*  667 */       pstmt.setLong(1, forumID);
/*  668 */       ResultSet rs = pstmt.executeQuery();
/*  669 */       while (rs.next()) {
/*  670 */         watches.add(rs.getLong(1));
/*      */       }
/*  672 */       rs.close();
/*      */     }
/*      */     catch (SQLException e) {
/*  675 */       Log.error(e);
/*      */     }
/*      */     finally {
/*  678 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/*  681 */     int i = 0; for (int n = watches.size(); i < n; i++)
/*  682 */       deleteWatches(1, watches.get(i));
/*      */   }
/*      */ 
/*      */   public void deleteWatches(User user)
/*      */   {
/*  688 */     Iterator cronTasks = FACTORY.getCronTaskManager().getCronTasks();
/*  689 */     while (cronTasks.hasNext()) {
/*  690 */       CronTask cronTask = (CronTask)cronTasks.next();
/*  691 */       if ((cronTask.getRunnable() instanceof BatchEmailWatchTask)) {
/*  692 */         BatchEmailWatchTask batchTask = (BatchEmailWatchTask)cronTask.getRunnable();
/*  693 */         if (batchTask.getUserID() == user.getID())
/*      */         {
/*  695 */           FACTORY.getCronTaskManager().removeCronTask(cronTask);
/*      */ 
/*  697 */           break;
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  703 */     Connection con = null;
/*  704 */     PreparedStatement pstmt = null;
/*      */     try
/*      */     {
/*  707 */       con = ConnectionManager.getConnection();
/*  708 */       pstmt = con.prepareStatement("DELETE FROM jiveWatch WHERE userID=?");
/*  709 */       pstmt.setLong(1, user.getID());
/*  710 */       pstmt.execute();
/*  711 */       pstmt.close();
/*      */ 
/*  713 */       pstmt = con.prepareStatement("DELETE FROM jiveBatchWatch WHERE userID=?");
/*  714 */       pstmt.setLong(1, user.getID());
/*  715 */       pstmt.execute();
/*      */     }
/*      */     catch (SQLException e) {
/*  718 */       Log.error(e);
/*      */     }
/*      */     finally {
/*  721 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/*  725 */     FACTORY.cacheManager.watchCache.remove(getCacheKey(user.getID(), 1));
/*  726 */     FACTORY.cacheManager.watchCache.remove(getCacheKey(user.getID(), 0));
/*  727 */     FACTORY.cacheManager.watchCache.remove(getCacheKey(user.getID(), 14));
/*  728 */     FACTORY.cacheManager.watchCache.remove(getCacheKey(user.getID(), 3));
/*      */   }
/*      */ 
/*      */   public void moveWatches(int objectType, long sourceObjectID, long destinationObjectID)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void notifyWatchUpdate(final ForumMessage message)
/*      */   {
/*  768 */     if (!JiveGlobals.getJiveBooleanProperty("watches.emailNotifyEnabled", true)) {
/*  769 */       return;
/*      */     }
/*      */ 
/*  773 */     if ("true".equals(message.getUnfilteredProperty("Jive-Created-Message"))) {
/*  774 */       return;
/*      */     }
/*      */ 
/*  779 */     TaskEngine.addTask(0, new Runnable()
/*      */     {
/*      */       private final ForumMessage val$message;
/*      */ 
/*      */       public void run()
/*      */       {
/*  786 */         LongHashMap users = new LongHashMap();
/*  787 */         Long EMPTY_VALUE = new Long(0L);
/*  788 */         long[] watchers = null;
/*      */ 
/*  790 */         ForumThread thread = message.getForumThread();
/*  791 */         Forum forum = thread.getForum();
/*      */ 
/*  796 */         if (!thread.getRootMessage().equals(message)) {
/*  797 */           watchers = DbWatchManager.this.getWatchers(1, thread.getID(), 1);
/*  798 */           LongList watcherList = new LongList();
/*  799 */           for (int i = 0; i < watchers.length; i++) {
/*  800 */             long userID = watchers[i];
/*      */ 
/*  802 */             if (forum.getPermissions(new DbWatchManager.DummyAuthToken(userID)).hasPermission(576460752303424385L))
/*      */             {
/*  806 */               watcherList.add(userID);
/*      */ 
/*  809 */               users.put(userID, EMPTY_VALUE);
/*      */             }
/*      */           }
/*  812 */           watchers = watcherList.toArray();
/*      */ 
/*  814 */           TaskEngine.addTask(0, new EmailWatchUpdateTask(1, message, watchers));
/*      */         }
/*      */ 
/*  819 */         watchers = DbWatchManager.this.getWatchers(0, forum.getID(), 1);
/*  820 */         LongList watcherList = new LongList();
/*  821 */         for (int i = 0; i < watchers.length; i++) {
/*  822 */           long userID = watchers[i];
/*      */ 
/*  824 */           if (!users.containsKey(userID))
/*      */           {
/*  826 */             if (forum.getPermissions(new DbWatchManager.DummyAuthToken(userID)).hasPermission(576460752303424385L))
/*      */             {
/*  830 */               watcherList.add(userID);
/*      */ 
/*  833 */               users.put(userID, EMPTY_VALUE);
/*      */             }
/*      */           }
/*      */         }
/*  837 */         watchers = watcherList.toArray();
/*  838 */         TaskEngine.addTask(0, new EmailWatchUpdateTask(0, message, watchers));
/*      */ 
/*  840 */         watcherList.clear();
/*      */ 
/*  843 */         ForumCategory category = forum.getForumCategory();
/*      */         do {
/*  845 */           watchers = DbWatchManager.this.getWatchers(14, category.getID(), 1);
/*  846 */           for (int i = 0; i < watchers.length; i++) {
/*  847 */             long userID = watchers[i];
/*      */ 
/*  849 */             if (!users.containsKey(userID))
/*      */             {
/*  851 */               if (forum.getPermissions(new DbWatchManager.DummyAuthToken(userID)).hasPermission(576460752303424385L))
/*      */               {
/*  855 */                 watcherList.add(userID);
/*      */ 
/*  858 */                 users.put(userID, EMPTY_VALUE);
/*      */               }
/*      */             }
/*      */           }
/*  862 */           watchers = watcherList.toArray();
/*  863 */           TaskEngine.addTask(0, new EmailWatchUpdateTask(14, message, watchers));
/*      */ 
/*  865 */           watcherList.clear();
/*      */         }
/*  867 */         while ((category = category.getParentCategory()) != null);
/*      */ 
/*  870 */         User user = message.getUser();
/*  871 */         if (user != null) {
/*  872 */           watchers = DbWatchManager.this.getWatchers(3, user.getID(), 1);
/*  873 */           for (int i = 0; i < watchers.length; i++) {
/*  874 */             long userID = watchers[i];
/*      */ 
/*  876 */             if (!users.containsKey(userID))
/*      */             {
/*  878 */               if (forum.getPermissions(new DbWatchManager.DummyAuthToken(userID)).hasPermission(576460752303424385L))
/*      */               {
/*  882 */                 watcherList.add(userID);
/*      */ 
/*  885 */                 users.put(userID, EMPTY_VALUE);
/*      */               }
/*      */             }
/*      */           }
/*  889 */           watchers = watcherList.toArray();
/*  890 */           TaskEngine.addTask(0, new EmailWatchUpdateTask(3, message, watchers));
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private long[] getWatchers(int objectType, long objectID, int watchType)
/*      */   {
/*  907 */     long[] users = null;
/*  908 */     String key = getCacheKey(objectType, objectID, watchType);
/*      */ 
/*  910 */     synchronized (key)
/*      */     {
/*  912 */       users = (long[])FACTORY.cacheManager.watchCache.get(key);
/*  913 */       if (users == null) {
/*  914 */         Connection con = null;
/*  915 */         PreparedStatement pstmt = null;
/*  916 */         LongList userList = new LongList();
/*      */         try {
/*  918 */           con = ConnectionManager.getConnection();
/*  919 */           pstmt = con.prepareStatement("SELECT userID FROM jiveWatch WHERE objectType=? AND objectID=? AND watchType=?");
/*  920 */           pstmt.setInt(1, objectType);
/*  921 */           pstmt.setLong(2, objectID);
/*  922 */           pstmt.setInt(3, watchType);
/*  923 */           ResultSet rs = pstmt.executeQuery();
/*  924 */           while (rs.next()) {
/*  925 */             userList.add(rs.getLong(1));
/*      */           }
/*  927 */           rs.close();
/*  928 */           users = userList.toArray();
/*      */ 
/*  930 */           FACTORY.cacheManager.watchCache.put(key, users);
/*      */         }
/*      */         catch (SQLException e) {
/*  933 */           Log.error(e);
/*      */         }
/*      */         finally {
/*  936 */           ConnectionManager.closeConnection(pstmt, con);
/*      */         }
/*      */       }
/*      */     }
/*  940 */     return users;
/*      */   }
/*      */ 
/*      */   static String getCacheKey(int objectType, long objectID, int watchType)
/*      */   {
/*  952 */     return (objectType + "," + objectID + "," + watchType).intern();
/*      */   }
/*      */ 
/*      */   static String getCacheKey(long userID, int objectType)
/*      */   {
/*  964 */     String key = null;
/*  965 */     switch (objectType) {
/*      */     case 1:
/*  967 */       key = "t-" + userID;
/*  968 */       break;
/*      */     case 0:
/*  970 */       key = "f-" + userID;
/*  971 */       break;
/*      */     case 14:
/*  973 */       key = "c-" + userID;
/*  974 */       break;
/*      */     case 3:
/*  976 */       key = "u-" + userID;
/*  977 */       break;
/*      */     default:
/*  979 */       throw new IllegalArgumentException("Object type invalid.");
/*      */     }
/*  981 */     return key.intern();
/*      */   }
/*      */ 
/*      */   private Watch[] getWatchList(long userID, int objectType)
/*      */   {
/*  992 */     Watch[] watchList = null;
/*  993 */     String key = getCacheKey(userID, objectType);
/*      */ 
/*  995 */     watchList = (Watch[])FACTORY.cacheManager.watchCache.get(key);
/*      */ 
/*  997 */     if (watchList == null) {
/*  998 */       List watches = new ArrayList();
/*  999 */       Connection con = null;
/* 1000 */       PreparedStatement pstmt = null;
/*      */       try {
/* 1002 */         con = ConnectionManager.getConnection();
/* 1003 */         pstmt = con.prepareStatement("SELECT objectID, watchType, expirable FROM jiveWatch WHERE userID=? AND objectType=? ORDER BY objectID DESC");
/* 1004 */         pstmt.setLong(1, userID);
/* 1005 */         pstmt.setInt(2, objectType);
/* 1006 */         ResultSet rs = pstmt.executeQuery();
/* 1007 */         while (rs.next()) {
/* 1008 */           long objectID = rs.getLong(1);
/* 1009 */           int watchType = rs.getInt(2);
/* 1010 */           boolean expirable = rs.getInt(3) == 1;
/* 1011 */           DbWatch dbWatch = new DbWatch(userID, objectType, objectID, watchType, expirable);
/*      */ 
/* 1013 */           watches.add(dbWatch);
/*      */         }
/* 1015 */         rs.close();
/*      */       }
/*      */       catch (SQLException e) {
/* 1018 */         Log.error(e);
/*      */       }
/*      */       finally {
/* 1021 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/* 1023 */       watchList = (Watch[])watches.toArray(new Watch[watches.size()]);
/*      */ 
/* 1025 */       FACTORY.cacheManager.watchCache.put(key, watchList);
/*      */     }
/*      */ 
/* 1028 */     if (watchList == null) {
/* 1029 */       return EMPTY_WATCH_LIST;
/*      */     }
/*      */ 
/* 1035 */     List watches = new ArrayList();
/* 1036 */     AuthToken authToken = new DummyAuthToken(userID);
/* 1037 */     for (int i = 0; i < watchList.length; i++) {
/*      */       try {
/* 1039 */         long objectID = watchList[i].getObjectID();
/* 1040 */         switch (objectType) {
/*      */         case 14:
/* 1042 */           ForumCategory category = FACTORY.cacheManager.getForumCategory(objectID);
/*      */ 
/* 1044 */           if (category.getPermissions(authToken).hasPermission(576460752303424129L)) {
/*      */             break;
/*      */           }
/* 1047 */           break;
/*      */         case 0:
/* 1051 */           Forum forum = FACTORY.cacheManager.getForum(objectID);
/* 1052 */           if (forum.getPermissions(authToken).hasPermission(576460752303424385L))
/*      */           {
/*      */             break;
/*      */           }
/* 1056 */           break;
/*      */         case 1:
/* 1060 */           ForumThread thread = FACTORY.cacheManager.getForumThread(objectID);
/* 1061 */           if (thread.getForum().getPermissions(authToken).hasPermission(576460752303424385L))
/*      */           {
/*      */             break;
/*      */           }
/* 1065 */           break;
/*      */         case 3:
/* 1069 */           FACTORY.userManager.getUser(objectID);
/* 1070 */           break;
/*      */         default:
/* 1072 */           throw new IllegalArgumentException("Invalid object type for watches: " + objectType);
/*      */         }
/*      */ 
/* 1076 */         watches.add(watchList[i]);
/*      */       }
/*      */       catch (IllegalArgumentException ie) {
/* 1079 */         Log.error(ie);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 1083 */         FACTORY.cacheManager.watchCache.remove(getCacheKey(userID, objectType));
/*      */       }
/*      */     }
/* 1086 */     return (Watch[])watches.toArray(new Watch[watches.size()]);
/*      */   }
/*      */ 
/*      */   private static class DummyAuthToken
/*      */     implements AuthToken
/*      */   {
/*      */     private long userID;
/*      */ 
/*      */     public DummyAuthToken(long userID)
/*      */     {
/* 1175 */       this.userID = userID;
/*      */     }
/*      */ 
/*      */     public long getUserID() {
/* 1179 */       return this.userID;
/*      */     }
/*      */ 
/*      */     public boolean isAnonymous() {
/* 1183 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */   class DeleteWatchesTask
/*      */     implements Runnable
/*      */   {
/*      */     DeleteWatchesTask()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/* 1101 */       long now = System.currentTimeMillis();
/* 1102 */       long deleteDays = 86400000L * DbWatchManager.this.getDeleteDays();
/*      */ 
/* 1105 */       Date oldestDate = new Date(now - deleteDays);
/*      */ 
/* 1107 */       Connection con = null;
/* 1108 */       PreparedStatement pstmt = null;
/*      */       try {
/* 1110 */         con = ConnectionManager.getConnection();
/* 1111 */         pstmt = con.prepareStatement("SELECT jiveWatch.userID, objectType, objectID, watchType FROM jiveWatch, jiveCategory WHERE jiveWatch.objectID=jiveCategory.categoryID AND jiveWatch.objectType=14 AND jiveCategory.modificationDate < ? AND jiveWatch.expirable=1");
/* 1112 */         pstmt.setLong(1, oldestDate.getTime());
/* 1113 */         ResultSet rs = pstmt.executeQuery();
/* 1114 */         while (rs.next()) {
/* 1115 */           long userID = rs.getLong(1);
/* 1116 */           int objectType = rs.getInt(2);
/* 1117 */           long objectID = rs.getLong(3);
/* 1118 */           int watchType = rs.getInt(4);
/* 1119 */           boolean expirable = true;
/* 1120 */           DbWatch dbWatch = new DbWatch(userID, objectType, objectID, watchType, expirable);
/* 1121 */           dbWatch.deleteFromDb();
/*      */         }
/* 1123 */         rs.close();
/* 1124 */         pstmt.close();
/*      */ 
/* 1126 */         pstmt = con.prepareStatement("SELECT jiveWatch.userID, objectType, objectID, watchType FROM jiveWatch, jiveForum WHERE jiveWatch.objectID=jiveForum.forumID AND jiveWatch.objectType=0 AND jiveForum.modificationDate < ? AND jiveWatch.expirable=1");
/* 1127 */         pstmt.setLong(1, oldestDate.getTime());
/* 1128 */         rs = pstmt.executeQuery();
/* 1129 */         while (rs.next()) {
/* 1130 */           long userID = rs.getLong(1);
/* 1131 */           int objectType = rs.getInt(2);
/* 1132 */           long objectID = rs.getLong(3);
/* 1133 */           int watchType = rs.getInt(4);
/* 1134 */           boolean expirable = true;
/* 1135 */           DbWatch dbWatch = new DbWatch(userID, objectType, objectID, watchType, expirable);
/* 1136 */           dbWatch.deleteFromDb();
/*      */         }
/* 1138 */         rs.close();
/* 1139 */         pstmt.close();
/*      */ 
/* 1141 */         pstmt = con.prepareStatement("SELECT jiveWatch.userID, objectType, objectID, watchType FROM jiveWatch, jiveThread WHERE jiveWatch.objectID=jiveThread.threadID AND jiveWatch.objectType=1 AND jiveThread.modificationDate < ? AND jiveWatch.expirable=1");
/* 1142 */         pstmt.setLong(1, oldestDate.getTime());
/* 1143 */         rs = pstmt.executeQuery();
/* 1144 */         while (rs.next()) {
/* 1145 */           long userID = rs.getLong(1);
/* 1146 */           int objectType = rs.getInt(2);
/* 1147 */           long objectID = rs.getLong(3);
/* 1148 */           int watchType = rs.getInt(4);
/* 1149 */           boolean expirable = true;
/* 1150 */           DbWatch dbWatch = new DbWatch(userID, objectType, objectID, watchType, expirable);
/* 1151 */           dbWatch.deleteFromDb();
/*      */         }
/* 1153 */         rs.close();
/*      */       }
/*      */       catch (SQLException e) {
/* 1156 */         Log.error(e);
/*      */       }
/*      */       finally {
/* 1159 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*      */ 
/* 1163 */       DbWatchManager.FACTORY.cacheManager.watchCache.clear();
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbWatchManager
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.gateway;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.forum.event.MessageEvent;
/*     */ import com.jivesoftware.forum.event.MessageListener;
/*     */ import com.jivesoftware.forum.event.ThreadEvent;
/*     */ import com.jivesoftware.forum.event.ThreadListener;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class GatewayListener
/*     */   implements ThreadListener, MessageListener
/*     */ {
/*  33 */   DbForumFactory dbFactory = DbForumFactory.getInstance();
/*     */ 
/*     */   public void threadAdded(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadDeleted(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadMoved(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadModerationModified(ThreadEvent event)
/*     */   {
/*  49 */     ForumThread thread = event.getThread();
/*  50 */     Forum forum = null;
/*     */     try {
/*  52 */       forum = this.dbFactory.getForum(thread.getForum().getID());
/*     */     }
/*     */     catch (ForumNotFoundException e) {
/*  55 */       Log.error(e);
/*  56 */       return;
/*     */     }
/*     */ 
/*  60 */     int oldValue = ((Integer)event.getParams().get("oldModerationValue")).intValue();
/*  61 */     int newValue = thread.getModerationValue();
/*     */ 
/*  64 */     if ((oldValue < 1) && (newValue >= 1))
/*     */     {
/*     */       try
/*     */       {
/*  68 */         GatewayManager.exportData(forum, thread.getRootMessage());
/*     */       }
/*     */       catch (Exception e) {
/*  71 */         Log.error(e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void threadRated(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageAdded(MessageEvent event) {
/*  81 */     ForumMessage message = event.getMessage();
/*     */ 
/*  84 */     boolean isRootMessage = message.equals(message.getForumThread().getRootMessage());
/*  85 */     Forum forum = null;
/*     */     try {
/*  87 */       forum = this.dbFactory.getForum(message.getForumThread().getForum().getID());
/*     */     }
/*     */     catch (ForumNotFoundException e) {
/*  90 */       Log.error(e);
/*     */       return;
/*     */     }
/*     */     int modValue;
/*     */     int modValue;
/*  95 */     if (isRootMessage) {
/*  96 */       modValue = message.getForumThread().getModerationValue();
/*     */     }
/*     */     else {
/*  99 */       modValue = message.getModerationValue();
/*     */     }
/*     */ 
/* 103 */     if (modValue >= 1)
/*     */       try {
/* 105 */         GatewayManager.exportData(forum, message);
/*     */       }
/*     */       catch (Exception e) {
/* 108 */         Log.error(e);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void messageDeleted(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageModified(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageMoved(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageModerationModified(MessageEvent event)
/*     */   {
/* 127 */     ForumMessage message = event.getMessage();
/*     */ 
/* 130 */     boolean isRootMessage = message.equals(message.getForumThread().getRootMessage());
/* 131 */     if (isRootMessage) {
/* 132 */       return;
/*     */     }
/* 134 */     Forum forum = null;
/*     */     try {
/* 136 */       forum = this.dbFactory.getForum(message.getForumThread().getForum().getID());
/*     */     }
/*     */     catch (ForumNotFoundException e) {
/* 139 */       Log.error(e);
/* 140 */       return;
/*     */     }
/*     */ 
/* 144 */     int oldValue = ((Integer)event.getParams().get("oldModerationValue")).intValue();
/* 145 */     int newValue = message.getModerationValue();
/*     */ 
/* 148 */     if ((oldValue < 1) && (newValue >= 1))
/*     */     {
/*     */       try
/*     */       {
/* 152 */         GatewayManager.exportData(forum, message);
/*     */       }
/*     */       catch (Exception e) {
/* 155 */         Log.error(e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void messageRated(MessageEvent event)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.GatewayListener
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.Poll;
/*     */ import com.jivesoftware.base.PollException;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PollProxy
/*     */   implements Poll
/*     */ {
/*     */   private Poll poll;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public PollProxy(Poll poll, Permissions permissions)
/*     */   {
/*  43 */     this.poll = poll;
/*  44 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public User getUser() {
/*  48 */     return this.poll.getUser();
/*     */   }
/*     */ 
/*     */   public int getObjectType() {
/*  52 */     return this.poll.getObjectType();
/*     */   }
/*     */ 
/*     */   public long getObjectID() {
/*  56 */     return this.poll.getObjectID();
/*     */   }
/*     */ 
/*     */   public long getID() {
/*  60 */     return this.poll.getID();
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  64 */     return this.poll.getName();
/*     */   }
/*     */ 
/*     */   public void setName(String name) throws UnauthorizedException {
/*  68 */     if (this.permissions.hasPermission(576460752303423632L))
/*     */     {
/*  71 */       this.poll.setName(name);
/*     */     }
/*     */     else
/*  74 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  79 */     return this.poll.getDescription();
/*     */   }
/*     */ 
/*     */   public void setDescription(String description) throws UnauthorizedException {
/*  83 */     if (this.permissions.hasPermission(576460752303423632L))
/*     */     {
/*  86 */       this.poll.setDescription(description);
/*     */     }
/*     */     else
/*  89 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean isModeEnabled(long mode)
/*     */   {
/*  94 */     return this.poll.isModeEnabled(mode);
/*     */   }
/*     */ 
/*     */   public void setMode(long mode, boolean enabled) throws UnauthorizedException {
/*  98 */     if (this.permissions.hasPermission(576460752303423632L))
/*     */     {
/* 101 */       this.poll.setMode(mode, enabled);
/*     */     }
/*     */     else
/* 104 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Date getCreationDate()
/*     */   {
/* 109 */     return this.poll.getCreationDate();
/*     */   }
/*     */ 
/*     */   public Date getModificationDate() {
/* 113 */     return this.poll.getModificationDate();
/*     */   }
/*     */ 
/*     */   public Date getStartDate() {
/* 117 */     return this.poll.getStartDate();
/*     */   }
/*     */ 
/*     */   public void setStartDate(Date startDate) throws UnauthorizedException {
/* 121 */     if (this.permissions.hasPermission(576460752303423632L))
/*     */     {
/* 124 */       this.poll.setStartDate(startDate);
/*     */     }
/*     */     else
/* 127 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Date getEndDate()
/*     */   {
/* 132 */     return this.poll.getEndDate();
/*     */   }
/*     */ 
/*     */   public void setEndDate(Date endDate) throws UnauthorizedException {
/* 136 */     if (this.permissions.hasPermission(576460752303423632L))
/*     */     {
/* 139 */       this.poll.setEndDate(endDate);
/*     */     }
/*     */     else
/* 142 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Date getExpirationDate()
/*     */   {
/* 147 */     return this.poll.getExpirationDate();
/*     */   }
/*     */ 
/*     */   public void setExpirationDate(Date expireDate) throws UnauthorizedException {
/* 151 */     if (this.permissions.hasPermission(576460752303423632L))
/*     */     {
/* 154 */       this.poll.setExpirationDate(expireDate);
/*     */     }
/*     */     else
/* 157 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getOptionCount()
/*     */   {
/* 162 */     return this.poll.getOptionCount();
/*     */   }
/*     */ 
/*     */   public String getOption(int index) {
/* 166 */     return this.poll.getOption(index);
/*     */   }
/*     */ 
/*     */   public void setOption(int index, String value) throws UnauthorizedException {
/* 170 */     if (this.permissions.hasPermission(576460752303423632L))
/*     */     {
/* 173 */       this.poll.setOption(index, value);
/*     */     }
/*     */     else
/* 176 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void setOptionIndex(int currentIndex, int newIndex) throws UnauthorizedException
/*     */   {
/* 181 */     if (this.permissions.hasPermission(576460752303423632L))
/*     */     {
/* 184 */       this.poll.setOptionIndex(currentIndex, newIndex);
/*     */     }
/*     */     else
/* 187 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void addOption(String value) throws UnauthorizedException
/*     */   {
/* 192 */     if (this.permissions.hasPermission(576460752303423632L))
/*     */     {
/* 195 */       this.poll.addOption(value);
/*     */     }
/*     */     else
/* 198 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteOption(int index) throws UnauthorizedException
/*     */   {
/* 203 */     if (this.permissions.hasPermission(576460752303423632L))
/*     */     {
/* 206 */       this.poll.deleteOption(index);
/*     */     }
/*     */     else
/* 209 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getVoteCount() throws PollException
/*     */   {
/* 214 */     return this.poll.getVoteCount();
/*     */   }
/*     */ 
/*     */   public int getVoteCount(int optionIndex) throws PollException {
/* 218 */     return this.poll.getVoteCount(optionIndex);
/*     */   }
/*     */ 
/*     */   public int getUserCount()
/*     */     throws PollException
/*     */   {
/* 225 */     return this.poll.getUserCount();
/*     */   }
/*     */ 
/*     */   public int getUserVoteCount() throws PollException {
/* 229 */     return this.poll.getUserVoteCount();
/*     */   }
/*     */ 
/*     */   public int getUserVoteCount(int optionIndex) throws PollException {
/* 233 */     return this.poll.getUserVoteCount(optionIndex);
/*     */   }
/*     */ 
/*     */   public int getAnonymousVoteCount() throws PollException {
/* 237 */     return this.poll.getAnonymousVoteCount();
/*     */   }
/*     */ 
/*     */   public int getAnonymousVoteCount(int index) throws PollException {
/* 241 */     return this.poll.getAnonymousVoteCount(index);
/*     */   }
/*     */ 
/*     */   public Iterator getUserVotes() throws PollException {
/* 245 */     return this.poll.getUserVotes();
/*     */   }
/*     */ 
/*     */   public Iterator getUserVotes(int optionIndex) throws PollException {
/* 249 */     return this.poll.getUserVotes(optionIndex);
/*     */   }
/*     */ 
/*     */   public Iterator getAnonymousVotes() throws PollException {
/* 253 */     return this.poll.getAnonymousVotes();
/*     */   }
/*     */ 
/*     */   public Iterator getAnonymousVotes(int optionIndex) throws PollException {
/* 257 */     return this.poll.getAnonymousVotes(optionIndex);
/*     */   }
/*     */ 
/*     */   public boolean hasUserVoted(User user) {
/* 261 */     return this.poll.hasUserVoted(user);
/*     */   }
/*     */ 
/*     */   public boolean hasAnonymousVoted(String uniqueID) {
/* 265 */     return this.poll.hasAnonymousVoted(uniqueID);
/*     */   }
/*     */ 
/*     */   public void addUserVote(int optionIndex, User user)
/*     */     throws PollException, UnauthorizedException
/*     */   {
/* 271 */     if (this.permissions.hasPermission(576460752303424656L))
/*     */     {
/* 274 */       this.poll.addUserVote(optionIndex, user);
/*     */     }
/*     */     else
/* 277 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void addAnonymousVote(int optionIndex, String uniqueID)
/*     */     throws PollException, UnauthorizedException
/*     */   {
/* 284 */     if (this.permissions.hasPermission(576460752303424656L))
/*     */     {
/* 287 */       this.poll.addAnonymousVote(optionIndex, uniqueID);
/*     */     }
/*     */     else
/* 290 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void changeUserVote(int prevOptionIndex, int newOptionIndex, User user)
/*     */     throws PollException, UnauthorizedException
/*     */   {
/* 297 */     if (this.permissions.hasPermission(576460752303424656L))
/*     */     {
/* 300 */       this.poll.changeUserVote(prevOptionIndex, newOptionIndex, user);
/*     */     }
/*     */     else
/* 303 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void changeAnonymousVote(int prevOptionIndex, int newOptionIndex, String uniqueID)
/*     */     throws PollException, UnauthorizedException
/*     */   {
/* 310 */     if (this.permissions.hasPermission(576460752303424656L))
/*     */     {
/* 313 */       this.poll.changeAnonymousVote(prevOptionIndex, newOptionIndex, uniqueID);
/*     */     }
/*     */     else
/* 316 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void removeUserVote(int prevOptionIndex, User user)
/*     */     throws PollException, UnauthorizedException
/*     */   {
/* 323 */     if (this.permissions.hasPermission(576460752303424656L))
/*     */     {
/* 326 */       this.poll.removeUserVote(prevOptionIndex, user);
/*     */     }
/*     */     else
/* 329 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void removeAnonymousVote(int prevOptionIndex, String uniqueID)
/*     */     throws PollException, UnauthorizedException
/*     */   {
/* 336 */     if (this.permissions.hasPermission(576460752303424656L))
/*     */     {
/* 339 */       this.poll.removeAnonymousVote(prevOptionIndex, uniqueID);
/*     */     }
/*     */     else
/* 342 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public List getUserVotes(User user)
/*     */   {
/* 347 */     return this.poll.getUserVotes(user);
/*     */   }
/*     */ 
/*     */   public List getAnonymousVotes(String uniqueID) {
/* 351 */     return this.poll.getAnonymousVotes(uniqueID);
/*     */   }
/*     */ 
/*     */   public boolean isAuthorized(long permissionType) {
/* 355 */     return this.permissions.hasPermission(permissionType);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 359 */     return this.poll.toString();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.PollProxy
 * JD-Core Version:    0.6.2
 */
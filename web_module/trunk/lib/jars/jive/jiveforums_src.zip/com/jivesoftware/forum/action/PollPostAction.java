/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.Poll;
/*     */ import com.jivesoftware.base.PollManager;
/*     */ import com.jivesoftware.base.PollManagerFactory;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.action.JiveObjectLoader;
/*     */ import com.jivesoftware.base.action.util.DateUtils;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import com.opensymphony.xwork.util.XWorkList;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PollPostAction extends ForumActionSupport
/*     */   implements Validateable, JiveObjectLoader
/*     */ {
/*     */   public static final String ACTIVE_NOW = "activenow";
/*     */   public static final String ACTIVE_LATER = "activelater";
/*     */   public static final String EXPIRES_NEVER = "expiresnever";
/*     */   public static final String EXPIRES_RELATIVE = "expiresrelative";
/*     */   public static final String EXPIRES_LATER = "expireslater";
/*  46 */   private long categoryID = 0L;
/*  47 */   private long forumID = 0L;
/*  48 */   private int objectType = -1;
/*  49 */   private long objectID = 0L;
/*     */   private String name;
/*     */   private String description;
/*     */   private String activeMode;
/*     */   private String expiresMode;
/*  54 */   private int expiresDays = -1;
/*     */   private String activeDate;
/*     */   private String expiresDate;
/*  57 */   private List options = new XWorkList(PollOption.class);
/*     */   private boolean cancel;
/*     */   private Poll poll;
/*     */   private ForumCategory category;
/*     */   private Forum forum;
/*     */ 
/*     */   public long getCategoryID()
/*     */   {
/*  68 */     return this.categoryID;
/*     */   }
/*     */ 
/*     */   public void setCategoryID(long categoryID)
/*     */   {
/*  75 */     this.categoryID = categoryID;
/*     */   }
/*     */ 
/*     */   public long getForumID()
/*     */   {
/*  82 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID)
/*     */   {
/*  89 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public int getObjectType()
/*     */   {
/*  96 */     return this.objectType;
/*     */   }
/*     */ 
/*     */   public void setObjectType(int objectType)
/*     */   {
/* 103 */     this.objectType = objectType;
/*     */   }
/*     */ 
/*     */   public long getObjectID()
/*     */   {
/* 110 */     return this.objectID;
/*     */   }
/*     */ 
/*     */   public void setObjectID(long objectID)
/*     */   {
/* 117 */     this.objectID = objectID;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 124 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 131 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 138 */     return this.description;
/*     */   }
/*     */ 
/*     */   public void setDescription(String description)
/*     */   {
/* 145 */     this.description = description;
/*     */   }
/*     */ 
/*     */   public String getActiveMode()
/*     */   {
/* 152 */     return this.activeMode;
/*     */   }
/*     */ 
/*     */   public void setActiveMode(String activeMode)
/*     */   {
/* 159 */     this.activeMode = activeMode;
/*     */   }
/*     */ 
/*     */   public String getExpiresMode()
/*     */   {
/* 167 */     return this.expiresMode;
/*     */   }
/*     */ 
/*     */   public void setExpiresMode(String expiresMode)
/*     */   {
/* 175 */     this.expiresMode = expiresMode;
/*     */   }
/*     */ 
/*     */   public int getExpiresDays()
/*     */   {
/* 182 */     return this.expiresDays;
/*     */   }
/*     */ 
/*     */   public void setExpiresDays(int expiresDays)
/*     */   {
/* 189 */     this.expiresDays = expiresDays;
/*     */   }
/*     */ 
/*     */   public String getActiveDate()
/*     */   {
/* 197 */     return this.activeDate;
/*     */   }
/*     */ 
/*     */   public void setActiveDate(String activeDate)
/*     */   {
/* 205 */     this.activeDate = activeDate;
/*     */   }
/*     */ 
/*     */   public String getExpiresDate()
/*     */   {
/* 213 */     return this.expiresDate;
/*     */   }
/*     */ 
/*     */   public void setExpiresDate(String expiresDate)
/*     */   {
/* 221 */     this.expiresDate = expiresDate;
/*     */   }
/*     */ 
/*     */   public List getOptions()
/*     */   {
/* 228 */     return this.options;
/*     */   }
/*     */ 
/*     */   public void setOptions(List options)
/*     */   {
/* 235 */     this.options = options;
/*     */   }
/*     */ 
/*     */   public String isCancel()
/*     */   {
/* 242 */     return String.valueOf(this.cancel);
/*     */   }
/*     */ 
/*     */   public void setCancel(String cancel)
/*     */   {
/* 249 */     this.cancel = true;
/*     */   }
/*     */ 
/*     */   public ForumCategory getCategory()
/*     */   {
/* 257 */     return this.category;
/*     */   }
/*     */ 
/*     */   public void setCategory(ForumCategory category)
/*     */   {
/* 264 */     this.category = category;
/*     */   }
/*     */ 
/*     */   public Forum getForum()
/*     */   {
/* 272 */     return this.forum;
/*     */   }
/*     */ 
/*     */   protected void setForum(Forum forum)
/*     */   {
/* 279 */     this.forum = forum;
/*     */   }
/*     */ 
/*     */   public Poll getPoll()
/*     */   {
/* 286 */     return this.poll;
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */     throws Exception
/*     */   {
/* 301 */     setActiveMode("activenow");
/* 302 */     setExpiresMode("expiresnever");
/*     */ 
/* 304 */     if ((this.forum == null) && (this.category == null)) {
/* 305 */       if ((!isSystemAdmin()) && (!getForumFactory().isAuthorized(16L))) {
/* 306 */         return "unauthorized";
/*     */       }
/*     */     }
/* 309 */     else if ((this.forum != null) && (this.category == null)) {
/* 310 */       if (!getCanCreatePoll(this.forum)) {
/* 311 */         return "unauthorized";
/*     */       }
/*     */     }
/* 314 */     else if ((this.forum == null) && (this.category != null) && 
/* 315 */       (!getCanCreatePoll(this.category))) {
/* 316 */       return "unauthorized";
/*     */     }
/*     */ 
/* 320 */     return "input";
/*     */   }
/*     */ 
/*     */   public void validate() {
/* 324 */     if (this.cancel) {
/* 325 */       return;
/*     */     }
/* 327 */     if (this.name == null) {
/* 328 */       addFieldError("name", "");
/*     */     }
/* 330 */     if ((!"activenow".equals(this.activeMode)) && (!"activelater".equals(this.activeMode))) {
/* 331 */       addFieldError("activeMode", "");
/*     */     }
/* 333 */     if (("activelater".equals(this.activeMode)) && (this.activeDate == null)) {
/* 334 */       addFieldError("activeDate", "");
/*     */     }
/* 336 */     if ((!"expiresnever".equals(this.expiresMode)) && (!"expiresrelative".equals(this.expiresMode)) && (!"expireslater".equals(this.expiresMode)))
/*     */     {
/* 339 */       addFieldError("expiresMode", "");
/*     */     }
/* 341 */     if (("expiresrelative".equals(this.expiresMode)) && (this.expiresDays < 1)) {
/* 342 */       addFieldError("expiresDays", "");
/*     */     }
/* 344 */     if (("expireslater".equals(this.expiresMode)) && (this.expiresDate == null)) {
/* 345 */       addFieldError("expiresDate", "");
/*     */     }
/* 347 */     if ((this.activeDate != null) || (this.expiresDate != null)) {
/* 348 */       SimpleDateFormat formatter = new SimpleDateFormat(DateUtils.getDatePattern());
/* 349 */       Date now = null;
/*     */       try {
/* 351 */         now = formatter.parse(formatter.format(new Date()));
/*     */       } catch (Exception ignored) {
/*     */       }
/* 354 */       Date actDate = null;
/* 355 */       if (this.activeDate != null) {
/*     */         try {
/* 357 */           actDate = formatter.parse(this.activeDate);
/* 358 */           if (actDate.before(now))
/* 359 */             addFieldError("activeDate", "");
/*     */         }
/*     */         catch (ParseException e)
/*     */         {
/* 363 */           addFieldError("activeDate", "");
/*     */         }
/*     */       }
/* 366 */       if (this.expiresDate != null) {
/*     */         try {
/* 368 */           Date date = formatter.parse(this.expiresDate);
/* 369 */           if ((date.before(now)) || ((actDate != null) && (date.getTime() <= actDate.getTime())))
/* 370 */             addFieldError("expiresDate", "");
/*     */         }
/*     */         catch (ParseException e)
/*     */         {
/* 374 */           addFieldError("expiresDate", "");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 379 */     int optionCount = 0;
/* 380 */     int i = 0; for (int n = this.options.size(); i < n; i++) {
/* 381 */       PollOption option = (PollOption)this.options.get(i);
/* 382 */       if ((option != null) && (!"".equals(option))) {
/* 383 */         optionCount++;
/*     */       }
/*     */     }
/* 386 */     if (optionCount < 2)
/* 387 */       addFieldError("options", "");
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */     throws Exception
/*     */   {
/* 404 */     if (this.cancel) {
/* 405 */       if ((this.forum == null) && (this.category != null)) {
/* 406 */         return "cancel-category";
/*     */       }
/* 408 */       if ((this.forum != null) && (this.category == null)) {
/* 409 */         return "cancel-forum";
/*     */       }
/*     */ 
/* 412 */       return "cancel";
/*     */     }
/*     */ 
/* 416 */     if ((this.forum == null) && (this.category == null)) {
/* 417 */       if ((!isSystemAdmin()) && (!getForumFactory().isAuthorized(16L))) {
/* 418 */         return "unauthorized";
/*     */       }
/*     */     }
/* 421 */     else if ((this.forum != null) && (this.category == null)) {
/* 422 */       if (!getCanCreatePoll(this.forum)) {
/* 423 */         return "unauthorized";
/*     */       }
/*     */     }
/* 426 */     else if ((this.forum == null) && (this.category != null) && 
/* 427 */       (!getCanCreatePoll(this.category))) {
/* 428 */       return "unauthorized";
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 434 */       PollManager manager = PollManagerFactory.getInstance();
/* 435 */       if ((this.forum != null) && (this.category == null))
/*     */       {
/* 437 */         this.poll = manager.createPoll(0, getForumID(), getPageUser(), getName());
/*     */       }
/* 439 */       else if ((this.forum == null) && (this.category != null))
/*     */       {
/* 441 */         this.poll = manager.createPoll(14, getCategoryID(), getPageUser(), getName());
/*     */       }
/*     */ 
/* 444 */       if (getDescription() != null) {
/* 445 */         this.poll.setDescription(getDescription());
/*     */       }
/*     */ 
/* 448 */       for (int i = 0; i < this.options.size(); i++) {
/* 449 */         PollOption option = (PollOption)this.options.get(i);
/* 450 */         if ((option != null) && (option.validate()))
/* 451 */           this.poll.addOption(option.getOption());
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 456 */       return "unauthorized";
/*     */     }
/*     */ 
/* 459 */     if ("activelater".equals(this.activeMode)) {
/* 460 */       SimpleDateFormat formatter = new SimpleDateFormat(DateUtils.getDatePattern());
/*     */       try {
/* 462 */         Date date = formatter.parse(this.activeDate);
/* 463 */         this.poll.setStartDate(date);
/*     */       } catch (Exception ignored) {
/*     */       }
/*     */     }
/* 467 */     if ("expiresrelative".equals(this.expiresMode)) {
/* 468 */       Calendar cal = Calendar.getInstance();
/* 469 */       cal.add(6, this.expiresDays);
/* 470 */       this.poll.setEndDate(cal.getTime());
/*     */     }
/* 472 */     else if (("expireslater".equals(this.expiresMode)) && (this.expiresDate != null)) {
/*     */       try {
/* 474 */         SimpleDateFormat formatter = new SimpleDateFormat(DateUtils.getDatePattern());
/* 475 */         Date date = formatter.parse(this.expiresDate);
/* 476 */         this.poll.setEndDate(date);
/*     */       } catch (Exception ignored) {
/*     */       }
/*     */     }
/* 480 */     return "success";
/*     */   }
/*     */ 
/*     */   public String loadObjects()
/*     */   {
/* 490 */     int objectType = getObjectType();
/* 491 */     long objectID = getObjectID();
/*     */ 
/* 494 */     if ((objectType > -1) && (objectID > 0L)) {
/* 495 */       switch (objectType) {
/*     */       case 14:
/* 497 */         setCategoryID(objectID);
/* 498 */         break;
/*     */       case 0:
/* 500 */         setForumID(objectID);
/* 501 */         break;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 508 */     if (getCategoryID() > 0L) {
/*     */       try {
/* 510 */         setCategory(getForumFactory().getForumCategory(getCategoryID()));
/* 511 */         setCategoryID(getCategory().getID());
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e) {
/* 514 */         addFieldError("categoryID", String.valueOf(this.categoryID));
/* 515 */         return "notfound";
/*     */       }
/*     */     }
/*     */ 
/* 519 */     if (this.forumID > 0L) {
/*     */       try {
/* 521 */         setForum(getForumFactory().getForum(getForumID()));
/* 522 */         setForumID(getForum().getID());
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 525 */         addFieldError("forumID", String.valueOf(this.forumID));
/* 526 */         return "notfound";
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 529 */         addFieldError("forumID", String.valueOf(this.forumID));
/* 530 */         return "unauthorized";
/*     */       }
/*     */     }
/* 533 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PollPostAction
 * JD-Core Version:    0.6.2
 */
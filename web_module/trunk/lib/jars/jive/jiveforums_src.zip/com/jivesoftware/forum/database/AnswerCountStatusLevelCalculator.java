/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.Question;
/*     */ import com.jivesoftware.forum.QuestionManager;
/*     */ import com.jivesoftware.forum.StatusLevelCalculator;
/*     */ import com.jivesoftware.forum.event.ForumEvent;
/*     */ import com.jivesoftware.forum.event.ForumEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ForumListener;
/*     */ import com.jivesoftware.forum.event.MessageEvent;
/*     */ import com.jivesoftware.forum.event.MessageEventDispatcher;
/*     */ import com.jivesoftware.forum.event.MessageListener;
/*     */ import com.jivesoftware.forum.event.QuestionEvent;
/*     */ import com.jivesoftware.forum.event.QuestionEventDispatcher;
/*     */ import com.jivesoftware.forum.event.QuestionListener;
/*     */ import com.jivesoftware.forum.event.ThreadEvent;
/*     */ import com.jivesoftware.forum.event.ThreadEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ThreadListener;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.CacheSizes;
/*     */ import com.jivesoftware.util.Cacheable;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import com.tangosol.io.ExternalizableLite;
/*     */ import com.tangosol.util.ExternalizableHelper;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class AnswerCountStatusLevelCalculator
/*     */   implements StatusLevelCalculator, QuestionListener, ForumListener, ThreadListener, MessageListener
/*     */ {
/*     */   public static final String HELPFUL_POINTS_PROPERTY = "answerCount.helpfulPoints";
/*     */   public static final String CORRECT_POINTS_PROPERTY = "answerCount.correctPoints";
/*     */   public static final int DEFAULT_HELPFUL_POINTS = 5;
/*     */   public static final int DEFAULT_CORRECT_POINTS = 10;
/*     */   private static final String SYSTEM_POINT_LEVEL = "SELECT sum( (? * helpfulAnswer) + (? * correctAnswer) ) FROM jiveAnswer WHERE userID = ?";
/*     */   private static final String FORUM_POINT_LEVEL = "SELECT sum( (? * helpfulAnswer) + (? * correctAnswer) ) FROM jiveAnswer WHERE userID = ? AND forumID = ?";
/*     */   private static final String CATEGORY_POINT_LEVEL = "SELECT sum( (? * jiveAnswer.helpfulAnswer) + (? * jiveAnswer.correctAnswer) ) FROM jiveAnswer, jiveForum, jiveCategory  WHERE jiveAnswer.forumID = jiveForum.forumID AND jiveForum.categoryID = jiveCategory.categoryID AND jiveCategory.lft >= ? AND jiveCategory.rgt <= ? AND jiveAnswer.userID = ?";
/*     */   private static final String SYSTEM_LEADERS = "SELECT userID, sum( (? * helpfulAnswer) + (? * correctAnswer) ) AS sm FROM jiveAnswer WHERE userID > 0 GROUP BY userID ORDER BY sm DESC";
/*     */   private static final String FORUM_LEADERS = "SELECT jiveAnswer.userID, sum( (? * helpfulAnswer) + (? * correctAnswer) ) AS sm FROM jiveAnswer WHERE forumID = ? AND jiveAnswer.userID > 0 GROUP BY userID ORDER BY sm DESC";
/*     */   private static final String CATEGORY_LEADERS = "SELECT jiveAnswer.userID, sum( (? * jiveAnswer.helpfulAnswer) + (? * jiveAnswer.correctAnswer) ) AS sm FROM jiveAnswer, jiveForum, jiveCategory WHERE jiveAnswer.forumID = jiveForum.forumID AND jiveForum.categoryID = jiveCategory.categoryID AND jiveCategory.lft >= ? AND jiveCategory.rgt <= ? AND jiveAnswer.userID > 0 GROUP BY jiveAnswer.userID ORDER BY sm DESC";
/*  87 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */ 
/* 115 */   public static Cache answerCountPointCache = CacheFactory.createCache("AnswerCount Point Cache", "answerCountPointCache", 65536, 21600000L);
/*     */ 
/*     */   protected String getSystemPointLevel()
/*     */   {
/*  92 */     return "SELECT sum( (? * helpfulAnswer) + (? * correctAnswer) ) FROM jiveAnswer WHERE userID = ?";
/*     */   }
/*     */ 
/*     */   protected String getForumPointLevel() {
/*  96 */     return "SELECT sum( (? * helpfulAnswer) + (? * correctAnswer) ) FROM jiveAnswer WHERE userID = ? AND forumID = ?";
/*     */   }
/*     */ 
/*     */   protected String getCategoryPointLevel() {
/* 100 */     return "SELECT sum( (? * jiveAnswer.helpfulAnswer) + (? * jiveAnswer.correctAnswer) ) FROM jiveAnswer, jiveForum, jiveCategory  WHERE jiveAnswer.forumID = jiveForum.forumID AND jiveForum.categoryID = jiveCategory.categoryID AND jiveCategory.lft >= ? AND jiveCategory.rgt <= ? AND jiveAnswer.userID = ?";
/*     */   }
/*     */ 
/*     */   protected String getSystemLeaders() {
/* 104 */     return "SELECT userID, sum( (? * helpfulAnswer) + (? * correctAnswer) ) AS sm FROM jiveAnswer WHERE userID > 0 GROUP BY userID ORDER BY sm DESC";
/*     */   }
/*     */ 
/*     */   protected String getForumLeaders() {
/* 108 */     return "SELECT jiveAnswer.userID, sum( (? * helpfulAnswer) + (? * correctAnswer) ) AS sm FROM jiveAnswer WHERE forumID = ? AND jiveAnswer.userID > 0 GROUP BY userID ORDER BY sm DESC";
/*     */   }
/*     */ 
/*     */   protected String getCategoryLeaders() {
/* 112 */     return "SELECT jiveAnswer.userID, sum( (? * jiveAnswer.helpfulAnswer) + (? * jiveAnswer.correctAnswer) ) AS sm FROM jiveAnswer, jiveForum, jiveCategory WHERE jiveAnswer.forumID = jiveForum.forumID AND jiveForum.categoryID = jiveCategory.categoryID AND jiveCategory.lft >= ? AND jiveCategory.rgt <= ? AND jiveAnswer.userID > 0 GROUP BY jiveAnswer.userID ORDER BY sm DESC";
/*     */   }
/*     */ 
/*     */   public AnswerCountStatusLevelCalculator()
/*     */   {
/* 121 */     QuestionEventDispatcher.getInstance().addListener(this);
/* 122 */     ForumEventDispatcher.getInstance().addListener(this);
/* 123 */     ThreadEventDispatcher.getInstance().addListener(this);
/* 124 */     MessageEventDispatcher.getInstance().addListener(this);
/*     */   }
/*     */ 
/*     */   public int getPointLevel(User user)
/*     */   {
/* 129 */     UserPointCacheKey key = new UserPointCacheKey(user.getID(), 17, -1L);
/* 130 */     Integer value = getPointsFromCache(key);
/* 131 */     if (value != null) {
/* 132 */       return value.intValue();
/*     */     }
/*     */ 
/* 136 */     int score = 0;
/* 137 */     Connection con = null;
/* 138 */     PreparedStatement pstmt = null;
/*     */     try {
/* 140 */       con = ConnectionManager.getConnection();
/* 141 */       pstmt = getSystemPointStmt(con, user);
/*     */ 
/* 143 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 145 */       if (rs.next()) {
/* 146 */         score = rs.getInt(1);
/*     */       }
/* 148 */       rs.close();
/*     */ 
/* 151 */       answerCountPointCache.put(key, new Integer(score));
/*     */     }
/*     */     catch (SQLException sqle) {
/* 154 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 157 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 160 */     return score;
/*     */   }
/*     */ 
/*     */   protected PreparedStatement getSystemPointStmt(Connection con, User user) throws SQLException {
/* 164 */     PreparedStatement pstmt = con.prepareStatement(getSystemPointLevel());
/* 165 */     pstmt.setInt(1, getHelpfulAnswerPoints());
/* 166 */     pstmt.setInt(2, getCorrectAnswerPoints());
/* 167 */     pstmt.setLong(3, user.getID());
/* 168 */     return pstmt;
/*     */   }
/*     */ 
/*     */   public int getPointLevel(User user, Forum forum)
/*     */   {
/* 173 */     UserPointCacheKey key = new UserPointCacheKey(user.getID(), 0, forum.getID());
/*     */ 
/* 175 */     Integer value = getPointsFromCache(key);
/* 176 */     if (value != null) {
/* 177 */       return value.intValue();
/*     */     }
/*     */ 
/* 181 */     int score = 0;
/* 182 */     Connection con = null;
/* 183 */     PreparedStatement pstmt = null;
/*     */     try {
/* 185 */       con = ConnectionManager.getConnection();
/* 186 */       pstmt = getForumPointStmt(con, user, forum);
/*     */ 
/* 188 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 190 */       if (rs.next()) {
/* 191 */         score = rs.getInt(1);
/*     */       }
/* 193 */       rs.close();
/*     */ 
/* 196 */       answerCountPointCache.put(key, new Integer(score));
/*     */     }
/*     */     catch (SQLException sqle) {
/* 199 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 202 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 205 */     return score;
/*     */   }
/*     */ 
/*     */   protected PreparedStatement getForumPointStmt(Connection con, User user, Forum forum) throws SQLException {
/* 209 */     PreparedStatement pstmt = con.prepareStatement(getForumPointLevel());
/* 210 */     pstmt.setInt(1, getHelpfulAnswerPoints());
/* 211 */     pstmt.setInt(2, getCorrectAnswerPoints());
/* 212 */     pstmt.setLong(3, user.getID());
/* 213 */     pstmt.setLong(4, forum.getID());
/* 214 */     return pstmt;
/*     */   }
/*     */ 
/*     */   public int getPointLevel(User user, ForumCategory category)
/*     */   {
/* 219 */     UserPointCacheKey key = new UserPointCacheKey(user.getID(), 14, category.getID());
/*     */ 
/* 221 */     Integer value = getPointsFromCache(key);
/* 222 */     if (value != null) {
/* 223 */       return value.intValue();
/*     */     }
/*     */ 
/* 227 */     int score = 0;
/* 228 */     Connection con = null;
/* 229 */     PreparedStatement pstmt = null;
/*     */     try {
/* 231 */       con = ConnectionManager.getConnection();
/* 232 */       int[] leftright = DbForumCategory.getLftRgtValues(category.getID());
/*     */ 
/* 234 */       pstmt = getCategoryPointStmt(con, leftright, user);
/*     */ 
/* 236 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 238 */       if (rs.next()) {
/* 239 */         score = rs.getInt(1);
/*     */       }
/* 241 */       rs.close();
/*     */ 
/* 244 */       answerCountPointCache.put(key, new Integer(score));
/*     */     }
/*     */     catch (SQLException sqle) {
/* 247 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 250 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 253 */     return score;
/*     */   }
/*     */ 
/*     */   protected PreparedStatement getCategoryPointStmt(Connection con, int[] leftright, User user) throws SQLException {
/* 257 */     PreparedStatement pstmt = con.prepareStatement(getCategoryPointLevel());
/* 258 */     pstmt.setInt(1, getHelpfulAnswerPoints());
/* 259 */     pstmt.setInt(2, getCorrectAnswerPoints());
/* 260 */     pstmt.setLong(3, leftright[0]);
/* 261 */     pstmt.setLong(4, leftright[1]);
/* 262 */     pstmt.setLong(5, user.getID());
/* 263 */     return pstmt;
/*     */   }
/*     */ 
/*     */   public long[] getLeaderIds(int startIndex, int numResults) {
/* 267 */     LongList longList = new LongList();
/* 268 */     Connection con = null;
/* 269 */     PreparedStatement pstmt = null;
/*     */     try {
/* 271 */       con = ConnectionManager.getConnection();
/* 272 */       pstmt = getSystemLeaderStmt(con);
/*     */ 
/* 274 */       ResultSet rs = pstmt.executeQuery();
/* 275 */       ConnectionManager.setFetchSize(rs, startIndex + numResults);
/* 276 */       ConnectionManager.scrollResultSet(rs, startIndex);
/*     */ 
/* 278 */       for (int i = 0; (i < numResults) && 
/* 279 */         (rs.next()); i++)
/*     */       {
/* 280 */         longList.add(rs.getLong(1));
/*     */       }
/*     */ 
/* 286 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 289 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 292 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 295 */     return longList.toArray();
/*     */   }
/*     */ 
/*     */   protected PreparedStatement getSystemLeaderStmt(Connection con) throws SQLException {
/* 299 */     PreparedStatement pstmt = ConnectionManager.createScrollablePreparedStatement(con, getSystemLeaders());
/* 300 */     pstmt.setInt(1, getHelpfulAnswerPoints());
/* 301 */     pstmt.setInt(2, getCorrectAnswerPoints());
/* 302 */     return pstmt;
/*     */   }
/*     */ 
/*     */   public long[] getLeaderIds(ForumCategory category, int startIndex, int numResults) {
/* 306 */     LongList longList = new LongList();
/* 307 */     Connection con = null;
/* 308 */     PreparedStatement pstmt = null;
/*     */     try {
/* 310 */       con = ConnectionManager.getConnection();
/* 311 */       int[] leftright = DbForumCategory.getLftRgtValues(category.getID());
/*     */ 
/* 313 */       pstmt = getCategoryLeaderStmt(con, leftright);
/*     */ 
/* 315 */       ResultSet rs = pstmt.executeQuery();
/* 316 */       ConnectionManager.setFetchSize(rs, startIndex + numResults);
/* 317 */       ConnectionManager.scrollResultSet(rs, startIndex);
/*     */ 
/* 319 */       for (int i = 0; (i < numResults) && 
/* 320 */         (rs.next()); i++)
/*     */       {
/* 321 */         longList.add(rs.getLong(1));
/*     */       }
/*     */ 
/* 327 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 330 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 333 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 336 */     return longList.toArray();
/*     */   }
/*     */ 
/*     */   protected PreparedStatement getCategoryLeaderStmt(Connection con, int[] leftright) throws SQLException {
/* 340 */     PreparedStatement pstmt = ConnectionManager.createScrollablePreparedStatement(con, getCategoryLeaders());
/* 341 */     pstmt.setInt(1, getHelpfulAnswerPoints());
/* 342 */     pstmt.setInt(2, getCorrectAnswerPoints());
/* 343 */     pstmt.setLong(3, leftright[0]);
/* 344 */     pstmt.setLong(4, leftright[1]);
/* 345 */     return pstmt;
/*     */   }
/*     */ 
/*     */   public long[] getLeaderIds(Forum forum, int startIndex, int numResults) {
/* 349 */     LongList longList = new LongList();
/* 350 */     Connection con = null;
/* 351 */     PreparedStatement pstmt = null;
/*     */     try {
/* 353 */       con = ConnectionManager.getConnection();
/* 354 */       pstmt = getForumLeaderStmt(con, forum);
/*     */ 
/* 356 */       ResultSet rs = pstmt.executeQuery();
/* 357 */       ConnectionManager.setFetchSize(rs, startIndex + numResults);
/* 358 */       ConnectionManager.scrollResultSet(rs, startIndex);
/*     */ 
/* 360 */       for (int i = 0; (i < numResults) && 
/* 361 */         (rs.next()); i++)
/*     */       {
/* 362 */         longList.add(rs.getLong(1));
/*     */       }
/*     */ 
/* 368 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 371 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 374 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 377 */     return longList.toArray();
/*     */   }
/*     */ 
/*     */   protected PreparedStatement getForumLeaderStmt(Connection con, Forum forum) throws SQLException {
/* 381 */     PreparedStatement pstmt = ConnectionManager.createScrollablePreparedStatement(con, getForumLeaders());
/* 382 */     pstmt.setInt(1, getHelpfulAnswerPoints());
/* 383 */     pstmt.setInt(2, getCorrectAnswerPoints());
/* 384 */     pstmt.setLong(3, forum.getID());
/* 385 */     return pstmt;
/*     */   }
/*     */ 
/*     */   public int getHelpfulAnswerPoints() {
/* 389 */     return JiveGlobals.getJiveIntProperty("answerCount.helpfulPoints", 5);
/*     */   }
/*     */ 
/*     */   public int getCorrectAnswerPoints() {
/* 393 */     return JiveGlobals.getJiveIntProperty("answerCount.correctPoints", 10);
/*     */   }
/*     */ 
/*     */   public void questionAdded(QuestionEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void questionDeleted(QuestionEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void questionStateModified(QuestionEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void correctAnswerAdded(QuestionEvent event)
/*     */   {
/* 412 */     ForumMessage msg = event.getQuestion().getCorrectAnswer();
/* 413 */     updateUserCache(msg, getCorrectAnswerPoints());
/*     */   }
/*     */ 
/*     */   public void helpfulAnswerAdded(QuestionEvent event)
/*     */   {
/* 418 */     long messageID = ((Long)event.getParams().get("messageID")).longValue();
/*     */     try {
/* 420 */       ForumMessage message = FACTORY.getMessage(messageID);
/* 421 */       updateUserCache(message, getHelpfulAnswerPoints());
/*     */     }
/*     */     catch (ForumMessageNotFoundException fmnfe) {
/* 424 */       Log.error(fmnfe);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void propertyModified(QuestionEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void forumAdded(ForumEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void forumDeleted(ForumEvent event) {
/* 437 */     answerCountPointCache.clear();
/*     */   }
/*     */ 
/*     */   public void forumMoved(ForumEvent event) {
/* 441 */     answerCountPointCache.clear();
/*     */   }
/*     */ 
/*     */   public void forumMerged(ForumEvent event) {
/* 445 */     answerCountPointCache.clear();
/*     */   }
/*     */ 
/*     */   public void threadAdded(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadDeleted(ThreadEvent event) {
/* 454 */     QuestionManager questionManager = FACTORY.getQuestionManager();
/*     */ 
/* 456 */     ForumThread thread = event.getThread();
/*     */     Question question;
/*     */     try {
/* 460 */       question = questionManager.getQuestion(thread);
/*     */     }
/*     */     catch (NotFoundException e)
/*     */     {
/* 464 */       return;
/*     */     }
/*     */ 
/* 468 */     ForumMessage msg = question.getCorrectAnswer();
/* 469 */     if (msg != null) {
/* 470 */       expireUserCacheEntries(msg.getUser(), msg.getForum().getID());
/*     */     }
/*     */ 
/* 478 */     Iterator i = question.getHelpfulAnswers().iterator();
/* 479 */     if (i.hasNext()) {
/* 480 */       msg = (ForumMessage)i.next();
/* 481 */       expireUserCacheEntries(msg.getUser(), msg.getForum().getID());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void threadMoved(ThreadEvent event)
/*     */   {
/* 489 */     QuestionManager questionManager = FACTORY.getQuestionManager();
/*     */ 
/* 491 */     ForumThread thread = event.getThread();
/*     */     Question question;
/*     */     try
/*     */     {
/* 495 */       question = questionManager.getQuestion(thread);
/*     */     }
/*     */     catch (NotFoundException e)
/*     */     {
/* 499 */       return;
/*     */     }
/*     */ 
/* 503 */     long forumID = ((Long)event.getParams().get("oldForumID")).longValue();
/*     */ 
/* 506 */     ForumMessage msg = question.getCorrectAnswer();
/* 507 */     if (msg != null) {
/* 508 */       User user = msg.getUser();
/* 509 */       expireUserCacheEntries(user, forumID);
/* 510 */       expireUserCacheEntries(user, msg.getForum().getID());
/*     */     }
/*     */ 
/* 518 */     Iterator i = question.getHelpfulAnswers().iterator();
/* 519 */     if (i.hasNext()) {
/* 520 */       msg = (ForumMessage)i.next();
/* 521 */       expireUserCacheEntries(msg.getUser(), forumID);
/* 522 */       expireUserCacheEntries(msg.getUser(), msg.getForum().getID());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void threadModerationModified(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadRated(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageAdded(MessageEvent event) {
/*     */   }
/*     */ 
/*     */   public void messageDeleted(MessageEvent event) {
/* 540 */     QuestionManager questionManager = FACTORY.getQuestionManager();
/*     */ 
/* 542 */     ForumMessage msg = event.getMessage();
/* 543 */     ForumThread thread = msg.getForumThread();
/*     */     Question question;
/*     */     try {
/* 547 */       question = questionManager.getQuestion(thread);
/*     */     }
/*     */     catch (NotFoundException e)
/*     */     {
/* 551 */       return;
/*     */     }
/*     */ 
/* 555 */     if ((!question.isCorrectAnswer(msg)) && (!question.isHelpfulAnswer(msg))) {
/* 556 */       return;
/*     */     }
/*     */ 
/* 560 */     expireUserCacheEntries(msg.getUser(), msg.getForum().getID());
/*     */   }
/*     */ 
/*     */   public void messageMoved(MessageEvent event)
/*     */   {
/* 566 */     QuestionManager questionManager = FACTORY.getQuestionManager();
/*     */ 
/* 568 */     ForumMessage msg = event.getMessage();
/* 569 */     Long oldThreadID = (Long)event.getParams().get("oldThreadID");
/* 570 */     ForumThread thread = null;
/*     */     try {
/* 572 */       thread = FACTORY.getForumThread(oldThreadID.longValue());
/*     */     }
/*     */     catch (ForumThreadNotFoundException e) {
/* 575 */       Log.error("Could not find old thread.", e);
/*     */       return;
/*     */     }
/*     */     Question question;
/*     */     try {
/* 581 */       question = questionManager.getQuestion(thread);
/*     */     }
/*     */     catch (NotFoundException e)
/*     */     {
/* 585 */       return;
/*     */     }
/*     */ 
/* 590 */     if ((!question.isCorrectAnswer(msg)) && (!question.isHelpfulAnswer(msg))) {
/* 591 */       return;
/*     */     }
/*     */ 
/* 595 */     long forumID = ((Long)event.getParams().get("oldForumID")).longValue();
/*     */ 
/* 597 */     expireUserCacheEntries(msg.getUser(), forumID);
/* 598 */     expireUserCacheEntries(msg.getUser(), msg.getForum().getID());
/*     */   }
/*     */ 
/*     */   public void messageModified(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageModerationModified(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageRated(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void updateUserCache(ForumMessage message, int pointsToAdd)
/*     */   {
/* 622 */     if (message.isAnonymous()) {
/* 623 */       return;
/*     */     }
/*     */ 
/* 626 */     User user = message.getUser();
/*     */ 
/* 631 */     UserPointCacheKey key = new UserPointCacheKey(user.getID(), 17, -1L);
/* 632 */     Integer value = getPointsFromCache(key);
/* 633 */     if (value != null) {
/* 634 */       int score = value.intValue();
/* 635 */       score += pointsToAdd;
/* 636 */       answerCountPointCache.put(key, new Integer(score));
/*     */     }
/*     */ 
/* 640 */     Forum forum = message.getForum();
/* 641 */     key = new UserPointCacheKey(user.getID(), 0, forum.getID());
/* 642 */     value = getPointsFromCache(key);
/* 643 */     if (value != null) {
/* 644 */       int score = value.intValue();
/* 645 */       score += pointsToAdd;
/* 646 */       answerCountPointCache.put(key, new Integer(score));
/*     */     }
/*     */ 
/* 650 */     ForumCategory current = forum.getForumCategory();
/* 651 */     while (current != null)
/*     */     {
/* 653 */       key = new UserPointCacheKey(user.getID(), 14, current.getID());
/*     */ 
/* 655 */       value = getPointsFromCache(key);
/* 656 */       if (value != null) {
/* 657 */         int score = value.intValue();
/* 658 */         score += pointsToAdd;
/* 659 */         answerCountPointCache.put(key, new Integer(score));
/*     */       }
/*     */ 
/* 662 */       current = current.getParentCategory();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void expireUserCacheEntries(User user, long forumID)
/*     */   {
/* 674 */     if (user == null) {
/* 675 */       return;
/*     */     }
/*     */ 
/* 679 */     UserPointCacheKey key = new UserPointCacheKey(user.getID(), 17, -1L);
/* 680 */     answerCountPointCache.remove(key);
/*     */     try
/*     */     {
/* 684 */       Forum forum = FACTORY.getForum(forumID);
/* 685 */       key = new UserPointCacheKey(user.getID(), 0, forum.getID());
/* 686 */       answerCountPointCache.remove(key);
/*     */ 
/* 690 */       ForumCategory current = forum.getForumCategory();
/* 691 */       while (current != null) {
/* 692 */         key = new UserPointCacheKey(user.getID(), 14, current.getID());
/*     */ 
/* 694 */         answerCountPointCache.remove(key);
/* 695 */         current = current.getParentCategory();
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 699 */       Log.error(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Integer getPointsFromCache(UserPointCacheKey key)
/*     */   {
/* 711 */     return (Integer)answerCountPointCache.get(key);
/*     */   }
/*     */ 
/*     */   public static class UserPointCacheKey implements Cacheable, ExternalizableLite
/*     */   {
/*     */     private long userID;
/*     */     private int objectType;
/*     */     private long objectID;
/*     */ 
/*     */     public UserPointCacheKey()
/*     */     {
/*     */     }
/*     */ 
/*     */     public UserPointCacheKey(long userID, int objectType, long objectID)
/*     */     {
/* 728 */       this.userID = userID;
/* 729 */       this.objectType = objectType;
/* 730 */       this.objectID = objectID;
/*     */     }
/*     */ 
/*     */     public long getUserID() {
/* 734 */       return this.userID;
/*     */     }
/*     */ 
/*     */     public void setUserID(long userID) {
/* 738 */       this.userID = userID;
/*     */     }
/*     */ 
/*     */     public int getObjectType() {
/* 742 */       return this.objectType;
/*     */     }
/*     */ 
/*     */     public void setObjectType(int objectType) {
/* 746 */       this.objectType = objectType;
/*     */     }
/*     */ 
/*     */     public long getObjectID() {
/* 750 */       return this.objectID;
/*     */     }
/*     */ 
/*     */     public void setObjectID(long objectID) {
/* 754 */       this.objectID = objectID;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o) {
/* 758 */       if (this == o) {
/* 759 */         return true;
/*     */       }
/* 761 */       if (!(o instanceof UserPointCacheKey)) {
/* 762 */         return false;
/*     */       }
/*     */ 
/* 765 */       UserPointCacheKey userPointCacheKey = (UserPointCacheKey)o;
/*     */ 
/* 767 */       if (this.objectID != userPointCacheKey.objectID) {
/* 768 */         return false;
/*     */       }
/* 770 */       if (this.objectType != userPointCacheKey.objectType) {
/* 771 */         return false;
/*     */       }
/* 773 */       if (this.userID != userPointCacheKey.userID) {
/* 774 */         return false;
/*     */       }
/*     */ 
/* 777 */       return true;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 782 */       int result = (int)(this.userID ^ this.userID >>> 32);
/* 783 */       result = 1801 * result + this.objectType;
/* 784 */       result = 1801 * result + (int)(this.objectID ^ this.objectID >>> 32);
/* 785 */       return result;
/*     */     }
/*     */ 
/*     */     public int getCachedSize() {
/* 789 */       int size = 0;
/* 790 */       size += CacheSizes.sizeOfObject();
/* 791 */       size += CacheSizes.sizeOfLong();
/* 792 */       size += CacheSizes.sizeOfInt();
/* 793 */       size += CacheSizes.sizeOfLong();
/* 794 */       return size;
/*     */     }
/*     */ 
/*     */     public void readExternal(DataInput in) throws IOException {
/* 798 */       this.userID = ExternalizableHelper.readLong(in);
/* 799 */       this.objectType = ExternalizableHelper.readInt(in);
/* 800 */       this.objectID = ExternalizableHelper.readLong(in);
/*     */     }
/*     */ 
/*     */     public void writeExternal(DataOutput out) throws IOException {
/* 804 */       ExternalizableHelper.writeLong(out, this.userID);
/* 805 */       ExternalizableHelper.writeInt(out, this.objectType);
/* 806 */       ExternalizableHelper.writeLong(out, this.objectID);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.AnswerCountStatusLevelCalculator
 * JD-Core Version:    0.6.2
 */
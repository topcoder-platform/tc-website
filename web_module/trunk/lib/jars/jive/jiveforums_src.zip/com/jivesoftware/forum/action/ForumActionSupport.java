/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.base.action.JiveActionSupport;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ReadTracker;
/*     */ import com.jivesoftware.forum.TreeWalker;
/*     */ import com.jivesoftware.forum.util.SkinUtils;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class ForumActionSupport extends JiveActionSupport
/*     */ {
/*     */   protected static final String SESSION_REFERRER_KEY = "jive.referrer.url";
/*     */   private ForumFactory forumFactory;
/*  39 */   private boolean pageUserLoaded = false;
/*     */ 
/*     */   public ForumFactory getForumFactory()
/*     */   {
/*  49 */     if (this.forumFactory == null) {
/*  50 */       this.forumFactory = ForumFactory.getInstance(getAuthToken());
/*     */     }
/*  52 */     return this.forumFactory;
/*     */   }
/*     */ 
/*     */   public void setForumFactory(ForumFactory forumFactory)
/*     */   {
/*  61 */     if (forumFactory != null)
/*  62 */       this.forumFactory = forumFactory;
/*     */   }
/*     */ 
/*     */   public User getPageUser()
/*     */   {
/*  76 */     if ((!this.pageUserLoaded) && (this.pageUser == null)) {
/*  77 */       AuthToken token = getAuthToken();
/*  78 */       if (!token.isAnonymous())
/*     */         try {
/*  80 */           setPageUser(getForumFactory().getUserManager().getUser(token.getUserID()));
/*     */         }
/*     */         catch (UserNotFoundException ignored) {
/*     */         }
/*     */     }
/*  85 */     return this.pageUser;
/*     */   }
/*     */ 
/*     */   public boolean isSystemAdmin()
/*     */   {
/*  94 */     User user = getPageUser();
/*  95 */     if (user != null) {
/*  96 */       return user.isAuthorized(576460752303423488L);
/*     */     }
/*  98 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isAdmin(ForumCategory category)
/*     */   {
/* 109 */     if (category == null) {
/* 110 */       return false;
/*     */     }
/* 112 */     return (isSystemAdmin()) || (category.isAuthorized(512L));
/*     */   }
/*     */ 
/*     */   public boolean isAdmin(Forum forum)
/*     */   {
/* 123 */     if (forum == null) {
/* 124 */       return false;
/*     */     }
/* 126 */     return (isSystemAdmin()) || (forum.isAuthorized(512L));
/*     */   }
/*     */ 
/*     */   public boolean isModerator(ForumCategory category)
/*     */   {
/* 139 */     if (category == null) {
/* 140 */       return false;
/*     */     }
/* 142 */     return (isAdmin(category)) || (category.isAuthorized(128L));
/*     */   }
/*     */ 
/*     */   public boolean isModerator(Forum forum)
/*     */   {
/* 152 */     if (forum == null) {
/* 153 */       return false;
/*     */     }
/* 155 */     return (isAdmin(forum)) || (forum.isAuthorized(128L));
/*     */   }
/*     */ 
/*     */   public boolean isAuthor(ForumThread thread)
/*     */   {
/* 168 */     if (thread == null) {
/* 169 */       return false;
/*     */     }
/* 171 */     ForumMessage root = thread.getRootMessage();
/* 172 */     if ((root.isAnonymous()) || (root.getUser() == null)) {
/* 173 */       return false;
/*     */     }
/*     */ 
/* 176 */     return getAuthToken().getUserID() == root.getUser().getID();
/*     */   }
/*     */ 
/*     */   public boolean isAuthor(ForumMessage message)
/*     */   {
/* 190 */     if (message == null) {
/* 191 */       return false;
/*     */     }
/* 193 */     if ((message.isAnonymous()) || (message.getUser() == null)) {
/* 194 */       return false;
/*     */     }
/*     */ 
/* 197 */     return getAuthToken().getUserID() == message.getUser().getID();
/*     */   }
/*     */ 
/*     */   public boolean getCanEdit(ForumMessage message)
/*     */   {
/* 219 */     if (message == null) {
/* 220 */       return false;
/*     */     }
/*     */ 
/* 223 */     if ((isSystemAdmin()) || (isModerator(message.getForum()))) {
/* 224 */       return true;
/*     */     }
/*     */ 
/* 228 */     String policy = JiveGlobals.getJiveProperty("messageEdit.policy", "always");
/*     */ 
/* 231 */     boolean locked = "true".equals(message.getForumThread().getProperty("jive.locked"));
/* 232 */     boolean archived = "true".equals(message.getForumThread().getProperty("jive.archived"));
/*     */ 
/* 234 */     boolean hasEditPerm = (isSystemAdmin()) || (message.isAuthorized(128L)) || ((isAuthor(message)) && (message.getForumThread().getForum().isAuthorized(6L)));
/*     */ 
/* 240 */     if ((!hasEditPerm) || (locked) || (archived)) {
/* 241 */       return false;
/*     */     }
/*     */ 
/* 244 */     if ("always".equals(policy)) {
/* 245 */       return true;
/*     */     }
/* 247 */     if ("never".equals(policy)) {
/* 248 */       return false;
/*     */     }
/* 250 */     if ("noreplies".equals(policy))
/*     */     {
/* 252 */       TreeWalker treeWalker = message.getForumThread().getTreeWalker();
/* 253 */       if (treeWalker.getChildCount(message) == 0) {
/* 254 */         return true;
/*     */       }
/*     */ 
/* 257 */       return false;
/*     */     }
/*     */ 
/* 260 */     if ("timewindow".equals(policy))
/*     */     {
/* 262 */       int mins = JiveGlobals.getJiveIntProperty("messageEdit.timeWindow", 0);
/*     */ 
/* 265 */       if (message.getModificationDate().getTime() + 60000 * mins > System.currentTimeMillis())
/*     */       {
/* 267 */         return true;
/*     */       }
/*     */ 
/* 270 */       return false;
/*     */     }
/*     */ 
/* 274 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean getCanAttach(Forum forum)
/*     */   {
/* 290 */     if (forum == null) {
/* 291 */       return false;
/*     */     }
/* 293 */     return forum.isAuthorized(576460752303424392L);
/*     */   }
/*     */ 
/*     */   public boolean getCanEditAttach(ForumMessage message)
/*     */   {
/* 309 */     if (message == null) {
/* 310 */       return false;
/*     */     }
/* 312 */     if ((getPageUser() == null) || ("true".equals(message.getForumThread().getProperty("jive.locked"))))
/*     */     {
/* 314 */       return false;
/*     */     }
/* 316 */     if (message.getUser() != null) {
/* 317 */       return (isSystemAdmin()) || (message.isAuthorized(896L)) || (message.getUser().getID() == getPageUser().getID());
/*     */     }
/*     */ 
/* 323 */     return (isSystemAdmin()) || (message.isAuthorized(896L));
/*     */   }
/*     */ 
/*     */   public boolean getCanPostAnnounce(ForumCategory category)
/*     */   {
/* 338 */     if (category == null) {
/* 339 */       return false;
/*     */     }
/* 341 */     return (isModerator(category)) || (isAdmin(category)) || (category.isAuthorized(4096L));
/*     */   }
/*     */ 
/*     */   public boolean getCanPostAnnounce(Forum forum)
/*     */   {
/* 355 */     if (forum == null) {
/* 356 */       return false;
/*     */     }
/* 358 */     return (isModerator(forum)) || (isAdmin(forum)) || (forum.isAuthorized(4096L));
/*     */   }
/*     */ 
/*     */   public boolean getCanCreatePoll(ForumCategory category)
/*     */   {
/* 372 */     if (category == null) {
/* 373 */       return false;
/*     */     }
/* 375 */     return (isModerator(category)) || (isAdmin(category)) || (category.isAuthorized(16L));
/*     */   }
/*     */ 
/*     */   public boolean getCanCreatePoll(Forum forum)
/*     */   {
/* 389 */     if (forum == null) {
/* 390 */       return false;
/*     */     }
/* 392 */     return (isModerator(forum)) || (isAdmin(forum)) || (forum.isAuthorized(16L));
/*     */   }
/*     */ 
/*     */   public String getSkinProperty(Forum forum, String name)
/*     */   {
/* 406 */     return SkinUtils.getSkinProperty(forum, name);
/*     */   }
/*     */ 
/*     */   public boolean getReadStatus(Object obj, int type)
/*     */   {
/* 422 */     if (isGuest()) {
/* 423 */       return false;
/*     */     }
/* 425 */     ReadTracker readTracker = getForumFactory().getReadTracker();
/*     */ 
/* 427 */     if (!readTracker.isReadTrackingEnabled()) {
/* 428 */       return false;
/*     */     }
/*     */ 
/* 431 */     User user = getPageUser();
/* 432 */     if ((obj instanceof ForumThread)) {
/* 433 */       return readTracker.getReadStatus(user, (ForumThread)obj) == type;
/*     */     }
/* 435 */     if ((obj instanceof ForumMessage)) {
/* 436 */       return readTracker.getReadStatus(user, (ForumMessage)obj) == type;
/*     */     }
/* 438 */     if ((obj instanceof Forum)) {
/* 439 */       if (type == 2) {
/* 440 */         return readTracker.getUnreadThreadCount(user, (Forum)obj) == 0;
/*     */       }
/*     */ 
/* 443 */       return readTracker.getUnreadThreadCount(user, (Forum)obj) > 0;
/*     */     }
/*     */ 
/* 446 */     if ((obj instanceof ForumCategory)) {
/* 447 */       ForumCategory cat = (ForumCategory)obj;
/*     */ 
/* 449 */       if (type == 2)
/*     */       {
/* 453 */         for (Iterator iter = cat.getRecursiveForums(); iter.hasNext(); ) {
/* 454 */           Forum f = (Forum)iter.next();
/* 455 */           if (readTracker.getUnreadThreadCount(user, f) > 0) {
/* 456 */             return false;
/*     */           }
/*     */         }
/* 459 */         return true;
/*     */       }
/*     */ 
/* 462 */       for (Iterator iter = cat.getRecursiveForums(); iter.hasNext(); ) {
/* 463 */         Forum f = (Forum)iter.next();
/* 464 */         if (readTracker.getUnreadThreadCount(user, f) > 0) {
/* 465 */           return true;
/*     */         }
/*     */       }
/* 468 */       return false;
/*     */     }
/*     */ 
/* 472 */     throw new IllegalArgumentException("Unrecognized object type");
/*     */   }
/*     */ 
/*     */   public boolean isThreadModerationOn(Forum forum)
/*     */   {
/* 486 */     if (forum == null) {
/* 487 */       return false;
/*     */     }
/* 489 */     int defaultModValue = forum.getModerationDefaultThreadValue();
/* 490 */     return defaultModValue < 1;
/*     */   }
/*     */ 
/*     */   public boolean isMessageModerationOn(Forum forum)
/*     */   {
/* 502 */     if (forum == null) {
/* 503 */       return false;
/*     */     }
/* 505 */     int defaultModValue = forum.getModerationDefaultMessageValue();
/* 506 */     return defaultModValue < 1;
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */     throws Exception
/*     */   {
/* 517 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.ForumActionSupport
 * JD-Core Version:    0.6.2
 */
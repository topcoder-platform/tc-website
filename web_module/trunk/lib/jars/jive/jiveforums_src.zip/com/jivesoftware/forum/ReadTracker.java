package com.jivesoftware.forum;

import com.jivesoftware.base.UnauthorizedException;
import com.jivesoftware.base.User;
import java.util.Iterator;

public abstract interface ReadTracker
{
  public static final int UNREAD = 0;
  public static final int UPDATED = 1;
  public static final int READ = 2;

  public abstract boolean isReadTrackingEnabled();

  public abstract void setReadTrackingEnabled(boolean paramBoolean)
    throws UnauthorizedException;

  public abstract int getReadStatus(User paramUser, ForumThread paramForumThread);

  public abstract int getReadStatus(User paramUser, ForumMessage paramForumMessage);

  public abstract void markRead(User paramUser, ForumMessage paramForumMessage);

  public abstract void markRead(User paramUser, Forum paramForum);

  public abstract void markRead(User paramUser, ForumCategory paramForumCategory);

  public abstract int getUnreadThreadCount(User paramUser, Forum paramForum);

  public abstract int getUnreadThreadCount(User paramUser, ForumCategory paramForumCategory);

  public abstract Iterator getUnreadThreads(User paramUser, Forum paramForum);

  public abstract Iterator getUnreadThreads(User paramUser, ForumCategory paramForumCategory);

  public abstract int getUnreadMessageCount(User paramUser, Forum paramForum);

  public abstract int getUnreadMessageCount(User paramUser, ForumCategory paramForumCategory);

  public abstract Iterator getUnreadMessages(User paramUser, Forum paramForum);

  public abstract Iterator getUnreadMessages(User paramUser, ForumCategory paramForumCategory);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.ReadTracker
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.Announcement;
/*    */ import com.jivesoftware.forum.AnnouncementManager;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ 
/*    */ public class AnnounceDeleteAction extends AnnounceAction
/*    */ {
/*    */   private boolean cancel;
/*    */ 
/*    */   public String isCancel()
/*    */   {
/* 33 */     return String.valueOf(this.cancel);
/*    */   }
/*    */ 
/*    */   public void setCancel(String cancel)
/*    */   {
/* 40 */     this.cancel = true;
/*    */   }
/*    */ 
/*    */   public String doDefault()
/*    */   {
/* 47 */     return "input";
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */   {
/* 58 */     if (this.cancel) {
/* 59 */       return "cancel";
/*    */     }
/*    */ 
/* 62 */     Announcement ann = getAnnouncement();
/* 63 */     AnnouncementManager manager = getForumFactory().getAnnouncementManager();
/*    */     try {
/* 65 */       manager.deleteAnnouncement(ann);
/*    */     }
/*    */     catch (UnauthorizedException e) {
/* 68 */       return "unauthorized";
/*    */     }
/* 70 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AnnounceDeleteAction
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.action.JiveObjectLoader;
/*     */ import com.jivesoftware.forum.Announcement;
/*     */ import com.jivesoftware.forum.AnnouncementManager;
/*     */ import com.jivesoftware.forum.AnnouncementNotFoundException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ 
/*     */ public class AnnounceAction extends ForumActionSupport
/*     */   implements JiveObjectLoader
/*     */ {
/*  32 */   private long annID = 0L;
/*     */ 
/*  34 */   private boolean systemAnnounce = false;
/*  35 */   private boolean categoryAnnounce = false;
/*  36 */   private boolean forumAnnounce = false;
/*     */   private Announcement ann;
/*     */   private Forum forum;
/*     */   private ForumCategory category;
/*     */ 
/*     */   public long getAnnID()
/*     */   {
/*  46 */     return this.annID;
/*     */   }
/*     */ 
/*     */   public void setAnnID(long annID)
/*     */   {
/*  53 */     this.annID = annID;
/*     */   }
/*     */ 
/*     */   public int getObjectType() {
/*  57 */     if (this.forumAnnounce) {
/*  58 */       return 0;
/*     */     }
/*  60 */     if (this.categoryAnnounce) {
/*  61 */       return 14;
/*     */     }
/*     */ 
/*  64 */     return -1;
/*     */   }
/*     */ 
/*     */   public boolean isSystemAnnounce()
/*     */   {
/*  73 */     return this.systemAnnounce;
/*     */   }
/*     */ 
/*     */   public boolean isCategoryAnnounce()
/*     */   {
/*  81 */     return this.categoryAnnounce;
/*     */   }
/*     */ 
/*     */   public boolean isForumAnnounce()
/*     */   {
/*  89 */     return this.forumAnnounce;
/*     */   }
/*     */ 
/*     */   public boolean isModerator() {
/*  93 */     if ((isSystemAdmin()) || (getForumFactory().isAuthorized(128L)) || (getForumFactory().isAuthorized(4096L)))
/*     */     {
/*  96 */       return true;
/*     */     }
/*  98 */     if (this.forumAnnounce) {
/*  99 */       return (isModerator(getForum())) || (getForum().isAuthorized(4096L));
/*     */     }
/*     */ 
/* 102 */     if (this.categoryAnnounce) {
/* 103 */       return (isModerator(getCategory())) || (getCategory().isAuthorized(4096L));
/*     */     }
/*     */ 
/* 107 */     return false;
/*     */   }
/*     */ 
/*     */   public Announcement getAnnouncement()
/*     */   {
/* 115 */     return this.ann;
/*     */   }
/*     */ 
/*     */   public Forum getForum()
/*     */   {
/* 123 */     return this.forum;
/*     */   }
/*     */ 
/*     */   public ForumCategory getCategory()
/*     */   {
/* 131 */     return this.category;
/*     */   }
/*     */ 
/*     */   public String execute() {
/* 135 */     return "success";
/*     */   }
/*     */ 
/*     */   public String loadObjects() throws Exception {
/* 139 */     ForumFactory factory = getForumFactory();
/* 140 */     AnnouncementManager manager = factory.getAnnouncementManager();
/* 141 */     long annID = getAnnID();
/*     */     try {
/* 143 */       this.ann = manager.getAnnouncement(annID);
/* 144 */       switch (this.ann.getContainerObjectType()) {
/*     */       case 0:
/* 146 */         this.forumAnnounce = true;
/*     */         try {
/* 148 */           this.forum = factory.getForum(this.ann.getContainerObjectID());
/*     */         }
/*     */         catch (ForumNotFoundException e) {
/* 151 */           addFieldError("forumID", String.valueOf(this.ann.getContainerObjectID()));
/* 152 */           return "notfound";
/*     */         }
/*     */ 
/*     */       case 14:
/* 156 */         this.categoryAnnounce = true;
/*     */         try {
/* 158 */           this.category = factory.getForumCategory(this.ann.getContainerObjectID());
/*     */         }
/*     */         catch (ForumCategoryNotFoundException e) {
/* 161 */           addFieldError("categoryID", String.valueOf(this.ann.getContainerObjectID()));
/* 162 */           return "notfound";
/*     */         }
/*     */ 
/*     */       default:
/* 166 */         this.systemAnnounce = true;
/*     */       }
/*     */     }
/*     */     catch (AnnouncementNotFoundException e)
/*     */     {
/* 171 */       addFieldError("annID", String.valueOf(annID));
/* 172 */       return "notfound";
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 175 */       return "unauthorized";
/*     */     }
/* 177 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AnnounceAction
 * JD-Core Version:    0.6.2
 */
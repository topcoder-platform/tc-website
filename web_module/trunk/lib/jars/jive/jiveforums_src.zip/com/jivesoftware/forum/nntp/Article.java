package com.jivesoftware.forum.nntp;

import java.io.IOException;

public abstract interface Article
{
  public abstract int getNumber();

  public abstract String getMessageID();

  public abstract String getSubject();

  public abstract String getAuthor();

  public abstract String getDate();

  public abstract String getReferences();

  public abstract String getNewsGroups();

  public abstract int getByteCount();

  public abstract int getLineCount();

  public abstract void sendBody(NNTPResponseBuffer paramNNTPResponseBuffer)
    throws IOException;

  public abstract void sendArticle(NNTPResponseBuffer paramNNTPResponseBuffer)
    throws IOException;

  public abstract String getHead();
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.Article
 * JD-Core Version:    0.6.2
 */
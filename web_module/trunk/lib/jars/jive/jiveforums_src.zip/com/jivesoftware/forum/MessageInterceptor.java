package com.jivesoftware.forum;

public abstract interface MessageInterceptor
{
  public static final int TYPE_PRE = 0;
  public static final int TYPE_POST = 1;
  public static final int TYPE_BOTH = 2;
  public static final int TYPE_EDIT = 3;
  public static final int TYPE_ALL = 4;

  public abstract int getType();

  public abstract void invokeInterceptor(ForumMessage paramForumMessage, int paramInt)
    throws MessageRejectedException;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.MessageInterceptor
 * JD-Core Version:    0.6.2
 */
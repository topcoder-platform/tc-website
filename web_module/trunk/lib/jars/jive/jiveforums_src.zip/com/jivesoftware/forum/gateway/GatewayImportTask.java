/*    */ package com.jivesoftware.forum.gateway;
/*    */ 
/*    */ import com.jivesoftware.base.Log;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class GatewayImportTask
/*    */   implements Runnable
/*    */ {
/* 23 */   private boolean isBusy = false;
/* 24 */   private boolean hasRun = false;
/* 25 */   private Gateway gateway = null;
/* 26 */   private Date afterDate = new Date();
/*    */ 
/*    */   public GatewayImportTask(Gateway gateway, Date afterDate) {
/* 29 */     this.gateway = gateway;
/* 30 */     this.afterDate = afterDate;
/*    */   }
/*    */ 
/*    */   public boolean isBusy() {
/* 34 */     return this.isBusy;
/*    */   }
/*    */ 
/*    */   public boolean hasRun() {
/* 38 */     return this.hasRun;
/*    */   }
/*    */ 
/*    */   public void run() {
/*    */     try {
/* 43 */       this.hasRun = true;
/* 44 */       this.isBusy = true;
/* 45 */       this.gateway.importData(this.afterDate);
/*    */     }
/*    */     catch (GatewayException ge) {
/* 48 */       Log.error(ge);
/*    */     }
/*    */     finally {
/* 51 */       this.isBusy = false;
/* 52 */       this.gateway = null;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void stop() {
/* 57 */     synchronized (this) {
/*    */       try {
/* 59 */         if ((this.isBusy) && (this.gateway != null)) {
/* 60 */           GatewayImporter importer = this.gateway.getGatewayImporter();
/* 61 */           importer.stop();
/*    */         }
/*    */       }
/*    */       catch (GatewayException ge) {
/* 65 */         Log.error(ge);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.GatewayImportTask
 * JD-Core Version:    0.6.2
 */
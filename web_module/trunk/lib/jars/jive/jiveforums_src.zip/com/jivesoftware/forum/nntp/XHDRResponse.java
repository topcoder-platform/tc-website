/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import com.jivesoftware.forum.net.Connection;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class XHDRResponse extends NNTPResponseBuffer
/*     */ {
/*     */   private static final int CODE = 221;
/*     */   private static final int LINE_LIMIT = 500;
/*     */   private static final String TEXT = "Header follows";
/*     */ 
/*     */   private XHDRResponse(Connection connection)
/*     */     throws IOException
/*     */   {
/*  44 */     super(connection, 221, "Header follows", true);
/*     */   }
/*     */ 
/*     */   public static NNTPResponse getXHDR(Connection connection, String header, ArticlePointer pointer, ArticleFilter filter)
/*     */     throws ArticleNotFoundException, ArticleNotSelectedException, NoPermissionException, IOException, NoGroupSelectedException
/*     */   {
/*  68 */     XHDRResponse response = new XHDRResponse(connection);
/*  69 */     Iterator articles = pointer.getArticles(filter);
/*  70 */     response.flush();
/*  71 */     if (header.equalsIgnoreCase("SUBJECT")) {
/*  72 */       populateSubject(response, articles);
/*     */     }
/*  74 */     else if (header.equalsIgnoreCase("FROM")) {
/*  75 */       populateFrom(response, articles);
/*     */     }
/*  77 */     else if (header.equalsIgnoreCase("DATE")) {
/*  78 */       populateDate(response, articles);
/*     */     }
/*  80 */     else if (header.equalsIgnoreCase("NEWSGROUPS")) {
/*  81 */       populateNewsgroups(response, articles);
/*     */     }
/*  83 */     else if (header.equalsIgnoreCase("MESSAGE-ID")) {
/*  84 */       populateMessageID(response, articles);
/*     */     }
/*  86 */     else if (header.equalsIgnoreCase("PATH")) {
/*  87 */       populatePath(response, articles);
/*     */     }
/*  89 */     return response;
/*     */   }
/*     */ 
/*     */   private static void populatePath(XHDRResponse response, Iterator articles)
/*     */     throws IOException
/*     */   {
/* 102 */     while (articles.hasNext())
/* 103 */       appendAndTruncate(response, "");
/*     */   }
/*     */ 
/*     */   private static void populateMessageID(XHDRResponse response, Iterator articles)
/*     */     throws IOException
/*     */   {
/* 116 */     while (articles.hasNext())
/* 117 */       appendAndTruncate(response, ((Article)articles.next()).getMessageID());
/*     */   }
/*     */ 
/*     */   private static void populateNewsgroups(XHDRResponse response, Iterator articles)
/*     */     throws IOException
/*     */   {
/* 130 */     while (articles.hasNext())
/* 131 */       appendAndTruncate(response, ((Article)articles.next()).getNewsGroups());
/*     */   }
/*     */ 
/*     */   private static void populateDate(XHDRResponse response, Iterator articles)
/*     */     throws IOException
/*     */   {
/* 144 */     while (articles.hasNext())
/* 145 */       appendAndTruncate(response, ((Article)articles.next()).getDate());
/*     */   }
/*     */ 
/*     */   private static void populateFrom(XHDRResponse response, Iterator articles)
/*     */     throws IOException
/*     */   {
/* 158 */     while (articles.hasNext())
/* 159 */       appendAndTruncate(response, ((Article)articles.next()).getAuthor());
/*     */   }
/*     */ 
/*     */   private static void populateSubject(XHDRResponse response, Iterator articles)
/*     */     throws IOException
/*     */   {
/* 172 */     while (articles.hasNext())
/* 173 */       appendAndTruncate(response, ((Article)articles.next()).getSubject());
/*     */   }
/*     */ 
/*     */   private static void appendAndTruncate(XHDRResponse response, String line)
/*     */     throws IOException
/*     */   {
/* 186 */     if (line.length() > 500) {
/* 187 */       line = line.substring(0, 500);
/*     */     }
/* 189 */     response.appendLine(line);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.XHDRResponse
 * JD-Core Version:    0.6.2
 */
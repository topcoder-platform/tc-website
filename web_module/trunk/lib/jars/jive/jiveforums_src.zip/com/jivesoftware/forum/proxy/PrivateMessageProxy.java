/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.AttachmentException;
/*     */ import com.jivesoftware.forum.PrivateMessage;
/*     */ import com.jivesoftware.forum.PrivateMessageFolder;
/*     */ import java.io.InputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class PrivateMessageProxy
/*     */   implements PrivateMessage
/*     */ {
/*     */   private PrivateMessage privateMessage;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public PrivateMessageProxy(PrivateMessage privateMessage, Permissions permissions)
/*     */   {
/*  36 */     this.privateMessage = privateMessage;
/*  37 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public long getID() {
/*  41 */     return this.privateMessage.getID();
/*     */   }
/*     */ 
/*     */   public Date getDate() {
/*  45 */     return this.privateMessage.getDate();
/*     */   }
/*     */ 
/*     */   public PrivateMessageFolder getFolder() {
/*  49 */     return this.privateMessage.getFolder();
/*     */   }
/*     */ 
/*     */   public String getSubject() {
/*  53 */     return this.privateMessage.getSubject();
/*     */   }
/*     */ 
/*     */   public String getUnfilteredSubject() {
/*  57 */     return this.privateMessage.getUnfilteredSubject();
/*     */   }
/*     */ 
/*     */   public void setSubject(String subject) throws UnauthorizedException {
/*  61 */     this.privateMessage.setSubject(subject);
/*     */   }
/*     */ 
/*     */   public String getBody() {
/*  65 */     return this.privateMessage.getBody();
/*     */   }
/*     */ 
/*     */   public String getUnfilteredBody() {
/*  69 */     return this.privateMessage.getUnfilteredBody();
/*     */   }
/*     */ 
/*     */   public void setBody(String body) throws UnauthorizedException {
/*  73 */     this.privateMessage.setBody(body);
/*     */   }
/*     */ 
/*     */   public User getSender() {
/*  77 */     return this.privateMessage.getSender();
/*     */   }
/*     */ 
/*     */   public User getRecipient() {
/*  81 */     return this.privateMessage.getRecipient();
/*     */   }
/*     */ 
/*     */   public boolean isRead() {
/*  85 */     return this.privateMessage.isRead();
/*     */   }
/*     */ 
/*     */   public void setRead(boolean read) {
/*  89 */     this.privateMessage.setRead(read);
/*     */   }
/*     */ 
/*     */   public Attachment createAttachment(String name, String contentType, InputStream data)
/*     */     throws IllegalStateException, AttachmentException, UnauthorizedException
/*     */   {
/*  95 */     if ((isAdmin()) || (this.permissions.hasPermission(128L)) || (this.permissions.hasPermission(8L)))
/*     */     {
/*  98 */       return this.privateMessage.createAttachment(name, contentType, data);
/*     */     }
/*     */ 
/* 101 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getAttachmentCount()
/*     */   {
/* 106 */     return this.privateMessage.getAttachmentCount();
/*     */   }
/*     */ 
/*     */   public Iterator getAttachments() {
/* 110 */     return this.privateMessage.getAttachments();
/*     */   }
/*     */ 
/*     */   public void deleteAttachment(Attachment attachment)
/*     */     throws AttachmentException, UnauthorizedException
/*     */   {
/* 116 */     this.privateMessage.deleteAttachment(attachment);
/*     */   }
/*     */ 
/*     */   public String getProperty(String name) {
/* 120 */     return this.privateMessage.getProperty(name);
/*     */   }
/*     */ 
/*     */   public Collection getProperties(String parentName) {
/* 124 */     return this.privateMessage.getProperties(parentName);
/*     */   }
/*     */ 
/*     */   public String getUnfilteredProperty(String name) {
/* 128 */     return this.privateMessage.getUnfilteredProperty(name);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value) throws UnauthorizedException {
/* 132 */     this.privateMessage.setProperty(name, value);
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) throws UnauthorizedException {
/* 136 */     this.privateMessage.deleteProperty(name);
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames() {
/* 140 */     return this.privateMessage.getPropertyNames();
/*     */   }
/*     */ 
/*     */   public boolean isAuthorized(long type) {
/* 144 */     return this.permissions.hasPermission(type);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 150 */     return this.privateMessage.toString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object) {
/* 154 */     return this.privateMessage.equals(object);
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 158 */     return this.privateMessage.hashCode();
/*     */   }
/*     */ 
/*     */   public PrivateMessage getProxiedPrivateMessage()
/*     */   {
/* 167 */     return this.privateMessage;
/*     */   }
/*     */ 
/*     */   private boolean isAdmin()
/*     */   {
/* 175 */     return this.permissions.hasPermission(576460752303423488L);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.PrivateMessageProxy
 * JD-Core Version:    0.6.2
 */
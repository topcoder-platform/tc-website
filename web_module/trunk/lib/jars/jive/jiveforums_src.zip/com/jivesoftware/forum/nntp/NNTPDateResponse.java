/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.TimeZone;
/*    */ 
/*    */ public class NNTPDateResponse extends StaticNNTPResponse
/*    */ {
/* 30 */   private static SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
/*    */   private static final int CODE = 111;
/*    */ 
/*    */   public NNTPDateResponse()
/*    */   {
/* 39 */     super(111, format.format(new Date()));
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 31 */     format.setTimeZone(TimeZone.getTimeZone("GMT"));
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NNTPDateResponse
 * JD-Core Version:    0.6.2
 */
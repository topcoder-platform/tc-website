/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.PresenceManager;
/*    */ import com.jivesoftware.base.Roster;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.base.UserManager;
/*    */ import com.jivesoftware.base.UserNotFoundException;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.opensymphony.xwork.Validateable;
/*    */ 
/*    */ public class AddressBookRemoveAction extends ForumActionSupport
/*    */   implements Validateable
/*    */ {
/*    */   private long[] userID;
/*    */   private Roster roster;
/*    */ 
/*    */   public long[] getUserID()
/*    */   {
/* 27 */     return this.userID;
/*    */   }
/*    */ 
/*    */   public void setUserID(long[] userID) {
/* 31 */     this.userID = userID;
/*    */   }
/*    */ 
/*    */   public Roster getRoster() {
/* 35 */     return this.roster;
/*    */   }
/*    */ 
/*    */   public String doDefault() {
/* 39 */     if (getAuthToken().isAnonymous())
/* 40 */       return "login";
/*    */     try
/*    */     {
/* 43 */       this.roster = getForumFactory().getPresenceManager().getRoster(getPageUser());
/*    */     }
/*    */     catch (UnauthorizedException ue) {
/* 46 */       return "login";
/*    */     }
/*    */ 
/* 49 */     return "input";
/*    */   }
/*    */ 
/*    */   public void validate() {
/* 53 */     if ((this.userID == null) || (this.userID.length == 0)) {
/* 54 */       addFieldError("userID", "");
/*    */     }
/*    */ 
/* 57 */     for (int i = 0; i < this.userID.length; i++)
/*    */       try {
/* 59 */         getForumFactory().getUserManager().getUser(this.userID[i]);
/*    */       }
/*    */       catch (UserNotFoundException unfe) {
/* 62 */         addFieldError("userNotFound", "");
/*    */       }
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */   {
/* 68 */     if (getAuthToken().isAnonymous())
/* 69 */       return "login";
/*    */     try
/*    */     {
/* 72 */       this.roster = getForumFactory().getPresenceManager().getRoster(getPageUser());
/*    */ 
/* 74 */       for (int i = 0; i < this.userID.length; i++) {
/*    */         try {
/* 76 */           this.roster.removeUser(getForumFactory().getUserManager().getUser(this.userID[i]));
/*    */         }
/*    */         catch (Exception ignored)
/*    */         {
/*    */         }
/*    */       }
/* 82 */       return "success";
/*    */     } catch (UnauthorizedException ue) {
/*    */     }
/* 85 */     return "login";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AddressBookRemoveAction
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class PostFailedException extends NNTPException
/*    */ {
/*    */   private static final int CODE = 441;
/* 28 */   private static final NNTPResponse RESPONSE = new StaticNNTPResponse(441, "posting failed");
/*    */ 
/*    */   public PostFailedException()
/*    */   {
/* 34 */     this.response = RESPONSE;
/*    */   }
/*    */ 
/*    */   public PostFailedException(String reason) {
/* 38 */     super(reason);
/* 39 */     this.response = RESPONSE;
/*    */   }
/*    */ 
/*    */   public PostFailedException(Throwable cause) {
/* 43 */     super(cause);
/* 44 */     this.response = RESPONSE;
/*    */   }
/*    */ 
/*    */   public PostFailedException(String message, Throwable cause) {
/* 48 */     super(message, cause);
/* 49 */     this.response = RESPONSE;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.PostFailedException
 * JD-Core Version:    0.6.2
 */
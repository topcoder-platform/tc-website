/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.AttachmentNotFoundException;
/*     */ import com.jivesoftware.forum.Avatar;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class AvatarProxy
/*     */   implements Avatar
/*     */ {
/*     */   private Avatar avatar;
/*     */   private AuthToken authToken;
/*     */   private Permissions permissions;
/*     */   private ForumFactory forumFactory;
/*     */ 
/*     */   public AvatarProxy(Avatar avatar, AuthToken authToken, Permissions permissions)
/*     */   {
/*  29 */     this.avatar = avatar;
/*  30 */     this.authToken = authToken;
/*  31 */     this.permissions = permissions;
/*  32 */     this.forumFactory = ForumFactory.getInstance(authToken);
/*     */   }
/*     */ 
/*     */   public long getID() {
/*  36 */     return this.avatar.getID();
/*     */   }
/*     */ 
/*     */   public int getModValue() {
/*  40 */     return this.avatar.getModValue();
/*     */   }
/*     */ 
/*     */   public Attachment getAttachment() throws AttachmentNotFoundException {
/*  44 */     return this.avatar.getAttachment();
/*     */   }
/*     */ 
/*     */   public String getProperty(String name) {
/*  48 */     return this.avatar.getProperty(name);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value) throws UnauthorizedException {
/*  52 */     ownerOrAdminCheck();
/*  53 */     this.avatar.setProperty(name, value);
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) throws UnauthorizedException {
/*  57 */     ownerOrAdminCheck();
/*  58 */     this.avatar.deleteProperty(name);
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames() {
/*  62 */     return this.avatar.getPropertyNames();
/*     */   }
/*     */ 
/*     */   public User getOwner() {
/*  66 */     return this.avatar.getOwner();
/*     */   }
/*     */ 
/*     */   public void setModValue(int modValue) throws UnauthorizedException {
/*  70 */     adminCheck();
/*  71 */     this.avatar.setModValue(modValue);
/*     */   }
/*     */ 
/*     */   private void ownerOrAdminCheck()
/*     */     throws UnauthorizedException
/*     */   {
/*  77 */     if ((!this.permissions.hasPermission(576460752303423488L)) && (!this.permissions.hasPermission(8192L)) && (!this.permissions.hasPermission(256L)) && (!this.permissions.hasPermission(512L)) && (!this.forumFactory.isAuthorized(128L)))
/*     */     {
/*  82 */       throw new UnauthorizedException();
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  90 */       ForumFactory factory = ForumFactory.getInstance(this.authToken);
/*  91 */       User currentUser = factory.getUserManager().getUser(this.authToken.getUserID());
/*     */ 
/*  93 */       if ((this.avatar.getOwner() != null) && (!this.avatar.getOwner().equals(currentUser))) {
/*  94 */         throw new UnauthorizedException("User is not the avatar owner or an admin");
/*     */       }
/*     */     }
/*     */     catch (UserNotFoundException e)
/*     */     {
/*  99 */       throw new UnauthorizedException("User must be the owner of the avatar or SYSTEM_ADMIN to perform action");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void adminCheck()
/*     */     throws UnauthorizedException
/*     */   {
/* 107 */     if ((!this.permissions.hasPermission(576460752303423488L)) && (!this.permissions.hasPermission(256L)) && (!this.permissions.hasPermission(512L)) && (!this.forumFactory.isAuthorized(128L)))
/*     */     {
/* 111 */       throw new UnauthorizedException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.AvatarProxy
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum.net;

public abstract interface ConnectionMonitor extends Monitor
{
  public abstract void addSample(Connection paramConnection);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.ConnectionMonitor
 * JD-Core Version:    0.6.2
 */
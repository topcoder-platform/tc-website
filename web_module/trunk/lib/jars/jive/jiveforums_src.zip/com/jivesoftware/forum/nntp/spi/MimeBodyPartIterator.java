/*    */ package com.jivesoftware.forum.nntp.spi;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ public class MimeBodyPartIterator extends PeekIterator
/*    */ {
/*    */   private String boundary;
/*    */ 
/*    */   public MimeBodyPartIterator(Iterator bodyIterator, String boundaryMarker)
/*    */   {
/* 40 */     super(bodyIterator);
/* 41 */     this.boundary = boundaryMarker;
/*    */   }
/*    */ 
/*    */   public boolean hasNext()
/*    */   {
/* 50 */     boolean next = false;
/* 51 */     if (this.boundary != null) {
/* 52 */       String line = (String)peek();
/* 53 */       if (line.indexOf(this.boundary) == -1) {
/* 54 */         next = true;
/*    */       }
/*    */     }
/* 57 */     return next;
/*    */   }
/*    */ 
/*    */   public boolean hasNextBodyPart()
/*    */   {
/* 68 */     boolean next = false;
/* 69 */     if (!hasNext()) {
/* 70 */       String line = (String)peek();
/*    */ 
/* 72 */       if (line.indexOf(this.boundary + "--") == -1) {
/* 73 */         next = true;
/*    */       }
/*    */     }
/* 76 */     return next;
/*    */   }
/*    */ 
/*    */   public Object next()
/*    */   {
/* 85 */     if (!hasNext()) {
/* 86 */       throw new NoSuchElementException();
/*    */     }
/* 88 */     return super.next();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.MimeBodyPartIterator
 * JD-Core Version:    0.6.2
 */
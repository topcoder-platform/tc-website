package com.jivesoftware.forum;

import com.jivesoftware.base.AuthToken;
import com.jivesoftware.base.FilterManager;
import com.jivesoftware.base.Permissions;
import com.jivesoftware.base.PermissionsManager;
import com.jivesoftware.base.UnauthorizedException;
import com.jivesoftware.base.User;
import com.jivesoftware.forum.gateway.GatewayManager;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

public abstract interface Forum
{
  public abstract long getID();

  public abstract String getName();

  public abstract void setName(String paramString)
    throws UnauthorizedException;

  public abstract String getNNTPName();

  public abstract void setNNTPName(String paramString)
    throws UnauthorizedException, NameAlreadyExistsException;

  public abstract String getDescription();

  public abstract void setDescription(String paramString)
    throws UnauthorizedException;

  public abstract Date getCreationDate();

  public abstract void setCreationDate(Date paramDate)
    throws UnauthorizedException;

  public abstract Date getModificationDate();

  public abstract void setModificationDate(Date paramDate)
    throws UnauthorizedException;

  public abstract int getModerationDefaultThreadValue();

  public abstract void setModerationDefaultThreadValue(int paramInt)
    throws UnauthorizedException;

  public abstract int getModerationDefaultMessageValue();

  public abstract void setModerationDefaultMessageValue(int paramInt)
    throws UnauthorizedException;

  public abstract int getMinForumIndex();

  public abstract int getMaxForumIndex();

  public abstract String getProperty(String paramString);

  public abstract Collection getProperties(String paramString);

  public abstract void setProperty(String paramString1, String paramString2)
    throws UnauthorizedException;

  public abstract void deleteProperty(String paramString)
    throws UnauthorizedException;

  public abstract Iterator getPropertyNames();

  public abstract ForumCategory getForumCategory();

  public abstract ForumThread getThread(long paramLong)
    throws ForumThreadNotFoundException;

  public abstract ForumThread createThread(ForumMessage paramForumMessage)
    throws UnauthorizedException;

  public abstract ForumMessage createMessage();

  public abstract ForumMessage createMessage(User paramUser)
    throws UnauthorizedException;

  public abstract void addThread(ForumThread paramForumThread)
    throws MessageRejectedException, UnauthorizedException;

  public abstract void deleteThread(ForumThread paramForumThread)
    throws UnauthorizedException;

  public abstract void moveThread(ForumThread paramForumThread, Forum paramForum)
    throws UnauthorizedException, IllegalArgumentException;

  public abstract ForumThreadIterator getThreads();

  public abstract ForumThreadIterator getThreads(ResultFilter paramResultFilter);

  public abstract Iterator getPopularThreads();

  public abstract ForumMessageIterator getMessages();

  public abstract ForumMessageIterator getMessages(ResultFilter paramResultFilter);

  public abstract int getThreadCount();

  public abstract int getThreadCount(ResultFilter paramResultFilter);

  public abstract int getMessageCount();

  public abstract int getMessageCount(ResultFilter paramResultFilter);

  public abstract ForumMessage getLatestMessage();

  public abstract Query createQuery();

  public abstract FilterManager getFilterManager();

  public abstract InterceptorManager getInterceptorManager()
    throws UnauthorizedException;

  public abstract GatewayManager getGatewayManager()
    throws UnauthorizedException;

  public abstract PermissionsManager getPermissionsManager()
    throws UnauthorizedException;

  public abstract Permissions getPermissions(AuthToken paramAuthToken);

  public abstract boolean isAuthorized(long paramLong);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.Forum
 * JD-Core Version:    0.6.2
 */
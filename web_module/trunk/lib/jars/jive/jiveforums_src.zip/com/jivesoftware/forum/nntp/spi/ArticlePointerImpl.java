/*     */ package com.jivesoftware.forum.nntp.spi;
/*     */ 
/*     */ import com.jivesoftware.forum.nntp.Article;
/*     */ import com.jivesoftware.forum.nntp.ArticleFilter;
/*     */ import com.jivesoftware.forum.nntp.ArticleNotFoundException;
/*     */ import com.jivesoftware.forum.nntp.ArticleNotSelectedException;
/*     */ import com.jivesoftware.forum.nntp.ArticlePointer;
/*     */ import com.jivesoftware.forum.nntp.MessageID;
/*     */ import com.jivesoftware.forum.nntp.NewsGroup;
/*     */ import com.jivesoftware.forum.nntp.NewsGroupFilter;
/*     */ import com.jivesoftware.forum.nntp.NewsGroupNotFoundException;
/*     */ import com.jivesoftware.forum.nntp.NoGroupSelectedException;
/*     */ import com.jivesoftware.forum.nntp.NoPermissionException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class ArticlePointerImpl
/*     */   implements ArticlePointer
/*     */ {
/*  27 */   private long groupID = -1L;
/*     */ 
/*  32 */   private int articleNumber = -1;
/*     */   private ForumSession session;
/*     */ 
/*     */   public ArticlePointerImpl(ForumSession session)
/*     */   {
/*  45 */     this.session = session;
/*     */   }
/*     */ 
/*     */   public NewsGroup setGroup(String name)
/*     */     throws NoPermissionException, NewsGroupNotFoundException
/*     */   {
/*  52 */     this.groupID = -1L;
/*  53 */     this.articleNumber = -1;
/*     */ 
/*  55 */     NewsGroup group = this.session.getNewsGroup(name);
/*  56 */     this.groupID = group.getID();
/*  57 */     this.articleNumber = group.getFirstArticleNumber();
/*  58 */     return group;
/*     */   }
/*     */ 
/*     */   public Article getArticle(int articleNumber)
/*     */     throws NoGroupSelectedException, ArticleNotFoundException, NoPermissionException
/*     */   {
/*  64 */     checkGroupSelected();
/*  65 */     this.articleNumber = articleNumber;
/*  66 */     return this.session.getArticle(this.groupID, articleNumber);
/*     */   }
/*     */ 
/*     */   public Article getArticle(String messageID)
/*     */     throws ArticleNotFoundException, NoPermissionException
/*     */   {
/*  72 */     return this.session.getArticle(MessageID.parseMessageID(messageID));
/*     */   }
/*     */ 
/*     */   public Article getCurrentArticle()
/*     */     throws ArticleNotFoundException, NoPermissionException, ArticleNotSelectedException, NoGroupSelectedException
/*     */   {
/*  78 */     checkGroupSelected();
/*  79 */     checkArticleSelected();
/*  80 */     return this.session.getArticle(this.groupID, this.articleNumber);
/*     */   }
/*     */ 
/*     */   public int getCurrentArticleNumber() throws ArticleNotSelectedException {
/*  84 */     checkArticleSelected();
/*  85 */     return this.articleNumber;
/*     */   }
/*     */ 
/*     */   public Iterator getArticles(ArticleFilter filter)
/*     */     throws NoGroupSelectedException, ArticleNotSelectedException, NoPermissionException, ArticleNotFoundException
/*     */   {
/*  91 */     checkGroupSelected();
/*  92 */     checkArticleSelected();
/*  93 */     return this.session.getArticles(NewsGroupFilter.getSingleGroupByIDFilter(this.groupID), filter);
/*     */   }
/*     */ 
/*     */   public NewsGroup getGroup() throws NoGroupSelectedException, NoPermissionException {
/*  97 */     checkGroupSelected();
/*     */     try {
/*  99 */       return this.session.getNewsGroup(this.groupID);
/*     */     } catch (NewsGroupNotFoundException e) {
/*     */     }
/* 102 */     throw new NoGroupSelectedException();
/*     */   }
/*     */ 
/*     */   public Article last()
/*     */     throws NoGroupSelectedException, ArticleNotFoundException, ArticleNotSelectedException, NoPermissionException
/*     */   {
/* 109 */     checkGroupSelected();
/* 110 */     checkArticleSelected();
/* 111 */     Article lastArticle = this.session.getLastArticle(this.groupID, this.articleNumber);
/* 112 */     this.articleNumber = lastArticle.getNumber();
/* 113 */     return lastArticle;
/*     */   }
/*     */ 
/*     */   public Article next()
/*     */     throws NoGroupSelectedException, ArticleNotFoundException, ArticleNotSelectedException, NoPermissionException
/*     */   {
/* 119 */     checkGroupSelected();
/* 120 */     checkArticleSelected();
/* 121 */     Article nextArticle = this.session.getNextArticle(this.groupID, this.articleNumber);
/* 122 */     this.articleNumber = nextArticle.getNumber();
/* 123 */     return nextArticle;
/*     */   }
/*     */ 
/*     */   private void checkGroupSelected()
/*     */     throws NoGroupSelectedException
/*     */   {
/* 133 */     if (this.groupID == -1L)
/* 134 */       throw new NoGroupSelectedException();
/*     */   }
/*     */ 
/*     */   private void checkArticleSelected()
/*     */     throws ArticleNotSelectedException
/*     */   {
/* 145 */     if (this.articleNumber == -1)
/* 146 */       throw new ArticleNotSelectedException();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.ArticlePointerImpl
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ public class EditAttachAction extends AttachAction
/*    */ {
/*    */   public boolean isEdit()
/*    */   {
/* 21 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.EditAttachAction
 * JD-Core Version:    0.6.2
 */
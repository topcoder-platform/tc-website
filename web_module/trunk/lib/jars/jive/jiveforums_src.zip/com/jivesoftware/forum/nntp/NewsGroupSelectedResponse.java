/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class NewsGroupSelectedResponse extends StaticNNTPResponse
/*    */ {
/*    */   private static final int CODE = 211;
/*    */ 
/*    */   private NewsGroupSelectedResponse(int code, String text)
/*    */   {
/* 30 */     super(code, text);
/*    */   }
/*    */ 
/*    */   public static NewsGroupSelectedResponse getResponse(NewsGroup group)
/*    */   {
/* 40 */     StringBuffer b = new StringBuffer(Long.toString(group.getArticleCount()));
/* 41 */     b.append(" ").append(Long.toString(group.getFirstArticleNumber()));
/* 42 */     b.append(" ").append(Long.toString(group.getLastArticleNumber()));
/* 43 */     b.append(" ").append(group.getName());
/* 44 */     b.append(" ").append("group selected");
/* 45 */     return new NewsGroupSelectedResponse(211, b.toString());
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NewsGroupSelectedResponse
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum.proxy;

import com.jivesoftware.base.AuthToken;

abstract interface ProxyFactory
{
  public abstract Object createProxy(Object paramObject, AuthToken paramAuthToken);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.ProxyFactory
 * JD-Core Version:    0.6.2
 */
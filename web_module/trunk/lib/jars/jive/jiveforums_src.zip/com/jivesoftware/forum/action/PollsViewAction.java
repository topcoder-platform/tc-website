/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.PollManager;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.action.JiveObjectLoader;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.action.util.Pageable;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PollsViewAction extends ForumActionSupport
/*     */   implements Pageable, JiveObjectLoader
/*     */ {
/*     */   public static final int NUM_POLLS_PER_PAGE = 15;
/*  36 */   private long objectID = 0L;
/*  37 */   private int objectType = -1;
/*  38 */   private long categoryID = 0L;
/*  39 */   private long forumID = 0L;
/*  40 */   private int start = 0;
/*     */   private Forum forum;
/*     */   private ForumCategory category;
/*     */   private PollManager manager;
/*  47 */   private int pollCount = -1;
/*     */   private ResultFilter resultFilter;
/*     */   private Iterator activePolls;
/*     */ 
/*     */   public long getObjectID()
/*     */   {
/*  55 */     return this.objectID;
/*     */   }
/*     */ 
/*     */   public void setObjectID(long objectID)
/*     */   {
/*  62 */     this.objectID = objectID;
/*     */   }
/*     */ 
/*     */   public int getObjectType()
/*     */   {
/*  69 */     return this.objectType;
/*     */   }
/*     */ 
/*     */   public void setObjectType(int objectType)
/*     */   {
/*  76 */     this.objectType = objectType;
/*     */   }
/*     */ 
/*     */   public long getCategoryID()
/*     */   {
/*  83 */     return this.categoryID;
/*     */   }
/*     */ 
/*     */   public void setCategoryID(long categoryID)
/*     */   {
/*  90 */     this.categoryID = categoryID;
/*     */   }
/*     */ 
/*     */   public long getForumID()
/*     */   {
/*  97 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID)
/*     */   {
/* 104 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public int getStart()
/*     */   {
/* 111 */     return this.start;
/*     */   }
/*     */ 
/*     */   public void setStart(int start)
/*     */   {
/* 118 */     this.start = start;
/*     */   }
/*     */ 
/*     */   public int getTotalItemCount()
/*     */   {
/* 125 */     if (this.pollCount == -1) {
/* 126 */       if (this.category != null) {
/* 127 */         this.pollCount = getManager().getActivePollCount(14, this.category.getID());
/*     */       }
/* 129 */       else if (this.forum != null) {
/* 130 */         this.pollCount = getManager().getActivePollCount(0, this.forum.getID());
/*     */       }
/*     */       else {
/* 133 */         this.pollCount = getManager().getActivePollCount();
/*     */       }
/*     */     }
/* 136 */     return this.pollCount;
/*     */   }
/*     */ 
/*     */   public ResultFilter getResultFilter()
/*     */   {
/* 143 */     if (this.resultFilter == null) {
/* 144 */       this.resultFilter = new ResultFilter();
/* 145 */       this.resultFilter.setStartIndex(getStart());
/* 146 */       this.resultFilter.setNumResults(15);
/*     */     }
/* 148 */     return this.resultFilter;
/*     */   }
/*     */ 
/*     */   public boolean isCategoryPollList()
/*     */   {
/* 155 */     return this.category != null;
/*     */   }
/*     */ 
/*     */   public boolean isForumPollList()
/*     */   {
/* 162 */     return this.forum != null;
/*     */   }
/*     */ 
/*     */   public boolean isSystemPollList()
/*     */   {
/* 169 */     return (!isCategoryPollList()) && (!isForumPollList());
/*     */   }
/*     */ 
/*     */   public Forum getForum()
/*     */   {
/* 176 */     return this.forum;
/*     */   }
/*     */ 
/*     */   public ForumCategory getCategory()
/*     */   {
/* 183 */     return this.category;
/*     */   }
/*     */ 
/*     */   public PollManager getManager()
/*     */   {
/* 190 */     if (this.manager == null) {
/* 191 */       this.manager = getForumFactory().getPollManager();
/*     */     }
/* 193 */     return this.manager;
/*     */   }
/*     */ 
/*     */   public Iterator getActivePolls()
/*     */   {
/* 200 */     Iterator polls = this.activePolls;
/* 201 */     int i = this.start;
/* 202 */     List pollList = new LinkedList();
/* 203 */     if (polls != null) {
/* 204 */       for (int j = 0; (j < i) && (polls.hasNext()); j++) {
/* 205 */         polls.next();
/*     */       }
/* 207 */       i = 0;
/* 208 */       int n = getResultFilter().getNumResults();
/* 209 */       while ((i < n) && (polls.hasNext())) {
/* 210 */         pollList.add(polls.next());
/* 211 */         i++;
/*     */       }
/*     */     }
/* 214 */     return pollList.iterator();
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/*     */     try
/*     */     {
/* 225 */       if (this.category != null) {
/* 226 */         this.activePolls = getManager().getActivePolls(14, this.category.getID());
/*     */       }
/* 228 */       else if (this.forum != null) {
/* 229 */         this.activePolls = getManager().getActivePolls(0, this.forum.getID());
/*     */       }
/*     */       else
/* 232 */         this.activePolls = getManager().getActivePolls();
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 236 */       return "unauthorized";
/*     */     }
/* 238 */     return "success";
/*     */   }
/*     */ 
/*     */   public String loadObjects()
/*     */     throws Exception
/*     */   {
/* 248 */     switch (this.objectType) {
/*     */     case 0:
/* 250 */       this.forumID = this.objectID;
/* 251 */       break;
/*     */     case 14:
/* 253 */       this.categoryID = this.objectID;
/* 254 */       break;
/*     */     }
/*     */ 
/* 260 */     if (this.categoryID > 0L) {
/*     */       try {
/* 262 */         this.category = getForumFactory().getForumCategory(getCategoryID());
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e) {
/* 265 */         addFieldError("categoryID", String.valueOf(this.categoryID));
/* 266 */         return "notfound";
/*     */       }
/*     */     }
/*     */ 
/* 270 */     if (this.forumID > 0L) {
/*     */       try {
/* 272 */         this.forum = getForumFactory().getForum(getForumID());
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 275 */         addFieldError("forumID", String.valueOf(this.forumID));
/* 276 */         return "notfound";
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 279 */         addFieldError("forumID", String.valueOf(this.forumID));
/* 280 */         return "unauthorized";
/*     */       }
/*     */     }
/* 283 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PollsViewAction
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.database.sequence.SequenceManager;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.AttachmentException;
/*     */ import com.jivesoftware.forum.AttachmentNotFoundException;
/*     */ import com.jivesoftware.forum.Avatar;
/*     */ import com.jivesoftware.forum.AvatarException;
/*     */ import com.jivesoftware.forum.AvatarManagerFactory;
/*     */ import com.jivesoftware.forum.AvatarNotFoundException;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheSizes;
/*     */ import com.jivesoftware.util.Cacheable;
/*     */ import com.jivesoftware.util.ExtendedPropertyUtils;
/*     */ import com.jivesoftware.util.ExternalizableLiteUtil;
/*     */ import com.tangosol.io.ExternalizableLite;
/*     */ import com.tangosol.util.ExternalizableHelper;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collections;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DbAvatar
/*     */   implements Avatar, Cacheable, ExternalizableLite
/*     */ {
/*     */   private static final String LOAD_BY_ID = "SELECT avatarID,modValue,ownerID FROM jiveAvatar WHERE avatarID = ?";
/*     */   private static final String SAVE_AVATAR = "UPDATE jiveAvatar SET modValue = ? WHERE avatarID = ?";
/*     */   private static final String ADD_AVATAR = "INSERT INTO jiveAvatar (avatarID, modValue, ownerID) VALUES (?, ?, ?)";
/*     */   private static final String LOAD_ATTACHMENT = "SELECT attachmentID FROM jiveAttachment WHERE objectType=26 AND objectID=?";
/*     */   private static final String LOAD_PROPERTIES = "SELECT name, propValue FROM jiveAvatarProp WHERE avatarID=?";
/*     */   private static final String INSERT_PROPERTY = "INSERT INTO jiveAvatarProp (avatarID,name,propValue) VALUES (?,?,?)";
/*     */   private static final String UPDATE_PROPERTY = "UPDATE jiveAvatarProp SET propValue=? WHERE name=? AND avatarID=?";
/*     */   private static final String DELETE_PROPERTY = "DELETE FROM jiveAvatarProp WHERE avatarID=? AND name=?";
/*  73 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */   private static final boolean LAZY_PROP_LOADING = true;
/*  85 */   private long id = -1L;
/*  86 */   private long ownerID = -1L;
/*  87 */   private int modValue = 0;
/*  88 */   private long attachmentID = -1L;
/*     */   private Map properties;
/*     */ 
/*     */   public DbAvatar(User owner, String name, String contentType, InputStream in)
/*     */     throws UnauthorizedException, AvatarException
/*     */   {
/*  99 */     this.id = SequenceManager.nextID(26);
/*     */ 
/* 101 */     if (owner != null) {
/* 102 */       this.ownerID = owner.getID();
/*     */     }
/*     */ 
/* 105 */     insertIntoDb();
/*     */     try
/*     */     {
/* 109 */       DbAttachment attachment = new DbAttachment(26, this.id, name, contentType, in);
/*     */ 
/* 112 */       this.attachmentID = attachment.getID();
/*     */     }
/*     */     catch (AttachmentException e)
/*     */     {
/* 116 */       throw new AvatarException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DbAvatar(long id)
/*     */     throws AvatarNotFoundException
/*     */   {
/* 128 */     if (id < 0L) {
/* 129 */       throw new AvatarNotFoundException("Id " + id + " is not valid");
/*     */     }
/*     */ 
/* 132 */     this.id = id;
/* 133 */     loadFromDb();
/*     */   }
/*     */ 
/*     */   public DbAvatar()
/*     */   {
/*     */   }
/*     */ 
/*     */   public long getID()
/*     */   {
/* 145 */     return this.id;
/*     */   }
/*     */ 
/*     */   public User getOwner() {
/* 149 */     if (this.ownerID > 0L) {
/*     */       try {
/* 151 */         return FACTORY.getUserManager().getUser(this.ownerID);
/*     */       }
/*     */       catch (Exception e) {
/* 154 */         Log.error(e);
/*     */       }
/*     */     }
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */   public int getModValue() {
/* 161 */     return this.modValue;
/*     */   }
/*     */ 
/*     */   public void setModValue(int modValue) throws UnauthorizedException {
/* 165 */     this.modValue = modValue;
/* 166 */     saveToDb();
/*     */   }
/*     */ 
/*     */   public Attachment getAttachment() throws AttachmentNotFoundException
/*     */   {
/* 171 */     if (this.attachmentID > 0L) {
/* 172 */       return FACTORY.cacheManager.getAttachment(this.attachmentID);
/*     */     }
/*     */ 
/* 175 */     DbAttachment attachment = null;
/*     */ 
/* 177 */     Connection con = null;
/* 178 */     PreparedStatement pstmt = null;
/*     */     try {
/* 180 */       con = ConnectionManager.getConnection();
/* 181 */       pstmt = con.prepareStatement("SELECT attachmentID FROM jiveAttachment WHERE objectType=26 AND objectID=?");
/* 182 */       pstmt.setLong(1, this.id);
/*     */ 
/* 185 */       ResultSet rs = pstmt.executeQuery();
/* 186 */       if (rs.next()) {
/* 187 */         this.attachmentID = rs.getLong(1);
/* 188 */         attachment = FACTORY.cacheManager.getAttachment(this.attachmentID);
/*     */       }
/* 190 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 193 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 196 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 199 */     return attachment;
/*     */   }
/*     */ 
/*     */   public String getProperty(String name) {
/* 203 */     if (this.properties == null) {
/* 204 */       loadPropertiesFromDb();
/*     */     }
/* 206 */     return (String)this.properties.get(name);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value) throws UnauthorizedException {
/* 210 */     if (this.properties == null) {
/* 211 */       loadPropertiesFromDb();
/*     */     }
/*     */ 
/* 214 */     value = ExtendedPropertyUtils.validateExtendedProperty(name, value);
/*     */ 
/* 216 */     if (this.properties.containsKey(name))
/*     */     {
/* 219 */       if (!value.equals(this.properties.get(name))) {
/* 220 */         this.properties.put(name, value);
/* 221 */         updatePropertyInDb(name, value);
/*     */ 
/* 223 */         AvatarManagerFactory.avatarCache.put(new Long(this.id), this);
/*     */       }
/*     */     } else {
/* 226 */       this.properties.put(name, value);
/* 227 */       insertPropertyIntoDb(name, value);
/*     */ 
/* 229 */       AvatarManagerFactory.avatarCache.put(new Long(this.id), this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) throws UnauthorizedException
/*     */   {
/* 235 */     if (this.properties == null) {
/* 236 */       loadPropertiesFromDb();
/*     */     }
/*     */ 
/* 239 */     if (this.properties.containsKey(name)) {
/* 240 */       this.properties.remove(name);
/* 241 */       deletePropertyFromDb(name);
/*     */ 
/* 243 */       AvatarManagerFactory.avatarCache.put(new Long(this.id), this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames() {
/* 248 */     if (this.properties == null) {
/* 249 */       loadPropertiesFromDb();
/*     */     }
/* 251 */     return Collections.unmodifiableSet(this.properties.keySet()).iterator();
/*     */   }
/*     */ 
/*     */   public int getCachedSize()
/*     */   {
/* 256 */     int size = 0;
/* 257 */     size += CacheSizes.sizeOfLong();
/* 258 */     size += CacheSizes.sizeOfLong();
/* 259 */     size += CacheSizes.sizeOfInt();
/* 260 */     size += CacheSizes.sizeOfLong();
/* 261 */     size += CacheSizes.sizeOfMap(this.properties);
/* 262 */     return size;
/*     */   }
/*     */ 
/*     */   public void readExternal(DataInput in) throws IOException {
/* 266 */     this.id = ExternalizableHelper.readLong(in);
/* 267 */     this.ownerID = ExternalizableHelper.readLong(in);
/* 268 */     this.modValue = ExternalizableHelper.readInt(in);
/* 269 */     this.attachmentID = ExternalizableHelper.readLong(in);
/* 270 */     this.properties = ExternalizableLiteUtil.readStringMap(in);
/*     */   }
/*     */ 
/*     */   public void writeExternal(DataOutput out) throws IOException {
/* 274 */     ExternalizableHelper.writeLong(out, this.id);
/* 275 */     ExternalizableHelper.writeLong(out, this.ownerID);
/* 276 */     ExternalizableHelper.writeInt(out, this.modValue);
/* 277 */     ExternalizableHelper.writeLong(out, this.attachmentID);
/* 278 */     ExternalizableLiteUtil.writeStringMap(out, this.properties);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 283 */     if (this == o) {
/* 284 */       return true;
/*     */     }
/* 286 */     if (!(o instanceof DbAvatar)) {
/* 287 */       return false;
/*     */     }
/*     */ 
/* 290 */     DbAvatar dbAvatar = (DbAvatar)o;
/*     */ 
/* 292 */     if (this.id != dbAvatar.id) {
/* 293 */       return false;
/*     */     }
/* 295 */     if (this.modValue != dbAvatar.modValue) {
/* 296 */       return false;
/*     */     }
/* 298 */     if (this.ownerID != dbAvatar.ownerID) {
/* 299 */       return false;
/*     */     }
/*     */ 
/* 302 */     return true;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 307 */     int result = (int)(this.id ^ this.id >>> 32);
/* 308 */     result = 2543 * result + (int)(this.ownerID ^ this.ownerID >>> 32);
/* 309 */     result = 2543 * result + this.modValue;
/* 310 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 314 */     return "Avatar [ id=" + this.id + ", modValue=" + this.modValue + ", ownerID=" + this.ownerID + " ]";
/*     */   }
/*     */ 
/*     */   private void insertIntoDb()
/*     */   {
/* 325 */     Connection con = null;
/* 326 */     PreparedStatement pstmt = null;
/* 327 */     boolean abortTransaction = false;
/*     */     try
/*     */     {
/* 331 */       con = ConnectionManager.getTransactionConnection();
/*     */ 
/* 333 */       pstmt = con.prepareStatement("INSERT INTO jiveAvatar (avatarID, modValue, ownerID) VALUES (?, ?, ?)");
/* 334 */       pstmt.setLong(1, this.id);
/* 335 */       pstmt.setInt(2, this.modValue);
/* 336 */       if (this.ownerID > 0L) {
/* 337 */         pstmt.setLong(3, this.ownerID);
/*     */       }
/*     */       else {
/* 340 */         pstmt.setNull(3, -5);
/*     */       }
/*     */ 
/* 343 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle)
/*     */     {
/* 347 */       Log.error(sqle);
/* 348 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 351 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadFromDb()
/*     */     throws AvatarNotFoundException
/*     */   {
/* 359 */     Connection con = null;
/* 360 */     PreparedStatement pstmt = null;
/* 361 */     ResultSet rs = null;
/*     */     try
/*     */     {
/* 364 */       con = ConnectionManager.getConnection();
/*     */ 
/* 367 */       pstmt = con.prepareStatement("SELECT avatarID,modValue,ownerID FROM jiveAvatar WHERE avatarID = ?");
/* 368 */       pstmt.setLong(1, this.id);
/*     */ 
/* 370 */       rs = pstmt.executeQuery();
/*     */ 
/* 372 */       if (!rs.next()) {
/* 373 */         throw new AvatarNotFoundException("Avatar " + getID() + "could not be loaded from the database");
/*     */       }
/*     */ 
/* 377 */       this.id = rs.getLong(1);
/* 378 */       this.modValue = rs.getInt(2);
/* 379 */       this.ownerID = rs.getLong(3);
/*     */     }
/*     */     catch (SQLException sqle)
/*     */     {
/* 400 */       Log.error(sqle);
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/* 405 */         if (rs != null) rs.close(); 
/*     */       } catch (Exception e) { Log.error(e); }
/*     */ 
/* 408 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void saveToDb()
/*     */   {
/* 416 */     Connection conn = null;
/* 417 */     PreparedStatement s = null;
/*     */     try
/*     */     {
/* 420 */       conn = ConnectionManager.getConnection();
/*     */ 
/* 422 */       s = conn.prepareStatement("UPDATE jiveAvatar SET modValue = ? WHERE avatarID = ?");
/* 423 */       s.setInt(1, this.modValue);
/* 424 */       s.setLong(2, this.id);
/*     */ 
/* 426 */       s.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 429 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 432 */       ConnectionManager.closeConnection(s, conn);
/*     */     }
/*     */ 
/* 437 */     AvatarManagerFactory.avatarCache.put(new Long(this.id), this);
/*     */   }
/*     */ 
/*     */   private synchronized void loadPropertiesFromDb()
/*     */   {
/* 445 */     this.properties = new Hashtable();
/* 446 */     Connection con = null;
/* 447 */     PreparedStatement pstmt = null;
/*     */     try {
/* 449 */       con = ConnectionManager.getConnection();
/* 450 */       pstmt = con.prepareStatement("SELECT name, propValue FROM jiveAvatarProp WHERE avatarID=?");
/* 451 */       pstmt.setLong(1, this.id);
/* 452 */       ResultSet rs = pstmt.executeQuery();
/* 453 */       while (rs.next()) {
/* 454 */         String name = rs.getString(1);
/* 455 */         String value = rs.getString(2);
/* 456 */         this.properties.put(name, value);
/*     */       }
/* 458 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 461 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 464 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 469 */     AvatarManagerFactory.avatarCache.put(new Long(this.id), this);
/*     */   }
/*     */ 
/*     */   private void insertPropertyIntoDb(String name, String value)
/*     */   {
/* 476 */     Connection con = null;
/* 477 */     PreparedStatement pstmt = null;
/* 478 */     boolean abortTransaction = false;
/*     */     try {
/* 480 */       con = ConnectionManager.getTransactionConnection();
/* 481 */       pstmt = con.prepareStatement("INSERT INTO jiveAvatarProp (avatarID,name,propValue) VALUES (?,?,?)");
/* 482 */       pstmt.setLong(1, this.id);
/* 483 */       pstmt.setString(2, name);
/* 484 */       pstmt.setString(3, value);
/* 485 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 488 */       Log.error(sqle);
/* 489 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 492 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updatePropertyInDb(String name, String value)
/*     */   {
/* 500 */     Connection con = null;
/* 501 */     PreparedStatement pstmt = null;
/* 502 */     boolean abortTransaction = false;
/*     */     try {
/* 504 */       con = ConnectionManager.getTransactionConnection();
/* 505 */       pstmt = con.prepareStatement("UPDATE jiveAvatarProp SET propValue=? WHERE name=? AND avatarID=?");
/* 506 */       pstmt.setString(1, value);
/* 507 */       pstmt.setString(2, name);
/* 508 */       pstmt.setLong(3, this.id);
/* 509 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 512 */       Log.error(sqle);
/* 513 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 516 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void deletePropertyFromDb(String name)
/*     */   {
/* 524 */     Connection con = null;
/* 525 */     PreparedStatement pstmt = null;
/* 526 */     boolean abortTransaction = false;
/*     */     try {
/* 528 */       con = ConnectionManager.getTransactionConnection();
/* 529 */       pstmt = con.prepareStatement("DELETE FROM jiveAvatarProp WHERE avatarID=? AND name=?");
/* 530 */       pstmt.setLong(1, this.id);
/* 531 */       pstmt.setString(2, name);
/* 532 */       pstmt.execute();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 535 */       Log.error(sqle);
/* 536 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 539 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbAvatar
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum;

public class ForumPermissions
{
  public static final long READ_FORUM = 1L;
  public static final long CREATE_MESSAGE = 2L;
  public static final long CREATE_THREAD = 4L;
  public static final long CREATE_MESSAGE_ATTACHMENT = 8L;
  public static final long CREATE_POLL = 16L;
  public static final long PRIVATE_MESSAGE = 32L;
  public static final long RATE_MESSAGE = 64L;
  public static final long MODERATOR = 128L;
  public static final long FORUM_ADMIN = 256L;
  public static final long FORUM_CATEGORY_ADMIN = 512L;
  public static final long VOTE_IN_POLL = 1024L;
  public static final long CREATE_PRIVATE_MESSAGE_ATTACHMENT = 2048L;
  public static final long ANNOUNCEMENT_ADMIN = 4096L;
  public static final long AVATAR = 8192L;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.ForumPermissions
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum;

import com.jivesoftware.base.UnauthorizedException;
import com.jivesoftware.base.User;
import java.util.Date;
import java.util.Iterator;

public abstract interface AnnouncementManager
{
  public abstract Announcement createAnnouncement(User paramUser)
    throws UnauthorizedException;

  public abstract Announcement createAnnouncement(User paramUser, ForumCategory paramForumCategory)
    throws UnauthorizedException;

  public abstract Announcement createAnnouncement(User paramUser, Forum paramForum)
    throws UnauthorizedException;

  public abstract void addAnnouncement(Announcement paramAnnouncement)
    throws UnauthorizedException;

  public abstract Announcement getAnnouncement(long paramLong)
    throws AnnouncementNotFoundException, UnauthorizedException;

  public abstract int getAnnouncementCount(Object paramObject);

  public abstract int getAnnouncementCount(Object paramObject, Date paramDate1, Date paramDate2);

  public abstract Iterator getAnnouncements(Object paramObject);

  public abstract Iterator getAnnouncements(Object paramObject, Date paramDate1, Date paramDate2);

  public abstract void deleteAnnouncement(Announcement paramAnnouncement)
    throws UnauthorizedException;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.AnnouncementManager
 * JD-Core Version:    0.6.2
 */
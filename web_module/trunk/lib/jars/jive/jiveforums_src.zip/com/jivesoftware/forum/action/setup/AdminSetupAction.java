/*     */ package com.jivesoftware.forum.action.setup;
/*     */ 
/*     */ import com.jivesoftware.base.AuthFactory;
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.util.ClassUtils;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import com.opensymphony.xwork.ModelDriven;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class AdminSetupAction extends SetupActionSupport
/*     */   implements ModelDriven
/*     */ {
/*     */   private Parameters params;
/*     */ 
/*     */   public AdminSetupAction()
/*     */   {
/*  26 */     this.params = new Parameters();
/*     */   }
/*     */ 
/*     */   public Object getModel()
/*     */   {
/*  31 */     return this.params;
/*     */   }
/*     */ 
/*     */   public boolean isJiveUserManager()
/*     */   {
/*  37 */     String userProp = JiveGlobals.getJiveProperty("UserManager.className");
/*  38 */     if ((userProp == null) || (userProp.equals("com.jivesoftware.base.database.DbUserManager"))) {
/*  39 */       return true;
/*     */     }
/*     */ 
/*  42 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isLdapUserManager() {
/*  46 */     String userProp = JiveGlobals.getJiveProperty("UserManager.className");
/*  47 */     if ((userProp != null) && (userProp.equals("com.jivesoftware.base.ldap.LdapUserManager"))) {
/*  48 */       return true;
/*     */     }
/*     */ 
/*  51 */     return false;
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*  57 */     if (isLdapUserManager()) {
/*  58 */       return "ldap";
/*     */     }
/*     */     try
/*     */     {
/*  62 */       AuthToken auth = AuthFactory.getAnonymousAuthToken();
/*  63 */       ForumFactory forumFactory = ForumFactory.getInstance(auth);
/*  64 */       UserManager userManager = forumFactory.getUserManager();
/*  65 */       User admin = userManager.getUser("admin");
/*  66 */       this.params.email = admin.getEmail();
/*     */     }
/*     */     catch (Exception e) {
/*  69 */       Log.error(e);
/*  70 */       addActionError(getText("setup.error.adminsetup.general_error"));
/*     */     }
/*     */ 
/*  73 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/*  74 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/*  75 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "done");
/*  76 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "done");
/*  77 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "in_progress");
/*  78 */     return "input";
/*     */   }
/*     */ 
/*     */   public void validate() {
/*     */     try {
/*  83 */       AuthFactory.getAuthToken("admin", this.params.currentPassword);
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/*  86 */       addFieldError("currentPassword", getText("setup.error.adminsetup.current_password"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public String execute() {
/*  91 */     AuthToken auth = null;
/*     */     try {
/*  93 */       auth = AuthFactory.getAuthToken("admin", this.params.currentPassword);
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/*  96 */       addFieldError("currentPassword", getText("setup.error.adminsetup.current_password"));
/*  97 */       return "error";
/*     */     }
/*     */ 
/* 100 */     if (!"true".equals(getDoContinue())) {
/*     */       try {
/* 102 */         ForumFactory forumFactory = ForumFactory.getInstance(auth);
/* 103 */         UserManager userManager = forumFactory.getUserManager();
/* 104 */         User admin = userManager.getUser("admin");
/* 105 */         admin.setPassword(this.params.password);
/* 106 */         if (this.params.email != null) {
/* 107 */           admin.setEmail(this.params.email);
/*     */         }
/* 109 */         Date now = new Date();
/* 110 */         admin.setCreationDate(now);
/* 111 */         admin.setModificationDate(now);
/*     */       }
/*     */       catch (Exception e) {
/* 114 */         Log.error(e);
/* 115 */         addActionError(getText("setup.error.adminsetup.general_error"));
/* 116 */         return "error";
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 121 */     cleanupSession();
/*     */ 
/* 124 */     com.jivesoftware.util.JiveSetupFilter.setup = true;
/* 125 */     com.jivesoftware.base.PresenceFilter.setup = true;
/*     */     try
/*     */     {
/* 129 */       Class c = ClassUtils.forName("com.jivesoftware.base.stats.BytesSentFilter");
/* 130 */       Field f = c.getField("setup");
/* 131 */       f.set(null, Boolean.TRUE);
/*     */     } catch (Throwable ignored) {
/*     */     }
/*     */     try {
/* 135 */       Class c = ClassUtils.forName("com.jivesoftware.base.stats.ReadStatsFilter");
/* 136 */       Field f = c.getField("setup");
/* 137 */       f.set(null, Boolean.TRUE);
/*     */     }
/*     */     catch (Throwable ignored) {
/*     */     }
/* 141 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/* 142 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/* 143 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "done");
/* 144 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "done");
/* 145 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "done");
/* 146 */     return "next";
/*     */   }
/*     */ 
/*     */   private void cleanupSession() {
/* 150 */     List deletables = new ArrayList(10);
/* 151 */     Iterator keys = ActionContext.getContext().getSession().keySet().iterator();
/* 152 */     while (keys.hasNext()) {
/* 153 */       String key = (String)keys.next();
/* 154 */       if (key.startsWith("jive.")) {
/* 155 */         deletables.add(key);
/*     */       }
/*     */     }
/*     */ 
/* 159 */     for (int i = 0; i < deletables.size(); i++) {
/* 160 */       String attribName = (String)deletables.get(i);
/* 161 */       ActionContext.getContext().getSession().remove(attribName);
/*     */     }
/*     */   }
/*     */   class Parameters {
/*     */     private String currentPassword;
/*     */     private String password;
/*     */     private String confirmPassword;
/*     */     private String email;
/*     */ 
/*     */     Parameters() {  }
/*     */ 
/* 174 */     public String getCurrentPassword() { return this.currentPassword; }
/*     */ 
/*     */     public void setCurrentPassword(String currentPassword)
/*     */     {
/* 178 */       this.currentPassword = currentPassword;
/*     */     }
/*     */ 
/*     */     public String getPassword() {
/* 182 */       return this.password;
/*     */     }
/*     */ 
/*     */     public void setPassword(String password) {
/* 186 */       this.password = password;
/*     */     }
/*     */ 
/*     */     public String getConfirmPassword() {
/* 190 */       return this.confirmPassword;
/*     */     }
/*     */ 
/*     */     public void setConfirmPassword(String confirmPassword) {
/* 194 */       this.confirmPassword = confirmPassword;
/*     */     }
/*     */ 
/*     */     public String getEmail() {
/* 198 */       return this.email;
/*     */     }
/*     */ 
/*     */     public void setEmail(String email) {
/* 202 */       this.email = email;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.AdminSetupAction
 * JD-Core Version:    0.6.2
 */
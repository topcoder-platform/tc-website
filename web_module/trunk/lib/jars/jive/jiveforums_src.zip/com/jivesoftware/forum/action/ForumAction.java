/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.action.JiveObjectLoader;
/*     */ import com.jivesoftware.base.action.util.RedirectAction;
/*     */ import com.jivesoftware.forum.AnnouncementManager;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.action.util.Pageable;
/*     */ import com.opensymphony.webwork.ServletActionContext;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ForumAction extends ForumActionSupport
/*     */   implements Pageable, JiveObjectLoader
/*     */ {
/*  34 */   private long forumID = 0L;
/*  35 */   private int start = -1;
/*     */   private Forum forum;
/*     */   private ResultFilter resultFilter;
/*     */   private ResultFilter messageResultFilter;
/*  41 */   private int totalItemCount = -1;
/*     */   private Iterator threads;
/*     */   private String threadMode;
/*     */ 
/*     */   public long getForumID()
/*     */   {
/*  52 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID)
/*     */   {
/*  60 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public int getStart()
/*     */   {
/*  73 */     if (this.start == -1) {
/*  74 */       initFields();
/*     */     }
/*  76 */     return this.start;
/*     */   }
/*     */ 
/*     */   public void setStart(int start)
/*     */   {
/*  84 */     this.start = start;
/*     */   }
/*     */ 
/*     */   public Forum getForum()
/*     */   {
/*  94 */     return this.forum;
/*     */   }
/*     */ 
/*     */   protected void setForum(Forum forum)
/*     */   {
/* 104 */     this.forum = forum;
/*     */   }
/*     */ 
/*     */   public int getTotalItemCount()
/*     */   {
/* 116 */     if (this.totalItemCount == -1) {
/* 117 */       initFields();
/*     */     }
/* 119 */     return this.totalItemCount;
/*     */   }
/*     */ 
/*     */   public ResultFilter getResultFilter()
/*     */   {
/* 133 */     if (this.resultFilter == null) {
/* 134 */       initFields();
/*     */     }
/* 136 */     return this.resultFilter;
/*     */   }
/*     */ 
/*     */   public ResultFilter getMessageResultFilter()
/*     */   {
/* 149 */     if (this.messageResultFilter == null) {
/* 150 */       this.messageResultFilter = ResultFilter.createDefaultMessageFilter();
/* 151 */       this.messageResultFilter.setStartIndex(getStart());
/* 152 */       int messageRange = JiveGlobals.getJiveIntProperty("skin.default.defaultMessagesPerPage", 15);
/* 153 */       if (getPageUser() == null)
/*     */         try {
/* 155 */           messageRange = Integer.parseInt(getGuestProperty("jiveMessageRange"));
/*     */         }
/*     */         catch (Exception ignored) {
/*     */         }
/*     */       else try {
/* 160 */           messageRange = Integer.parseInt(getPageUser().getProperty("jiveMessageRange"));
/*     */         }
/*     */         catch (Exception ignored) {
/*     */         } this.messageResultFilter.setNumResults(messageRange);
/*     */     }
/* 165 */     return this.messageResultFilter;
/*     */   }
/*     */ 
/*     */   public void setMessageResultFilter(ResultFilter filter)
/*     */   {
/* 175 */     this.messageResultFilter = filter;
/*     */   }
/*     */ 
/*     */   public String getThreadMode() {
/* 179 */     if (this.threadMode == null) {
/* 180 */       String threadModeProp = JiveGlobals.getJiveProperty("skin.default.threadMode", "success-flat");
/*     */ 
/* 184 */       User user = getPageUser();
/* 185 */       if ((user != null) && (JiveGlobals.getJiveBooleanProperty("skin.default.usersChooseThreadMode", false)))
/*     */       {
/* 188 */         if (user.getProperty("jiveThreadMode") != null) {
/* 189 */           threadModeProp = user.getProperty("jiveThreadMode");
/*     */         }
/*     */       }
/* 192 */       if ("threaded".equals(threadModeProp)) {
/* 193 */         this.threadMode = "success-threaded";
/*     */       }
/* 195 */       else if ("tree".equals(threadModeProp)) {
/* 196 */         this.threadMode = "success-tree";
/*     */       }
/*     */       else {
/* 199 */         this.threadMode = "success-flat";
/*     */       }
/*     */     }
/* 202 */     return this.threadMode;
/*     */   }
/*     */ 
/*     */   public Iterator getThreads()
/*     */   {
/* 214 */     if (this.threads == null) {
/* 215 */       initFields();
/*     */     }
/* 217 */     return this.threads;
/*     */   }
/*     */ 
/*     */   public Iterator getAnnouncements()
/*     */   {
/* 225 */     boolean annEnabled = JiveGlobals.getJiveBooleanProperty("announcements.enabled", true);
/* 226 */     if (annEnabled) {
/* 227 */       return getForumFactory().getAnnouncementManager().getAnnouncements(getForum());
/*     */     }
/*     */ 
/* 230 */     return Collections.EMPTY_LIST.iterator();
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */     throws Exception
/*     */   {
/* 252 */     initFields();
/*     */ 
/* 254 */     RedirectAction.pushPreviousURL(ServletActionContext.getRequest());
/*     */ 
/* 256 */     return "success";
/*     */   }
/*     */ 
/*     */   public String loadObjects() throws Exception
/*     */   {
/*     */     try {
/* 262 */       this.forum = getForumFactory().getForum(this.forumID);
/* 263 */       return "success";
/*     */     }
/*     */     catch (ForumNotFoundException e) {
/* 266 */       addFieldError("forumID", String.valueOf(this.forumID));
/* 267 */       return "notfound";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 271 */       RedirectAction.pushPreviousURL(ServletActionContext.getRequest());
/* 272 */     }return "unauthorized";
/*     */   }
/*     */ 
/*     */   protected void initFields()
/*     */   {
/* 278 */     if (this.start == -1) {
/* 279 */       Integer startIdx = (Integer)ActionContext.getContext().getSession().get("jive.forum." + getForumID() + ".start");
/*     */ 
/* 281 */       if (startIdx == null) {
/* 282 */         startIdx = new Integer(0);
/*     */       }
/* 284 */       this.start = startIdx.intValue();
/*     */     }
/*     */     else {
/* 287 */       ActionContext.getContext().getSession().put("jive.forum." + getForumID() + ".start", new Integer(this.start));
/*     */     }
/*     */ 
/* 292 */     this.resultFilter = ResultFilter.createDefaultThreadFilter();
/* 293 */     this.resultFilter.setStartIndex(getStart());
/* 294 */     int threadRange = JiveGlobals.getJiveIntProperty("skin.default.defaultThreadsPerPage", 15);
/* 295 */     if (getPageUser() == null)
/*     */       try {
/* 297 */         threadRange = Integer.parseInt(getGuestProperty("jiveThreadRange"));
/*     */       }
/*     */       catch (Exception ignored) {
/*     */       }
/*     */     else try {
/* 302 */         threadRange = Integer.parseInt(getPageUser().getProperty("jiveThreadRange"));
/*     */       }
/*     */       catch (Exception ignored) {
/*     */       } this.resultFilter.setNumResults(threadRange);
/*     */ 
/* 308 */     this.totalItemCount = this.forum.getThreadCount(getResultFilter());
/*     */ 
/* 311 */     this.threads = this.forum.getThreads(getResultFilter());
/*     */ 
/* 315 */     if ((this.start > 0) && (!this.threads.hasNext())) {
/* 316 */       this.start = 0;
/* 317 */       this.resultFilter.setStartIndex(getStart());
/* 318 */       this.threads = this.forum.getThreads(getResultFilter());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean loadJiveObjects()
/*     */     throws UnauthorizedException
/*     */   {
/* 343 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.ForumAction
 * JD-Core Version:    0.6.2
 */
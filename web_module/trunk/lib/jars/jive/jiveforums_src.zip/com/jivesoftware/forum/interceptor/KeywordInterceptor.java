/*     */ package com.jivesoftware.forum.interceptor;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.MessageInterceptor;
/*     */ import com.jivesoftware.forum.MessageRejectedException;
/*     */ import com.jivesoftware.util.EmailTask;
/*     */ import com.jivesoftware.util.StringUtils;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.lucene.analysis.Analyzer;
/*     */ import org.apache.lucene.analysis.LowerCaseTokenizer;
/*     */ import org.apache.lucene.analysis.PorterStemFilter;
/*     */ import org.apache.lucene.analysis.StopFilter;
/*     */ import org.apache.lucene.analysis.TokenStream;
/*     */ import org.apache.lucene.analysis.standard.StandardAnalyzer;
/*     */ import org.apache.lucene.document.Document;
/*     */ import org.apache.lucene.document.Field;
/*     */ import org.apache.lucene.index.IndexWriter;
/*     */ import org.apache.lucene.queryParser.QueryParser;
/*     */ import org.apache.lucene.search.Hits;
/*     */ import org.apache.lucene.search.IndexSearcher;
/*     */ import org.apache.lucene.search.Query;
/*     */ import org.apache.lucene.store.RAMDirectory;
/*     */ 
/*     */ public class KeywordInterceptor
/*     */   implements MessageInterceptor
/*     */ {
/*     */   private String moderationQueryString;
/*     */   private String blockQueryString;
/*     */   private String blockError;
/*     */   private String emailQueryString;
/*  48 */   private List emailList = null;
/*  49 */   private boolean stemmingEnabled = false;
/*     */ 
/*  51 */   private String emailName = null;
/*  52 */   private String emailAddress = null;
/*  53 */   private String emailSubject = null;
/*  54 */   private String emailBody = null;
/*     */ 
/*  56 */   private Analyzer analyzer = new StandardAnalyzer();
/*     */ 
/*     */   public KeywordInterceptor()
/*     */   {
/*     */   }
/*     */ 
/*     */   public KeywordInterceptor(int objectType, long objectID)
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean isStemmingEnabled()
/*     */   {
/*  77 */     return this.stemmingEnabled;
/*     */   }
/*     */ 
/*     */   public void setStemmingEnabled(boolean stemmingEnabled)
/*     */   {
/*  92 */     if (this.stemmingEnabled == stemmingEnabled) {
/*  93 */       return;
/*     */     }
/*  95 */     if (stemmingEnabled)
/*     */     {
/*  97 */       this.stemmingEnabled = true;
/*  98 */       this.analyzer = new StemmingAnalyzer(null);
/*     */     }
/*     */     else
/*     */     {
/* 102 */       this.stemmingEnabled = false;
/* 103 */       this.analyzer = new StandardAnalyzer();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getModerationQueryString() {
/* 108 */     return this.moderationQueryString;
/*     */   }
/*     */ 
/*     */   public void setModerationQueryString(String moderationQueryString) {
/* 112 */     this.moderationQueryString = moderationQueryString;
/*     */   }
/*     */ 
/*     */   public String getBlockQueryString() {
/* 116 */     return this.blockQueryString;
/*     */   }
/*     */ 
/*     */   public void setBlockQueryString(String blockQueryString) {
/* 120 */     this.blockQueryString = blockQueryString;
/*     */   }
/*     */ 
/*     */   public String getBlockError() {
/* 124 */     return this.blockError;
/*     */   }
/*     */ 
/*     */   public void setBlockError(String blockError) {
/* 128 */     this.blockError = blockError;
/*     */   }
/*     */ 
/*     */   public String getEmailQueryString()
/*     */   {
/* 138 */     return this.emailQueryString;
/*     */   }
/*     */ 
/*     */   public void setEmailQueryString(String emailQueryString)
/*     */   {
/* 148 */     this.emailQueryString = emailQueryString;
/*     */   }
/*     */ 
/*     */   public String getEmailNotifyList()
/*     */   {
/* 158 */     if ((this.emailList == null) || (this.emailList.isEmpty())) {
/* 159 */       return "";
/*     */     }
/* 161 */     StringBuffer buf = new StringBuffer();
/* 162 */     buf.append(this.emailList.get(0));
/* 163 */     for (int i = 1; i < this.emailList.size(); i++) {
/* 164 */       buf.append(", ");
/* 165 */       buf.append(this.emailList.get(i));
/*     */     }
/* 167 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public void setEmailNotifyList(String notifyList)
/*     */   {
/* 177 */     if ((notifyList == null) || (notifyList.equals(""))) {
/* 178 */       this.emailList = null;
/*     */     }
/*     */     else {
/* 181 */       this.emailList = new ArrayList();
/* 182 */       StringTokenizer tokenizer = new StringTokenizer(notifyList, ",");
/* 183 */       while (tokenizer.hasMoreTokens()) {
/* 184 */         String emailAddress = tokenizer.nextToken().trim();
/* 185 */         this.emailList.add(emailAddress);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getEmailName()
/*     */   {
/* 196 */     return this.emailName;
/*     */   }
/*     */ 
/*     */   public void setEmailName(String emailName)
/*     */   {
/* 205 */     this.emailName = emailName;
/*     */   }
/*     */ 
/*     */   public String getEmailAddress()
/*     */   {
/* 214 */     return this.emailAddress;
/*     */   }
/*     */ 
/*     */   public void setEmailAddress(String emailAddress)
/*     */   {
/* 223 */     this.emailAddress = emailAddress;
/*     */   }
/*     */ 
/*     */   public String getEmailSubject()
/*     */   {
/* 232 */     return this.emailSubject;
/*     */   }
/*     */ 
/*     */   public void setEmailSubject(String emailSubject)
/*     */   {
/* 241 */     this.emailSubject = emailSubject;
/*     */   }
/*     */ 
/*     */   public String getEmailBody()
/*     */   {
/* 250 */     return this.emailBody;
/*     */   }
/*     */ 
/*     */   public void setEmailBody(String emailBody)
/*     */   {
/* 259 */     this.emailBody = emailBody;
/*     */   }
/*     */ 
/*     */   public int getType() {
/* 263 */     return 2;
/*     */   }
/*     */ 
/*     */   public void invokeInterceptor(ForumMessage message, int type)
/*     */     throws MessageRejectedException
/*     */   {
/* 269 */     String text = "";
/* 270 */     if (message.getSubject() != null) {
/* 271 */       text = text + message.getSubject() + " ";
/*     */     }
/* 273 */     if (message.getBody() != null) {
/* 274 */       text = text + message.getBody();
/*     */     }
/*     */ 
/* 278 */     if (type == 0) {
/* 279 */       if ((this.blockQueryString != null) && 
/* 280 */         (hasMatch(this.blockQueryString, text))) {
/* 281 */         String error = getBlockError();
/* 282 */         if (error == null) {
/* 283 */           error = "";
/*     */         }
/* 285 */         throw new MessageRejectedException(error, message);
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 292 */       if ((this.moderationQueryString != null) && 
/* 293 */         (hasMatch(this.moderationQueryString, text))) {
/*     */         try {
/* 295 */           message.setModerationValue(0, null);
/*     */         }
/*     */         catch (UnauthorizedException ue)
/*     */         {
/*     */         }
/*     */       }
/*     */ 
/* 302 */       if ((this.emailQueryString != null) && (this.emailList != null))
/*     */       {
/* 304 */         if (hasMatch(this.emailQueryString, text)) {
/* 305 */           String body = replaceTokens(this.emailBody, message);
/*     */ 
/* 308 */           EmailTask emailTask = new EmailTask();
/* 309 */           for (int i = 0; i < this.emailList.size(); i++) {
/* 310 */             emailTask.addMessage(null, (String)this.emailList.get(i), this.emailName, this.emailAddress, this.emailSubject, body, null);
/*     */           }
/*     */ 
/* 313 */           TaskEngine.addTask(emailTask);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean hasMatch(String queryString, String text) {
/* 320 */     boolean foundMatch = false;
/*     */     try
/*     */     {
/* 325 */       RAMDirectory dir = new RAMDirectory();
/*     */ 
/* 327 */       IndexWriter writer = new IndexWriter(dir, this.analyzer, true);
/* 328 */       Document doc = new Document();
/* 329 */       doc.add(Field.Text("text", text));
/* 330 */       writer.addDocument(doc);
/* 331 */       writer.close();
/*     */ 
/* 333 */       IndexSearcher searcher = new IndexSearcher(dir);
/* 334 */       QueryParser parser = new QueryParser("text", this.analyzer);
/* 335 */       Query query = parser.parse(queryString);
/* 336 */       Hits hits = searcher.search(query);
/*     */ 
/* 338 */       if (hits.length() > 0) {
/* 339 */         foundMatch = true;
/*     */       }
/* 341 */       searcher.close();
/*     */     }
/*     */     catch (Exception e) {
/* 344 */       Log.error(e);
/*     */     }
/* 346 */     return foundMatch;
/*     */   }
/*     */ 
/*     */   private String replaceTokens(String string, ForumMessage message)
/*     */   {
/* 355 */     string = StringUtils.replace(string, "{jiveURL}", JiveGlobals.getJiveProperty("jiveURL"));
/*     */ 
/* 358 */     string = StringUtils.replace(string, "{queryString}", this.emailQueryString);
/*     */ 
/* 361 */     String messageUser = "Guest";
/* 362 */     if (!message.isAnonymous()) {
/* 363 */       if (message.getUser().getName() != null) {
/* 364 */         messageUser = message.getUser().getName();
/*     */       }
/*     */       else {
/* 367 */         messageUser = message.getUser().getUsername();
/*     */       }
/*     */     }
/*     */ 
/* 371 */     string = StringUtils.replace(string, "{messageUser}", messageUser);
/* 372 */     string = StringUtils.replace(string, "{messageID}", Long.toString(message.getID()));
/* 373 */     string = StringUtils.replace(string, "{messageSubject}", message.getSubject());
/* 374 */     string = StringUtils.replace(string, "{messageBody}", message.getUnfilteredBody());
/* 375 */     string = StringUtils.replace(string, "{messageModificatonDate}", JiveGlobals.formatDateTime(message.getModificationDate()));
/*     */ 
/* 377 */     string = StringUtils.replace(string, "{messageCreationDate}", JiveGlobals.formatDateTime(message.getCreationDate()));
/*     */ 
/* 380 */     ForumThread thread = message.getForumThread();
/*     */ 
/* 382 */     string = StringUtils.replace(string, "{threadID}", Long.toString(thread.getID()));
/* 383 */     string = StringUtils.replace(string, "{threadName}", thread.getName());
/* 384 */     string = StringUtils.replace(string, "{threadModificatonDate}", JiveGlobals.formatDateTime(thread.getModificationDate()));
/*     */ 
/* 386 */     string = StringUtils.replace(string, "{threadCreationDate}", JiveGlobals.formatDateTime(thread.getCreationDate()));
/*     */ 
/* 390 */     Forum forum = thread.getForum();
/* 391 */     string = StringUtils.replace(string, "{forumID}", Long.toString(forum.getID()));
/* 392 */     string = StringUtils.replace(string, "{forumName}", forum.getName());
/*     */ 
/* 395 */     ForumCategory category = forum.getForumCategory();
/* 396 */     string = StringUtils.replace(string, "{categoryID}", Long.toString(category.getID()));
/* 397 */     string = StringUtils.replace(string, "{categoryName}", category.getName());
/*     */ 
/* 400 */     if (!message.isAnonymous()) {
/* 401 */       User user = message.getUser();
/* 402 */       string = StringUtils.replace(string, "{user-ID}", Long.toString(user.getID()));
/* 403 */       string = StringUtils.replace(string, "{user-username}", user.getUsername());
/* 404 */       String userName = user.getName();
/* 405 */       if (userName != null) {
/* 406 */         string = StringUtils.replace(string, "{user-name}", user.getName());
/*     */       }
/* 408 */       String userEmail = user.getEmail();
/* 409 */       if (userEmail != null) {
/* 410 */         string = StringUtils.replace(string, "{user-email}", user.getEmail());
/*     */       }
/*     */     }
/*     */ 
/* 414 */     return string;
/*     */   }
/*     */ 
/*     */   private class StemmingAnalyzer extends Analyzer
/*     */   {
/*     */     private StemmingAnalyzer() {
/*     */     }
/*     */ 
/*     */     public final TokenStream tokenStream(String fieldName, Reader reader) {
/* 423 */       TokenStream stream = new StopFilter(new LowerCaseTokenizer(reader), StandardAnalyzer.STOP_WORDS);
/*     */ 
/* 425 */       return new PorterStemFilter(stream);
/*     */     }
/*     */ 
/*     */     StemmingAnalyzer(KeywordInterceptor.1 x1)
/*     */     {
/* 420 */       this();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.KeywordInterceptor
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.proxy;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.base.Permissions;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.ForumNotFoundException;
/*    */ import com.jivesoftware.forum.Query;
/*    */ import com.jivesoftware.forum.QueryManager;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class QueryManagerProxy
/*    */   implements QueryManager
/*    */ {
/*    */   private QueryManager queryManager;
/*    */   private AuthToken auth;
/*    */   private Permissions permissions;
/*    */ 
/*    */   public QueryManagerProxy(QueryManager queryManager, AuthToken auth, Permissions permissions)
/*    */   {
/* 41 */     this.queryManager = queryManager;
/* 42 */     this.auth = auth;
/* 43 */     this.permissions = permissions;
/*    */   }
/*    */ 
/*    */   public Query createQuery()
/*    */   {
/* 49 */     ArrayList forumList = new ArrayList();
/* 50 */     for (Iterator iter = ForumFactory.getInstance(this.auth).getForums(); iter.hasNext(); ) {
/* 51 */       forumList.add(iter.next());
/*    */     }
/*    */ 
/* 54 */     Forum[] forums = (Forum[])forumList.toArray(new Forum[forumList.size()]);
/* 55 */     return createQuery(forums);
/*    */   }
/*    */ 
/*    */   public Query createQuery(Forum[] forums) {
/* 59 */     if (forums == null) {
/* 60 */       return new QueryProxy(this.queryManager.createQuery(null), this.auth);
/*    */     }
/*    */ 
/* 65 */     ArrayList forumList = new ArrayList();
/* 66 */     for (int i = 0; i < forums.length; i++) {
/* 67 */       Forum forum = forums[i];
/* 68 */       ForumProxy proxy = null;
/*    */       try {
/* 70 */         proxy = (ForumProxy)ForumFactory.getInstance(this.auth).getForum(forum.getID()); } catch (ForumNotFoundException e) {
/* 71 */         Log.error(e);
/*    */       } catch (UnauthorizedException e) {
/*    */       }
/* 74 */       if ((proxy != null) && (proxy.isAuthorized(576460752303424385L)))
/*    */       {
/* 80 */         forumList.add(forum);
/*    */       }
/*    */     }
/*    */ 
/* 84 */     Forum[] f = (Forum[])forumList.toArray(new Forum[forumList.size()]);
/* 85 */     return new QueryProxy(this.queryManager.createQuery(f), this.auth);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.QueryManagerProxy
 * JD-Core Version:    0.6.2
 */
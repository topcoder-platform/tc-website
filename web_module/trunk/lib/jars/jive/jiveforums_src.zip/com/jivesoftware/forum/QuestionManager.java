package com.jivesoftware.forum;

import com.jivesoftware.base.NotFoundException;
import com.jivesoftware.base.UnauthorizedException;
import java.util.Iterator;

public abstract interface QuestionManager
{
  public abstract int getHelpfulAnswersPerThread();

  public abstract void setHelpfulAnswersPerThread(int paramInt)
    throws UnauthorizedException;

  public abstract Question getQuestion(ForumThread paramForumThread)
    throws NotFoundException;

  public abstract boolean hasQuestion(ForumThread paramForumThread);

  public abstract Question createQuestion(ForumThread paramForumThread)
    throws UnauthorizedException;

  public abstract void deleteQuestion(Question paramQuestion)
    throws UnauthorizedException;

  public abstract int getQuestionCount();

  public abstract int getQuestionCount(QuestionFilter paramQuestionFilter);

  public abstract int getQuestionCount(ForumCategory paramForumCategory);

  public abstract int getQuestionCount(ForumCategory paramForumCategory, QuestionFilter paramQuestionFilter);

  public abstract int getQuestionCount(Forum paramForum);

  public abstract int getQuestionCount(Forum paramForum, QuestionFilter paramQuestionFilter);

  public abstract Iterator getQuestions();

  public abstract Iterator getQuestions(QuestionFilter paramQuestionFilter);

  public abstract Iterator getQuestions(ForumCategory paramForumCategory);

  public abstract Iterator getQuestions(ForumCategory paramForumCategory, QuestionFilter paramQuestionFilter);

  public abstract Iterator getQuestions(Forum paramForum);

  public abstract Iterator getQuestions(Forum paramForum, QuestionFilter paramQuestionFilter);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.QuestionManager
 * JD-Core Version:    0.6.2
 */
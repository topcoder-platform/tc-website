/*     */ package com.jivesoftware.forum.action.setup;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.util.LocaleUtils;
/*     */ import com.opensymphony.xwork.Action;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import com.opensymphony.xwork.LocaleProvider;
/*     */ import com.opensymphony.xwork.TextProvider;
/*     */ import com.opensymphony.xwork.TextProviderSupport;
/*     */ import com.opensymphony.xwork.ValidationAware;
/*     */ import com.opensymphony.xwork.ValidationAwareSupport;
/*     */ import com.opensymphony.xwork.util.OgnlValueStack;
/*     */ import java.io.File;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ public class SetupActionSupport
/*     */   implements Action, TextProvider, LocaleProvider, ValidationAware
/*     */ {
/*     */   public static final String NEXT = "next";
/*     */   public static final String INCOMPLETE = "incomplete";
/*     */   public static final String IN_PROGRESS = "in_progress";
/*     */   public static final String DONE = "done";
/*     */   private TextProvider textProvider;
/*  33 */   private ValidationAware validationAware = new ValidationAwareSupport();
/*     */   private String doContinue;
/*     */   private String localeCode;
/*     */ 
/*     */   public String getText(String aTextName)
/*     */   {
/*  39 */     return getTextProvider().getText(aTextName);
/*     */   }
/*     */ 
/*     */   public String getText(String aTextName, String defaultValue) {
/*  43 */     return getTextProvider().getText(aTextName, defaultValue);
/*     */   }
/*     */ 
/*     */   public String getText(String aTextName, List args) {
/*  47 */     return getTextProvider().getText(aTextName, args);
/*     */   }
/*     */ 
/*     */   public String getText(String aTextName, String defaultValue, List args) {
/*  51 */     return getTextProvider().getText(aTextName, defaultValue, args);
/*     */   }
/*     */ 
/*     */   public String getText(String s, String s1, List list, OgnlValueStack ognlValueStack) {
/*  55 */     return getTextProvider().getText(s, s1, list, ognlValueStack);
/*     */   }
/*     */ 
/*     */   public ResourceBundle getTexts(String aBundleName) {
/*  59 */     return getTextProvider().getTexts(aBundleName);
/*     */   }
/*     */ 
/*     */   public ResourceBundle getTexts() {
/*  63 */     return getTextProvider().getTexts();
/*     */   }
/*     */ 
/*     */   public Locale getLocale() {
/*  67 */     Locale locale = (Locale)ActionContext.getContext().getSession().get("jive_forums_setup.locale");
/*     */ 
/*  69 */     if ((locale == null) && (this.localeCode != null)) {
/*  70 */       locale = LocaleUtils.localeCodeToLocale(this.localeCode);
/*     */     }
/*     */ 
/*  73 */     if (locale == null) {
/*  74 */       locale = JiveGlobals.getLocale();
/*     */     }
/*     */ 
/*  77 */     ActionContext.getContext().getSession().put("jive_forums_setup.locale", locale);
/*     */ 
/*  79 */     return locale;
/*     */   }
/*     */ 
/*     */   public void setActionErrors(Collection errorMessages) {
/*  83 */     this.validationAware.setActionErrors(errorMessages);
/*     */   }
/*     */ 
/*     */   public Collection getActionErrors() {
/*  87 */     return this.validationAware.getActionErrors();
/*     */   }
/*     */ 
/*     */   public void setActionMessages(Collection messages) {
/*  91 */     this.validationAware.setActionMessages(messages);
/*     */   }
/*     */ 
/*     */   public Collection getActionMessages() {
/*  95 */     return this.validationAware.getActionMessages();
/*     */   }
/*     */ 
/*     */   public void setFieldErrors(Map errorMap) {
/*  99 */     this.validationAware.setFieldErrors(errorMap);
/*     */   }
/*     */ 
/*     */   public Map getFieldErrors() {
/* 103 */     return this.validationAware.getFieldErrors();
/*     */   }
/*     */ 
/*     */   public void addActionError(String anErrorMessage) {
/* 107 */     this.validationAware.addActionError(anErrorMessage);
/*     */   }
/*     */ 
/*     */   public void addActionMessage(String aMessage) {
/* 111 */     this.validationAware.addActionMessage(aMessage);
/*     */   }
/*     */ 
/*     */   public void addFieldError(String fieldName, String errorMessage) {
/* 115 */     this.validationAware.addFieldError(fieldName, errorMessage);
/*     */   }
/*     */ 
/*     */   public boolean hasActionErrors() {
/* 119 */     return this.validationAware.hasActionErrors();
/*     */   }
/*     */ 
/*     */   public boolean hasActionMessages() {
/* 123 */     return this.validationAware.hasActionMessages();
/*     */   }
/*     */ 
/*     */   public boolean hasErrors() {
/* 127 */     return this.validationAware.hasErrors();
/*     */   }
/*     */ 
/*     */   public boolean hasFieldErrors() {
/* 131 */     return this.validationAware.hasFieldErrors();
/*     */   }
/*     */ 
/*     */   private TextProvider getTextProvider() {
/* 135 */     if (this.textProvider == null) {
/* 136 */       this.textProvider = new TextProviderSupport(getClass(), this);
/*     */     }
/*     */ 
/* 139 */     return this.textProvider;
/*     */   }
/*     */ 
/*     */   public String execute() {
/* 143 */     return "success";
/*     */   }
/*     */ 
/*     */   public String getLocaleCode() {
/* 147 */     return this.localeCode;
/*     */   }
/*     */ 
/*     */   public void setLocaleCode(String localeCode) {
/* 151 */     if ((localeCode != null) && (!"".equals(localeCode))) {
/* 152 */       this.localeCode = localeCode;
/* 153 */       ActionContext.getContext().getSession().remove("jive_forums_setup.locale");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getDoContinue() {
/* 158 */     return this.doContinue;
/*     */   }
/*     */ 
/*     */   public void setDoContinue(String doContinue) {
/* 162 */     this.doContinue = "true";
/*     */   }
/*     */ 
/*     */   public File getJiveHome()
/*     */   {
/* 173 */     File jiveHomeDir = null;
/* 174 */     String jiveHomeProp = JiveGlobals.getJiveHome();
/* 175 */     if ((jiveHomeProp != null) && (!"".equals(jiveHomeProp)))
/*     */       try {
/* 177 */         jiveHomeDir = new File(jiveHomeProp);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/* 182 */     return jiveHomeDir;
/*     */   }
/*     */ 
/*     */   public File getJiveFile(String filename)
/*     */   {
/* 193 */     if (getJiveHome() == null) {
/* 194 */       return null;
/*     */     }
/*     */ 
/* 197 */     File file = null;
/* 198 */     if ((filename != null) && (!"".equals(filename)))
/*     */       try {
/* 200 */         file = new File(getJiveHome(), filename);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/* 205 */     return file;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.SetupActionSupport
 * JD-Core Version:    0.6.2
 */
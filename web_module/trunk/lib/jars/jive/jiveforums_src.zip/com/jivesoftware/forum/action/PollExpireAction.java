/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.Poll;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.base.action.util.DateUtils;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class PollExpireAction extends PollAction
/*    */ {
/*    */   private boolean cancel;
/*    */ 
/*    */   public String isCancel()
/*    */   {
/* 33 */     return String.valueOf(this.cancel);
/*    */   }
/*    */ 
/*    */   public void setCancel(String cancel)
/*    */   {
/* 40 */     this.cancel = true;
/*    */   }
/*    */ 
/*    */   public String doDefault() throws Exception {
/* 44 */     return "input";
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */     throws Exception
/*    */   {
/* 50 */     if (this.cancel) {
/* 51 */       return "cancel";
/*    */     }
/*    */ 
/* 54 */     Poll poll = getPoll();
/*    */     try {
/* 56 */       Date now = DateUtils.roundDate(new Date(), 1800);
/* 57 */       poll.setEndDate(now);
/* 58 */       poll.setExpirationDate(now);
/*    */     }
/*    */     catch (UnauthorizedException e) {
/* 61 */       return "unauthorized";
/*    */     }
/* 63 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PollExpireAction
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.BinFormat;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.Report.ExtraInfo;
/*     */ import com.jivesoftware.base.stats.bin.CyclicSequence;
/*     */ import com.jivesoftware.base.stats.element.CyclicElement;
/*     */ import com.jivesoftware.base.stats.element.DayOfWeekElementFormat;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ public class SearchQueryDayOfWeekReport extends AbstractForumReport
/*     */ {
/*     */   private static final String EARLIEST_SEARCH_DATE = "SELECT min(searchDate) FROM jiveSearch WHERE searchType=19";
/*     */   private static final String SEARCH_QUERIES = "SELECT searchDate from jiveSearch WHERE searchDate >= ? AND searchDate <= ? AND searchType=19";
/*  41 */   private int firstDayOfWeek = Calendar.getInstance(JiveGlobals.getLocale()).getFirstDayOfWeek();
/*  42 */   private BinFormat labelFormatter = new BinFormat(new DayOfWeekElementFormat("EEE"), "$1");
/*     */ 
/*     */   public void execute()
/*     */   {
/*  47 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  48 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  50 */     if (end.compareTo(start) < 0)
/*     */     {
/*  52 */       start = end;
/*     */     }
/*     */ 
/*  55 */     Histogram hist = new Histogram(new CyclicSequence(7L), new CyclicElement(7L, this.firstDayOfWeek, this.firstDayOfWeek), new CyclicElement(7L, this.firstDayOfWeek, this.firstDayOfWeek - 1));
/*     */ 
/*  58 */     addHistogram(hist);
/*     */ 
/*  61 */     Connection con = null;
/*  62 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/*  65 */       con = ConnectionManager.getConnection();
/*  66 */       pstmt = con.prepareStatement("SELECT searchDate from jiveSearch WHERE searchDate >= ? AND searchDate <= ? AND searchType=19");
/*  67 */       pstmt.setLong(1, start.getTime());
/*  68 */       pstmt.setLong(2, end.getTime());
/*  69 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  71 */       Calendar cal = Calendar.getInstance(JiveGlobals.getTimeZone(), JiveGlobals.getLocale());
/*  72 */       while (rs.next()) {
/*  73 */         cal.setTime(new Date(rs.getLong(1)));
/*  74 */         hist.add(new CyclicElement(7L, this.firstDayOfWeek, cal.get(7)));
/*     */       }
/*  76 */       rs.close();
/*     */     } catch (SQLException e) {
/*  78 */       Log.error(e);
/*     */     } finally {
/*  80 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/*  85 */     Histogram[] histograms = getHistograms();
/*  86 */     if (histograms.length == 0) {
/*  87 */       return new DataTable[0];
/*     */     }
/*  89 */     DataTable data = new DataTable(getName());
/*  90 */     data.setColumns(new String[] { "Day of the Week", "Searches" });
/*  91 */     Histogram hist = histograms[0];
/*  92 */     Bin[] bins = hist.getBins();
/*  93 */     for (int i = 0; i < bins.length; i++) {
/*  94 */       Bin bin = bins[i];
/*  95 */       long count = hist.getCount(bin);
/*  96 */       data.addRow(new Object[] { this.labelFormatter.format(bin), new Long(count) });
/*     */     }
/*  98 */     return new DataTable[] { data };
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 102 */     Histogram[] histograms = getHistograms();
/* 103 */     if (histograms.length == 0) {
/* 104 */       return new Chart[0];
/*     */     }
/* 106 */     Chart chart = new Chart(getName());
/* 107 */     chart.setXaxisLabel("Day of the Week");
/* 108 */     chart.setYaxisLabel("Searches");
/* 109 */     chart.setType(1);
/* 110 */     Histogram hist = histograms[0];
/* 111 */     Bin[] bins = hist.getBins();
/* 112 */     String[] labels = new String[bins.length];
/* 113 */     for (int i = 0; i < bins.length; i++) {
/* 114 */       Bin bin = bins[i];
/* 115 */       labels[i] = this.labelFormatter.format(bin);
/*     */     }
/* 117 */     chart.setLabels(labels);
/*     */ 
/* 119 */     return new Chart[] { chart };
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 123 */     Histogram[] histograms = getHistograms();
/* 124 */     if (histograms.length == 0) {
/* 125 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/* 127 */     List extraInfo = new ArrayList(4);
/* 128 */     Histogram hist = histograms[0];
/* 129 */     if (hist.getNElement() > 0L)
/*     */     {
/* 131 */       extraInfo.add(new Report.ExtraInfo("Median searches/day", new Long(hist.getMedianCount())));
/*     */ 
/* 134 */       BinFormat dataFormat = new BinFormat(new DayOfWeekElementFormat("EEEE"), "$1");
/* 135 */       String day = dataFormat.format(hist.getMaxCountBin());
/* 136 */       extraInfo.add(new Report.ExtraInfo("Peak Day", day));
/*     */     }
/*     */ 
/* 140 */     extraInfo.add(getDateRange());
/*     */ 
/* 142 */     return new List[] { extraInfo };
/*     */   }
/*     */ 
/*     */   protected Date calculateStartDate() {
/* 146 */     Connection con = null;
/* 147 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 150 */       con = ConnectionManager.getConnection();
/* 151 */       pstmt = con.prepareStatement("SELECT min(searchDate) FROM jiveSearch WHERE searchType=19");
/* 152 */       ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 154 */       if (rs.next()) {
/* 155 */         return new Date(rs.getLong(1));
/*     */       }
/* 157 */       rs.close();
/*     */     } catch (SQLException e) {
/* 159 */       Log.error(e);
/*     */     } finally {
/* 161 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 164 */     return super.calculateStartDate();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.SearchQueryDayOfWeekReport
 * JD-Core Version:    0.6.2
 */
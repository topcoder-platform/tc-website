/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.User;
/*    */ import com.jivesoftware.base.action.LogoutAction;
/*    */ 
/*    */ public class ForumLogoutAction extends LogoutAction
/*    */ {
/*    */   public User getPageUser()
/*    */   {
/* 27 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.ForumLogoutAction
 * JD-Core Version:    0.6.2
 */
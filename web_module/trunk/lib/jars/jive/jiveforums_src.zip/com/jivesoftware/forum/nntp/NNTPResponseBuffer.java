/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import com.jivesoftware.forum.net.Connection;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ public class NNTPResponseBuffer
/*     */   implements NNTPResponse
/*     */ {
/*     */   private static final int LINE_LIMIT = 510;
/*     */   private int value;
/*  34 */   private int lines = 0;
/*     */ 
/*  36 */   private int lineLength = 0;
/*     */ 
/*  44 */   private boolean appendedLineEnd = false;
/*     */   private boolean continuedBuffer;
/*  51 */   private boolean closed = false;
/*     */   private Writer writer;
/*     */ 
/*     */   public NNTPResponseBuffer(Connection connection, int val)
/*     */     throws IOException
/*     */   {
/*  66 */     this(connection, val, null, false);
/*     */   }
/*     */ 
/*     */   public NNTPResponseBuffer(Connection connection, int val, String text, boolean continued)
/*     */     throws IOException
/*     */   {
/*  85 */     this.writer = connection.getWriter();
/*  86 */     this.value = val;
/*  87 */     this.continuedBuffer = continued;
/*     */ 
/*  89 */     String commandVal = Integer.toString(val);
/*  90 */     this.writer.write(commandVal);
/*  91 */     this.writer.write(" ");
/*  92 */     this.lineLength = (commandVal.length() + 1);
/*  93 */     if (text != null)
/*  94 */       appendLine(text);
/*     */   }
/*     */ 
/*     */   public int getValue()
/*     */   {
/*  99 */     return this.value;
/*     */   }
/*     */ 
/*     */   public void send(Connection con) throws IOException {
/* 103 */     if (!this.closed) {
/* 104 */       close();
/* 105 */       this.writer.flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void flush() throws IOException {
/* 110 */     this.writer.flush();
/*     */   }
/*     */ 
/*     */   public NNTPResponseBuffer close()
/*     */     throws IOException
/*     */   {
/* 120 */     if (!this.closed) {
/* 121 */       if ((this.continuedBuffer) || (this.lines > 1)) {
/* 122 */         if (!this.appendedLineEnd) {
/* 123 */           append("\r\n");
/*     */         }
/* 125 */         append(".\r\n");
/*     */       }
/* 127 */       else if ((this.lines == 0) && (!this.appendedLineEnd)) {
/* 128 */         append("\r\n");
/*     */       }
/* 130 */       this.closed = true;
/*     */     }
/* 132 */     return this;
/*     */   }
/*     */ 
/*     */   public NNTPResponseBuffer append(String text)
/*     */     throws IOException
/*     */   {
/* 146 */     if ((text != null) && (!this.closed)) {
/* 147 */       if (text.length() + this.lineLength > 510) {
/* 148 */         int truncateCount = 510 - this.lineLength;
/* 149 */         append(text.substring(0, truncateCount));
/* 150 */         this.writer.write("\r\n");
/* 151 */         this.lineLength = 0;
/* 152 */         append(text.substring(truncateCount));
/*     */       }
/*     */       else {
/* 155 */         this.writer.write(text);
/* 156 */         this.lineLength += text.length();
/* 157 */         this.appendedLineEnd = false;
/*     */       }
/*     */     }
/* 160 */     return this;
/*     */   }
/*     */ 
/*     */   public NNTPResponseBuffer appendParameter(String text)
/*     */     throws IOException
/*     */   {
/* 177 */     if ((text != null) && (!this.closed)) {
/* 178 */       append(" ");
/* 179 */       append(text);
/* 180 */       this.appendedLineEnd = false;
/*     */     }
/* 182 */     return this;
/*     */   }
/*     */ 
/*     */   public NNTPResponseBuffer appendXParameter(String text)
/*     */     throws IOException
/*     */   {
/* 200 */     if (!this.closed) {
/* 201 */       append("\t");
/* 202 */       if (text != null) {
/* 203 */         append(text);
/*     */       }
/* 205 */       this.appendedLineEnd = false;
/*     */     }
/* 207 */     return this;
/*     */   }
/*     */ 
/*     */   public void endLine()
/*     */     throws IOException
/*     */   {
/* 216 */     if (!this.closed) {
/* 217 */       append("\r\n");
/* 218 */       this.lineLength = 0;
/* 219 */       this.lines += 1;
/* 220 */       this.appendedLineEnd = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void appendLine(String text)
/*     */     throws IOException
/*     */   {
/* 231 */     if ((text != null) && (!this.closed)) {
/* 232 */       append(text);
/*     */     }
/* 234 */     endLine();
/*     */   }
/*     */ 
/*     */   public NNTPResponseBuffer appendBulkText(String text)
/*     */     throws IOException
/*     */   {
/* 248 */     int mark = -1;
/* 249 */     int limit = text.length();
/* 250 */     if ((text != null) && (!this.closed)) {
/* 251 */       this.continuedBuffer = true;
/* 252 */       boolean sawCR = this.appendedLineEnd;
/* 253 */       for (int i = 0; i < limit; i++) {
/* 254 */         char c = text.charAt(i);
/* 255 */         if (c == '\r') {
/* 256 */           sawCR = true;
/* 257 */           if (mark != -1) {
/* 258 */             append(text.substring(mark, i));
/* 259 */             mark = -1;
/*     */           }
/* 261 */           append("\r\n");
/* 262 */           this.lineLength = 0;
/* 263 */           this.lines += 1;
/* 264 */           this.appendedLineEnd = true;
/*     */         }
/* 266 */         else if (c == '\n') {
/* 267 */           if (!sawCR) {
/* 268 */             if (mark != -1) {
/* 269 */               append(text.substring(mark, i));
/* 270 */               mark = -1;
/*     */             }
/* 272 */             append("\r\n");
/* 273 */             this.lineLength = 0;
/* 274 */             this.lines += 1;
/* 275 */             this.appendedLineEnd = true;
/*     */           }
/*     */           else {
/* 278 */             sawCR = true;
/*     */           }
/*     */         }
/*     */         else {
/* 282 */           if (sawCR) {
/* 283 */             if (c == '.') {
/* 284 */               if (mark != -1) {
/* 285 */                 append(text.substring(mark, i));
/* 286 */                 mark = -1;
/*     */               }
/* 288 */               append("..");
/*     */             }
/* 291 */             else if (mark == -1) {
/* 292 */               mark = i;
/*     */             }
/*     */ 
/* 295 */             sawCR = false;
/*     */           }
/* 298 */           else if (mark == -1) {
/* 299 */             mark = i;
/*     */           }
/*     */ 
/* 302 */           this.appendedLineEnd = false;
/*     */         }
/*     */       }
/*     */     }
/* 306 */     if (mark != -1) {
/* 307 */       append(text.substring(mark, limit));
/*     */     }
/* 309 */     return this;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NNTPResponseBuffer
 * JD-Core Version:    0.6.2
 */
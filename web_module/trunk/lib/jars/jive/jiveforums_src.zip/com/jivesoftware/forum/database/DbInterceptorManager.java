/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.JiveManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.InterceptorManager;
/*     */ import com.jivesoftware.forum.MessageInterceptor;
/*     */ import com.jivesoftware.forum.MessageRejectedException;
/*     */ import com.jivesoftware.forum.Version;
/*     */ import com.jivesoftware.forum.Version.Edition;
/*     */ import com.jivesoftware.util.BeanUtils;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.ClassUtils;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DbInterceptorManager
/*     */   implements InterceptorManager, JiveManager
/*     */ {
/*  34 */   public static final String[] ENT_DEFAULT_INTERCEPTOR_CLASSES = { "com.jivesoftware.forum.interceptor.GovernorInterceptor", "com.jivesoftware.forum.interceptor.UserInterceptor", "com.jivesoftware.forum.interceptor.KeywordInterceptor", "com.jivesoftware.forum.interceptor.ModerationInterceptor", "com.jivesoftware.forum.interceptor.GatewayInterceptor", "com.jivesoftware.forum.interceptor.IPInterceptor", "com.jivesoftware.forum.interceptor.VirusScanInterceptor" };
/*     */ 
/*  44 */   public static final String[] PRO_DEFAULT_INTERCEPTOR_CLASSES = { "com.jivesoftware.forum.interceptor.UserInterceptor" };
/*     */ 
/*  48 */   private static MessageInterceptor[] availableInterceptors = null;
/*  49 */   private static Object lock = new Object();
/*     */   private static DbForumFactory FACTORY;
/*  51 */   private boolean initialized = false;
/*     */   private MessageInterceptor[] interceptors;
/*     */   private int objectType;
/*     */   private long objectID;
/*     */ 
/*     */   public DbInterceptorManager(int objectType, long objectID)
/*     */   {
/*  64 */     this.objectType = objectType;
/*  65 */     this.objectID = objectID;
/*     */   }
/*     */ 
/*     */   public synchronized void initialize() {
/*  69 */     if (!this.initialized) {
/*  70 */       FACTORY = DbForumFactory.getInstance();
/*     */ 
/*  72 */       if (this.objectType == 17) {
/*  73 */         loadGlobalInterceptors();
/*     */       }
/*  75 */       else if (this.objectType == 14) {
/*     */         try {
/*  77 */           loadCategoryInterceptors();
/*     */         }
/*     */         catch (ForumCategoryNotFoundException e) {
/*  80 */           Log.error(e);
/*     */         }
/*     */       }
/*  83 */       else if (this.objectType == 0) {
/*     */         try {
/*  85 */           loadForumInterceptors();
/*     */         }
/*     */         catch (ForumNotFoundException e) {
/*  88 */           Log.error(e);
/*     */         }
/*     */       }
/*  91 */       this.initialized = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public MessageInterceptor getInterceptor(int index) {
/*  96 */     if ((index < 0) || (index > this.interceptors.length - 1)) {
/*  97 */       throw new IllegalArgumentException("Index " + index + " is not valid.");
/*     */     }
/*  99 */     return this.interceptors[index];
/*     */   }
/*     */ 
/*     */   public int getInterceptorCount() {
/* 103 */     return this.interceptors.length;
/*     */   }
/*     */ 
/*     */   public void addInterceptor(int index, MessageInterceptor interceptor) {
/* 107 */     if ((index < 0) || (index > this.interceptors.length)) {
/* 108 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 110 */     if (interceptor == null) {
/* 111 */       throw new NullPointerException("Parameter " + interceptor + " was null.");
/*     */     }
/*     */ 
/* 114 */     List newList = new ArrayList(Arrays.asList(this.interceptors));
/* 115 */     newList.add(index, interceptor);
/* 116 */     this.interceptors = ((MessageInterceptor[])newList.toArray(new MessageInterceptor[newList.size()]));
/* 117 */     saveInterceptors();
/*     */   }
/*     */ 
/*     */   public void removeInterceptor(int index) {
/* 121 */     if ((index < 0) || (index > this.interceptors.length - 1)) {
/* 122 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 124 */     List newList = new ArrayList(Arrays.asList(this.interceptors));
/* 125 */     newList.remove(index);
/* 126 */     this.interceptors = ((MessageInterceptor[])newList.toArray(new MessageInterceptor[newList.size()]));
/* 127 */     saveInterceptors();
/*     */   }
/*     */ 
/*     */   public synchronized void saveInterceptors() {
/* 131 */     String context = null;
/*     */ 
/* 133 */     if (this.objectType == 17) {
/* 134 */       JiveGlobals.deleteJiveProperty("interceptor.global");
/* 135 */       context = "interceptor.global.";
/*     */     }
/* 137 */     else if (this.objectType == 14) {
/*     */       try {
/* 139 */         DbForumCategory category = FACTORY.cacheManager.getForumCategory(this.objectID);
/* 140 */         List propertyNames = new ArrayList();
/* 141 */         for (Iterator i = category.getPropertyNames(); i.hasNext(); ) {
/* 142 */           propertyNames.add(i.next());
/*     */         }
/* 144 */         for (int i = 0; i < propertyNames.size(); i++) {
/* 145 */           String property = (String)propertyNames.get(i);
/* 146 */           if (property.startsWith("jive.interceptor"))
/* 147 */             category.deleteProperty(property);
/*     */         }
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e)
/*     */       {
/* 152 */         Log.error(e);
/*     */       }
/* 154 */       context = "jive.interceptor.";
/*     */     }
/* 156 */     else if (this.objectType == 0) {
/*     */       try {
/* 158 */         DbForum forum = FACTORY.cacheManager.getForum(this.objectID);
/* 159 */         List propertyNames = new ArrayList();
/* 160 */         for (Iterator i = forum.getPropertyNames(); i.hasNext(); ) {
/* 161 */           propertyNames.add(i.next());
/*     */         }
/* 163 */         for (int i = 0; i < propertyNames.size(); i++) {
/* 164 */           String property = (String)propertyNames.get(i);
/* 165 */           if (property.startsWith("jive.interceptor"))
/* 166 */             forum.deleteProperty(property);
/*     */         }
/*     */       }
/*     */       catch (ForumNotFoundException e)
/*     */       {
/* 171 */         Log.error(e);
/*     */       }
/* 173 */       context = "jive.interceptor.";
/*     */     }
/*     */ 
/* 176 */     Map propertyMap = new HashMap();
/*     */ 
/* 178 */     if (this.interceptors.length > 0)
/* 179 */       propertyMap.put(context + "interceptorCount", String.valueOf(this.interceptors.length));
/*     */     String interceptorContext;
/*     */     Map interceptorProps;
/*     */     Iterator iter;
/* 183 */     for (int i = 0; i < this.interceptors.length; i++) {
/* 184 */       MessageInterceptor interceptor = this.interceptors[i];
/* 185 */       interceptorContext = context + "interceptor" + i + ".";
/*     */ 
/* 188 */       propertyMap.put(interceptorContext + "className", interceptor.getClass().getName());
/*     */ 
/* 191 */       interceptorProps = BeanUtils.getProperties(interceptor);
/* 192 */       for (iter = interceptorProps.keySet().iterator(); iter.hasNext(); ) {
/* 193 */         String name = (String)iter.next();
/* 194 */         String value = (String)interceptorProps.get(name);
/* 195 */         if ((value != null) && (!"".equals(value))) {
/* 196 */           propertyMap.put(interceptorContext + "properties." + name, value);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 201 */     if (this.objectType == 17) {
/* 202 */       JiveGlobals.setJiveProperties(propertyMap);
/*     */     }
/* 204 */     else if (this.objectType == 14) {
/*     */       try {
/* 206 */         category = FACTORY.cacheManager.getForumCategory(this.objectID);
/* 207 */         for (i = propertyMap.keySet().iterator(); i.hasNext(); ) {
/* 208 */           String name = (String)i.next();
/* 209 */           String value = (String)propertyMap.get(name);
/* 210 */           category.setProperty(name, value);
/*     */         }
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e)
/*     */       {
/*     */         DbForumCategory category;
/*     */         Iterator i;
/* 214 */         Log.error(e);
/*     */       }
/*     */     }
/* 217 */     else if (this.objectType == 0) {
/*     */       try {
/* 219 */         forum = FACTORY.cacheManager.getForum(this.objectID);
/* 220 */         for (i = propertyMap.keySet().iterator(); i.hasNext(); ) {
/* 221 */           String name = (String)i.next();
/* 222 */           String value = (String)propertyMap.get(name);
/* 223 */           forum.setProperty(name, value);
/*     */         }
/*     */       }
/*     */       catch (ForumNotFoundException e)
/*     */       {
/*     */         DbForum forum;
/*     */         Iterator i;
/* 227 */         Log.error(e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 232 */     CacheFactory.doClusterTask(new UpdateClusterTask(this.objectType, this.objectID));
/*     */   }
/*     */ 
/*     */   public MessageInterceptor[] getAvailableInterceptors() {
/* 236 */     synchronized (lock) {
/* 237 */       if (availableInterceptors == null)
/*     */       {
/* 239 */         List interceptorList = new ArrayList();
/*     */ 
/* 241 */         if ((Version.getEdition() == Version.Edition.ENTERPRISE) || (Version.getEdition() == Version.Edition.EXPERT))
/*     */         {
/* 244 */           for (int i = 0; i < ENT_DEFAULT_INTERCEPTOR_CLASSES.length; i++)
/*     */             try {
/* 246 */               Class interceptorClass = ClassUtils.forName(ENT_DEFAULT_INTERCEPTOR_CLASSES[i]);
/*     */ 
/* 248 */               Constructor constructor = interceptorClass.getConstructor(new Class[] { Integer.TYPE, Long.TYPE });
/*     */ 
/* 250 */               Object[] initargs = { new Integer(this.objectType), new Long(this.objectID) };
/* 251 */               MessageInterceptor interceptor = (MessageInterceptor)constructor.newInstance(initargs);
/*     */ 
/* 253 */               interceptorList.add(interceptor);
/*     */             }
/*     */             catch (Exception e) {
/*     */             }
/*     */         }
/* 258 */         else if (Version.getEdition() == Version.Edition.PROFESSIONAL) {
/* 259 */           for (int i = 0; i < PRO_DEFAULT_INTERCEPTOR_CLASSES.length; i++) {
/*     */             try {
/* 261 */               Class interceptorClass = ClassUtils.forName(PRO_DEFAULT_INTERCEPTOR_CLASSES[i]);
/*     */ 
/* 263 */               Constructor constructor = interceptorClass.getConstructor(new Class[] { Integer.TYPE, Long.TYPE });
/*     */ 
/* 265 */               Object[] initargs = { new Integer(this.objectType), new Long(this.objectID) };
/* 266 */               MessageInterceptor interceptor = (MessageInterceptor)constructor.newInstance(initargs);
/*     */ 
/* 268 */               interceptorList.add(interceptor);
/*     */             }
/*     */             catch (Exception e)
/*     */             {
/*     */             }
/*     */           }
/*     */         }
/* 275 */         List classNames = JiveGlobals.getJiveProperties("interceptor.interceptorClasses");
/* 276 */         label434: for (int i = 0; i < classNames.size(); i++) {
/*     */           try {
/* 278 */             Class interceptorClass = ClassUtils.forName((String)classNames.get(i));
/*     */ 
/* 280 */             for (int j = 0; j < interceptorList.size(); j++) {
/* 281 */               if (interceptorClass.equals(interceptorList.get(j).getClass())) {
/*     */                 break label434;
/*     */               }
/*     */             }
/* 285 */             Constructor constructor = interceptorClass.getConstructor(new Class[] { Integer.TYPE, Long.TYPE });
/*     */ 
/* 287 */             Object[] initargs = { new Integer(this.objectType), new Long(this.objectID) };
/* 288 */             MessageInterceptor interceptor = (MessageInterceptor)constructor.newInstance(initargs);
/*     */ 
/* 290 */             interceptorList.add(interceptor);
/*     */           }
/*     */           catch (Exception e) {
/* 293 */             Log.error(e);
/*     */           }
/*     */         }
/*     */ 
/* 297 */         availableInterceptors = new MessageInterceptor[interceptorList.size()];
/* 298 */         for (int i = 0; i < availableInterceptors.length; i++) {
/* 299 */           availableInterceptors[i] = ((MessageInterceptor)interceptorList.get(i));
/*     */         }
/*     */       }
/* 302 */       return availableInterceptors;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addInterceptorClass(String className)
/*     */     throws ClassNotFoundException, IllegalArgumentException
/*     */   {
/* 309 */     synchronized (lock)
/*     */     {
/* 312 */       Class newClass = ClassUtils.forName(className);
/*     */       try {
/* 314 */         Constructor constructor = newClass.getConstructor(new Class[] { Integer.TYPE, Long.TYPE });
/*     */ 
/* 316 */         Object[] initargs = { new Integer(this.objectType), new Long(this.objectID) };
/* 317 */         MessageInterceptor newInterceptor = (MessageInterceptor)constructor.newInstance(initargs);
/*     */ 
/* 320 */         for (int i = 0; i < availableInterceptors.length; i++) {
/* 321 */           if (newInterceptor.getClass().equals(availableInterceptors[i].getClass())) {
/* 322 */             return;
/*     */           }
/*     */         }
/*     */ 
/* 326 */         MessageInterceptor[] newInterceptors = new MessageInterceptor[availableInterceptors.length + 1];
/*     */ 
/* 328 */         for (int i = 0; i < newInterceptors.length - 1; i++) {
/* 329 */           newInterceptors[i] = availableInterceptors[i];
/*     */         }
/* 331 */         newInterceptors[(newInterceptors.length - 1)] = newInterceptor;
/* 332 */         availableInterceptors = newInterceptors;
/*     */ 
/* 334 */         JiveGlobals.deleteJiveProperty("interceptor.interceptorClasses");
/* 335 */         for (int i = 0; i < availableInterceptors.length; i++) {
/* 336 */           String cName = availableInterceptors[i].getClass().getName();
/* 337 */           JiveGlobals.setJiveProperty("interceptor.interceptorClasses.interceptor" + i, cName);
/*     */         }
/*     */       }
/*     */       catch (IllegalAccessException e) {
/* 341 */         throw new IllegalArgumentException(e.getMessage());
/*     */       }
/*     */       catch (InstantiationException e2) {
/* 344 */         throw new IllegalArgumentException(e2.getMessage());
/*     */       }
/*     */       catch (NoSuchMethodException e3) {
/* 347 */         throw new IllegalArgumentException(e3.getMessage());
/*     */       }
/*     */       catch (InvocationTargetException e4) {
/* 350 */         throw new ClassNotFoundException(e4.getMessage());
/*     */       }
/*     */       catch (ClassCastException e5) {
/* 353 */         throw new IllegalArgumentException("Class is not a MessageInterceptor");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void invokeInterceptors(ForumMessage message, int type)
/*     */     throws MessageRejectedException
/*     */   {
/* 367 */     if (this.objectType == 17)
/*     */     {
/* 369 */       for (int i = 0; i < this.interceptors.length; i++) {
/* 370 */         MessageInterceptor interceptor = this.interceptors[i];
/* 371 */         if (interceptorMatches(interceptor.getType(), type)) {
/* 372 */           interceptor.invokeInterceptor(message, type);
/*     */         }
/*     */       }
/*     */     }
/* 376 */     else if (this.objectType == 14) {
/*     */       try {
/* 378 */         ForumCategory category = FACTORY.getForumCategory(this.objectID);
/*     */ 
/* 381 */         if (category.getParentCategory() == null) {
/* 382 */           DbInterceptorManager manager = (DbInterceptorManager)FACTORY.getInterceptorManager();
/* 383 */           manager.invokeInterceptors(message, type);
/*     */ 
/* 385 */           for (int i = 0; i < this.interceptors.length; i++) {
/* 386 */             MessageInterceptor interceptor = this.interceptors[i];
/* 387 */             if (interceptorMatches(interceptor.getType(), type)) {
/* 388 */               interceptor.invokeInterceptor(message, type);
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 395 */           DbForumCategory parentCategory = (DbForumCategory)category.getParentCategory();
/* 396 */           DbInterceptorManager manager = (DbInterceptorManager)parentCategory.getInterceptorManager();
/* 397 */           manager.invokeInterceptors(message, type);
/*     */ 
/* 399 */           for (int i = 0; i < this.interceptors.length; i++) {
/* 400 */             MessageInterceptor interceptor = this.interceptors[i];
/* 401 */             if (interceptorMatches(interceptor.getType(), type))
/* 402 */               interceptor.invokeInterceptor(message, type);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e)
/*     */       {
/*     */       }
/*     */     }
/*     */     else
/*     */       try
/*     */       {
/* 413 */         DbForumCategory category = (DbForumCategory)FACTORY.getForum(this.objectID).getForumCategory();
/* 414 */         DbInterceptorManager manager = (DbInterceptorManager)category.getInterceptorManager();
/* 415 */         manager.invokeInterceptors(message, type);
/*     */ 
/* 417 */         for (int i = 0; i < this.interceptors.length; i++) {
/* 418 */           MessageInterceptor interceptor = this.interceptors[i];
/* 419 */           if (interceptorMatches(interceptor.getType(), type))
/* 420 */             interceptor.invokeInterceptor(message, type);
/*     */         }
/*     */       }
/*     */       catch (ForumNotFoundException e)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   private static boolean interceptorMatches(int interceptorType, int type)
/*     */   {
/* 436 */     if (interceptorType == 4) {
/* 437 */       return true;
/*     */     }
/* 439 */     if (interceptorType == type) {
/* 440 */       return true;
/*     */     }
/* 442 */     if ((interceptorType == 2) && ((type == 1) || (type == 0)))
/*     */     {
/* 445 */       return true;
/*     */     }
/* 447 */     return false;
/*     */   }
/*     */ 
/*     */   private void loadGlobalInterceptors()
/*     */   {
/* 452 */     int interceptorCount = JiveGlobals.getJiveIntProperty("interceptor.global.interceptorCount", 0);
/*     */ 
/* 455 */     List interceptorList = new ArrayList(interceptorCount);
/* 456 */     for (int i = 0; i < interceptorCount; i++) {
/*     */       try {
/* 458 */         String interceptorContext = "interceptor.global.interceptor" + i + ".";
/* 459 */         String className = JiveGlobals.getJiveProperty(interceptorContext + "className");
/* 460 */         Class interceptorClass = ClassUtils.forName(className);
/* 461 */         Constructor constructor = interceptorClass.getConstructor(new Class[] { Integer.TYPE, Long.TYPE });
/*     */ 
/* 463 */         Object[] initargs = { new Integer(this.objectType), new Long(this.objectID) };
/* 464 */         interceptorList.add(constructor.newInstance(initargs));
/*     */ 
/* 467 */         List props = JiveGlobals.getJivePropertyNames(interceptorContext + "properties");
/* 468 */         Map interceptorProps = new HashMap();
/*     */ 
/* 470 */         for (int k = 0; k < props.size(); k++) {
/* 471 */           String key = (String)props.get(k);
/* 472 */           String value = JiveGlobals.getJiveProperty((String)props.get(k));
/*     */ 
/* 475 */           interceptorProps.put(key.substring(key.lastIndexOf(".") + 1), value);
/*     */         }
/*     */ 
/* 479 */         BeanUtils.setProperties(interceptorList.get(i), interceptorProps);
/*     */       }
/*     */       catch (Exception e) {
/* 482 */         Log.error("Error loading global interceptor " + i, e);
/*     */       }
/*     */     }
/* 485 */     this.interceptors = ((MessageInterceptor[])interceptorList.toArray(new MessageInterceptor[interceptorList.size()]));
/*     */   }
/*     */ 
/*     */   private void loadCategoryInterceptors() throws ForumCategoryNotFoundException
/*     */   {
/* 490 */     DbForumCategory category = FACTORY.cacheManager.getForumCategory(this.objectID);
/* 491 */     int interceptorCount = 0;
/* 492 */     String iCount = category.getProperty("jive.interceptor.interceptorCount");
/* 493 */     if (iCount != null) {
/*     */       try {
/* 495 */         interceptorCount = Integer.parseInt(iCount);
/*     */       }
/*     */       catch (NumberFormatException nfe)
/*     */       {
/*     */       }
/*     */     }
/* 501 */     List interceptorList = new ArrayList(interceptorCount);
/* 502 */     for (int i = 0; i < interceptorCount; i++) {
/*     */       try {
/* 504 */         String interceptorContext = "jive.interceptor.interceptor" + i + ".";
/* 505 */         String className = category.getProperty(interceptorContext + "className");
/* 506 */         Class interceptorClass = ClassUtils.forName(className);
/* 507 */         Constructor constructor = interceptorClass.getConstructor(new Class[] { Integer.TYPE, Long.TYPE });
/*     */ 
/* 509 */         Object[] initargs = { new Integer(this.objectType), new Long(this.objectID) };
/* 510 */         interceptorList.add(constructor.newInstance(initargs));
/*     */ 
/* 513 */         Iterator props = getChildrenPropertyNames(interceptorContext + "properties", category.getPropertyNames());
/*     */ 
/* 515 */         Map interceptorProps = new HashMap();
/*     */ 
/* 517 */         for (Iterator k = props; k.hasNext(); ) {
/* 518 */           String key = (String)k.next();
/* 519 */           String value = category.getProperty(key);
/*     */ 
/* 522 */           interceptorProps.put(key.substring(key.lastIndexOf(".") + 1), value);
/*     */         }
/*     */ 
/* 526 */         BeanUtils.setProperties(interceptorList.get(i), interceptorProps);
/*     */       }
/*     */       catch (Exception e) {
/* 529 */         Log.error("Error loading category filter " + i, e);
/*     */       }
/*     */     }
/* 532 */     this.interceptors = ((MessageInterceptor[])interceptorList.toArray(new MessageInterceptor[interceptorList.size()]));
/*     */   }
/*     */ 
/*     */   private void loadForumInterceptors() throws ForumNotFoundException
/*     */   {
/* 537 */     DbForum forum = FACTORY.cacheManager.getForum(this.objectID);
/* 538 */     int interceptorCount = 0;
/* 539 */     String iCount = forum.getProperty("jive.interceptor.interceptorCount");
/* 540 */     if (iCount != null) {
/*     */       try {
/* 542 */         interceptorCount = Integer.parseInt(iCount);
/*     */       }
/*     */       catch (NumberFormatException nfe)
/*     */       {
/*     */       }
/*     */     }
/* 548 */     List interceptorList = new ArrayList(interceptorCount);
/* 549 */     for (int i = 0; i < interceptorCount; i++) {
/*     */       try {
/* 551 */         String interceptorContext = "jive.interceptor.interceptor" + i + ".";
/* 552 */         String className = forum.getProperty(interceptorContext + "className");
/* 553 */         Class interceptorClass = ClassUtils.forName(className);
/* 554 */         Constructor constructor = interceptorClass.getConstructor(new Class[] { Integer.TYPE, Long.TYPE });
/*     */ 
/* 556 */         Object[] initargs = { new Integer(this.objectType), new Long(this.objectID) };
/* 557 */         interceptorList.add(constructor.newInstance(initargs));
/*     */ 
/* 560 */         Iterator props = getChildrenPropertyNames(interceptorContext + "properties", forum.getPropertyNames());
/*     */ 
/* 562 */         Map interceptorProps = new HashMap();
/*     */ 
/* 564 */         for (Iterator k = props; k.hasNext(); ) {
/* 565 */           String key = (String)k.next();
/* 566 */           String value = forum.getProperty(key);
/*     */ 
/* 569 */           interceptorProps.put(key.substring(key.lastIndexOf(".") + 1), value);
/*     */         }
/*     */ 
/* 573 */         BeanUtils.setProperties(interceptorList.get(i), interceptorProps);
/*     */       }
/*     */       catch (Exception e) {
/* 576 */         Log.error("Error loading category filter " + i, e);
/*     */       }
/*     */     }
/* 579 */     this.interceptors = ((MessageInterceptor[])interceptorList.toArray(new MessageInterceptor[interceptorList.size()]));
/*     */   }
/*     */ 
/*     */   private static Iterator getChildrenPropertyNames(String parent, Iterator properties)
/*     */   {
/* 591 */     List results = new ArrayList();
/* 592 */     for (Iterator i = properties; i.hasNext(); ) {
/* 593 */       String name = (String)i.next();
/* 594 */       if ((name.startsWith(parent)) && (!name.equals(parent))) {
/* 595 */         results.add(name);
/*     */       }
/*     */     }
/* 598 */     return results.iterator();
/*     */   }
/*     */ 
/*     */   private static class UpdateClusterTask
/*     */     implements Runnable, Serializable
/*     */   {
/*     */     private int objectType;
/*     */     private long objectID;
/*     */ 
/*     */     public UpdateClusterTask(int objectType, long objectID)
/*     */     {
/* 610 */       this.objectType = objectType;
/* 611 */       this.objectID = objectID;
/*     */     }
/*     */ 
/*     */     public void run() {
/* 615 */       DbForumFactory factory = DbForumFactory.getInstance();
/* 616 */       if (this.objectType == 17) {
/* 617 */         DbInterceptorManager manager = (DbInterceptorManager)factory.getInterceptorManager();
/*     */ 
/* 619 */         manager.loadGlobalInterceptors();
/*     */       }
/* 621 */       else if (this.objectType == 14) {
/*     */         try {
/* 623 */           DbForumCategory category = (DbForumCategory)factory.getForumCategory(this.objectID);
/* 624 */           DbInterceptorManager manager = (DbInterceptorManager)category.getInterceptorManager();
/*     */ 
/* 626 */           manager.loadCategoryInterceptors();
/*     */         }
/*     */         catch (ForumCategoryNotFoundException fcnfe) {
/* 629 */           Log.error(fcnfe);
/*     */         }
/*     */       }
/* 632 */       else if (this.objectType == 0) {
/*     */         try {
/* 634 */           DbForum forum = (DbForum)factory.getForum(this.objectID);
/* 635 */           DbInterceptorManager manager = (DbInterceptorManager)forum.getInterceptorManager();
/*     */ 
/* 637 */           manager.loadForumInterceptors();
/*     */         }
/*     */         catch (ForumNotFoundException fnfe) {
/* 640 */           Log.error(fnfe);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbInterceptorManager
 * JD-Core Version:    0.6.2
 */
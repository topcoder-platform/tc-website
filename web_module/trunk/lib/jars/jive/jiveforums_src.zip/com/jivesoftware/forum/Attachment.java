package com.jivesoftware.forum;

import com.jivesoftware.base.UnauthorizedException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

public abstract interface Attachment
{
  public abstract long getID();

  public abstract String getContentType();

  public abstract String getName();

  public abstract void setName(String paramString)
    throws UnauthorizedException;

  public abstract long getSize();

  public abstract InputStream getData()
    throws IOException;

  public abstract Date getCreationDate();

  public abstract Date getModificationDate();

  public abstract String getProperty(String paramString);

  public abstract Collection getProperties(String paramString);

  public abstract void setProperty(String paramString1, String paramString2)
    throws UnauthorizedException;

  public abstract void deleteProperty(String paramString)
    throws UnauthorizedException;

  public abstract Iterator getPropertyNames();
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.Attachment
 * JD-Core Version:    0.6.2
 */
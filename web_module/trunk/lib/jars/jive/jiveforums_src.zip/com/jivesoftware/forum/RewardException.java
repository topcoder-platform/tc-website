/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ public class RewardException extends Exception
/*    */ {
/* 23 */   private Throwable nestedThrowable = null;
/*    */ 
/*    */   public RewardException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public RewardException(String msg) {
/* 30 */     super(msg);
/*    */   }
/*    */ 
/*    */   public RewardException(Throwable nestedThrowable) {
/* 34 */     this.nestedThrowable = nestedThrowable;
/*    */   }
/*    */ 
/*    */   public RewardException(String msg, Throwable nestedThrowable) {
/* 38 */     super(msg);
/* 39 */     this.nestedThrowable = nestedThrowable;
/*    */   }
/*    */ 
/*    */   public void printStackTrace() {
/* 43 */     super.printStackTrace();
/* 44 */     if (this.nestedThrowable != null)
/* 45 */       this.nestedThrowable.printStackTrace();
/*    */   }
/*    */ 
/*    */   public void printStackTrace(PrintStream ps)
/*    */   {
/* 50 */     super.printStackTrace(ps);
/* 51 */     if (this.nestedThrowable != null)
/* 52 */       this.nestedThrowable.printStackTrace(ps);
/*    */   }
/*    */ 
/*    */   public void printStackTrace(PrintWriter pw)
/*    */   {
/* 57 */     super.printStackTrace(pw);
/* 58 */     if (this.nestedThrowable != null)
/* 59 */       this.nestedThrowable.printStackTrace(pw);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.RewardException
 * JD-Core Version:    0.6.2
 */
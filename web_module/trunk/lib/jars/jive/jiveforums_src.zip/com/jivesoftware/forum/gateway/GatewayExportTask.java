/*     */ package com.jivesoftware.forum.gateway;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class GatewayExportTask
/*     */   implements Runnable
/*     */ {
/*  27 */   private boolean isBusy = false;
/*  28 */   private boolean hasRun = false;
/*  29 */   private Forum forum = null;
/*  30 */   private Gateway gateway = null;
/*  31 */   private Date afterDate = new Date();
/*  32 */   private int current = 0;
/*  33 */   private int total = 0;
/*  34 */   private ArrayList err = new ArrayList();
/*     */ 
/*     */   public GatewayExportTask(Forum forum, Gateway gateway, Date afterDate) {
/*  37 */     this.forum = forum;
/*  38 */     this.gateway = gateway;
/*  39 */     this.afterDate = afterDate;
/*     */   }
/*     */ 
/*     */   public boolean isBusy() {
/*  43 */     return this.isBusy;
/*     */   }
/*     */ 
/*     */   public boolean hasRun() {
/*  47 */     return this.hasRun;
/*     */   }
/*     */ 
/*     */   public int getCurrentMessageCount() {
/*  51 */     return this.current;
/*     */   }
/*     */ 
/*     */   public int getTotalMessageCount() {
/*  55 */     return this.total;
/*     */   }
/*     */ 
/*     */   public ArrayList getErrors() {
/*  59 */     return this.err;
/*     */   }
/*     */ 
/*     */   public void run() {
/*     */     try {
/*  64 */       this.hasRun = true;
/*  65 */       this.isBusy = true;
/*     */ 
/*  67 */       ResultFilter filter = ResultFilter.createDefaultMessageFilter();
/*  68 */       filter.setCreationDateRangeMin(this.afterDate);
/*  69 */       Iterator messages = this.forum.getMessages(filter);
/*  70 */       this.total = this.forum.getMessageCount(filter);
/*  71 */       List toExport = new ArrayList();
/*     */ 
/*  73 */       while (messages.hasNext()) {
/*  74 */         ForumMessage message = (ForumMessage)messages.next();
/*     */ 
/*  77 */         if (message.getUnfilteredProperty("Jive-Created-Message") != null) {
/*  78 */           this.total -= 1;
/*     */         }
/*     */         else
/*     */         {
/*  82 */           this.current += 1;
/*     */ 
/*  84 */           toExport.add(message);
/*     */ 
/*  87 */           if (this.current % 50 == 0) {
/*     */             try {
/*  89 */               ForumMessage[] fmArray = new ForumMessage[toExport.size()];
/*  90 */               this.gateway.exportData((ForumMessage[])toExport.toArray(fmArray));
/*     */             }
/*     */             catch (GatewayException ge) {
/*  93 */               this.err.add(ge);
/*  94 */               Log.error(ge);
/*     */             }
/*     */             finally {
/*  97 */               toExport.clear();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 102 */       if (!toExport.isEmpty())
/*     */         try {
/* 104 */           ForumMessage[] fmArray = new ForumMessage[toExport.size()];
/* 105 */           this.gateway.exportData((ForumMessage[])toExport.toArray(fmArray));
/*     */         }
/*     */         catch (GatewayException ge) {
/* 108 */           this.err.add(ge);
/* 109 */           Log.error(ge);
/*     */         }
/*     */     }
/*     */     finally
/*     */     {
/* 114 */       this.isBusy = false;
/* 115 */       this.gateway = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stop() {
/* 120 */     synchronized (this) {
/*     */       try {
/* 122 */         if ((this.isBusy) && (this.gateway != null)) {
/* 123 */           GatewayExporter exporter = this.gateway.getGatewayExporter();
/* 124 */           exporter.stop();
/*     */         }
/*     */       }
/*     */       catch (GatewayException ge) {
/* 128 */         Log.error(ge);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.GatewayExportTask
 * JD-Core Version:    0.6.2
 */
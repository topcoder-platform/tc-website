/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class NewsGroupFilter
/*     */ {
/*  43 */   public static final NewsGroupFilter MATCH_ALL = new NewsGroupFilter();
/*     */   private LinkedList filterList;
/*     */   private NNTPDate startDate;
/*     */   private long groupID;
/*  52 */   private static final Pattern DOT_PATTERN = Pattern.compile("\\.");
/*     */ 
/*  54 */   private static final Pattern STAR_PATTERN = Pattern.compile("\\*");
/*     */ 
/*     */   public NewsGroupFilter()
/*     */   {
/*  46 */     this.filterList = new LinkedList();
/*     */ 
/*  48 */     this.startDate = null;
/*     */ 
/*  50 */     this.groupID = -1L;
/*     */   }
/*     */ 
/*     */   public static NewsGroupFilter getSingleGroupByIDFilter(long id)
/*     */   {
/*  64 */     NewsGroupFilter filter = new NewsGroupFilter();
/*  65 */     filter.groupID = id;
/*  66 */     return filter;
/*     */   }
/*     */ 
/*     */   public boolean isSingleGroupFilter()
/*     */   {
/*  75 */     return this.groupID > 0L;
/*     */   }
/*     */ 
/*     */   public long getGroupID()
/*     */   {
/*  84 */     return this.groupID;
/*     */   }
/*     */ 
/*     */   public void setStartDate(NNTPDate start)
/*     */   {
/*  95 */     this.startDate = start;
/*     */   }
/*     */ 
/*     */   public NNTPDate getStartDate()
/*     */   {
/* 106 */     return this.startDate;
/*     */   }
/*     */ 
/*     */   public int getNameFilterCount()
/*     */   {
/* 116 */     return this.filterList.size();
/*     */   }
/*     */ 
/*     */   public void addFilterList(String list)
/*     */   {
/* 126 */     String[] filters = list.split(",");
/* 127 */     for (int i = 0; i < filters.length; i++)
/* 128 */       this.filterList.addLast(new GroupMatcher(filters[i], null));
/*     */   }
/*     */ 
/*     */   public void addDistributionList(String list)
/*     */   {
/* 139 */     String[] filters = list.split(",");
/* 140 */     for (int i = 0; i < filters.length; i++)
/* 141 */       this.filterList.addLast(new GroupMatcher(filters[i] + ".*", null));
/*     */   }
/*     */ 
/*     */   public boolean matches(String name)
/*     */   {
/* 156 */     boolean matches = false;
/* 157 */     if (this.filterList.isEmpty()) {
/* 158 */       matches = true;
/*     */     }
/*     */     else {
/* 161 */       Iterator filters = this.filterList.iterator();
/* 162 */       while (filters.hasNext()) {
/* 163 */         GroupMatcher matcher = (GroupMatcher)filters.next();
/* 164 */         if (!matches) {
/* 165 */           if (!matcher.isNot()) {
/* 166 */             matches = matcher.matches(name);
/*     */           }
/*     */         }
/* 169 */         else if ((matcher.isNot()) && (matcher.matches(name))) {
/* 170 */           matches = false;
/*     */         }
/*     */       }
/*     */     }
/* 174 */     return matches;
/*     */   }
/*     */ 
/*     */   private class GroupMatcher
/*     */   {
/* 185 */     private boolean not = false;
/*     */     private Pattern compiledPattern;
/*     */ 
/*     */     private GroupMatcher(String pattern)
/*     */     {
/* 196 */       if (pattern.charAt(0) == '!') {
/* 197 */         this.not = true;
/* 198 */         pattern = pattern.substring(1);
/*     */       }
/* 200 */       Matcher matcher = NewsGroupFilter.DOT_PATTERN.matcher(pattern);
/* 201 */       pattern = matcher.replaceAll("\\.");
/* 202 */       matcher = NewsGroupFilter.STAR_PATTERN.matcher(pattern);
/* 203 */       pattern = matcher.replaceAll(".*");
/* 204 */       this.compiledPattern = Pattern.compile(pattern);
/*     */     }
/*     */ 
/*     */     private boolean isNot()
/*     */     {
/* 214 */       return this.not;
/*     */     }
/*     */ 
/*     */     private boolean matches(String name)
/*     */     {
/* 225 */       Matcher matcher = this.compiledPattern.matcher(name);
/* 226 */       return matcher.matches();
/*     */     }
/*     */ 
/*     */     GroupMatcher(String x1, NewsGroupFilter.1 x2)
/*     */     {
/* 182 */       this(x1);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NewsGroupFilter
 * JD-Core Version:    0.6.2
 */
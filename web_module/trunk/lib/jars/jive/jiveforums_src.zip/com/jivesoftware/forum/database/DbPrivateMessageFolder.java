/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.forum.PrivateMessage;
/*     */ import com.jivesoftware.forum.PrivateMessageFolder;
/*     */ import com.jivesoftware.forum.PrivateMessageFolderNotFoundException;
/*     */ import com.jivesoftware.forum.proxy.PrivateMessageProxy;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheSizes;
/*     */ import com.jivesoftware.util.Cacheable;
/*     */ import com.jivesoftware.util.ExternalizableLiteUtil;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import com.tangosol.io.ExternalizableLite;
/*     */ import com.tangosol.util.ExternalizableHelper;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class DbPrivateMessageFolder
/*     */   implements PrivateMessageFolder, Cacheable, ExternalizableLite
/*     */ {
/*     */   private static final String GET_MESSAGE_COUNT = "SELECT count(*) FROM jivePMessage WHERE folderID=? AND ownerID=?";
/*     */   private static final String GET_UNREAD_MESSAGE_COUNT = "SELECT count(*) FROM jivePMessage WHERE folderID=? AND readStatus=0 AND ownerID=?";
/*     */   private static final String GET_MESSAGES = "SELECT pMessageID FROM jivePMessage WHERE folderID=? AND ownerID=?";
/*     */   private static final String LOAD_FOLDER = "SELECT name FROM jivePMessageFldr WHERE folderID=? AND userID=?";
/*     */   private static final String GET_MAX_FOLDER_ID = "SELECT max(folderID) FROM jivePMessageFldr WHERE userID=?";
/*     */   private static final String INSERT_FOLDER = "INSERT into jivePMessageFldr(folderID, userID, name) VALUES(?,?,?)";
/*     */   private static final String SAVE_FOLDER_NAME = "UPDATE jivePMessageFldr SET name=? WHERE folderID=? AND userID=?";
/*  53 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */   private int folderID;
/*     */   private long userID;
/*     */   private String name;
/*  59 */   private int messageCount = -1;
/*  60 */   private int unreadMessageCount = -1;
/*  61 */   private long[] messages = null;
/*     */ 
/*     */   public DbPrivateMessageFolder(int folderID, long userID)
/*     */     throws PrivateMessageFolderNotFoundException
/*     */   {
/*  73 */     this.folderID = folderID;
/*  74 */     this.userID = userID;
/*  75 */     switch (folderID) {
/*     */     case 1:
/*  77 */       this.name = "INBOX";
/*  78 */       break;
/*     */     case 3:
/*  80 */       this.name = "DRAFTS";
/*  81 */       break;
/*     */     case 2:
/*  83 */       this.name = "SENT";
/*  84 */       break;
/*     */     case 4:
/*  86 */       this.name = "TRASH";
/*  87 */       break;
/*     */     default:
/*  89 */       loadFromDb();
/*     */     }
/*     */   }
/*     */ 
/*     */   public DbPrivateMessageFolder(long userID, String name)
/*     */   {
/* 100 */     this.userID = userID;
/* 101 */     this.name = name;
/* 102 */     insertIntoDb();
/*     */   }
/*     */ 
/*     */   public DbPrivateMessageFolder()
/*     */   {
/*     */   }
/*     */ 
/*     */   public int getID()
/*     */   {
/* 113 */     return this.folderID;
/*     */   }
/*     */ 
/*     */   public User getOwner() {
/*     */     try {
/* 118 */       return FACTORY.getUserManager().getUser(this.userID);
/*     */     }
/*     */     catch (UserNotFoundException unfe) {
/* 121 */       Log.error(unfe);
/*     */     }
/* 123 */     return null;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 127 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 132 */     if ((this.folderID == 1) || (this.folderID == 3) || (this.folderID == 2) || (this.folderID == 4))
/*     */     {
/* 135 */       return;
/*     */     }
/*     */ 
/* 138 */     if (this.name.equals(name)) {
/* 139 */       return;
/*     */     }
/* 141 */     this.name = name;
/*     */ 
/* 143 */     Connection con = null;
/* 144 */     PreparedStatement pstmt = null;
/*     */     try {
/* 146 */       con = ConnectionManager.getConnection();
/* 147 */       pstmt = con.prepareStatement("UPDATE jivePMessageFldr SET name=? WHERE folderID=? AND userID=?");
/* 148 */       pstmt.setString(1, name);
/* 149 */       pstmt.setInt(2, this.folderID);
/* 150 */       pstmt.setLong(3, this.userID);
/* 151 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 154 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 157 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 160 */     FACTORY.cacheManager.privateMessageFolderCache.put(getCacheKey(this.folderID, this.userID), this);
/*     */   }
/*     */ 
/*     */   public synchronized int getMessageCount() {
/* 164 */     if (this.messageCount != -1) {
/* 165 */       return this.messageCount;
/*     */     }
/* 167 */     Connection con = null;
/* 168 */     PreparedStatement pstmt = null;
/*     */     try {
/* 170 */       con = ConnectionManager.getConnection();
/* 171 */       pstmt = con.prepareStatement("SELECT count(*) FROM jivePMessage WHERE folderID=? AND ownerID=?");
/* 172 */       pstmt.setInt(1, this.folderID);
/* 173 */       pstmt.setLong(2, this.userID);
/* 174 */       ResultSet rs = pstmt.executeQuery();
/* 175 */       rs.next();
/* 176 */       this.messageCount = rs.getInt(1);
/* 177 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 180 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 183 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 186 */     FACTORY.cacheManager.privateMessageFolderCache.put(getCacheKey(this.folderID, this.userID), this);
/* 187 */     return this.messageCount;
/*     */   }
/*     */ 
/*     */   public synchronized int getUnreadMessageCount() {
/* 191 */     if (this.unreadMessageCount != -1) {
/* 192 */       return this.unreadMessageCount;
/*     */     }
/* 194 */     Connection con = null;
/* 195 */     PreparedStatement pstmt = null;
/*     */     try {
/* 197 */       con = ConnectionManager.getConnection();
/* 198 */       pstmt = con.prepareStatement("SELECT count(*) FROM jivePMessage WHERE folderID=? AND readStatus=0 AND ownerID=?");
/* 199 */       pstmt.setInt(1, this.folderID);
/* 200 */       pstmt.setLong(2, this.userID);
/* 201 */       ResultSet rs = pstmt.executeQuery();
/* 202 */       rs.next();
/* 203 */       this.unreadMessageCount = rs.getInt(1);
/* 204 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 207 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 210 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */ 
/* 213 */     FACTORY.cacheManager.privateMessageFolderCache.put(getCacheKey(this.folderID, this.userID), this);
/* 214 */     return this.unreadMessageCount;
/*     */   }
/*     */ 
/*     */   public synchronized Iterator getMessages() {
/* 218 */     if (this.messages != null) {
/* 219 */       return new DatabaseObjectIterator(20, this.messages, FACTORY.getPrivateMessageManager());
/*     */     }
/*     */ 
/* 223 */     LongList messageList = new LongList();
/* 224 */     Connection con = null;
/* 225 */     PreparedStatement pstmt = null;
/*     */     try {
/* 227 */       con = ConnectionManager.getConnection();
/* 228 */       pstmt = con.prepareStatement("SELECT pMessageID FROM jivePMessage WHERE folderID=? AND ownerID=?");
/* 229 */       pstmt.setInt(1, this.folderID);
/* 230 */       pstmt.setLong(2, this.userID);
/* 231 */       ResultSet rs = pstmt.executeQuery();
/* 232 */       while (rs.next()) {
/* 233 */         messageList.add(rs.getInt(1));
/*     */       }
/* 235 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 238 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 241 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 243 */     this.messages = messageList.toArray();
/*     */ 
/* 245 */     FACTORY.cacheManager.privateMessageFolderCache.put(getCacheKey(this.folderID, this.userID), this);
/* 246 */     return new DatabaseObjectIterator(20, this.messages, FACTORY.getPrivateMessageManager());
/*     */   }
/*     */ 
/*     */   public Iterator getMessages(int startIndex, int count, int sortField, boolean sortDescending)
/*     */   {
/* 251 */     List messages = new ArrayList();
/* 252 */     for (Iterator i = getMessages(); i.hasNext(); ) {
/* 253 */       messages.add(i.next());
/*     */     }
/* 255 */     Collections.sort(messages, new PrivateMessageComparator(sortField, sortDescending));
/* 256 */     if (startIndex >= messages.size()) {
/* 257 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/* 259 */     int end = startIndex + count;
/* 260 */     if (end > messages.size()) {
/* 261 */       end = messages.size();
/*     */     }
/* 263 */     messages = messages.subList(startIndex, end);
/* 264 */     return Collections.unmodifiableList(messages).iterator();
/*     */   }
/*     */ 
/*     */   public void deleteMessage(PrivateMessage privateMessage) {
/* 268 */     DbPrivateMessage dbPrivateMessage = null;
/* 269 */     if ((privateMessage instanceof PrivateMessageProxy)) {
/* 270 */       PrivateMessageProxy proxy = (PrivateMessageProxy)privateMessage;
/* 271 */       dbPrivateMessage = (DbPrivateMessage)proxy.getProxiedPrivateMessage();
/*     */     }
/*     */     else {
/* 274 */       dbPrivateMessage = (DbPrivateMessage)privateMessage;
/*     */     }
/* 276 */     if (!equals(dbPrivateMessage.getFolder())) {
/* 277 */       throw new IllegalArgumentException("Cannot delete a message that doesn't belong to this folder.");
/*     */     }
/*     */ 
/* 281 */     if (this.folderID == 4) {
/* 282 */       return;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 287 */       dbPrivateMessage.setFolder(new DbPrivateMessageFolder(4, this.userID));
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/* 291 */     FACTORY.cacheManager.privateMessageFolderCache.remove(getCacheKey(this.folderID, this.userID));
/* 292 */     FACTORY.cacheManager.privateMessageFolderCache.remove(getCacheKey(4, this.userID));
/*     */   }
/*     */ 
/*     */   public void moveMessage(PrivateMessage privateMessage, PrivateMessageFolder destinationFolder)
/*     */   {
/* 297 */     if (destinationFolder == null) {
/* 298 */       throw new IllegalArgumentException("Destination folder cannot be null.");
/*     */     }
/* 300 */     DbPrivateMessage dbPrivateMessage = null;
/* 301 */     if ((privateMessage instanceof PrivateMessageProxy)) {
/* 302 */       PrivateMessageProxy proxy = (PrivateMessageProxy)privateMessage;
/* 303 */       dbPrivateMessage = (DbPrivateMessage)proxy.getProxiedPrivateMessage();
/*     */     }
/*     */     else {
/* 306 */       dbPrivateMessage = (DbPrivateMessage)privateMessage;
/*     */     }
/* 308 */     if ((dbPrivateMessage.getOwnerID() != this.userID) || (!equals(dbPrivateMessage.getFolder())))
/*     */     {
/* 311 */       throw new IllegalArgumentException("Cannot move a message that doesn't belong to this folder.");
/*     */     }
/*     */ 
/* 314 */     dbPrivateMessage.setFolder(destinationFolder);
/* 315 */     FACTORY.cacheManager.privateMessageFolderCache.remove(getCacheKey(this.folderID, this.userID));
/* 316 */     FACTORY.cacheManager.privateMessageFolderCache.remove(getCacheKey(destinationFolder.getID(), this.userID));
/*     */   }
/*     */ 
/*     */   public int getCachedSize()
/*     */   {
/* 323 */     int size = 0;
/* 324 */     size += CacheSizes.sizeOfObject();
/* 325 */     size += CacheSizes.sizeOfInt();
/* 326 */     size += CacheSizes.sizeOfLong();
/* 327 */     size += CacheSizes.sizeOfString(this.name);
/* 328 */     size += CacheSizes.sizeOfInt() * 2;
/* 329 */     if (this.messages != null) {
/* 330 */       size += CacheSizes.sizeOfLong() * this.messages.length;
/*     */     }
/* 332 */     return size;
/*     */   }
/*     */ 
/*     */   public void readExternal(DataInput in)
/*     */     throws IOException
/*     */   {
/* 338 */     this.folderID = ExternalizableHelper.readInt(in);
/* 339 */     this.userID = ExternalizableHelper.readLong(in);
/* 340 */     this.name = ExternalizableHelper.readSafeUTF(in);
/* 341 */     this.messageCount = ExternalizableHelper.readInt(in);
/* 342 */     this.unreadMessageCount = ExternalizableHelper.readInt(in);
/* 343 */     this.messages = ExternalizableLiteUtil.readLongArray(in);
/*     */   }
/*     */ 
/*     */   public void writeExternal(DataOutput out) throws IOException {
/* 347 */     ExternalizableHelper.writeInt(out, this.folderID);
/* 348 */     ExternalizableHelper.writeLong(out, this.userID);
/* 349 */     ExternalizableHelper.writeSafeUTF(out, this.name);
/* 350 */     ExternalizableHelper.writeInt(out, this.messageCount);
/* 351 */     ExternalizableHelper.writeInt(out, this.unreadMessageCount);
/* 352 */     ExternalizableLiteUtil.writeLongArray(out, this.messages);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 358 */     return "[" + this.folderID + "] " + this.name;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object) {
/* 362 */     if (this == object) {
/* 363 */       return true;
/*     */     }
/* 365 */     if ((object != null) && ((object instanceof ExternalizableLite))) {
/* 366 */       return (this.folderID == ((ExternalizableLite)object).getID()) && (this.userID == ((ExternalizableLite)object).getOwner().getID());
/*     */     }
/*     */ 
/* 370 */     return false;
/*     */   }
/*     */ 
/*     */   private void loadFromDb() throws PrivateMessageFolderNotFoundException
/*     */   {
/* 375 */     Connection con = null;
/* 376 */     PreparedStatement pstmt = null;
/*     */     try {
/* 378 */       con = ConnectionManager.getConnection();
/* 379 */       pstmt = con.prepareStatement("SELECT name FROM jivePMessageFldr WHERE folderID=? AND userID=?");
/* 380 */       pstmt.setInt(1, this.folderID);
/* 381 */       pstmt.setLong(2, this.userID);
/*     */ 
/* 383 */       ResultSet rs = pstmt.executeQuery();
/* 384 */       if (!rs.next()) {
/* 385 */         throw new PrivateMessageFolderNotFoundException("Private message folder " + getCacheKey(this.folderID, this.userID) + " could not be loaded from the database.");
/*     */       }
/*     */ 
/* 388 */       this.name = rs.getString(1);
/* 389 */       rs.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 392 */       throw new PrivateMessageFolderNotFoundException("Private message folder with id " + getCacheKey(this.folderID, this.userID) + " could not be loaded from the database.");
/*     */     }
/*     */     finally
/*     */     {
/* 397 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void insertIntoDb() {
/* 402 */     Connection con = null;
/* 403 */     PreparedStatement pstmt = null;
/* 404 */     boolean abortTransaction = false;
/*     */     try {
/* 406 */       con = ConnectionManager.getTransactionConnection();
/*     */ 
/* 408 */       pstmt = con.prepareStatement("SELECT max(folderID) FROM jivePMessageFldr WHERE userID=?");
/* 409 */       pstmt.setLong(1, this.userID);
/* 410 */       ResultSet rs = pstmt.executeQuery();
/* 411 */       if (rs.next()) {
/* 412 */         this.folderID = (rs.getInt(1) + 1);
/*     */       }
/*     */ 
/* 419 */       if (this.folderID <= 4) {
/* 420 */         this.folderID = 5;
/*     */       }
/* 422 */       rs.close();
/* 423 */       pstmt.close();
/*     */ 
/* 425 */       pstmt = con.prepareStatement("INSERT into jivePMessageFldr(folderID, userID, name) VALUES(?,?,?)");
/* 426 */       pstmt.setInt(1, this.folderID);
/* 427 */       pstmt.setLong(2, this.userID);
/* 428 */       pstmt.setString(3, this.name);
/* 429 */       pstmt.execute();
/* 430 */       rs.close();
/* 431 */       pstmt.close();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 434 */       abortTransaction = true;
/* 435 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 438 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   static String getCacheKey(int folderID, long userID)
/*     */   {
/* 450 */     return folderID + "-" + userID;
/*     */   }
/*     */ 
/*     */   private static class PrivateMessageComparator
/*     */     implements Comparator
/*     */   {
/*     */     private int sortField;
/*     */     private boolean sortDescending;
/*     */ 
/*     */     public PrivateMessageComparator(int sortField, boolean sortDescending)
/*     */     {
/* 462 */       this.sortField = sortField;
/* 463 */       this.sortDescending = sortDescending;
/*     */     }
/*     */ 
/*     */     public int compare(Object o1, Object o2) {
/* 467 */       PrivateMessage message1 = (PrivateMessage)o1;
/* 468 */       PrivateMessage message2 = (PrivateMessage)o2;
/* 469 */       switch (this.sortField) {
/*     */       case 1000:
/* 471 */         if (this.sortDescending) {
/* 472 */           return message1.getDate().compareTo(message2.getDate()) * -1;
/*     */         }
/*     */ 
/* 475 */         return message1.getDate().compareTo(message2.getDate());
/*     */       case 1002:
/* 478 */         String sender1 = getName(message1.getSender());
/* 479 */         String sender2 = getName(message2.getSender());
/* 480 */         if (this.sortDescending) {
/* 481 */           return sender1.compareTo(sender2) * -1;
/*     */         }
/*     */ 
/* 484 */         return sender1.compareTo(sender2);
/*     */       case 1001:
/* 487 */         if (this.sortDescending) {
/* 488 */           return message1.getSubject().compareTo(message2.getSubject()) * -1;
/*     */         }
/*     */ 
/* 491 */         return message1.getSubject().compareTo(message2.getSubject());
/*     */       }
/*     */ 
/* 494 */       return 0;
/*     */     }
/*     */ 
/*     */     private static String getName(User user)
/*     */     {
/* 505 */       if (user == null) {
/* 506 */         return "";
/*     */       }
/* 508 */       String name = user.getName();
/* 509 */       if (name != null) {
/* 510 */         return name;
/*     */       }
/*     */ 
/* 513 */       return user.getUsername();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbPrivateMessageFolder
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ public class ForumCategoryNotFoundException extends Exception
/*    */ {
/* 19 */   private long forumCategoryID = -1L;
/*    */ 
/*    */   public ForumCategoryNotFoundException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ForumCategoryNotFoundException(String msg) {
/* 26 */     super(msg);
/*    */   }
/*    */ 
/*    */   public ForumCategoryNotFoundException(String s, long forumCategoryID)
/*    */   {
/* 36 */     super(s);
/* 37 */     this.forumCategoryID = forumCategoryID;
/*    */   }
/*    */ 
/*    */   public ForumCategoryNotFoundException(long forumCategoryID)
/*    */   {
/* 46 */     this.forumCategoryID = forumCategoryID;
/*    */   }
/*    */ 
/*    */   public void setForumCategoryID(long forumCategoryID)
/*    */   {
/* 54 */     this.forumCategoryID = forumCategoryID;
/*    */   }
/*    */ 
/*    */   public long getForumCategoryID()
/*    */   {
/* 63 */     return this.forumCategoryID;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.ForumCategoryNotFoundException
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.event;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.event.GroupEvent;
/*     */ import com.jivesoftware.base.event.GroupEventDispatcher;
/*     */ import com.jivesoftware.base.event.GroupListener;
/*     */ import com.jivesoftware.base.event.PollEvent;
/*     */ import com.jivesoftware.base.event.PollEventDispatcher;
/*     */ import com.jivesoftware.base.event.PollListener;
/*     */ import com.jivesoftware.base.event.UserEvent;
/*     */ import com.jivesoftware.base.event.UserEventDispatcher;
/*     */ import com.jivesoftware.base.event.UserListener;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DebugEventListener
/*     */   implements CategoryListener, ForumListener, ThreadListener, MessageListener, UserListener, GroupListener, PrivateMessageListener, PollListener
/*     */ {
/*     */   public DebugEventListener()
/*     */   {
/*  30 */     CategoryEventDispatcher.getInstance().addListener(this);
/*  31 */     ForumEventDispatcher.getInstance().addListener(this);
/*  32 */     ThreadEventDispatcher.getInstance().addListener(this);
/*  33 */     MessageEventDispatcher.getInstance().addListener(this);
/*  34 */     PrivateMessageEventDispatcher.getInstance().addListener(this);
/*  35 */     UserEventDispatcher.getInstance().addListener(this);
/*  36 */     GroupEventDispatcher.getInstance().addListener(this);
/*  37 */     PollEventDispatcher.getInstance().addListener(this);
/*     */   }
/*     */ 
/*     */   public void categoryAdded(CategoryEvent event)
/*     */   {
/*  43 */     Log.debug("* Category added: " + event.getCategory() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void categoryDeleted(CategoryEvent event) {
/*  47 */     Log.debug("* Category deleted: " + event.getCategory() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void categoryMoved(CategoryEvent event) {
/*  51 */     Log.debug("* Category moved: " + event.getCategory() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void forumAdded(ForumEvent event)
/*     */   {
/*  57 */     Log.debug("* Forum added: " + event.getForum() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void forumDeleted(ForumEvent event) {
/*  61 */     Log.debug("* Forum deleted: " + event.getForum() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void forumMoved(ForumEvent event) {
/*  65 */     Log.debug("* Forum moved: " + event.getForum() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void forumMerged(ForumEvent event) {
/*  69 */     Log.debug("* Forum merged: " + event.getForum() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void threadAdded(ThreadEvent event)
/*     */   {
/*  75 */     Log.debug("* Thread added: " + event.getThread() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void threadDeleted(ThreadEvent event) {
/*  79 */     Log.debug("* Thread deleted: " + event.getThread() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void threadMoved(ThreadEvent event) {
/*  83 */     Log.debug("* Thread moved: " + event.getThread() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void threadModerationModified(ThreadEvent event) {
/*  87 */     Log.debug("* Thread moderation modifed: " + event.getThread() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void threadRated(ThreadEvent event) {
/*  91 */     Log.debug("* Thread rated: " + event.getThread() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void messageAdded(MessageEvent event)
/*     */   {
/*  97 */     Log.debug("* Message added: " + event.getMessage() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void messageDeleted(MessageEvent event) {
/* 101 */     Log.debug("* Message deleted: " + event.getMessage() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void messageModified(MessageEvent event) {
/* 105 */     Log.debug("* Message modified: " + event.getMessage() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void messageModerationModified(MessageEvent event) {
/* 109 */     Log.debug("* Message moderation modified: " + event.getMessage() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void messageRated(MessageEvent event) {
/* 113 */     Log.debug("* Message rated: " + event.getMessage() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void messageMoved(MessageEvent event) {
/* 117 */     Log.debug("* Message moved: " + event.getMessage() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void privateMessageSent(PrivateMessageEvent event)
/*     */   {
/* 123 */     Log.debug("* Private message sent: " + event.getPrivateMessage() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void userCreated(UserEvent event)
/*     */   {
/* 130 */     Log.debug("* User created: " + event.getUser() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void userDeleted(UserEvent event) {
/* 134 */     Log.debug("* User deleted: " + event.getUser() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void userModified(UserEvent event) {
/* 138 */     Log.debug("* User modified: " + event.getUser() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void groupCreated(GroupEvent event)
/*     */   {
/* 144 */     Log.debug("* Group created: " + event.getGroup() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void groupDeleted(GroupEvent event) {
/* 148 */     Log.debug("* Group deleted: " + event.getGroup() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void groupUserAdded(GroupEvent event) {
/* 152 */     Log.debug("* User added to group: " + event.getGroup() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void groupUserDeleted(GroupEvent event) {
/* 156 */     Log.debug("* User removed from group: " + event.getGroup() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void groupAdministratorAdded(GroupEvent event) {
/* 160 */     Log.debug("* Admin added to group: " + event.getGroup() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void groupAdministratorDeleted(GroupEvent event) {
/* 164 */     Log.debug("* Admin removed from group:" + event.getGroup() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void groupModified(GroupEvent event) {
/* 168 */     Log.debug("* Group modified: " + event.getGroup() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void pollCreated(PollEvent event)
/*     */   {
/* 174 */     Log.debug("* Poll created: " + event.getPoll() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void pollDeleted(PollEvent event) {
/* 178 */     Log.debug("* Poll deleted: " + event.getPoll() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void voteAdded(PollEvent event) {
/* 182 */     Log.debug("* Poll voted added: " + event.getPoll() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void anonymousVoteAdded(PollEvent event) {
/* 186 */     Log.debug("* Anonymous poll vote addec: " + event.getPoll() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void voteModified(PollEvent event) {
/* 190 */     Log.debug("* Poll vote modifed: " + event.getPoll() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void anonymousVoteModified(PollEvent event) {
/* 194 */     Log.debug("* Anonymous poll voted modified: " + event.getPoll() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void voteRemoved(PollEvent event) {
/* 198 */     Log.debug("* Poll voted removed: " + event.getPoll() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   public void anonymousVoteRemoved(PollEvent event) {
/* 202 */     Log.debug("* Anonymous poll vote removed: " + event.getPoll() + getParamsString(event.getParams()));
/*     */   }
/*     */ 
/*     */   private String getParamsString(Map params) {
/* 206 */     if (params.isEmpty()) {
/* 207 */       return "";
/*     */     }
/* 209 */     StringBuffer buf = new StringBuffer("\n  -- Parameters:");
/* 210 */     for (Iterator i = params.keySet().iterator(); i.hasNext(); ) {
/* 211 */       String key = (String)i.next();
/* 212 */       String value = params.get(key).toString();
/* 213 */       buf.append("\n    ").append(key).append(", ").append(value).append("");
/*     */     }
/* 215 */     return buf.toString();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.DebugEventListener
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.nntp.spi;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.forum.database.DbForumMessage;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class ArticleIterator
/*     */   implements Iterator
/*     */ {
/*  29 */   private static DbForumFactory factory = DbForumFactory.getInstance();
/*     */   private int pointer;
/*     */   private int endIndex;
/*     */   private long forumID;
/*     */ 
/*     */   public ArticleIterator(int start, int end, long forumID)
/*     */   {
/*  43 */     this.pointer = start;
/*  44 */     this.endIndex = end;
/*  45 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public boolean hasNext() {
/*  49 */     boolean hasNext = false;
/*     */ 
/*  51 */     if (this.pointer <= this.endIndex)
/*     */     {
/*  54 */       long messageID = factory.getMessageID(this.forumID, this.pointer);
/*  55 */       while ((messageID == -1L) && (this.pointer < this.endIndex)) {
/*  56 */         this.pointer += 1;
/*  57 */         messageID = factory.getMessageID(this.forumID, this.pointer);
/*     */       }
/*     */ 
/*  60 */       if (messageID != -1L) {
/*  61 */         hasNext = true;
/*     */       }
/*     */     }
/*  64 */     return hasNext;
/*     */   }
/*     */ 
/*     */   public Object next() {
/*  68 */     Object next = null;
/*     */ 
/*  70 */     if (this.pointer > this.endIndex) {
/*  71 */       throw new NoSuchElementException();
/*     */     }
/*     */ 
/*  75 */     long messageID = factory.getMessageID(this.forumID, this.pointer);
/*  76 */     while ((messageID == -1L) && (this.pointer < this.endIndex)) {
/*  77 */       this.pointer += 1;
/*  78 */       messageID = factory.getMessageID(this.forumID, this.pointer);
/*     */     }
/*     */ 
/*  81 */     if (messageID == -1L) {
/*  82 */       throw new NoSuchElementException();
/*     */     }
/*     */ 
/*  85 */     this.pointer += 1;
/*     */     try {
/*  87 */       DbForumMessage msg = (DbForumMessage)factory.getMessage(messageID);
/*  88 */       next = new FMessageArticleAdapter(msg);
/*     */     }
/*     */     catch (ForumMessageNotFoundException fe) {
/*  91 */       Log.error(fe);
/*     */ 
/*  93 */       next = next();
/*     */     }
/*     */ 
/*  96 */     return next;
/*     */   }
/*     */ 
/*     */   public void remove() {
/* 100 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.ArticleIterator
 * JD-Core Version:    0.6.2
 */
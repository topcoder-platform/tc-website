/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.base.action.util.RedirectAction;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.Watch;
/*     */ import com.jivesoftware.forum.WatchManager;
/*     */ import com.opensymphony.webwork.ServletActionContext;
/*     */ 
/*     */ public class WatchesAction extends ForumActionSupport
/*     */ {
/*  26 */   private long categoryID = -1L;
/*  27 */   private long forumID = -1L;
/*  28 */   private long threadID = -1L;
/*  29 */   private long userID = -1L;
/*     */   private ForumCategory category;
/*     */   private Forum forum;
/*     */   private ForumThread thread;
/*     */   private User user;
/*     */   private WatchManager manager;
/*     */ 
/*     */   public long getCategoryID()
/*     */   {
/*  42 */     return this.categoryID;
/*     */   }
/*     */ 
/*     */   public void setCategoryID(long categoryID) {
/*  46 */     this.categoryID = categoryID;
/*     */   }
/*     */ 
/*     */   public long getForumID() {
/*  50 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID) {
/*  54 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public long getThreadID() {
/*  58 */     return this.threadID;
/*     */   }
/*     */ 
/*     */   public void setThreadID(long threadID) {
/*  62 */     this.threadID = threadID;
/*     */   }
/*     */ 
/*     */   public long getUserID() {
/*  66 */     return this.userID;
/*     */   }
/*     */ 
/*     */   public void setUserID(long userID) {
/*  70 */     this.userID = userID;
/*     */   }
/*     */ 
/*     */   public String doAdd()
/*     */   {
/*     */     try
/*     */     {
/*  81 */       if (!loadJiveObjects())
/*  82 */         return "error";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/*  86 */       setLoginAttributes();
/*  87 */       addActionError(getText("watches.error_unauth"));
/*  88 */       return "login";
/*     */     }
/*     */ 
/*  92 */     if (getPageUser() == null) {
/*  93 */       setLoginAttributes();
/*  94 */       addActionError(getText("error.permission"));
/*  95 */       return "login";
/*     */     }
/*     */     try
/*     */     {
/*  99 */       if (this.user != null) {
/* 100 */         if (!this.manager.isWatched(getPageUser(), this.user))
/*     */         {
/* 102 */           this.manager.createWatch(getPageUser(), this.user);
/*     */         }
/*     */       }
/* 105 */       else if (this.thread != null) {
/* 106 */         if (!this.manager.isWatched(getPageUser(), this.thread))
/*     */         {
/* 108 */           this.manager.createWatch(getPageUser(), this.thread);
/*     */         }
/*     */       }
/* 111 */       else if (this.forum != null) {
/* 112 */         if (!this.manager.isWatched(getPageUser(), this.forum))
/*     */         {
/* 114 */           this.manager.createWatch(getPageUser(), this.forum);
/*     */         }
/*     */       }
/* 117 */       else if (this.category != null) {
/* 118 */         if (!this.manager.isWatched(getPageUser(), this.category))
/*     */         {
/* 120 */           this.manager.createWatch(getPageUser(), this.category);
/*     */         }
/*     */       }
/*     */       else {
/* 124 */         addActionError(getText("watches.error_no_target_object"));
/* 125 */         return "error";
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 129 */       setLoginAttributes();
/* 130 */       addActionError(ue.getMessage());
/* 131 */       return "login";
/*     */     }
/*     */ 
/* 135 */     if (this.user != null) {
/* 136 */       return "useraddsuccess";
/*     */     }
/* 138 */     if ((this.thread != null) && (this.forum != null)) {
/* 139 */       return "threadaddsuccess";
/*     */     }
/* 141 */     if (this.forum != null) {
/* 142 */       return "forumaddsuccess";
/*     */     }
/*     */ 
/* 145 */     return "categoryaddsuccess";
/*     */   }
/*     */ 
/*     */   public String doRemove()
/*     */   {
/*     */     try {
/* 151 */       if (!loadJiveObjects())
/* 152 */         return "error";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 156 */       setLoginAttributes();
/* 157 */       addActionError(getText("watches.error_unauth"));
/* 158 */       return "login";
/*     */     }
/*     */ 
/* 162 */     if (getPageUser() == null) {
/* 163 */       setLoginAttributes();
/* 164 */       addActionError(getText("error.permission"));
/* 165 */       return "login";
/*     */     }
/*     */     try
/*     */     {
/* 169 */       if (this.user != null)
/*     */       {
/* 171 */         Watch watch = this.manager.getWatch(getPageUser(), this.user);
/* 172 */         this.manager.deleteWatch(watch);
/* 173 */         RedirectAction.pushPreviousURL(ServletActionContext.getRequest());
/*     */       }
/* 175 */       else if (this.thread != null)
/*     */       {
/* 177 */         Watch watch = this.manager.getWatch(getPageUser(), this.thread);
/* 178 */         this.manager.deleteWatch(watch);
/*     */       }
/* 180 */       else if (this.forum != null)
/*     */       {
/* 182 */         Watch watch = this.manager.getWatch(getPageUser(), this.forum);
/* 183 */         this.manager.deleteWatch(watch);
/*     */       }
/* 185 */       else if (this.category != null)
/*     */       {
/* 187 */         Watch watch = this.manager.getWatch(getPageUser(), this.category);
/* 188 */         this.manager.deleteWatch(watch);
/*     */       }
/*     */       else {
/* 191 */         addActionError("No target object (category, forum, thread) watch to delete.");
/* 192 */         return "error";
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 196 */       addActionError(ue.getMessage());
/* 197 */       return "login";
/*     */     }
/*     */ 
/* 201 */     if (this.user != null) {
/* 202 */       return "userremovesuccess";
/*     */     }
/* 204 */     if ((this.thread != null) && (this.forum != null)) {
/* 205 */       return "threadremovesuccess";
/*     */     }
/* 207 */     if (this.forum != null) {
/* 208 */       return "forumremovesuccess";
/*     */     }
/*     */ 
/* 211 */     return "categoryremovesuccess";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 219 */     return "success";
/*     */   }
/*     */ 
/*     */   protected boolean loadJiveObjects()
/*     */     throws UnauthorizedException
/*     */   {
/* 225 */     boolean success = true;
/* 226 */     this.manager = getForumFactory().getWatchManager();
/* 227 */     if ((this.categoryID > -1L) && (this.category == null)) {
/*     */       try {
/* 229 */         this.category = getForumFactory().getForumCategory(this.categoryID);
/* 230 */         this.categoryID = this.category.getID();
/*     */       }
/*     */       catch (ForumCategoryNotFoundException fcnfe) {
/* 233 */         addActionError(fcnfe.getMessage());
/* 234 */         success = false;
/*     */       }
/*     */     }
/* 237 */     else if ((this.forumID > -1L) && (this.forum == null)) {
/*     */       try {
/* 239 */         this.forum = getForumFactory().getForum(this.forumID);
/* 240 */         this.forumID = this.forum.getID();
/*     */       }
/*     */       catch (ForumNotFoundException fnfe) {
/* 243 */         addActionError(fnfe.getMessage());
/* 244 */         success = false;
/*     */       }
/*     */     }
/*     */ 
/* 248 */     if ((this.threadID > -1L) && (this.thread == null)) {
/* 249 */       if (this.forum == null) {
/* 250 */         addActionError(getText("watches.error_no_target_object"));
/* 251 */         success = false;
/*     */       }
/*     */       else {
/*     */         try {
/* 255 */           this.thread = this.forum.getThread(this.threadID);
/*     */         }
/*     */         catch (ForumThreadNotFoundException ftnfe) {
/* 258 */           addActionError(ftnfe.getMessage());
/* 259 */           success = false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 264 */     if ((this.userID != -1L) && (this.user == null)) {
/*     */       try {
/* 266 */         this.user = getForumFactory().getUserManager().getUser(this.userID);
/* 267 */         success = true;
/*     */       }
/*     */       catch (UserNotFoundException unfe) {
/* 270 */         addActionError(unfe.getMessage());
/*     */       }
/*     */     }
/* 273 */     return success;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.WatchesAction
 * JD-Core Version:    0.6.2
 */
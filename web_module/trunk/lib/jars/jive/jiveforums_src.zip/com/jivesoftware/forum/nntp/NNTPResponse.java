package com.jivesoftware.forum.nntp;

import com.jivesoftware.forum.net.Connection;
import java.io.IOException;

public abstract interface NNTPResponse
{
  public static final String ENDLINE = "\r\n";
  public static final String DOT_TERMINATOR = ".\r\n";

  public abstract int getValue();

  public abstract void send(Connection paramConnection)
    throws IOException;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NNTPResponse
 * JD-Core Version:    0.6.2
 */
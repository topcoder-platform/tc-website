/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Element;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.Report.ExtraInfo;
/*     */ import com.jivesoftware.base.stats.bin.DateSequence;
/*     */ import com.jivesoftware.base.stats.element.DateElement;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.base.stats.util.DateFormatter;
/*     */ import com.jivesoftware.base.stats.util.DecimalFormatter;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class HTTPPageViewsReport extends AbstractForumReport
/*     */ {
/*     */   private static final String VIEWS_BY_DATE = "SELECT rs.creationDate FROM jiveReadStat rs, jiveHTTPReadStatSession hrs WHERE rs.sessionID=hrs.sessionID AND rs.creationDate >= ? AND rs.creationDate < ?";
/*     */   private static final String VIEWS_BY_DATE_AND_FORUM = "SELECT rs.creationDate FROM jiveReadStat rs, jiveHTTPReadStatSession hrs WHERE rs.sessionID=hrs.sessionID AND rs.creationDate >= ? AND rs.creationDate < ? AND rs.objectType = 0 AND rs.objectID = ?";
/*  48 */   private long stepSize = 24L;
/*     */ 
/*     */   public long getStepSize()
/*     */   {
/*  54 */     return this.stepSize;
/*     */   }
/*     */ 
/*     */   public void setStepSize(long stepSize) {
/*  58 */     this.stepSize = stepSize;
/*     */   }
/*     */ 
/*     */   public void execute() throws Exception {
/*  62 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  63 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  66 */     Histogram hist = new Histogram(new DateSequence(start, getStepSize() * 60L * 60L * 1000L));
/*  67 */     addHistogram(hist);
/*     */ 
/*  69 */     Connection con = null;
/*  70 */     PreparedStatement pstmt = null;
/*  71 */     ResultSet rs = null;
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/*  76 */         con = ConnectionManager.getConnection();
/*  77 */         pstmt = con.prepareStatement("SELECT rs.creationDate FROM jiveReadStat rs, jiveHTTPReadStatSession hrs WHERE rs.sessionID=hrs.sessionID AND rs.creationDate >= ? AND rs.creationDate < ?");
/*  78 */         pstmt.setLong(1, start.getTime());
/*  79 */         pstmt.setLong(2, end.getTime());
/*  80 */         rs = pstmt.executeQuery();
/*     */ 
/*  82 */         while (rs.next()) {
/*  83 */           hist.add(new DateElement(new Date(rs.getLong(1))));
/*     */         }
/*  85 */         rs.close();
/*  86 */         pstmt.close();
/*     */       }
/*     */       catch (SQLException sqle)
/*     */       {
/*     */       }
/*     */ 
/*  94 */       List forums = getObjects();
/*  95 */       for (iter = forums.iterator(); iter.hasNext(); ) {
/*  96 */         Forum forum = (Forum)iter.next();
/*  97 */         long forumID = forum.getID();
/*  98 */         hist = new Histogram(new DateSequence(start, getStepSize() * 60L * 60L * 1000L));
/*  99 */         addHistogram(hist);
/*     */         try {
/* 101 */           pstmt = con.prepareStatement("SELECT rs.creationDate FROM jiveReadStat rs, jiveHTTPReadStatSession hrs WHERE rs.sessionID=hrs.sessionID AND rs.creationDate >= ? AND rs.creationDate < ? AND rs.objectType = 0 AND rs.objectID = ?");
/* 102 */           pstmt.setLong(1, start.getTime());
/* 103 */           pstmt.setLong(2, end.getTime());
/* 104 */           pstmt.setLong(3, forumID);
/* 105 */           rs = pstmt.executeQuery();
/*     */ 
/* 107 */           while (rs.next()) {
/* 108 */             hist.add(new DateElement(new Date(rs.getLong(1))));
/*     */           }
/* 110 */           rs.close();
/* 111 */           pstmt.close();
/*     */         }
/*     */         catch (SQLException sqle)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       Iterator iter;
/* 119 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/* 124 */     Histogram[] histograms = getHistograms();
/* 125 */     if (histograms.length == 0) {
/* 126 */       return new DataTable[0];
/*     */     }
/* 128 */     List tables = new ArrayList(histograms.length);
/* 129 */     for (int i = 0; i < histograms.length; i++) {
/* 130 */       Histogram hist = histograms[i];
/* 131 */       DataTable data = new DataTable(getName());
/* 132 */       data.setColumns(new String[] { "Day", "Views" });
/* 133 */       Bin[] bins = hist.getBins();
/* 134 */       for (int j = 0; j < bins.length; j++) {
/* 135 */         Bin bin = bins[j];
/* 136 */         String week = DateFormatter.format("M/dd/yyyy", new Date(bin.getBegin().toLong().longValue()));
/*     */ 
/* 138 */         long count = hist.getCount(bin);
/* 139 */         data.addRow(new Object[] { week, new Long(count) });
/*     */       }
/* 141 */       tables.add(data);
/*     */     }
/* 143 */     return (DataTable[])tables.toArray(new DataTable[0]);
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 147 */     Histogram[] histograms = getHistograms();
/* 148 */     Chart[] charts = new Chart[histograms.length];
/* 149 */     List forums = getObjects();
/* 150 */     for (int i = 0; i < histograms.length; i++) {
/* 151 */       Histogram hist = histograms[i];
/* 152 */       String name = getName();
/* 153 */       if (i == 0) {
/* 154 */         name = name + " - All forums";
/*     */       }
/*     */       else {
/* 157 */         name = name + " - " + forums.get(i - 1);
/*     */       }
/* 159 */       Chart chart = new Chart(name);
/* 160 */       chart.setXaxisLabel("Dates");
/* 161 */       chart.setYaxisLabel("New Users");
/* 162 */       chart.setType(2);
/* 163 */       Bin[] bins = hist.getBins();
/* 164 */       String[] labels = new String[bins.length];
/* 165 */       for (int j = 0; j < bins.length; j++) {
/* 166 */         Bin bin = bins[j];
/* 167 */         Date begin = new Date(bin.getBegin().toLong().longValue());
/* 168 */         Date end = new Date(bin.getEnd().toLong().longValue());
/* 169 */         Date mid = new Date((begin.getTime() + end.getTime()) / 2L);
/* 170 */         labels[j] = DateFormatter.format("M/dd/yy", mid);
/*     */       }
/* 172 */       chart.setLabels(labels);
/* 173 */       charts[i] = chart;
/*     */     }
/* 175 */     return charts;
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 179 */     Histogram[] histograms = getHistograms();
/* 180 */     if (histograms.length == 0) {
/* 181 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/* 183 */     List lists = new ArrayList(histograms.length);
/*     */ 
/* 185 */     for (int i = 0; i < histograms.length; i++) {
/* 186 */       List extraInfo = new ArrayList(3);
/* 187 */       Histogram hist = histograms[i];
/* 188 */       double meanElement = hist.getMeanCount();
/* 189 */       double sumCount = hist.getSumCount();
/*     */ 
/* 192 */       extraInfo.add(getDateRange());
/*     */ 
/* 194 */       extraInfo.add(new Report.ExtraInfo("Total Page Views", DecimalFormatter.format("#,##0", new Double(sumCount).doubleValue())));
/*     */ 
/* 197 */       extraInfo.add(new Report.ExtraInfo("Average Views Per Day", DecimalFormatter.format("#.0", new Double(meanElement).doubleValue())));
/*     */ 
/* 199 */       lists.add(extraInfo);
/*     */     }
/* 201 */     return (List[])lists.toArray(new List[0]);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.HTTPPageViewsReport
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.interceptor;
/*    */ 
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.forum.ForumMessage;
/*    */ import com.jivesoftware.forum.MessageInterceptor;
/*    */ import com.jivesoftware.forum.MessageRejectedException;
/*    */ import com.jivesoftware.forum.virusscan.VirusScanManager;
/*    */ 
/*    */ public class VirusScanInterceptor
/*    */   implements MessageInterceptor
/*    */ {
/* 39 */   public static int VIRUS_CHECK_MODERATION_VALUE = -156;
/*    */   private static final String ORIGINAL_MODERATION_VALUE = "virusscan.original_mod";
/*    */ 
/*    */   public VirusScanInterceptor()
/*    */   {
/*    */   }
/*    */ 
/*    */   public VirusScanInterceptor(int objectType, long objectID)
/*    */   {
/*    */   }
/*    */ 
/*    */   public int getType()
/*    */   {
/* 52 */     return 1;
/*    */   }
/*    */ 
/*    */   public void invokeInterceptor(ForumMessage message, int type) throws MessageRejectedException
/*    */   {
/* 57 */     if (message.getAttachmentCount() < 1) {
/* 58 */       return;
/*    */     }
/*    */ 
/*    */     try
/*    */     {
/* 63 */       int modValue = message.getModerationValue();
/* 64 */       message.setProperty("virusscan.original_mod", String.valueOf(modValue));
/* 65 */       message.setModerationValue(VIRUS_CHECK_MODERATION_VALUE, null);
/* 66 */       if (VirusScanManager.getInstance().isVirusScanEnabled())
/*    */       {
/*    */         try {
/* 69 */           VirusScanManager.getInstance().addMessageToQueue(message);
/*    */         } catch (Exception e) {
/* 71 */           Log.error("Unable to add message " + message.getID() + " to virus scan queue.", e);
/*    */         }
/*    */ 
/* 74 */         if (Log.isDebugEnabled())
/* 75 */           Log.debug("Message " + message.getID() + " added to virus scanner queue.");
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 79 */       Log.error(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.VirusScanInterceptor
 * JD-Core Version:    0.6.2
 */
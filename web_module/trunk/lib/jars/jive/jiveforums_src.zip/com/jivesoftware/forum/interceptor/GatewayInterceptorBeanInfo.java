/*    */ package com.jivesoftware.forum.interceptor;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class GatewayInterceptorBeanInfo extends JiveBeanInfo
/*    */ {
/* 21 */   public static final String[] PROPERTY_NAMES = { "hideName", "hideEmail", "storeNameAsProp", "storeEmailAsProp", "nameProp", "emailProp" };
/*    */ 
/*    */   public Class getBeanClass()
/*    */   {
/* 30 */     return GatewayInterceptor.class;
/*    */   }
/*    */ 
/*    */   public String[] getPropertyNames() {
/* 34 */     return PROPERTY_NAMES;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 38 */     return "GatewayInterceptor";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.GatewayInterceptorBeanInfo
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.AuthFactory;
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.base.User;
/*    */ import com.jivesoftware.base.UserManager;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.util.LocaleUtils;
/*    */ import com.opensymphony.xwork.ActionContext;
/*    */ import com.opensymphony.xwork.ActionInvocation;
/*    */ import com.opensymphony.xwork.interceptor.AroundInterceptor;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class UserLocaleInterceptor extends AroundInterceptor
/*    */ {
/*    */   protected void after(ActionInvocation dispatcher, String result)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   protected void before(ActionInvocation invocation)
/*    */     throws Exception
/*    */   {
/* 34 */     ActionContext ctx = invocation.getInvocationContext();
/* 35 */     HttpServletRequest req = (HttpServletRequest)ctx.get("com.opensymphony.xwork.dispatcher.HttpServletRequest");
/* 36 */     HttpServletResponse res = (HttpServletResponse)ctx.get("com.opensymphony.xwork.dispatcher.HttpServletResponse");
/*    */     try {
/* 38 */       AuthToken authToken = AuthFactory.getAuthToken(req, res);
/* 39 */       if ((authToken != null) && (!authToken.isAnonymous())) {
/* 40 */         User user = ForumFactory.getInstance(authToken).getUserManager().getUser(authToken.getUserID());
/* 41 */         ctx.setLocale(LocaleUtils.getUserLocale(req, user));
/*    */       }
/*    */       else
/*    */       {
/* 45 */         ctx.setLocale(LocaleUtils.getUserLocale(req, null));
/*    */       }
/*    */     }
/*    */     catch (UnauthorizedException e) {
/* 49 */       ctx.setLocale(LocaleUtils.getUserLocale(req, null));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.UserLocaleInterceptor
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.filter;
/*     */ 
/*     */ import com.jivesoftware.base.Filter;
/*     */ import com.jivesoftware.base.FilterChain;
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.forum.database.DbForumMessage;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.Node;
/*     */ import org.dom4j.io.XPP3Reader;
/*     */ 
/*     */ public class JIRAFilter
/*     */   implements Filter
/*     */ {
/*  29 */   private List patterns = new ArrayList();
/*     */ 
/*  31 */   private String projectNames = null;
/*  32 */   private String jiraInstance = "";
/*  33 */   private boolean openWindow = true;
/*  34 */   private String username = null;
/*  35 */   private String password = null;
/*  36 */   private boolean trackbackEnabled = false;
/*     */ 
/*     */   public JIRAFilter()
/*     */   {
/*  43 */     long filterExpiration = DbForumMessage.getFilterExpiration();
/*  44 */     if ((filterExpiration < 0L) || (filterExpiration > 1800000L))
/*  45 */       DbForumMessage.setFilterExpiration(1800000L);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  50 */     return "JIRAFilter";
/*     */   }
/*     */ 
/*     */   public String applyFilter(String string, int currentIndex, FilterChain filterChain) {
/*  54 */     if ((string == null) || (string.length() == 0)) {
/*  55 */       return string;
/*     */     }
/*     */ 
/*  58 */     int length = string.length();
/*  59 */     StringBuffer filtered = new StringBuffer((int)(length * 1.5D));
/*  60 */     filtered.append(string);
/*     */ 
/*  63 */     for (Iterator i = this.patterns.iterator(); i.hasNext(); ) {
/*  64 */       string = filtered.toString();
/*  65 */       filtered.delete(0, filtered.length());
/*  66 */       Pattern pattern = (Pattern)i.next();
/*  67 */       Matcher matcher = pattern.matcher(string.subSequence(0, string.length()));
/*  68 */       while (matcher.find()) {
/*  69 */         String issueID = matcher.group();
/*  70 */         matcher.appendReplacement(filtered, getIssueHTML(issueID));
/*     */ 
/*  73 */         doTrackback(filterChain, issueID);
/*     */       }
/*  75 */       matcher.appendTail(filtered);
/*     */     }
/*     */ 
/*  78 */     return filterChain.applyFilters(currentIndex, filtered.toString());
/*     */   }
/*     */ 
/*     */   public String getProjectNames()
/*     */   {
/*  87 */     return this.projectNames;
/*     */   }
/*     */ 
/*     */   public void setProjectNames(String projectNames)
/*     */   {
/*  96 */     this.projectNames = projectNames;
/*  97 */     this.patterns.clear();
/*     */ 
/*  99 */     if ((this.projectNames == null) || (this.projectNames.equals(""))) {
/* 100 */       return;
/*     */     }
/*     */ 
/* 103 */     StringTokenizer tokens = new StringTokenizer(this.projectNames, ",");
/* 104 */     while (tokens.hasMoreTokens()) {
/* 105 */       String name = tokens.nextToken().trim();
/*     */ 
/* 107 */       this.patterns.add(Pattern.compile(name + "-[0-9]*"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getJiraInstance()
/*     */   {
/* 117 */     return this.jiraInstance;
/*     */   }
/*     */ 
/*     */   public void setJiraInstance(String jiraInstance)
/*     */   {
/* 126 */     if (!jiraInstance.endsWith("/")) {
/* 127 */       jiraInstance = jiraInstance + "/";
/*     */     }
/* 129 */     this.jiraInstance = jiraInstance;
/*     */   }
/*     */ 
/*     */   public boolean isOpenWindow()
/*     */   {
/* 138 */     return this.openWindow;
/*     */   }
/*     */ 
/*     */   public void setOpenWindow(boolean openWindow)
/*     */   {
/* 147 */     this.openWindow = openWindow;
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 157 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 167 */     this.username = username;
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 177 */     return this.password;
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 187 */     this.password = password;
/*     */   }
/*     */ 
/*     */   public boolean isTrackbackEnabled()
/*     */   {
/* 197 */     return this.trackbackEnabled;
/*     */   }
/*     */ 
/*     */   public void setTrackbackEnabled(boolean trackbackEnabled)
/*     */   {
/* 207 */     this.trackbackEnabled = trackbackEnabled;
/*     */   }
/*     */ 
/*     */   private String getIssueHTML(String issueID)
/*     */   {
/*     */     try
/*     */     {
/* 219 */       String URL = getJiraInstance() + "browse/" + issueID + "?decorator=none&view=rss";
/* 220 */       XPP3Reader reader = new XPP3Reader();
/* 221 */       Document document = reader.read(URL);
/*     */ 
/* 223 */       String title = document.selectSingleNode("/rss/channel/item/title").getText();
/* 224 */       String status = document.selectSingleNode("/rss/channel/item/status").getText();
/* 225 */       String type = document.selectSingleNode("/rss/channel/item/type").getText();
/* 226 */       String resolution = document.selectSingleNode("/rss/channel/item/resolution").getText();
/*     */ 
/* 228 */       StringBuffer html = new StringBuffer();
/* 229 */       html.append("<img src=\"").append(getJiraInstance());
/*     */ 
/* 231 */       boolean closed = false;
/* 232 */       if (status.equals("Closed")) {
/* 233 */         closed = true;
/*     */       }
/* 235 */       else if (status.equals("Resolved")) {
/* 236 */         closed = true;
/*     */       }
/*     */ 
/* 241 */       String imgURL = "images/icons/genericissue.gif";
/* 242 */       if (type.equals("Bug")) {
/* 243 */         imgURL = "images/icons/bug.gif";
/*     */       }
/* 245 */       else if (type.equals("Improvement")) {
/* 246 */         imgURL = "images/icons/improvement.gif";
/*     */       }
/* 248 */       else if (type.equals("New Feature")) {
/* 249 */         imgURL = "images/icons/newfeature.gif";
/*     */       }
/* 251 */       else if (type.equals("Task")) {
/* 252 */         imgURL = "images/icons/task.gif";
/*     */       }
/*     */ 
/* 255 */       html.append(imgURL).append("\" title=\"").append(type).append("-- ");
/* 256 */       html.append(status).append(": ").append(resolution).append("\"");
/* 257 */       html.append(" width=\"16\" height=\"16\"");
/* 258 */       html.append(">");
/* 259 */       html.append(" <a href=\"");
/* 260 */       html.append(this.jiraInstance);
/* 261 */       html.append("browse/").append("$0");
/* 262 */       if (this.openWindow) {
/* 263 */         html.append("\" target=\"_blank");
/*     */       }
/* 265 */       html.append("\">");
/* 266 */       html.append("<span title=\"").append(title);
/* 267 */       html.append("\">");
/* 268 */       if (closed) {
/* 269 */         html.append("<strike>$0</strike>");
/*     */       }
/*     */       else {
/* 272 */         html.append("$0");
/*     */       }
/* 274 */       html.append("</span>");
/* 275 */       html.append("</a>");
/*     */ 
/* 277 */       return html.toString();
/*     */     }
/*     */     catch (Exception e) {
/* 280 */       Log.error(e);
/*     */     }
/* 282 */     return issueID;
/*     */   }
/*     */ 
/*     */   private void doTrackback(FilterChain filterChain, String issueID)
/*     */   {
/* 287 */     if (this.trackbackEnabled) {
/* 288 */       String jiveURL = JiveGlobals.getJiveProperty("jiveURL");
/*     */ 
/* 290 */       if (jiveURL == null) {
/* 291 */         return;
/*     */       }
/* 293 */       if (!jiveURL.endsWith("/")) {
/* 294 */         jiveURL = jiveURL + "/";
/*     */       }
/* 296 */       if ((filterChain.getSourceObject() instanceof DbForumMessage)) {
/* 297 */         DbForumMessage message = (DbForumMessage)filterChain.getSourceObject();
/* 298 */         String jiraTrackback = message.getProperty("JIRATrackback");
/* 299 */         if (jiraTrackback == null) {
/* 300 */           jiraTrackback = "";
/*     */         }
/*     */ 
/* 305 */         if (jiraTrackback.indexOf(issueID + ",") == -1)
/*     */           try {
/* 307 */             StringBuffer trackbackURL = new StringBuffer();
/* 308 */             trackbackURL.append(this.jiraInstance).append("rpc/trackback/").append(issueID);
/*     */ 
/* 310 */             StringBuffer trackbackParams = new StringBuffer();
/* 311 */             trackbackParams.append("title=").append(URLEncoder.encode(message.getSubject(), "UTF-8"));
/* 312 */             trackbackParams.append("&url=").append(jiveURL).append("thread.jspa?messageID=").append(message.getID()).append("#").append(message.getID());
/*     */ 
/* 315 */             HttpURLConnection trackbackUrlConnection = (HttpURLConnection)new URL(trackbackURL.toString()).openConnection();
/*     */ 
/* 317 */             trackbackUrlConnection.setRequestMethod("POST");
/* 318 */             trackbackUrlConnection.setRequestProperty("Content-Encoding", "UTF-8");
/* 319 */             trackbackUrlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
/* 320 */             trackbackUrlConnection.setRequestProperty("Content-Length", "" + trackbackParams.length());
/* 321 */             trackbackUrlConnection.setDoOutput(true);
/* 322 */             trackbackUrlConnection.getOutputStream().write(trackbackParams.toString().getBytes("UTF-8"));
/* 323 */             trackbackUrlConnection.connect();
/* 324 */             BufferedReader trackbackStatus = new BufferedReader(new InputStreamReader(trackbackUrlConnection.getInputStream()));
/*     */ 
/* 327 */             StringBuffer status = new StringBuffer();
/*     */             String line;
/* 328 */             while ((line = trackbackStatus.readLine()) != null) {
/* 329 */               status.append(line).append("\n");
/*     */             }
/*     */ 
/* 334 */             jiraTrackback = jiraTrackback + issueID + ",";
/* 335 */             message.setProperty("JIRATrackback", jiraTrackback);
/*     */           }
/*     */           catch (Exception e) {
/* 338 */             Log.error(e);
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.filter.JIRAFilter
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.Query;
/*     */ import com.jivesoftware.forum.QueryLogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class QueryLoggerProxy
/*     */   implements QueryLogger
/*     */ {
/*     */   private QueryLogger queryLogger;
/*     */   private AuthToken auth;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public QueryLoggerProxy(QueryLogger queryLogger, AuthToken auth, Permissions permissions)
/*     */   {
/*  42 */     this.queryLogger = queryLogger;
/*  43 */     this.auth = auth;
/*  44 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public int getQueryCount() throws UnauthorizedException {
/*  48 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  49 */       return this.queryLogger.getQueryCount();
/*     */     }
/*     */ 
/*  52 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getQueryCount(User user) throws UnauthorizedException
/*     */   {
/*  57 */     if (((user != null) && (this.auth.getUserID() == user.getID())) || (this.permissions.hasPermission(576460752303423488L))) {
/*  58 */       return this.queryLogger.getQueryCount(user);
/*     */     }
/*     */ 
/*  61 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getQueries() throws UnauthorizedException
/*     */   {
/*  66 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  67 */       return new IteratorProxy(19, this.queryLogger.getQueries(), this.auth);
/*     */     }
/*     */ 
/*  70 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getQueries(User user) throws UnauthorizedException
/*     */   {
/*  75 */     if (((user != null) && (this.auth.getUserID() == user.getID())) || (this.permissions.hasPermission(576460752303423488L))) {
/*  76 */       return new IteratorProxy(19, this.queryLogger.getQueries(user), this.auth);
/*     */     }
/*     */ 
/*  79 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Query getQuery(long queryID) throws NotFoundException, UnauthorizedException
/*     */   {
/*  84 */     Query q = this.queryLogger.getQuery(queryID);
/*     */ 
/*  86 */     if (((q.getUser() != null) && (q.getUser().getID() == this.auth.getUserID())) || (this.permissions.hasPermission(576460752303423488L)))
/*     */     {
/*  89 */       return new QueryProxy(q, this.auth);
/*     */     }
/*     */ 
/*  92 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Map getLoggedQueryInfo(Query query)
/*     */   {
/*  97 */     Map info = this.queryLogger.getLoggedQueryInfo(query);
/*     */ 
/* 101 */     Forum[] forums = (Forum[])info.get("forums");
/* 102 */     if (forums != null) {
/* 103 */       List validcats = new ArrayList();
/* 104 */       for (int i = 0; i < forums.length; i++) {
/* 105 */         Forum forum = forums[i];
/*     */         try {
/* 107 */           Forum proxyCat = ForumFactory.getInstance(this.auth).getForum(forum.getID());
/* 108 */           validcats.add(proxyCat);
/*     */         }
/*     */         catch (ForumNotFoundException e)
/*     */         {
/* 112 */           Log.error(e);
/*     */         }
/*     */         catch (UnauthorizedException e)
/*     */         {
/*     */         }
/*     */       }
/*     */ 
/* 119 */       info.put("forums", validcats.toArray(new Forum[validcats.size()]));
/*     */     }
/*     */ 
/* 122 */     return info;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.QueryLoggerProxy
 * JD-Core Version:    0.6.2
 */
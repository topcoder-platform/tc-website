/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ public class NameAlreadyExistsException extends Exception
/*    */ {
/*    */   public NameAlreadyExistsException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NameAlreadyExistsException(String message)
/*    */   {
/* 28 */     super(message);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.NameAlreadyExistsException
 * JD-Core Version:    0.6.2
 */
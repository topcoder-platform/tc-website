/*     */ package com.jivesoftware.forum.moderation;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.stats.util.DateFormatter;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageIterator;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.util.EmailTask;
/*     */ import com.jivesoftware.util.LocaleUtils;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ 
/*     */ public class ModerationManagerImpl
/*     */   implements ModerationManager
/*     */ {
/*  19 */   private static ModerationManager moderationManager = null;
/*     */   private ModerationFilter modFilter;
/*     */   private boolean emailAlertEnabled;
/*     */   private String emailName;
/*     */   private String emailAddress;
/*     */   private String emailSubject;
/*     */   private String emailBodyText;
/*     */   private String emailBodyHtml;
/*     */ 
/*     */   public static ModerationManager getInstance()
/*     */   {
/*  32 */     if (moderationManager == null) {
/*  33 */       moderationManager = new ModerationManagerImpl();
/*     */     }
/*  35 */     return moderationManager;
/*     */   }
/*     */ 
/*     */   private ModerationManagerImpl()
/*     */   {
/*  40 */     this.modFilter = ModerationFilter.createDefaultModerationFilter();
/*  41 */     this.emailAlertEnabled = JiveGlobals.getJiveBooleanProperty("moderation.emailalert.enabled");
/*  42 */     this.emailName = JiveGlobals.getJiveProperty("moderation.emailalert.name");
/*  43 */     this.emailAddress = JiveGlobals.getJiveProperty("moderation.emailalert.address");
/*  44 */     this.emailSubject = JiveGlobals.getJiveProperty("moderation.emailalert.subject");
/*  45 */     this.emailBodyText = JiveGlobals.getJiveProperty("moderation.emailalert.textBody");
/*  46 */     this.emailBodyHtml = JiveGlobals.getJiveProperty("moderation.emailalert.htmlBody");
/*     */   }
/*     */ 
/*     */   public List getForums(AuthToken authToken) {
/*  50 */     ForumFactory forumFactory = ForumFactory.getInstance(authToken);
/*     */ 
/*  52 */     ForumCategory rootCategory = forumFactory.getRootForumCategory();
/*     */ 
/*  54 */     List forums = new ArrayList();
/*     */ 
/*  56 */     for (Iterator iter = rootCategory.getRecursiveForums(); iter.hasNext(); ) {
/*  57 */       Forum forum = (Forum)iter.next();
/*  58 */       if (isAuthorized(forumFactory, forum))
/*     */       {
/*  61 */         boolean isThreadModOn = forum.getModerationDefaultThreadValue() < 1;
/*     */ 
/*  64 */         boolean isMessageModOn = forum.getModerationDefaultMessageValue() < 1;
/*     */ 
/*  67 */         if ((isThreadModOn) || (isMessageModOn)) {
/*  68 */           forums.add(forum);
/*     */         }
/*     */         else
/*     */         {
/*  74 */           ModerationFilter modFilter = ModerationFilter.createDefaultModerationFilter();
/*  75 */           modFilter.setStartIndex(0);
/*  76 */           modFilter.setNumResults(1);
/*  77 */           Iterator messages = forum.getMessages(modFilter);
/*  78 */           if (messages.hasNext()) {
/*  79 */             forums.add(forum);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  85 */     return forums;
/*     */   }
/*     */ 
/*     */   public List getMessages(AuthToken authToken) {
/*  89 */     List forumList = getForums(authToken);
/*     */ 
/*  91 */     if (forumList.size() == 0) {
/*  92 */       return Collections.EMPTY_LIST;
/*     */     }
/*     */ 
/*  95 */     List messageList = new ArrayList(5 * forumList.size());
/*     */ 
/*  97 */     for (Iterator forums = forumList.iterator(); forums.hasNext(); ) {
/*  98 */       Forum forum = (Forum)forums.next();
/*  99 */       for (messages = forum.getMessages(this.modFilter); messages.hasNext(); )
/* 100 */         messageList.add(messages.next());
/*     */     }
/*     */     Iterator messages;
/* 104 */     return messageList;
/*     */   }
/*     */ 
/*     */   public List getMessages(ModerationFilter modFilter, AuthToken authToken) {
/* 108 */     List forumList = getForums(authToken);
/*     */ 
/* 110 */     if (forumList.size() == 0) {
/* 111 */       return Collections.EMPTY_LIST;
/*     */     }
/*     */ 
/* 114 */     List messageList = new ArrayList(5 * forumList.size());
/*     */ 
/* 116 */     for (Iterator forums = forumList.iterator(); forums.hasNext(); ) {
/* 117 */       Forum forum = (Forum)forums.next();
/* 118 */       for (messages = forum.getMessages(modFilter); messages.hasNext(); )
/* 119 */         messageList.add(messages.next());
/*     */     }
/*     */     Iterator messages;
/* 123 */     return messageList;
/*     */   }
/*     */ 
/*     */   public ForumMessageIterator getMessages(AuthToken authToken, Forum forum) throws UnauthorizedException
/*     */   {
/* 128 */     ForumMessageIterator iterator = null;
/* 129 */     if (isAuthorized(ForumFactory.getInstance(authToken), forum)) {
/* 130 */       iterator = forum.getMessages(this.modFilter);
/*     */ 
/* 132 */       if (iterator == null) {
/* 133 */         iterator = ForumMessageIterator.EMPTY_ITERATOR;
/*     */       }
/* 135 */       return iterator;
/*     */     }
/*     */ 
/* 138 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public ForumMessageIterator getMessages(ModerationFilter modFilter, AuthToken authToken, Forum forum)
/*     */     throws UnauthorizedException
/*     */   {
/* 146 */     ForumMessageIterator iterator = null;
/* 147 */     if (isAuthorized(ForumFactory.getInstance(authToken), forum)) {
/* 148 */       iterator = forum.getMessages(modFilter);
/*     */ 
/* 150 */       if (iterator == null) {
/* 151 */         iterator = ForumMessageIterator.EMPTY_ITERATOR;
/*     */       }
/* 153 */       return iterator;
/*     */     }
/*     */ 
/* 156 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getMessageCount(Forum forum)
/*     */   {
/* 161 */     return forum.getMessageCount(this.modFilter);
/*     */   }
/*     */ 
/*     */   public int getMessageCount(ModerationFilter modFilter, Forum forum) {
/* 165 */     return forum.getMessageCount(modFilter);
/*     */   }
/*     */ 
/*     */   public void approve(AuthToken authToken, ForumMessage message) throws UnauthorizedException {
/* 169 */     Forum forum = message.getForum();
/* 170 */     if (isAuthorized(ForumFactory.getInstance(authToken), forum)) {
/* 171 */       message.setModerationValue(1, authToken);
/* 172 */       message.setProperty("moderation.timeApproved", String.valueOf(System.currentTimeMillis()));
/*     */     }
/*     */     else
/*     */     {
/* 176 */       throw new UnauthorizedException();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void editAndApprove(AuthToken authToken, ForumMessage message, String subject, String body) throws UnauthorizedException
/*     */   {
/* 182 */     Forum forum = message.getForum();
/* 183 */     if (isAuthorized(ForumFactory.getInstance(authToken), forum)) {
/* 184 */       if ((subject != null) && (!"".equals(subject.trim()))) {
/* 185 */         message.setSubject(subject);
/*     */       }
/* 187 */       if ((body != null) && (!"".equals(body.trim()))) {
/* 188 */         message.setBody(body);
/*     */       }
/* 190 */       message.setModerationValue(1, authToken);
/* 191 */       message.setProperty("moderation.timeApproved", String.valueOf(System.currentTimeMillis()));
/*     */     }
/*     */     else
/*     */     {
/* 195 */       throw new UnauthorizedException();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void reject(AuthToken authToken, ForumMessage message) throws UnauthorizedException {
/* 200 */     Forum forum = message.getForum();
/* 201 */     if (isAuthorized(ForumFactory.getInstance(authToken), forum)) {
/* 202 */       ForumThread thread = message.getForumThread();
/* 203 */       if (thread.getRootMessage().getID() == message.getID()) {
/* 204 */         thread.setModerationValue(-9998, authToken);
/*     */       }
/*     */       else {
/* 207 */         message.setModerationValue(-9998, authToken);
/*     */       }
/* 209 */       if (isEmailAlertEnabled())
/* 210 */         messageRejectedEmail(message);
/*     */     }
/*     */     else
/*     */     {
/* 214 */       throw new UnauthorizedException();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void messageRejectedEmail(ForumMessage message)
/*     */   {
/* 220 */     String subject = LocaleUtils.getLocalizedString(getEmailSubject());
/* 221 */     String textBody = generateString(LocaleUtils.getLocalizedString(getEmailBodyText()), message);
/*     */ 
/* 223 */     String htmlBody = generateString(LocaleUtils.getLocalizedString(getEmailBodyHtml()), message);
/*     */ 
/* 226 */     EmailTask emailTask = new EmailTask();
/*     */     String email;
/*     */     String name;
/*     */     String email;
/* 231 */     if (message.getUser() != null) {
/* 232 */       String name = message.getUser().getName();
/* 233 */       email = message.getUser().getEmail();
/*     */     }
/*     */     else {
/* 236 */       name = message.getProperty("name");
/* 237 */       email = message.getProperty("email");
/*     */     }
/*     */ 
/* 240 */     emailTask.addMessage(name, email, getEmailName(), getEmailAddress(), subject, textBody, htmlBody);
/*     */ 
/* 243 */     TaskEngine.addTask(emailTask);
/*     */   }
/*     */ 
/*     */   public boolean isEmailAlertEnabled() {
/* 247 */     return this.emailAlertEnabled;
/*     */   }
/*     */ 
/*     */   public void setEmailAlertEnabled(boolean emailAlertEnabled) {
/* 251 */     this.emailAlertEnabled = emailAlertEnabled;
/* 252 */     JiveGlobals.setJiveProperty("moderation.emailalert.enabled", String.valueOf(emailAlertEnabled));
/*     */   }
/*     */ 
/*     */   public String getEmailName() {
/* 256 */     return this.emailName;
/*     */   }
/*     */ 
/*     */   public void setEmailName(String emailName) {
/* 260 */     this.emailName = emailName;
/* 261 */     if ((emailName == null) || (emailName.equals(""))) {
/* 262 */       JiveGlobals.deleteJiveProperty("moderation.emailalert.name");
/*     */     }
/*     */     else
/* 265 */       JiveGlobals.setJiveProperty("moderation.emailalert.name", emailName);
/*     */   }
/*     */ 
/*     */   public String getEmailAddress()
/*     */   {
/* 270 */     return this.emailAddress;
/*     */   }
/*     */ 
/*     */   public void setEmailAddress(String emailAddress) {
/* 274 */     this.emailAddress = emailAddress;
/* 275 */     if ((emailAddress == null) || (emailAddress.equals(""))) {
/* 276 */       JiveGlobals.deleteJiveProperty("moderation.emailalert.address");
/*     */     }
/*     */     else
/* 279 */       JiveGlobals.setJiveProperty("moderation.emailalert.address", emailAddress);
/*     */   }
/*     */ 
/*     */   public String getEmailSubject()
/*     */   {
/* 284 */     if ((this.emailSubject == null) || ("".equals(this.emailSubject.trim()))) {
/* 285 */       return LocaleUtils.getLocalizedString("moderation.emailalert.subject");
/*     */     }
/*     */ 
/* 288 */     return this.emailSubject;
/*     */   }
/*     */ 
/*     */   public void setEmailSubject(String emailSubject)
/*     */   {
/* 293 */     this.emailSubject = emailSubject;
/* 294 */     if ((emailSubject == null) || (emailSubject.equals(""))) {
/* 295 */       JiveGlobals.deleteJiveProperty("moderation.emailalert.subject");
/*     */     }
/*     */     else
/* 298 */       JiveGlobals.setJiveProperty("moderation.emailalert.subject", emailSubject);
/*     */   }
/*     */ 
/*     */   public String getEmailBodyText()
/*     */   {
/* 303 */     if ((this.emailBodyText == null) || ("".equals(this.emailBodyText.trim()))) {
/* 304 */       return LocaleUtils.getLocalizedString("moderation.emailalert.textBody");
/*     */     }
/*     */ 
/* 307 */     return this.emailBodyText;
/*     */   }
/*     */ 
/*     */   public void setEmailBodyText(String emailBodyText)
/*     */   {
/* 312 */     this.emailBodyText = emailBodyText;
/* 313 */     if ((emailBodyText == null) || (emailBodyText.equals(""))) {
/* 314 */       JiveGlobals.deleteJiveProperty("moderation.emailalert.textBody");
/*     */     }
/*     */     else
/* 317 */       JiveGlobals.setJiveProperty("moderation.emailalert.textBody", emailBodyText);
/*     */   }
/*     */ 
/*     */   public String getEmailBodyHtml()
/*     */   {
/* 322 */     if ((this.emailBodyHtml == null) || ("".equals(this.emailBodyHtml.trim()))) {
/* 323 */       return LocaleUtils.getLocalizedString("moderation.emailalert.htmlBody");
/*     */     }
/*     */ 
/* 326 */     return this.emailBodyHtml;
/*     */   }
/*     */ 
/*     */   public void setEmailBodyHtml(String emailBodyHtml)
/*     */   {
/* 331 */     this.emailBodyHtml = emailBodyHtml;
/* 332 */     if ((emailBodyHtml == null) || (emailBodyHtml.equals(""))) {
/* 333 */       JiveGlobals.deleteJiveProperty("moderation.emailalert.htmlBody");
/*     */     }
/*     */     else
/* 336 */       JiveGlobals.setJiveProperty("moderation.emailalert.htmlBody", emailBodyHtml);
/*     */   }
/*     */ 
/*     */   private String generateString(String key, ForumMessage message)
/*     */   {
/* 342 */     Map context = new HashMap();
/*     */ 
/* 345 */     context.put("dateFormatter", new DateFormatter());
/* 346 */     context.put("message", message);
/*     */     try
/*     */     {
/* 350 */       VelocityContext velContext = new VelocityContext(context);
/* 351 */       Writer sw = new StringWriter();
/* 352 */       VelocityEngine ve = new VelocityEngine();
/* 353 */       ve.init();
/* 354 */       ve.evaluate(velContext, sw, "moderationManager", key);
/* 355 */       return sw.toString();
/*     */     }
/*     */     catch (Exception e) {
/* 358 */       Log.error(e);
/* 359 */     }return null;
/*     */   }
/*     */ 
/*     */   private boolean isAuthorized(ForumFactory forumFactory, Forum forum)
/*     */   {
/* 366 */     return (forumFactory.isAuthorized(576460752303423488L)) || (forum.isAuthorized(256L)) || (forum.isAuthorized(128L));
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.moderation.ModerationManagerImpl
 * JD-Core Version:    0.6.2
 */
/*      */ package com.jivesoftware.forum.database;
/*      */ 
/*      */ import com.jivesoftware.base.AuthToken;
/*      */ import com.jivesoftware.base.FilterManager;
/*      */ import com.jivesoftware.base.GroupManager;
/*      */ import com.jivesoftware.base.GroupManagerFactory;
/*      */ import com.jivesoftware.base.JiveGlobals;
/*      */ import com.jivesoftware.base.LicenseException;
/*      */ import com.jivesoftware.base.Log;
/*      */ import com.jivesoftware.base.PermissionType;
/*      */ import com.jivesoftware.base.Permissions;
/*      */ import com.jivesoftware.base.PermissionsManager;
/*      */ import com.jivesoftware.base.PollManager;
/*      */ import com.jivesoftware.base.PollManagerFactory;
/*      */ import com.jivesoftware.base.PresenceManager;
/*      */ import com.jivesoftware.base.UnauthorizedException;
/*      */ import com.jivesoftware.base.User;
/*      */ import com.jivesoftware.base.UserManager;
/*      */ import com.jivesoftware.base.UserManagerFactory;
/*      */ import com.jivesoftware.base.database.CachedPreparedStatement;
/*      */ import com.jivesoftware.base.database.ConnectionManager;
/*      */ import com.jivesoftware.base.database.ConnectionManager.DatabaseType;
/*      */ import com.jivesoftware.base.database.DbPermissionsManager;
/*      */ import com.jivesoftware.base.database.DbPresenceManager;
/*      */ import com.jivesoftware.base.event.UserEventDispatcher;
/*      */ import com.jivesoftware.forum.AnnouncementManager;
/*      */ import com.jivesoftware.forum.ArchiveManager;
/*      */ import com.jivesoftware.forum.AttachmentManager;
/*      */ import com.jivesoftware.forum.AvatarManager;
/*      */ import com.jivesoftware.forum.AvatarManagerFactory;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumCategory;
/*      */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*      */ import com.jivesoftware.forum.ForumFactory;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*      */ import com.jivesoftware.forum.ForumNotFoundException;
/*      */ import com.jivesoftware.forum.ForumThread;
/*      */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*      */ import com.jivesoftware.forum.InterceptorManager;
/*      */ import com.jivesoftware.forum.PrivateMessageManager;
/*      */ import com.jivesoftware.forum.Query;
/*      */ import com.jivesoftware.forum.QueryManager;
/*      */ import com.jivesoftware.forum.QuestionManager;
/*      */ import com.jivesoftware.forum.ReadTracker;
/*      */ import com.jivesoftware.forum.ResultFilter;
/*      */ import com.jivesoftware.forum.RewardManager;
/*      */ import com.jivesoftware.forum.SearchManager;
/*      */ import com.jivesoftware.forum.StatusLevelManager;
/*      */ import com.jivesoftware.forum.StatusLevelManagerFactory;
/*      */ import com.jivesoftware.forum.Version;
/*      */ import com.jivesoftware.forum.Version.Edition;
/*      */ import com.jivesoftware.forum.WatchManager;
/*      */ import com.jivesoftware.forum.event.DebugEventListener;
/*      */ import com.jivesoftware.forum.event.ForumEvent;
/*      */ import com.jivesoftware.forum.event.ForumEventDispatcher;
/*      */ import com.jivesoftware.forum.event.MessageEventDispatcher;
/*      */ import com.jivesoftware.forum.event.ThreadEventDispatcher;
/*      */ import com.jivesoftware.forum.gateway.GatewayManager;
/*      */ import com.jivesoftware.forum.nntp.NNTPServer;
/*      */ import com.jivesoftware.forum.virusscan.VirusScanManager;
/*      */ import com.jivesoftware.util.Cache;
/*      */ import com.jivesoftware.util.CacheFactory;
/*      */ import com.jivesoftware.util.CronTaskManager;
/*      */ import com.jivesoftware.util.LongHashMap;
/*      */ import com.jivesoftware.util.LongList;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ public class DbForumFactory extends ForumFactory
/*      */ {
/*      */   private static final String GET_FORUM_ID = "SELECT forumID FROM jiveForum WHERE name=?";
/*      */   private static final String ALL_FORUM_MESSAGES = "SELECT messageID, forumIndex, threadID FROM jiveMessage WHERE forumID=?";
/*      */   private static final String POPULAR_FORUMS = "SELECT forumID, count(*) AS msgCount FROM jiveMessage WHERE modificationDate > ? AND modValue >= 1 GROUP BY forumID ORDER BY msgCount DESC";
/*      */   private static final String POPULAR_FORUMS_ORACLE = "SELECT /*+ INDEX (jiveMessage jiveMessage_mDate_idx) */ forumID, count(*) AS msgCount FROM jiveMessage WHERE modificationDate > ? AND modValue >= 1 GROUP BY forumID ORDER BY msgCount DESC";
/*      */   private static final String POPULAR_THREADS = "SELECT threadID, count(*) AS msgCount FROM jiveMessage WHERE modificationDate > ? AND modValue >= 1 GROUP BY threadID ORDER BY msgCount DESC";
/*      */   private static final String POPULAR_THREADS_ORACLE = "SELECT /*+ INDEX (jiveMessage jiveMessage_mDate_idx) */ threadID, count(*) AS msgCount FROM jiveMessage WHERE modificationDate > ? AND modValue >= 1 GROUP BY threadID ORDER BY msgCount DESC";
/*      */   private static final String MOVE_THREADS_TO_FORUM = "UPDATE jiveThread SET forumID=? WHERE forumID=?";
/*      */   private static final String MOVE_MESSAGES_TO_FORUM = "UPDATE jiveMessage SET forumID=?, forumIndex=0 WHERE forumID=?";
/*      */   private static final String GET_MOVED_MESSAGE_COUNT = "SELECT count(*) FROM jiveMessage WHERE forumID=? AND forumIndex=0";
/*      */   private static final String GET_MOVED_MESSAGES = "SELECT messageID FROM jiveMessage WHERE forumID=? AND forumIndex=0";
/*      */   private static final String USER_MESSAGE_COUNT = "SELECT count(*) FROM jiveMessage WHERE jiveMessage.userID=? AND modValue >= 1";
/*      */   public DatabaseCacheManager cacheManager;
/*      */   protected UserManager userManager;
/*      */   protected GroupManager groupManager;
/*      */   private DbSearchManager searchManager;
/*      */   private DbFilterManager filterManager;
/*      */   private DbInterceptorManager interceptorManager;
/*      */   protected DbPermissionsManager permissionsManager;
/*      */   protected DbWatchManager watchManager;
/*   87 */   protected DbRewardManager rewardManager = null;
/*      */   protected DbQueryManager queryManager;
/*   89 */   private DbAttachmentManager attachmentManager = null;
/*      */   private DbArchiveManager archiveManager;
/*      */   private DbPresenceManager presenceManager;
/*      */   private DbReadTracker readTracker;
/*      */   private NNTPServer nntpServer;
/*      */   private PollManager pollManager;
/*      */   private DbPrivateMessageManager privateMessageManager;
/*      */   private DbAnnouncementManager announcementManager;
/*      */   private CronTaskManager cronTaskManager;
/*      */   private StatusLevelManager statusLevelManager;
/*      */   private AvatarManager avatarManager;
/*      */   private DbQuestionManager questionManager;
/*      */   private VirusScanManager virusScanManager;
/*      */   public LongHashMap gatewayManagers;
/*  114 */   private int popularForumsNumber = 4;
/*  115 */   private int popularForumsWindow = 24;
/*  116 */   private int popularThreadsNumber = 4;
/*  117 */   private int popularThreadsWindow = 24;
/*      */ 
/*  119 */   private long[] popularForums = null;
/*  120 */   private long[] popularThreads = null;
/*      */ 
/*  122 */   private long popularObjectsTimestamp = System.currentTimeMillis();
/*      */   private boolean moderationDisabled;
/*  129 */   private static DbForumFactory instance = null;
/*  130 */   private static final Object startupLock = new Object();
/*  131 */   private static boolean initialized = false;
/*      */ 
/*      */   public static synchronized DbForumFactory getInstance()
/*      */   {
/*  137 */     synchronized (startupLock) {
/*  138 */       if (instance == null) {
/*  139 */         instance = new DbForumFactory();
/*  140 */         instance.init();
/*  141 */         instance.startup();
/*  142 */         initialized = true;
/*      */       }
/*      */     }
/*  145 */     return instance;
/*      */   }
/*      */ 
/*      */   public static synchronized DbForumFactory getNonInitializedInstance() {
/*  149 */     synchronized (startupLock) {
/*  150 */       if (instance == null) {
/*  151 */         instance = new DbForumFactory();
/*  152 */         instance.init();
/*      */       }
/*      */     }
/*  155 */     return instance;
/*      */   }
/*      */ 
/*      */   public static synchronized void initializeInstance() {
/*  159 */     synchronized (startupLock) {
/*  160 */       if (instance == null) {
/*  161 */         return;
/*      */       }
/*      */ 
/*  164 */       if (!initialized) {
/*  165 */         instance.startup();
/*  166 */         initialized = true;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static boolean isInitialized() {
/*  172 */     return initialized;
/*      */   }
/*      */ 
/*      */   public static void clear()
/*      */   {
/*  180 */     instance = null;
/*  181 */     initialized = false;
/*      */   }
/*      */ 
/*      */   private void init()
/*      */   {
/*  190 */     Log.info("Starting Jive Forums " + Version.getEdition() + " " + Version.getVersionNumber());
/*      */ 
/*  193 */     GroupManagerFactory.addListener(new GroupDeletedListener());
/*      */ 
/*  195 */     UserManagerFactory.addListener(new UserDeletedListener());
/*      */ 
/*  197 */     this.searchManager = DbSearchManager.getInstance();
/*  198 */     this.filterManager = new DbFilterManager(17, -1L);
/*  199 */     this.interceptorManager = new DbInterceptorManager(17, -1L);
/*  200 */     this.permissionsManager = DbPermissionsManager.getInstance();
/*  201 */     this.watchManager = new DbWatchManager();
/*  202 */     this.archiveManager = new DbArchiveManager();
/*  203 */     this.userManager = UserManagerFactory.getInstance();
/*  204 */     this.groupManager = GroupManagerFactory.getInstance();
/*  205 */     this.presenceManager = DbPresenceManager.getInstance();
/*  206 */     this.readTracker = DbReadTracker.getInstance();
/*  207 */     this.privateMessageManager = DbPrivateMessageManager.getInstance();
/*  208 */     this.announcementManager = DbAnnouncementManager.getInstance();
/*  209 */     this.cronTaskManager = CronTaskManager.getInstance();
/*  210 */     this.queryManager = DbQueryManager.getInstance();
/*      */ 
/*  213 */     if ((Version.getEdition() == Version.Edition.ENTERPRISE) || (Version.getEdition() == Version.Edition.EXPERT))
/*      */     {
/*      */       try
/*      */       {
/*  217 */         this.virusScanManager = VirusScanManager.getInstance();
/*      */       }
/*      */       catch (LicenseException le) {
/*  220 */         Log.error("Virus scanner failed due to license exception. Functionality will be disabled", le);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  225 */     if (Version.getEdition() == Version.Edition.EXPERT) {
/*      */       try {
/*  227 */         this.questionManager = DbQuestionManager.getInstance();
/*      */       }
/*      */       catch (LicenseException le) {
/*  230 */         Log.error("Question manager loading failed due to license exception. Functionality will be disabled", le);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  236 */     this.nntpServer = NNTPServer.getInstance();
/*      */ 
/*  239 */     this.popularForumsNumber = JiveGlobals.getJiveIntProperty("popularForums.number", this.popularForumsNumber);
/*  240 */     this.popularForumsWindow = JiveGlobals.getJiveIntProperty("popularForums.timeWindow", this.popularForumsWindow);
/*  241 */     this.popularThreadsNumber = JiveGlobals.getJiveIntProperty("popularThreads.number", this.popularThreadsNumber);
/*  242 */     this.popularThreadsWindow = JiveGlobals.getJiveIntProperty("popularThreads.timeWindow", this.popularThreadsWindow);
/*      */ 
/*  245 */     this.moderationDisabled = JiveGlobals.getJiveBooleanProperty("database.moderationDisabled", false);
/*      */   }
/*      */ 
/*      */   private void startup()
/*      */   {
/*  250 */     CacheFactory.isClusteringEnabled();
/*      */ 
/*  252 */     this.cacheManager = new DatabaseCacheManager();
/*      */ 
/*  255 */     GroupManagerFactory.doInitialize();
/*  256 */     UserManagerFactory.doInitialize();
/*  257 */     this.userManager = UserManagerFactory.getInstance();
/*  258 */     this.groupManager = GroupManagerFactory.getInstance();
/*      */ 
/*  260 */     this.searchManager.initialize();
/*  261 */     this.filterManager.initialize();
/*  262 */     this.interceptorManager.initialize();
/*  263 */     this.permissionsManager.initialize();
/*  264 */     this.watchManager.initialize();
/*  265 */     this.archiveManager.initialize();
/*  266 */     this.presenceManager.initialize();
/*  267 */     this.readTracker.initialize();
/*  268 */     PollManagerFactory.doInitialize();
/*  269 */     this.pollManager = PollManagerFactory.getInstance();
/*  270 */     this.privateMessageManager.initialize();
/*  271 */     this.announcementManager.initialize();
/*  272 */     this.cronTaskManager.initialize();
/*  273 */     this.queryManager.initialize();
/*  274 */     StatusLevelManagerFactory.doInitialize();
/*  275 */     this.statusLevelManager = StatusLevelManagerFactory.getInstance();
/*  276 */     AvatarManagerFactory.doInitialize();
/*  277 */     this.avatarManager = AvatarManagerFactory.getInstance();
/*      */ 
/*  280 */     if (((Version.getEdition() == Version.Edition.ENTERPRISE) || (Version.getEdition() == Version.Edition.EXPERT)) && 
/*  281 */       (this.virusScanManager != null)) {
/*  282 */       this.virusScanManager.initialize();
/*      */     }
/*      */ 
/*  286 */     if ((Version.getEdition() == Version.Edition.EXPERT) && 
/*  287 */       (this.questionManager != null)) {
/*  288 */       this.questionManager.initialize();
/*      */     }
/*      */ 
/*  293 */     this.nntpServer.initialize();
/*      */ 
/*  296 */     this.gatewayManagers = new LongHashMap();
/*      */ 
/*  298 */     long[] forumIDs = GatewayManager.getForumsWithGateways();
/*  299 */     for (int i = 0; i < forumIDs.length; i++) {
/*      */       try {
/*  301 */         Forum forum = this.cacheManager.getForum(forumIDs[i]);
/*  302 */         GatewayManager gManager = new GatewayManager(this, forum);
/*  303 */         this.gatewayManagers.put(forum.getID(), gManager);
/*      */       }
/*      */       catch (ForumNotFoundException fnfe) {
/*  306 */         Log.error("Forum referenced in gateway config could not be loaded.", fnfe);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  311 */     PollCleanupListener pollListener = new PollCleanupListener();
/*  312 */     ForumEventDispatcher.getInstance().addListener(pollListener);
/*  313 */     ThreadEventDispatcher.getInstance().addListener(pollListener);
/*  314 */     MessageEventDispatcher.getInstance().addListener(pollListener);
/*  315 */     UserEventDispatcher.getInstance().addListener(pollListener);
/*      */ 
/*  318 */     if (Log.isDebugEnabled())
/*  319 */       new DebugEventListener();
/*      */   }
/*      */ 
/*      */   public Forum createForum(String name, String description)
/*      */   {
/*  326 */     return createForum(name, description, getRootForumCategory());
/*      */   }
/*      */ 
/*      */   public Forum createForum(String name, String description, ForumCategory category) {
/*  330 */     Forum newForum = new DbForum(name, description, category);
/*      */ 
/*  332 */     this.gatewayManagers.put(newForum.getID(), new GatewayManager(this, newForum));
/*      */     try
/*      */     {
/*  337 */       ForumCategory cat = category;
/*  338 */       while (cat != null) {
/*  339 */         this.cacheManager.getForumCategory(cat.getID()).clearCache();
/*  340 */         cat = cat.getParentCategory();
/*      */       }
/*      */     }
/*      */     catch (ForumCategoryNotFoundException e)
/*      */     {
/*      */     }
/*  346 */     ForumEvent event = new ForumEvent(120, newForum, Collections.EMPTY_MAP);
/*  347 */     ForumEventDispatcher.getInstance().dispatchEvent(event);
/*      */ 
/*  349 */     return newForum;
/*      */   }
/*      */ 
/*      */   public void deleteForum(Forum forum) throws UnauthorizedException {
/*  353 */     getRootForumCategory().deleteForum(forum);
/*      */   }
/*      */ 
/*      */   public synchronized void mergeForums(Forum forum1, Forum forum2)
/*      */     throws UnauthorizedException
/*      */   {
/*  359 */     this.permissionsManager.removeAllPermissions(0, forum2.getID());
/*      */ 
/*  364 */     boolean largeForum = forum2.getMessageCount() > 750;
/*  365 */     LongList messages = new LongList();
/*  366 */     LongList forumIndexes = new LongList();
/*  367 */     LongList threads = new LongList();
/*  368 */     if (!largeForum) {
/*  369 */       Connection con = null;
/*  370 */       PreparedStatement pstmt = null;
/*      */       try {
/*  372 */         con = ConnectionManager.getConnection();
/*  373 */         pstmt = con.prepareStatement("SELECT messageID, forumIndex, threadID FROM jiveMessage WHERE forumID=?");
/*  374 */         pstmt.setLong(1, forum2.getID());
/*  375 */         ResultSet rs = pstmt.executeQuery();
/*  376 */         while (rs.next()) {
/*  377 */           messages.add(rs.getLong(1));
/*  378 */           forumIndexes.add(rs.getInt(2));
/*  379 */           threads.add(rs.getLong(3));
/*      */         }
/*  381 */         rs.close();
/*      */       }
/*      */       catch (SQLException sqle) {
/*  384 */         Log.error(sqle);
/*      */       }
/*      */       finally {
/*  387 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  392 */     boolean abortTransaction = false;
/*  393 */     Connection con = null;
/*  394 */     PreparedStatement pstmt = null;
/*      */     try {
/*  396 */       con = ConnectionManager.getTransactionConnection();
/*      */ 
/*  398 */       pstmt = con.prepareStatement("UPDATE jiveThread SET forumID=? WHERE forumID=?");
/*  399 */       pstmt.setLong(1, forum1.getID());
/*  400 */       pstmt.setLong(2, forum2.getID());
/*  401 */       pstmt.executeUpdate();
/*  402 */       pstmt.close();
/*      */ 
/*  405 */       pstmt = con.prepareStatement("UPDATE jiveMessage SET forumID=?, forumIndex=0 WHERE forumID=?");
/*  406 */       pstmt.setLong(1, forum1.getID());
/*  407 */       pstmt.setLong(2, forum2.getID());
/*  408 */       pstmt.executeUpdate();
/*      */     } catch (SQLException sqle) { Log.error(sqle);
/*  412 */       abortTransaction = true;
/*      */       return;
/*      */     }
/*      */     finally {
/*  416 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */ 
/*  420 */     Object params = new TreeMap();
/*  421 */     ((Map)params).put("mergedForumID", new Long(forum2.getID()));
/*  422 */     ((Map)params).put("mergedForumCategoryID", new Long(forum2.getForumCategory().getID()));
/*  423 */     ForumEvent event = new ForumEvent(123, forum1, (Map)params);
/*  424 */     ForumEventDispatcher.getInstance().dispatchEvent(event);
/*      */ 
/*  427 */     ((DbForumCategory)getRootForumCategory()).deleteForum(forum2, false);
/*  428 */     this.cacheManager.forumCache.remove(new Long(forum2.getID()));
/*      */     try
/*      */     {
/*  432 */       DbForum dbForum = this.cacheManager.getForum(forum1.getID());
/*  433 */       dbForum.clearCache();
/*      */     }
/*      */     catch (ForumNotFoundException fnfe)
/*      */     {
/*      */     }
/*      */ 
/*  440 */     if (largeForum) {
/*  441 */       this.cacheManager.messageCache.clear();
/*  442 */       this.cacheManager.forumIndexCache.clear();
/*  443 */       this.cacheManager.threadCache.clear();
/*      */     }
/*      */     else
/*      */     {
/*  447 */       for (int i = 0; i < messages.size(); i++) {
/*  448 */         this.cacheManager.messageRemove(messages.get(i));
/*  449 */         String key = forum2.getID() + '-' + forumIndexes.get(i);
/*      */ 
/*  451 */         this.cacheManager.forumIndexRemove(key);
/*  452 */         this.cacheManager.threadRemove(threads.get(i));
/*      */       }
/*  454 */       messages = null;
/*  455 */       forumIndexes = null;
/*  456 */       threads = null;
/*      */     }
/*      */ 
/*  461 */     ResultFilter newestThreadFilter = ResultFilter.createDefaultThreadFilter();
/*  462 */     newestThreadFilter.setNumResults(1);
/*  463 */     Iterator threadIter = forum1.getThreads(newestThreadFilter);
/*  464 */     if (threadIter.hasNext()) {
/*  465 */       ForumThread newestThread = (ForumThread)threadIter.next();
/*  466 */       if (newestThread != null) {
/*  467 */         forum1.setModificationDate(newestThread.getModificationDate());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  476 */     abortTransaction = false;
/*  477 */     int messageCount = 0;
/*  478 */     int nextForumIndex = 0;
/*      */     try {
/*  480 */       con = ConnectionManager.getTransactionConnection();
/*  481 */       pstmt = con.prepareStatement("SELECT count(*) FROM jiveMessage WHERE forumID=? AND forumIndex=0");
/*  482 */       pstmt.setLong(1, forum1.getID());
/*  483 */       ResultSet rs = pstmt.executeQuery();
/*  484 */       rs.next();
/*  485 */       messageCount = rs.getInt(1);
/*  486 */       rs.close();
/*  487 */       pstmt.close();
/*      */ 
/*  489 */       nextForumIndex = DbForumMessage.getForumIndexValues(messageCount, forum1.getID()) - messageCount + 1;
/*      */     }
/*      */     catch (SQLException sqle)
/*      */     {
/*  493 */       Log.error(sqle);
/*  494 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/*  497 */       ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*      */     }
/*      */ 
/*  500 */     Connection con2 = null;
/*      */     try {
/*  502 */       con = ConnectionManager.getConnection();
/*      */ 
/*  506 */       con2 = ConnectionManager.getConnection();
/*      */ 
/*  508 */       pstmt = con.prepareStatement("SELECT messageID FROM jiveMessage WHERE forumID=? AND forumIndex=0");
/*  509 */       pstmt.setLong(1, forum1.getID());
/*  510 */       ResultSet rs = pstmt.executeQuery();
/*  511 */       for (int i = 0; (i < messageCount) && (rs.next()); nextForumIndex++) {
/*  512 */         long messageID = rs.getLong(1);
/*      */         try {
/*  514 */           DbForumMessage message = (DbForumMessage)getMessage(messageID);
/*      */ 
/*  516 */           message.setForumIndex(nextForumIndex, con2);
/*      */         }
/*      */         catch (ForumMessageNotFoundException e)
/*      */         {
/*      */         }
/*  511 */         i++;
/*      */       }
/*      */ 
/*  520 */       rs.close();
/*      */     }
/*      */     catch (SQLException sqle) {
/*  523 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/*  526 */       ConnectionManager.closeConnection(pstmt, con);
/*  527 */       ConnectionManager.closeConnection(con2);
/*      */     }
/*      */   }
/*      */ 
/*      */   public ForumCategory getForumCategory(long categoryID) throws ForumCategoryNotFoundException {
/*  532 */     return this.cacheManager.getForumCategory(categoryID);
/*      */   }
/*      */ 
/*      */   public ForumCategory getRootForumCategory() {
/*  536 */     ForumCategory root = null;
/*      */     try {
/*  538 */       root = this.cacheManager.getForumCategory(1L);
/*      */     }
/*      */     catch (Exception e) {
/*  541 */       Log.error(e);
/*      */     }
/*  543 */     return root;
/*      */   }
/*      */ 
/*      */   public Forum getForum(long forumID) throws ForumNotFoundException {
/*  547 */     return this.cacheManager.getForum(forumID);
/*      */   }
/*      */ 
/*      */   public Forum getForum(String nntpName) throws ForumNotFoundException {
/*  551 */     return this.cacheManager.getForum(nntpName);
/*      */   }
/*      */ 
/*      */   public ForumThread getForumThread(long threadID) throws ForumThreadNotFoundException {
/*  555 */     return this.cacheManager.getForumThread(threadID);
/*      */   }
/*      */ 
/*      */   public ForumMessage getMessage(long messageID) throws ForumMessageNotFoundException {
/*  559 */     return this.cacheManager.getMessage(messageID);
/*      */   }
/*      */ 
/*      */   public long getMessageID(long forumID, int forumIndex) {
/*  563 */     return this.cacheManager.getMessageID(forumID, forumIndex);
/*      */   }
/*      */ 
/*      */   public int getForumCount() {
/*  567 */     return getRootForumCategory().getRecursiveForumCount();
/*      */   }
/*      */ 
/*      */   public int getForumCount(ResultFilter resultFilter) {
/*  571 */     return getRootForumCategory().getRecursiveForumCount(resultFilter);
/*      */   }
/*      */ 
/*      */   public Iterator getForums() {
/*  575 */     return getRootForumCategory().getRecursiveForums();
/*      */   }
/*      */ 
/*      */   public Iterator getForums(ResultFilter resultFilter) {
/*  579 */     return getRootForumCategory().getRecursiveForums(resultFilter);
/*      */   }
/*      */ 
/*      */   public Query createQuery() {
/*  583 */     return getQueryManager().createQuery();
/*      */   }
/*      */ 
/*      */   public Query createQuery(Forum[] forums)
/*      */   {
/*  590 */     return getQueryManager().createQuery(forums);
/*      */   }
/*      */ 
/*      */   public Iterator getPopularForums() {
/*  594 */     if (this.popularForums == null)
/*      */     {
/*  596 */       loadPopularObjects();
/*      */     }
/*  598 */     return new DatabaseObjectIterator(0, this.popularForums, this);
/*      */   }
/*      */ 
/*      */   public Iterator getPopularThreads() {
/*  602 */     if (this.popularThreads == null)
/*      */     {
/*  604 */       loadPopularObjects();
/*      */     }
/*  606 */     return new DatabaseObjectIterator(1, this.popularThreads, this);
/*      */   }
/*      */ 
/*      */   public int getUserMessageCount(User user) {
/*  610 */     Long key = new Long(user.getID());
/*      */ 
/*  612 */     Integer msgCount = (Integer)this.cacheManager.userMessageCountCache.get(key);
/*  613 */     if (msgCount != null) {
/*  614 */       return msgCount.intValue();
/*      */     }
/*      */ 
/*  617 */     int count = 0;
/*  618 */     Connection con = null;
/*  619 */     PreparedStatement pstmt = null;
/*      */     try {
/*  621 */       con = ConnectionManager.getConnection();
/*  622 */       pstmt = con.prepareStatement("SELECT count(*) FROM jiveMessage WHERE jiveMessage.userID=? AND modValue >= 1");
/*  623 */       pstmt.setLong(1, user.getID());
/*  624 */       ResultSet rs = pstmt.executeQuery();
/*  625 */       if (rs.next()) {
/*  626 */         count = rs.getInt(1);
/*      */       }
/*  628 */       rs.close();
/*      */ 
/*  630 */       msgCount = new Integer(count);
/*  631 */       this.cacheManager.userMessageCountCache.put(key, msgCount);
/*      */     }
/*      */     catch (SQLException sqle) {
/*  634 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/*  637 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*  639 */     return count;
/*      */   }
/*      */ 
/*      */   public int getUserMessageCount(User user, ResultFilter resultFilter) {
/*  643 */     CachedPreparedStatement sql = getUserMessageListSQL(user.getID(), resultFilter, true);
/*  644 */     QueryCacheKey key = new QueryCacheKey(3, user.getID(), sql, -1);
/*  645 */     return QueryCache.getCount(key, true);
/*      */   }
/*      */ 
/*      */   public Iterator getUserMessages(User user) {
/*  649 */     return getUserMessages(user, ResultFilter.createDefaultUserMessagesFilter());
/*      */   }
/*      */ 
/*      */   public Iterator getUserMessages(User user, ResultFilter resultFilter) {
/*  653 */     CachedPreparedStatement query = getUserMessageListSQL(user.getID(), resultFilter, false);
/*  654 */     long[] messageBlock = QueryCache.getBlock(query, 3, user.getID(), resultFilter.getStartIndex(), true);
/*      */ 
/*  656 */     int startIndex = resultFilter.getStartIndex();
/*      */     int endIndex;
/*      */     int endIndex;
/*  660 */     if (resultFilter.getNumResults() == 2147483524) {
/*  661 */       endIndex = getUserMessageCount(user, resultFilter);
/*      */     }
/*      */     else {
/*  664 */       endIndex = resultFilter.getNumResults() + startIndex;
/*      */     }
/*  666 */     return new ForumMessageBlockIterator(messageBlock, query, startIndex, endIndex, 3, user.getID());
/*      */   }
/*      */ 
/*      */   public UserManager getUserManager()
/*      */   {
/*  671 */     return this.userManager;
/*      */   }
/*      */ 
/*      */   public GroupManager getGroupManager() {
/*  675 */     return this.groupManager;
/*      */   }
/*      */ 
/*      */   public SearchManager getSearchManager() {
/*  679 */     return this.searchManager;
/*      */   }
/*      */ 
/*      */   public FilterManager getFilterManager() {
/*  683 */     return this.filterManager;
/*      */   }
/*      */ 
/*      */   public InterceptorManager getInterceptorManager() {
/*  687 */     return this.interceptorManager;
/*      */   }
/*      */ 
/*      */   public WatchManager getWatchManager() {
/*  691 */     return this.watchManager;
/*      */   }
/*      */ 
/*      */   public RewardManager getRewardManager() {
/*  695 */     if (this.rewardManager == null) {
/*  696 */       this.rewardManager = new DbRewardManager();
/*      */     }
/*  698 */     return this.rewardManager;
/*      */   }
/*      */ 
/*      */   public AttachmentManager getAttachmentManager() {
/*  702 */     if (this.attachmentManager == null) {
/*  703 */       this.attachmentManager = DbAttachmentManager.getInstance();
/*      */     }
/*  705 */     return this.attachmentManager;
/*      */   }
/*      */ 
/*      */   public ArchiveManager getArchiveManager() {
/*  709 */     return this.archiveManager;
/*      */   }
/*      */ 
/*      */   public PresenceManager getPresenceManager() {
/*  713 */     return this.presenceManager;
/*      */   }
/*      */ 
/*      */   public PermissionsManager getPermissionsManager() {
/*  717 */     return this.permissionsManager;
/*      */   }
/*      */ 
/*      */   public QueryManager getQueryManager() {
/*  721 */     return this.queryManager;
/*      */   }
/*      */ 
/*      */   public ReadTracker getReadTracker() {
/*  725 */     return this.readTracker;
/*      */   }
/*      */ 
/*      */   public PollManager getPollManager() {
/*  729 */     return this.pollManager;
/*      */   }
/*      */ 
/*      */   public PrivateMessageManager getPrivateMessageManager() {
/*  733 */     return this.privateMessageManager;
/*      */   }
/*      */ 
/*      */   public AnnouncementManager getAnnouncementManager() {
/*  737 */     return this.announcementManager;
/*      */   }
/*      */ 
/*      */   public CronTaskManager getCronTaskManager() {
/*  741 */     return this.cronTaskManager;
/*      */   }
/*      */ 
/*      */   public QuestionManager getQuestionManager() {
/*  745 */     return this.questionManager;
/*      */   }
/*      */ 
/*      */   public NNTPServer getNNTPServer() {
/*  749 */     return this.nntpServer;
/*      */   }
/*      */ 
/*      */   public VirusScanManager getVirusScanManager() {
/*  753 */     return this.virusScanManager;
/*      */   }
/*      */ 
/*      */   public Permissions getPermissions(AuthToken authToken)
/*      */   {
/*  758 */     return this.permissionsManager.getFinalUserPerms(17, -1L, authToken.getUserID(), PermissionType.ADDITIVE);
/*      */   }
/*      */ 
/*      */   public boolean isAuthorized(long type)
/*      */   {
/*  763 */     return true;
/*      */   }
/*      */ 
/*      */   public DatabaseCacheManager getCacheManager()
/*      */   {
/*  772 */     return this.cacheManager;
/*      */   }
/*      */ 
/*      */   public StatusLevelManager getStatusLevelManager() {
/*  776 */     return this.statusLevelManager;
/*      */   }
/*      */ 
/*      */   public AvatarManager getAvatarManager() {
/*  780 */     return this.avatarManager;
/*      */   }
/*      */ 
/*      */   protected static long getForumID(String name)
/*      */     throws ForumNotFoundException
/*      */   {
/*  789 */     Connection con = null;
/*  790 */     PreparedStatement pstmt = null;
/*  791 */     long forumID = -1L;
/*      */     try {
/*  793 */       con = ConnectionManager.getConnection();
/*  794 */       pstmt = con.prepareStatement("SELECT forumID FROM jiveForum WHERE name=?");
/*  795 */       pstmt.setString(1, name);
/*  796 */       ResultSet rs = pstmt.executeQuery();
/*  797 */       if (!rs.next()) {
/*  798 */         throw new ForumNotFoundException("Forum with name " + name + "does not exist.");
/*      */       }
/*      */ 
/*  801 */       forumID = rs.getLong(1);
/*  802 */       rs.close();
/*      */     }
/*      */     catch (SQLException sqle) {
/*  805 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/*  808 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*  810 */     return forumID;
/*      */   }
/*      */ 
/*      */   private synchronized void loadPopularObjects() {
/*  814 */     if ((this.popularForums == null) || (this.popularThreads == null))
/*      */     {
/*  816 */       this.popularObjectsTimestamp = CacheFactory.currentTime;
/*      */ 
/*  819 */       LongList popForums = new LongList(this.popularForumsNumber);
/*      */ 
/*  821 */       Calendar cal = Calendar.getInstance();
/*  822 */       cal.add(11, -this.popularForumsWindow);
/*      */ 
/*  824 */       Connection con = null;
/*  825 */       PreparedStatement pstmt = null;
/*      */       try {
/*  827 */         con = ConnectionManager.getConnection();
/*      */ 
/*  830 */         if (ConnectionManager.getDatabaseType() == ConnectionManager.DatabaseType.ORACLE)
/*      */         {
/*  833 */           pstmt = con.prepareStatement("SELECT /*+ INDEX (jiveMessage jiveMessage_mDate_idx) */ forumID, count(*) AS msgCount FROM jiveMessage WHERE modificationDate > ? AND modValue >= 1 GROUP BY forumID ORDER BY msgCount DESC");
/*      */         }
/*      */         else {
/*  836 */           pstmt = con.prepareStatement("SELECT forumID, count(*) AS msgCount FROM jiveMessage WHERE modificationDate > ? AND modValue >= 1 GROUP BY forumID ORDER BY msgCount DESC");
/*      */         }
/*  838 */         pstmt.setLong(1, cal.getTime().getTime());
/*  839 */         ResultSet rs = pstmt.executeQuery();
/*  840 */         for (int i = 0; (i < this.popularForumsNumber) && 
/*  841 */           (rs.next()); i++)
/*      */         {
/*  844 */           popForums.add(rs.getLong(1));
/*      */         }
/*  846 */         rs.close();
/*  847 */         this.popularForums = popForums.toArray();
/*      */       }
/*      */       catch (SQLException sqle) {
/*  850 */         Log.error(sqle);
/*      */       }
/*      */       finally {
/*  853 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*      */ 
/*  857 */       LongList threadIDs = new LongList(this.popularThreadsNumber);
/*      */ 
/*  859 */       cal = Calendar.getInstance();
/*  860 */       cal.add(11, -this.popularThreadsWindow);
/*      */ 
/*  862 */       con = null;
/*  863 */       pstmt = null;
/*      */       try {
/*  865 */         con = ConnectionManager.getConnection();
/*      */ 
/*  868 */         if (ConnectionManager.getDatabaseType() == ConnectionManager.DatabaseType.ORACLE)
/*      */         {
/*  871 */           pstmt = con.prepareStatement("SELECT /*+ INDEX (jiveMessage jiveMessage_mDate_idx) */ threadID, count(*) AS msgCount FROM jiveMessage WHERE modificationDate > ? AND modValue >= 1 GROUP BY threadID ORDER BY msgCount DESC");
/*      */         }
/*      */         else {
/*  874 */           pstmt = con.prepareStatement("SELECT threadID, count(*) AS msgCount FROM jiveMessage WHERE modificationDate > ? AND modValue >= 1 GROUP BY threadID ORDER BY msgCount DESC");
/*      */         }
/*  876 */         pstmt.setLong(1, cal.getTime().getTime());
/*  877 */         ResultSet rs = pstmt.executeQuery();
/*  878 */         for (int i = 0; (i < this.popularThreadsNumber) && 
/*  879 */           (rs.next()); i++)
/*      */         {
/*  882 */           threadIDs.add(rs.getLong(1));
/*      */         }
/*  884 */         rs.close();
/*  885 */         this.popularThreads = threadIDs.toArray();
/*      */       }
/*      */       catch (Exception e) {
/*  888 */         Log.error(e);
/*      */       }
/*      */       finally {
/*  891 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void expirePopularObjects(boolean forceReload)
/*      */   {
/*  904 */     long delta = CacheFactory.currentTime - this.popularObjectsTimestamp;
/*      */ 
/*  906 */     if (delta > 900000L) {
/*  907 */       this.popularForums = null;
/*  908 */       this.popularThreads = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected final boolean moderationDisabled()
/*      */   {
/*  925 */     return this.moderationDisabled;
/*      */   }
/*      */ 
/*      */   protected CachedPreparedStatement getUserMessageListSQL(long userID, ResultFilter resultFilter, boolean countQuery)
/*      */   {
/*  934 */     int sortField = resultFilter.getSortField();
/*      */ 
/*  936 */     if ((!countQuery) && (sortField != 9) && (sortField != 8) && (sortField != 6) && ((sortField != 10) || (resultFilter.getSortPropertyName() == null)))
/*      */     {
/*  945 */       throw new IllegalArgumentException("The specified sort field is not valid.");
/*      */     }
/*      */ 
/*  948 */     CachedPreparedStatement pstmt = new CachedPreparedStatement();
/*      */ 
/*  950 */     StringBuffer query = new StringBuffer(200);
/*  951 */     if (!countQuery) {
/*  952 */       query.append("SELECT jiveMessage.messageID");
/*      */     }
/*      */     else {
/*  955 */       query.append("SELECT count(*)");
/*      */     }
/*      */ 
/*  958 */     boolean filterCreationDate = (resultFilter.getCreationDateRangeMin() != null) || (resultFilter.getCreationDateRangeMax() != null);
/*      */ 
/*  960 */     boolean filterModifiedDate = (resultFilter.getModificationDateRangeMin() != null) || (resultFilter.getModificationDateRangeMax() != null);
/*      */ 
/*  962 */     int propertyCount = resultFilter.getPropertyCount();
/*      */ 
/*  965 */     if (!countQuery) {
/*  966 */       switch (sortField) {
/*      */       case 6:
/*  968 */         query.append(", subject");
/*  969 */         break;
/*      */       case 9:
/*  971 */         query.append(", modificationDate");
/*  972 */         break;
/*      */       case 8:
/*  974 */         query.append(", creationDate");
/*  975 */         break;
/*      */       case 10:
/*  977 */         query.append(", propTable.propValue");
/*      */       case 7:
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  983 */     query.append(" FROM jiveMessage");
/*  984 */     for (int i = 0; i < propertyCount; i++) {
/*  985 */       query.append(", jiveMessageProp p").append(i);
/*      */     }
/*  987 */     if (resultFilter.getSortField() == 10) {
/*  988 */       query.append(", jiveMessageProp propTable");
/*      */     }
/*      */ 
/*  992 */     query.append(" WHERE userID=?");
/*  993 */     pstmt.addLong(userID);
/*      */ 
/*  995 */     for (int i = 0; i < propertyCount; i++) {
/*  996 */       query.append(" AND jiveMessage.messageID=p").append(i).append(".messageID");
/*  997 */       query.append(" AND p").append(i).append(".name=?");
/*  998 */       pstmt.addString(resultFilter.getPropertyName(i));
/*  999 */       query.append(" AND p").append(i).append(".propValue=?");
/* 1000 */       pstmt.addString(resultFilter.getPropertyValue(i));
/*      */     }
/*      */ 
/* 1003 */     if (sortField == 10) {
/* 1004 */       query.append(" AND jiveMessage.messageID=propTable.messageID");
/* 1005 */       query.append(" AND propTable.name=?");
/* 1006 */       pstmt.addString(resultFilter.getSortPropertyName());
/*      */     }
/*      */ 
/* 1010 */     if (filterCreationDate) {
/* 1011 */       if (resultFilter.getCreationDateRangeMin() != null) {
/* 1012 */         query.append(" AND creationDate >= ?");
/* 1013 */         pstmt.addLong(resultFilter.getCreationDateRangeMin().getTime());
/*      */       }
/* 1015 */       if (resultFilter.getCreationDateRangeMax() != null) {
/* 1016 */         query.append(" AND creationDate <= ?");
/* 1017 */         pstmt.addLong(resultFilter.getCreationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1022 */     if (filterModifiedDate) {
/* 1023 */       if (resultFilter.getModificationDateRangeMin() != null) {
/* 1024 */         query.append(" AND modificationDate >= ?");
/* 1025 */         pstmt.addLong(resultFilter.getModificationDateRangeMin().getTime());
/*      */       }
/* 1027 */       if (resultFilter.getModificationDateRangeMax() != null) {
/* 1028 */         query.append(" AND modificationDate <= ?");
/* 1029 */         pstmt.addLong(resultFilter.getModificationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1035 */     if (!moderationDisabled()) {
/* 1036 */       int moderationRangeMin = resultFilter.getModerationRangeMin();
/*      */ 
/* 1039 */       if (moderationRangeMin == 2147483524) {
/* 1040 */         moderationRangeMin = 1;
/*      */       }
/* 1042 */       int moderationRangeMax = resultFilter.getModerationRangeMax();
/* 1043 */       if (moderationRangeMin == moderationRangeMax) {
/* 1044 */         query.append(" AND modValue = ?");
/* 1045 */         pstmt.addInt(moderationRangeMin);
/*      */       }
/*      */       else
/*      */       {
/* 1049 */         if (moderationRangeMin > -1000000) {
/* 1050 */           query.append(" AND modValue >= ?");
/* 1051 */           pstmt.addInt(moderationRangeMin);
/*      */         }
/*      */ 
/* 1054 */         if (moderationRangeMax != 2147483524) {
/* 1055 */           query.append(" AND modValue <= ?");
/* 1056 */           pstmt.addInt(moderationRangeMax);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1062 */     if (!countQuery) {
/* 1063 */       switch (sortField) {
/*      */       case 6:
/* 1065 */         query.append(" ORDER BY subject");
/* 1066 */         break;
/*      */       case 9:
/* 1068 */         query.append(" ORDER BY modificationDate");
/* 1069 */         break;
/*      */       case 8:
/* 1071 */         query.append(" ORDER BY creationDate");
/* 1072 */         break;
/*      */       case 10:
/* 1074 */         query.append(" ORDER BY propTable.propValue");
/*      */       case 7:
/*      */       }
/* 1077 */       if (resultFilter.getSortOrder() == 0) {
/* 1078 */         query.append(" DESC");
/*      */       }
/*      */       else {
/* 1081 */         query.append(" ASC");
/*      */       }
/*      */     }
/*      */ 
/* 1085 */     pstmt.setSQL(query.toString());
/* 1086 */     return pstmt;
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbForumFactory
 * JD-Core Version:    0.6.2
 */
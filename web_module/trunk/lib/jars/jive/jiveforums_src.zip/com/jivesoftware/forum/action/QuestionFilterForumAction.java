/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.Question;
/*     */ import com.jivesoftware.forum.Question.State;
/*     */ import com.jivesoftware.forum.QuestionFilter;
/*     */ import com.jivesoftware.forum.QuestionManager;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.opensymphony.webwork.interceptor.SessionAware;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class QuestionFilterForumAction extends ForumAction
/*     */   implements SessionAware
/*     */ {
/*     */   public static final String FILTER_KEY = "jive.filter";
/*     */   public static final String ALL = "all";
/*     */   public static final String OPEN_QUESTIONS = "open";
/*     */   public static final String ANSWERED_QUESTIONS = "answered";
/*     */   private Map session;
/*     */   private String filter;
/*     */   private QuestionManager qman;
/*     */   private QuestionFilter questionFilter;
/*     */   private Iterator threads;
/*     */   private int totalItems;
/*     */ 
/*     */   public QuestionFilterForumAction()
/*     */   {
/*  46 */     this.totalItems = -1;
/*     */   }
/*     */   public QuestionManager getQuestionManager() {
/*  49 */     return this.qman;
/*     */   }
/*     */ 
/*     */   public String getFilter() {
/*  53 */     return this.filter;
/*     */   }
/*     */ 
/*     */   public void setFilter(String filter) {
/*  57 */     this.filter = filter;
/*     */   }
/*     */ 
/*     */   public int getTotalItemCount() {
/*  61 */     if (this.totalItems == -1) {
/*  62 */       return super.getTotalItemCount();
/*     */     }
/*     */ 
/*  65 */     return this.totalItems;
/*     */   }
/*     */ 
/*     */   public Iterator getThreads()
/*     */   {
/*  70 */     if (this.threads != null) {
/*  71 */       return this.threads;
/*     */     }
/*     */ 
/*  74 */     return super.getThreads();
/*     */   }
/*     */ 
/*     */   public void setSession(Map session)
/*     */   {
/*  79 */     this.session = session;
/*     */   }
/*     */ 
/*     */   public String execute() throws Exception {
/*  83 */     if (this.filter == null)
/*     */     {
/*  85 */       this.filter = ((String)this.session.get("jive.filter.forum." + getForumID()));
/*     */     }
/*  87 */     if (this.filter != null) {
/*  88 */       if (("open".equals(this.filter)) || ("answered".equals(this.filter))) {
/*  89 */         this.qman = getForumFactory().getQuestionManager();
/*  90 */         ResultFilter parentFilter = getResultFilter();
/*  91 */         this.questionFilter = new QuestionFilter();
/*  92 */         this.questionFilter.clearResolutionStates();
/*  93 */         this.questionFilter.setNumResults(parentFilter.getNumResults());
/*  94 */         this.questionFilter.setStartIndex(parentFilter.getStartIndex());
/*  95 */         if ("open".equals(this.filter)) {
/*  96 */           this.questionFilter.addResolutionState(Question.State.open);
/*  97 */           this.questionFilter.addResolutionState(Question.State.possibly_resolved);
/*     */         }
/*  99 */         else if ("answered".equals(this.filter)) {
/* 100 */           this.questionFilter.addResolutionState(Question.State.resolved);
/* 101 */           this.questionFilter.addResolutionState(Question.State.assumed_resolved);
/*     */         }
/* 103 */         Iterator questions = this.qman.getQuestions(getForum(), this.questionFilter);
/* 104 */         this.threads = new QuestionIterator(questions);
/* 105 */         this.totalItems = this.qman.getQuestionCount(getForum(), this.questionFilter);
/* 106 */         this.session.put("jive.filter.forum." + getForumID(), this.filter);
/* 107 */         if ((getStart() > 0) && (!this.threads.hasNext())) {
/* 108 */           setStart(0);
/* 109 */           this.questionFilter.setStartIndex(0);
/* 110 */           this.threads = new QuestionIterator(this.qman.getQuestions(getForum(), this.questionFilter));
/*     */         }
/*     */       }
/* 113 */       else if ("all".equals(this.filter))
/*     */       {
/* 115 */         this.session.remove("jive.filter.forum." + getForumID());
/* 116 */         return "all";
/*     */       }
/*     */     }
/* 119 */     return super.execute();
/*     */   }
/*     */ 
/*     */   public class QuestionIterator implements Iterator
/*     */   {
/*     */     private Iterator questions;
/*     */ 
/*     */     public QuestionIterator(Iterator questions) {
/* 127 */       this.questions = questions;
/*     */     }
/*     */ 
/*     */     public void remove() {
/* 131 */       throw new UnsupportedOperationException("Remove not supported.");
/*     */     }
/*     */ 
/*     */     public boolean hasNext() {
/* 135 */       return this.questions.hasNext();
/*     */     }
/*     */ 
/*     */     public Object next() {
/* 139 */       Question question = (Question)this.questions.next();
/* 140 */       ForumThread thread = null;
/* 141 */       if (question != null) {
/* 142 */         thread = question.getForumThread();
/*     */       }
/* 144 */       return thread;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.QuestionFilterForumAction
 * JD-Core Version:    0.6.2
 */
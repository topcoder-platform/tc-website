package com.jivesoftware.forum;

import com.jivesoftware.base.UnauthorizedException;
import com.jivesoftware.base.User;
import java.util.Iterator;

public abstract interface RatingManager
{
  public abstract boolean isRatingsEnabled();

  public abstract void setRatingsEnabled(boolean paramBoolean)
    throws UnauthorizedException;

  public abstract Iterator getAvailableRatings();

  public abstract int getAvailableRatingCount();

  public abstract Rating getRatingFromScore(int paramInt);

  public abstract Rating createRating(int paramInt, String paramString)
    throws UnauthorizedException;

  public abstract void removeRating(Rating paramRating)
    throws UnauthorizedException;

  public abstract Iterator getRatings(ForumMessage paramForumMessage);

  public abstract Iterator getRatings(ForumThread paramForumThread);

  public abstract int getRatingCount(ForumMessage paramForumMessage);

  public abstract int getRatingCount(ForumThread paramForumThread);

  public abstract double getMeanRating(long paramLong);

  public abstract double getMeanRating(ForumMessage paramForumMessage);

  public abstract double getMeanRating(ForumThread paramForumThread);

  public abstract boolean hasRated(User paramUser, ForumMessage paramForumMessage);

  public abstract boolean hasRated(User paramUser, ForumThread paramForumThread);

  public abstract Rating getRating(User paramUser, ForumMessage paramForumMessage);

  public abstract Rating getRating(User paramUser, ForumThread paramForumThread);

  public abstract void addRating(User paramUser, ForumMessage paramForumMessage, Rating paramRating)
    throws UnauthorizedException;

  public abstract void addRating(User paramUser, ForumThread paramForumThread, Rating paramRating)
    throws UnauthorizedException;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.RatingManager
 * JD-Core Version:    0.6.2
 */
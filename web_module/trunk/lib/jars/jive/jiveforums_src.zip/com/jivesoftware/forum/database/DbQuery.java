/*      */ package com.jivesoftware.forum.database;
/*      */ 
/*      */ import com.jivesoftware.base.JiveGlobals;
/*      */ import com.jivesoftware.base.Log;
/*      */ import com.jivesoftware.base.NotFoundException;
/*      */ import com.jivesoftware.base.User;
/*      */ import com.jivesoftware.base.UserManager;
/*      */ import com.jivesoftware.base.UserNotFoundException;
/*      */ import com.jivesoftware.base.database.ConnectionManager;
/*      */ import com.jivesoftware.base.database.sequence.SequenceManager;
/*      */ import com.jivesoftware.forum.Attachment;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumCategory;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*      */ import com.jivesoftware.forum.ForumNotFoundException;
/*      */ import com.jivesoftware.forum.ForumThread;
/*      */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*      */ import com.jivesoftware.forum.QueryResult;
/*      */ import com.jivesoftware.forum.SearchManager;
/*      */ import com.jivesoftware.forum.Version;
/*      */ import com.jivesoftware.forum.Version.Edition;
/*      */ import com.jivesoftware.util.Cache;
/*      */ import com.jivesoftware.util.CacheSizes;
/*      */ import com.jivesoftware.util.Cacheable;
/*      */ import com.jivesoftware.util.ClassUtils;
/*      */ import com.jivesoftware.util.LongList;
/*      */ import com.jivesoftware.util.ReadWriteLock;
/*      */ import com.jivesoftware.util.StringUtils;
/*      */ import com.jivesoftware.util.search.CachedFilter;
/*      */ import com.jivesoftware.util.search.FieldFilter;
/*      */ import com.jivesoftware.util.search.MultiFilter;
/*      */ import com.jivesoftware.util.search.MultiFilter.FilterType;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.StringReader;
/*      */ import java.lang.reflect.Method;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.lucene.analysis.Analyzer;
/*      */ import org.apache.lucene.analysis.TokenStream;
/*      */ import org.apache.lucene.document.DateField;
/*      */ import org.apache.lucene.document.Document;
/*      */ import org.apache.lucene.index.Term;
/*      */ import org.apache.lucene.queryParser.ParseException;
/*      */ import org.apache.lucene.queryParser.QueryParser;
/*      */ import org.apache.lucene.search.BooleanQuery;
/*      */ import org.apache.lucene.search.DateFilter;
/*      */ import org.apache.lucene.search.Filter;
/*      */ import org.apache.lucene.search.Hits;
/*      */ import org.apache.lucene.search.Searcher;
/*      */ import org.apache.lucene.search.TermQuery;
/*      */ import org.apache.lucene.search.highlight.Highlighter;
/*      */ import org.apache.lucene.search.highlight.QueryScorer;
/*      */ import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
/*      */ 
/*      */ public class DbQuery
/*      */   implements com.jivesoftware.forum.Query, Cacheable
/*      */ {
/*  106 */   protected static final int MAX_RESULTS_SIZE = maxSize;
/*      */   private static final String LOAD_QUERY = "SELECT userID, query, searchDuration, numResults, searchDate FROM jiveSearch WHERE searchID=?";
/*      */   private static final String LOAD_QUERY_CONSTRAINTS = "SELECT criteriaName, criteriaValue FROM jiveSearchCriteria WHERE searchID=?";
/*   60 */   private String queryString = null;
/*   61 */   private long id = -1L;
/*   62 */   private long userID = -1L;
/*   63 */   private int searchDuration = 0;
/*   64 */   private long filteredUserID = -1L;
/*      */   private long[] forumIDs;
/*   66 */   private long threadID = -1L;
/*      */   private Date searchDate;
/*      */   private Date beforeDate;
/*      */   private Date afterDate;
/*   70 */   private boolean hasLogged = false;
/*      */ 
/*   72 */   private int sortField = 10001;
/*   73 */   private int sortOrder = 1;
/*      */ 
/*   78 */   private transient List results = new ArrayList();
/*      */ 
/*   83 */   private transient List resultMessagesByThread = new ArrayList();
/*      */ 
/*   88 */   private transient Set resultForums = new HashSet();
/*      */   private transient org.apache.lucene.search.Query query;
/*      */ 
/*      */   public DbQuery(Forum[] forums)
/*      */   {
/*  111 */     if (forums == null) {
/*  112 */       this.forumIDs = null;
/*  113 */       return;
/*      */     }
/*      */ 
/*  116 */     LongList forumIDs = new LongList();
/*  117 */     for (int i = 0; i < forums.length; i++) {
/*  118 */       forumIDs.add(forums[i].getID());
/*      */     }
/*  120 */     this.forumIDs = forumIDs.toArray();
/*      */   }
/*      */ 
/*      */   protected DbQuery(long id)
/*      */     throws NotFoundException
/*      */   {
/*  130 */     Connection con = null;
/*  131 */     PreparedStatement pstmt = null;
/*      */     try
/*      */     {
/*  134 */       con = ConnectionManager.getConnection();
/*  135 */       pstmt = con.prepareStatement("SELECT userID, query, searchDuration, numResults, searchDate FROM jiveSearch WHERE searchID=?");
/*  136 */       pstmt.setLong(1, id);
/*  137 */       ResultSet rs = pstmt.executeQuery();
/*  138 */       if (rs.next()) {
/*  139 */         this.id = id;
/*  140 */         if (rs.getLong(1) != 0L) {
/*  141 */           this.userID = rs.getLong(1);
/*      */         }
/*  143 */         String q = rs.getString(2);
/*  144 */         if (!"*".equals(q)) {
/*  145 */           this.queryString = q;
/*      */         }
/*  147 */         this.searchDuration = rs.getInt(3);
/*  148 */         this.searchDate = new Date(rs.getLong(5));
/*      */       }
/*      */       else {
/*  151 */         throw new NotFoundException();
/*      */       }
/*      */ 
/*  154 */       rs.close();
/*  155 */       pstmt = con.prepareStatement("SELECT criteriaName, criteriaValue FROM jiveSearchCriteria WHERE searchID=?");
/*  156 */       pstmt.setLong(1, id);
/*  157 */       rs = pstmt.executeQuery();
/*  158 */       while (rs.next()) {
/*  159 */         String key = rs.getString(1);
/*  160 */         String value = rs.getString(2);
/*      */ 
/*  162 */         if ("beforeDate".equals(key)) try {
/*  163 */             this.beforeDate = new Date(Long.parseLong(value.trim())); } catch (NumberFormatException e) {
/*  164 */             Log.error(e);
/*      */           }
/*  166 */         else if ("afterDate".equals(key)) try {
/*  167 */             this.afterDate = new Date(Long.parseLong(value.trim())); } catch (NumberFormatException e) {
/*  168 */             Log.error(e);
/*      */           }
/*  170 */         else if ("filteredUserID".equals(key)) try {
/*  171 */             this.filteredUserID = Long.parseLong(value.trim()); } catch (NumberFormatException e) {
/*  172 */             Log.error(e);
/*      */           }
/*  174 */         else if ("threadID".equals(key)) try {
/*  175 */             this.threadID = Long.parseLong(value.trim()); } catch (NumberFormatException e) {
/*  176 */             Log.error(e);
/*      */           }
/*  178 */         else if ("forumID".equals(key)) {
/*  179 */           if (this.forumIDs == null) {
/*  180 */             this.forumIDs = new long[] { Long.parseLong(value.trim()) };
/*      */           }
/*      */           else {
/*  183 */             LongList l = new LongList(this.forumIDs);
/*  184 */             l.add(Long.parseLong(value.trim()));
/*  185 */             this.forumIDs = l.toArray();
/*      */           }
/*      */         }
/*  188 */         else if ("sortField".equals(key)) try {
/*  189 */             this.sortField = Integer.parseInt(value.trim()); } catch (NumberFormatException e) {
/*  190 */             Log.error(e);
/*      */           }
/*  192 */         else if ("sortOrder".equals(key)) {
/*  193 */           this.sortOrder = ("0".equals(value.trim()) ? 0 : 1);
/*      */         }
/*      */       }
/*      */ 
/*  197 */       rs.close();
/*      */     } catch (SQLException e) {
/*  199 */       Log.error(e);
/*      */     } finally {
/*  201 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/*  204 */     this.hasLogged = true;
/*      */   }
/*      */ 
/*      */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/*  208 */     in.defaultReadObject();
/*  209 */     this.results = new ArrayList();
/*  210 */     this.resultMessagesByThread = new ArrayList();
/*      */   }
/*      */ 
/*      */   public long getID() {
/*  214 */     return this.id;
/*      */   }
/*      */ 
/*      */   public long getUserID() {
/*  218 */     return this.userID;
/*      */   }
/*      */ 
/*      */   public User getUser() {
/*  222 */     if (this.userID != -1L) {
/*      */       try {
/*  224 */         return DbForumFactory.getInstance().getUserManager().getUser(this.userID);
/*      */       }
/*      */       catch (UserNotFoundException e) {
/*  227 */         Log.error(e);
/*      */       }
/*      */     }
/*      */ 
/*  231 */     return null;
/*      */   }
/*      */ 
/*      */   public int getObjectType() {
/*  235 */     return 19;
/*      */   }
/*      */ 
/*      */   public Date getSearchDate() {
/*  239 */     return this.searchDate;
/*      */   }
/*      */ 
/*      */   public int getSearchDuration() {
/*  243 */     return this.searchDuration;
/*      */   }
/*      */ 
/*      */   public Forum[] getForums() {
/*  247 */     if (this.forumIDs == null) {
/*  248 */       return null;
/*      */     }
/*      */ 
/*  251 */     Forum[] forums = new Forum[this.forumIDs.length];
/*  252 */     for (int i = 0; i < this.forumIDs.length; i++) {
/*  253 */       long forumID = this.forumIDs[i];
/*      */       try {
/*  255 */         forums[i] = DbForumFactory.getInstance().getForum(forumID);
/*      */       }
/*      */       catch (ForumNotFoundException e) {
/*  258 */         Log.error(e);
/*      */       }
/*      */     }
/*      */ 
/*  262 */     return forums;
/*      */   }
/*      */ 
/*      */   public void setQueryString(String queryString) {
/*  266 */     if (queryString == null) {
/*  267 */       resetResults();
/*  268 */       return;
/*      */     }
/*      */ 
/*  271 */     SearchManager searchManager = DbForumFactory.getInstance().getSearchManager();
/*  272 */     boolean wildcardIgnored = searchManager.isWildcardIgnored();
/*  273 */     this.queryString = (wildcardIgnored ? stripWildcards(queryString) : queryString);
/*      */ 
/*  279 */     if ((!wildcardIgnored) && (containsWildcards(queryString))) {
/*  280 */       this.queryString = lowerCaseQueryString(this.queryString);
/*      */     }
/*      */ 
/*  283 */     resetResults();
/*      */   }
/*      */ 
/*      */   public String getQueryString() {
/*  287 */     return this.queryString;
/*      */   }
/*      */ 
/*      */   public void setBeforeDate(Date beforeDate) {
/*  291 */     this.beforeDate = beforeDate;
/*  292 */     resetResults();
/*      */   }
/*      */ 
/*      */   public Date getBeforeDate() {
/*  296 */     return this.beforeDate;
/*      */   }
/*      */ 
/*      */   public void setAfterDate(Date afterDate) {
/*  300 */     this.afterDate = afterDate;
/*  301 */     resetResults();
/*      */   }
/*      */ 
/*      */   public Date getAfterDate() {
/*  305 */     return this.afterDate;
/*      */   }
/*      */ 
/*      */   public long[] getForumIDs() {
/*  309 */     if ((this.forumIDs == null) || (this.forumIDs.length < 1)) {
/*  310 */       return null;
/*      */     }
/*      */ 
/*  313 */     long[] copy = new long[this.forumIDs.length];
/*  314 */     System.arraycopy(this.forumIDs, 0, copy, 0, this.forumIDs.length);
/*  315 */     return copy;
/*      */   }
/*      */ 
/*      */   public User getFilteredUser() {
/*  319 */     if (this.filteredUserID == -1L) {
/*  320 */       return null;
/*      */     }
/*      */     try
/*      */     {
/*  324 */       return DbForumFactory.getInstance().getUserManager().getUser(this.filteredUserID);
/*      */     }
/*      */     catch (UserNotFoundException e) {
/*  327 */       Log.error(e);
/*      */     }
/*      */ 
/*  330 */     return null;
/*      */   }
/*      */ 
/*      */   public void filterOnUser(User user) {
/*  334 */     if (user == null) {
/*  335 */       this.filteredUserID = -1L;
/*      */     }
/*      */     else {
/*  338 */       this.filteredUserID = user.getID();
/*      */     }
/*      */ 
/*  341 */     resetResults();
/*      */   }
/*      */ 
/*      */   public ForumThread getFilteredThread() {
/*  345 */     if (this.threadID == -1L) {
/*  346 */       return null;
/*      */     }
/*      */     try
/*      */     {
/*  350 */       return DbForumFactory.getInstance().getForumThread(this.threadID);
/*      */     }
/*      */     catch (ForumThreadNotFoundException e) {
/*  353 */       Log.error(e);
/*      */     }
/*      */ 
/*  356 */     return null;
/*      */   }
/*      */ 
/*      */   public void filterOnThread(ForumThread thread) {
/*  360 */     if (thread == null) {
/*  361 */       this.threadID = -1L;
/*      */     }
/*      */     else {
/*  364 */       this.threadID = thread.getID();
/*      */     }
/*  366 */     resetResults();
/*      */   }
/*      */ 
/*      */   public int getSortField() {
/*  370 */     return this.sortField;
/*      */   }
/*      */ 
/*      */   public void setSortField(int sortField) {
/*  374 */     this.sortField = sortField;
/*      */   }
/*      */ 
/*      */   public int getSortOrder() {
/*  378 */     return this.sortOrder;
/*      */   }
/*      */ 
/*      */   public void setSortOrder(int sortOrder) {
/*  382 */     this.sortOrder = sortOrder;
/*      */   }
/*      */ 
/*      */   public int getResultCount() {
/*  386 */     if ((getQueryString() == null) && (this.filteredUserID == -1L)) {
/*  387 */       return 0;
/*      */     }
/*      */ 
/*  390 */     if (this.results.isEmpty()) {
/*  391 */       executeQuery();
/*      */     }
/*  393 */     return this.results.size();
/*      */   }
/*      */ 
/*      */   public int getResultByThreadCount() {
/*  397 */     if (this.resultMessagesByThread.isEmpty()) {
/*  398 */       loadResultsByThread();
/*      */     }
/*  400 */     return this.resultMessagesByThread.size();
/*      */   }
/*      */ 
/*      */   public Iterator getResults() {
/*  404 */     if ((getQueryString() == null) && (this.filteredUserID == -1L)) {
/*  405 */       return Collections.EMPTY_LIST.iterator();
/*      */     }
/*      */ 
/*  408 */     if (this.results.isEmpty()) {
/*  409 */       executeQuery();
/*      */     }
/*      */ 
/*  412 */     if (this.results.size() > 1) {
/*  413 */       Collections.sort(this.results, new QueryResultComparator(this));
/*      */     }
/*      */ 
/*  416 */     return this.results.iterator();
/*      */   }
/*      */ 
/*      */   public Iterator getResults(int startIndex, int numResults) {
/*  420 */     if ((startIndex < 0) || (numResults < 0)) {
/*  421 */       throw new IllegalArgumentException("Parameter value can't be less than 0.");
/*      */     }
/*      */ 
/*  424 */     if ((getQueryString() == null) && (this.filteredUserID == -1L)) {
/*  425 */       return Collections.EMPTY_LIST.iterator();
/*      */     }
/*      */ 
/*  428 */     if (this.results.isEmpty()) {
/*  429 */       executeQuery();
/*      */     }
/*      */ 
/*  432 */     int endIndex = startIndex + numResults - 1;
/*  433 */     if (endIndex > this.results.size() - 1) {
/*  434 */       endIndex = this.results.size() - 1;
/*      */     }
/*      */ 
/*  437 */     if (endIndex - startIndex + 1 <= 0) {
/*  438 */       return Collections.EMPTY_LIST.iterator();
/*      */     }
/*      */ 
/*  441 */     if (this.results.size() > 1) {
/*  442 */       Collections.sort(this.results, new QueryResultComparator(this));
/*      */     }
/*      */ 
/*  445 */     return this.results.subList(startIndex, endIndex + 1).iterator();
/*      */   }
/*      */ 
/*      */   public Iterator getResultsByThread()
/*      */   {
/*  450 */     if (this.resultMessagesByThread.isEmpty()) {
/*  451 */       loadResultsByThread();
/*      */     }
/*      */ 
/*  454 */     if (this.resultMessagesByThread.size() > 1) {
/*  455 */       Collections.sort(this.resultMessagesByThread, new QueryResultComparator(this));
/*      */     }
/*      */ 
/*  458 */     return this.resultMessagesByThread.iterator();
/*      */   }
/*      */ 
/*      */   public Iterator getResultsByThread(int startIndex, int numResults) {
/*  462 */     if (this.resultMessagesByThread.isEmpty()) {
/*  463 */       loadResultsByThread();
/*      */     }
/*      */ 
/*  466 */     int endIndex = startIndex + numResults - 1;
/*  467 */     if (endIndex > this.resultMessagesByThread.size() - 1) {
/*  468 */       endIndex = this.resultMessagesByThread.size() - 1;
/*      */     }
/*      */ 
/*  471 */     if (endIndex - startIndex + 1 <= 0) {
/*  472 */       return Collections.EMPTY_LIST.iterator();
/*      */     }
/*      */ 
/*  475 */     if (this.resultMessagesByThread.size() > 1) {
/*  476 */       Collections.sort(this.resultMessagesByThread, new QueryResultComparator(this));
/*      */     }
/*      */ 
/*  479 */     return this.resultMessagesByThread.subList(startIndex, endIndex + 1).iterator();
/*      */   }
/*      */ 
/*      */   public Iterator getResultForums()
/*      */   {
/*  484 */     if ((getQueryString() == null) && (this.filteredUserID == -1L)) {
/*  485 */       return Collections.EMPTY_LIST.iterator();
/*      */     }
/*      */ 
/*  488 */     if (this.results.isEmpty()) {
/*  489 */       executeQuery();
/*      */     }
/*      */ 
/*  492 */     Long[] longForumIDs = (Long[])this.resultForums.toArray(new Long[this.resultForums.size()]);
/*  493 */     long[] forumIDs = new long[longForumIDs.length];
/*  494 */     for (int i = 0; i < forumIDs.length; i++) {
/*  495 */       forumIDs[i] = longForumIDs[i].longValue();
/*      */     }
/*  497 */     return new DatabaseObjectIterator(0, forumIDs, DbForumFactory.getInstance());
/*      */   }
/*      */ 
/*      */   public String[] highlightResult(QueryResult result, String preTag, String postTag)
/*      */   {
/*  502 */     if (this.results.isEmpty()) {
/*  503 */       getResults();
/*      */     }
/*      */ 
/*  506 */     ForumMessage message = null;
/*  507 */     Highlighter highlighter = null;
/*      */     try
/*      */     {
/*  510 */       DbSearchManager.searcherLock.acquireReadLock();
/*  511 */       message = result.getMessage();
/*      */ 
/*  514 */       if (getQueryString() == null) {
/*  515 */         String title = StringUtils.stripTags(message.getSubject());
/*  516 */         String body = message.getBody();
/*      */         String[] arrayOfString;
/*  518 */         if (body != null) {
/*  519 */           body = StringUtils.stripTags(StringUtils.replace(body, "<br><br>", " .. "));
/*  520 */           body = StringUtils.chopAtWord(body, 200);
/*  521 */           body = body + " ...";
/*      */ 
/*  523 */           return new String[] { title, body };
/*      */         }
/*      */ 
/*  526 */         return new String[] { title, "" };
/*      */       }
/*      */ 
/*  530 */       Analyzer analyzer = DbSearchManager.searcherAnalyzer;
/*  531 */       highlighter = new Highlighter(new SimpleHTMLFormatter(preTag, postTag), new QueryScorer(this.query));
/*      */ 
/*  534 */       String subject = StringUtils.stripTags(message.getSubject());
/*  535 */       TokenStream tokenStream = null;
/*  536 */       tokenStream = analyzer.tokenStream(null, new StringReader(subject));
/*  537 */       String highlightedSubject = highlighter.getBestFragment(tokenStream, subject);
/*      */ 
/*  540 */       highlightedSubject = highlightedSubject == null ? subject : highlightedSubject;
/*      */ 
/*  542 */       int maxNumFragmentsRequired = 4;
/*  543 */       String fragmentSeparator = " ...";
/*  544 */       String highlightedText = "";
/*      */ 
/*  547 */       if (message.getBody() != null) {
/*  548 */         tokenStream = analyzer.tokenStream(null, new StringReader(message.getBody()));
/*  549 */         highlightedText = highlighter.getBestFragments(tokenStream, message.getBody(), maxNumFragmentsRequired, fragmentSeparator);
/*      */       }
/*      */ 
/*  554 */       DbSearchManager searchManager = (DbSearchManager)DbForumFactory.getInstance().getSearchManager();
/*      */ 
/*  556 */       if (("".equals(highlightedText)) && (searchManager.isAttachmentSearchEnabled()))
/*      */       {
/*  558 */         StringBuffer buffer = new StringBuffer(4096);
/*  559 */         Iterator attachments = message.getAttachments();
/*      */ 
/*  561 */         while (attachments.hasNext()) {
/*  562 */           buffer.append(DbAttachmentSearchIndexer.getAttachmentContent((Attachment)attachments.next()));
/*  563 */           buffer.append(" ");
/*      */         }
/*      */ 
/*  566 */         String bufferText = buffer.toString();
/*  567 */         tokenStream = analyzer.tokenStream(null, new StringReader(bufferText));
/*  568 */         highlightedText = highlighter.getBestFragments(tokenStream, bufferText, maxNumFragmentsRequired, fragmentSeparator);
/*      */       }
/*      */       String body;
/*  572 */       if ("".equals(highlightedText)) {
/*  573 */         body = message.getBody();
/*      */ 
/*  575 */         if (body != null) {
/*  576 */           body = StringUtils.stripTags(StringUtils.replace(body, "<br><br>", " .. "));
/*  577 */           body = StringUtils.chopAtWord(body, 200);
/*  578 */           body = body + " ...";
/*      */ 
/*  580 */           highlightedText = body;
/*      */         }
/*      */       }
/*      */ 
/*  584 */       return new String[] { highlightedSubject, highlightedText };
/*      */     }
/*      */     catch (ForumMessageNotFoundException e) {
/*  587 */       Log.error(e);
/*      */     }
/*      */     catch (IOException e) {
/*  590 */       Log.error(e);
/*      */     }
/*      */     finally {
/*  593 */       DbSearchManager.searcherLock.releaseReadLock();
/*      */     }
/*      */ 
/*  596 */     return new String[] { result.getSubject(), "" };
/*      */   }
/*      */ 
/*      */   public long logQuery(User user) {
/*  600 */     if ((Version.getEdition() == Version.Edition.LITE) || (Version.getEdition() == Version.Edition.PROFESSIONAL))
/*      */     {
/*  603 */       return this.id;
/*      */     }
/*  605 */     if (!JiveGlobals.getJiveBooleanProperty("search.querylogging.enabled", true)) {
/*  606 */       return this.id;
/*      */     }
/*      */ 
/*  609 */     if (!this.hasLogged)
/*      */     {
/*  611 */       if ((this.id == -1L) && (this.searchDate != null) && (this.queryString != null))
/*      */       {
/*      */         try
/*      */         {
/*  615 */           Class clazz = ClassUtils.forName("com.jivesoftware.forum.database.DbQueryLogger");
/*  616 */           Method m1 = clazz.getMethod("getInstance", (Class[])null);
/*  617 */           Method m2 = clazz.getMethod("logQuery", new Class[] { User.class, DbQuery.class });
/*  618 */           Object clazz2 = m1.invoke(null, (Object[])null);
/*  619 */           this.id = SequenceManager.nextID(23);
/*  620 */           m2.invoke(clazz2, new Object[] { user, this });
/*  621 */           this.hasLogged = true;
/*      */         }
/*      */         catch (Exception e) {
/*  624 */           Log.error(e);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  629 */     return this.id;
/*      */   }
/*      */ 
/*      */   public void logSearchClick(long searchID, long messageID) {
/*  633 */     if ((Version.getEdition() == Version.Edition.LITE) || (Version.getEdition() == Version.Edition.PROFESSIONAL))
/*      */     {
/*  636 */       return;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  642 */       Class clazz = ClassUtils.forName("com.jivesoftware.forum.database.DbQueryLogger");
/*  643 */       Method m1 = clazz.getMethod("getInstance", (Class[])null);
/*  644 */       Method m2 = clazz.getMethod("logSearchClick", new Class[] { Long.TYPE, Long.TYPE });
/*  645 */       Object clazz2 = m1.invoke(null, (Object[])null);
/*  646 */       m2.invoke(clazz2, (Object[])new Long[] { new Long(searchID), new Long(messageID) });
/*      */     }
/*      */     catch (Exception e) {
/*  649 */       Log.error(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getCachedSize() {
/*  654 */     int size = 0;
/*  655 */     size += CacheSizes.sizeOfObject();
/*  656 */     size += CacheSizes.sizeOfString(this.queryString);
/*  657 */     size += CacheSizes.sizeOfLong() * 4;
/*  658 */     size += CacheSizes.sizeOfDate() * 3;
/*  659 */     size += CacheSizes.sizeOfBoolean() * 2;
/*  660 */     size += CacheSizes.sizeOfInt() * 3;
/*  661 */     if (this.forumIDs != null) {
/*  662 */       size += CacheSizes.sizeOfLong() + this.forumIDs.length;
/*      */     }
/*  664 */     return size;
/*      */   }
/*      */ 
/*      */   public boolean equals(com.jivesoftware.forum.Query query)
/*      */   {
/*  669 */     if (this == query) {
/*  670 */       return true;
/*      */     }
/*      */ 
/*  673 */     if (query != null) {
/*  674 */       return this.id == query.getID();
/*      */     }
/*      */ 
/*  677 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object o) {
/*  681 */     if (this == o) {
/*  682 */       return true;
/*      */     }
/*  684 */     if (!(o instanceof Cacheable)) {
/*  685 */       return false;
/*      */     }
/*      */ 
/*  688 */     return equals((Cacheable)o);
/*      */   }
/*      */ 
/*      */   public int hashCode() {
/*  692 */     return (int)(this.id ^ this.id >>> 32);
/*      */   }
/*      */ 
/*      */   private void executeQuery()
/*      */   {
/*  699 */     long startTime = System.currentTimeMillis();
/*      */     try
/*      */     {
/*  704 */       DbSearchManager.searcherLock.acquireReadLock();
/*  705 */       Searcher searcher = DbSearchManager.getSearcher();
/*  706 */       if (searcher == null)
/*      */       {
/*  708 */         resetResults();
/*      */         return;
/*      */       }
/*  712 */       BooleanQuery comboQuery = null;
/*  713 */       org.apache.lucene.search.Query userQuery = null;
/*      */ 
/*  715 */       if ((this.queryString != null) && (!this.queryString.equals(""))) {
/*  716 */         String cleanQueryString = escapeBadCharacters(this.queryString);
/*      */ 
/*  719 */         QueryParser bodyQP = new QueryParser("body", DbSearchManager.searcherAnalyzer);
/*  720 */         QueryParser subjectQP = new QueryParser("subject", DbSearchManager.searcherAnalyzer);
/*      */ 
/*  723 */         if ("AND".equals(JiveGlobals.getJiveProperty("search.defaultOperator"))) {
/*  724 */           bodyQP.setOperator(1);
/*  725 */           subjectQP.setOperator(1);
/*      */         }
/*      */ 
/*  728 */         org.apache.lucene.search.Query bodyQuery = bodyQP.parse(cleanQueryString);
/*      */ 
/*  730 */         org.apache.lucene.search.Query subjectQuery = subjectQP.parse(cleanQueryString);
/*      */ 
/*  732 */         comboQuery = new BooleanQuery();
/*  733 */         comboQuery.add(subjectQuery, false, false);
/*  734 */         comboQuery.add(bodyQuery, false, false);
/*  735 */         if (DbForumFactory.getInstance().getSearchManager().isAttachmentSearchEnabled()) {
/*  736 */           org.apache.lucene.search.Query attachmentsQuery = QueryParser.parse(cleanQueryString, "attachmentsText", DbSearchManager.searcherAnalyzer);
/*      */ 
/*  739 */           comboQuery.add(attachmentsQuery, false, false);
/*      */         }
/*      */       }
/*  742 */       else if (this.filteredUserID != -1L) {
/*  743 */         userQuery = new TermQuery(new Term("userID", "" + this.filteredUserID));
/*      */       }
/*      */ 
/*  746 */       MultiFilter multiFilter = new MultiFilter(3);
/*  747 */       int filterCount = 0;
/*      */ 
/*  751 */       if ((this.forumIDs != null) && (DbForumFactory.getInstance().getRootForumCategory().getRecursiveForumCount() != this.forumIDs.length))
/*      */       {
/*  756 */         MultiFilter allForumsFilter = new MultiFilter(this.forumIDs.length, MultiFilter.FilterType.OR);
/*  757 */         for (int i = 0; i < this.forumIDs.length; i++) {
/*  758 */           String fID = Long.toString(this.forumIDs[i]);
/*  759 */           Filter filter = (Filter)DbQueryManager.filterCache.get("fID:" + fID);
/*  760 */           if (filter == null) {
/*  761 */             filter = new CachedFilter(new FieldFilter("forumID", fID));
/*  762 */             DbQueryManager.filterCache.put("fID:" + fID, filter);
/*      */           }
/*  764 */           allForumsFilter.add(filter);
/*      */         }
/*  766 */         multiFilter.add(allForumsFilter);
/*  767 */         filterCount++;
/*      */       }
/*      */ 
/*  771 */       if ((this.beforeDate != null) || (this.afterDate != null)) {
/*  772 */         if ((this.beforeDate != null) && (this.afterDate != null)) {
/*  773 */           String key = "bDate:" + this.beforeDate.getTime() + ":aDate:" + this.afterDate.getTime();
/*  774 */           Filter filter = (Filter)DbQueryManager.filterCache.get(key);
/*  775 */           if (filter == null) {
/*  776 */             filter = new CachedFilter(new DateFilter("creationDate", this.afterDate, this.beforeDate));
/*  777 */             DbQueryManager.filterCache.put(key, filter);
/*      */           }
/*  779 */           multiFilter.add(filter);
/*  780 */           filterCount++;
/*      */         }
/*  782 */         else if (this.beforeDate == null) {
/*  783 */           String key = "aDate:" + this.afterDate.getTime();
/*  784 */           Filter filter = (Filter)DbQueryManager.filterCache.get(key);
/*  785 */           if (filter == null) {
/*  786 */             filter = new CachedFilter(DateFilter.After("creationDate", this.afterDate));
/*  787 */             DbQueryManager.filterCache.put(key, filter);
/*      */           }
/*  789 */           multiFilter.add(filter);
/*  790 */           filterCount++;
/*      */         }
/*      */         else {
/*  793 */           String key = "bDate:" + this.beforeDate.getTime();
/*  794 */           Filter filter = (Filter)DbQueryManager.filterCache.get(key);
/*  795 */           if (filter == null) {
/*  796 */             filter = new CachedFilter(DateFilter.Before("creationDate", this.beforeDate));
/*  797 */             DbQueryManager.filterCache.put(key, filter);
/*      */           }
/*  799 */           multiFilter.add(filter);
/*  800 */           filterCount++;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  805 */       if (this.filteredUserID != -1L) {
/*  806 */         String key = "filteredUserID:" + this.filteredUserID;
/*  807 */         Filter filter = (Filter)DbQueryManager.filterCache.get(key);
/*  808 */         if (filter == null) {
/*  809 */           filter = new CachedFilter(new FieldFilter("userID", "" + this.filteredUserID));
/*  810 */           DbQueryManager.filterCache.put(key, filter);
/*      */         }
/*  812 */         multiFilter.add(filter);
/*  813 */         filterCount++;
/*      */       }
/*      */ 
/*  817 */       if (this.threadID != -1L) {
/*  818 */         String key = "tID:" + this.threadID;
/*  819 */         Filter filter = (Filter)DbQueryManager.filterCache.get(key);
/*  820 */         if (filter == null) {
/*  821 */           filter = new CachedFilter(new FieldFilter("threadID", "" + this.threadID));
/*  822 */           DbQueryManager.filterCache.put(key, filter);
/*      */         }
/*  824 */         multiFilter.add(filter);
/*  825 */         filterCount++;
/*      */       }
/*      */ 
/*  828 */       if (comboQuery != null) {
/*  829 */         this.query = comboQuery;
/*      */       }
/*  831 */       else if (userQuery != null) {
/*  832 */         this.query = userQuery;
/*      */       }
/*      */       else
/*      */       {
/*  835 */         resetResults();
/*      */         return;
/*      */       }
/*  840 */       this.query = searcher.rewrite(this.query);
/*      */       Hits hits;
/*  844 */       if (filterCount > 0) {
/*  845 */         hits = searcher.search(this.query, multiFilter);
/*      */       }
/*      */       else {
/*  848 */         hits = searcher.search(this.query);
/*      */       }
/*      */ 
/*  852 */       int numResults = hits.length() < MAX_RESULTS_SIZE ? hits.length() : MAX_RESULTS_SIZE;
/*      */ 
/*  854 */       for (int i = 0; i < numResults; i++)
/*      */       {
/*  856 */         Map l = new HashMap();
/*      */         try {
/*  858 */           Document doc = hits.doc(i);
/*  859 */           long messageID = Long.parseLong(doc.get("messageID"));
/*  860 */           if (l.get(new Long(messageID)) == null)
/*      */           {
/*  863 */             l.put(new Long(messageID), " ");
/*  864 */             String tID = doc.get("threadID");
/*  865 */             if (tID == null) {
/*  866 */               Log.error("Unable to retrieve threadID from search index for message with ID " + messageID);
/*      */             }
/*      */             else {
/*  869 */               long threadID = Long.parseLong(tID);
/*  870 */               long forumID = Long.parseLong(doc.get("forumID"));
/*      */ 
/*  872 */               this.resultForums.add(new Long(forumID));
/*  873 */               Date modDate = DateField.stringToDate(doc.get("modificationDate"));
/*  874 */               Date createDate = DateField.stringToDate(doc.get("creationDate"));
/*  875 */               String subject = doc.get("subject");
/*  876 */               QueryResult result = new QueryResult(messageID, threadID, forumID, subject, modDate, createDate, hits.score(i));
/*      */ 
/*  878 */               this.results.add(result);
/*      */             }
/*      */           }
/*      */         } catch (NumberFormatException e) { Log.error(e); }
/*      */ 
/*      */       }
/*      */ 
/*  885 */       Hits hits = null;
/*      */     }
/*      */     catch (ParseException e) {
/*  888 */       Log.error("Search failure - lucene error parsing query: " + this.queryString);
/*  889 */       resetResults();
/*      */     }
/*      */     catch (Exception e) {
/*  892 */       Log.error(e);
/*  893 */       resetResults();
/*      */     }
/*      */     finally {
/*  896 */       DbSearchManager.searcherLock.releaseReadLock();
/*      */     }
/*      */ 
/*  899 */     if (this.id == -1L) {
/*  900 */       this.searchDuration = ((int)(System.currentTimeMillis() - startTime));
/*  901 */       this.searchDate = new Date();
/*      */     }
/*      */ 
/*  904 */     if (Log.isDebugEnabled())
/*  905 */       Log.debug("Search Query was \"" + this.queryString + "\", lucene result count: " + this.results.size() + ", search time: " + this.searchDuration + "ms");
/*      */   }
/*      */ 
/*      */   private void loadResultsByThread()
/*      */   {
/*  915 */     if ((getQueryString() == null) && (this.filteredUserID == -1L)) {
/*  916 */       return;
/*      */     }
/*  918 */     if (this.results.isEmpty()) {
/*  919 */       executeQuery();
/*      */     }
/*      */ 
/*  922 */     if (this.resultMessagesByThread.isEmpty()) {
/*  923 */       Map threads = new HashMap(this.results.size());
/*  924 */       for (int i = 0; i < this.results.size(); i++) {
/*  925 */         QueryResult result = (QueryResult)this.results.get(i);
/*  926 */         Long threadID = new Long(result.getThreadID());
/*  927 */         if (threads.get(threadID) == null) {
/*  928 */           threads.put(threadID, " ");
/*  929 */           this.resultMessagesByThread.add(result);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void resetResults() {
/*  936 */     this.results.clear();
/*  937 */     this.resultMessagesByThread.clear();
/*  938 */     this.resultForums.clear();
/*  939 */     this.query = null;
/*      */   }
/*      */ 
/*      */   private static String stripWildcards(String string) {
/*  943 */     string = StringUtils.replace(string, "*", "");
/*  944 */     string = StringUtils.replace(string, "?", "");
/*  945 */     string = StringUtils.replace(string, "~", "");
/*  946 */     return string;
/*      */   }
/*      */ 
/*      */   private static boolean containsWildcards(String string) {
/*  950 */     return (string.indexOf('?') != -1) || (string.indexOf('*') != -1) || (string.indexOf('~') != -1);
/*      */   }
/*      */ 
/*      */   private static String escapeBadCharacters(String queryString)
/*      */   {
/*  965 */     String query = StringUtils.replace(queryString, ":", "\\:");
/*      */ 
/*  967 */     int index = query.indexOf("\"");
/*  968 */     if ((index != -1) && (
/*  969 */       (index == query.length() - 1) || (query.indexOf("\"", index + 1) == -1))) {
/*  970 */       query = StringUtils.replace(query, "\"", "\\\"");
/*      */     }
/*      */ 
/*  974 */     return query;
/*      */   }
/*      */ 
/*      */   private static String lowerCaseQueryString(String queryString) {
/*  978 */     char[] chars = queryString.toCharArray();
/*  979 */     for (int i = 0; i < chars.length; i++) {
/*  980 */       char c = chars[i];
/*  981 */       if (Character.isUpperCase(c)) {
/*  982 */         if (c == 'A')
/*      */         {
/*  984 */           if ((i > 0) && (i + 3 < chars.length) && (!Character.isLetterOrDigit(chars[(i - 1)])) && (!Character.isLetterOrDigit(chars[(i + 3)])) && ((chars[(i + 1)] == 'n') || (chars[(i + 1)] == 'N')) && ((chars[(i + 2)] == 'd') || (chars[(i + 2)] == 'D')))
/*      */           {
/*  990 */             chars[(i + 1)] = Character.toUpperCase(chars[(i + 1)]);
/*  991 */             chars[(i + 2)] = Character.toUpperCase(chars[(i + 2)]);
/*  992 */             i += 2;
/*  993 */             continue;
/*      */           }
/*      */         }
/*  996 */         else if (c == 'O')
/*      */         {
/*  998 */           if ((i > 0) && (i + 2 < chars.length) && (!Character.isLetterOrDigit(chars[(i - 1)])) && (!Character.isLetterOrDigit(chars[(i + 2)])) && ((chars[(i + 1)] == 'r') || (chars[(i + 1)] == 'R')))
/*      */           {
/* 1003 */             chars[(i + 1)] = Character.toUpperCase(chars[(i + 1)]);
/* 1004 */             i++;
/* 1005 */             continue;
/*      */           }
/*      */         }
/*      */ 
/* 1009 */         chars[i] = Character.toLowerCase(c);
/*      */       }
/*      */     }
/*      */ 
/* 1013 */     return new String(chars);
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   98 */     int maxSize = 500;
/*   99 */     String maxResultsSize = JiveGlobals.getJiveProperty("search.maxResultsSize");
/*  100 */     if (maxResultsSize != null)
/*      */       try {
/*  102 */         maxSize = Integer.parseInt(maxResultsSize);
/*      */       }
/*      */       catch (NumberFormatException nfe)
/*      */       {
/*      */       }
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbQuery
 * JD-Core Version:    0.6.2
 */
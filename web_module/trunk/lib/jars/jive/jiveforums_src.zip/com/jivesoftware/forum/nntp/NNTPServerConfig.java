/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.tangosol.net.Invocable;
/*     */ import com.tangosol.net.InvocationService;
/*     */ import java.net.InetAddress;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.IllegalCharsetNameException;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ 
/*     */ public class NNTPServerConfig
/*     */ {
/*     */   private static final int DEFAULT_BUFFER_SIZE = 1024;
/*     */   private static final int MAX_HEADER_LENGTH = 80;
/*     */   private static final int LINE_LENGTH = 512;
/*  38 */   private static NNTPServerConfig instance = new NNTPServerConfig();
/*     */   private String name;
/*     */   private String mimeIntro;
/*     */   private String anonymousUsername;
/*  47 */   private int bufferSize = -1;
/*  48 */   private int maxHeaderLength = -1;
/*     */   private boolean attachmentsAllowed;
/*     */   private boolean crossPostingAllowed;
/*  51 */   private boolean useHtml = false;
/*     */   private String mimeCharsetName;
/*     */   private Charset mimeCharset;
/*     */   private boolean emptyList;
/*     */   private String emptyListGroupName;
/*     */   private boolean emptyNewNews;
/*     */   private String defaultSubject;
/*     */ 
/*     */   public static NNTPServerConfig getInstance()
/*     */   {
/*  41 */     return instance;
/*     */   }
/*     */ 
/*     */   private NNTPServerConfig()
/*     */   {
/*  60 */     loadConfig();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  69 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String hostName)
/*     */   {
/*  79 */     this.name = hostName;
/*  80 */     JiveGlobals.setJiveProperty("nntp.hostname", this.name);
/*     */ 
/*  82 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   public void setAnonymousUsername(String username)
/*     */   {
/*  93 */     JiveGlobals.setJiveProperty("nntp.anonymousName", this.anonymousUsername);
/*  94 */     this.anonymousUsername = username;
/*     */ 
/*  96 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   public String getAnonymousUsername()
/*     */   {
/* 105 */     return this.anonymousUsername;
/*     */   }
/*     */ 
/*     */   public void setMimeIntro(String intro)
/*     */   {
/* 119 */     JiveGlobals.setJiveProperty("nntp.mimeIntro", intro);
/* 120 */     this.mimeIntro = intro;
/*     */ 
/* 122 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   public String getMimeIntro()
/*     */   {
/* 131 */     return this.mimeIntro;
/*     */   }
/*     */ 
/*     */   public void setWriteBufferSize(int size)
/*     */   {
/* 144 */     if (size < 0) {
/* 145 */       this.bufferSize = 1024;
/*     */     }
/*     */     else {
/* 148 */       this.bufferSize = size;
/*     */     }
/* 150 */     JiveGlobals.setJiveProperty("nntp.writeBufferSize", String.valueOf(this.bufferSize));
/*     */ 
/* 152 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   public int getWriteBufferSize()
/*     */   {
/* 162 */     return this.bufferSize;
/*     */   }
/*     */ 
/*     */   public void setMaxHeaderLength(int headerLength)
/*     */   {
/* 174 */     if ((this.maxHeaderLength < 0) || (this.maxHeaderLength > 512)) {
/* 175 */       this.maxHeaderLength = 80;
/*     */     }
/*     */     else {
/* 178 */       this.maxHeaderLength = headerLength;
/*     */     }
/* 180 */     JiveGlobals.setJiveProperty("nntp.maxHeaderLength", String.valueOf(this.maxHeaderLength));
/*     */ 
/* 182 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   public int getMaxHeaderLength()
/*     */   {
/* 191 */     return this.maxHeaderLength;
/*     */   }
/*     */ 
/*     */   public boolean isAttachmentsAllowed()
/*     */   {
/* 200 */     return this.attachmentsAllowed;
/*     */   }
/*     */ 
/*     */   public void setAttachmentsAllowed(boolean allowed)
/*     */   {
/* 211 */     this.attachmentsAllowed = allowed;
/* 212 */     JiveGlobals.setJiveProperty("nntp.attachmentsAllowed", this.attachmentsAllowed ? "true" : "false");
/*     */ 
/* 215 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   public boolean isCrossPostingAllowed()
/*     */   {
/* 224 */     return this.crossPostingAllowed;
/*     */   }
/*     */ 
/*     */   public void setCrossPostingAllowed(boolean allowed)
/*     */   {
/* 234 */     this.crossPostingAllowed = allowed;
/* 235 */     JiveGlobals.setJiveProperty("nntp.crossPostingAllowed", this.crossPostingAllowed ? "true" : "false");
/*     */ 
/* 238 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   public String getMimeCharacterEncoding()
/*     */   {
/* 248 */     return this.mimeCharsetName;
/*     */   }
/*     */ 
/*     */   public Charset getMimeCharset()
/*     */   {
/* 258 */     return this.mimeCharset;
/*     */   }
/*     */ 
/*     */   public String getDefaultSubject()
/*     */   {
/* 269 */     return this.defaultSubject;
/*     */   }
/*     */ 
/*     */   public void setDefaultSubject(String subject)
/*     */   {
/* 279 */     this.defaultSubject = subject;
/* 280 */     JiveGlobals.setJiveProperty("nntp.defaultSubject", subject);
/*     */ 
/* 282 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   public String getGlobalMessageFooter() {
/* 286 */     return null;
/*     */   }
/*     */ 
/*     */   public void setGlobalMessageFooter(String messageFooter)
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean isEmptyList()
/*     */   {
/* 308 */     return this.emptyList;
/*     */   }
/*     */ 
/*     */   public void setEmptyList(boolean list)
/*     */   {
/* 317 */     JiveGlobals.setJiveProperty("nntp.list", list ? "true" : "false");
/* 318 */     this.emptyList = list;
/*     */ 
/* 320 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   public boolean isEmptyNewNews()
/*     */   {
/* 336 */     return this.emptyNewNews;
/*     */   }
/*     */ 
/*     */   public void setEmptyNewNews(boolean newNews)
/*     */   {
/* 345 */     JiveGlobals.setJiveProperty("nntp.newNews", newNews ? "true" : "false");
/* 346 */     this.emptyNewNews = newNews;
/*     */ 
/* 348 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   public String getEmptyListGroupName()
/*     */   {
/* 361 */     return this.emptyListGroupName;
/*     */   }
/*     */ 
/*     */   public void setEmptyListGroupName(String newName)
/*     */   {
/* 370 */     if ((newName == null) || (newName.trim().length() == 0)) {
/* 371 */       this.emptyListGroupName = "";
/*     */     }
/*     */     else {
/* 374 */       this.emptyListGroupName = newName;
/*     */     }
/* 376 */     JiveGlobals.setJiveProperty("nntp.emptyListGroupName", this.emptyListGroupName);
/*     */ 
/* 378 */     CacheFactory.doClusterTask(new ReloadConfigTask());
/*     */   }
/*     */ 
/*     */   private void loadConfig()
/*     */   {
/* 385 */     this.attachmentsAllowed = JiveGlobals.getJiveBooleanProperty("nntp.attachmentsAllowed", true);
/* 386 */     this.crossPostingAllowed = JiveGlobals.getJiveBooleanProperty("nntp.crossPostingAllowed", true);
/* 387 */     this.useHtml = JiveGlobals.getJiveBooleanProperty("nntp.sendHtml", false);
/* 388 */     this.mimeIntro = JiveGlobals.getJiveProperty("nntp.mimeIntro", "This message is in MIME format. Since your mail reader does not \r\nunderstand this format, some or all of this message may not be legible.");
/*     */ 
/* 392 */     this.bufferSize = JiveGlobals.getJiveIntProperty("nntp.writeBufferSize", 1024);
/* 393 */     this.maxHeaderLength = JiveGlobals.getJiveIntProperty("nntp.maxHeaderLength", 80);
/* 394 */     this.anonymousUsername = JiveGlobals.getJiveProperty("nntp.anonymousName", "Anonymous <>");
/* 395 */     String encoding = JiveGlobals.getCharacterEncoding();
/*     */     try {
/* 397 */       this.mimeCharsetName = MimeUtility.mimeCharset(encoding);
/* 398 */       this.mimeCharset = Charset.forName(encoding);
/*     */     }
/*     */     catch (IllegalCharsetNameException e) {
/* 401 */       Log.error("Invalid charset encoding: " + encoding + ", not setting a mime charset for NNTP.");
/*     */     }
/*     */     catch (UnsupportedCharsetException e) {
/* 404 */       Log.error("Invalid charset encoding: " + encoding + ", not setting a mime charset for NNTP.");
/*     */     }
/* 406 */     this.emptyList = JiveGlobals.getJiveBooleanProperty("nntp.emptyList", false);
/* 407 */     this.emptyNewNews = JiveGlobals.getJiveBooleanProperty("nntp.emptyNewNews", false);
/* 408 */     this.emptyListGroupName = JiveGlobals.getJiveProperty("nntp.emptyListGroupName", "");
/* 409 */     this.defaultSubject = JiveGlobals.getJiveProperty("nntp.defaultSubject", "");
/*     */ 
/* 412 */     String defaultName = null;
/*     */     try {
/* 414 */       defaultName = InetAddress.getLocalHost().getHostName();
/*     */     }
/*     */     catch (Exception e) {
/* 417 */       defaultName = "";
/*     */     }
/* 419 */     this.name = JiveGlobals.getJiveProperty("nntp.hostname", defaultName);
/*     */   }
/*     */ 
/*     */   private static class ReloadConfigTask
/*     */     implements Invocable
/*     */   {
/*     */     public void init(InvocationService invocationService)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 434 */       NNTPServerConfig.getInstance().loadConfig();
/*     */     }
/*     */ 
/*     */     public Object getResult() {
/* 438 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NNTPServerConfig
 * JD-Core Version:    0.6.2
 */
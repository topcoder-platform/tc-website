/*     */ package com.jivesoftware.forum.gateway;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.sun.net.ssl.internal.ssl.Provider;
/*     */ import java.security.Security;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Store;
/*     */ import javax.mail.URLName;
/*     */ 
/*     */ public class Pop3Importer
/*     */   implements GatewayImporter
/*     */ {
/*     */   private POP3Gateway gateway;
/*     */   public static final String GATEWAY_MESSAGE_ID = "Email-Message-ID";
/*     */   public static final String GATEWAY_PARENT_ID = "Email-Parent-ID";
/*  59 */   private static Map forumLock = Collections.synchronizedMap(new HashMap());
/*     */ 
/*     */   public Pop3Importer(ForumFactory factory, Forum forum)
/*     */   {
/*  66 */     this.gateway = new POP3Gateway(factory, forum);
/*     */ 
/*  68 */     synchronized (forumLock) {
/*  69 */       if (forumLock.get(new Long(this.gateway.forumID)) == null)
/*  70 */         forumLock.put(new Long(this.gateway.forumID), new Long(this.gateway.forumID));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void importData(Date afterDate)
/*     */     throws GatewayException
/*     */   {
/*  78 */     synchronized (forumLock.get(new Long(this.gateway.forumID))) {
/*  79 */       this.gateway.importData(afterDate);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */     throws GatewayException
/*     */   {
/*  86 */     this.gateway.stop();
/*     */   }
/*     */ 
/*     */   public String getHost()
/*     */   {
/*  98 */     return this.gateway.getHost();
/*     */   }
/*     */ 
/*     */   public void setHost(String host)
/*     */   {
/* 108 */     this.gateway.setHost(host);
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 118 */     return this.gateway.getPort();
/*     */   }
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 128 */     this.gateway.setPort(port);
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 138 */     return this.gateway.getUsername();
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 148 */     this.gateway.setUsername(username);
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 158 */     return this.gateway.getPassword();
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 168 */     this.gateway.setPassword(password);
/*     */   }
/*     */ 
/*     */   public boolean isDeleteEnabled()
/*     */   {
/* 180 */     return this.gateway.isDeleteEnabled();
/*     */   }
/*     */ 
/*     */   public void setDeleteEnabled(boolean POP3DeleteEnabled)
/*     */   {
/* 192 */     this.gateway.setDeleteEnabled(POP3DeleteEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isDebugEnabled()
/*     */   {
/* 204 */     return this.gateway.isDebugEnabled();
/*     */   }
/*     */ 
/*     */   public void setDebugEnabled(boolean debugEnabled)
/*     */   {
/* 214 */     this.gateway.setDebugEnabled(debugEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isAttachmentsEnabled()
/*     */   {
/* 223 */     return this.gateway.isAttachmentsEnabled();
/*     */   }
/*     */ 
/*     */   public void setAttachmentsEnabled(boolean attachmentEnabled)
/*     */   {
/* 232 */     this.gateway.setAttachmentsEnabled(attachmentEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isEmailToUserMappingEnabled()
/*     */   {
/* 241 */     return this.gateway.isEmailToUserMappingEnabled();
/*     */   }
/*     */ 
/*     */   public void setEmailToUserMappingEnabled(boolean emailToUserMappingEnabled)
/*     */   {
/* 251 */     this.gateway.setEmailToUserMappingEnabled(emailToUserMappingEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isImportHtmlEnabled()
/*     */   {
/* 260 */     return this.gateway.isImportHtmlEnabled();
/*     */   }
/*     */ 
/*     */   public void setImportHtmlEnabled(boolean importHtmlEnabled)
/*     */   {
/* 271 */     this.gateway.setImportHtmlEnabled(importHtmlEnabled);
/*     */   }
/*     */ 
/*     */   public String getDefaultCharacterSet()
/*     */   {
/* 282 */     return this.gateway.defaultCharacterSet;
/*     */   }
/*     */ 
/*     */   public void setDefaultCharacterSet(String defaultCharacterSet)
/*     */   {
/* 293 */     if (defaultCharacterSet != null)
/* 294 */       this.gateway.setDefaultCharacterSet(defaultCharacterSet);
/*     */   }
/*     */ 
/*     */   public String getTemporaryParentBody()
/*     */   {
/* 317 */     return this.gateway.getTemporaryParentBody();
/*     */   }
/*     */ 
/*     */   public void setTemporaryParentBody(String temporaryParentBody)
/*     */   {
/* 339 */     this.gateway.setTemporaryParentBody(temporaryParentBody);
/*     */   }
/*     */ 
/*     */   public boolean isSSLEnabled()
/*     */   {
/* 350 */     return this.gateway.isSSLEnabled();
/*     */   }
/*     */ 
/*     */   public void setSSLEnabled(boolean enabled)
/*     */   {
/* 359 */     this.gateway.setSSLEnabled(enabled);
/*     */   }
/*     */ 
/*     */   public String getReplyPrefixes()
/*     */   {
/* 371 */     String prefixes = "";
/* 372 */     String delim = "";
/* 373 */     for (int i = 0; i < this.gateway.replyPrefixes.length; i++) {
/* 374 */       prefixes = prefixes + delim;
/* 375 */       prefixes = prefixes + this.gateway.replyPrefixes[i];
/* 376 */       delim = ",";
/*     */     }
/*     */ 
/* 379 */     return prefixes;
/*     */   }
/*     */ 
/*     */   public void setReplyPrefixes(String replyPrefixes)
/*     */   {
/* 390 */     if (replyPrefixes == null) {
/* 391 */       return;
/*     */     }
/* 393 */     StringTokenizer st = new StringTokenizer(replyPrefixes, ",");
/* 394 */     ArrayList prefixes = new ArrayList();
/* 395 */     while (st.hasMoreElements()) {
/* 396 */       String prefix = (String)st.nextElement();
/* 397 */       prefixes.add(prefix);
/*     */     }
/*     */ 
/* 400 */     this.gateway.replyPrefixes = ((String[])prefixes.toArray(new String[prefixes.size()]));
/*     */   }
/*     */ 
/*     */   public boolean isSubjectParentageCheckEnabled()
/*     */   {
/* 409 */     return this.gateway.subjectParentageCheckEnabled;
/*     */   }
/*     */ 
/*     */   public void setSubjectParentageCheckEnabled(boolean subjectParentageCheckEnabled)
/*     */   {
/* 419 */     this.gateway.subjectParentageCheckEnabled = subjectParentageCheckEnabled;
/*     */   }
/*     */ 
/*     */   public String getEmptySubject()
/*     */   {
/* 428 */     return this.gateway.emptySubject;
/*     */   }
/*     */ 
/*     */   public void setEmptySubject(String emptySubject)
/*     */   {
/* 437 */     this.gateway.emptySubject = emptySubject;
/*     */   }
/*     */ 
/*     */   private class POP3Gateway extends JavaMailGateway
/*     */   {
/* 448 */     boolean SSLEnabled = false;
/* 449 */     Session session = null;
/*     */     private static final String SSL_FACTORY = "com.jivesoftware.util.ssl.DummySSLSocketFactory";
/*     */ 
/*     */     public POP3Gateway(ForumFactory factory, Forum forum)
/*     */     {
/* 454 */       super(forum);
/* 455 */       setPort(110);
/* 456 */       setProtocol("pop3");
/* 457 */       setMailbox("INBOX");
/*     */ 
/* 459 */       this.gatewayMessageId = "Email-Message-ID";
/* 460 */       this.gatewayParentId = "Email-Parent-ID";
/*     */     }
/*     */ 
/*     */     protected Store getStore(Date afterDate)
/*     */       throws MessagingException
/*     */     {
/* 471 */       getSession();
/*     */ 
/* 474 */       this.session.setDebug(this.debugEnabled);
/*     */ 
/* 477 */       URLName url = new URLName(this.protocol, this.host, this.port, this.mailbox, this.username, this.password);
/* 478 */       Store store = this.session.getStore(url);
/*     */       try
/*     */       {
/* 482 */         store.connect();
/*     */       }
/*     */       catch (MessagingException e) {
/*     */         try {
/* 486 */           Forum forum = this.factory.getForum(this.forumID);
/* 487 */           Log.error("Unable to open POP3 gateway in forum " + forum.getName() + ", Reason: " + e.getMessage());
/*     */ 
/* 489 */           throw e;
/*     */         } catch (ForumNotFoundException e1) {
/*     */         }
/*     */         catch (UnauthorizedException e1) {
/*     */         }
/*     */       }
/* 495 */       return store;
/*     */     }
/*     */ 
/*     */     public boolean isSSLEnabled() {
/* 499 */       return this.SSLEnabled;
/*     */     }
/*     */ 
/*     */     public void setSSLEnabled(boolean enabled) {
/* 503 */       this.SSLEnabled = enabled;
/*     */ 
/* 507 */       this.session = null;
/*     */ 
/* 510 */       if (enabled) {
/* 511 */         Security.addProvider(new Provider());
/* 512 */         Security.setProperty("ssl.SocketFactory.provider", "com.jivesoftware.util.ssl.DummySSLSocketFactory");
/*     */       }
/*     */     }
/*     */ 
/*     */     private void getSession()
/*     */     {
/* 520 */       if ((this.session == null) && (this.SSLEnabled)) {
/* 521 */         Properties mailProps = new Properties();
/*     */ 
/* 524 */         mailProps.setProperty("mail.pop3.socketFactory.class", "com.jivesoftware.util.ssl.DummySSLSocketFactory");
/* 525 */         mailProps.setProperty("mail.pop3.socketFactory.fallback", "false");
/*     */ 
/* 527 */         this.session = Session.getInstance(mailProps, null);
/*     */       }
/* 529 */       else if (this.session == null) {
/* 530 */         this.session = Session.getInstance(System.getProperties(), null);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.Pop3Importer
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.event;
/*    */ 
/*    */ import com.jivesoftware.base.JiveGlobals;
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.util.ClassUtils;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class CategoryEventDispatcher
/*    */ {
/* 28 */   private static CategoryEventDispatcher instance = new CategoryEventDispatcher();
/*    */ 
/* 34 */   private ArrayList listeners = new ArrayList();
/*    */ 
/*    */   public static CategoryEventDispatcher getInstance()
/*    */   {
/* 31 */     return instance;
/*    */   }
/*    */ 
/*    */   private CategoryEventDispatcher()
/*    */   {
/* 38 */     List listenerList = JiveGlobals.getJiveProperties("eventListeners.CategoryListener");
/* 39 */     for (int i = 0; i < listenerList.size(); i++) {
/* 40 */       String listenerStr = (String)listenerList.get(i);
/*    */       try {
/* 42 */         CategoryListener listener = (CategoryListener)ClassUtils.forName(listenerStr).newInstance();
/* 43 */         this.listeners.add(listener);
/*    */       }
/*    */       catch (Exception e) {
/* 46 */         Log.error("Error loading CategoryListener", e);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public synchronized void addListener(CategoryListener listener) {
/* 52 */     if (listener == null) {
/* 53 */       throw new NullPointerException();
/*    */     }
/* 55 */     this.listeners.add(listener);
/*    */   }
/*    */ 
/*    */   public synchronized void removeListener(CategoryListener listener) {
/* 59 */     this.listeners.remove(listener);
/*    */   }
/*    */ 
/*    */   public void dispatchEvent(CategoryEvent event) {
/* 63 */     int eventType = event.getEventType();
/*    */ 
/* 65 */     for (int i = 0; i < this.listeners.size(); i++)
/*    */       try {
/* 67 */         CategoryListener listener = (CategoryListener)this.listeners.get(i);
/* 68 */         switch (eventType) {
/*    */         case 130:
/* 70 */           listener.categoryAdded(event);
/* 71 */           break;
/*    */         case 131:
/* 74 */           listener.categoryDeleted(event);
/* 75 */           break;
/*    */         case 132:
/* 78 */           listener.categoryMoved(event);
/*    */         }
/*    */ 
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 86 */         Log.error(e);
/*    */       }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.CategoryEventDispatcher
 * JD-Core Version:    0.6.2
 */
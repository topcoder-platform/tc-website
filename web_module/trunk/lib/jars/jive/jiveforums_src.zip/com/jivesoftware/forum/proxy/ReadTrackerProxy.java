/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ReadTracker;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class ReadTrackerProxy
/*     */   implements ReadTracker
/*     */ {
/*     */   private ReadTracker readTracker;
/*     */   private AuthToken authToken;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public ReadTrackerProxy(ReadTracker readTracker, AuthToken authToken, Permissions permissions)
/*     */   {
/*  37 */     this.readTracker = readTracker;
/*  38 */     this.authToken = authToken;
/*  39 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public boolean isReadTrackingEnabled()
/*     */   {
/*  45 */     return this.readTracker.isReadTrackingEnabled();
/*     */   }
/*     */ 
/*     */   public void setReadTrackingEnabled(boolean enabled) throws UnauthorizedException {
/*  49 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  50 */       this.readTracker.setReadTrackingEnabled(enabled);
/*     */     }
/*     */     else
/*  53 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getReadStatus(User user, ForumThread thread)
/*     */   {
/*  58 */     return this.readTracker.getReadStatus(user, thread);
/*     */   }
/*     */ 
/*     */   public int getReadStatus(User user, ForumMessage message) {
/*  62 */     return this.readTracker.getReadStatus(user, message);
/*     */   }
/*     */ 
/*     */   public void markRead(User user, ForumMessage message) {
/*  66 */     this.readTracker.markRead(user, message);
/*     */   }
/*     */ 
/*     */   public void markRead(User user, Forum forum) {
/*  70 */     this.readTracker.markRead(user, forum);
/*     */   }
/*     */ 
/*     */   public void markRead(User user, ForumCategory category) {
/*  74 */     this.readTracker.markRead(user, category);
/*     */   }
/*     */ 
/*     */   public int getUnreadThreadCount(User user, Forum forum) {
/*  78 */     return this.readTracker.getUnreadThreadCount(user, forum);
/*     */   }
/*     */ 
/*     */   public int getUnreadThreadCount(User user, ForumCategory category) {
/*  82 */     return this.readTracker.getUnreadThreadCount(user, category);
/*     */   }
/*     */ 
/*     */   public Iterator getUnreadThreads(User user, Forum forum) {
/*  86 */     Iterator iter = this.readTracker.getUnreadThreads(user, forum);
/*  87 */     return new IteratorProxy(1, iter, this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getUnreadThreads(User user, ForumCategory category) {
/*  91 */     return this.readTracker.getUnreadThreads(user, category);
/*     */   }
/*     */ 
/*     */   public int getUnreadMessageCount(User user, Forum forum) {
/*  95 */     return this.readTracker.getUnreadMessageCount(user, forum);
/*     */   }
/*     */ 
/*     */   public int getUnreadMessageCount(User user, ForumCategory category) {
/*  99 */     return this.readTracker.getUnreadMessageCount(user, category);
/*     */   }
/*     */ 
/*     */   public Iterator getUnreadMessages(User user, Forum forum) {
/* 103 */     Iterator iter = this.readTracker.getUnreadMessages(user, forum);
/* 104 */     return new IteratorProxy(2, iter, this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getUnreadMessages(User user, ForumCategory category) {
/* 108 */     return this.readTracker.getUnreadMessages(user, category);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.ReadTrackerProxy
 * JD-Core Version:    0.6.2
 */
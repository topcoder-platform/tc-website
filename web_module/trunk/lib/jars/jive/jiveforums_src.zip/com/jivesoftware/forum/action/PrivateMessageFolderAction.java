/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.PrivateMessageManager;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ 
/*    */ public class PrivateMessageFolderAction extends ForumActionSupport
/*    */ {
/*    */   private Collection folders;
/*    */ 
/*    */   public Collection getFolders()
/*    */   {
/* 27 */     return this.folders;
/*    */   }
/*    */ 
/*    */   public String execute() {
/* 31 */     PrivateMessageManager manager = getForumFactory().getPrivateMessageManager();
/* 32 */     if (getAuthToken().isAnonymous()) {
/* 33 */       return "login";
/*    */     }
/* 35 */     if (!manager.isPrivateMessagesEnabled()) {
/* 36 */       return "disabled";
/*    */     }
/*    */     try
/*    */     {
/* 40 */       this.folders = new LinkedList();
/* 41 */       for (iter = manager.getFolders(getPageUser()); iter.hasNext(); )
/* 42 */         this.folders.add(iter.next());
/*    */     }
/*    */     catch (UnauthorizedException e)
/*    */     {
/*    */       Iterator iter;
/* 46 */       addFieldError("unauthorized", "");
/* 47 */       return "error";
/*    */     }
/* 49 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PrivateMessageFolderAction
 * JD-Core Version:    0.6.2
 */
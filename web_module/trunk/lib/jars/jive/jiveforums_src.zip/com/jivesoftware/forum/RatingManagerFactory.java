/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.JiveGlobals;
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.forum.database.DbRatingManager;
/*    */ import com.jivesoftware.forum.proxy.RatingManagerProxy;
/*    */ import com.jivesoftware.util.Cache;
/*    */ import com.jivesoftware.util.CacheFactory;
/*    */ import com.jivesoftware.util.ClassUtils;
/*    */ 
/*    */ public class RatingManagerFactory
/*    */ {
/*    */   private static RatingManager ratingManager;
/* 28 */   public static Cache ratingsCache = CacheFactory.createCache("Forum Ratings", "ratingCache", 131072, -1L);
/*    */ 
/*    */   public static RatingManager getInstance(AuthToken authToken)
/*    */   {
/* 40 */     if (ratingManager != null) {
/* 41 */       return new RatingManagerProxy(ratingManager, ForumFactory.getInstance(authToken).getPermissions(authToken));
/*    */     }
/*    */ 
/* 47 */     String className = JiveGlobals.getJiveProperty("RatingManager.className");
/* 48 */     if (className != null) {
/*    */       try {
/* 50 */         Class c = ClassUtils.forName(className);
/* 51 */         ratingManager = (RatingManager)c.newInstance();
/*    */       }
/*    */       catch (Exception e) {
/* 54 */         Log.fatal("Error loading custom RatingManager " + className, e);
/* 55 */         ratingManager = DbRatingManager.getInstance();
/*    */       }
/*    */     }
/*    */     else {
/* 59 */       ratingManager = DbRatingManager.getInstance();
/*    */     }
/*    */ 
/* 62 */     return new RatingManagerProxy(ratingManager, ForumFactory.getInstance(authToken).getPermissions(authToken));
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.RatingManagerFactory
 * JD-Core Version:    0.6.2
 */
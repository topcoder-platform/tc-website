/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.AttachmentManager;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class AttachmentManagerProxy
/*     */   implements AttachmentManager
/*     */ {
/*     */   private AttachmentManager attachmentManager;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public AttachmentManagerProxy(AttachmentManager attachmentManager, Permissions permissions)
/*     */   {
/*  25 */     this.attachmentManager = attachmentManager;
/*  26 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public boolean isDatabaseModeEnabled()
/*     */   {
/*  32 */     return this.attachmentManager.isDatabaseModeEnabled();
/*     */   }
/*     */ 
/*     */   public void setDatabaseModeEnabled(boolean enabled) throws UnauthorizedException {
/*  36 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  37 */       this.attachmentManager.setDatabaseModeEnabled(enabled);
/*     */     }
/*     */     else
/*  40 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public long getAttachmentDirectorySize() throws UnauthorizedException
/*     */   {
/*  45 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  46 */       return this.attachmentManager.getAttachmentDirectorySize();
/*     */     }
/*     */ 
/*  49 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public long getMaxFilesystemCacheSize() throws UnauthorizedException
/*     */   {
/*  54 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  55 */       return this.attachmentManager.getMaxFilesystemCacheSize();
/*     */     }
/*     */ 
/*  58 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void setMaxFilesystemCacheSize(long maxSize) throws UnauthorizedException
/*     */   {
/*  63 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  64 */       this.attachmentManager.setMaxFilesystemCacheSize(maxSize);
/*     */     }
/*     */     else
/*  67 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getMaxAttachmentSize()
/*     */   {
/*  72 */     return this.attachmentManager.getMaxAttachmentSize();
/*     */   }
/*     */ 
/*     */   public void setMaxAttachmentSize(int maxAttachmentSize)
/*     */     throws UnauthorizedException
/*     */   {
/*  78 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  79 */       this.attachmentManager.setMaxAttachmentSize(maxAttachmentSize);
/*     */     }
/*     */     else
/*  82 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getMaxAttachmentsPerMessage()
/*     */   {
/*  87 */     return this.attachmentManager.getMaxAttachmentsPerMessage();
/*     */   }
/*     */ 
/*     */   public void setMaxAttachmentsPerMessage(int maxAttachmentsPerMessage)
/*     */     throws UnauthorizedException
/*     */   {
/*  93 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  94 */       this.attachmentManager.setMaxAttachmentsPerMessage(maxAttachmentsPerMessage);
/*     */     }
/*     */     else
/*  97 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean isValidType(String contentType)
/*     */   {
/* 102 */     return this.attachmentManager.isValidType(contentType);
/*     */   }
/*     */ 
/*     */   public void addAllowedType(String contentType)
/*     */     throws UnauthorizedException
/*     */   {
/* 108 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 109 */       this.attachmentManager.addAllowedType(contentType);
/*     */     }
/*     */     else
/* 112 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void removeAllowedType(String contentType)
/*     */     throws UnauthorizedException
/*     */   {
/* 119 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 120 */       this.attachmentManager.removeAllowedType(contentType);
/*     */     }
/*     */     else
/* 123 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator allowedTypes()
/*     */   {
/* 128 */     return this.attachmentManager.allowedTypes();
/*     */   }
/*     */ 
/*     */   public void addDisallowedType(String contentType)
/*     */     throws UnauthorizedException
/*     */   {
/* 134 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 135 */       this.attachmentManager.addDisallowedType(contentType);
/*     */     }
/*     */     else
/* 138 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void removeDisallowedType(String contentType)
/*     */     throws UnauthorizedException
/*     */   {
/* 145 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 146 */       this.attachmentManager.removeDisallowedType(contentType);
/*     */     }
/*     */     else
/* 149 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator disallowedTypes()
/*     */   {
/* 154 */     return this.attachmentManager.disallowedTypes();
/*     */   }
/*     */ 
/*     */   public boolean getAllowAllByDefault() {
/* 158 */     return this.attachmentManager.getAllowAllByDefault();
/*     */   }
/*     */ 
/*     */   public void setAllowAllByDefault(boolean allowAllByDefault)
/*     */     throws UnauthorizedException
/*     */   {
/* 164 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 165 */       this.attachmentManager.setAllowAllByDefault(allowAllByDefault);
/*     */     }
/*     */     else
/* 168 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean isImagePreviewEnabled()
/*     */   {
/* 173 */     return this.attachmentManager.isImagePreviewEnabled();
/*     */   }
/*     */ 
/*     */   public void setImagePreviewEnabled(boolean imagePreviewEnabled)
/*     */     throws UnauthorizedException
/*     */   {
/* 179 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 180 */       this.attachmentManager.setImagePreviewEnabled(imagePreviewEnabled);
/*     */     }
/*     */     else
/* 183 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getImagePreviewMaxSize()
/*     */   {
/* 188 */     return this.attachmentManager.getImagePreviewMaxSize();
/*     */   }
/*     */ 
/*     */   public void setImagePreviewMaxSize(int imagePreviewMaxSize)
/*     */     throws UnauthorizedException
/*     */   {
/* 194 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 195 */       this.attachmentManager.setImagePreviewMaxSize(imagePreviewMaxSize);
/*     */     }
/*     */     else
/* 198 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean isImagePreviewRatioEnabled()
/*     */   {
/* 203 */     return this.attachmentManager.isImagePreviewRatioEnabled();
/*     */   }
/*     */ 
/*     */   public void setImagePreviewRatioEnabled(boolean imagePreviewRatioEnabled)
/*     */     throws UnauthorizedException
/*     */   {
/* 209 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 210 */       this.attachmentManager.setImagePreviewRatioEnabled(imagePreviewRatioEnabled);
/*     */     }
/*     */     else
/* 213 */       throw new UnauthorizedException();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.AttachmentManagerProxy
 * JD-Core Version:    0.6.2
 */
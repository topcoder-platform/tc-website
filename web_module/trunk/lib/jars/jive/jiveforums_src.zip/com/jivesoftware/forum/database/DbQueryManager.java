/*    */ package com.jivesoftware.forum.database;
/*    */ 
/*    */ import com.jivesoftware.base.JiveGlobals;
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import com.jivesoftware.forum.Query;
/*    */ import com.jivesoftware.forum.QueryManager;
/*    */ import com.jivesoftware.util.Cache;
/*    */ import com.jivesoftware.util.ClassUtils;
/*    */ import java.lang.reflect.Constructor;
/*    */ 
/*    */ public class DbQueryManager
/*    */   implements QueryManager
/*    */ {
/*    */   protected static Cache filterCache;
/* 33 */   private static DbQueryManager instance = new DbQueryManager();
/*    */ 
/* 35 */   private static boolean initialized = false;
/*    */ 
/*    */   public static DbQueryManager getInstance()
/*    */   {
/* 39 */     return instance;
/*    */   }
/*    */ 
/*    */   public synchronized void initialize()
/*    */   {
/* 45 */     if (!initialized) {
/* 46 */       filterCache = new LuceneFilterCache();
/* 47 */       initialized = true;
/*    */     }
/*    */   }
/*    */ 
/*    */   public Query createQuery() {
/* 52 */     return createQuery(null);
/*    */   }
/*    */ 
/*    */   public Query createQuery(Forum[] forums)
/*    */   {
/* 61 */     String className = JiveGlobals.getJiveProperty("Query.className");
/* 62 */     if (className != null) {
/* 63 */       Log.debug("Loading custom Query from class: " + className);
/*    */       try
/*    */       {
/* 66 */         Class c = ClassUtils.forName(className);
/* 67 */         Class[] params = { new Forum[0].getClass() };
/* 68 */         Constructor constructor = c.getConstructor(params);
/* 69 */         Query query = (Query)constructor.newInstance(new Object[] { forums });
/* 70 */         Log.debug("Custom Query '" + className + "' loaded successfully");
/* 71 */         return query;
/*    */       }
/*    */       catch (Exception e) {
/* 74 */         Log.fatal("Error loading custom Query " + className, e);
/*    */       }
/*    */     }
/*    */ 
/* 78 */     return new DbQuery(forums);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbQueryManager
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum.gateway;

import com.jivesoftware.forum.ForumMessage;

public abstract interface GatewayExporter
{
  public abstract void exportData(ForumMessage paramForumMessage)
    throws GatewayException;

  public abstract void exportData(ForumMessage[] paramArrayOfForumMessage)
    throws GatewayException;

  public abstract void stop()
    throws GatewayException;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.GatewayExporter
 * JD-Core Version:    0.6.2
 */
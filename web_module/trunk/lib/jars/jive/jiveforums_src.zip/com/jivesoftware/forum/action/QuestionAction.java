/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class QuestionAction extends ForumActionSupport
/*     */   implements Validateable
/*     */ {
/*     */   public static final String ANSWERED = "answered";
/*     */   public static final String UNANSWERED = "unanswered";
/*     */   public static final String ASSUMED_ANSWERED = "assumed_answered";
/*     */   public static final String USER_QUESTION_COUNT = "jiveQuestionCount";
/*  52 */   public static int INACTIVE_WINDOW = 5;
/*     */   private long forumID;
/*     */   private long threadID;
/*     */   private String resolution;
/*     */   private String doCancel;
/*     */   private Forum forum;
/*     */   private ForumThread thread;
/*     */ 
/*     */   public static boolean isInactiveQuestion(ForumThread thread)
/*     */   {
/*  89 */     if (thread != null)
/*     */     {
/*  91 */       if ("true".equals(thread.getProperty("isQuestion")))
/*     */       {
/*  94 */         long delta = CacheFactory.currentTime - thread.getModificationDate().getTime();
/*  95 */         boolean isOld = delta >= INACTIVE_WINDOW * 24 * 60 * 60 * 1000;
/*  96 */         if (isOld)
/*     */         {
/*  98 */           String resolution = thread.getProperty("questionResolution");
/*  99 */           if ((resolution == null) || ("unanswered".equals(resolution))) {
/* 100 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   public long getForumID()
/*     */   {
/* 111 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID) {
/* 115 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public long getThreadID() {
/* 119 */     return this.threadID;
/*     */   }
/*     */ 
/*     */   public void setThreadID(long threadID) {
/* 123 */     this.threadID = threadID;
/*     */   }
/*     */ 
/*     */   public String getResolution() {
/* 127 */     return this.resolution;
/*     */   }
/*     */ 
/*     */   public void setResolution(String resolution)
/*     */   {
/* 136 */     if ((resolution != null) && (!"".equals(resolution.trim()))) {
/* 137 */       this.resolution = resolution;
/*     */     }
/*     */ 
/* 140 */     if ("assumed".equals(this.resolution))
/* 141 */       this.resolution = "assumed_answered";
/*     */   }
/*     */ 
/*     */   public String getDoCancel()
/*     */   {
/* 146 */     return this.doCancel;
/*     */   }
/*     */ 
/*     */   public void setDoCancel(String doCancel) {
/* 150 */     this.doCancel = "true";
/*     */   }
/*     */ 
/*     */   public Forum getForum()
/*     */   {
/* 156 */     return this.forum;
/*     */   }
/*     */ 
/*     */   protected void setForum(Forum forum) {
/* 160 */     this.forum = forum;
/*     */   }
/*     */ 
/*     */   public ForumThread getThread() {
/* 164 */     return this.thread;
/*     */   }
/*     */ 
/*     */   protected void setThread(ForumThread thread) {
/* 168 */     this.thread = thread;
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/* 175 */     if ((this.resolution == null) || ((!"answered".equals(this.resolution)) && (!"unanswered".equals(this.resolution)) && (!"assumed_answered".equals(this.resolution))))
/*     */     {
/* 178 */       addFieldError("resolution", getText("question.error_resolution"));
/*     */     }
/*     */ 
/* 181 */     if (("assumed_answered".equals(this.resolution)) && (!isModerator(this.forum)))
/* 182 */       addActionError("You must be a moderator to set this resolution (assumed answered).");
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*     */     try {
/* 188 */       if (!loadJiveObjects())
/* 189 */         return "fatal";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 193 */       setLoginAttributes();
/* 194 */       addActionError(getText("question.error_unauth"));
/* 195 */       return "login";
/*     */     }
/*     */ 
/* 199 */     if ("assumed_answered".equals(this.resolution))
/*     */     {
/* 201 */       if (!isModerator(this.forum)) {
/* 202 */         setLoginAttributes();
/* 203 */         addActionError(getText("question.error_unauth"));
/* 204 */         return "login";
/*     */       }
/*     */     }
/* 207 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute() {
/*     */     try {
/* 212 */       if (!loadJiveObjects())
/* 213 */         return "fatal";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 217 */       setLoginAttributes();
/* 218 */       addActionError(getText("question.error_unauth"));
/* 219 */       return "login";
/*     */     }
/*     */ 
/* 222 */     ForumMessage message = getThread().getRootMessage();
/*     */ 
/* 224 */     if ((!isSystemAdmin()) && (!isAuthor(message)) && (!isModerator(getForum()))) {
/* 225 */       setLoginAttributes();
/* 226 */       addActionError(getText("question.error_unauth"));
/* 227 */       return "login";
/*     */     }
/*     */ 
/* 230 */     if ("true".equals(getDoCancel())) {
/* 231 */       return "cancel";
/*     */     }
/*     */ 
/* 235 */     if (hasErrors())
/*     */     {
/* 237 */       addActionError(getText("question.general_error"));
/* 238 */       return "error";
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 244 */       if (("assumed_answered".equals(this.resolution)) && (!isSystemAdmin()) && (!isAuthor(message)) && (!isModerator(getForum())))
/*     */       {
/* 247 */         setLoginAttributes();
/* 248 */         addActionError(getText("question.error_unauth"));
/* 249 */         return "login";
/*     */       }
/* 251 */       getThread().setProperty("questionResolution", this.resolution);
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 254 */       addActionError(getText("question.error_unauth"));
/* 255 */       return "error";
/*     */     }
/*     */ 
/* 258 */     return "success";
/*     */   }
/*     */ 
/*     */   private boolean loadJiveObjects()
/*     */     throws UnauthorizedException
/*     */   {
/* 264 */     boolean success = false;
/*     */     try {
/* 266 */       setThread(getForumFactory().getForumThread(getThreadID()));
/* 267 */       setForum(getThread().getForum());
/* 268 */       setForumID(getForum().getID());
/* 269 */       success = true;
/*     */     }
/*     */     catch (ForumThreadNotFoundException ftnfe) {
/* 272 */       addActionError(ftnfe.getMessage());
/*     */     }
/* 274 */     return success;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  54 */     String inactiveProp = JiveGlobals.getJiveProperty("markAsQuestion.inactiveWindow");
/*  55 */     if (inactiveProp != null)
/*     */       try {
/*  57 */         INACTIVE_WINDOW = Integer.parseInt(inactiveProp);
/*     */       }
/*     */       catch (NumberFormatException nfe) {
/*  60 */         Log.warn("Jive property 'markAsQuestion.inactiveWindow' is invalid. Must be a number. Using default value of 5 days.");
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.QuestionAction
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum.net;

import com.jivesoftware.base.JiveManager;
import com.jivesoftware.base.NotFoundException;
import com.jivesoftware.base.UnauthorizedException;
import java.io.IOException;
import java.net.Socket;
import java.util.Iterator;

public abstract interface ConnectionManager extends JiveManager
{
  public abstract int getMaxConnections();

  public abstract void setMaxConnections(int paramInt);

  public abstract int getConnectionCount();

  public abstract Iterator getConnections();

  public abstract Iterator getConnections(BasicResultFilter paramBasicResultFilter);

  public abstract Connection getConnection(int paramInt)
    throws NotFoundException;

  public abstract Connection createConnection(Socket paramSocket, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException;

  public abstract void addConnection(Connection paramConnection);

  public abstract void removeConnection(Connection paramConnection)
    throws InterruptedException;

  public abstract ConnectionMonitor getConnectedMonitor();

  public abstract ConnectionMonitor getConfigMonitor();

  public abstract ConnectionMonitor getDisconnectedMonitor();

  public abstract Object registerCloseListener(ConnectionCloseListener paramConnectionCloseListener, Object paramObject)
    throws UnauthorizedException;

  public abstract Object removeCloseListener(ConnectionCloseListener paramConnectionCloseListener)
    throws UnauthorizedException;

  public abstract void stop();
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.ConnectionManager
 * JD-Core Version:    0.6.2
 */
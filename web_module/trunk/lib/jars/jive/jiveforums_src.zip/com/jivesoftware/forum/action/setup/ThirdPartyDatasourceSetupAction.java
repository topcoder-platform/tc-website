/*     */ package com.jivesoftware.forum.action.setup;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.database.ConnectionProvider;
/*     */ import com.jivesoftware.base.database.DefaultConnectionProvider;
/*     */ import com.jivesoftware.forum.Version;
/*     */ import com.jivesoftware.forum.Version.Edition;
/*     */ import com.jivesoftware.util.ClassUtils;
/*     */ import com.jivesoftware.util.JiveProperties;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import com.opensymphony.xwork.ModelDriven;
/*     */ import com.opensymphony.xwork.Preparable;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ThirdPartyDatasourceSetupAction extends DatasourceSetupAction
/*     */   implements ModelDriven, Preparable, Validateable, Serializable
/*     */ {
/*     */   private Parameters params;
/*     */ 
/*     */   public ThirdPartyDatasourceSetupAction()
/*     */   {
/*  29 */     this.params = new Parameters();
/*     */   }
/*     */ 
/*     */   public Object getModel()
/*     */   {
/*  34 */     return this.params;
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */   {
/*  40 */     this.params.username = JiveGlobals.getLocalProperty("database.defaultProvider.username");
/*  41 */     this.params.password = JiveGlobals.getLocalProperty("database.defaultProvider.password");
/*  42 */     this.params.driver = JiveGlobals.getLocalProperty("database.defaultProvider.driver");
/*  43 */     this.params.serverURL = JiveGlobals.getLocalProperty("database.defaultProvider.serverURL");
/*     */     try
/*     */     {
/*  46 */       this.params.minConnections = Integer.parseInt(JiveGlobals.getLocalProperty("database.defaultProvider.minConnections"));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     try {
/*  52 */       this.params.maxConnections = Integer.parseInt(JiveGlobals.getLocalProperty("database.defaultProvider.maxConnections"));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     try {
/*  58 */       this.params.connectionTimeout = Double.parseDouble(JiveGlobals.getLocalProperty("database.defaultProvider.connectionTimeout"));
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/*     */   }
/*     */ 
/*     */   public String doDefault() {
/*  65 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/*  66 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "in_progress");
/*  67 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "incomplete");
/*  68 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "incomplete");
/*  69 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "incomplete");
/*  70 */     return "input";
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/*     */     try {
/*  76 */       ClassUtils.forName(this.params.driver);
/*     */     }
/*     */     catch (Exception cnfe) {
/*  79 */       addFieldError("driver", getText("setup.error.thirdpartydatasource.unable_to_load_driver"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public String execute() {
/*  84 */     setupDriver();
/*     */ 
/*  86 */     if ((hasErrors()) || (!testConnection())) {
/*  87 */       return "error";
/*     */     }
/*     */ 
/*  92 */     JiveProperties.getInstance().init();
/*     */ 
/*  94 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.1", "done");
/*  95 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.2", "done");
/*  96 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.3", "in_progress");
/*  97 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.4", "incomplete");
/*  98 */     ActionContext.getContext().getSession().put("jive.setup.sidebar.5", "incomplete");
/*  99 */     return "next";
/*     */   }
/*     */ 
/*     */   private void setupDriver()
/*     */   {
/* 106 */     JiveGlobals.deleteLocalProperty("connectionProvider.className");
/* 107 */     ConnectionProvider conProvider = new DefaultConnectionProvider();
/*     */     try
/*     */     {
/* 112 */       BeanInfo beanInfo = Introspector.getBeanInfo(conProvider.getClass());
/*     */ 
/* 114 */       PropertyDescriptor[] propDescriptors = beanInfo.getPropertyDescriptors();
/*     */ 
/* 116 */       PropertyDescriptor descriptor = null;
/* 117 */       Method writeMethod = null;
/*     */ 
/* 120 */       descriptor = getPropertyDescriptor(propDescriptors, "minConnections");
/* 121 */       writeMethod = descriptor.getWriteMethod();
/* 122 */       writeMethod.invoke(conProvider, (Object[])new Integer[] { new Integer(this.params.minConnections) });
/*     */ 
/* 124 */       descriptor = getPropertyDescriptor(propDescriptors, "maxConnections");
/* 125 */       writeMethod = descriptor.getWriteMethod();
/* 126 */       writeMethod.invoke(conProvider, (Object[])new Integer[] { new Integer(this.params.maxConnections) });
/*     */ 
/* 129 */       descriptor = getPropertyDescriptor(propDescriptors, "connectionTimeout");
/* 130 */       writeMethod = descriptor.getWriteMethod();
/* 131 */       writeMethod.invoke(conProvider, (Object[])new Double[] { new Double(this.params.connectionTimeout) });
/*     */ 
/* 134 */       descriptor = getPropertyDescriptor(propDescriptors, "driver");
/* 135 */       writeMethod = descriptor.getWriteMethod();
/* 136 */       writeMethod.invoke(conProvider, (Object[])new String[] { this.params.driver });
/*     */ 
/* 138 */       descriptor = getPropertyDescriptor(propDescriptors, "serverURL");
/* 139 */       writeMethod = descriptor.getWriteMethod();
/* 140 */       writeMethod.invoke(conProvider, (Object[])new String[] { this.params.serverURL });
/*     */ 
/* 142 */       descriptor = getPropertyDescriptor(propDescriptors, "username");
/* 143 */       writeMethod = descriptor.getWriteMethod();
/* 144 */       writeMethod.invoke(conProvider, (Object[])new String[] { this.params.username });
/*     */ 
/* 146 */       descriptor = getPropertyDescriptor(propDescriptors, "password");
/* 147 */       writeMethod = descriptor.getWriteMethod();
/* 148 */       writeMethod.invoke(conProvider, (Object[])new String[] { this.params.password });
/*     */     }
/*     */     catch (Exception e) {
/* 151 */       addActionError(getText("setup.error.thirdpartydatasource.unable_to_set_props"));
/* 152 */       Log.error(e);
/*     */     }
/*     */ 
/* 155 */     ConnectionManager.setConnectionProvider(conProvider);
/*     */   }
/*     */ 
/*     */   private static final PropertyDescriptor getPropertyDescriptor(PropertyDescriptor[] pd, String name)
/*     */   {
/* 162 */     for (int i = 0; i < pd.length; i++) {
/* 163 */       if (name.equals(pd[i].getName())) {
/* 164 */         return pd[i];
/*     */       }
/*     */     }
/*     */ 
/* 168 */     return null; } 
/*     */   class Parameters { private String username;
/*     */     private String password;
/* 174 */     private int minConnections = 5;
/* 175 */     private int maxConnections = Version.getEdition() == Version.Edition.PROFESSIONAL ? 15 : 25;
/* 176 */     private double connectionTimeout = 1.0D;
/*     */     private String driver;
/*     */     private String serverURL;
/*     */ 
/*     */     Parameters() {  } 
/* 181 */     public String getUsername() { return this.username; }
/*     */ 
/*     */     public void setUsername(String username)
/*     */     {
/* 185 */       this.username = (username == null ? null : username.trim());
/*     */     }
/*     */ 
/*     */     public String getPassword() {
/* 189 */       return this.password;
/*     */     }
/*     */ 
/*     */     public void setPassword(String password) {
/* 193 */       this.password = (password == null ? null : password.trim());
/*     */     }
/*     */ 
/*     */     public int getMinConnections() {
/* 197 */       return this.minConnections;
/*     */     }
/*     */ 
/*     */     public void setMinConnections(int minConnections) {
/* 201 */       this.minConnections = minConnections;
/*     */     }
/*     */ 
/*     */     public int getMaxConnections() {
/* 205 */       return this.maxConnections;
/*     */     }
/*     */ 
/*     */     public void setMaxConnections(int maxConnections) {
/* 209 */       this.maxConnections = maxConnections;
/*     */     }
/*     */ 
/*     */     public double getConnectionTimeout() {
/* 213 */       return this.connectionTimeout;
/*     */     }
/*     */ 
/*     */     public void setConnectionTimeout(double connectionTimeout) {
/* 217 */       this.connectionTimeout = connectionTimeout;
/*     */     }
/*     */ 
/*     */     public String getDriver() {
/* 221 */       return this.driver;
/*     */     }
/*     */ 
/*     */     public void setDriver(String driver) {
/* 225 */       this.driver = (driver == null ? null : driver.trim());
/*     */     }
/*     */ 
/*     */     public String getServerURL() {
/* 229 */       return this.serverURL;
/*     */     }
/*     */ 
/*     */     public void setServerURL(String serverURL) {
/* 233 */       this.serverURL = (serverURL == null ? null : serverURL.trim());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.setup.ThirdPartyDatasourceSetupAction
 * JD-Core Version:    0.6.2
 */
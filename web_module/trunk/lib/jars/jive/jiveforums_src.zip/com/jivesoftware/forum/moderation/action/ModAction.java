/*    */ package com.jivesoftware.forum.moderation.action;
/*    */ 
/*    */ public class ModAction
/*    */ {
/*    */   private long messageID;
/*    */   private int type;
/*    */   private String subject;
/*    */   private String body;
/*    */   private boolean showEditStamp;
/*    */   private String editStamp;
/*    */ 
/*    */   public long getMessageID()
/*    */   {
/* 13 */     return this.messageID;
/*    */   }
/*    */ 
/*    */   public void setMessageID(long messageID) {
/* 17 */     this.messageID = messageID;
/*    */   }
/*    */ 
/*    */   public int getType() {
/* 21 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(int type) {
/* 25 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public String getSubject() {
/* 29 */     return this.subject;
/*    */   }
/*    */ 
/*    */   public void setSubject(String subject) {
/* 33 */     this.subject = subject;
/*    */   }
/*    */ 
/*    */   public String getBody() {
/* 37 */     return this.body;
/*    */   }
/*    */ 
/*    */   public void setBody(String body) {
/* 41 */     this.body = body;
/*    */   }
/*    */ 
/*    */   public boolean isShowEditStamp() {
/* 45 */     return this.showEditStamp;
/*    */   }
/*    */ 
/*    */   public void setShowEditStamp(boolean showEditStamp) {
/* 49 */     this.showEditStamp = showEditStamp;
/*    */   }
/*    */ 
/*    */   public String getEditStamp() {
/* 53 */     return this.editStamp;
/*    */   }
/*    */ 
/*    */   public void setEditStamp(String editStamp) {
/* 57 */     this.editStamp = editStamp;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.moderation.action.ModAction
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.forum.ForumCategory;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.stats.ViewCountManager;
/*    */ import com.opensymphony.xwork.ActionInvocation;
/*    */ import com.opensymphony.xwork.interceptor.AroundInterceptor;
/*    */ 
/*    */ public class ViewCountInterceptor extends AroundInterceptor
/*    */ {
/*    */   public static final String CATEGORY = "category";
/*    */   public static final String FORUM = "forum";
/*    */   public static final String THREAD = "thread";
/*    */   private String type;
/*    */ 
/*    */   public String getType()
/*    */   {
/* 51 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(String type)
/*    */   {
/* 62 */     if ((!"category".equals(type)) && (!"forum".equals(type)) && (!"thread".equals(type))) {
/* 63 */       throw new IllegalArgumentException("Invalid type");
/*    */     }
/* 65 */     this.type = type;
/*    */   }
/*    */ 
/*    */   protected void before(ActionInvocation in)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   protected void after(ActionInvocation in, String result)
/*    */     throws Exception
/*    */   {
/* 81 */     if (("success".equals(result)) || (result.startsWith("success")))
/*    */     {
/* 83 */       if (ViewCountManager.isViewCountsEnabled()) {
/* 84 */         String type = getType();
/* 85 */         if (type == null) {
/* 86 */           throw new IllegalArgumentException("Invalid type");
/*    */         }
/* 88 */         if (Log.isDebugEnabled()) {
/* 89 */           Log.debug("Adding a view count from class " + getClass().getName() + ", type: " + type);
/*    */         }
/*    */ 
/* 94 */         if ("category".equals(type)) {
/* 95 */           ForumCategoryAction action = (ForumCategoryAction)in.getAction();
/*    */ 
/* 97 */           long rootID = action.getForumFactory().getRootForumCategory().getID();
/* 98 */           if (action.getCategory().getID() != rootID) {
/* 99 */             ViewCountManager.getInstance().addCategoryCount(action.getCategory());
/*    */           }
/*    */         }
/* 102 */         else if ("forum".equals(type)) {
/* 103 */           ForumAction action = (ForumAction)in.getAction();
/* 104 */           ViewCountManager.getInstance().addForumCount(action.getForum());
/*    */         }
/* 106 */         else if ("thread".equals(type)) {
/* 107 */           ForumThreadAction action = (ForumThreadAction)in.getAction();
/* 108 */           ViewCountManager.getInstance().addThreadCount(action.getThread());
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.ViewCountInterceptor
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.net.policies;
/*    */ 
/*    */ import com.jivesoftware.forum.net.AcceptPolicy;
/*    */ import com.jivesoftware.forum.net.Connection;
/*    */ 
/*    */ public class BasicAcceptPolicy
/*    */   implements AcceptPolicy
/*    */ {
/*    */   private boolean accept;
/*    */ 
/*    */   public BasicAcceptPolicy(boolean alwaysAccept)
/*    */   {
/* 34 */     this.accept = alwaysAccept;
/*    */   }
/*    */ 
/*    */   public boolean evaluate(Connection connection)
/*    */   {
/* 45 */     return this.accept;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.net.policies.BasicAcceptPolicy
 * JD-Core Version:    0.6.2
 */
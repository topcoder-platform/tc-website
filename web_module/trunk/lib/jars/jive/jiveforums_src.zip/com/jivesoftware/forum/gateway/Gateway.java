/*    */ package com.jivesoftware.forum.gateway;
/*    */ 
/*    */ import com.jivesoftware.forum.ForumMessage;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class Gateway
/*    */   implements GatewayImporter, GatewayExporter
/*    */ {
/*    */   private GatewayImporter importer;
/*    */   private GatewayExporter exporter;
/*    */ 
/*    */   public Gateway(GatewayImporter importer, GatewayExporter exporter)
/*    */   {
/* 36 */     this.importer = importer;
/* 37 */     this.exporter = exporter;
/*    */   }
/*    */ 
/*    */   public void importData(Date date) throws GatewayException {
/* 41 */     this.importer.importData(date);
/*    */   }
/*    */ 
/*    */   public void exportData(ForumMessage message) throws GatewayException {
/* 45 */     this.exporter.exportData(message);
/*    */   }
/*    */ 
/*    */   public void exportData(ForumMessage[] messages) throws GatewayException {
/* 49 */     this.exporter.exportData(messages);
/*    */   }
/*    */ 
/*    */   public GatewayImporter getGatewayImporter()
/*    */   {
/* 58 */     return this.importer;
/*    */   }
/*    */ 
/*    */   public GatewayExporter getGatewayExporter()
/*    */   {
/* 67 */     return this.exporter;
/*    */   }
/*    */ 
/*    */   public void stop()
/*    */     throws GatewayException
/*    */   {
/* 74 */     this.importer.stop();
/* 75 */     this.exporter.stop();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.Gateway
 * JD-Core Version:    0.6.2
 */
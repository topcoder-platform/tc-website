/*    */ package com.jivesoftware.forum.interceptor;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class KeywordInterceptorBeanInfo extends JiveBeanInfo
/*    */ {
/* 23 */   public static final String[] PROPERTY_NAMES = { "stemmingEnabled", "moderationQueryString", "blockQueryString", "blockError", "emailQueryString", "emailNotifyList", "emailName", "emailAddress", "emailSubject", "emailBody" };
/*    */ 
/*    */   public Class getBeanClass()
/*    */   {
/* 32 */     return KeywordInterceptor.class;
/*    */   }
/*    */ 
/*    */   public String[] getPropertyNames() {
/* 36 */     return PROPERTY_NAMES;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 40 */     return "KeywordInterceptor";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.KeywordInterceptorBeanInfo
 * JD-Core Version:    0.6.2
 */
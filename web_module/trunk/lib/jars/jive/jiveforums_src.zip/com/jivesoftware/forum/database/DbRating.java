/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.forum.Rating;
/*     */ import com.jivesoftware.forum.RatingManagerFactory;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.CacheSizes;
/*     */ import com.jivesoftware.util.Cacheable;
/*     */ import com.tangosol.net.Invocable;
/*     */ import com.tangosol.net.InvocationService;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class DbRating
/*     */   implements Rating, Cacheable
/*     */ {
/*     */   private static final String SET_RATING_SCORE = "UPDATE jiveRatingType SET score=? WHERE score=?";
/*     */   private static final String SET_RATING_DESCRIPTION = "UPDATE jiveRatingType SET description=? WHERE score=?";
/*     */   private static final String UPDATE_RATINGS = "UPDATE jiveRating SET score=? WHERE score=?";
/*  32 */   private int score = -1;
/*  33 */   private String description = "";
/*     */ 
/*     */   public DbRating(int score, String description)
/*     */   {
/*  37 */     this.score = score;
/*  38 */     this.description = description;
/*     */   }
/*     */ 
/*     */   public int getScore() {
/*  42 */     return this.score;
/*     */   }
/*     */ 
/*     */   public synchronized void setScore(int score) {
/*  46 */     if (this.score == score) {
/*  47 */       return;
/*     */     }
/*     */ 
/*  50 */     DbRatingManager manager = DbRatingManager.getInstance();
/*     */ 
/*  53 */     Iterator ratings = manager.getAvailableRatings();
/*  54 */     while (ratings.hasNext()) {
/*  55 */       Rating rating = (Cacheable)ratings.next();
/*  56 */       if (rating.getScore() == score) {
/*  57 */         throw new IllegalArgumentException("Rating score is already in use: " + score);
/*     */       }
/*     */     }
/*     */ 
/*  61 */     int oldScore = this.score;
/*  62 */     this.score = score;
/*     */ 
/*  65 */     Connection con = null;
/*  66 */     PreparedStatement pstmt = null;
/*  67 */     boolean abortTransaction = false;
/*     */     try
/*     */     {
/*  71 */       con = ConnectionManager.getTransactionConnection();
/*  72 */       pstmt = con.prepareStatement("UPDATE jiveRatingType SET score=? WHERE score=?");
/*  73 */       pstmt.setInt(1, score);
/*  74 */       pstmt.setInt(2, oldScore);
/*  75 */       pstmt.execute();
/*  76 */       pstmt.close();
/*     */ 
/*  79 */       pstmt = con.prepareStatement("UPDATE jiveRating SET score=? WHERE score=?");
/*  80 */       pstmt.setInt(1, score);
/*  81 */       pstmt.setInt(2, oldScore);
/*  82 */       pstmt.execute();
/*  83 */       pstmt.close();
/*     */     }
/*     */     catch (SQLException e) {
/*  86 */       Log.error(e);
/*  87 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/*  90 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */ 
/*  94 */     manager.loadAvailableRatings();
/*     */ 
/*  97 */     CacheFactory.doClusterTask(new UpdateAvailableRatingsClusterTask());
/*     */ 
/* 100 */     RatingManagerFactory.ratingsCache.clear();
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 104 */     return this.description;
/*     */   }
/*     */ 
/*     */   public synchronized void setDescription(String description) {
/* 108 */     this.description = description;
/*     */ 
/* 111 */     Connection con = null;
/* 112 */     PreparedStatement pstmt = null;
/* 113 */     boolean abortTransaction = false;
/*     */     try
/*     */     {
/* 116 */       con = ConnectionManager.getTransactionConnection();
/* 117 */       pstmt = con.prepareStatement("UPDATE jiveRatingType SET description=? WHERE score=?");
/* 118 */       pstmt.setString(1, description);
/* 119 */       pstmt.setInt(2, this.score);
/* 120 */       pstmt.execute();
/* 121 */       pstmt.close();
/*     */     }
/*     */     catch (SQLException e) {
/* 124 */       Log.error(e);
/* 125 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 128 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */ 
/* 132 */     DbRatingManager.getInstance().loadAvailableRatings();
/*     */ 
/* 135 */     CacheFactory.doClusterTask(new UpdateAvailableRatingsClusterTask());
/*     */   }
/*     */ 
/*     */   public boolean equals(Rating rating) {
/* 139 */     if ((rating != null) && (rating.getScore() == this.score)) {
/* 140 */       return true;
/*     */     }
/*     */ 
/* 143 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj) {
/* 147 */     if (((obj instanceof Cacheable)) && (((Cacheable)obj).getScore() == this.score)) {
/* 148 */       return true;
/*     */     }
/*     */ 
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 155 */     return this.score;
/*     */   }
/*     */ 
/*     */   public int getCachedSize() {
/* 159 */     int size = 0;
/* 160 */     size += CacheSizes.sizeOfObject();
/* 161 */     size += CacheSizes.sizeOfInt();
/* 162 */     size += CacheSizes.sizeOfString(this.description);
/*     */ 
/* 164 */     return size;
/*     */   }
/*     */ 
/*     */   public class UpdateAvailableRatingsClusterTask
/*     */     implements Invocable
/*     */   {
/*     */     public UpdateAvailableRatingsClusterTask()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void init(InvocationService service)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*     */       try
/*     */       {
/* 187 */         DbRatingManager manager = DbRatingManager.getInstance();
/*     */ 
/* 190 */         manager.loadAvailableRatings();
/*     */       } catch (Exception e) {
/* 192 */         Log.error(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     public Object getResult()
/*     */     {
/* 199 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbRating
 * JD-Core Version:    0.6.2
 */
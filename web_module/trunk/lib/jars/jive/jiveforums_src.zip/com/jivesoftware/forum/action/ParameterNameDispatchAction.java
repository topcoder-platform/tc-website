/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.opensymphony.webwork.ServletActionContext;
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ public class ParameterNameDispatchAction extends ForumActionSupport
/*    */ {
/*    */   public String execute()
/*    */   {
/* 22 */     for (Enumeration e = ServletActionContext.getRequest().getParameterNames(); e.hasMoreElements(); ) {
/* 23 */       String name = (String)e.nextElement();
/* 24 */       if ((name.startsWith("do")) && (name.length() >= 3)) {
/* 25 */         name = name.substring(2, name.length());
/* 26 */         return name;
/*    */       }
/*    */     }
/* 29 */     return "error";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.ParameterNameDispatchAction
 * JD-Core Version:    0.6.2
 */
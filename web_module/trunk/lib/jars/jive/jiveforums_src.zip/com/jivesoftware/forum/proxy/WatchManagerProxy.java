/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserIteratorProxy;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.Watch;
/*     */ import com.jivesoftware.forum.WatchManager;
/*     */ import com.jivesoftware.util.CronTimer;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class WatchManagerProxy
/*     */   implements WatchManager
/*     */ {
/*     */   private WatchManager manager;
/*     */   private AuthToken authToken;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public WatchManagerProxy(WatchManager manager, AuthToken authToken, Permissions permissions)
/*     */   {
/*  43 */     this.manager = manager;
/*  44 */     this.authToken = authToken;
/*  45 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public void setDeleteDays(int deleteDays) throws UnauthorizedException {
/*  49 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  50 */       this.manager.setDeleteDays(deleteDays);
/*     */     }
/*     */     else
/*  53 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getDeleteDays()
/*     */   {
/*  58 */     return this.manager.getDeleteDays();
/*     */   }
/*     */ 
/*     */   public CronTimer getBatchTimer(User user) throws UnauthorizedException {
/*  62 */     if ((this.permissions.hasPermission(576460752303423488L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/*  65 */       return this.manager.getBatchTimer(user);
/*     */     }
/*     */ 
/*  68 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void setBatchTimer(User user, CronTimer timer) throws UnauthorizedException
/*     */   {
/*  73 */     if ((this.permissions.hasPermission(576460752303423488L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/*  76 */       this.manager.setBatchTimer(user, timer);
/*     */     }
/*     */     else
/*  79 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Watch createWatch(User user, User watchedUser) throws UnauthorizedException
/*     */   {
/*  84 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/*  87 */       return this.manager.createWatch(user, watchedUser);
/*     */     }
/*     */ 
/*  90 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Watch createWatch(User user, ForumThread thread) throws UnauthorizedException
/*     */   {
/*  95 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/*  98 */       return this.manager.createWatch(user, thread);
/*     */     }
/*     */ 
/* 101 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Watch createWatch(User user, Forum forum) throws UnauthorizedException
/*     */   {
/* 106 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 109 */       return this.manager.createWatch(user, forum);
/*     */     }
/*     */ 
/* 112 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Watch createWatch(User user, ForumCategory category) throws UnauthorizedException
/*     */   {
/* 117 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 120 */       return this.manager.createWatch(user, category);
/*     */     }
/*     */ 
/* 123 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getTotalWatchCount(User user, int objectType) throws UnauthorizedException
/*     */   {
/* 128 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 131 */       return this.manager.getTotalWatchCount(user, objectType);
/*     */     }
/*     */ 
/* 134 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getAllWatches(User user, int objectType) throws UnauthorizedException
/*     */   {
/* 139 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 142 */       if (objectType == 3) {
/* 143 */         return new UserIteratorProxy(this.manager.getAllWatches(user, objectType), this.authToken, this.permissions);
/*     */       }
/*     */ 
/* 146 */       return new IteratorProxy(objectType, this.manager.getAllWatches(user, objectType), this.authToken);
/*     */     }
/*     */ 
/* 150 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getWatchCount(User user, Forum forum) throws UnauthorizedException
/*     */   {
/* 155 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 158 */       return this.manager.getWatchCount(user, forum);
/*     */     }
/*     */ 
/* 161 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getWatchCount(User user, ForumCategory category) throws UnauthorizedException
/*     */   {
/* 166 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 169 */       return this.manager.getWatchCount(user, category);
/*     */     }
/*     */ 
/* 172 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getWatches(User user, Forum forum) throws UnauthorizedException
/*     */   {
/* 177 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 180 */       return new IteratorProxy(1, this.manager.getWatches(user, forum), this.authToken);
/*     */     }
/*     */ 
/* 183 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getWatches(User user, ForumCategory category) throws UnauthorizedException
/*     */   {
/* 188 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 191 */       return new IteratorProxy(0, this.manager.getWatches(user, category), this.authToken);
/*     */     }
/*     */ 
/* 194 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Watch getWatch(User user, User watchedUser) throws UnauthorizedException
/*     */   {
/* 199 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 202 */       return this.manager.getWatch(user, watchedUser);
/*     */     }
/*     */ 
/* 205 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Watch getWatch(User user, ForumThread thread) throws UnauthorizedException
/*     */   {
/* 210 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 213 */       return this.manager.getWatch(user, thread);
/*     */     }
/*     */ 
/* 216 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Watch getWatch(User user, Forum forum) throws UnauthorizedException
/*     */   {
/* 221 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 224 */       return this.manager.getWatch(user, forum);
/*     */     }
/*     */ 
/* 227 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Watch getWatch(User user, ForumCategory category) throws UnauthorizedException
/*     */   {
/* 232 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 235 */       return this.manager.getWatch(user, category);
/*     */     }
/*     */ 
/* 238 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean isWatched(User user, ForumCategory category) throws UnauthorizedException
/*     */   {
/* 243 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 246 */       return this.manager.isWatched(user, category);
/*     */     }
/*     */ 
/* 249 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean isWatched(User user, Forum forum) throws UnauthorizedException
/*     */   {
/* 254 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 257 */       return this.manager.isWatched(user, forum);
/*     */     }
/*     */ 
/* 260 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean isWatched(User user, ForumThread thread) throws UnauthorizedException
/*     */   {
/* 265 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 268 */       return this.manager.isWatched(user, thread);
/*     */     }
/*     */ 
/* 271 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean isWatched(User user, User watchedUser) throws UnauthorizedException
/*     */   {
/* 276 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 279 */       return this.manager.isWatched(user, watchedUser);
/*     */     }
/*     */ 
/* 282 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteWatches(User user) throws UnauthorizedException
/*     */   {
/* 287 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == user.getID()))
/*     */     {
/* 290 */       this.manager.deleteWatches(user);
/*     */     }
/*     */     else
/* 293 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteWatch(Watch watch) throws UnauthorizedException
/*     */   {
/* 298 */     if ((this.permissions.hasPermission(720575940379279360L)) || (this.authToken.getUserID() == watch.getUser().getID()))
/*     */     {
/* 301 */       this.manager.deleteWatch(watch);
/*     */     }
/*     */     else
/* 304 */       throw new UnauthorizedException();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.WatchManagerProxy
 * JD-Core Version:    0.6.2
 */
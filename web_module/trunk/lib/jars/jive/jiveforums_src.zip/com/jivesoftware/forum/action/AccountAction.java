/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.AuthFactory;
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserAlreadyExistsException;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.opensymphony.webwork.ServletActionContext;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class AccountAction extends ForumActionSupport
/*     */   implements Validateable
/*     */ {
/*     */   public static final String DISABLED = "disabled";
/*     */   public static final int DEFAULT_MIN_PASSWORD_LENGTH = 4;
/*  45 */   private int defaultMinPasswordLength = JiveGlobals.getJiveIntProperty("skin.default.defaultMinPasswordLength", 6);
/*     */   private String name;
/*     */   private Boolean nameVisible;
/*     */   private String email;
/*     */   private Boolean emailVisible;
/*     */   private String username;
/*     */   private String password;
/*     */   private String passwordConfirm;
/*     */   private String location;
/*     */   private String occupation;
/*     */   private String homepage;
/*     */   private String biography;
/*     */   private String signature;
/*     */   private Boolean signatureVisible;
/*     */   private Boolean autoLogin;
/*     */   private User newUser;
/*  69 */   private String doCancel = null;
/*     */ 
/*     */   public String getName()
/*     */   {
/*  79 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  89 */     if (name != null) {
/*  90 */       name = name.trim();
/*  91 */       if ((!"".equals(name)) && (name.length() <= 100))
/*  92 */         this.name = name;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Boolean getNameVisible()
/*     */   {
/* 104 */     if (this.nameVisible == null) {
/* 105 */       return Boolean.TRUE;
/*     */     }
/*     */ 
/* 108 */     return this.nameVisible;
/*     */   }
/*     */ 
/*     */   public void setNameVisible(Boolean nameVisible)
/*     */   {
/* 118 */     this.nameVisible = nameVisible;
/*     */   }
/*     */ 
/*     */   public String getEmail()
/*     */   {
/* 127 */     return this.email;
/*     */   }
/*     */ 
/*     */   public void setEmail(String email)
/*     */   {
/* 137 */     if (email != null) {
/* 138 */       email = email.trim();
/*     */ 
/* 140 */       if (email.length() >= 3) {
/* 141 */         int atPos = email.indexOf('@');
/* 142 */         if ((atPos > 0) && (atPos < email.length() - 1))
/* 143 */           this.email = email;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Boolean getEmailVisible()
/*     */   {
/* 156 */     if (this.emailVisible == null) {
/* 157 */       return Boolean.TRUE;
/*     */     }
/*     */ 
/* 160 */     return this.emailVisible;
/*     */   }
/*     */ 
/*     */   public void setEmailVisible(Boolean emailVisible)
/*     */   {
/* 170 */     this.emailVisible = emailVisible;
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 179 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 189 */     if (username != null) {
/* 190 */       username = username.trim();
/* 191 */       if ((!"".equals(username)) && (username.length() <= 30))
/* 192 */         this.username = username;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 203 */     return this.password;
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 213 */     if (password != null)
/* 214 */       this.password = password.trim();
/*     */   }
/*     */ 
/*     */   public String getPasswordConfirm()
/*     */   {
/* 224 */     return this.passwordConfirm;
/*     */   }
/*     */ 
/*     */   public void setPasswordConfirm(String passwordConfirm)
/*     */   {
/* 234 */     if (passwordConfirm != null)
/* 235 */       this.passwordConfirm = passwordConfirm.trim();
/*     */   }
/*     */ 
/*     */   public String getLocation()
/*     */   {
/* 245 */     return this.location;
/*     */   }
/*     */ 
/*     */   public void setLocation(String location)
/*     */   {
/* 255 */     if (location != null)
/* 256 */       if (location.length() > 150) {
/* 257 */         addFieldError("location", getText("account.error_location_not_valid"));
/*     */       }
/*     */       else
/* 260 */         this.location = location;
/*     */   }
/*     */ 
/*     */   public String getOccupation()
/*     */   {
/* 271 */     return this.occupation;
/*     */   }
/*     */ 
/*     */   public void setOccupation(String occupation)
/*     */   {
/* 280 */     if (occupation != null)
/* 281 */       if (occupation.length() > 150) {
/* 282 */         addFieldError("occupation", getText("account.error_occupation_not_valid"));
/*     */       }
/*     */       else
/* 285 */         this.occupation = occupation;
/*     */   }
/*     */ 
/*     */   public String getHomepage()
/*     */   {
/* 296 */     return this.homepage;
/*     */   }
/*     */ 
/*     */   public void setHomepage(String homepage)
/*     */   {
/* 306 */     if ((homepage != null) && (!"http://".equals(homepage.trim())))
/* 307 */       if (homepage.length() > 200) {
/* 308 */         addFieldError("homepage", getText("account.error_homepage_not_valid"));
/*     */       }
/* 311 */       else if ((!"".equals(homepage)) && (!homepage.startsWith("http://"))) {
/* 312 */         this.homepage = ("http://" + homepage);
/*     */       }
/*     */       else
/* 315 */         this.homepage = homepage;
/*     */   }
/*     */ 
/*     */   public String getBiography()
/*     */   {
/* 327 */     return this.biography;
/*     */   }
/*     */ 
/*     */   public void setBiography(String biography)
/*     */   {
/* 336 */     if (biography != null)
/* 337 */       if (biography.length() > 1000) {
/* 338 */         addFieldError("biography", getText("account.error_biography_not_valid"));
/*     */       }
/*     */       else
/* 341 */         this.biography = biography;
/*     */   }
/*     */ 
/*     */   public String getSignature()
/*     */   {
/* 352 */     return this.signature;
/*     */   }
/*     */ 
/*     */   public void setSignature(String signature)
/*     */   {
/* 361 */     if (signature != null)
/* 362 */       if (signature.length() > 500) {
/* 363 */         addFieldError("signature", getText("account.error_sig_not_valid"));
/*     */       }
/*     */       else
/* 366 */         this.signature = signature;
/*     */   }
/*     */ 
/*     */   public Boolean getSignatureVisible()
/*     */   {
/* 377 */     if (this.signatureVisible == null) {
/* 378 */       return Boolean.TRUE;
/*     */     }
/*     */ 
/* 381 */     return this.signatureVisible;
/*     */   }
/*     */ 
/*     */   public void setSignatureVisible(Boolean signatureVisible)
/*     */   {
/* 391 */     this.signatureVisible = signatureVisible;
/*     */   }
/*     */ 
/*     */   public Boolean isAutoLogin()
/*     */   {
/* 400 */     if (this.autoLogin == null) {
/* 401 */       return Boolean.FALSE;
/*     */     }
/*     */ 
/* 404 */     return this.autoLogin;
/*     */   }
/*     */ 
/*     */   public void setAutoLogin(String autoLogin)
/*     */   {
/* 414 */     if (("on".equalsIgnoreCase(autoLogin)) || ("true".equalsIgnoreCase(autoLogin)))
/* 415 */       this.autoLogin = Boolean.TRUE;
/*     */   }
/*     */ 
/*     */   public String getDoCancel()
/*     */   {
/* 427 */     return this.doCancel;
/*     */   }
/*     */ 
/*     */   public void setDoCancel(String doCancel)
/*     */   {
/* 436 */     if ((doCancel != null) && (!"".equals(doCancel)))
/* 437 */       this.doCancel = "true";
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/* 448 */     if ("true".equals(getDoCancel())) {
/* 449 */       return;
/*     */     }
/*     */ 
/* 453 */     if ((this.name == null) && (getFieldErrors().get("name") == null)) {
/* 454 */       addFieldError("name", getText("account.error_your_name"));
/*     */     }
/* 456 */     if ((this.email == null) && (getFieldErrors().get("email") == null)) {
/* 457 */       addFieldError("email", getText("account.error_email"));
/*     */     }
/* 459 */     if ((this.username == null) && (getFieldErrors().get("username") == null)) {
/* 460 */       List args = new ArrayList(1);
/* 461 */       args.add(new Integer(this.defaultMinPasswordLength));
/* 462 */       addFieldError("username", getText("account.error_username_length", args));
/*     */     }
/*     */     else
/*     */     {
/*     */       try {
/* 467 */         Long.parseLong(this.username);
/* 468 */         addFieldError("username", getText("account.error_username"));
/*     */       } catch (NumberFormatException ignored) {
/*     */       }
/*     */     }
/* 472 */     if ((this.password == null) && (getFieldErrors().get("password") == null)) {
/* 473 */       List args = new ArrayList(1);
/* 474 */       args.add(new Integer(this.defaultMinPasswordLength));
/* 475 */       addFieldError("password", getText("account.error_password", args));
/*     */     }
/* 478 */     else if (this.password.length() < this.defaultMinPasswordLength) {
/* 479 */       List args = new ArrayList(1);
/* 480 */       args.add(new Integer(this.defaultMinPasswordLength));
/* 481 */       addFieldError("password", getText("account.error_password", args));
/*     */     }
/*     */ 
/* 484 */     if (this.passwordConfirm == null) {
/* 485 */       addFieldError("passwordConfirm", getText("account.error_confirm_password"));
/*     */     }
/* 488 */     else if (this.passwordConfirm.length() < this.defaultMinPasswordLength) {
/* 489 */       List args = new ArrayList(1);
/* 490 */       args.add(new Integer(this.defaultMinPasswordLength));
/* 491 */       addFieldError("passwordConfirm", getText("account.error_password", args));
/*     */     }
/*     */ 
/* 494 */     if ((this.password != null) && (this.passwordConfirm != null) && (!this.password.equals(this.passwordConfirm)))
/* 495 */       addFieldError("passwordMatch", getText("account.passwords"));
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/* 506 */     if (!isAccountCreationEnabled()) {
/* 507 */       return "disabled";
/*     */     }
/* 509 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 520 */     if (!isAccountCreationEnabled()) {
/* 521 */       return "disabled";
/*     */     }
/*     */ 
/* 524 */     if ("true".equals(getDoCancel())) {
/* 525 */       return "cancel";
/*     */     }
/*     */ 
/* 528 */     if (hasErrors()) {
/* 529 */       addActionError(getText("account.errors"));
/* 530 */       return "error";
/*     */     }
/*     */     try
/*     */     {
/* 534 */       UserManager userManager = getForumFactory().getUserManager();
/* 535 */       this.newUser = userManager.createUser(this.username, this.password, this.email);
/*     */ 
/* 537 */       if (this.name != null) {
/* 538 */         this.newUser.setName(this.name);
/*     */       }
/*     */ 
/* 541 */       if (this.nameVisible == Boolean.TRUE) {
/* 542 */         this.newUser.setNameVisible(true);
/*     */       }
/*     */       else {
/* 545 */         this.newUser.setNameVisible(false);
/*     */       }
/* 547 */       if (this.emailVisible == Boolean.TRUE) {
/* 548 */         this.newUser.setEmailVisible(true);
/*     */       }
/*     */       else {
/* 551 */         this.newUser.setEmailVisible(false);
/*     */       }
/*     */ 
/* 554 */       if ((this.location != null) && (!"".equals(this.location))) {
/* 555 */         this.newUser.setProperty("jiveLocation", this.location);
/*     */       }
/* 557 */       if ((this.occupation != null) && (!"".equals(this.occupation))) {
/* 558 */         this.newUser.setProperty("jiveOccupation", this.occupation);
/*     */       }
/* 560 */       if ((this.homepage != null) && (!"".equals(this.homepage))) {
/* 561 */         this.newUser.setProperty("jiveHomepage", this.homepage);
/*     */       }
/* 563 */       if ((this.biography != null) && (!"".equals(this.biography))) {
/* 564 */         this.newUser.setProperty("jiveBiography", this.biography);
/*     */       }
/* 566 */       if ((this.signature != null) && (!"".equals(this.signature))) {
/* 567 */         this.newUser.setProperty("jiveSignature", this.signature);
/*     */       }
/*     */ 
/* 570 */       if (Boolean.FALSE == this.signatureVisible) {
/* 571 */         this.newUser.setProperty("jiveSignatureVisible", "true");
/*     */       }
/*     */ 
/* 575 */       boolean auto = this.autoLogin == Boolean.TRUE;
/* 576 */       AuthToken token = AuthFactory.loginUser(this.username, this.password, auto, ServletActionContext.getRequest(), ServletActionContext.getResponse());
/*     */ 
/* 579 */       setAuthToken(token);
/* 580 */       setForumFactory(ForumFactory.getInstance(token));
/*     */     }
/*     */     catch (UserAlreadyExistsException uaee) {
/* 583 */       addFieldError("username", getText("account.username_taken"));
/* 584 */       return "error";
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 587 */       addActionError(getText("account.error_not_auth"));
/* 588 */       return "error";
/*     */     }
/*     */ 
/* 591 */     if (hasErrors()) {
/* 592 */       return "error";
/*     */     }
/*     */ 
/* 595 */     return "success";
/*     */   }
/*     */ 
/*     */   private boolean isAccountCreationEnabled()
/*     */   {
/* 600 */     boolean enabled = true;
/*     */ 
/* 602 */     if ("false".equals(JiveGlobals.getJiveProperty("skin.default.newAccountCreationEnabled"))) {
/* 603 */       addActionError(getText("account.new_accounts_disabled"));
/* 604 */       enabled = false;
/*     */     }
/* 606 */     return enabled;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AccountAction
 * JD-Core Version:    0.6.2
 */
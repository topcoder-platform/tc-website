/*    */ package com.jivesoftware.forum.event;
/*    */ 
/*    */ import com.jivesoftware.base.JiveGlobals;
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.util.ClassUtils;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class QuestionEventDispatcher
/*    */ {
/* 29 */   private static QuestionEventDispatcher instance = new QuestionEventDispatcher();
/*    */ 
/* 35 */   private ArrayList listeners = new ArrayList();
/*    */ 
/*    */   public static QuestionEventDispatcher getInstance()
/*    */   {
/* 32 */     return instance;
/*    */   }
/*    */ 
/*    */   private QuestionEventDispatcher()
/*    */   {
/* 39 */     List listenerList = JiveGlobals.getJiveProperties("eventListeners.QuestionListener");
/* 40 */     for (int i = 0; i < listenerList.size(); i++) {
/* 41 */       String listenerStr = (String)listenerList.get(i);
/*    */       try {
/* 43 */         QuestionListener listener = (QuestionListener)ClassUtils.forName(listenerStr).newInstance();
/* 44 */         this.listeners.add(listener);
/*    */       }
/*    */       catch (Exception e) {
/* 47 */         Log.error("Error loading QuestionListener", e);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public synchronized void addListener(QuestionListener listener) {
/* 53 */     if (listener == null) {
/* 54 */       throw new NullPointerException();
/*    */     }
/*    */ 
/* 57 */     this.listeners.add(listener);
/*    */   }
/*    */ 
/*    */   public synchronized void removeListener(QuestionListener listener) {
/* 61 */     this.listeners.remove(listener);
/*    */   }
/*    */ 
/*    */   public void dispatchEvent(QuestionEvent event) {
/* 65 */     int eventType = event.getEventType();
/*    */ 
/* 67 */     for (int i = 0; i < this.listeners.size(); i++)
/*    */       try {
/* 69 */         QuestionListener listener = (QuestionListener)this.listeners.get(i);
/*    */ 
/* 71 */         switch (eventType) {
/*    */         case 160:
/* 73 */           listener.questionAdded(event);
/* 74 */           break;
/*    */         case 161:
/* 77 */           listener.questionDeleted(event);
/* 78 */           break;
/*    */         case 162:
/* 81 */           listener.questionStateModified(event);
/* 82 */           break;
/*    */         case 163:
/* 85 */           listener.correctAnswerAdded(event);
/* 86 */           break;
/*    */         case 164:
/* 89 */           listener.helpfulAnswerAdded(event);
/* 90 */           break;
/*    */         case 165:
/* 93 */           listener.propertyModified(event);
/*    */         }
/*    */ 
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 100 */         Log.error(e);
/*    */       }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.QuestionEventDispatcher
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum;

import com.jivesoftware.base.UnauthorizedException;
import java.util.Iterator;

public abstract interface AttachmentManager
{
  public abstract boolean isDatabaseModeEnabled();

  public abstract void setDatabaseModeEnabled(boolean paramBoolean)
    throws UnauthorizedException;

  public abstract long getAttachmentDirectorySize()
    throws UnauthorizedException;

  public abstract long getMaxFilesystemCacheSize()
    throws UnauthorizedException;

  public abstract void setMaxFilesystemCacheSize(long paramLong)
    throws UnauthorizedException;

  public abstract int getMaxAttachmentSize();

  public abstract void setMaxAttachmentSize(int paramInt)
    throws UnauthorizedException;

  public abstract int getMaxAttachmentsPerMessage();

  public abstract void setMaxAttachmentsPerMessage(int paramInt)
    throws UnauthorizedException;

  public abstract boolean isValidType(String paramString);

  public abstract void addAllowedType(String paramString)
    throws UnauthorizedException;

  public abstract void removeAllowedType(String paramString)
    throws UnauthorizedException;

  public abstract Iterator allowedTypes();

  public abstract void addDisallowedType(String paramString)
    throws UnauthorizedException;

  public abstract void removeDisallowedType(String paramString)
    throws UnauthorizedException;

  public abstract Iterator disallowedTypes();

  public abstract boolean getAllowAllByDefault();

  public abstract void setAllowAllByDefault(boolean paramBoolean)
    throws UnauthorizedException;

  public abstract boolean isImagePreviewEnabled();

  public abstract void setImagePreviewEnabled(boolean paramBoolean)
    throws UnauthorizedException;

  public abstract int getImagePreviewMaxSize();

  public abstract void setImagePreviewMaxSize(int paramInt)
    throws UnauthorizedException;

  public abstract boolean isImagePreviewRatioEnabled();

  public abstract void setImagePreviewRatioEnabled(boolean paramBoolean)
    throws UnauthorizedException;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.AttachmentManager
 * JD-Core Version:    0.6.2
 */
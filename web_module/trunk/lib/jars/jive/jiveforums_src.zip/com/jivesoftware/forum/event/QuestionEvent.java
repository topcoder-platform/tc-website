/*     */ package com.jivesoftware.forum.event;
/*     */ 
/*     */ import com.jivesoftware.base.JiveEvent;
/*     */ import com.jivesoftware.forum.Question;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class QuestionEvent
/*     */   implements JiveEvent
/*     */ {
/*     */   public static final int QUESTION_ADDED = 160;
/*     */   public static final int QUESTION_DELETED = 161;
/*     */   public static final int QUESTION_STATE_MODIFIED = 162;
/*     */   public static final int CORRECT_ANSWER_SET = 163;
/*     */   public static final int HELPFUL_ANSWER_ADDED = 164;
/*     */   public static final int PROPERTY_MODIFIED = 165;
/*     */   private int eventType;
/*     */   private Question question;
/*     */   private Date date;
/*     */   private Map params;
/*     */ 
/*     */   public QuestionEvent(int eventType, Question question, Map params)
/*     */   {
/*  86 */     this.eventType = eventType;
/*  87 */     this.question = question;
/*  88 */     this.params = (params == null ? null : Collections.unmodifiableMap(params));
/*  89 */     this.date = new Date();
/*     */   }
/*     */ 
/*     */   public int getEventType() {
/*  93 */     return this.eventType;
/*     */   }
/*     */ 
/*     */   public Question getQuestion()
/*     */   {
/* 102 */     return this.question;
/*     */   }
/*     */ 
/*     */   public Map getParams() {
/* 106 */     return this.params;
/*     */   }
/*     */ 
/*     */   public Date getDate() {
/* 110 */     return this.date;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.QuestionEvent
 * JD-Core Version:    0.6.2
 */
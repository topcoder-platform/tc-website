/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ public class AvatarException extends Exception
/*    */ {
/*    */   public static final int DEFAULT = 0;
/*    */   public static final int FILE_NOT_ACCEPTED = 1;
/* 23 */   int type = 0;
/*    */ 
/*    */   public AvatarException() {
/*    */   }
/*    */ 
/*    */   public AvatarException(String s) {
/* 29 */     super(s);
/*    */   }
/*    */ 
/*    */   public AvatarException(String s, Throwable throwable) {
/* 33 */     super(s, throwable);
/*    */   }
/*    */ 
/*    */   public AvatarException(Throwable throwable) {
/* 37 */     super(throwable);
/*    */   }
/*    */ 
/*    */   public AvatarException(AttachmentException ae) {
/* 41 */     super(ae);
/* 42 */     this.type = 1;
/*    */   }
/*    */ 
/*    */   public int getType() {
/* 46 */     return this.type;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.AvatarException
 * JD-Core Version:    0.6.2
 */
/*      */ package com.jivesoftware.forum.database;
/*      */ 
/*      */ import com.jivesoftware.base.AuthToken;
/*      */ import com.jivesoftware.base.FilterManager;
/*      */ import com.jivesoftware.base.JiveGlobals;
/*      */ import com.jivesoftware.base.Log;
/*      */ import com.jivesoftware.base.PermissionType;
/*      */ import com.jivesoftware.base.Permissions;
/*      */ import com.jivesoftware.base.PermissionsManager;
/*      */ import com.jivesoftware.base.User;
/*      */ import com.jivesoftware.base.database.CachedPreparedStatement;
/*      */ import com.jivesoftware.base.database.ConnectionManager;
/*      */ import com.jivesoftware.base.database.ConnectionManager.DatabaseType;
/*      */ import com.jivesoftware.base.database.DbPermissionsManager;
/*      */ import com.jivesoftware.base.database.sequence.SequenceManager;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumCategory;
/*      */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumMessageIterator;
/*      */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*      */ import com.jivesoftware.forum.ForumNotFoundException;
/*      */ import com.jivesoftware.forum.ForumThread;
/*      */ import com.jivesoftware.forum.ForumThreadIterator;
/*      */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*      */ import com.jivesoftware.forum.InterceptorManager;
/*      */ import com.jivesoftware.forum.MessageRejectedException;
/*      */ import com.jivesoftware.forum.NameAlreadyExistsException;
/*      */ import com.jivesoftware.forum.Query;
/*      */ import com.jivesoftware.forum.QueryManager;
/*      */ import com.jivesoftware.forum.ResultFilter;
/*      */ import com.jivesoftware.forum.event.MessageEvent;
/*      */ import com.jivesoftware.forum.event.MessageEventDispatcher;
/*      */ import com.jivesoftware.forum.event.ThreadEvent;
/*      */ import com.jivesoftware.forum.event.ThreadEventDispatcher;
/*      */ import com.jivesoftware.forum.gateway.GatewayManager;
/*      */ import com.jivesoftware.forum.proxy.ForumMessageProxy;
/*      */ import com.jivesoftware.forum.proxy.ForumThreadProxy;
/*      */ import com.jivesoftware.util.Cache;
/*      */ import com.jivesoftware.util.CacheSizes;
/*      */ import com.jivesoftware.util.Cacheable;
/*      */ import com.jivesoftware.util.ExtendedPropertyUtils;
/*      */ import com.jivesoftware.util.ExternalizableLiteUtil;
/*      */ import com.jivesoftware.util.LongHashMap;
/*      */ import com.jivesoftware.util.LongList;
/*      */ import com.jivesoftware.util.profile.Profiler;
/*      */ import com.tangosol.io.ExternalizableLite;
/*      */ import com.tangosol.util.ExternalizableHelper;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ public class DbForum
/*      */   implements Forum, Cacheable, ExternalizableLite
/*      */ {
/*   42 */   public static final boolean ENABLE_DATE_UPDATES = JiveGlobals.getJiveBooleanProperty("forum.enableDateUpdates", true);
/*      */   private static final String ALL_THREADS = "SELECT threadID FROM jiveThread WHERE forumID=?";
/*      */   private static final String MOVE_THREAD = "UPDATE jiveThread SET forumID=? WHERE threadID=?";
/*      */   private static final String MOVE_MESSAGES = "UPDATE jiveMessage SET forumID=?, forumIndex=0 WHERE threadID=?";
/*      */   private static final String ALL_MESSAGE_ATTACHMENTS = "SELECT attachmentID FROM jiveAttachment, jiveMessage WHERE objectType=2 AND jiveAttachment.objectID=jiveMessage.messageID AND threadID=?";
/*      */   private static final String ALL_THREAD_MESSAGES = "SELECT messageID, forumIndex FROM jiveMessage WHERE threadID=?";
/*      */   private static final String DELETE_MESSAGES = "DELETE FROM jiveMessage WHERE threadID=?";
/*      */   private static final String DELETE_MESSAGE_PROPERTIES = "DELETE FROM jiveMessageProp WHERE messageID IN(SELECT messageID FROM jiveMessage WHERE threadID=?)";
/*      */   private static final String SELECT_MESSAGE_PROPERTIES = "SELECT jiveMessageProp.messageID FROM jiveMessageProp, jiveMessage WHERE jiveMessageProp.messageID=jiveMessage.messageID AND jiveMessage.threadID=?";
/*      */   private static final String DELETE_MESSAGE_PROPERTIES_BATCH = "DELETE FROM jiveMessageProp WHERE messageID IN";
/*      */   private static final String DELETE_THREAD = "DELETE FROM jiveThread WHERE threadID=?";
/*      */   private static final String DELETE_THREAD_PROPERTIES = "DELETE FROM jiveThreadProp WHERE threadID=?";
/*      */   private static final String LOAD_PROPERTIES = "SELECT name, propValue FROM jiveForumProp WHERE forumID=?";
/*      */   private static final String DELETE_PROPERTY = "DELETE FROM jiveForumProp WHERE forumID=? AND name=?";
/*      */   private static final String UPDATE_PROPERTY = "UPDATE jiveForumProp SET propValue=? WHERE name=? AND forumID=?";
/*      */   private static final String INSERT_PROPERTY = "INSERT INTO jiveForumProp(forumID,name,propValue) VALUES(?,?,?)";
/*      */   private static final String LOAD_FORUM_BY_ID = "SELECT forumID, name, nntpName, description, modDefaultThreadVal, modDefaultMsgVal, creationDate, modificationDate, categoryID FROM jiveForum WHERE forumID=?";
/*      */   private static final String LOAD_FORUM_BY_NNTP_NAME = "SELECT forumID, name, nntpName, description, modDefaultThreadVal, modDefaultMsgVal, creationDate, modificationDate, categoryID FROM jiveForum WHERE nntpName=?";
/*      */   private static final String ADD_FORUM = "INSERT INTO jiveForum(forumID, categoryID, categoryIndex, name, nntpName, description, modDefaultThreadVal, modDefaultMsgVal, creationDate, modificationDate, forumIndexCounter) VALUES (?,?,?,?,?,?,?,?,?,?,0)";
/*      */   private static final String SAVE_FORUM = "UPDATE jiveForum SET name=?, nntpName=?, description=?, modDefaultThreadVal=?, modDefaultMsgVal=?, creationDate=?, modificationDate=? WHERE forumID=?";
/*      */   private static final String UPDATE_FORUM_MODIFIED_DATE = "UPDATE jiveForum SET modificationDate=? WHERE forumID=?";
/*      */   private static final String POPULAR_THREADS = "SELECT threadID, count(*) AS msgCount FROM jiveMessage WHERE modificationDate > ? AND forumID=? AND modValue >= 1 GROUP BY threadID ORDER BY msgCount DESC";
/*      */   private static final String POPULAR_THREADS_ORACLE = "SELECT /*+ INDEX (jiveMessage jiveMessage_mDate_idx) */ threadID, count(*) AS msgCount FROM jiveMessage, jiveForum WHERE jiveMessage.modificationDate > ? AND jiveMessage.forumID=? AND jiveMessage.forumID=jiveForum.forumID AND jiveMessage.modValue >= 1 GROUP BY threadID ORDER BY msgCount DESC";
/*      */   private static final String MIN_FORUM_INDEX = "SELECT min(forumIndex) FROM jiveMessage WHERE forumID=? AND forumIndex > 0";
/*      */   private static final String MAX_FORUM_INDEX = "SELECT forumIndexCounter FROM jiveForum WHERE forumID=?";
/*      */   private static final boolean LAZY_PROP_LOADING = true;
/*  130 */   private static final ResultFilter DEFAULT_THREAD_FILTER = ResultFilter.createDefaultThreadFilter();
/*      */ 
/*  132 */   private static final ResultFilter DEFAULT_MESSAGE_FILTER = ResultFilter.createDefaultMessageFilter();
/*      */   private static final long serialVersionUID = 1L;
/*  137 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*      */ 
/*  139 */   private long id = -1L;
/*      */   private long categoryID;
/*      */   private String name;
/*      */   private String nntpName;
/*      */   private String description;
/*      */   private Date creationDate;
/*      */   private Date modificationDate;
/*  146 */   private int modDefaultThreadValue = 1;
/*  147 */   private int modDefaultMessageValue = 1;
/*      */   private Map properties;
/*  150 */   private long[] popularThreads = null;
/*      */ 
/*  152 */   private transient int minForumIndex = -1;
/*  153 */   private transient int maxForumIndex = -1;
/*      */   private transient DbFilterManager filterManager;
/*      */   private transient DbInterceptorManager interceptorManager;
/*      */ 
/*      */   protected DbForum(String name, String description, ForumCategory category)
/*      */   {
/*  166 */     this.id = SequenceManager.nextID(0);
/*  167 */     this.categoryID = category.getID();
/*  168 */     this.name = name;
/*  169 */     this.nntpName = convertToNNTP(name, category);
/*      */ 
/*  174 */     int counter = 0;
/*  175 */     String tempName = null;
/*      */     while (true) {
/*  177 */       tempName = this.nntpName;
/*  178 */       if (counter > 0)
/*  179 */         tempName = tempName + "_" + counter;
/*      */       try
/*      */       {
/*  182 */         FACTORY.cacheManager.getForum(tempName);
/*  183 */         counter++;
/*      */       }
/*      */       catch (ForumNotFoundException fnfe)
/*      */       {
/*  187 */         this.nntpName = tempName;
/*      */ 
/*  191 */         this.description = description;
/*  192 */         long now = System.currentTimeMillis();
/*  193 */         this.creationDate = new Date(now);
/*  194 */         this.modificationDate = new Date(now);
/*  195 */         insertIntoDb(category.getForumCount());
/*  196 */         this.properties = new Hashtable();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected DbForum(long id)
/*      */     throws ForumNotFoundException
/*      */   {
/*  206 */     if (id < 0L) {
/*  207 */       throw new ForumNotFoundException("ID " + id + " is not valid.", id);
/*      */     }
/*  209 */     this.id = id;
/*  210 */     loadFromDb();
/*      */   }
/*      */ 
/*      */   protected DbForum(String nntpName)
/*      */     throws ForumNotFoundException
/*      */   {
/*  220 */     if (nntpName == null) {
/*  221 */       throw new ForumNotFoundException("NNTP name cannot be null.");
/*      */     }
/*  223 */     this.nntpName = nntpName;
/*  224 */     loadFromDb();
/*      */   }
/*      */ 
/*      */   public DbForum()
/*      */   {
/*      */   }
/*      */ 
/*      */   public long getID()
/*      */   {
/*  236 */     return this.id;
/*      */   }
/*      */ 
/*      */   public String getName() {
/*  240 */     return this.name;
/*      */   }
/*      */ 
/*      */   public void setName(String name)
/*      */   {
/*  245 */     if (this.name.equals(name)) {
/*  246 */       return;
/*      */     }
/*  248 */     this.name = name;
/*  249 */     saveToDb();
/*      */   }
/*      */ 
/*      */   public String getNNTPName() {
/*  253 */     return this.nntpName;
/*      */   }
/*      */ 
/*      */   public void setNNTPName(String nntpName) throws NameAlreadyExistsException
/*      */   {
/*  258 */     nntpName = nntpName.toLowerCase();
/*      */ 
/*  261 */     nntpName = nntpName.replaceAll("[[*!,\\s][^\\p{ASCII}]]", "_");
/*      */ 
/*  263 */     if (this.nntpName.equals(nntpName)) {
/*  264 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  268 */       FACTORY.cacheManager.getForum(nntpName);
/*      */ 
/*  270 */       throw new NameAlreadyExistsException("The specified NNTP name, " + nntpName + ", is already in use by another forum.");
/*      */     }
/*      */     catch (ForumNotFoundException fnfe)
/*      */     {
/*  275 */       FACTORY.cacheManager.forumNNTPNameCache.remove(this.nntpName);
/*      */ 
/*  277 */       this.nntpName = nntpName;
/*  278 */       saveToDb();
/*      */     }
/*      */   }
/*      */ 
/*  282 */   public String getDescription() { return this.description; }
/*      */ 
/*      */   public void setDescription(String description)
/*      */   {
/*  286 */     this.description = description;
/*  287 */     saveToDb();
/*      */   }
/*      */ 
/*      */   public Date getCreationDate() {
/*  291 */     return new Date(this.creationDate.getTime());
/*      */   }
/*      */ 
/*      */   public void setCreationDate(Date creationDate) {
/*  295 */     this.creationDate = new Date(creationDate.getTime());
/*  296 */     saveToDb();
/*      */   }
/*      */ 
/*      */   public Date getModificationDate() {
/*  300 */     return new Date(this.modificationDate.getTime());
/*      */   }
/*      */ 
/*      */   public void setModificationDate(Date modificationDate) {
/*  304 */     this.modificationDate = new Date(modificationDate.getTime());
/*  305 */     saveToDb();
/*      */   }
/*      */ 
/*      */   public int getModerationDefaultThreadValue() {
/*  309 */     return this.modDefaultThreadValue;
/*      */   }
/*      */ 
/*      */   public void setModerationDefaultThreadValue(int value) {
/*  313 */     this.modDefaultThreadValue = value;
/*  314 */     saveToDb();
/*      */   }
/*      */ 
/*      */   public int getModerationDefaultMessageValue() {
/*  318 */     return this.modDefaultMessageValue;
/*      */   }
/*      */ 
/*      */   public void setModerationDefaultMessageValue(int value) {
/*  322 */     this.modDefaultMessageValue = value;
/*  323 */     saveToDb();
/*      */   }
/*      */ 
/*      */   public int getMinForumIndex() {
/*  327 */     if (this.minForumIndex == -1) {
/*  328 */       Connection con = null;
/*  329 */       PreparedStatement pstmt = null;
/*      */       try {
/*  331 */         con = ConnectionManager.getConnection();
/*  332 */         pstmt = con.prepareStatement("SELECT min(forumIndex) FROM jiveMessage WHERE forumID=? AND forumIndex > 0");
/*  333 */         pstmt.setLong(1, this.id);
/*  334 */         ResultSet rs = pstmt.executeQuery();
/*  335 */         if (rs.next()) {
/*  336 */           this.minForumIndex = rs.getInt(1);
/*      */         }
/*  338 */         rs.close();
/*      */       }
/*      */       catch (SQLException sqle) {
/*  341 */         Log.error(sqle);
/*      */       }
/*      */       finally {
/*  344 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*      */     }
/*  347 */     return this.minForumIndex;
/*      */   }
/*      */ 
/*      */   public int getMaxForumIndex() {
/*  351 */     if (SequenceManager.isNamedSequencesSupportd()) {
/*  352 */       return (int)SequenceManager.currID("forumIdx" + getID());
/*      */     }
/*      */ 
/*  355 */     if (this.maxForumIndex == -1) {
/*  356 */       Connection con = null;
/*  357 */       PreparedStatement pstmt = null;
/*      */       try {
/*  359 */         con = ConnectionManager.getConnection();
/*  360 */         pstmt = con.prepareStatement("SELECT forumIndexCounter FROM jiveForum WHERE forumID=?");
/*  361 */         pstmt.setLong(1, this.id);
/*  362 */         ResultSet rs = pstmt.executeQuery();
/*  363 */         if (rs.next()) {
/*  364 */           this.maxForumIndex = rs.getInt(1);
/*      */         }
/*  366 */         rs.close();
/*      */       }
/*      */       catch (SQLException sqle) {
/*  369 */         Log.error(sqle);
/*      */       }
/*      */       finally {
/*  372 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*      */     }
/*  375 */     return this.maxForumIndex;
/*      */   }
/*      */ 
/*      */   public String getProperty(String name) {
/*  379 */     if (this.properties == null) {
/*  380 */       loadPropertiesFromDb();
/*      */     }
/*  382 */     return (String)this.properties.get(name);
/*      */   }
/*      */ 
/*      */   public Collection getProperties(String parentName) {
/*  386 */     Object[] keys = this.properties.keySet().toArray();
/*  387 */     ArrayList results = new ArrayList();
/*  388 */     int i = 0; for (int n = keys.length; i < n; i++) {
/*  389 */       String key = (String)keys[i];
/*  390 */       if ((key.startsWith(parentName)) && 
/*  391 */         (!key.equals(parentName)))
/*      */       {
/*  394 */         if (key.substring(parentName.length()).lastIndexOf(".") == 0) {
/*  395 */           results.add(this.properties.get(key));
/*      */         }
/*      */       }
/*      */     }
/*  399 */     return Collections.unmodifiableCollection(results);
/*      */   }
/*      */ 
/*      */   public void setProperty(String name, String value) {
/*  403 */     if (this.properties == null) {
/*  404 */       loadPropertiesFromDb();
/*      */     }
/*      */ 
/*  407 */     value = ExtendedPropertyUtils.validateExtendedProperty(name, value);
/*      */ 
/*  409 */     if (this.properties.containsKey(name))
/*      */     {
/*  412 */       if (!value.equals(this.properties.get(name))) {
/*  413 */         this.properties.put(name, value);
/*  414 */         updatePropertyInDb(name, value);
/*      */ 
/*  416 */         clearCache();
/*  417 */         FACTORY.cacheManager.forumCache.put(new Long(this.id), this);
/*      */       }
/*      */     }
/*      */     else {
/*  421 */       this.properties.put(name, value);
/*  422 */       insertPropertyIntoDb(name, value);
/*      */ 
/*  424 */       clearCache();
/*  425 */       FACTORY.cacheManager.forumCache.put(new Long(this.id), this);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void deleteProperty(String name) {
/*  430 */     if (this.properties == null) {
/*  431 */       loadPropertiesFromDb();
/*      */     }
/*      */ 
/*  434 */     if (this.properties.containsKey(name)) {
/*  435 */       this.properties.remove(name);
/*  436 */       deletePropertyFromDb(name);
/*      */ 
/*  438 */       clearCache();
/*  439 */       FACTORY.cacheManager.forumCache.put(new Long(this.id), this);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Iterator getPropertyNames() {
/*  444 */     if (this.properties == null) {
/*  445 */       loadPropertiesFromDb();
/*      */     }
/*  447 */     return Collections.unmodifiableSet(this.properties.keySet()).iterator();
/*      */   }
/*      */ 
/*      */   public ForumCategory getForumCategory() {
/*      */     try {
/*  452 */       return FACTORY.cacheManager.getForumCategory(this.categoryID);
/*      */     }
/*      */     catch (ForumCategoryNotFoundException e) {
/*  455 */       Log.error(e);
/*  456 */     }return null;
/*      */   }
/*      */ 
/*      */   public ForumThread createThread(ForumMessage rootMessage)
/*      */   {
/*  464 */     if ((rootMessage.getForumThread() != null) && 
/*  465 */       (rootMessage.equals(rootMessage.getForumThread().getRootMessage()))) {
/*  466 */       throw new IllegalArgumentException("Cannot create a new thread with an existing root message.");
/*      */     }
/*      */ 
/*  470 */     return new DbForumThread(this, rootMessage);
/*      */   }
/*      */ 
/*      */   public ForumMessage createMessage() {
/*  474 */     return new DbForumMessage(null, this);
/*      */   }
/*      */ 
/*      */   public ForumMessage createMessage(User user) {
/*  478 */     return new DbForumMessage(user, this);
/*      */   }
/*      */ 
/*      */   public void addThread(ForumThread thread) throws MessageRejectedException {
/*  482 */     Profiler.begin("addThread");
/*  483 */     DbForumThread dbThread = null;
/*  484 */     long oldThreadID = -1L;
/*  485 */     long oldForumID = -1L;
/*      */ 
/*  487 */     if ((thread instanceof ForumThreadProxy)) {
/*      */       try {
/*  489 */         ForumThreadProxy proxyThread = (ForumThreadProxy)thread;
/*  490 */         dbThread = (DbForumThread)proxyThread.getProxiedForumThread();
/*      */       }
/*      */       catch (Exception e) {
/*  493 */         Log.error(e);
/*  494 */         return;
/*      */       }
/*      */     }
/*      */     else {
/*  498 */       dbThread = (DbForumThread)thread;
/*      */     }
/*  500 */     ForumMessage dbMessage = dbThread.getRootMessage();
/*      */ 
/*  503 */     boolean newMessage = dbMessage.getForumThread() == null;
/*  504 */     if (newMessage) {
/*  505 */       if ((dbMessage instanceof ForumMessageProxy))
/*      */         try {
/*  507 */           ForumMessageProxy proxyMessage = (ForumMessageProxy)dbMessage;
/*  508 */           dbMessage = proxyMessage.getProxiedForumMessage();
/*      */         }
/*      */         catch (Exception e) {
/*  511 */           Log.error(e);
/*      */         }
/*      */     }
/*      */     else {
/*      */       try
/*      */       {
/*  517 */         dbMessage = FACTORY.getMessage(dbMessage.getID());
/*  518 */         oldThreadID = dbMessage.getForumThread().getID();
/*  519 */         oldForumID = dbMessage.getForum().getID();
/*      */       }
/*      */       catch (ForumMessageNotFoundException e) {
/*  522 */         Log.error(e);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  527 */     DbInterceptorManager manager = (DbInterceptorManager)getInterceptorManager();
/*  528 */     manager.invokeInterceptors(dbMessage, 0);
/*      */ 
/*  531 */     if (newMessage) {
/*  532 */       if (dbThread.moderationValue == -2147483648)
/*      */       {
/*  534 */         if (((DbForumMessage)dbMessage).moderationValue == -2147483648) {
/*  535 */           dbThread.moderationValue = getModerationDefaultThreadValue();
/*      */ 
/*  538 */           ((DbForumMessage)dbMessage).moderationValue = dbThread.moderationValue;
/*      */         }
/*      */         else
/*      */         {
/*  542 */           dbThread.moderationValue = ((DbForumMessage)dbMessage).moderationValue;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*  550 */     else if (dbThread.moderationValue == -2147483648) {
/*  551 */       dbThread.moderationValue = ((DbForumMessage)dbMessage).moderationValue;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  557 */       dbThread.prepareInsertIntoDb(this);
/*  558 */       ((DbForumMessage)dbMessage).prepareInsertIntoDb(dbThread);
/*      */     }
/*      */     catch (Exception e) {
/*  561 */       Log.error(e);
/*      */     }
/*      */ 
/*  564 */     boolean abortTransaction = false;
/*  565 */     Connection con = null;
/*      */     try {
/*  567 */       con = ConnectionManager.getTransactionConnection();
/*      */ 
/*  569 */       dbThread.insertIntoDb(this, con);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  573 */       Log.error(e);
/*  574 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/*  577 */       ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*      */     }
/*      */ 
/*  588 */     if ((thread.getModerationValue() >= 1) && (!abortTransaction))
/*      */     {
/*      */       try
/*      */       {
/*  592 */         con = ConnectionManager.getConnection();
/*  593 */         updateModifiedDate(thread.getModificationDate().getTime(), con);
/*      */       }
/*      */       catch (Exception e) {
/*  596 */         Log.error(e);
/*      */       }
/*      */       finally {
/*  599 */         ConnectionManager.closeConnection(con);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  604 */     FACTORY.cacheManager.threadPut(dbThread.getID(), dbThread);
/*      */ 
/*  607 */     manager.invokeInterceptors(dbMessage, 1);
/*      */ 
/*  610 */     clearCache();
/*      */ 
/*  613 */     if (newMessage) {
/*  614 */       FACTORY.cacheManager.messagePut(dbMessage.getID(), dbMessage);
/*      */     }
/*      */     else
/*      */     {
/*  618 */       FACTORY.cacheManager.threadRemove(oldThreadID);
/*  619 */       FACTORY.cacheManager.queryRemove(1, oldThreadID);
/*      */ 
/*  622 */       FACTORY.cacheManager.queryRemove(0, oldForumID);
/*      */     }
/*      */ 
/*  627 */     if (newMessage) {
/*  628 */       ResultFilter defaultFilter = ResultFilter.createDefaultMessageFilter();
/*  629 */       QueryCacheKey countKey = new QueryCacheKey(1, dbThread.getID(), dbThread.getMessageListSQL(defaultFilter, true), -1);
/*      */ 
/*  631 */       FACTORY.cacheManager.queryPut(countKey, new Integer(1));
/*  632 */       QueryCacheKey listKey = new QueryCacheKey(1, dbThread.getID(), dbThread.getMessageListSQL(defaultFilter, false), 0);
/*      */ 
/*  634 */       FACTORY.cacheManager.queryPut(listKey, new long[] { dbMessage.getID() });
/*      */     }
/*      */ 
/*  638 */     ThreadEvent threadEvent = new ThreadEvent(110, dbThread, Collections.EMPTY_MAP);
/*      */ 
/*  640 */     ThreadEventDispatcher.getInstance().dispatchEvent(threadEvent);
/*      */ 
/*  642 */     if (newMessage) {
/*  643 */       MessageEvent messageEvent = new MessageEvent(100, dbMessage, Collections.EMPTY_MAP);
/*      */ 
/*  645 */       MessageEventDispatcher.getInstance().dispatchEvent(messageEvent);
/*      */     }
/*  647 */     Profiler.end("addThread");
/*      */   }
/*      */ 
/*      */   public ForumThread getThread(long threadID) throws ForumThreadNotFoundException {
/*  651 */     ForumThread thread = FACTORY.getForumThread(threadID);
/*  652 */     if (!thread.getForum().equals(this)) {
/*  653 */       throw new ForumThreadNotFoundException("Thread with ID " + threadID + " not in forum " + getName());
/*      */     }
/*      */ 
/*  656 */     return thread;
/*      */   }
/*      */ 
/*      */   public void deleteThread(ForumThread thread) {
/*      */     try {
/*  661 */       DbForumThread dbThread = (DbForumThread)getThread(thread.getID());
/*      */ 
/*  663 */       dbThread.setProperty("locked", "true");
/*      */     }
/*      */     catch (ForumThreadNotFoundException e)
/*      */     {
/*  668 */       Log.error("Thread " + thread.getID() + " could not be found.", e);
/*      */     }
/*      */ 
/*  672 */     ThreadEvent event = new ThreadEvent(111, thread, Collections.EMPTY_MAP);
/*      */ 
/*  674 */     ThreadEventDispatcher.getInstance().dispatchEvent(event);
/*      */ 
/*  677 */     LongList messages = new LongList();
/*  678 */     LongList forumIndexes = new LongList();
/*  679 */     Connection con = null;
/*  680 */     PreparedStatement pstmt = null;
/*      */     try {
/*  682 */       con = ConnectionManager.getConnection();
/*  683 */       pstmt = con.prepareStatement("SELECT messageID, forumIndex FROM jiveMessage WHERE threadID=?");
/*  684 */       pstmt.setLong(1, thread.getID());
/*  685 */       ResultSet rs = pstmt.executeQuery();
/*  686 */       while (rs.next()) {
/*  687 */         messages.add(rs.getLong(1));
/*  688 */         forumIndexes.add(rs.getInt(2));
/*      */       }
/*  690 */       rs.close();
/*      */     }
/*      */     catch (SQLException sqle) {
/*  693 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/*  696 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/*  699 */     boolean abortTransaction = false;
/*      */     try {
/*  701 */       con = ConnectionManager.getTransactionConnection();
/*      */ 
/*  704 */       LongList attachIDs = new LongList();
/*  705 */       pstmt = con.prepareStatement("SELECT attachmentID FROM jiveAttachment, jiveMessage WHERE objectType=2 AND jiveAttachment.objectID=jiveMessage.messageID AND threadID=?");
/*  706 */       pstmt.setLong(1, thread.getID());
/*  707 */       ResultSet rs = pstmt.executeQuery();
/*  708 */       while (rs.next()) {
/*  709 */         attachIDs.add(rs.getLong(1));
/*      */       }
/*  711 */       rs.close();
/*  712 */       pstmt.close();
/*  713 */       long[] attachments = attachIDs.toArray();
/*  714 */       for (int i = 0; i < attachments.length; i++) {
/*      */         try {
/*  716 */           DbAttachment attachment = FACTORY.cacheManager.getAttachment(attachments[i]);
/*  717 */           attachment.delete(con);
/*      */         }
/*      */         catch (Exception e) {
/*  720 */           Log.error(e);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  725 */       if (ConnectionManager.isSubqueriesSupported()) {
/*  726 */         ConnectionManager.disablePostgresTablescan(con);
/*      */         try {
/*  728 */           pstmt = con.prepareStatement("DELETE FROM jiveMessageProp WHERE messageID IN(SELECT messageID FROM jiveMessage WHERE threadID=?)");
/*  729 */           pstmt.setLong(1, thread.getID());
/*  730 */           pstmt.execute();
/*  731 */           pstmt.close();
/*      */         }
/*      */         finally {
/*  734 */           ConnectionManager.enablePostgresTablescan(con);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  739 */         LongList messageIDs = new LongList();
/*  740 */         pstmt = con.prepareStatement("SELECT jiveMessageProp.messageID FROM jiveMessageProp, jiveMessage WHERE jiveMessageProp.messageID=jiveMessage.messageID AND jiveMessage.threadID=?");
/*  741 */         pstmt.setLong(1, thread.getID());
/*  742 */         rs = pstmt.executeQuery();
/*  743 */         while (rs.next()) {
/*  744 */           messageIDs.add(rs.getLong(1));
/*      */         }
/*  746 */         rs.close();
/*  747 */         pstmt.close();
/*      */ 
/*  750 */         ConnectionManager.batchDeleteWithoutSubqueries(con, "DELETE FROM jiveMessageProp WHERE messageID IN", messageIDs.toArray());
/*      */       }
/*      */ 
/*  755 */       pstmt = con.prepareStatement("DELETE FROM jiveMessage WHERE threadID=?");
/*  756 */       pstmt.setLong(1, thread.getID());
/*  757 */       pstmt.execute();
/*  758 */       pstmt.close();
/*      */ 
/*  761 */       pstmt = con.prepareStatement("DELETE FROM jiveThreadProp WHERE threadID=?");
/*  762 */       pstmt.setLong(1, thread.getID());
/*  763 */       pstmt.execute();
/*  764 */       pstmt.close();
/*      */ 
/*  766 */       pstmt = con.prepareStatement("DELETE FROM jiveThread WHERE threadID=?");
/*  767 */       pstmt.setLong(1, thread.getID());
/*  768 */       pstmt.execute();
/*      */     } catch (Exception e) {
/*  772 */       Log.error(e);
/*  773 */       abortTransaction = true;
/*      */       return;
/*      */     }
/*      */     finally {
/*  777 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */ 
/*  781 */     FACTORY.cacheManager.threadRemove(thread.getID());
/*      */ 
/*  784 */     for (int i = 0; i < messages.size(); i++) {
/*  785 */       FACTORY.cacheManager.messageRemove(messages.get(i));
/*  786 */       String key = this.id + '-' + forumIndexes.get(i);
/*      */ 
/*  788 */       FACTORY.cacheManager.forumIndexRemove(key);
/*      */     }
/*  790 */     messages = null;
/*  791 */     forumIndexes = null;
/*      */ 
/*  794 */     clearCache();
/*      */   }
/*      */ 
/*      */   public void moveThread(ForumThread thread, Forum otherForum)
/*      */   {
/*  799 */     if (thread.getForum().getID() != this.id) {
/*  800 */       throw new IllegalArgumentException("The thread does not belong to this forum.");
/*      */     }
/*  802 */     if (this.id == otherForum.getID()) {
/*  803 */       throw new IllegalArgumentException("Thread already in forum " + this.name + ".");
/*      */     }
/*      */ 
/*  806 */     Log.debug("Moving thread ID " + thread.getID() + " to forum " + otherForum.getName());
/*      */ 
/*  808 */     DbForum forum = null;
/*      */     try {
/*  810 */       forum = FACTORY.cacheManager.getForum(otherForum.getID());
/*      */     }
/*      */     catch (ForumNotFoundException fnfe) {
/*  813 */       Log.error(fnfe);
/*      */     }
/*  815 */     Log.debug("Moving thread, got ForumFactory");
/*      */ 
/*  818 */     LongList messages = new LongList();
/*  819 */     LongList forumIndexes = new LongList();
/*  820 */     Connection con = null;
/*  821 */     PreparedStatement pstmt = null;
/*      */     try {
/*  823 */       con = ConnectionManager.getConnection();
/*  824 */       pstmt = con.prepareStatement("SELECT messageID, forumIndex FROM jiveMessage WHERE threadID=?");
/*  825 */       pstmt.setLong(1, thread.getID());
/*  826 */       Log.debug("Moving thread, about to execute ALL_THREAD_MESSAGES");
/*  827 */       ResultSet rs = pstmt.executeQuery();
/*  828 */       Log.debug("Moving thread, finished executing ALL_THREAD_MESSAGES");
/*  829 */       while (rs.next()) {
/*  830 */         messages.add(rs.getLong(1));
/*  831 */         forumIndexes.add(rs.getInt(2));
/*      */       }
/*  833 */       Log.debug("Moving thread, all messages added to list");
/*  834 */       rs.close();
/*      */     }
/*      */     catch (SQLException sqle) {
/*  837 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/*  840 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/*  844 */     boolean abortTransaction = false;
/*  845 */     con = null;
/*      */     try {
/*  847 */       con = ConnectionManager.getTransactionConnection();
/*  848 */       pstmt = null;
/*      */       try {
/*  850 */         Log.debug("Moving thread, about to MOVE_THREAD");
/*  851 */         pstmt = con.prepareStatement("UPDATE jiveThread SET forumID=? WHERE threadID=?");
/*  852 */         pstmt.setLong(1, forum.getID());
/*  853 */         pstmt.setLong(2, thread.getID());
/*  854 */         pstmt.executeUpdate();
/*  855 */         Log.debug("Moving thread, MOVE_THREAD complete");
/*  856 */         pstmt.close();
/*      */ 
/*  859 */         Log.debug("Moving thread, about to MOVE_MESSAGES");
/*  860 */         pstmt = con.prepareStatement("UPDATE jiveMessage SET forumID=?, forumIndex=0 WHERE threadID=?");
/*  861 */         pstmt.setLong(1, forum.getID());
/*  862 */         pstmt.setLong(2, thread.getID());
/*  863 */         pstmt.executeUpdate();
/*  864 */         Log.debug("Moving thread, MOVE_MESSAGES complete");
/*      */       }
/*      */       finally {
/*  867 */         ConnectionManager.closePreparedStatement(pstmt);
/*      */       }
/*      */     } catch (SQLException sqle) { Log.error(sqle);
/*  872 */       abortTransaction = true;
/*      */       return;
/*      */     }
/*      */     finally {
/*  876 */       ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*      */     }
/*      */ 
/*  879 */     DatabaseCacheManager cacheManager = FACTORY.cacheManager;
/*      */ 
/*  881 */     Log.debug("Move thread, about to clear caches");
/*      */ 
/*  883 */     clearCache();
/*  884 */     forum.clearCache();
/*  885 */     Log.debug("Move thread, caches cleared");
/*      */ 
/*  889 */     Log.debug("Move thread, updating modification date of thread");
/*  890 */     ResultFilter newestThreadFilter = ResultFilter.createDefaultThreadFilter();
/*  891 */     newestThreadFilter.setNumResults(1);
/*  892 */     Object threadIter = getThreads(newestThreadFilter);
/*  893 */     if (((Iterator)threadIter).hasNext()) {
/*  894 */       ForumThread newestThread = (ForumThread)((Iterator)threadIter).next();
/*  895 */       if (newestThread != null) {
/*  896 */         setModificationDate(newestThread.getModificationDate());
/*      */       }
/*      */     }
/*  899 */     Log.debug("Move thread, finished updating modification date of thread");
/*      */ 
/*  901 */     Log.debug("Move thread, updating modification date of forum");
/*  902 */     threadIter = forum.getThreads(newestThreadFilter);
/*  903 */     if (((Iterator)threadIter).hasNext()) {
/*  904 */       ForumThread newestThread = (ForumThread)((Iterator)threadIter).next();
/*  905 */       if (newestThread != null) {
/*  906 */         forum.setModificationDate(newestThread.getModificationDate());
/*      */       }
/*      */     }
/*  909 */     Log.debug("Move thread, finished updating modification date of forum");
/*      */ 
/*  912 */     Log.debug("Move thread, removing thread from cache");
/*      */     try {
/*  914 */       DbForumThread dbThread = cacheManager.getForumThread(thread.getID());
/*  915 */       dbThread.clearCache();
/*      */     }
/*      */     catch (ForumThreadNotFoundException e) {
/*  918 */       Log.error(e);
/*      */     }
/*  920 */     cacheManager.threadRemove(thread.getID());
/*  921 */     Log.debug("Move thread, finished removing thread from cache");
/*      */ 
/*  928 */     abortTransaction = false;
/*  929 */     Log.debug("Move thread, assigning new forum indexes to messages");
/*      */     try {
/*  931 */       con = ConnectionManager.getTransactionConnection();
/*  932 */       int nextForumIndex = DbForumMessage.getForumIndexValues(messages.size(), forum.getID()) - messages.size() + 1;
/*      */ 
/*  934 */       for (int i = 0; i < messages.size(); nextForumIndex++) {
/*  935 */         long messageID = messages.get(i);
/*  936 */         Log.debug("Move thread, setting new forum index for message ID: " + messageID);
/*      */         try
/*      */         {
/*  940 */           pstmt = con.prepareStatement("UPDATE jiveMessage SET forumIndex=? WHERE messageID=?");
/*  941 */           pstmt.setInt(1, nextForumIndex);
/*  942 */           pstmt.setLong(2, messageID);
/*  943 */           pstmt.executeUpdate();
/*      */         }
/*      */         finally {
/*  946 */           ConnectionManager.closePreparedStatement(pstmt);
/*      */         }
/*      */ 
/*  950 */         cacheManager.messageRemove(messageID);
/*      */ 
/*  952 */         String key = this.id + '-' + forumIndexes.get(i);
/*      */ 
/*  954 */         FACTORY.cacheManager.forumIndexRemove(key);
/*  955 */         Log.debug("Move thread, updated forum index for message ID: " + messageID);
/*      */ 
/*  934 */         i++;
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (SQLException sqle)
/*      */     {
/*  959 */       Log.error(sqle);
/*  960 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/*  963 */       ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*      */     }
/*  965 */     Log.debug("Move thread, done assigning new forum indexes");
/*      */     try
/*      */     {
/*  970 */       thread = FACTORY.cacheManager.getForumThread(thread.getID());
/*      */     } catch (ForumThreadNotFoundException e) {
/*      */     }
/*  973 */     Map params = new TreeMap();
/*  974 */     params.put("oldForumID", new Long(this.id));
/*  975 */     ThreadEvent event = new ThreadEvent(112, thread, params);
/*  976 */     ThreadEventDispatcher.getInstance().dispatchEvent(event);
/*  977 */     Log.debug("Move thread, done firing event");
/*      */   }
/*      */ 
/*      */   public ForumThreadIterator getThreads() {
/*  981 */     return getThreads(DEFAULT_THREAD_FILTER);
/*      */   }
/*      */ 
/*      */   public ForumThreadIterator getThreads(ResultFilter resultFilter) {
/*  985 */     CachedPreparedStatement query = getThreadListSQL(resultFilter, false);
/*  986 */     long[] threadBlock = QueryCache.getBlock(query, 0, this.id, resultFilter.getStartIndex(), true);
/*      */ 
/*  988 */     int startIndex = resultFilter.getStartIndex();
/*      */     int endIndex;
/*      */     int endIndex;
/*  992 */     if (resultFilter.getNumResults() == 2147483524) {
/*  993 */       endIndex = getThreadCount(resultFilter);
/*      */     }
/*      */     else {
/*  996 */       endIndex = resultFilter.getNumResults() + startIndex;
/*      */     }
/*  998 */     return new ForumThreadBlockIterator(threadBlock, query, startIndex, endIndex, 0, this.id, FACTORY);
/*      */   }
/*      */ 
/*      */   public Iterator getPopularThreads()
/*      */   {
/* 1003 */     if (this.popularThreads == null)
/*      */     {
/* 1006 */       int threadNumber = 4;
/*      */       try {
/* 1008 */         String number = JiveGlobals.getJiveProperty("popularThreads.number");
/* 1009 */         if (number != null) {
/* 1010 */           threadNumber = Integer.parseInt(number);
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */ 
/* 1017 */       int timeWindow = 24;
/*      */       try {
/* 1019 */         String window = JiveGlobals.getJiveProperty("popularThreads.timeWindow");
/* 1020 */         if (window != null)
/* 1021 */           timeWindow = Integer.parseInt(window);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/* 1026 */       LongList popThreads = new LongList(threadNumber);
/*      */ 
/* 1028 */       Calendar cal = Calendar.getInstance();
/* 1029 */       cal.add(11, -timeWindow);
/*      */ 
/* 1031 */       Connection con = null;
/* 1032 */       PreparedStatement pstmt = null;
/*      */       try {
/* 1034 */         con = ConnectionManager.getConnection();
/*      */ 
/* 1037 */         if (ConnectionManager.getDatabaseType() == ConnectionManager.DatabaseType.ORACLE)
/*      */         {
/* 1040 */           pstmt = con.prepareStatement("SELECT /*+ INDEX (jiveMessage jiveMessage_mDate_idx) */ threadID, count(*) AS msgCount FROM jiveMessage, jiveForum WHERE jiveMessage.modificationDate > ? AND jiveMessage.forumID=? AND jiveMessage.forumID=jiveForum.forumID AND jiveMessage.modValue >= 1 GROUP BY threadID ORDER BY msgCount DESC");
/*      */         }
/*      */         else {
/* 1043 */           pstmt = con.prepareStatement("SELECT threadID, count(*) AS msgCount FROM jiveMessage WHERE modificationDate > ? AND forumID=? AND modValue >= 1 GROUP BY threadID ORDER BY msgCount DESC");
/*      */         }
/* 1045 */         pstmt.setLong(1, cal.getTime().getTime());
/* 1046 */         pstmt.setLong(2, this.id);
/* 1047 */         ResultSet rs = pstmt.executeQuery();
/* 1048 */         for (int i = 0; (i < threadNumber) && 
/* 1049 */           (rs.next()); i++)
/*      */         {
/* 1052 */           popThreads.add(rs.getLong(1));
/*      */         }
/* 1054 */         rs.close();
/* 1055 */         this.popularThreads = popThreads.toArray();
/*      */       }
/*      */       catch (SQLException sqle) {
/* 1058 */         Log.error(sqle);
/*      */       }
/*      */       finally {
/* 1061 */         ConnectionManager.closeConnection(pstmt, con);
/*      */       }
/*      */     }
/* 1064 */     return new DatabaseObjectIterator(1, this.popularThreads, this);
/*      */   }
/*      */ 
/*      */   public ForumMessageIterator getMessages() {
/* 1068 */     return getMessages(DEFAULT_MESSAGE_FILTER);
/*      */   }
/*      */ 
/*      */   public ForumMessageIterator getMessages(ResultFilter resultFilter) {
/* 1072 */     CachedPreparedStatement cachedPstmt = getMessageListSQL(resultFilter, false);
/* 1073 */     long[] messageBlock = QueryCache.getBlock(cachedPstmt, 0, this.id, resultFilter.getStartIndex(), true);
/*      */ 
/* 1075 */     int startIndex = resultFilter.getStartIndex();
/*      */     int endIndex;
/*      */     int endIndex;
/* 1079 */     if (resultFilter.getNumResults() == 2147483524) {
/* 1080 */       endIndex = getMessageCount(resultFilter);
/*      */     }
/*      */     else {
/* 1083 */       endIndex = resultFilter.getNumResults() + startIndex;
/*      */     }
/* 1085 */     return new ForumMessageBlockIterator(messageBlock, cachedPstmt, startIndex, endIndex, 0, this.id);
/*      */   }
/*      */ 
/*      */   public int getThreadCount()
/*      */   {
/* 1090 */     return getThreadCount(DEFAULT_THREAD_FILTER);
/*      */   }
/*      */ 
/*      */   public int getThreadCount(ResultFilter resultFilter) {
/* 1094 */     CachedPreparedStatement cachedPstmt = getThreadListSQL(resultFilter, true);
/* 1095 */     QueryCacheKey key = new QueryCacheKey(0, this.id, cachedPstmt, -1);
/* 1096 */     return QueryCache.getCount(key, true);
/*      */   }
/*      */ 
/*      */   public int getMessageCount() {
/* 1100 */     return getMessageCount(DEFAULT_MESSAGE_FILTER);
/*      */   }
/*      */ 
/*      */   public int getMessageCount(ResultFilter resultFilter) {
/* 1104 */     CachedPreparedStatement cachedPstmt = getMessageListSQL(resultFilter, true);
/* 1105 */     QueryCacheKey key = new QueryCacheKey(0, this.id, cachedPstmt, -1);
/* 1106 */     return QueryCache.getCount(key, true);
/*      */   }
/*      */ 
/*      */   public ForumMessage getLatestMessage() {
/* 1110 */     if (getMessageCount() == 0) {
/* 1111 */       return null;
/*      */     }
/* 1113 */     ResultFilter filter = new ResultFilter();
/* 1114 */     filter.setSortOrder(0);
/* 1115 */     filter.setSortField(9);
/*      */ 
/* 1117 */     filter.setModificationDateRangeMin(ResultFilter.roundDate(this.modificationDate, 86400));
/* 1118 */     filter.setNumResults(1);
/* 1119 */     Iterator messages = getMessages(filter);
/* 1120 */     ForumMessage latestMessage = null;
/* 1121 */     if (messages.hasNext()) {
/* 1122 */       latestMessage = (ForumMessage)messages.next();
/*      */     }
/*      */ 
/* 1127 */     if (latestMessage == null) {
/* 1128 */       filter = new ResultFilter();
/* 1129 */       filter.setSortOrder(0);
/* 1130 */       filter.setSortField(9);
/* 1131 */       filter.setNumResults(1);
/* 1132 */       messages = getMessages(filter);
/* 1133 */       if (messages.hasNext()) {
/* 1134 */         latestMessage = (ForumMessage)messages.next();
/*      */       }
/*      */     }
/*      */ 
/* 1138 */     return latestMessage;
/*      */   }
/*      */ 
/*      */   public Query createQuery() {
/* 1142 */     return FACTORY.getQueryManager().createQuery(new ExternalizableLite[] { this });
/*      */   }
/*      */ 
/*      */   public synchronized FilterManager getFilterManager() {
/* 1146 */     if (this.filterManager == null) {
/* 1147 */       this.filterManager = new DbFilterManager(0, this.id);
/* 1148 */       this.filterManager.initialize();
/*      */     }
/* 1150 */     return this.filterManager;
/*      */   }
/*      */ 
/*      */   public synchronized InterceptorManager getInterceptorManager() {
/* 1154 */     if (this.interceptorManager == null) {
/* 1155 */       this.interceptorManager = new DbInterceptorManager(0, this.id);
/* 1156 */       this.interceptorManager.initialize();
/*      */     }
/* 1158 */     return this.interceptorManager;
/*      */   }
/*      */ 
/*      */   public GatewayManager getGatewayManager() {
/* 1162 */     GatewayManager manager = null;
/* 1163 */     synchronized (FACTORY.gatewayManagers) {
/* 1164 */       manager = (GatewayManager)FACTORY.gatewayManagers.get(this.id);
/*      */ 
/* 1166 */       if (manager == null) {
/* 1167 */         manager = new GatewayManager(FACTORY, this);
/* 1168 */         FACTORY.gatewayManagers.put(this.id, manager);
/*      */       }
/*      */     }
/* 1171 */     return manager;
/*      */   }
/*      */ 
/*      */   public PermissionsManager getPermissionsManager()
/*      */   {
/* 1176 */     return null;
/*      */   }
/*      */ 
/*      */   public Permissions getPermissions(AuthToken authToken)
/*      */   {
/* 1181 */     Permissions perms = new Permissions(0L);
/* 1182 */     perms.set(getForumCategory().getPermissions(authToken).value(), true);
/*      */ 
/* 1185 */     Permissions p = DbPermissionsManager.getInstance().getFinalUserPerms(0, this.id, authToken.getUserID(), PermissionType.NEGATIVE);
/*      */ 
/* 1187 */     perms.set(p.value(), false);
/*      */ 
/* 1190 */     p = DbPermissionsManager.getInstance().getFinalUserPerms(0, this.id, authToken.getUserID(), PermissionType.ADDITIVE);
/*      */ 
/* 1192 */     perms.set(p.value(), true);
/*      */ 
/* 1194 */     return perms;
/*      */   }
/*      */ 
/*      */   public boolean isAuthorized(long type) {
/* 1198 */     return true;
/*      */   }
/*      */ 
/*      */   public static int getObjectType()
/*      */   {
/* 1204 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getCachedSize()
/*      */   {
/* 1212 */     int size = 0;
/* 1213 */     size += CacheSizes.sizeOfObject();
/* 1214 */     size += CacheSizes.sizeOfLong();
/* 1215 */     size += CacheSizes.sizeOfString(this.name);
/* 1216 */     size += CacheSizes.sizeOfString(this.nntpName);
/* 1217 */     size += CacheSizes.sizeOfString(this.description);
/* 1218 */     size += CacheSizes.sizeOfDate();
/* 1219 */     size += CacheSizes.sizeOfDate();
/* 1220 */     size += CacheSizes.sizeOfMap(this.properties);
/* 1221 */     size += CacheSizes.sizeOfObject() + CacheSizes.sizeOfLong() * 5;
/*      */ 
/* 1223 */     size += CacheSizes.sizeOfInt() * 4;
/* 1224 */     return size;
/*      */   }
/*      */ 
/*      */   public void readExternal(DataInput in)
/*      */     throws IOException
/*      */   {
/* 1230 */     this.id = ExternalizableHelper.readLong(in);
/* 1231 */     this.categoryID = ExternalizableHelper.readLong(in);
/* 1232 */     this.name = ExternalizableHelper.readSafeUTF(in);
/* 1233 */     this.nntpName = ExternalizableHelper.readSafeUTF(in);
/* 1234 */     this.description = ExternalizableHelper.readSafeUTF(in);
/* 1235 */     this.creationDate = new Date(in.readLong());
/* 1236 */     this.modificationDate = new Date(in.readLong());
/* 1237 */     this.modDefaultThreadValue = ExternalizableHelper.readInt(in);
/* 1238 */     this.modDefaultMessageValue = ExternalizableHelper.readInt(in);
/* 1239 */     this.properties = ExternalizableLiteUtil.readStringMap(in);
/* 1240 */     this.popularThreads = ExternalizableLiteUtil.readLongArray(in);
/*      */ 
/* 1246 */     this.minForumIndex = -1;
/* 1247 */     this.maxForumIndex = -1;
/*      */   }
/*      */ 
/*      */   public void writeExternal(DataOutput out) throws IOException {
/* 1251 */     ExternalizableHelper.writeLong(out, this.id);
/* 1252 */     ExternalizableHelper.writeLong(out, this.categoryID);
/* 1253 */     ExternalizableHelper.writeSafeUTF(out, this.name);
/* 1254 */     ExternalizableHelper.writeSafeUTF(out, this.nntpName);
/* 1255 */     ExternalizableHelper.writeSafeUTF(out, this.description);
/* 1256 */     out.writeLong(this.creationDate.getTime());
/* 1257 */     out.writeLong(this.modificationDate.getTime());
/* 1258 */     ExternalizableHelper.writeInt(out, this.modDefaultThreadValue);
/* 1259 */     ExternalizableHelper.writeInt(out, this.modDefaultMessageValue);
/* 1260 */     ExternalizableLiteUtil.writeStringMap(out, this.properties);
/* 1261 */     ExternalizableLiteUtil.writeLongArray(out, this.popularThreads);
/*      */   }
/*      */ 
/*      */   private void readObject(ObjectInputStream in)
/*      */     throws IOException, ClassNotFoundException
/*      */   {
/* 1267 */     in.defaultReadObject();
/*      */ 
/* 1272 */     this.minForumIndex = -1;
/* 1273 */     this.maxForumIndex = -1;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1282 */     return this.name;
/*      */   }
/*      */ 
/*      */   public int hashCode() {
/* 1286 */     return (int)this.id;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object object) {
/* 1290 */     if (this == object) {
/* 1291 */       return true;
/*      */     }
/* 1293 */     if ((object != null) && ((object instanceof ExternalizableLite))) {
/* 1294 */       return this.id == ((ExternalizableLite)object).getID();
/*      */     }
/*      */ 
/* 1297 */     return false;
/*      */   }
/*      */ 
/*      */   public static String convertToNNTP(String forumName, ForumCategory category)
/*      */   {
/* 1309 */     String name = forumName;
/* 1310 */     name = name.trim().replace('.', '_');
/* 1311 */     ForumCategory rootCategory = DbForumFactory.getInstance().getRootForumCategory();
/* 1312 */     while (!category.equals(rootCategory)) {
/* 1313 */       String categoryName = category.getName();
/* 1314 */       categoryName = categoryName.trim().replace('.', '_');
/* 1315 */       name = categoryName + "." + name;
/* 1316 */       category = category.getParentCategory();
/*      */     }
/* 1318 */     name = name.toLowerCase();
/*      */ 
/* 1321 */     name = name.replaceAll("[[*!,\\s][^\\p{ASCII}]]", "_");
/* 1322 */     return name;
/*      */   }
/*      */ 
/*      */   protected void updateModifiedDate(long date, Connection con)
/*      */     throws SQLException
/*      */   {
/* 1330 */     if (!ENABLE_DATE_UPDATES) {
/* 1331 */       return;
/*      */     }
/*      */ 
/* 1335 */     if (date > this.modificationDate.getTime()) {
/* 1336 */       this.modificationDate.setTime(date);
/* 1337 */       PreparedStatement pstmt = null;
/*      */       try {
/* 1339 */         pstmt = con.prepareStatement("UPDATE jiveForum SET modificationDate=? WHERE forumID=?");
/* 1340 */         pstmt.setLong(1, this.modificationDate.getTime());
/* 1341 */         pstmt.setLong(2, this.id);
/* 1342 */         pstmt.executeUpdate();
/*      */       }
/*      */       finally {
/* 1345 */         ConnectionManager.closePreparedStatement(pstmt);
/*      */       }
/* 1347 */       FACTORY.cacheManager.forumCache.put(new Long(this.id), this);
/* 1348 */       ((DbForumCategory)getForumCategory()).updateModifiedDate(date, con);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected long[] getAllThreads()
/*      */   {
/* 1360 */     LongList threads = new LongList(getThreadCount());
/* 1361 */     Connection con = null;
/* 1362 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1364 */       con = ConnectionManager.getConnection();
/* 1365 */       pstmt = con.prepareStatement("SELECT threadID FROM jiveThread WHERE forumID=?");
/* 1366 */       pstmt.setLong(1, this.id);
/* 1367 */       ResultSet rs = pstmt.executeQuery();
/* 1368 */       while (rs.next()) {
/* 1369 */         threads.add(rs.getLong(1));
/*      */       }
/* 1371 */       rs.close();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 1374 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/* 1377 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/* 1379 */     return threads.toArray();
/*      */   }
/*      */ 
/*      */   protected void clearCache()
/*      */   {
/* 1386 */     Profiler.begin("clearCache");
/* 1387 */     FACTORY.cacheManager.queryRemove(0, this.id);
/*      */ 
/* 1390 */     this.popularThreads = null;
/*      */ 
/* 1393 */     this.minForumIndex = -1;
/* 1394 */     this.maxForumIndex = -1;
/*      */ 
/* 1397 */     DbForumCategory dbCategory = (DbForumCategory)getForumCategory();
/*      */     do {
/* 1399 */       dbCategory.clearCache();
/* 1400 */       dbCategory = (DbForumCategory)dbCategory.getParentCategory();
/* 1401 */     }while (dbCategory != null);
/*      */ 
/* 1404 */     FACTORY.expirePopularObjects(false);
/* 1405 */     Profiler.end("clearCache");
/*      */   }
/*      */ 
/*      */   protected CachedPreparedStatement getThreadListSQL(ResultFilter resultFilter, boolean countQuery)
/*      */   {
/* 1414 */     boolean isMysql = ConnectionManager.getDatabaseType() == ConnectionManager.DatabaseType.MYSQL;
/* 1415 */     int sortField = resultFilter.getSortField();
/*      */ 
/* 1418 */     if ((!countQuery) && (sortField != 9) && (sortField != 8) && (sortField != 5) && ((sortField != 10) || (resultFilter.getSortPropertyName() == null)))
/*      */     {
/* 1427 */       throw new IllegalArgumentException("The specified sort field is not valid.");
/*      */     }
/*      */ 
/* 1430 */     CachedPreparedStatement pstmt = new CachedPreparedStatement();
/* 1431 */     StringBuffer query = new StringBuffer(80);
/* 1432 */     if (!countQuery) {
/* 1433 */       query.append("SELECT jiveThread.threadID");
/*      */     }
/*      */     else {
/* 1436 */       query.append("SELECT count(*)");
/*      */     }
/*      */ 
/* 1439 */     boolean filterUser = resultFilter.getUserID() != 2147483524L;
/* 1440 */     boolean filterCreationDate = (resultFilter.getCreationDateRangeMin() != null) || (resultFilter.getCreationDateRangeMax() != null);
/*      */ 
/* 1442 */     boolean filterModifiedDate = (resultFilter.getModificationDateRangeMin() != null) || (resultFilter.getModificationDateRangeMax() != null);
/*      */ 
/* 1444 */     int propertyCount = resultFilter.getPropertyCount();
/*      */ 
/* 1447 */     if (!countQuery) {
/* 1448 */       switch (sortField) {
/*      */       case 5:
/* 1450 */         query.append(", jiveMessage.subject");
/* 1451 */         break;
/*      */       case 9:
/* 1453 */         query.append(", jiveThread.modificationDate");
/* 1454 */         break;
/*      */       case 8:
/* 1456 */         query.append(", jiveThread.creationDate");
/* 1457 */         break;
/*      */       case 10:
/* 1459 */         query.append(", propTable.propValue");
/*      */       case 6:
/*      */       case 7:
/*      */       }
/*      */     }
/*      */ 
/* 1465 */     if (isMysql)
/*      */     {
/* 1467 */       boolean isForceIndex = false;
/* 1468 */       query.append(" FROM jiveThread");
/* 1469 */       if (!FACTORY.moderationDisabled()) {
/* 1470 */         query.append(" FORCE INDEX (jiveThread_forumID_modVal_idx");
/* 1471 */         isForceIndex = true;
/*      */       }
/* 1473 */       if ((!countQuery) && (sortField == 9)) {
/* 1474 */         if (isForceIndex) {
/* 1475 */           query.append(", ");
/*      */         }
/*      */         else {
/* 1478 */           query.append(" FORCE INDEX (");
/* 1479 */           isForceIndex = true;
/*      */         }
/* 1481 */         query.append("jiveThread_mDate_idx");
/*      */       }
/* 1483 */       else if ((!countQuery) && (sortField == 8)) {
/* 1484 */         if (isForceIndex) {
/* 1485 */           query.append(", ");
/*      */         }
/*      */         else {
/* 1488 */           query.append(" FORCE INDEX (");
/* 1489 */           isForceIndex = true;
/*      */         }
/* 1491 */         query.append("jiveThread_cDate_idx");
/*      */       }
/*      */ 
/* 1494 */       if (isForceIndex)
/* 1495 */         query.append(")");
/*      */     }
/*      */     else
/*      */     {
/* 1499 */       query.append(" FROM jiveThread");
/*      */     }
/*      */ 
/* 1502 */     if ((filterUser) || ((!countQuery) && (resultFilter.getSortField() == 5)))
/*      */     {
/* 1505 */       query.append(", jiveMessage");
/*      */     }
/* 1507 */     for (int i = 0; i < propertyCount; i++) {
/* 1508 */       query.append(", jiveThreadProp p").append(i);
/*      */     }
/* 1510 */     if (resultFilter.getSortField() == 10) {
/* 1511 */       query.append(", jiveThreadProp propTable");
/*      */     }
/*      */ 
/* 1515 */     query.append(" WHERE jiveThread.forumID=?");
/* 1516 */     pstmt.addLong(this.id);
/*      */ 
/* 1518 */     if ((filterUser) || ((!countQuery) && (sortField == 5))) {
/* 1519 */       query.append(" AND jiveThread.threadID=jiveMessage.threadID");
/* 1520 */       query.append(" AND jiveMessage.parentMessageID IS NULL");
/*      */     }
/* 1522 */     if (filterUser) {
/* 1523 */       query.append(" AND jiveMessage.userID=?");
/* 1524 */       pstmt.addLong(resultFilter.getUserID());
/*      */     }
/*      */ 
/* 1527 */     for (int i = 0; i < propertyCount; i++) {
/* 1528 */       query.append(" AND jiveThread.threadID=p").append(i).append(".threadID");
/* 1529 */       query.append(" AND p").append(i).append(".name=?");
/* 1530 */       pstmt.addString(resultFilter.getPropertyName(i));
/* 1531 */       query.append(" AND p").append(i).append(".propValue=?");
/* 1532 */       pstmt.addString(resultFilter.getPropertyValue(i));
/*      */     }
/*      */ 
/* 1535 */     if ((!countQuery) && (sortField == 5)) {
/* 1536 */       query.append(" AND jiveThread.threadID=jiveMessage.threadID");
/*      */     }
/*      */ 
/* 1539 */     if (sortField == 10) {
/* 1540 */       query.append(" AND jiveThread.threadID=propTable.threadID");
/* 1541 */       query.append(" AND propTable.name=?");
/* 1542 */       pstmt.addString(resultFilter.getSortPropertyName());
/*      */     }
/*      */ 
/* 1546 */     if (filterCreationDate) {
/* 1547 */       if (resultFilter.getCreationDateRangeMin() != null) {
/* 1548 */         query.append(" AND jiveThread.creationDate >= ?");
/* 1549 */         pstmt.addLong(resultFilter.getCreationDateRangeMin().getTime());
/*      */       }
/* 1551 */       if (resultFilter.getCreationDateRangeMax() != null) {
/* 1552 */         query.append(" AND jiveThread.creationDate <= ?");
/* 1553 */         pstmt.addLong(resultFilter.getCreationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1558 */     if (filterModifiedDate) {
/* 1559 */       if (resultFilter.getModificationDateRangeMin() != null) {
/* 1560 */         query.append(" AND jiveThread.modificationDate >= ?");
/* 1561 */         pstmt.addLong(resultFilter.getModificationDateRangeMin().getTime());
/*      */       }
/* 1563 */       if (resultFilter.getModificationDateRangeMax() != null) {
/* 1564 */         query.append(" AND jiveThread.modificationDate <= ?");
/* 1565 */         pstmt.addLong(resultFilter.getModificationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1571 */     if (!FACTORY.moderationDisabled()) {
/* 1572 */       int moderationRangeMin = resultFilter.getModerationRangeMin();
/*      */ 
/* 1575 */       if (moderationRangeMin == 2147483524) {
/* 1576 */         moderationRangeMin = 1;
/*      */       }
/* 1578 */       int moderationRangeMax = resultFilter.getModerationRangeMax();
/* 1579 */       if (moderationRangeMin == moderationRangeMax) {
/* 1580 */         query.append(" AND jiveThread.modValue = ?");
/* 1581 */         pstmt.addInt(moderationRangeMin);
/*      */       }
/*      */       else
/*      */       {
/* 1585 */         if (moderationRangeMin > -1000000) {
/* 1586 */           query.append(" AND jiveThread.modValue >= ?");
/* 1587 */           pstmt.addInt(moderationRangeMin);
/*      */         }
/*      */ 
/* 1590 */         if (moderationRangeMax != 2147483524) {
/* 1591 */           query.append(" AND jiveThread.modValue <= ?");
/* 1592 */           pstmt.addInt(moderationRangeMax);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1598 */     if (!countQuery) {
/* 1599 */       switch (sortField) {
/*      */       case 5:
/* 1601 */         query.append(" ORDER BY jiveMessage.subject");
/* 1602 */         break;
/*      */       case 9:
/* 1604 */         query.append(" ORDER BY jiveThread.modificationDate");
/* 1605 */         break;
/*      */       case 8:
/* 1607 */         query.append(" ORDER BY jiveThread.creationDate");
/* 1608 */         break;
/*      */       case 10:
/* 1610 */         query.append(" ORDER BY propTable.propValue");
/*      */       case 6:
/*      */       case 7:
/* 1613 */       }if (resultFilter.getSortOrder() == 0) {
/* 1614 */         query.append(" DESC");
/*      */       }
/*      */       else {
/* 1617 */         query.append(" ASC");
/*      */       }
/*      */     }
/*      */ 
/* 1621 */     pstmt.setSQL(query.toString());
/* 1622 */     return pstmt;
/*      */   }
/*      */ 
/*      */   protected CachedPreparedStatement getMessageListSQL(ResultFilter resultFilter, boolean countQuery)
/*      */   {
/* 1631 */     boolean isMysql = ConnectionManager.getDatabaseType() == ConnectionManager.DatabaseType.MYSQL;
/* 1632 */     int sortField = resultFilter.getSortField();
/*      */ 
/* 1635 */     if ((!countQuery) && (sortField != 9) && (sortField != 8) && (sortField != 6) && ((sortField != 10) || (resultFilter.getSortPropertyName() == null)))
/*      */     {
/* 1644 */       throw new IllegalArgumentException("The specified sort field is not valid.");
/*      */     }
/*      */ 
/* 1647 */     CachedPreparedStatement pstmt = new CachedPreparedStatement();
/*      */ 
/* 1649 */     StringBuffer query = new StringBuffer(200);
/* 1650 */     if (!countQuery) {
/* 1651 */       query.append("SELECT jiveMessage.messageID");
/*      */     }
/*      */     else {
/* 1654 */       query.append("SELECT count(*)");
/*      */     }
/*      */ 
/* 1657 */     boolean filterUser = resultFilter.getUserID() != 2147483524L;
/* 1658 */     boolean filterCreationDate = (resultFilter.getCreationDateRangeMin() != null) || (resultFilter.getCreationDateRangeMax() != null);
/*      */ 
/* 1660 */     boolean filterModifiedDate = (resultFilter.getModificationDateRangeMin() != null) || (resultFilter.getModificationDateRangeMax() != null);
/*      */ 
/* 1662 */     int propertyCount = resultFilter.getPropertyCount();
/*      */ 
/* 1665 */     if (!countQuery) {
/* 1666 */       switch (sortField) {
/*      */       case 6:
/* 1668 */         query.append(", subject");
/* 1669 */         break;
/*      */       case 9:
/* 1671 */         query.append(", modificationDate");
/* 1672 */         break;
/*      */       case 8:
/* 1674 */         query.append(", creationDate");
/* 1675 */         break;
/*      */       case 10:
/* 1677 */         query.append(", propTable.propValue");
/*      */       case 7:
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1683 */     if ((!isMysql) || ((isMysql) && (countQuery))) {
/* 1684 */       query.append(" FROM jiveMessage");
/*      */     }
/*      */     else
/*      */     {
/* 1688 */       boolean isForceIndex = false;
/* 1689 */       query.append(" FROM jiveMessage");
/* 1690 */       if (!FACTORY.moderationDisabled()) {
/* 1691 */         query.append(" FORCE INDEX (jiveMessage_forumID_modVal_idx");
/* 1692 */         isForceIndex = true;
/*      */       }
/* 1694 */       if (sortField == 9) {
/* 1695 */         if (isForceIndex) {
/* 1696 */           query.append(", ");
/*      */         }
/*      */         else {
/* 1699 */           query.append(" FORCE INDEX (");
/* 1700 */           isForceIndex = true;
/*      */         }
/* 1702 */         query.append("jiveMessage_mDate_idx");
/*      */       }
/* 1704 */       else if (sortField == 8) {
/* 1705 */         if (isForceIndex) {
/* 1706 */           query.append(", ");
/*      */         }
/*      */         else {
/* 1709 */           query.append(" FORCE INDEX (");
/* 1710 */           isForceIndex = true;
/*      */         }
/* 1712 */         query.append("jiveMessage_cDate_idx");
/*      */       }
/*      */ 
/* 1715 */       if (filterUser) {
/* 1716 */         if (isForceIndex) {
/* 1717 */           query.append(", ");
/*      */         }
/*      */         else {
/* 1720 */           query.append(" FORCE INDEX (");
/* 1721 */           isForceIndex = true;
/*      */         }
/* 1723 */         query.append("jiveMessage_userID_idx");
/*      */       }
/*      */ 
/* 1726 */       if (isForceIndex) {
/* 1727 */         query.append(")");
/*      */       }
/*      */     }
/*      */ 
/* 1731 */     for (int i = 0; i < propertyCount; i++) {
/* 1732 */       query.append(", jiveMessageProp p").append(i);
/*      */     }
/* 1734 */     if (resultFilter.getSortField() == 10) {
/* 1735 */       query.append(", jiveMessageProp propTable");
/*      */     }
/*      */ 
/* 1739 */     query.append(" WHERE forumID=?");
/* 1740 */     pstmt.addLong(this.id);
/*      */ 
/* 1742 */     if (filterUser) {
/* 1743 */       query.append(" AND userID=?");
/* 1744 */       pstmt.addLong(resultFilter.getUserID());
/*      */     }
/*      */ 
/* 1747 */     for (int i = 0; i < propertyCount; i++) {
/* 1748 */       query.append(" AND jiveMessage.messageID=p").append(i).append(".messageID");
/* 1749 */       query.append(" AND p").append(i).append(".name=?");
/* 1750 */       pstmt.addString(resultFilter.getPropertyName(i));
/* 1751 */       query.append(" AND p").append(i).append(".propValue=?");
/* 1752 */       pstmt.addString(resultFilter.getPropertyValue(i));
/*      */     }
/*      */ 
/* 1755 */     if (sortField == 10) {
/* 1756 */       query.append(" AND jiveMessage.messageID=propTable.messageID");
/* 1757 */       query.append(" AND propTable.name=?");
/* 1758 */       pstmt.addString(resultFilter.getSortPropertyName());
/*      */     }
/*      */ 
/* 1762 */     if (filterCreationDate) {
/* 1763 */       if (resultFilter.getCreationDateRangeMin() != null) {
/* 1764 */         query.append(" AND creationDate >= ?");
/* 1765 */         pstmt.addLong(resultFilter.getCreationDateRangeMin().getTime());
/*      */       }
/* 1767 */       if (resultFilter.getCreationDateRangeMax() != null) {
/* 1768 */         query.append(" AND creationDate <= ?");
/* 1769 */         pstmt.addLong(resultFilter.getCreationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1774 */     if (filterModifiedDate) {
/* 1775 */       if (resultFilter.getModificationDateRangeMin() != null) {
/* 1776 */         query.append(" AND modificationDate >= ?");
/* 1777 */         pstmt.addLong(resultFilter.getModificationDateRangeMin().getTime());
/*      */       }
/* 1779 */       if (resultFilter.getModificationDateRangeMax() != null) {
/* 1780 */         query.append(" AND modificationDate <= ?");
/* 1781 */         pstmt.addLong(resultFilter.getModificationDateRangeMax().getTime());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1787 */     if (!FACTORY.moderationDisabled()) {
/* 1788 */       int moderationRangeMin = resultFilter.getModerationRangeMin();
/*      */ 
/* 1791 */       if (moderationRangeMin == 2147483524) {
/* 1792 */         moderationRangeMin = 1;
/*      */       }
/* 1794 */       int moderationRangeMax = resultFilter.getModerationRangeMax();
/* 1795 */       if (moderationRangeMin == moderationRangeMax) {
/* 1796 */         query.append(" AND modValue = ?");
/* 1797 */         pstmt.addInt(moderationRangeMin);
/*      */       }
/*      */       else
/*      */       {
/* 1801 */         if (moderationRangeMin > -1000000) {
/* 1802 */           query.append(" AND modValue >= ?");
/* 1803 */           pstmt.addInt(moderationRangeMin);
/*      */         }
/*      */ 
/* 1806 */         if (moderationRangeMax != 2147483524) {
/* 1807 */           query.append(" AND modValue <= ?");
/* 1808 */           pstmt.addInt(moderationRangeMax);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1814 */     if (!countQuery) {
/* 1815 */       switch (sortField) {
/*      */       case 6:
/* 1817 */         query.append(" ORDER BY subject");
/* 1818 */         break;
/*      */       case 9:
/* 1820 */         query.append(" ORDER BY modificationDate");
/* 1821 */         break;
/*      */       case 8:
/* 1823 */         query.append(" ORDER BY creationDate");
/* 1824 */         break;
/*      */       case 10:
/* 1826 */         query.append(" ORDER BY propTable.propValue");
/*      */       case 7:
/*      */       }
/* 1829 */       if (resultFilter.getSortOrder() == 0) {
/* 1830 */         query.append(" DESC");
/*      */       }
/*      */       else {
/* 1833 */         query.append(" ASC");
/*      */       }
/*      */     }
/*      */ 
/* 1837 */     pstmt.setSQL(query.toString());
/* 1838 */     return pstmt;
/*      */   }
/*      */ 
/*      */   private synchronized void loadPropertiesFromDb()
/*      */   {
/* 1845 */     this.properties = new Hashtable();
/* 1846 */     Connection con = null;
/* 1847 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1849 */       con = ConnectionManager.getConnection();
/* 1850 */       pstmt = con.prepareStatement("SELECT name, propValue FROM jiveForumProp WHERE forumID=?");
/* 1851 */       pstmt.setLong(1, this.id);
/* 1852 */       ResultSet rs = pstmt.executeQuery();
/* 1853 */       while (rs.next()) {
/* 1854 */         String name = rs.getString(1);
/* 1855 */         String value = rs.getString(2);
/* 1856 */         this.properties.put(name, value);
/*      */       }
/* 1858 */       rs.close();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 1861 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/* 1864 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/* 1868 */     FACTORY.cacheManager.forumCache.put(new Long(this.id), this);
/*      */   }
/*      */ 
/*      */   private void insertPropertyIntoDb(String name, String value)
/*      */   {
/* 1875 */     Connection con = null;
/* 1876 */     PreparedStatement pstmt = null;
/* 1877 */     boolean abortTransaction = false;
/*      */     try {
/* 1879 */       con = ConnectionManager.getTransactionConnection();
/* 1880 */       pstmt = con.prepareStatement("INSERT INTO jiveForumProp(forumID,name,propValue) VALUES(?,?,?)");
/* 1881 */       pstmt.setLong(1, this.id);
/* 1882 */       pstmt.setString(2, name);
/* 1883 */       pstmt.setString(3, value);
/* 1884 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 1887 */       Log.error(sqle);
/* 1888 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/* 1891 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void updatePropertyInDb(String name, String value)
/*      */   {
/* 1899 */     Connection con = null;
/* 1900 */     PreparedStatement pstmt = null;
/* 1901 */     boolean abortTransaction = false;
/*      */     try {
/* 1903 */       con = ConnectionManager.getTransactionConnection();
/* 1904 */       pstmt = con.prepareStatement("UPDATE jiveForumProp SET propValue=? WHERE name=? AND forumID=?");
/* 1905 */       pstmt.setString(1, value);
/* 1906 */       pstmt.setString(2, name);
/* 1907 */       pstmt.setLong(3, this.id);
/* 1908 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 1911 */       Log.error(sqle);
/* 1912 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/* 1915 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void deletePropertyFromDb(String name)
/*      */   {
/* 1923 */     Connection con = null;
/* 1924 */     PreparedStatement pstmt = null;
/* 1925 */     boolean abortTransaction = false;
/*      */     try {
/* 1927 */       con = ConnectionManager.getTransactionConnection();
/* 1928 */       pstmt = con.prepareStatement("DELETE FROM jiveForumProp WHERE forumID=? AND name=?");
/* 1929 */       pstmt.setLong(1, this.id);
/* 1930 */       pstmt.setString(2, name);
/* 1931 */       pstmt.execute();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 1934 */       Log.error(sqle);
/* 1935 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/* 1938 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void loadFromDb()
/*      */     throws ForumNotFoundException
/*      */   {
/* 1946 */     Connection con = null;
/* 1947 */     PreparedStatement pstmt = null;
/*      */     try {
/* 1949 */       con = ConnectionManager.getConnection();
/*      */ 
/* 1951 */       if (this.id != -1L) {
/* 1952 */         pstmt = con.prepareStatement("SELECT forumID, name, nntpName, description, modDefaultThreadVal, modDefaultMsgVal, creationDate, modificationDate, categoryID FROM jiveForum WHERE forumID=?");
/* 1953 */         pstmt.setLong(1, this.id);
/*      */       }
/*      */       else {
/* 1956 */         pstmt = con.prepareStatement("SELECT forumID, name, nntpName, description, modDefaultThreadVal, modDefaultMsgVal, creationDate, modificationDate, categoryID FROM jiveForum WHERE nntpName=?");
/* 1957 */         pstmt.setString(1, this.nntpName);
/*      */       }
/* 1959 */       ResultSet rs = pstmt.executeQuery();
/* 1960 */       if (!rs.next()) {
/* 1961 */         rs.close();
/* 1962 */         throw new ForumNotFoundException("Forum " + getID() + " could not be loaded from the database.", this.id);
/*      */       }
/*      */ 
/* 1965 */       this.id = rs.getLong(1);
/* 1966 */       this.name = rs.getString(2);
/* 1967 */       this.nntpName = rs.getString(3);
/* 1968 */       this.description = rs.getString(4);
/* 1969 */       this.modDefaultThreadValue = rs.getInt(5);
/* 1970 */       this.modDefaultMessageValue = rs.getInt(6);
/* 1971 */       this.creationDate = new Date(rs.getLong(7));
/* 1972 */       this.modificationDate = new Date(rs.getLong(8));
/* 1973 */       this.categoryID = rs.getLong(9);
/* 1974 */       rs.close();
/*      */     }
/*      */     catch (SQLException sqle)
/*      */     {
/* 1992 */       Log.error(sqle);
/* 1993 */       throw new ForumNotFoundException("Forum " + getID() + " could not be loaded from the database.", getID());
/*      */     }
/*      */     catch (NumberFormatException nfe)
/*      */     {
/* 1997 */       Log.warn("WARNING: In DbForum.loadFromDb() -- there was an error parsing the dates returned from the database. Ensure that they're being stored correctly.");
/*      */     }
/*      */     finally
/*      */     {
/* 2002 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void insertIntoDb(int categoryIndex)
/*      */   {
/* 2010 */     Connection con = null;
/* 2011 */     PreparedStatement pstmt = null;
/* 2012 */     boolean abortTransaction = false;
/*      */     try {
/* 2014 */       con = ConnectionManager.getTransactionConnection();
/* 2015 */       pstmt = con.prepareStatement("INSERT INTO jiveForum(forumID, categoryID, categoryIndex, name, nntpName, description, modDefaultThreadVal, modDefaultMsgVal, creationDate, modificationDate, forumIndexCounter) VALUES (?,?,?,?,?,?,?,?,?,?,0)");
/* 2016 */       pstmt.setLong(1, this.id);
/* 2017 */       pstmt.setLong(2, this.categoryID);
/* 2018 */       pstmt.setInt(3, categoryIndex);
/* 2019 */       pstmt.setString(4, this.name);
/* 2020 */       pstmt.setString(5, this.nntpName);
/* 2021 */       pstmt.setString(6, this.description);
/* 2022 */       pstmt.setInt(7, this.modDefaultThreadValue);
/* 2023 */       pstmt.setInt(8, this.modDefaultMessageValue);
/* 2024 */       pstmt.setLong(9, this.creationDate.getTime());
/* 2025 */       pstmt.setLong(10, this.modificationDate.getTime());
/* 2026 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 2029 */       Log.error(sqle);
/* 2030 */       abortTransaction = true;
/*      */     }
/*      */     finally {
/* 2033 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void saveToDb()
/*      */   {
/* 2041 */     Connection con = null;
/* 2042 */     PreparedStatement pstmt = null;
/*      */     try {
/* 2044 */       con = ConnectionManager.getConnection();
/* 2045 */       pstmt = con.prepareStatement("UPDATE jiveForum SET name=?, nntpName=?, description=?, modDefaultThreadVal=?, modDefaultMsgVal=?, creationDate=?, modificationDate=? WHERE forumID=?");
/* 2046 */       pstmt.setString(1, this.name);
/* 2047 */       pstmt.setString(2, this.nntpName);
/* 2048 */       pstmt.setString(3, this.description);
/* 2049 */       pstmt.setInt(4, this.modDefaultThreadValue);
/* 2050 */       pstmt.setInt(5, this.modDefaultMessageValue);
/* 2051 */       pstmt.setLong(6, this.creationDate.getTime());
/* 2052 */       pstmt.setLong(7, this.modificationDate.getTime());
/* 2053 */       pstmt.setLong(8, this.id);
/* 2054 */       pstmt.executeUpdate();
/*      */     }
/*      */     catch (SQLException sqle) {
/* 2057 */       Log.error(sqle);
/*      */     }
/*      */     finally {
/* 2060 */       ConnectionManager.closeConnection(pstmt, con);
/*      */     }
/*      */ 
/* 2064 */     FACTORY.cacheManager.forumCache.put(new Long(this.id), this);
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbForum
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.action.rss;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.action.rss.RSSActionSupport;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.util.SkinUtils;
/*     */ import com.jivesoftware.util.LocaleUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class RSSForums extends RSSActionSupport
/*     */ {
/*     */   private String categoryIDs;
/*     */   private String forumIDs;
/*     */   private boolean fullListingEnabled;
/*     */   private Iterator forums;
/*     */   private List forumList;
/*     */ 
/*     */   public String getCategoryIDs()
/*     */   {
/*  39 */     return this.categoryIDs;
/*     */   }
/*     */ 
/*     */   public void setCategoryIDs(String categoryIDs) {
/*  43 */     this.categoryIDs = categoryIDs;
/*     */   }
/*     */ 
/*     */   public String getForumIDs() {
/*  47 */     return this.forumIDs;
/*     */   }
/*     */ 
/*     */   public void setForumIDs(String forumIDs) {
/*  51 */     this.forumIDs = forumIDs;
/*     */   }
/*     */ 
/*     */   public boolean isFullListingEnabled()
/*     */   {
/*  58 */     return this.fullListingEnabled;
/*     */   }
/*     */ 
/*     */   private void setFullListingEnabled(boolean fullListingEnabled)
/*     */   {
/*  66 */     this.fullListingEnabled = fullListingEnabled;
/*     */   }
/*     */ 
/*     */   public Iterator getForums()
/*     */   {
/*  73 */     if (this.forums == null) {
/*  74 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/*  76 */     return this.forums;
/*     */   }
/*     */ 
/*     */   public String getFeedTitle()
/*     */   {
/*  90 */     List args = new ArrayList();
/*  91 */     args.add(SkinUtils.getCommunityName());
/*     */ 
/*  93 */     if (this.forumList.size() > 1) {
/*  94 */       return LocaleUtils.getLocalizedString("rss.forums_multiple", getLocale(), args);
/*     */     }
/*     */ 
/*  97 */     Forum forum = (Forum)this.forumList.get(0);
/*  98 */     args.add(forum.getName());
/*  99 */     return LocaleUtils.getLocalizedString("rss.forums_single", getLocale(), args);
/*     */   }
/*     */ 
/*     */   public String executeRSS()
/*     */   {
/* 106 */     setFullListingEnabled(JiveGlobals.getJiveBooleanProperty("rss.fullForumListingEnabled", true));
/*     */     try
/*     */     {
/* 111 */       ForumFactory forumFactory = ForumFactory.getInstance(getAuthToken());
/* 112 */       this.forumList = new ArrayList();
/*     */ 
/* 116 */       if (this.forumIDs != null) {
/* 117 */         StringTokenizer tokens = new StringTokenizer(this.forumIDs, ",");
/* 118 */         while (tokens.hasMoreTokens()) {
/* 119 */           long forumID = Long.parseLong(tokens.nextToken());
/*     */           try {
/* 121 */             Forum forum = forumFactory.getForum(forumID);
/* 122 */             if (!this.forumList.contains(forum))
/* 123 */               this.forumList.add(forum);
/*     */           }
/*     */           catch (ForumNotFoundException e)
/*     */           {
/* 127 */             addFieldError("forumNotFound", String.valueOf(forumID));
/* 128 */             return "error";
/*     */           }
/*     */           catch (UnauthorizedException e) {
/* 131 */             return "unauthorized";
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 136 */       if (this.categoryIDs != null) {
/* 137 */         StringTokenizer tokens = new StringTokenizer(this.categoryIDs, ",");
/* 138 */         while (tokens.hasMoreTokens()) {
/* 139 */           long categoryID = Long.parseLong(tokens.nextToken());
/*     */           try {
/* 141 */             ForumCategory category = forumFactory.getForumCategory(categoryID);
/* 142 */             Iterator iter = category.getRecursiveForums();
/* 143 */             while (iter.hasNext()) {
/* 144 */               Forum forum = (Forum)iter.next();
/* 145 */               if (!this.forumList.contains(forum))
/* 146 */                 this.forumList.add(forum);
/*     */             }
/*     */           }
/*     */           catch (ForumCategoryNotFoundException e)
/*     */           {
/* 151 */             addFieldError("categoryNotFound", String.valueOf(categoryID));
/* 152 */             return "error";
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 158 */       if ((this.forumIDs == null) && (this.categoryIDs == null) && (isFullListingEnabled())) {
/* 159 */         Iterator iter = forumFactory.getRootForumCategory().getRecursiveForums();
/* 160 */         while (iter.hasNext()) {
/* 161 */           this.forumList.add(iter.next());
/*     */         }
/*     */       }
/* 164 */       this.forums = this.forumList.iterator();
/*     */     }
/*     */     catch (Exception e) {
/* 167 */       return "error";
/*     */     }
/*     */ 
/* 170 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.rss.RSSForums
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.opensymphony.util.TextUtils;
/*    */ 
/*    */ public class PollOption
/*    */ {
/*    */   private String option;
/*    */ 
/*    */   public PollOption()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PollOption(String option)
/*    */   {
/* 24 */     this.option = option;
/*    */   }
/*    */ 
/*    */   public String getOption() {
/* 28 */     return this.option;
/*    */   }
/*    */ 
/*    */   public void setOption(String option) {
/* 32 */     this.option = option;
/*    */   }
/*    */ 
/*    */   public boolean validate() {
/* 36 */     return TextUtils.stringSet(this.option);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PollOption
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.ForumMessage;
/*    */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*    */ import com.jivesoftware.forum.Query;
/*    */ 
/*    */ public class Click extends ForumActionSupport
/*    */ {
/* 23 */   private long searchID = -1L;
/* 24 */   private long messageID = -1L;
/*    */ 
/*    */   public long getSearchID() {
/* 27 */     return this.searchID;
/*    */   }
/*    */ 
/*    */   public void setSearchID(long searchID) {
/* 31 */     this.searchID = searchID;
/*    */   }
/*    */ 
/*    */   public long getMessageID() {
/* 35 */     return this.messageID;
/*    */   }
/*    */ 
/*    */   public void setMessageID(long messageID) {
/* 39 */     this.messageID = messageID;
/*    */   }
/*    */ 
/*    */   public ForumMessage getMessage() {
/* 43 */     if (this.messageID > -1L) {
/*    */       try {
/* 45 */         return getForumFactory().getMessage(this.messageID);
/*    */       }
/*    */       catch (ForumMessageNotFoundException e) {
/* 48 */         Log.error(e);
/*    */       }
/*    */       catch (UnauthorizedException e) {
/* 51 */         Log.error(e);
/*    */       }
/*    */     }
/* 54 */     return null;
/*    */   }
/*    */ 
/*    */   public String execute() {
/* 58 */     if ((this.searchID > -1L) && (this.messageID > -1L))
/*    */     {
/* 60 */       Query q = getForumFactory().createQuery();
/* 61 */       q.logSearchClick(this.searchID, this.messageID);
/*    */     }
/* 63 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.Click
 * JD-Core Version:    0.6.2
 */
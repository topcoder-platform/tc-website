package com.jivesoftware.forum.database;

public class ForumFilterType
{
  public static final long PROPERTY = 4L;
  public static final long SUBJECT = 8L;
  public static final long BODY = 16L;
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.ForumFilterType
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.action.JiveObjectLoader;
/*     */ import com.jivesoftware.base.action.util.RedirectAction;
/*     */ import com.jivesoftware.forum.AnnouncementManager;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.action.util.Pageable;
/*     */ import com.opensymphony.webwork.ServletActionContext;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ForumCategoryAction extends ForumActionSupport
/*     */   implements Pageable, JiveObjectLoader
/*     */ {
/*  33 */   private long categoryID = 0L;
/*     */   private Integer start;
/*     */   private ForumCategory category;
/*     */   private ResultFilter resultFilter;
/*     */   private ResultFilter messageResultFilter;
/*     */   private String threadMode;
/*     */ 
/*     */   public long getCategoryID()
/*     */   {
/*  49 */     return this.categoryID;
/*     */   }
/*     */ 
/*     */   public void setCategoryID(long categoryID)
/*     */   {
/*  57 */     this.categoryID = categoryID;
/*     */   }
/*     */ 
/*     */   public int getStart()
/*     */   {
/*  70 */     int val = this.start != null ? this.start.intValue() : 0;
/*  71 */     return val < 0 ? 0 : val;
/*     */   }
/*     */ 
/*     */   public void setStart(int start)
/*     */   {
/*  79 */     this.start = new Integer(start);
/*     */   }
/*     */ 
/*     */   public ForumCategory getCategory()
/*     */   {
/*  89 */     return this.category;
/*     */   }
/*     */ 
/*     */   public int getTotalItemCount()
/*     */   {
/*  99 */     return this.category.getThreadCount(getResultFilter());
/*     */   }
/*     */ 
/*     */   public ResultFilter getResultFilter()
/*     */   {
/* 113 */     return this.resultFilter;
/*     */   }
/*     */ 
/*     */   protected void setResultFilter(ResultFilter resultFilter)
/*     */   {
/* 122 */     this.resultFilter = resultFilter;
/*     */   }
/*     */ 
/*     */   public ResultFilter getMessageResultFilter()
/*     */   {
/* 135 */     if (this.messageResultFilter == null) {
/* 136 */       this.messageResultFilter = ResultFilter.createDefaultMessageFilter();
/* 137 */       this.messageResultFilter.setStartIndex(getStart());
/* 138 */       int messageRange = JiveGlobals.getJiveIntProperty("skin.default.defaultMessagesPerPage", 15);
/* 139 */       if (getPageUser() == null)
/*     */         try {
/* 141 */           messageRange = Integer.parseInt(getGuestProperty("jiveMessageRange"));
/*     */         }
/*     */         catch (Exception ignored) {
/*     */         }
/*     */       else try {
/* 146 */           messageRange = Integer.parseInt(getPageUser().getProperty("jiveMessageRange"));
/*     */         }
/*     */         catch (Exception ignored) {
/*     */         } this.messageResultFilter.setNumResults(messageRange);
/*     */     }
/* 151 */     return this.messageResultFilter;
/*     */   }
/*     */ 
/*     */   public String getThreadMode() {
/* 155 */     if (this.threadMode == null) {
/* 156 */       String threadModeProp = JiveGlobals.getJiveProperty("skin.default.threadMode", "success-flat");
/*     */ 
/* 160 */       User user = getPageUser();
/* 161 */       if ((user != null) && (JiveGlobals.getJiveBooleanProperty("skin.default.usersChooseThreadMode", false)))
/*     */       {
/* 164 */         if (user.getProperty("jiveThreadMode") != null) {
/* 165 */           threadModeProp = user.getProperty("jiveThreadMode");
/*     */         }
/*     */       }
/* 168 */       if ("threaded".equals(threadModeProp)) {
/* 169 */         this.threadMode = "success-threaded";
/*     */       }
/* 171 */       else if ("tree".equals(threadModeProp)) {
/* 172 */         this.threadMode = "success-tree";
/*     */       }
/*     */       else {
/* 175 */         this.threadMode = "success-flat";
/*     */       }
/*     */     }
/* 178 */     return this.threadMode;
/*     */   }
/*     */ 
/*     */   public Iterator getThreads()
/*     */   {
/* 189 */     return this.category.getThreads(getResultFilter());
/*     */   }
/*     */ 
/*     */   public Iterator getAnnouncements()
/*     */   {
/* 197 */     boolean annEnabled = JiveGlobals.getJiveBooleanProperty("announcements.enabled", true);
/* 198 */     if (annEnabled) {
/* 199 */       return getForumFactory().getAnnouncementManager().getAnnouncements(getCategory());
/*     */     }
/*     */ 
/* 202 */     return Collections.EMPTY_LIST.iterator();
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 221 */     if (this.start == null) {
/* 222 */       Integer val = (Integer)ActionContext.getContext().getSession().get("jive.category." + this.categoryID + ".start");
/*     */ 
/* 224 */       this.start = (val != null ? val : this.start);
/*     */     }
/*     */ 
/* 227 */     if (this.start == null) {
/* 228 */       this.start = new Integer(0);
/*     */     }
/*     */ 
/* 231 */     ActionContext.getContext().getSession().put("jive.category." + this.categoryID + ".start", this.start);
/*     */ 
/* 234 */     this.resultFilter = ResultFilter.createDefaultThreadFilter();
/* 235 */     this.resultFilter.setStartIndex(this.start.intValue());
/* 236 */     int threadRange = JiveGlobals.getJiveIntProperty("skin.default.defaultThreadsPerPage", 15);
/* 237 */     if (getPageUser() == null)
/*     */       try {
/* 239 */         threadRange = Integer.parseInt(getGuestProperty("jiveThreadRange"));
/*     */       }
/*     */       catch (Exception ignored) {
/*     */       }
/*     */     else try {
/* 244 */         threadRange = Integer.parseInt(getPageUser().getProperty("jiveThreadRange"));
/*     */       }
/*     */       catch (Exception ignored) {
/*     */       } this.resultFilter.setNumResults(threadRange);
/*     */ 
/* 250 */     RedirectAction.pushPreviousURL(ServletActionContext.getRequest());
/*     */ 
/* 252 */     return "success";
/*     */   }
/*     */ 
/*     */   public String loadObjects()
/*     */     throws Exception
/*     */   {
/* 258 */     if (this.categoryID <= 0L) {
/* 259 */       this.categoryID = getForumFactory().getRootForumCategory().getID();
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 264 */       this.category = getForumFactory().getForumCategory(this.categoryID);
/* 265 */       return "success";
/*     */     }
/*     */     catch (ForumCategoryNotFoundException e) {
/* 268 */       addFieldError("categoryID", String.valueOf(this.categoryID));
/* 269 */     }return "notfound";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.ForumCategoryAction
 * JD-Core Version:    0.6.2
 */
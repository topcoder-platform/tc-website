/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class NoGroupSelectedException extends NNTPException
/*    */ {
/*    */   private static final int CODE = 412;
/* 23 */   private static final NNTPResponse RESPONSE = new StaticNNTPResponse(412, "no newsgroup has been selected");
/*    */ 
/*    */   public NoGroupSelectedException()
/*    */   {
/* 30 */     this.response = RESPONSE;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NoGroupSelectedException
 * JD-Core Version:    0.6.2
 */
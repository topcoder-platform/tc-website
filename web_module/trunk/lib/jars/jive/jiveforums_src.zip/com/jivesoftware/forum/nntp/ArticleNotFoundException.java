/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class ArticleNotFoundException extends NNTPException
/*    */ {
/*    */   private static final int CODE = 430;
/* 29 */   private static final NNTPResponse RESPONSE = new StaticNNTPResponse(430, "no such article found");
/*    */ 
/*    */   public ArticleNotFoundException()
/*    */   {
/* 37 */     this.response = RESPONSE;
/*    */   }
/*    */ 
/*    */   public ArticleNotFoundException(String message)
/*    */   {
/* 48 */     super(message);
/* 49 */     this.response = new StaticNNTPResponse(430, message);
/*    */   }
/*    */ 
/*    */   public ArticleNotFoundException(Throwable cause)
/*    */   {
/* 62 */     super(cause);
/* 63 */     this.response = RESPONSE;
/*    */   }
/*    */ 
/*    */   public ArticleNotFoundException(String message, Throwable cause)
/*    */   {
/* 77 */     super(message, cause);
/* 78 */     this.response = new StaticNNTPResponse(430, message);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.ArticleNotFoundException
 * JD-Core Version:    0.6.2
 */
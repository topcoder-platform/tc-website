/*     */ package com.jivesoftware.forum.interceptor;
/*     */ 
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.MessageInterceptor;
/*     */ import com.jivesoftware.forum.MessageRejectedException;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.DefaultCache;
/*     */ import com.jivesoftware.util.StringUtils;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class GovernorInterceptor
/*     */   implements MessageInterceptor
/*     */ {
/*  34 */   private static final Pattern MSG_FORMAT_TOKEN = Pattern.compile(".*\\{[0-9]*\\}.*");
/*     */ 
/*  36 */   private int postInterval = 30;
/*  37 */   private String rejectionMessage = "Not allowed to post messages more than once every {0} seconds.";
/*     */   private Cache postLimitCache;
/*     */ 
/*     */   public GovernorInterceptor()
/*     */   {
/*     */   }
/*     */ 
/*     */   public GovernorInterceptor(int objectType, long objectID)
/*     */   {
/*  67 */     String cacheName = objectType + "-" + objectID + "-postLimitCache";
/*  68 */     this.postLimitCache = new DefaultCache(cacheName, 10240, this.postInterval * 1000L);
/*     */   }
/*     */ 
/*     */   public int getPostInterval()
/*     */   {
/*  79 */     return this.postInterval;
/*     */   }
/*     */ 
/*     */   public void setPostInterval(int postInterval)
/*     */   {
/*  89 */     this.postInterval = postInterval;
/*  90 */     if (postInterval > 1) {
/*  91 */       this.postLimitCache.setMaxLifetime(postInterval * 1000L);
/*     */     }
/*     */     else {
/*  94 */       this.postLimitCache.setMaxLifetime(0L);
/*  95 */       this.postInterval = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getRejectionMessage()
/*     */   {
/* 109 */     return this.rejectionMessage;
/*     */   }
/*     */ 
/*     */   public void setRejectionMessage(String rejectionMessage)
/*     */   {
/* 122 */     this.rejectionMessage = rejectionMessage;
/*     */   }
/*     */ 
/*     */   public int getType() {
/* 126 */     return 0;
/*     */   }
/*     */ 
/*     */   public void invokeInterceptor(ForumMessage message, int type) throws MessageRejectedException
/*     */   {
/* 131 */     if (message.isAnonymous()) {
/* 132 */       return;
/*     */     }
/* 134 */     Long userID = new Long(message.getUser().getID());
/*     */ 
/* 138 */     if (this.postLimitCache.containsKey(userID))
/*     */     {
/* 141 */       String rejectMsg = this.rejectionMessage;
/* 142 */       if (MSG_FORMAT_TOKEN.matcher(this.rejectionMessage).matches()) {
/* 143 */         rejectMsg = StringUtils.replace(rejectMsg, "'", "''");
/*     */       }
/* 145 */       rejectMsg = MessageFormat.format(rejectMsg, (Object[])new String[] { Integer.toString(this.postInterval) });
/*     */ 
/* 147 */       throw new MessageRejectedException(rejectMsg, message);
/*     */     }
/*     */ 
/* 153 */     this.postLimitCache.put(userID, userID);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.GovernorInterceptor
 * JD-Core Version:    0.6.2
 */
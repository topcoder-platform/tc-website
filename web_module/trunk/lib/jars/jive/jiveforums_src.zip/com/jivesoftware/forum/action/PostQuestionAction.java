/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.Question;
/*     */ import com.jivesoftware.forum.Question.State;
/*     */ import com.jivesoftware.forum.QuestionManager;
/*     */ 
/*     */ public class PostQuestionAction extends PostAction
/*     */ {
/*     */   private Boolean ansQuestion;
/*     */ 
/*     */   public Boolean getAnsQuestion()
/*     */   {
/*  37 */     return this.ansQuestion;
/*     */   }
/*     */ 
/*     */   public void setAnsQuestion(Boolean ansQuestion) {
/*  41 */     this.ansQuestion = ansQuestion;
/*     */   }
/*     */ 
/*     */   public QuestionManager getQuestionManager() {
/*  45 */     return getForumFactory().getQuestionManager();
/*     */   }
/*     */ 
/*     */   protected void validate() {
/*  49 */     super.validate();
/*     */ 
/*  51 */     if ((isReply()) && (isAuthor(getThread().getRootMessage())) && 
/*  52 */       (getQuestionManager().hasQuestion(getThread())))
/*     */       try {
/*  54 */         Question question = getQuestionManager().getQuestion(getThread());
/*  55 */         if ((question.getState() != Question.State.resolved) && 
/*  56 */           (this.ansQuestion == null))
/*  57 */           addFieldError("ansQuestion", "");
/*     */       }
/*     */       catch (NotFoundException e)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*  67 */     String result = super.doDefault();
/*     */ 
/*  69 */     if (getFrom() == null) {
/*  70 */       setMarkAsQuestion(JiveGlobals.getJiveBooleanProperty("questions.markThreadAsQuestionByDefault", false));
/*     */     }
/*     */ 
/*  73 */     return result;
/*     */   }
/*     */ 
/*     */   public String execute() {
/*  77 */     String result = super.execute();
/*  78 */     if ((result.startsWith("success")) && (!isGuest()) && 
/*  79 */       (isAuthor(getThread().getRootMessage()))) {
/*  80 */       if (!isReply())
/*     */       {
/*  83 */         if (isMarkAsQuestion()) {
/*  84 */           QuestionManager qman = getForumFactory().getQuestionManager();
/*     */           try {
/*  86 */             qman.createQuestion(getThread());
/*     */           }
/*     */           catch (UnauthorizedException e) {
/*  89 */             Log.error(e);
/*  90 */             return "unauthorized";
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*  95 */       else if (getQuestionManager().hasQuestion(getThread())) {
/*     */         try
/*     */         {
/*  98 */           Question question = getForumFactory().getQuestionManager().getQuestion(getThread());
/*     */ 
/* 100 */           Question.State currentState = question.getState();
/*     */ 
/* 102 */           if (Boolean.TRUE == getAnsQuestion()) {
/* 103 */             if (currentState != Question.State.resolved) {
/* 104 */               question.setState(Question.State.resolved);
/*     */             }
/*     */           }
/* 107 */           else if ((Boolean.FALSE == getAnsQuestion()) && 
/* 108 */             (currentState != Question.State.open)) {
/* 109 */             question.setState(Question.State.open);
/*     */           }
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 114 */           Log.error(e);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 120 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PostQuestionAction
 * JD-Core Version:    0.6.2
 */
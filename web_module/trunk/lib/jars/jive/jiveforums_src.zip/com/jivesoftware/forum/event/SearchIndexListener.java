package com.jivesoftware.forum.event;

public abstract interface SearchIndexListener
{
  public abstract void messageAdded(SearchIndexEvent paramSearchIndexEvent);

  public abstract void messageDeleted(SearchIndexEvent paramSearchIndexEvent);

  public abstract void rebuildStarted(SearchIndexEvent paramSearchIndexEvent);

  public abstract void rebuildCompleted(SearchIndexEvent paramSearchIndexEvent);

  public abstract void updateStarted(SearchIndexEvent paramSearchIndexEvent);

  public abstract void updateCompleted(SearchIndexEvent paramSearchIndexEvent);

  public abstract void optimizeStarted(SearchIndexEvent paramSearchIndexEvent);

  public abstract void optimizeCompleted(SearchIndexEvent paramSearchIndexEvent);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.SearchIndexListener
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.gateway;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.util.Semaphore;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import dog.mail.nntp.NNTPStore;
/*     */ import dog.mail.nntp.Newsgroup;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ 
/*     */ public class NewsgroupFailedImportTask
/*     */   implements Runnable
/*     */ {
/*     */   private NewsgroupImporter.NNTPGateway importer;
/*     */   private Forum forum;
/*     */   private long forumID;
/*     */   private List failed;
/*  41 */   private int count = 1;
/*     */ 
/*     */   public NewsgroupFailedImportTask(NewsgroupImporter.NNTPGateway importer, long forumID, List failed) {
/*  44 */     this.importer = importer;
/*  45 */     this.forumID = forumID;
/*  46 */     this.failed = failed;
/*     */   }
/*     */ 
/*     */   public void run() {
/*  50 */     if (this.failed.isEmpty()) {
/*  51 */       return;
/*     */     }
/*     */     try
/*     */     {
/*  55 */       this.forum = DbForumFactory.getInstance().getForum(this.forumID);
/*     */     }
/*     */     catch (ForumNotFoundException e) {
/*  58 */       Log.error(e);
/*  59 */       return;
/*     */     }
/*     */ 
/*  62 */     Log.info("Attempting to import " + this.failed.size() + " message(s) into forum " + this.forum.getName() + " after initial failure. This is attempt #" + this.count);
/*     */ 
/*  65 */     synchronized (NewsgroupImporter.forumLock.get(new Long(this.forumID))) {
/*  66 */       synchronized (NewsgroupImporter.serverSemaphores) {
/*  67 */         if (NewsgroupImporter.serverSemaphores.get(this.importer.getHost()) == null) {
/*  68 */           int maxCons = 3;
/*     */           try {
/*  70 */             String mCon = JiveGlobals.getJiveProperty("gateways.maxConnectionsPerHost");
/*  71 */             maxCons = Integer.parseInt(mCon);
/*     */           }
/*     */           catch (NumberFormatException e) {
/*     */           }
/*  75 */           Semaphore semaphore = new Semaphore(maxCons);
/*  76 */           NewsgroupImporter.serverSemaphores.put(this.importer.getHost(), semaphore);
/*     */         }
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/*  82 */         ((Semaphore)NewsgroupImporter.serverSemaphores.get(this.importer.getHost())).acquire();
/*     */       }
/*     */       catch (InterruptedException e) {
/*  85 */         Log.error(e);
/*     */       }
/*     */       try
/*     */       {
/*  89 */         reimport();
/*     */       }
/*     */       finally
/*     */       {
/*  93 */         ((Semaphore)NewsgroupImporter.serverSemaphores.get(this.importer.getHost())).release();
/*     */       }
/*     */ 
/*  97 */       if ((!this.failed.isEmpty()) && (this.count < 3)) {
/*  98 */         if (this.count == 1) {
/*  99 */           this.count += 1;
/* 100 */           TaskEngine.scheduleTask(this, new Date(System.currentTimeMillis() + 600000L));
/*     */         }
/* 103 */         else if (this.count == 2) {
/* 104 */           this.count += 1;
/* 105 */           TaskEngine.scheduleTask(this, new Date(System.currentTimeMillis() + 1200000L));
/*     */         }
/*     */ 
/*     */       }
/* 109 */       else if (!this.failed.isEmpty()) {
/* 110 */         for (int i = 0; i < this.failed.size(); i++) {
/* 111 */           String messageID = (String)this.failed.get(i);
/* 112 */           Log.error("Unable to import message with id " + messageID + "into forum " + this.forum.getName() + ", after 3 attempts. No more attempts will be made.");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 117 */       this.importer.parentMessageIDs.clear();
/* 118 */       this.importer.failedMessageIDs.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void reimport() {
/* 123 */     NNTPStore store = null;
/* 124 */     Newsgroup folder = null;
/*     */     try
/*     */     {
/* 127 */       store = (NNTPStore)this.importer.getStore(new Date(0L));
/*     */     }
/*     */     catch (MessagingException e)
/*     */     {
/* 131 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 135 */       folder = (Newsgroup)this.importer.getFolder(store);
/* 136 */       importMessages(store, folder);
/*     */     }
/*     */     catch (MessagingException e) {
/* 139 */       Log.error(e);
/*     */     } finally {
/*     */       try {
/* 142 */         folder.close(false);
/*     */       } catch (Exception e) {
/* 144 */         Log.error("Unable to close folder when importing into forum \"" + this.forum.getName() + "\", Reason: " + e.getMessage());
/*     */       }
/*     */       try {
/* 147 */         store.close();
/*     */       } catch (Exception e) {
/* 149 */         Log.error("Unable to close store when importing into forum \"" + this.forum.getName() + "\", Reason: " + e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void importMessages(NNTPStore store, Newsgroup folder)
/*     */   {
/*     */     try {
/* 157 */       for (int i = 0; i < this.failed.size(); i++) {
/* 158 */         String messageID = (String)this.failed.get(i);
/*     */ 
/* 160 */         if (messageID == null) {
/* 161 */           Log.info("Unable to import previously failed message since we couldn't retrieve a messageID. This is common if a network connection completely fails and shouldn't be an issue as the gateway should restart from where it previously left off.");
/*     */ 
/* 165 */           this.failed.remove(i);
/* 166 */           i--;
/*     */         }
/*     */         else
/*     */         {
/* 170 */           Log.info("Attempting to import previously failed message with ID " + messageID + " into forum " + this.forum.getName());
/*     */           try
/*     */           {
/* 176 */             if ((!folder.isOpen()) || (!store.isConnected())) {
/* 177 */               Log.warn("Javamail server has disconnected, reconnecting...");
/*     */               try {
/* 179 */                 folder.close(false); } catch (Exception e) {
/*     */               }try {
/* 181 */                 store.close();
/*     */               } catch (Exception e) {
/*     */               }
/* 184 */               int retry = 1;
/* 185 */               while ((!store.isConnected()) && (retry < 4)) {
/* 186 */                 retry++;
/* 187 */                 store = (NNTPStore)this.importer.getStore(new Date(0L));
/* 188 */                 folder = (Newsgroup)this.importer.getFolder(store);
/*     */               }
/*     */ 
/* 192 */               if ((!store.isConnected()) && (retry > 3)) {
/* 193 */                 Log.error("Unable to connect to the JavaMail store provider during reimport attempt into forum " + this.forum.getName());
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/* 199 */             MimeMessage message = store.getArticle(folder, messageID);
/* 200 */             ForumMessage forumMessage = this.importer.parseMessage(message, new Date(0L));
/*     */ 
/* 203 */             if (forumMessage == null) {
/* 204 */               Log.error("Parsing of message " + messageID + " failed.");
/*     */             }
/*     */             else
/*     */             {
/* 211 */               ForumMessage dbMessage = this.importer.lookupMessageByID(this.forum, messageID, true);
/*     */ 
/* 213 */               if ((dbMessage != null) && (!"true".equals(dbMessage.getUnfilteredProperty("Jive-Created-Message"))))
/*     */               {
/* 216 */                 Log.info("Not importing previously failed message with ID " + messageID + " into forum " + this.forum.getName() + " since it now exists in " + "the database. This is likely because another import session has " + "imported the message.");
/*     */ 
/* 220 */                 this.failed.remove(messageID);
/* 221 */                 i--;
/*     */               }
/*     */               else
/*     */               {
/* 225 */                 List messages = new ArrayList();
/* 226 */                 messages.add(forumMessage);
/* 227 */                 this.importer.processMessagesAndImport(messages);
/*     */ 
/* 229 */                 if ((this.importer.isMessageWithAttachments(message)) && (this.importer.attachmentsEnabled))
/*     */                 {
/* 232 */                   forumMessage = this.importer.lookupMessageByID(this.forum, messageID, false);
/*     */ 
/* 234 */                   if (forumMessage != null)
/*     */                   {
/* 239 */                     if (forumMessage.getAttachmentCount() < 1) {
/*     */                       try {
/* 241 */                         this.importer.addAttachments(forumMessage, message);
/*     */                       }
/*     */                       catch (MessagingException e) {
/* 244 */                         Log.error(e);
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                   else {
/* 249 */                     Log.warn("Message which should be in the db wasn't: " + messageID);
/*     */                   }
/*     */                 }
/*     */ 
/* 253 */                 Log.info("Successfully imported previously failed message with ID " + messageID + " into forum " + this.forum.getName());
/*     */ 
/* 255 */                 this.failed.remove(messageID);
/* 256 */                 i--;
/*     */               }
/*     */             }
/*     */           } catch (MessagingException e) { Log.error("An unhandled error occurred importing previously failed messages into forum \"" + this.forum.getName() + "\", stack trace follows", e); }
/*     */ 
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (ForumNotFoundException e)
/*     */     {
/* 266 */       Log.error(e);
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 269 */       Log.error(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.NewsgroupFailedImportTask
 * JD-Core Version:    0.6.2
 */
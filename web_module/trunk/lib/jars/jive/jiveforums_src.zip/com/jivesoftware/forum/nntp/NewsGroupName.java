/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class NewsGroupName
/*    */ {
/*    */   private String name;
/* 29 */   private String[] split = null;
/*    */ 
/*    */   public NewsGroupName(String groupName)
/*    */   {
/* 37 */     this.name = groupName;
/*    */   }
/*    */ 
/*    */   public boolean isInDistribution(NewsGroupName distribution)
/*    */   {
/* 51 */     return this.name.startsWith(distribution.name);
/*    */   }
/*    */ 
/*    */   public String[] toStringParts()
/*    */   {
/* 61 */     if (this.split == null) {
/* 62 */       this.split = this.name.split("\\.");
/*    */     }
/* 64 */     return this.split;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 68 */     return this.name;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 72 */     return this.name.hashCode();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NewsGroupName
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.action.util;
/*     */ 
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Paginator
/*     */ {
/*     */   private Pageable pageable;
/*     */   private Page[] pages;
/*  42 */   private int numPages = -1;
/*     */ 
/*     */   public Paginator(Pageable pageable)
/*     */   {
/*  52 */     this.pageable = pageable;
/*     */   }
/*     */ 
/*     */   public int getNumPages()
/*     */   {
/*  63 */     if (this.numPages == -1) {
/*  64 */       int totalItemCount = this.pageable.getTotalItemCount();
/*  65 */       int numResults = this.pageable.getResultFilter().getNumResults();
/*  66 */       this.numPages = ((int)Math.ceil(totalItemCount / numResults));
/*     */     }
/*  68 */     return this.numPages;
/*     */   }
/*     */ 
/*     */   public Pageable getPageable()
/*     */   {
/*  78 */     return this.pageable;
/*     */   }
/*     */ 
/*     */   public int getStart()
/*     */   {
/*  87 */     return this.pageable.getStart();
/*     */   }
/*     */ 
/*     */   public int getRange()
/*     */   {
/*  97 */     return this.pageable.getResultFilter().getNumResults();
/*     */   }
/*     */ 
/*     */   public int getPageIndex()
/*     */   {
/* 106 */     ResultFilter filter = this.pageable.getResultFilter();
/* 107 */     if (filter.getNumResults() == 0) {
/* 108 */       return 0;
/*     */     }
/* 110 */     return this.pageable.getStart() / filter.getNumResults();
/*     */   }
/*     */ 
/*     */   public boolean getPreviousPage()
/*     */   {
/* 119 */     return getPageIndex() > 0;
/*     */   }
/*     */ 
/*     */   public int getPreviousPageStart()
/*     */   {
/* 131 */     return (getPageIndex() - 1) * this.pageable.getResultFilter().getNumResults();
/*     */   }
/*     */ 
/*     */   public boolean getNextPage()
/*     */   {
/* 140 */     return getPageIndex() + 1 < getNumPages();
/*     */   }
/*     */ 
/*     */   public int getNextPageStart()
/*     */   {
/* 152 */     return (getPageIndex() + 1) * this.pageable.getResultFilter().getNumResults();
/*     */   }
/*     */ 
/*     */   public Page[] getPages()
/*     */   {
/* 163 */     return getPages(10);
/*     */   }
/*     */ 
/*     */   public Page[] getPages(int numViewablePages)
/*     */   {
/* 183 */     if (this.pages == null)
/*     */     {
/* 185 */       int numResults = this.pageable.getResultFilter().getNumResults();
/*     */ 
/* 188 */       int pageCount = getNumPages();
/*     */ 
/* 190 */       int startIndex = getPageIndex();
/* 191 */       int maxPages = pageCount < numViewablePages ? pageCount : numViewablePages;
/* 192 */       List pageList = new ArrayList(maxPages);
/*     */ 
/* 194 */       for (int i = 0; i < maxPages; i++) {
/* 195 */         Page page = new Page();
/* 196 */         page.setNumber(i + startIndex + 1);
/* 197 */         page.setStart((i + startIndex) * numResults);
/* 198 */         pageList.add(page);
/*     */ 
/* 201 */         if (i + startIndex + 2 > pageCount)
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*     */ 
/* 207 */       if (pageList.size() > 0) {
/* 208 */         Page lowestPage = (Page)pageList.get(0);
/* 209 */         while ((pageList.size() < maxPages) && (lowestPage.getStart() != 0)) {
/* 210 */           Page page = Page.getPrev(lowestPage, numResults);
/* 211 */           pageList.add(0, page);
/* 212 */           lowestPage = page;
/*     */         }
/*     */ 
/* 215 */         int count = 2;
/* 216 */         while ((count-- > 0) && (lowestPage.getStart() != 0)) {
/* 217 */           Page page = Page.getPrev(lowestPage, numResults);
/* 218 */           pageList.add(0, page);
/* 219 */           lowestPage = page;
/* 220 */           if ((count == 0) && (lowestPage.getNumber() == 2)) {
/* 221 */             count++;
/*     */           }
/*     */         }
/*     */ 
/* 225 */         if (lowestPage.getNumber() - 1 >= 2) {
/* 226 */           pageList.add(0, null);
/* 227 */           pageList.add(0, Page.FIRST);
/*     */         }
/*     */       }
/* 230 */       this.pages = ((Page[])pageList.toArray(new Page[0]));
/*     */     }
/* 232 */     return this.pages;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.util.Paginator
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.gateway;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.util.Semaphore;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import dog.mail.nntp.NNTPStore;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Store;
/*     */ import javax.mail.URLName;
/*     */ 
/*     */ public class NewsgroupImporter
/*     */   implements GatewayImporter
/*     */ {
/*     */   protected NNTPGateway gateway;
/*  34 */   private int previousLastMessageNumberSeen = -1;
/*  35 */   private int lastMessageNumberSeen = -1;
/*     */   public static final String GATEWAY_MESSAGE_ID = "NNTP-Message-ID";
/*     */   public static final String GATEWAY_PARENT_ID = "NNTP-Parent-ID";
/*  52 */   private static final SimpleDateFormat DATEFORMATTER = new SimpleDateFormat("yyyy.MM.dd hh:mm:ss");
/*     */ 
/*  55 */   protected static Map forumLock = Collections.synchronizedMap(new HashMap());
/*  56 */   protected static Map serverSemaphores = Collections.synchronizedMap(new HashMap());
/*     */ 
/*     */   public NewsgroupImporter(ForumFactory factory, Forum forum)
/*     */   {
/*  62 */     this.gateway = new NNTPGateway(factory, forum);
/*     */ 
/*  64 */     synchronized (forumLock) {
/*  65 */       if (forumLock.get(new Long(this.gateway.forumID)) == null)
/*  66 */         forumLock.put(new Long(this.gateway.forumID), new Long(this.gateway.forumID));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void importData(Date afterDate)
/*     */     throws GatewayException
/*     */   {
/*  74 */     synchronized (forumLock.get(new Long(this.gateway.forumID))) {
/*  75 */       synchronized (serverSemaphores) {
/*  76 */         if (serverSemaphores.get(this.gateway.host) == null) {
/*  77 */           int maxCons = 3;
/*     */           try {
/*  79 */             String mCon = JiveGlobals.getJiveProperty("gateways.maxConnectionsPerHost");
/*  80 */             maxCons = Integer.parseInt(mCon);
/*     */           }
/*     */           catch (NumberFormatException e) {
/*     */           }
/*  84 */           Semaphore semaphore = new Semaphore(maxCons);
/*  85 */           serverSemaphores.put(this.gateway.host, semaphore);
/*     */         }
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/*  91 */         ((Semaphore)serverSemaphores.get(this.gateway.host)).acquire();
/*     */       }
/*     */       catch (InterruptedException e) {
/*  94 */         Log.error(e);
/*     */       }
/*     */       try
/*     */       {
/*  98 */         this.gateway.importData(afterDate);
/*     */       }
/*     */       finally
/*     */       {
/* 102 */         ((Semaphore)serverSemaphores.get(this.gateway.host)).release();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stop() throws GatewayException {
/* 108 */     this.gateway.stop();
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 119 */     return this.gateway.getUsername();
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 128 */     if ("".equals(username)) {
/* 129 */       username = null;
/*     */     }
/* 131 */     this.gateway.setUsername(username);
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 141 */     return this.gateway.getPassword();
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 151 */     if ("".equals(password)) {
/* 152 */       password = null;
/*     */     }
/* 154 */     this.gateway.setPassword(password);
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 165 */     return this.gateway.getPort();
/*     */   }
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 176 */     this.gateway.setPort(port);
/*     */ 
/* 179 */     this.gateway.session = null;
/*     */   }
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 189 */     return this.gateway.getHost();
/*     */   }
/*     */ 
/*     */   public void setHost(String host)
/*     */   {
/* 199 */     this.gateway.setHost(host);
/*     */ 
/* 202 */     this.gateway.session = null;
/*     */   }
/*     */ 
/*     */   public String getNewsgroup()
/*     */   {
/* 211 */     return this.gateway.getMailbox();
/*     */   }
/*     */ 
/*     */   public void setNewsgroup(String newsgroup)
/*     */   {
/* 220 */     this.gateway.setMailbox(newsgroup);
/*     */ 
/* 223 */     this.gateway.session = null;
/*     */   }
/*     */ 
/*     */   public String getTemporaryParentBody()
/*     */   {
/* 245 */     return this.gateway.getTemporaryParentBody();
/*     */   }
/*     */ 
/*     */   public void setTemporaryParentBody(String temporaryParentBody)
/*     */   {
/* 267 */     this.gateway.setTemporaryParentBody(temporaryParentBody);
/*     */   }
/*     */ 
/*     */   public boolean isDebugEnabled()
/*     */   {
/* 277 */     return this.gateway.isDebugEnabled();
/*     */   }
/*     */ 
/*     */   public void setDebugEnabled(boolean debugEnabled)
/*     */   {
/* 287 */     this.gateway.setDebugEnabled(debugEnabled);
/*     */ 
/* 290 */     this.gateway.session = null;
/*     */   }
/*     */ 
/*     */   public void setLastMessageNumberSeen(int messageNumber)
/*     */   {
/* 304 */     if (messageNumber > 0)
/* 305 */       this.lastMessageNumberSeen = messageNumber;
/*     */   }
/*     */ 
/*     */   public int getLastMessageNumberSeen()
/*     */   {
/* 321 */     return this.lastMessageNumberSeen;
/*     */   }
/*     */ 
/*     */   public boolean isAttachmentsEnabled()
/*     */   {
/* 330 */     return this.gateway.isAttachmentsEnabled();
/*     */   }
/*     */ 
/*     */   public void setAttachmentsEnabled(boolean attachmentsEnabled)
/*     */   {
/* 342 */     this.gateway.setAttachmentsEnabled(attachmentsEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isEmailToUserMappingEnabled()
/*     */   {
/* 351 */     return this.gateway.isEmailToUserMappingEnabled();
/*     */   }
/*     */ 
/*     */   public void setEmailToUserMappingEnabled(boolean emailToUserMappingEnabled)
/*     */   {
/* 361 */     this.gateway.setEmailToUserMappingEnabled(emailToUserMappingEnabled);
/*     */   }
/*     */ 
/*     */   public boolean isImportHtmlEnabled()
/*     */   {
/* 370 */     return this.gateway.isImportHtmlEnabled();
/*     */   }
/*     */ 
/*     */   public void setImportHtmlEnabled(boolean importHtmlEnabled)
/*     */   {
/* 381 */     this.gateway.setImportHtmlEnabled(importHtmlEnabled);
/*     */   }
/*     */ 
/*     */   public String getDefaultCharacterSet()
/*     */   {
/* 392 */     return this.gateway.defaultCharacterSet;
/*     */   }
/*     */ 
/*     */   public void setDefaultCharacterSet(String defaultCharacterSet)
/*     */   {
/* 403 */     if (defaultCharacterSet != null)
/* 404 */       this.gateway.setDefaultCharacterSet(defaultCharacterSet);
/*     */   }
/*     */ 
/*     */   public String getReplyPrefixes()
/*     */   {
/* 417 */     String prefixes = "";
/* 418 */     String delim = "";
/* 419 */     for (int i = 0; i < this.gateway.replyPrefixes.length; i++) {
/* 420 */       prefixes = prefixes + delim;
/* 421 */       prefixes = prefixes + this.gateway.replyPrefixes[i];
/* 422 */       delim = ",";
/*     */     }
/*     */ 
/* 425 */     return prefixes;
/*     */   }
/*     */ 
/*     */   public void setReplyPrefixes(String replyPrefixes)
/*     */   {
/* 436 */     if (replyPrefixes == null) {
/* 437 */       return;
/*     */     }
/*     */ 
/* 440 */     StringTokenizer st = new StringTokenizer(replyPrefixes, ",");
/* 441 */     ArrayList prefixes = new ArrayList();
/* 442 */     while (st.hasMoreElements()) {
/* 443 */       String prefix = (String)st.nextElement();
/* 444 */       prefixes.add(prefix);
/*     */     }
/*     */ 
/* 447 */     this.gateway.replyPrefixes = ((String[])prefixes.toArray(new String[prefixes.size()]));
/*     */   }
/*     */ 
/*     */   public boolean isSubjectParentageCheckEnabled()
/*     */   {
/* 456 */     return this.gateway.subjectParentageCheckEnabled;
/*     */   }
/*     */ 
/*     */   public void setSubjectParentageCheckEnabled(boolean subjectParentageCheckEnabled)
/*     */   {
/* 466 */     this.gateway.subjectParentageCheckEnabled = subjectParentageCheckEnabled;
/*     */   }
/*     */ 
/*     */   public String getEmptySubject()
/*     */   {
/* 475 */     return this.gateway.emptySubject;
/*     */   }
/*     */ 
/*     */   public void setEmptySubject(String emptySubject)
/*     */   {
/* 484 */     this.gateway.emptySubject = emptySubject;
/*     */   }
/*     */ 
/*     */   protected class NNTPGateway extends JavaMailGateway
/*     */   {
/* 492 */     protected Session session = null;
/*     */ 
/*     */     public NNTPGateway(ForumFactory factory, Forum forum) {
/* 495 */       super(forum);
/* 496 */       setPort(119);
/* 497 */       setProtocol("nntp");
/*     */ 
/* 499 */       this.gatewayMessageId = "NNTP-Message-ID";
/* 500 */       this.gatewayParentId = "NNTP-Parent-ID";
/*     */     }
/*     */ 
/*     */     protected Store getStore(Date afterDate)
/*     */       throws MessagingException
/*     */     {
/* 511 */       if (afterDate == null) {
/* 512 */         afterDate = new Date(0L);
/*     */       }
/*     */ 
/* 515 */       Properties props = new Properties();
/* 516 */       props.put("mail.nntp.useNewNews", "false");
/* 517 */       props.put("mail.nntp.SimpleDateFormat", NewsgroupImporter.DATEFORMATTER.toPattern());
/* 518 */       props.put("mail.nntp.afterDate", NewsgroupImporter.DATEFORMATTER.format(afterDate));
/* 519 */       props.put("mail.nntp.memoryOptimisation", Boolean.TRUE.toString());
/* 520 */       props.put("mail.nntp.checkNewTimeout", "10");
/* 521 */       props.put("mail.store.protocol", "nntp");
/* 522 */       props.put("mail.transport.protocol", "nntp-post");
/* 523 */       if (NewsgroupImporter.this.lastMessageNumberSeen > 0) {
/* 524 */         props.put("mail.nntp.lastArticleIdSeen", String.valueOf(NewsgroupImporter.this.lastMessageNumberSeen));
/* 525 */         NewsgroupImporter.this.previousLastMessageNumberSeen = NewsgroupImporter.this.lastMessageNumberSeen;
/*     */       }
/*     */ 
/* 529 */       this.session = Session.getInstance(props, null);
/* 530 */       this.session.setDebug(this.debugEnabled);
/*     */ 
/* 533 */       URLName url = new URLName(this.protocol, this.host, this.port, this.mailbox, this.username, this.password);
/* 534 */       Store store = new NNTPStore(this.session, url);
/*     */       try
/*     */       {
/* 538 */         store.connect();
/*     */       }
/*     */       catch (MessagingException e) {
/*     */         try {
/* 542 */           Forum forum = this.factory.getForum(this.forumID);
/* 543 */           Log.error("Unable to open NNTP gateway in forum " + forum.getName() + ", Reason: " + e.getMessage());
/*     */ 
/* 545 */           throw e;
/*     */         } catch (ForumNotFoundException e1) {
/*     */         }
/*     */         catch (UnauthorizedException e1) {
/*     */         }
/*     */       }
/* 551 */       return store;
/*     */     }
/*     */ 
/*     */     protected String getMessageID(Message message)
/*     */       throws MessagingException
/*     */     {
/* 558 */       if (message.getMessageNumber() > 0) {
/* 559 */         int messageNumber = message.getMessageNumber();
/* 560 */         if (messageNumber != NewsgroupImporter.this.lastMessageNumberSeen) {
/* 561 */           NewsgroupImporter.this.lastMessageNumberSeen = messageNumber;
/*     */         }
/*     */       }
/*     */ 
/* 565 */       return super.getMessageID(message);
/*     */     }
/*     */ 
/*     */     protected void cleanup()
/*     */     {
/* 579 */       if (this.failedMessageIDs.size() < 2)
/*     */         try {
/* 581 */           GatewayManager gatewayManager = this.factory.getForum(this.forumID).getGatewayManager();
/*     */ 
/* 583 */           for (int i = 0; i < gatewayManager.getGatewayCount(); i++) {
/* 584 */             GatewayImporter gateway = gatewayManager.getGateway(i).getGatewayImporter();
/* 585 */             if ((gateway != null) && ((gateway instanceof NewsgroupImporter))) {
/* 586 */               ((NewsgroupImporter)gateway).setLastMessageNumberSeen(NewsgroupImporter.this.lastMessageNumberSeen);
/*     */             }
/*     */           }
/*     */ 
/* 590 */           gatewayManager.saveGateways(false);
/*     */         }
/*     */         catch (ForumNotFoundException e) {
/*     */         }
/*     */         catch (UnauthorizedException e) {
/*     */         }
/* 596 */       if (!this.failedMessageIDs.isEmpty()) {
/* 597 */         Log.info("Creating task to reattempt import of " + this.failedMessageIDs.size() + " message(s) into forum with ID " + this.forumID);
/*     */ 
/* 604 */         List failed = new ArrayList(this.failedMessageIDs.size());
/* 605 */         for (int i = 0; i < this.failedMessageIDs.size(); i++) {
/* 606 */           failed.add(this.failedMessageIDs.get(i));
/*     */         }
/*     */ 
/* 610 */         NewsgroupFailedImportTask task = new NewsgroupFailedImportTask(this, this.forumID, failed);
/* 611 */         TaskEngine.scheduleTask(task, new Date(System.currentTimeMillis() + 300000L));
/*     */ 
/* 615 */         NewsgroupImporter.this.lastMessageNumberSeen = NewsgroupImporter.this.previousLastMessageNumberSeen;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.NewsgroupImporter
 * JD-Core Version:    0.6.2
 */
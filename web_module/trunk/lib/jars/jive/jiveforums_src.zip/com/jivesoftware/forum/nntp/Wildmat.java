/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class Wildmat
/*     */ {
/*     */   private GroupMatcher matcher;
/*  75 */   private static final Pattern DOT_PATTERN = Pattern.compile("\\.");
/*     */ 
/*  77 */   private static final Pattern STAR_PATTERN = Pattern.compile("\\*");
/*     */ 
/*     */   public Wildmat(String pattern)
/*     */   {
/*  71 */     this.matcher = new GroupMatcher(pattern, null);
/*     */   }
/*     */ 
/*     */   public boolean matches(NewsGroupName name)
/*     */   {
/*  89 */     return this.matcher.matches(name);
/*     */   }
/*     */ 
/*     */   public boolean isNot()
/*     */   {
/*  98 */     return this.matcher.isNot();
/*     */   }
/*     */ 
/*     */   private class GroupMatcher
/*     */   {
/* 108 */     private boolean not = false;
/*     */     private Pattern compiledPattern;
/*     */ 
/*     */     private GroupMatcher(String pattern)
/*     */     {
/* 118 */       if (pattern.charAt(0) == '!') {
/* 119 */         this.not = true;
/* 120 */         pattern = pattern.substring(1);
/*     */       }
/* 122 */       Matcher match = Wildmat.DOT_PATTERN.matcher(pattern);
/* 123 */       pattern = match.replaceAll("\\.");
/* 124 */       match = Wildmat.STAR_PATTERN.matcher(pattern);
/* 125 */       pattern = match.replaceAll(".*");
/* 126 */       this.compiledPattern = Pattern.compile(pattern);
/*     */     }
/*     */ 
/*     */     private boolean isNot()
/*     */     {
/* 135 */       return this.not;
/*     */     }
/*     */ 
/*     */     private boolean matches(NewsGroupName name)
/*     */     {
/* 148 */       Matcher match = this.compiledPattern.matcher(name.toString());
/* 149 */       return match.matches();
/*     */     }
/*     */ 
/*     */     GroupMatcher(String x1, Wildmat.1 x2)
/*     */     {
/* 106 */       this(x1);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.Wildmat
 * JD-Core Version:    0.6.2
 */
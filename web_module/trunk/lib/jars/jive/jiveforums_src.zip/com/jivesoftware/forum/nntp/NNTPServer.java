/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.JiveManager;
/*     */ import com.jivesoftware.base.LicenseException;
/*     */ import com.jivesoftware.base.LicenseManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.forum.net.AcceptManager;
/*     */ import com.jivesoftware.forum.net.AcceptPort;
/*     */ import com.jivesoftware.forum.net.Connection;
/*     */ import com.jivesoftware.forum.net.ConnectionManager;
/*     */ import com.jivesoftware.forum.nntp.spi.NNTPConnectionManager;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class NNTPServer
/*     */   implements JiveManager
/*     */ {
/*  33 */   private static final NNTPServer instance = new NNTPServer();
/*     */ 
/*  36 */   private SessionManager sessionManager = null;
/*     */ 
/*  38 */   private AcceptManager acceptManager = null;
/*     */ 
/*  40 */   private ConnectionManager connectionManager = null;
/*     */ 
/*  42 */   private Date startDate = null;
/*     */ 
/*  44 */   private Date stopDate = null;
/*     */   private NNTPServerConfig serverConfig;
/*     */   private static final String PORTNAME_PREFIX = "nntp.ports";
/*  50 */   private static boolean initialized = false;
/*     */ 
/*     */   public static NNTPServer getInstance()
/*     */   {
/*  58 */     return instance;
/*     */   }
/*     */ 
/*     */   private NNTPServer()
/*     */   {
/*  65 */     this.serverConfig = NNTPServerConfig.getInstance();
/*  66 */     this.sessionManager = SessionManager.getInstance();
/*  67 */     this.connectionManager = new NNTPConnectionManager(this.sessionManager);
/*  68 */     this.acceptManager = new AcceptManager(this.connectionManager, "nntp.ports");
/*     */   }
/*     */ 
/*     */   public synchronized void initialize() {
/*  72 */     if (!initialized) {
/*  73 */       initialized = true;
/*  74 */       if (isNNTPEnabled())
/*     */         try {
/*  76 */           LicenseManager.validateLicense("Jive Forums Enterprise", "4.2");
/*  77 */           startup();
/*     */         }
/*     */         catch (LicenseException le) {
/*  80 */           Log.info("Not allowed to start NNTP server. The NNTP feature requires a validJive Forums Enterprise or better license.");
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public NNTPServerConfig getServerConfig()
/*     */   {
/*  93 */     return this.serverConfig;
/*     */   }
/*     */ 
/*     */   public Date getStartDate()
/*     */     throws IllegalStateException
/*     */   {
/* 103 */     if (this.startDate == null) {
/* 104 */       throw new IllegalStateException();
/*     */     }
/* 106 */     return this.startDate;
/*     */   }
/*     */ 
/*     */   public Date getStopDate()
/*     */   {
/* 117 */     return this.stopDate;
/*     */   }
/*     */ 
/*     */   public SessionManager getSessionManager()
/*     */     throws IllegalStateException
/*     */   {
/* 127 */     return this.sessionManager;
/*     */   }
/*     */ 
/*     */   public ConnectionManager getConnectionManager()
/*     */     throws IllegalStateException
/*     */   {
/* 136 */     return this.connectionManager;
/*     */   }
/*     */ 
/*     */   public AcceptManager getAcceptManager()
/*     */     throws IllegalStateException
/*     */   {
/* 146 */     return this.acceptManager;
/*     */   }
/*     */ 
/*     */   public boolean isRunning()
/*     */   {
/* 159 */     return (this.stopDate == null) && (this.startDate != null);
/*     */   }
/*     */ 
/*     */   private boolean isNNTPEnabled()
/*     */   {
/* 176 */     Boolean databaseValue = getNNTPEnabledDatabaseProperty();
/* 177 */     boolean isSetDb = databaseValue != null;
/*     */ 
/* 180 */     if (isSetDb) {
/* 181 */       JiveGlobals.setLocalProperty("nntp.enabled", databaseValue.toString());
/* 182 */       JiveGlobals.deleteJiveProperty("nntp.enabled");
/*     */     }
/*     */ 
/* 185 */     String value = JiveGlobals.getLocalProperty("nntp.enabled");
/* 186 */     return (value != null) && ("true".equals(value.trim().toLowerCase()));
/*     */   }
/*     */ 
/*     */   public void setNNTPEnabled(boolean enabled)
/*     */   {
/* 196 */     if (enabled == isNNTPEnabled()) {
/* 197 */       return;
/*     */     }
/* 199 */     JiveGlobals.setLocalProperty("nntp.enabled", String.valueOf(enabled));
/* 200 */     if (enabled) {
/* 201 */       startup();
/*     */     }
/*     */     else
/* 204 */       shutdown();
/*     */   }
/*     */ 
/*     */   private Boolean getNNTPEnabledDatabaseProperty()
/*     */   {
/* 213 */     String enabled = JiveGlobals.getJiveProperty("nntp.enabled");
/* 214 */     if (enabled == null) {
/* 215 */       return null;
/*     */     }
/*     */ 
/* 218 */     return "true".equals(enabled.trim().toLowerCase()) ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */ 
/*     */   private void startup()
/*     */   {
/* 223 */     if (!isRunning()) {
/* 224 */       Log.info("Starting NNTP Module");
/*     */ 
/* 226 */       List portNames = JiveGlobals.getJivePropertyNames("nntp.ports");
/*     */ 
/* 228 */       if (portNames.isEmpty()) {
/* 229 */         JiveGlobals.setJiveProperty("nntp.ports.port1.portnumber", "119");
/*     */       }
/* 231 */       this.sessionManager.initialize();
/* 232 */       this.connectionManager.initialize();
/* 233 */       this.acceptManager.initialize();
/*     */ 
/* 235 */       this.startDate = new Date();
/* 236 */       this.stopDate = null;
/*     */ 
/* 239 */       Log.debug("Attempting to start NNTP accept ports");
/* 240 */       if (this.acceptManager != null) {
/* 241 */         Iterator ports = this.acceptManager.getAcceptPorts();
/* 242 */         while (ports.hasNext()) {
/* 243 */           AcceptPort port = (AcceptPort)ports.next();
/*     */           try {
/* 245 */             port.open();
/*     */           }
/*     */           catch (Exception e) {
/* 248 */             Log.error("Trouble starting NNTP port " + port, e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void restart()
/*     */   {
/* 259 */     if (isRunning()) {
/* 260 */       shutdown();
/* 261 */       startup();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void shutdown() {
/* 266 */     if (isRunning()) {
/* 267 */       this.stopDate = new Date();
/* 268 */       Log.info("Stopping NNTP Module");
/* 269 */       if (this.acceptManager != null) {
/* 270 */         Iterator ports = this.acceptManager.getAcceptPorts();
/* 271 */         while (ports.hasNext()) {
/* 272 */           AcceptPort port = (AcceptPort)ports.next();
/*     */           try {
/* 274 */             port.close();
/*     */           }
/*     */           catch (Exception e) {
/* 277 */             Log.error("Trouble shutting down port " + port, e);
/*     */           }
/*     */         }
/*     */       }
/* 281 */       if (this.connectionManager != null) {
/* 282 */         Iterator connections = this.connectionManager.getConnections();
/* 283 */         while (connections.hasNext()) {
/* 284 */           Connection conn = (Connection)connections.next();
/*     */           try {
/* 286 */             this.connectionManager.removeConnection(conn);
/* 287 */             conn.close();
/*     */           }
/*     */           catch (Exception e) {
/* 290 */             Log.error("Trouble closing connection " + conn, e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 303 */     getInstance().startup();
/* 304 */     Runtime.getRuntime().addShutdownHook(new Thread() {
/*     */       public void run() {
/* 306 */         NNTPServer.getInstance().shutdown();
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NNTPServer
 * JD-Core Version:    0.6.2
 */
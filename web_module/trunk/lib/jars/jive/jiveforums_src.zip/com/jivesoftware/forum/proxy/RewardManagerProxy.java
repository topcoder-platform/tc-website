/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.RewardException;
/*     */ import com.jivesoftware.forum.RewardManager;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class RewardManagerProxy
/*     */   implements RewardManager
/*     */ {
/*     */   protected RewardManager rewardManager;
/*     */   protected AuthToken authToken;
/*     */   protected Permissions permissions;
/*     */ 
/*     */   public RewardManagerProxy(RewardManager rewardManager, AuthToken authToken, Permissions permissions)
/*     */   {
/*  32 */     this.rewardManager = rewardManager;
/*  33 */     this.authToken = authToken;
/*  34 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public boolean isRewardsEnabled() {
/*  38 */     return this.rewardManager.isRewardsEnabled();
/*     */   }
/*     */ 
/*     */   public void setRewardsEnabled(boolean enabled) throws UnauthorizedException {
/*  42 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  43 */       this.rewardManager.setRewardsEnabled(enabled);
/*     */     }
/*     */     else
/*  46 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getMaxThreadPoints()
/*     */   {
/*  51 */     return this.rewardManager.getMaxThreadPoints();
/*     */   }
/*     */ 
/*     */   public void setMaxThreadPoints(int numPoints) throws UnauthorizedException {
/*  55 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  56 */       this.rewardManager.setMaxThreadPoints(numPoints);
/*     */     }
/*     */     else
/*  59 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getMaxMessagePoints()
/*     */   {
/*  64 */     return this.rewardManager.getMaxMessagePoints();
/*     */   }
/*     */ 
/*     */   public void setMaxMessagePoints(int numPoints) throws UnauthorizedException {
/*  68 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  69 */       this.rewardManager.setMaxMessagePoints(numPoints);
/*     */     }
/*     */     else
/*  72 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void transferPoints(ForumThread thread, int numPoints)
/*     */     throws UnauthorizedException, RewardException
/*     */   {
/*  79 */     User user = thread.getRootMessage().getUser();
/*  80 */     if ((this.permissions.hasPermission(576460752303423488L)) || ((user != null) && (user.getID() == this.authToken.getUserID())))
/*     */     {
/*  83 */       this.rewardManager.transferPoints(thread, numPoints);
/*     */     }
/*     */     else
/*  86 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void rewardPoints(ForumMessage message, int numPoints)
/*     */     throws UnauthorizedException, RewardException
/*     */   {
/*  93 */     User user = message.getForumThread().getRootMessage().getUser();
/*  94 */     if ((this.permissions.hasPermission(576460752303423488L)) || ((user != null) && (user.getID() == this.authToken.getUserID())))
/*     */     {
/*  97 */       this.rewardManager.rewardPoints(message, numPoints);
/*     */     }
/*     */     else
/* 100 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getPoints(ForumThread thread)
/*     */   {
/* 105 */     return this.rewardManager.getPoints(thread);
/*     */   }
/*     */ 
/*     */   public int getPoints(ForumMessage message) {
/* 109 */     return this.rewardManager.getPoints(message);
/*     */   }
/*     */ 
/*     */   public int getBankPoints(User user) {
/* 113 */     return this.rewardManager.getBankPoints(user);
/*     */   }
/*     */ 
/*     */   public boolean isBankEnabled() {
/* 117 */     return this.rewardManager.isBankEnabled();
/*     */   }
/*     */ 
/*     */   public void setBankEnabled(boolean enabled) throws UnauthorizedException {
/* 121 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 122 */       this.rewardManager.setBankEnabled(enabled);
/*     */     }
/*     */     else
/* 125 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void addBankPoints(User user, int numPoints)
/*     */     throws UnauthorizedException
/*     */   {
/* 131 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 132 */       this.rewardManager.addBankPoints(user, numPoints);
/*     */     }
/*     */     else
/* 135 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void addBankPoints(int numPoints)
/*     */     throws UnauthorizedException
/*     */   {
/* 141 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 142 */       this.rewardManager.addBankPoints(numPoints);
/*     */     }
/*     */     else
/* 145 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getInitialBankPoints()
/*     */   {
/* 150 */     return this.rewardManager.getInitialBankPoints();
/*     */   }
/*     */ 
/*     */   public void setInitialBankPoints(int initialBankPoints) throws UnauthorizedException {
/* 154 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 155 */       this.rewardManager.setInitialBankPoints(initialBankPoints);
/*     */     }
/*     */     else
/* 158 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public int getMaxBankPoints()
/*     */   {
/* 163 */     return this.rewardManager.getMaxBankPoints();
/*     */   }
/*     */ 
/*     */   public void setMaxBankPoints(int maxBankPoints) throws UnauthorizedException {
/* 167 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 168 */       this.rewardManager.setMaxBankPoints(maxBankPoints);
/*     */     }
/*     */     else
/* 171 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getPendingRewardThreads(User user)
/*     */   {
/* 177 */     return new IteratorProxy(1, this.rewardManager.getPendingRewardThreads(user), this.authToken);
/*     */   }
/*     */ 
/*     */   public int getPointsRewarded(User user)
/*     */   {
/* 182 */     return this.rewardManager.getPointsRewarded(user);
/*     */   }
/*     */ 
/*     */   public int getPointsEarned(User user) {
/* 186 */     return this.rewardManager.getPointsEarned(user);
/*     */   }
/*     */ 
/*     */   public int getPointsRewarded(ForumThread thread) {
/* 190 */     return this.rewardManager.getPointsRewarded(thread);
/*     */   }
/*     */ 
/*     */   public int getPendingRewardThreadsCount(User user) {
/* 194 */     return this.rewardManager.getPendingRewardThreadsCount(user);
/*     */   }
/*     */ 
/*     */   public int getPointsEarned(User user, Forum forum) {
/* 198 */     return this.rewardManager.getPointsEarned(user, forum);
/*     */   }
/*     */ 
/*     */   public int getPointsEarned(User user, ForumCategory category) {
/* 202 */     return this.rewardManager.getPointsEarned(user, category);
/*     */   }
/*     */ 
/*     */   public Iterator getTopUsers(int startIndex, int numResults) {
/* 206 */     return this.rewardManager.getTopUsers(startIndex, numResults);
/*     */   }
/*     */ 
/*     */   public Iterator getTopUsers(int startIndex, int numResults, ForumCategory category) {
/* 210 */     return this.rewardManager.getTopUsers(startIndex, numResults, category);
/*     */   }
/*     */ 
/*     */   public Iterator getTopUsers(int startIndex, int numResults, Forum forum) {
/* 214 */     return this.rewardManager.getTopUsers(startIndex, numResults, forum);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.RewardManagerProxy
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.action.rss;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.action.rss.RSSActionSupport;
/*     */ import com.jivesoftware.forum.AnnouncementManager;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.util.SkinUtils;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.LocaleUtils;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class RSSAnnouncements extends RSSActionSupport
/*     */ {
/*     */   public static final String DEFAULT_DATE_FORMAT = "MM/dd/yyyy";
/*  33 */   private long categoryID = 0L;
/*  34 */   private long forumID = 0L;
/*     */   private boolean full;
/*     */   private String start;
/*     */   private String end;
/*     */   private ForumCategory category;
/*     */   private Forum forum;
/*     */   private Iterator announcements;
/*     */ 
/*     */   public long getCategoryID()
/*     */   {
/*  45 */     return this.categoryID;
/*     */   }
/*     */ 
/*     */   public void setCategoryID(long categoryID) {
/*  49 */     this.categoryID = categoryID;
/*     */   }
/*     */ 
/*     */   public long getForumID() {
/*  53 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID) {
/*  57 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public boolean isFull()
/*     */   {
/*  65 */     return this.full;
/*     */   }
/*     */ 
/*     */   public boolean getFull()
/*     */   {
/*  73 */     return this.full;
/*     */   }
/*     */ 
/*     */   public void setFull(boolean full)
/*     */   {
/*  80 */     this.full = full;
/*     */   }
/*     */ 
/*     */   public String getStart()
/*     */   {
/*  87 */     return this.start;
/*     */   }
/*     */ 
/*     */   public void setStart(String start)
/*     */   {
/*  94 */     this.start = start;
/*     */   }
/*     */ 
/*     */   public String getEnd()
/*     */   {
/* 101 */     return this.end;
/*     */   }
/*     */ 
/*     */   public void setEnd(String end)
/*     */   {
/* 108 */     this.end = end;
/*     */   }
/*     */ 
/*     */   public ForumCategory getCategory()
/*     */   {
/* 115 */     return this.category;
/*     */   }
/*     */ 
/*     */   public Forum getForum()
/*     */   {
/* 122 */     return this.forum;
/*     */   }
/*     */ 
/*     */   public Iterator getAnnouncements()
/*     */   {
/* 130 */     if (this.announcements == null) {
/* 131 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/* 133 */     return this.announcements;
/*     */   }
/*     */ 
/*     */   public String getFeedTitle()
/*     */   {
/* 144 */     List args = new ArrayList();
/* 145 */     args.add(SkinUtils.getCommunityName());
/* 146 */     if (this.forum != null) {
/* 147 */       args.add(this.forum.getName());
/* 148 */       return LocaleUtils.getLocalizedString("rss.announcements_forum", getLocale(), args);
/*     */     }
/* 150 */     if (this.category != null) {
/* 151 */       args.add(this.category.getName());
/* 152 */       return LocaleUtils.getLocalizedString("rss.announcements_category", getLocale(), args);
/*     */     }
/*     */ 
/* 155 */     return LocaleUtils.getLocalizedString("rss.announcements_global", getLocale(), args);
/*     */   }
/*     */ 
/*     */   public String executeRSS()
/*     */   {
/* 161 */     String dateFormat = JiveGlobals.getJiveProperty("rss.rssannouncements.dateformat");
/* 162 */     if (dateFormat == null) {
/* 163 */       dateFormat = "MM/dd/yyyy";
/*     */     }
/*     */ 
/* 167 */     Date startDate = null;
/* 168 */     Date endDate = null;
/* 169 */     SimpleDateFormat formatter = null;
/* 170 */     String start = getStart();
/* 171 */     String end = getEnd();
/* 172 */     if ((start != null) || (end != null)) {
/*     */       try {
/* 174 */         formatter = new SimpleDateFormat(dateFormat);
/*     */       }
/*     */       catch (Exception e) {
/* 177 */         addFieldError("dateformat", dateFormat);
/*     */       }
/*     */     }
/* 180 */     if (!hasErrors()) {
/* 181 */       if (start != null) {
/*     */         try {
/* 183 */           startDate = formatter.parse(start);
/*     */         }
/*     */         catch (Exception e) {
/* 186 */           addFieldError("dateformat", dateFormat);
/*     */         }
/*     */       }
/* 189 */       if ((!hasErrors()) && (end != null)) {
/*     */         try {
/* 191 */           endDate = formatter.parse(end);
/*     */         }
/*     */         catch (Exception e) {
/* 194 */           addFieldError("dateformat", dateFormat);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 200 */     if ((start != null) && (end != null)) {
/* 201 */       if (startDate.getTime() > endDate.getTime()) {
/* 202 */         addFieldError("daterange", "");
/*     */       }
/* 204 */       Date now = new Date(CacheFactory.currentTime);
/* 205 */       if ((startDate.getTime() > now.getTime()) || (endDate.getTime() > now.getTime())) {
/* 206 */         addFieldError("daterange", "");
/*     */       }
/*     */     }
/*     */ 
/* 210 */     if (hasErrors()) {
/* 211 */       return "error";
/*     */     }
/*     */ 
/* 214 */     ForumFactory forumFactory = ForumFactory.getInstance(getAuthToken());
/* 215 */     if (this.categoryID > 0L) {
/*     */       try {
/* 217 */         this.category = forumFactory.getForumCategory(this.categoryID);
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e) {
/* 220 */         addFieldError("categoryNotFound", "" + this.categoryID);
/*     */       }
/*     */     }
/* 223 */     if (this.forumID > 0L) {
/*     */       try {
/* 225 */         this.forum = forumFactory.getForum(this.forumID);
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 228 */         addFieldError("forumNotFound", "" + this.forumID);
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 231 */         addFieldError("unauthorized", "");
/*     */       }
/*     */     }
/*     */ 
/* 235 */     int numItems = getNumItems();
/* 236 */     if (numItems > 0) {
/* 237 */       AnnouncementManager manager = forumFactory.getAnnouncementManager();
/*     */ 
/* 239 */       if (this.forum != null)
/*     */       {
/* 242 */         if ((startDate == null) && (endDate == null)) {
/* 243 */           this.announcements = manager.getAnnouncements(this.forum);
/*     */         }
/*     */         else {
/* 246 */           this.announcements = manager.getAnnouncements(this.forum, startDate, endDate);
/*     */         }
/*     */       }
/* 249 */       else if (this.category != null) {
/* 250 */         if ((startDate == null) && (endDate == null)) {
/* 251 */           this.announcements = manager.getAnnouncements(this.category);
/*     */         }
/*     */         else {
/* 254 */           this.announcements = manager.getAnnouncements(this.category, startDate, endDate);
/*     */         }
/*     */ 
/*     */       }
/* 259 */       else if ((startDate == null) && (endDate == null)) {
/* 260 */         this.announcements = manager.getAnnouncements(null);
/*     */       }
/*     */       else {
/* 263 */         this.announcements = manager.getAnnouncements(null, startDate, endDate);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 268 */     if (hasErrors()) {
/* 269 */       return "error";
/*     */     }
/* 271 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.rss.RSSAnnouncements
 * JD-Core Version:    0.6.2
 */
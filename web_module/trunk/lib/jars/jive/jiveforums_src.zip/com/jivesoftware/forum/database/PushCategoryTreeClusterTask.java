/*    */ package com.jivesoftware.forum.database;
/*    */ 
/*    */ import com.jivesoftware.util.LongTree;
/*    */ import com.tangosol.net.Invocable;
/*    */ import com.tangosol.net.InvocationService;
/*    */ 
/*    */ public class PushCategoryTreeClusterTask
/*    */   implements Invocable
/*    */ {
/*    */   private LongTree categoryTree;
/*    */ 
/*    */   public PushCategoryTreeClusterTask(LongTree categoryTree)
/*    */   {
/* 29 */     this.categoryTree = categoryTree;
/*    */   }
/*    */ 
/*    */   public void init(InvocationService service)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/* 46 */     if (DbForumFactory.isInitialized())
/* 47 */       DbForumCategory.setCategoryTree(this.categoryTree);
/*    */   }
/*    */ 
/*    */   public Object getResult()
/*    */   {
/* 55 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.PushCategoryTreeClusterTask
 * JD-Core Version:    0.6.2
 */
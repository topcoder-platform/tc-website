/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserProxy;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.Question;
/*     */ import com.jivesoftware.forum.Question.State;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class QuestionProxy
/*     */   implements Question
/*     */ {
/*     */   private Question question;
/*     */   private AuthToken authToken;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public QuestionProxy(Question question, AuthToken authToken, Permissions permissions)
/*     */   {
/*  43 */     this.question = question;
/*  44 */     this.authToken = authToken;
/*  45 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public User getUser() {
/*  49 */     User user = this.question.getUser();
/*  50 */     if (user == null) {
/*  51 */       return null;
/*     */     }
/*  53 */     return new UserProxy(this.question.getUser(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public ForumThread getForumThread() {
/*  57 */     ForumThread thread = this.question.getForumThread();
/*  58 */     Permissions forumPerms = thread.getForum().getPermissions(this.authToken);
/*  59 */     return new ForumThreadProxy(this.question.getForumThread(), this.authToken, forumPerms);
/*     */   }
/*     */ 
/*     */   public Question.State getState() {
/*  63 */     return this.question.getState();
/*     */   }
/*     */ 
/*     */   public void setState(Question.State state) throws UnauthorizedException {
/*  67 */     long userID = this.question.getUser() == null ? -2L : this.question.getUser().getID();
/*     */ 
/*  69 */     if (state == Question.State.open) {
/*  70 */       if ((userID == this.authToken.getUserID()) || (this.permissions.hasPermission(576460752303423488L)))
/*     */       {
/*  73 */         this.question.setState(state);
/*     */       }
/*     */       else {
/*  76 */         throw new UnauthorizedException();
/*     */       }
/*     */ 
/*     */     }
/*  80 */     else if (state == Question.State.possibly_resolved) {
/*  81 */       this.question.setState(state);
/*     */     }
/*  84 */     else if (state == Question.State.assumed_resolved) {
/*  85 */       if (isAdmin()) {
/*  86 */         this.question.setState(state);
/*     */       }
/*     */       else {
/*  89 */         throw new UnauthorizedException();
/*     */       }
/*     */ 
/*     */     }
/*  93 */     else if (state == Question.State.resolved)
/*  94 */       if ((userID == this.authToken.getUserID()) || (this.permissions.hasPermission(576460752303423488L)))
/*     */       {
/*  97 */         this.question.setState(state);
/*     */       }
/*     */       else
/* 100 */         throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Date getCreationDate()
/*     */   {
/* 106 */     return this.question.getCreationDate();
/*     */   }
/*     */ 
/*     */   public Date getResolutionDate() {
/* 110 */     return this.question.getResolutionDate();
/*     */   }
/*     */ 
/*     */   public void addHelpfulAnswer(ForumMessage message) throws UnauthorizedException {
/* 114 */     if (isAdmin()) {
/* 115 */       this.question.addHelpfulAnswer(message);
/*     */     }
/*     */     else
/* 118 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean isHelpfulAnswer(ForumMessage message)
/*     */   {
/* 123 */     return this.question.isHelpfulAnswer(message);
/*     */   }
/*     */ 
/*     */   public Collection getHelpfulAnswers() {
/* 127 */     return this.question.getHelpfulAnswers();
/*     */   }
/*     */ 
/*     */   public void setCorrectAnswer(ForumMessage message) throws UnauthorizedException {
/* 131 */     if (isAdmin()) {
/* 132 */       this.question.setCorrectAnswer(message);
/*     */     }
/*     */     else
/* 135 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public boolean isCorrectAnswer(ForumMessage message)
/*     */   {
/* 140 */     return this.question.isCorrectAnswer(message);
/*     */   }
/*     */ 
/*     */   public ForumMessage getCorrectAnswer() {
/* 144 */     ForumMessage message = this.question.getCorrectAnswer();
/* 145 */     if (message == null) {
/* 146 */       return null;
/*     */     }
/* 148 */     return new ForumMessageProxy(message, this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public String getProperty(String name) {
/* 152 */     return this.question.getProperty(name);
/*     */   }
/*     */ 
/*     */   public Collection getProperties(String parentName) {
/* 156 */     return this.question.getProperties(parentName);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value) throws UnauthorizedException {
/* 160 */     this.question.setProperty(name, value);
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) throws UnauthorizedException {
/* 164 */     this.question.deleteProperty(name);
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames() {
/* 168 */     return this.question.getPropertyNames();
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 172 */     return this.question.toString();
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 176 */     return this.question.hashCode();
/*     */   }
/*     */ 
/*     */   private boolean isAdmin()
/*     */   {
/* 185 */     if ((this.question.getUser() != null) && (this.question.getUser().getID() == this.authToken.getUserID())) {
/* 186 */       return true;
/*     */     }
/* 188 */     if (this.permissions.hasPermission(576460752303423488L)) {
/* 189 */       return true;
/*     */     }
/* 191 */     ForumThread thread = getForumThread();
/* 192 */     if (thread.isAuthorized(896L))
/*     */     {
/* 195 */       return true;
/*     */     }
/* 197 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.QuestionProxy
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum.nntp;

public class SessionAlreadyExistsException extends Exception
{
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.SessionAlreadyExistsException
 * JD-Core Version:    0.6.2
 */
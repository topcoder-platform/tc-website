/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.base.stats.ReadStat;
/*    */ import com.jivesoftware.base.stats.ReadStatSession;
/*    */ import com.jivesoftware.base.stats.ReadStatsManager;
/*    */ import com.jivesoftware.base.stats.ReadStatsManagerFactory;
/*    */ import com.jivesoftware.base.stats.WebContext;
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import com.jivesoftware.forum.ForumCategory;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.ForumThread;
/*    */ import com.opensymphony.webwork.ServletActionContext;
/*    */ import com.opensymphony.xwork.ActionInvocation;
/*    */ import com.opensymphony.xwork.interceptor.AroundInterceptor;
/*    */ 
/*    */ public class ReadStatsInterceptor extends AroundInterceptor
/*    */ {
/*    */   public static final String CATEGORY = "category";
/*    */   public static final String FORUM = "forum";
/*    */   public static final String THREAD = "thread";
/*    */   private String type;
/*    */ 
/*    */   public String getType()
/*    */   {
/* 54 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(String type)
/*    */   {
/* 65 */     if ((!"category".equals(type)) && (!"forum".equals(type)) && (!"thread".equals(type))) {
/* 66 */       throw new IllegalArgumentException("Invalid type");
/*    */     }
/* 68 */     this.type = type;
/*    */   }
/*    */ 
/*    */   protected void before(ActionInvocation in)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   protected void after(ActionInvocation in, String result)
/*    */     throws Exception
/*    */   {
/* 84 */     if ((result != null) && (result.startsWith("success")))
/*    */     {
/* 86 */       if (ReadStatsManager.isReadStatsEnabled()) {
/* 87 */         String type = getType();
/* 88 */         if (type == null) {
/* 89 */           throw new IllegalArgumentException("Invalid type");
/*    */         }
/* 91 */         if (Log.isDebugEnabled()) {
/* 92 */           Log.debug("Adding a read stat from class " + getClass().getName() + ", type: " + type);
/*    */         }
/*    */ 
/* 97 */         ReadStatSession sess = new WebContext(ServletActionContext.getRequest(), ServletActionContext.getResponse()).getReadStatSession();
/*    */ 
/* 101 */         if ("category".equals(type)) {
/* 102 */           ForumCategoryAction action = (ForumCategoryAction)in.getAction();
/*    */ 
/* 104 */           long rootID = action.getForumFactory().getRootForumCategory().getID();
/* 105 */           if (action.getCategory().getID() != rootID) {
/* 106 */             ReadStatsManagerFactory.getInstance().addReadStat(new ReadStat(action.getPageUser(), 14, action.getCategory().getID(), sess));
/*    */           }
/*    */ 
/*    */         }
/* 111 */         else if ("forum".equals(type)) {
/* 112 */           ForumAction action = (ForumAction)in.getAction();
/* 113 */           ReadStatsManagerFactory.getInstance().addReadStat(new ReadStat(action.getPageUser(), 0, action.getForum().getID(), sess));
/*    */         }
/* 117 */         else if ("thread".equals(type)) {
/* 118 */           ForumThreadAction action = (ForumThreadAction)in.getAction();
/* 119 */           ReadStatsManagerFactory.getInstance().addReadStat(new ReadStat(action.getPageUser(), 1, action.getThread().getID(), sess));
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.ReadStatsInterceptor
 * JD-Core Version:    0.6.2
 */
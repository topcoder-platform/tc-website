/*     */ package com.jivesoftware.forum.nntp.spi;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class PeekIterator
/*     */   implements Iterator
/*     */ {
/*     */   private Iterator iterator;
/*  26 */   private Object peekObject = null;
/*     */ 
/*     */   public PeekIterator(Iterator itr)
/*     */   {
/*  34 */     this.iterator = itr;
/*     */   }
/*     */ 
/*     */   public PeekIterator(Iterator itr, Object firstItem)
/*     */   {
/*  45 */     this.iterator = itr;
/*  46 */     this.peekObject = firstItem;
/*     */   }
/*     */ 
/*     */   public Object peek()
/*     */   {
/*  57 */     if (this.peekObject == null) {
/*  58 */       this.peekObject = this.iterator.next();
/*     */     }
/*  60 */     return this.peekObject;
/*     */   }
/*     */ 
/*     */   public void remove()
/*     */     throws UnsupportedOperationException
/*     */   {
/*  70 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/*  80 */     boolean next = false;
/*  81 */     if (this.peekObject == null)
/*  82 */       next = this.iterator.hasNext();
/*     */     else {
/*  84 */       next = true;
/*     */     }
/*  86 */     return next;
/*     */   }
/*     */ 
/*     */   public Object next()
/*     */   {
/*  95 */     Object next = this.peekObject;
/*  96 */     if (next == null)
/*  97 */       next = this.iterator.next();
/*     */     else {
/*  99 */       this.peekObject = null;
/*     */     }
/* 101 */     return next;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.PeekIterator
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.ForumThread;
/*    */ import com.jivesoftware.forum.RewardManager;
/*    */ 
/*    */ public class MyRewardsAction extends ForumActionSupport
/*    */ {
/*    */   public RewardManager getRewardManager()
/*    */   {
/* 29 */     return getForumFactory().getRewardManager();
/*    */   }
/*    */ 
/*    */   public int getReplyCount(ForumThread thread)
/*    */   {
/* 39 */     return thread.getMessageCount() - 1;
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */   {
/* 50 */     if (getAuthToken().isAnonymous()) {
/* 51 */       setLoginAttributes();
/* 52 */       return "login";
/*    */     }
/* 54 */     return "success";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.MyRewardsAction
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.nntp.spi;
/*    */ 
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*    */ import com.jivesoftware.forum.database.DbForumFactory;
/*    */ import com.jivesoftware.forum.database.DbForumMessage;
/*    */ import com.jivesoftware.forum.nntp.Article;
/*    */ import com.jivesoftware.forum.nntp.ArticleNotFoundException;
/*    */ import com.jivesoftware.forum.nntp.NewsGroup;
/*    */ 
/*    */ public class FForumNewsGroupAdapter
/*    */   implements NewsGroup
/*    */ {
/* 35 */   private static DbForumFactory factory = DbForumFactory.getInstance();
/*    */   private Forum forum;
/*    */ 
/*    */   public FForumNewsGroupAdapter(Forum forum)
/*    */   {
/* 44 */     this.forum = forum;
/*    */   }
/*    */ 
/*    */   public Forum getForum()
/*    */   {
/* 52 */     return this.forum;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 64 */     return this.forum.getNNTPName();
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 68 */     return this.forum.getDescription();
/*    */   }
/*    */ 
/*    */   public boolean isModerated() {
/* 72 */     return this.forum.getModerationDefaultMessageValue() == 0;
/*    */   }
/*    */ 
/*    */   public int getFirstArticleNumber() {
/* 76 */     return this.forum.getMinForumIndex();
/*    */   }
/*    */ 
/*    */   public int getLastArticleNumber() {
/* 80 */     return this.forum.getMaxForumIndex();
/*    */   }
/*    */ 
/*    */   public int getArticleCount() {
/* 84 */     return this.forum.getMessageCount();
/*    */   }
/*    */ 
/*    */   public Article getArticle(int articleNumber) throws ArticleNotFoundException {
/* 88 */     long messageID = factory.getMessageID(this.forum.getID(), articleNumber);
/*    */     try {
/* 90 */       return new FMessageArticleAdapter((DbForumMessage)factory.getMessage(messageID));
/*    */     }
/*    */     catch (ForumMessageNotFoundException fe) {
/* 93 */       throw new ArticleNotFoundException(fe.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   public long getID() {
/* 98 */     return this.forum.getID();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.spi.FForumNewsGroupAdapter
 * JD-Core Version:    0.6.2
 */
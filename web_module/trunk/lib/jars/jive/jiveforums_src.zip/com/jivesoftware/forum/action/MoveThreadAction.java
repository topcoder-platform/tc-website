/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.jivesoftware.forum.ForumNotFoundException;
/*    */ 
/*    */ public class MoveThreadAction extends ForumThreadAction
/*    */ {
/*    */   private String doCancel;
/* 23 */   private long targetForumID = -1L;
/*    */   private Forum targetForum;
/*    */ 
/*    */   public String getDoCancel()
/*    */   {
/* 32 */     return this.doCancel;
/*    */   }
/*    */ 
/*    */   public void setDoCancel(String doCancel) {
/* 36 */     this.doCancel = "true";
/*    */   }
/*    */ 
/*    */   public long getTargetForumID() {
/* 40 */     return this.targetForumID;
/*    */   }
/*    */ 
/*    */   public void setTargetForumID(long targetForumID) {
/* 44 */     this.targetForumID = targetForumID;
/*    */   }
/*    */ 
/*    */   public Forum getTargetForum()
/*    */   {
/* 50 */     return this.targetForum;
/*    */   }
/*    */ 
/*    */   public String doDefault() {
/* 54 */     if (getAuthToken().isAnonymous()) {
/* 55 */       setLoginAttributes();
/* 56 */       return "login";
/*    */     }
/* 58 */     return "input";
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */   {
/* 64 */     if ("true".equals(getDoCancel())) {
/* 65 */       return "cancel";
/*    */     }
/*    */ 
/* 69 */     if ((this.targetForumID == -1L) || (this.targetForumID == getForum().getID())) {
/* 70 */       addFieldError("targetForumID", "");
/* 71 */       return "input";
/*    */     }
/*    */ 
/*    */     try
/*    */     {
/* 76 */       this.targetForum = getForumFactory().getForum(this.targetForumID);
/*    */ 
/* 78 */       getForum().moveThread(getThread(), this.targetForum);
/* 79 */       return "success";
/*    */     }
/*    */     catch (UnauthorizedException ue) {
/* 82 */       addFieldError("permission", "");
/* 83 */       return "input";
/*    */     }
/*    */     catch (ForumNotFoundException fnfe) {
/* 86 */       addFieldError("targetForumID", String.valueOf(this.targetForumID));
/*    */     }
/*    */ 
/* 89 */     return "input";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.MoveThreadAction
 * JD-Core Version:    0.6.2
 */
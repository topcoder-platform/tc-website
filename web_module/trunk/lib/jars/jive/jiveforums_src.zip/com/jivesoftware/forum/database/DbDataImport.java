/*      */ package com.jivesoftware.forum.database;
/*      */ 
/*      */ import com.jivesoftware.base.AuthFactory;
/*      */ import com.jivesoftware.base.AuthToken;
/*      */ import com.jivesoftware.base.Group;
/*      */ import com.jivesoftware.base.GroupAlreadyExistsException;
/*      */ import com.jivesoftware.base.GroupManager;
/*      */ import com.jivesoftware.base.GroupNotFoundException;
/*      */ import com.jivesoftware.base.JiveGlobals;
/*      */ import com.jivesoftware.base.Log;
/*      */ import com.jivesoftware.base.PermissionType;
/*      */ import com.jivesoftware.base.PermissionsManager;
/*      */ import com.jivesoftware.base.Poll;
/*      */ import com.jivesoftware.base.PollException;
/*      */ import com.jivesoftware.base.PollManager;
/*      */ import com.jivesoftware.base.PollManagerFactory;
/*      */ import com.jivesoftware.base.UnauthorizedException;
/*      */ import com.jivesoftware.base.User;
/*      */ import com.jivesoftware.base.UserAlreadyExistsException;
/*      */ import com.jivesoftware.base.UserManager;
/*      */ import com.jivesoftware.base.UserNotFoundException;
/*      */ import com.jivesoftware.base.database.DbPoll;
/*      */ import com.jivesoftware.forum.Announcement;
/*      */ import com.jivesoftware.forum.AnnouncementManager;
/*      */ import com.jivesoftware.forum.Attachment;
/*      */ import com.jivesoftware.forum.AttachmentException;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumCategory;
/*      */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*      */ import com.jivesoftware.forum.ForumFactory;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumNotFoundException;
/*      */ import com.jivesoftware.forum.ForumThread;
/*      */ import com.jivesoftware.forum.MessageRejectedException;
/*      */ import com.jivesoftware.forum.PrivateMessageFolder;
/*      */ import com.jivesoftware.forum.PrivateMessageManager;
/*      */ import com.jivesoftware.util.AbstractPollableRunnable;
/*      */ import com.jivesoftware.util.Cache;
/*      */ import com.jivesoftware.util.StringUtils;
/*      */ import com.jivesoftware.util.ZipFileUtil;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.sql.SQLException;
/*      */ import java.text.ParseException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.activation.MimetypesFileTypeMap;
/*      */ import org.apache.commons.cli.BasicParser;
/*      */ import org.apache.commons.cli.CommandLine;
/*      */ import org.apache.commons.cli.CommandLineParser;
/*      */ import org.apache.commons.cli.HelpFormatter;
/*      */ import org.apache.commons.cli.Option;
/*      */ import org.apache.commons.cli.Options;
/*      */ import org.xmlpull.v1.XmlPullParser;
/*      */ import org.xmlpull.v1.XmlPullParserException;
/*      */ import org.xmlpull.v1.XmlPullParserFactory;
/*      */ 
/*      */ public class DbDataImport extends AbstractPollableRunnable
/*      */   implements Serializable
/*      */ {
/*   40 */   private static String NAME = "Jive Software Database Export Utility";
/*      */ 
/*   42 */   private static XmlPullParserFactory factory = null;
/*      */ 
/*   48 */   private static final Pattern PROPERTY_IGNORE_PATTERN = Pattern.compile("^gateway\\.");
/*      */   public static final String XML_DATE_FORMAT = "yyyy/MM/dd HH:mm:ss.SS z";
/*      */   public static final String XML_VERSION = "4.0";
/*   57 */   private static SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SS z");
/*      */ 
/*   60 */   private static HashMap handlerMap = new HashMap();
/*      */ 
/*   63 */   private static MimetypesFileTypeMap typeMap = new MimetypesFileTypeMap();
/*      */ 
/*  105 */   private ForumFactory forumFactory = null;
/*      */ 
/*  108 */   private UserManager userManager = null;
/*  109 */   private GroupManager groupManager = null;
/*      */   private Forum forum;
/*      */   private ForumThread thread;
/*      */   private Reader reader;
/*      */   private File file;
/*      */   private File attachmentDirectory;
/*      */ 
/*      */   public DbDataImport(ForumFactory forumFactory, File file)
/*      */     throws Exception
/*      */   {
/*  127 */     this.forumFactory = forumFactory;
/*      */ 
/*  129 */     this.userManager = forumFactory.getUserManager();
/*  130 */     this.groupManager = forumFactory.getGroupManager();
/*      */ 
/*  132 */     this.file = file;
/*      */   }
/*      */ 
/*      */   public int getTaskValue()
/*      */   {
/*  137 */     return 0;
/*      */   }
/*      */ 
/*      */   public void doRun() {
/*  141 */     Log.debug("DbDataImport#doRun : called!");
/*      */     try
/*      */     {
/*  145 */       if (this.file.getName().endsWith(".xml")) {
/*  146 */         this.reader = new BufferedReader(new FileReader(this.file));
/*      */       }
/*  148 */       else if (this.file.getName().endsWith(".zip")) {
/*  149 */         File directory = ZipFileUtil.expandZipFile(this.file);
/*  150 */         File xmlFile = new File(directory, "export.xml");
/*  151 */         this.reader = new BufferedReader(new FileReader(xmlFile));
/*  152 */         this.attachmentDirectory = new File(directory, "attachments");
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  158 */       Log.error("Input Failed!", e);
/*  159 */       return;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  164 */       XmlPullParser xpp = factory.newPullParser();
/*  165 */       xpp.setInput(this.reader);
/*  166 */       handleChildEvents(null, xpp, this);
/*      */     }
/*      */     catch (Exception e) {
/*  169 */       Log.error(e);
/*      */     }
/*      */     finally {
/*      */       try {
/*  173 */         this.reader.close();
/*      */       }
/*      */       catch (IOException ioe) {
/*  176 */         Log.error(ioe);
/*      */       }
/*      */     }
/*  179 */     Log.debug("DbDataImport#doRun : ending!");
/*      */   }
/*      */ 
/*      */   public Reader getReader() {
/*  183 */     return this.reader;
/*      */   }
/*      */ 
/*      */   public void setReader(Reader reader) {
/*  187 */     this.reader = reader;
/*      */   }
/*      */ 
/*      */   private static void handleChildEvents(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */     throws XmlPullParserException, IOException
/*      */   {
/* 2010 */     String caller = xpp.getName();
/* 2011 */     int depth = xpp.getDepth();
/* 2012 */     Log.debug("DbDataImport#handleChildEvents : caller -> " + caller + " depth -> " + depth);
/* 2013 */     xpp.next();
/*      */ 
/* 2016 */     while ((!isEndTag(caller, depth, xpp)) && (1 != xpp.getEventType()))
/*      */     {
/* 2018 */       Log.debug("DbDataImport#handleChildEvents : node -> " + xpp.getName() + " type -> " + xpp.getEventType() + " depth-> " + xpp.getDepth());
/*      */ 
/* 2021 */       executeHandler(parent, xpp, importer);
/*      */ 
/* 2023 */       xpp.next();
/*      */     }
/* 2025 */     Log.debug("DbDataImport#handleChildEvents : returning with caller -> " + caller);
/*      */   }
/*      */ 
/*      */   private static void executeHandler(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */     throws XmlPullParserException, IOException
/*      */   {
/* 2034 */     if (2 == xpp.getEventType())
/*      */     {
/* 2036 */       Log.debug("DbDataImport#executeHandler : Looking for handler for tag --> " + xpp.getName() + " depth --> " + xpp.getDepth());
/*      */ 
/* 2039 */       Object o = handlerMap.get(xpp.getName());
/*      */ 
/* 2043 */       if (o != null)
/*      */       {
/* 2046 */         if ((o instanceof Handler)) {
/* 2047 */           Handler handler = (Handler)o;
/* 2048 */           handler.handle(parent, xpp, importer);
/*      */         }
/* 2050 */         else if ((o instanceof Class)) {
/* 2051 */           Class clazz = (Class)o;
/* 2052 */           if (clazz != null) {
/*      */             try {
/* 2054 */               Handler handler = (Handler)clazz.newInstance();
/* 2055 */               handler.handle(parent, xpp, importer);
/*      */             }
/*      */             catch (InstantiationException e)
/*      */             {
/* 2059 */               Log.error(e);
/*      */             }
/*      */             catch (IllegalAccessException e) {
/* 2062 */               Log.error(e);
/*      */             }
/*      */           }
/*      */           else
/* 2066 */             Log.debug("no handler found for tag --> " + xpp.getName());
/*      */         }
/*      */         else
/*      */         {
/* 2070 */           throw new IllegalArgumentException("handlerMap must contain objects of type Class or Handler");
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static boolean isEndTag(String tag, int depth, XmlPullParser xpp)
/*      */     throws XmlPullParserException
/*      */   {
/* 2092 */     boolean isSameName = xpp.getName() != null ? xpp.getName().equals(tag) : false;
/*      */ 
/* 2094 */     boolean isSameDepth = xpp.getDepth() == depth;
/*      */ 
/* 2096 */     boolean isEndTag = xpp.getEventType() == 3;
/*      */ 
/* 2099 */     return (isSameName) && (isSameDepth) && (isEndTag);
/*      */   }
/*      */ 
/*      */   private static boolean getBooleanValue(String text)
/*      */   {
/* 2110 */     return !"false".equalsIgnoreCase(text);
/*      */   }
/*      */ 
/*      */   private static long getPermission(String permission)
/*      */   {
/* 2122 */     if (permission == null) {
/* 2123 */       throw new IllegalArgumentException("permission is null!");
/*      */     }
/* 2125 */     if ("READ_FORUM".equals(permission)) {
/* 2126 */       return 1L;
/*      */     }
/* 2128 */     if ("CREATE_MESSAGE".equals(permission)) {
/* 2129 */       return 2L;
/*      */     }
/* 2131 */     if ("CREATE_THREAD".equals(permission)) {
/* 2132 */       return 4L;
/*      */     }
/* 2134 */     if ("CREATE_MESSAGE_ATTACHMENT".equals(permission)) {
/* 2135 */       return 8L;
/*      */     }
/* 2137 */     if ("CREATE_POLL".equals(permission)) {
/* 2138 */       return 16L;
/*      */     }
/* 2140 */     if ("PRIVATE_MESSAGE".equals(permission)) {
/* 2141 */       return 32L;
/*      */     }
/* 2143 */     if ("RATE_MESSAGE".equals(permission)) {
/* 2144 */       return 64L;
/*      */     }
/* 2146 */     if ("MODERATOR".equals(permission)) {
/* 2147 */       return 128L;
/*      */     }
/* 2149 */     if ("FORUM_ADMIN".equals(permission)) {
/* 2150 */       return 256L;
/*      */     }
/* 2152 */     if ("FORUM_CATEGORY_ADMIN".equals(permission)) {
/* 2153 */       return 512L;
/*      */     }
/* 2155 */     if ("VOTE_IN_POLL".equals(permission)) {
/* 2156 */       return 1024L;
/*      */     }
/* 2158 */     if ("CREATE_PRIVATE_MESSAGE_ATTACHMENT".equals(permission)) {
/* 2159 */       return 2048L;
/*      */     }
/* 2161 */     if ("NONE".equals(permission)) {
/* 2162 */       return 0L;
/*      */     }
/* 2164 */     if ("VIEW_ONLINE_STATUS".equals(permission)) {
/* 2165 */       return 72057594037927936L;
/*      */     }
/* 2167 */     if ("USER_ADMIN".equals(permission)) {
/* 2168 */       return 144115188075855872L;
/*      */     }
/* 2170 */     if ("GROUP_ADMIN".equals(permission)) {
/* 2171 */       return 288230376151711744L;
/*      */     }
/* 2173 */     if ("SYSTEM_ADMIN".equals(permission)) {
/* 2174 */       return 576460752303423488L;
/*      */     }
/* 2176 */     if ("CUSTOM_1".equals(permission)) {
/* 2177 */       return 1152921504606846976L;
/*      */     }
/* 2179 */     if ("CUSTOM_2".equals(permission)) {
/* 2180 */       return 2305843009213693952L;
/*      */     }
/* 2182 */     if ("CUSTOM_3".equals(permission)) {
/* 2183 */       return 4611686018427387904L;
/*      */     }
/* 2185 */     if ("CUSTOM_4".equals(permission)) {
/* 2186 */       return -9223372036854775808L;
/*      */     }
/* 2188 */     if ("READ".equals(permission))
/*      */     {
/* 2190 */       return 1L;
/*      */     }
/* 2192 */     if ("CATEGORY_ADMIN".equals(permission))
/*      */     {
/* 2195 */       return 256L;
/*      */     }
/* 2197 */     if ("CREATE_ATTACHMENT".equals(permission))
/*      */     {
/* 2200 */       return 8L;
/*      */     }
/* 2202 */     if ("MODERATE_MESSAGES".equals(permission))
/*      */     {
/* 2205 */       return 128L;
/*      */     }
/* 2207 */     if ("MODERATE_THREADS".equals(permission))
/*      */     {
/* 2210 */       return 128L;
/*      */     }
/*      */ 
/* 2213 */     throw new IllegalArgumentException("not auth type --> " + permission);
/*      */   }
/*      */ 
/*      */   private static PermissionType getPermissionType(String permissionType)
/*      */   {
/* 2226 */     if ("NEGATIVE".equals(permissionType)) {
/* 2227 */       return PermissionType.NEGATIVE;
/*      */     }
/*      */ 
/* 2230 */     return PermissionType.ADDITIVE;
/*      */   }
/*      */ 
/*      */   private static Date parseDate(String dateText)
/*      */   {
/*      */     try
/*      */     {
/* 2240 */       return dateFormatter.parse(dateText);
/*      */     } catch (ParseException pe) {
/*      */     }
/* 2243 */     return new Date();
/*      */   }
/*      */ 
/*      */   public static void main(String[] args)
/*      */   {
/* 2261 */     Options options = new Options();
/*      */ 
/* 2263 */     Option o = new Option("username", true, "required - the username to export with with");
/* 2264 */     o.setRequired(true);
/* 2265 */     options.addOption(o);
/*      */ 
/* 2267 */     o = new Option("password", true, "required - the user's password");
/* 2268 */     o.setRequired(true);
/* 2269 */     options.addOption(o);
/*      */ 
/* 2271 */     o = new Option("input", true, "required - the output file");
/* 2272 */     o.setRequired(true);
/* 2273 */     options.addOption(o);
/*      */ 
/* 2276 */     CommandLineParser commandLineParser = new BasicParser();
/* 2277 */     CommandLine cli = null;
/*      */ 
/* 2279 */     boolean isError = false;
/*      */     try
/*      */     {
/* 2282 */       cli = commandLineParser.parse(options, args);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2286 */       System.err.println(e.getMessage());
/*      */     }
/*      */ 
/* 2290 */     if ((isError) || (cli == null)) {
/* 2291 */       usageAndExit(options);
/*      */     }
/*      */ 
/* 2294 */     String username = cli.getOptionValue("username");
/* 2295 */     String password = cli.getOptionValue("password");
/* 2296 */     String input = cli.getOptionValue("input");
/*      */ 
/* 2298 */     AuthToken authToken = null;
/*      */     try {
/* 2300 */       authToken = AuthFactory.getAuthToken(username, password);
/*      */     }
/*      */     catch (UnauthorizedException e) {
/* 2303 */       System.err.println("Error authenicating user " + username + ". " + "Please make sure you're using the correct username and " + "password.");
/*      */ 
/* 2306 */       System.exit(1);
/*      */     }
/*      */ 
/* 2310 */     Log.debug("Starting importer in standalone mode");
/* 2311 */     System.out.println("Starting importer in standalone mode");
/*      */ 
/* 2314 */     long time = 0L;
/*      */     try
/*      */     {
/* 2317 */       ForumFactory forumFactory = ForumFactory.getInstance(authToken);
/* 2318 */       DbDataImport importer = new DbDataImport(forumFactory, new File(input));
/* 2319 */       time = System.currentTimeMillis();
/* 2320 */       importer.doRun();
/* 2321 */       time = System.currentTimeMillis() - time;
/*      */     }
/*      */     catch (Exception e) {
/* 2324 */       Log.error(e);
/*      */     }
/* 2326 */     Log.info("Finished import.");
/* 2327 */     Log.info("--------------------------------");
/* 2328 */     Log.info("Total time: " + time / 1000.0D + " seconds");
/* 2329 */     System.out.println("Finished import.");
/* 2330 */     System.out.println("--------------------------------");
/* 2331 */     System.out.println("Total time: " + time / 1000.0D + " seconds");
/* 2332 */     System.exit(0);
/*      */   }
/*      */ 
/*      */   private static void usageAndExit(Options options) {
/* 2336 */     printNameAndVersion();
/* 2337 */     HelpFormatter formatter = new HelpFormatter();
/* 2338 */     formatter.printHelp("java -classpath=[jive classpath] -DjavaHome=[javaHome]  com.jivesoftware.forum.database.DbDataImport -username <name> -password <password> -input <xml file>\n ", options);
/*      */ 
/* 2343 */     System.exit(1);
/*      */   }
/*      */ 
/*      */   private static void printNameAndVersion() {
/* 2347 */     System.out.println("\n");
/* 2348 */     String fullName = NAME;
/* 2349 */     System.out.println(fullName);
/* 2350 */     for (int i = 0; i < fullName.length(); i++) {
/* 2351 */       System.out.print('_');
/*      */     }
/* 2353 */     System.out.print("\n");
/* 2354 */     System.out.println("\n");
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*      */     try
/*      */     {
/*   67 */       factory = XmlPullParserFactory.newInstance("org.xmlpull.mxp1.MXParserFactory", null);
/*      */     }
/*      */     catch (Exception e) {
/*   70 */       Log.error(e);
/*      */     }
/*      */ 
/*   79 */     handlerMap.put("PropertyList", new PropertyListHandler(null));
/*   80 */     handlerMap.put("MemberList", new GroupMemberHandler());
/*   81 */     handlerMap.put("AdministratorList", new GroupAdministratorHandler());
/*   82 */     handlerMap.put("JivePropertyList", new JivePropertyListHandler(null));
/*   83 */     handlerMap.put("PrivateMessage", new PrivateMessageHandler());
/*      */ 
/*   87 */     handlerMap.put("Jive", JiveHandler.class);
/*   88 */     handlerMap.put("User", UserHandler.class);
/*   89 */     handlerMap.put("Group", GroupHandler.class);
/*   90 */     handlerMap.put("UserPermission", UserPermissionHandler.class);
/*   91 */     handlerMap.put("GroupPermission", GroupPermissionHandler.class);
/*   92 */     handlerMap.put("Category", CategoryHandler.class);
/*   93 */     handlerMap.put("Forum", ForumHandler.class);
/*   94 */     handlerMap.put("Thread", ThreadHandler.class);
/*   95 */     handlerMap.put("Message", MessageHandler.class);
/*   96 */     handlerMap.put("Poll", PollHandler.class);
/*   97 */     handlerMap.put("Announcement", AnnouncmentHandler.class);
/*   98 */     handlerMap.put("FolderList", FolderListHandler.class);
/*   99 */     handlerMap.put("Folder", FolderHandler.class);
/*  100 */     handlerMap.put("Attachment", AttachmentHandler.class);
/*      */   }
/*      */ 
/*      */   static class AttachmentHandler
/*      */     implements DbDataImport.Handler, DbDataImport.PropertyAddable
/*      */   {
/*      */     private HashMap properties;
/*      */     private Attachment attachment;
/*      */     private String contentType;
/*      */     private String id;
/*      */     private String name;
/*      */     private Date creationDate;
/*      */     private Date modifiedDate;
/*      */     private DbDataImport importer;
/*      */ 
/*      */     public AttachmentHandler()
/*      */     {
/* 1892 */       this.properties = new HashMap();
/*      */     }
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/* 1898 */       this.importer = importer;
/*      */ 
/* 1901 */       int depth = xpp.getDepth();
/* 1902 */       while ((!"AttachmentList".equals(xpp.getName())) && (!DbDataImport.isEndTag("Attachment", depth, xpp)))
/*      */       {
/* 1904 */         if (2 == xpp.getEventType())
/*      */         {
/* 1906 */           if ("Attachment".equals(xpp.getName())) {
/* 1907 */             this.id = xpp.getAttributeValue(null, "id");
/* 1908 */             this.contentType = xpp.getAttributeValue(null, "contentType");
/*      */           }
/*      */ 
/* 1911 */           if ("Name".equals(xpp.getName())) {
/* 1912 */             this.name = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/* 1914 */           else if ("CreationDate".equals(xpp.getName())) {
/* 1915 */             this.creationDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/* 1917 */           else if ("ModifiedDate".equals(xpp.getName())) {
/* 1918 */             this.modifiedDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/* 1920 */           else if ("PropertyList".equals(xpp.getName())) {
/* 1921 */             DbDataImport.executeHandler(this, xpp, importer);
/*      */           }
/*      */           else
/* 1924 */             xpp.next();
/*      */         }
/*      */         else
/*      */         {
/* 1928 */           xpp.next();
/*      */         }
/*      */       }
/*      */       try {
/* 1932 */         if ((parent instanceof DbDataImport.MessageHandler)) {
/* 1933 */           DbDataImport.MessageHandler parentHandler = (DbDataImport.MessageHandler)parent;
/*      */ 
/* 1935 */           if ((this.contentType == null) || ("".equals(this.contentType))) {
/* 1936 */             this.contentType = resolveContentType(this.name);
/*      */           }
/*      */ 
/* 1939 */           InputStream data = getAttachmentData(this.id);
/* 1940 */           this.attachment = DbDataImport.MessageHandler.access$1500(parentHandler).createAttachment(this.name, this.contentType, data);
/*      */         }
/*      */         else
/*      */         {
/* 1944 */           throw new IllegalStateException("parent Handler must be of type MessageHandler  not --> " + parent.getClass().getName());
/*      */         }
/*      */ 
/* 1949 */         for (i = this.properties.keySet().iterator(); i.hasNext(); ) {
/* 1950 */           String key = (String)i.next();
/* 1951 */           String value = (String)this.properties.get(key);
/* 1952 */           if (value != null)
/* 1953 */             this.attachment.setProperty(key, value);
/*      */         }
/*      */       }
/*      */       catch (UnauthorizedException ue)
/*      */       {
/*      */         Iterator i;
/* 1958 */         Log.error(ue);
/*      */       }
/*      */       catch (AttachmentException ae) {
/* 1961 */         Log.error(ae);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void addProperty(String name, String value) {
/* 1966 */       this.properties.put(name, value);
/*      */     }
/*      */ 
/*      */     public InputStream getAttachmentData(String id) throws IOException {
/* 1970 */       File file = new File(this.importer.attachmentDirectory, id + ".bin");
/* 1971 */       return new BufferedInputStream(new FileInputStream(file));
/*      */     }
/*      */ 
/*      */     public String resolveContentType(String filename) {
/* 1975 */       String contentType = DbDataImport.typeMap.getContentType(filename.toLowerCase());
/* 1976 */       Log.debug("Found content type of: " + contentType + " for filename: " + filename);
/*      */ 
/* 1978 */       if (contentType == null) {
/* 1979 */         contentType = "application/octet-stream";
/*      */       }
/* 1981 */       return contentType;
/*      */     }
/*      */   }
/*      */ 
/*      */   static class PrivateMessageHandler
/*      */     implements DbDataImport.Handler
/*      */   {
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/* 1797 */       String subject = null;
/* 1798 */       String body = null;
/* 1799 */       User sender = null;
/* 1800 */       User recipient = null;
/* 1801 */       Date creationDate = null;
/*      */ 
/* 1803 */       int depth = xpp.getDepth();
/* 1804 */       while (!DbDataImport.isEndTag("PrivateMessage", depth, xpp))
/*      */       {
/* 1806 */         if (2 == xpp.getEventType())
/*      */         {
/* 1808 */           if ("Subject".equals(xpp.getName())) {
/* 1809 */             subject = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/* 1811 */           else if ("Body".equals(xpp.getName())) {
/* 1812 */             body = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/* 1814 */           else if ("Sender".equals(xpp.getName())) {
/* 1815 */             String username = StringUtils.unescapeFromXML(xpp.nextText());
/*      */             try
/*      */             {
/* 1818 */               sender = importer.forumFactory.getUserManager().getUser(username);
/*      */             }
/*      */             catch (UserNotFoundException e)
/*      */             {
/*      */             }
/*      */           }
/* 1824 */           else if ("Recipient".equals(xpp.getName())) {
/* 1825 */             String username = StringUtils.unescapeFromXML(xpp.nextText());
/*      */             try
/*      */             {
/* 1828 */               recipient = importer.forumFactory.getUserManager().getUser(username);
/*      */             }
/*      */             catch (UserNotFoundException e)
/*      */             {
/*      */             }
/*      */ 
/*      */           }
/* 1835 */           else if ("CreationDate".equals(xpp.getName())) {
/* 1836 */             creationDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/*      */           else {
/* 1839 */             xpp.next();
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1844 */           xpp.next();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/* 1852 */         DbPrivateMessage msg = new DbPrivateMessage(sender);
/*      */ 
/* 1854 */         msg.setBody(body);
/* 1855 */         msg.setSubject(subject);
/* 1856 */         msg.setDate(creationDate);
/* 1857 */         if (recipient != null) {
/* 1858 */           msg.setRecipient(recipient);
/*      */         }
/* 1860 */         msg.insertIntoDb();
/*      */ 
/* 1863 */         DbDataImport.FolderHandler folderHandler = (DbDataImport.FolderHandler)parent;
/* 1864 */         msg.setFolder(folderHandler.getFolder());
/*      */       }
/*      */       catch (UnauthorizedException e)
/*      */       {
/*      */       }
/*      */       catch (SQLException e)
/*      */       {
/* 1871 */         Log.error(e);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class FolderHandler
/*      */     implements DbDataImport.Handler
/*      */   {
/*      */     private PrivateMessageFolder folder;
/*      */ 
/*      */     public PrivateMessageFolder getFolder()
/*      */     {
/* 1712 */       return this.folder;
/*      */     }
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/* 1719 */       int depth = xpp.getDepth();
/*      */ 
/* 1724 */       String name = null;
/*      */ 
/* 1726 */       xpp.next();
/* 1727 */       while ((!DbDataImport.isEndTag("Folder", depth, xpp)) && (!"PrivateMessageList".equals(xpp.getName())))
/*      */       {
/* 1729 */         if (2 == xpp.getEventType())
/*      */         {
/* 1731 */           if ("Name".equals(xpp.getName())) {
/* 1732 */             name = xpp.nextText();
/*      */           }
/*      */           else {
/* 1735 */             xpp.next();
/*      */           }
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1741 */           xpp.next();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1746 */       DbDataImport.FolderListHandler folderListHandler = (DbDataImport.FolderListHandler)parent;
/*      */ 
/* 1748 */       PrivateMessageManager privateMessageManager = importer.forumFactory.getPrivateMessageManager();
/*      */       try
/*      */       {
/* 1754 */         this.folder = privateMessageManager.createFolder(folderListHandler.getUser(), name);
/*      */       }
/*      */       catch (UnauthorizedException e) {
/* 1757 */         Log.error(e);
/*      */       }
/*      */ 
/* 1764 */       xpp.next();
/* 1765 */       while (!DbDataImport.isEndTag("Folder", depth, xpp))
/*      */       {
/* 1767 */         if (2 == xpp.getEventType())
/*      */         {
/* 1769 */           if ("PrivateMessage".equals(xpp.getName())) {
/* 1770 */             DbDataImport.executeHandler(this, xpp, importer);
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1775 */           xpp.next();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class FolderListHandler
/*      */     implements DbDataImport.Handler
/*      */   {
/*      */     private User user;
/*      */ 
/*      */     public User getUser()
/*      */     {
/* 1668 */       return this.user;
/*      */     }
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/* 1675 */       String username = StringUtils.unescapeFromXML(xpp.getAttributeValue(null, "username"));
/*      */       try
/*      */       {
/* 1678 */         this.user = importer.forumFactory.getUserManager().getUser(username);
/*      */       }
/*      */       catch (UserNotFoundException e) {
/* 1681 */         Log.warn("DbDataImporter#FolderListHandler could not find user --> " + username);
/*      */       }
/*      */ 
/* 1685 */       int depth = xpp.getDepth();
/*      */ 
/* 1687 */       xpp.next();
/* 1688 */       while (!DbDataImport.isEndTag("FolderList", depth, xpp))
/*      */       {
/* 1690 */         if (2 == xpp.getEventType())
/*      */         {
/* 1692 */           if ("Folder".equals(xpp.getName())) {
/* 1693 */             DbDataImport.executeHandler(this, xpp, importer);
/*      */           }
/*      */           else {
/* 1696 */             xpp.next();
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1701 */           xpp.next();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class AnnouncmentHandler
/*      */     implements DbDataImport.Handler
/*      */   {
/*      */     private int objectType;
/*      */     private long objectId;
/*      */     private User user;
/*      */     private String subject;
/*      */     private String body;
/*      */     private Date startDate;
/*      */     private Date endDate;
/*      */     private int depth;
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/* 1524 */       this.depth = xpp.getDepth();
/*      */ 
/* 1526 */       getValues(xpp, importer);
/* 1527 */       getObjectType(parent, importer);
/*      */ 
/* 1529 */       AnnouncementManager announcementManager = importer.forumFactory.getAnnouncementManager();
/*      */ 
/* 1532 */       if (this.user == null)
/*      */       {
/*      */         try
/*      */         {
/* 1536 */           this.user = importer.forumFactory.getUserManager().getUser(1L);
/*      */         }
/*      */         catch (Exception e) {
/* 1539 */           Log.error(e);
/*      */         }
/*      */       }
/*      */       try
/*      */       {
/*      */         Announcement announcement;
/* 1546 */         switch (this.objectType) {
/*      */         case 0:
/* 1548 */           Forum forum = importer.forumFactory.getForum(this.objectId);
/* 1549 */           announcement = announcementManager.createAnnouncement(this.user, forum);
/* 1550 */           break;
/*      */         case 14:
/* 1553 */           ForumCategory category = importer.forumFactory.getForumCategory(this.objectId);
/* 1554 */           announcement = announcementManager.createAnnouncement(this.user, category);
/* 1555 */           break;
/*      */         case 17:
/* 1558 */           announcement = announcementManager.createAnnouncement(this.user);
/* 1559 */           break;
/*      */         default:
/* 1562 */           throw new IllegalArgumentException("unsupported object type " + this.objectType);
/*      */         }
/*      */ 
/* 1565 */         announcement.setSubject(this.subject);
/* 1566 */         announcement.setBody(this.body);
/* 1567 */         announcement.setStartDate(this.startDate);
/* 1568 */         announcement.setEndDate(this.endDate);
/*      */ 
/* 1570 */         announcementManager.addAnnouncement(announcement);
/*      */       }
/*      */       catch (UnauthorizedException e)
/*      */       {
/* 1574 */         Log.error(e);
/*      */       }
/*      */       catch (ForumNotFoundException fe) {
/* 1577 */         Log.error(fe);
/*      */       }
/*      */       catch (ForumCategoryNotFoundException fce) {
/* 1580 */         Log.error(fce);
/*      */       }
/*      */     }
/*      */ 
/*      */     private void getValues(XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/* 1589 */       xpp.next();
/* 1590 */       while (!DbDataImport.isEndTag("Announcement", this.depth, xpp))
/*      */       {
/* 1593 */         if (xpp.getEventType() == 2)
/*      */         {
/* 1595 */           if ("Username".equals(xpp.getName())) {
/* 1596 */             String username = StringUtils.unescapeFromXML(xpp.nextText());
/*      */             try
/*      */             {
/* 1599 */               this.user = importer.forumFactory.getUserManager().getUser(username);
/*      */             }
/*      */             catch (UserNotFoundException e) {
/* 1602 */               Log.error(e);
/*      */             }
/*      */ 
/*      */           }
/* 1606 */           else if ("Subject".equals(xpp.getName())) {
/* 1607 */             this.subject = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/* 1610 */           else if ("Body".equals(xpp.getName())) {
/* 1611 */             this.body = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/* 1614 */           else if ("StartDate".equals(xpp.getName())) {
/* 1615 */             this.startDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/* 1618 */           else if ("EndDate".equals(xpp.getName())) {
/* 1619 */             this.endDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/*      */           else
/*      */           {
/* 1623 */             xpp.next();
/*      */           }
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1629 */           xpp.next();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private void getObjectType(Object parent, DbDataImport importer) {
/* 1635 */       if ((parent instanceof DbDataImport.JiveHandler)) {
/* 1636 */         this.objectType = 17;
/* 1637 */         this.objectId = -1L;
/*      */       }
/* 1640 */       else if ((parent instanceof DbDataImport.ForumHandler)) {
/* 1641 */         this.objectType = 0;
/* 1642 */         this.objectId = importer.forum.getID();
/*      */       }
/* 1645 */       else if ((parent instanceof DbDataImport.CategoryHandler)) {
/* 1646 */         this.objectType = 14;
/*      */ 
/* 1648 */         DbDataImport.CategoryHandler ch = (DbDataImport.CategoryHandler)parent;
/* 1649 */         this.objectId = ch.getForumCategory().getID();
/*      */       }
/*      */       else {
/* 1652 */         throw new IllegalArgumentException("bad parent --> " + parent);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static final class PollHandler
/*      */     implements DbDataImport.Handler
/*      */   {
/*      */     int depth;
/*      */     private long objectId;
/*      */     private int objectType;
/*      */     private User user;
/*      */     private Date startDate;
/*      */     private Date endDate;
/*      */     private Date expireDate;
/*      */     private String description;
/*      */     private String name;
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/* 1208 */       this.depth = xpp.getDepth();
/*      */ 
/* 1210 */       PollManager pollManager = importer.forumFactory.getPollManager();
/*      */ 
/* 1212 */       getField(xpp, importer);
/* 1213 */       getObjectType(parent, importer);
/*      */       try
/*      */       {
/* 1217 */         if (this.user == null)
/*      */         {
/*      */           try
/*      */           {
/* 1221 */             this.user = importer.forumFactory.getUserManager().getUser(1L);
/*      */           }
/*      */           catch (Exception e) {
/* 1224 */             Log.error(e);
/*      */           }
/*      */         }
/*      */ 
/* 1228 */         Poll poll = pollManager.createPoll(this.objectType, this.objectId, this.user, this.name);
/*      */ 
/* 1231 */         poll.setDescription(this.description != null ? this.description : "");
/*      */ 
/* 1233 */         poll.setStartDate(this.startDate);
/*      */ 
/* 1238 */         while (!DbDataImport.isEndTag("Poll", this.depth, xpp))
/*      */         {
/* 1240 */           if (xpp.getEventType() == 2) {
/* 1241 */             if ("PollMode".equals(xpp.getName())) {
/* 1242 */               long value = getPollMode(xpp.getAttributeValue(null, "mode"));
/* 1243 */               poll.setMode(value, true);
/* 1244 */               xpp.next();
/*      */             }
/* 1247 */             else if ("PollOptionList".equals(xpp.getName())) {
/* 1248 */               populateOptions(poll, xpp);
/*      */             }
/* 1251 */             else if ("PollVoteList".equals(xpp.getName())) {
/*      */               try {
/* 1253 */                 populateVotes(poll, xpp, importer);
/*      */               }
/*      */               catch (PollException pe) {
/* 1256 */                 Log.error(pe);
/*      */               }
/*      */             }
/*      */             else {
/* 1260 */               xpp.next();
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 1265 */             xpp.next();
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1270 */         poll.setEndDate(this.endDate);
/* 1271 */         poll.setExpirationDate(this.expireDate);
/*      */       }
/*      */       catch (UnauthorizedException ue)
/*      */       {
/* 1276 */         Log.error(ue);
/*      */       }
/*      */     }
/*      */ 
/*      */     private void populateOptions(Poll poll, XmlPullParser xpp)
/*      */       throws XmlPullParserException, IOException, UnauthorizedException
/*      */     {
/* 1289 */       int pollOptionListDepth = xpp.getDepth();
/*      */ 
/* 1291 */       while ((!DbDataImport.isEndTag("Poll", this.depth, xpp)) && (!DbDataImport.isEndTag("PollOptionList", pollOptionListDepth, xpp)))
/*      */       {
/* 1294 */         if (xpp.getEventType() == 2) {
/* 1295 */           if ("PollOption".equals(xpp.getName()))
/*      */           {
/* 1297 */             int index = Integer.parseInt(xpp.getAttributeValue(null, "index"));
/*      */ 
/* 1299 */             String text = xpp.nextText();
/*      */ 
/* 1301 */             poll.setOption(index, text);
/*      */           }
/*      */           else
/*      */           {
/* 1305 */             xpp.next();
/*      */           }
/*      */         }
/*      */         else
/* 1309 */           xpp.next();
/*      */       }
/*      */     }
/*      */ 
/*      */     private void populateVotes(Poll poll, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException, PollException
/*      */     {
/* 1321 */       int pollVoteListDepth = xpp.getDepth();
/*      */ 
/* 1323 */       while ((!DbDataImport.isEndTag("Poll", this.depth, xpp)) && (!DbDataImport.isEndTag("PollVoteList", pollVoteListDepth, xpp)))
/*      */       {
/* 1326 */         if (xpp.getEventType() == 2) {
/* 1327 */           if ("PollVote".equals(xpp.getName())) {
/* 1328 */             populateVote(poll, xpp, importer);
/*      */           }
/*      */           else {
/* 1331 */             xpp.next();
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1336 */           xpp.next();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private void populateVote(Poll poll, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException, PollException
/*      */     {
/* 1352 */       int poleVoteDepth = xpp.getDepth();
/*      */ 
/* 1355 */       int index = Integer.parseInt(xpp.getAttributeValue(null, "index")) - 1;
/*      */ 
/* 1360 */       User voter = null;
/* 1361 */       String guestId = null;
/*      */ 
/* 1363 */       Date createDate = null;
/*      */ 
/* 1365 */       while (!DbDataImport.isEndTag("PollVote", poleVoteDepth, xpp))
/*      */       {
/* 1367 */         if (xpp.getEventType() == 2)
/*      */         {
/* 1369 */           if ("Username".equals(xpp.getName())) {
/* 1370 */             String username = StringUtils.unescapeFromXML(xpp.nextText());
/*      */             try
/*      */             {
/* 1373 */               voter = importer.forumFactory.getUserManager().getUser(username);
/*      */             }
/*      */             catch (UserNotFoundException e) {
/* 1376 */               Log.error(e);
/*      */             }
/*      */           }
/* 1379 */           else if ("Guest".equals(xpp.getName()))
/*      */           {
/* 1381 */             guestId = StringUtils.unescapeFromXML(xpp.getAttributeValue(null, "id"));
/* 1382 */             xpp.next();
/*      */           }
/* 1385 */           else if ("CreationDate".equals(xpp.getName()))
/*      */           {
/* 1387 */             createDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/*      */           else
/*      */           {
/* 1391 */             xpp.next();
/*      */           }
/*      */         }
/*      */         else {
/* 1395 */           xpp.next();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1401 */       DbPoll dbPoll = (DbPoll)PollManagerFactory.pollCache.get(new Long(poll.getID()));
/*      */ 
/* 1403 */       if (voter != null) {
/* 1404 */         dbPoll.addUserVote(index, voter, createDate);
/*      */       }
/*      */       else
/* 1407 */         dbPoll.addAnonymousVote(index, guestId, createDate);
/*      */     }
/*      */ 
/*      */     private void getField(XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/* 1418 */       xpp.next();
/* 1419 */       while ((!DbDataImport.isEndTag("Poll", this.depth, xpp)) && (!"PollModeList".equals(xpp.getName())))
/*      */       {
/* 1421 */         if (xpp.getEventType() == 2)
/*      */         {
/* 1423 */           if ("Username".equals(xpp.getName()))
/*      */           {
/* 1426 */             String username = StringUtils.unescapeFromXML(xpp.nextText());
/*      */             try {
/* 1428 */               this.user = importer.forumFactory.getUserManager().getUser(username);
/*      */             }
/*      */             catch (UserNotFoundException e) {
/* 1431 */               Log.error(e);
/*      */             }
/*      */ 
/*      */           }
/* 1435 */           else if ("Description".equals(xpp.getName())) {
/* 1436 */             this.description = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/* 1439 */           else if ("Name".equals(xpp.getName())) {
/* 1440 */             this.name = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/* 1443 */           else if ("StartDate".equals(xpp.getName())) {
/* 1444 */             this.startDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/* 1447 */           else if ("EndDate".equals(xpp.getName())) {
/* 1448 */             this.endDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/* 1451 */           else if ("ExpireDate".equals(xpp.getName())) {
/* 1452 */             this.expireDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/*      */           else {
/* 1455 */             xpp.next();
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1460 */           xpp.next();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     private void getObjectType(Object parent, DbDataImport importer)
/*      */     {
/* 1467 */       if ((parent instanceof DbDataImport.JiveHandler)) {
/* 1468 */         this.objectType = 17;
/* 1469 */         this.objectId = -1L;
/*      */       }
/* 1472 */       else if ((parent instanceof DbDataImport.ForumHandler)) {
/* 1473 */         this.objectType = 0;
/* 1474 */         this.objectId = importer.forum.getID();
/*      */       }
/* 1477 */       else if ((parent instanceof DbDataImport.CategoryHandler)) {
/* 1478 */         this.objectType = 14;
/*      */ 
/* 1480 */         DbDataImport.CategoryHandler ch = (DbDataImport.CategoryHandler)parent;
/* 1481 */         this.objectId = ch.getForumCategory().getID();
/*      */       }
/* 1483 */       else if ((parent instanceof DbDataImport.ThreadHandler)) {
/* 1484 */         this.objectType = 1;
/* 1485 */         this.objectId = importer.thread.getID();
/*      */       }
/*      */       else {
/* 1488 */         throw new IllegalArgumentException("bad parent --> " + parent);
/*      */       }
/*      */     }
/*      */ 
/*      */     static long getPollMode(String s)
/*      */     {
/* 1494 */       if ("ALLOW_USER_VOTE_MODIFICATION".equals(s)) {
/* 1495 */         return 16L;
/*      */       }
/* 1497 */       if ("MULTIPLE_SELECTIONS_ALLOWED".equals(s)) {
/* 1498 */         return 256L;
/*      */       }
/* 1500 */       if ("ALLOW_ANONYMOUS_VOTE_MODIFICATION".equals(s)) {
/* 1501 */         return 32L;
/*      */       }
/*      */ 
/* 1504 */       throw new IllegalArgumentException("could not find poll mode --> " + s);
/*      */     }
/*      */   }
/*      */ 
/*      */   static class MessageHandler
/*      */     implements DbDataImport.Handler, DbDataImport.PropertyAddable
/*      */   {
/*      */     private HashMap properties;
/*      */     private ForumMessage message;
/*      */     private String subject;
/*      */     private String body;
/*      */     private String username;
/*      */     private Date creationDate;
/*      */     private Date modifiedDate;
/*      */     private MessageHandler parentMessageHandler;
/*      */     private DbDataImport importer;
/*      */ 
/*      */     public MessageHandler()
/*      */     {
/* 1061 */       this.properties = new HashMap();
/*      */     }
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/* 1067 */       this.importer = importer;
/*      */ 
/* 1070 */       int depth = xpp.getDepth();
/* 1071 */       xpp.next();
/* 1072 */       while ((!"MessageList".equals(xpp.getName())) && (!"AttachmentList".equals(xpp.getName())) && (!DbDataImport.isEndTag("Message", depth, xpp)))
/*      */       {
/* 1075 */         if (2 == xpp.getEventType())
/*      */         {
/* 1077 */           if ("Body".equals(xpp.getName())) {
/* 1078 */             this.body = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/* 1080 */           else if ("Subject".equals(xpp.getName())) {
/* 1081 */             this.subject = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/* 1084 */           else if ("Username".equals(xpp.getName())) {
/* 1085 */             this.username = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/* 1088 */           else if ("CreationDate".equals(xpp.getName())) {
/* 1089 */             this.creationDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/* 1092 */           else if ("ModifiedDate".equals(xpp.getName())) {
/* 1093 */             this.modifiedDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/*      */           else
/*      */           {
/* 1097 */             DbDataImport.executeHandler(this, xpp, importer);
/* 1098 */             xpp.next();
/*      */           }
/*      */         }
/*      */         else {
/* 1102 */           xpp.next();
/*      */         }
/*      */       }
/*      */       try
/*      */       {
/* 1107 */         this.message = createMessage();
/* 1108 */         if ((parent instanceof MessageHandler)) {
/* 1109 */           MessageHandler parentMessageHandler = (MessageHandler)parent;
/* 1110 */           this.parentMessageHandler = parentMessageHandler;
/*      */         }
/* 1112 */         else if (!(parent instanceof DbDataImport.ThreadHandler))
/*      */         {
/* 1114 */           throw new IllegalStateException("parent Handler must be of type MessageHandler or ThreadHandler not --> " + parent.getClass().getName());
/*      */         }
/*      */ 
/* 1119 */         for (Iterator i = this.properties.keySet().iterator(); i.hasNext(); ) {
/* 1120 */           String key = (String)i.next();
/* 1121 */           String value = (String)this.properties.get(key);
/* 1122 */           if (value != null) {
/* 1123 */             this.message.setProperty(key, value);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1128 */         if (this.parentMessageHandler == null) {
/* 1129 */           importer.thread = importer.forum.createThread(this.message);
/* 1130 */           importer.forum.addThread(importer.thread);
/*      */         }
/*      */         else {
/* 1133 */           importer.thread.addMessage(this.parentMessageHandler.message, this.message);
/*      */         }
/*      */ 
/* 1137 */         if ("MessageList".equals(xpp.getName())) {
/* 1138 */           DbDataImport.handleChildEvents(this, xpp, importer);
/*      */         }
/*      */ 
/* 1141 */         if ("AttachmentList".equals(xpp.getName())) {
/* 1142 */           DbDataImport.handleChildEvents(this, xpp, importer);
/*      */         }
/*      */       }
/*      */       catch (UnauthorizedException ue)
/*      */       {
/* 1147 */         Log.error(ue);
/*      */       }
/*      */       catch (MessageRejectedException mre) {
/* 1150 */         Log.error(mre);
/*      */       }
/*      */     }
/*      */ 
/*      */     private ForumMessage createMessage() throws UnauthorizedException
/*      */     {
/* 1156 */       User u = null;
/* 1157 */       boolean userNotFound = false;
/*      */       try {
/* 1159 */         u = this.importer.userManager.getUser(this.username);
/*      */       }
/*      */       catch (UserNotFoundException ue) {
/* 1162 */         userNotFound = true;
/*      */       }
/*      */       ForumMessage forumMessage;
/*      */       ForumMessage forumMessage;
/* 1167 */       if (u != null) {
/* 1168 */         forumMessage = this.importer.forum.createMessage(u);
/*      */       }
/*      */       else {
/* 1171 */         forumMessage = this.importer.forum.createMessage();
/*      */       }
/* 1173 */       forumMessage.setBody(this.body);
/* 1174 */       forumMessage.setCreationDate(this.creationDate);
/* 1175 */       forumMessage.setModificationDate(this.modifiedDate);
/* 1176 */       forumMessage.setSubject(this.subject);
/*      */ 
/* 1178 */       if ((userNotFound) && (this.username != null) && (!"".equals(this.username.trim()))) {
/* 1179 */         forumMessage.setProperty("user", this.username);
/*      */       }
/* 1181 */       return forumMessage;
/*      */     }
/*      */ 
/*      */     public void addProperty(String name, String value)
/*      */     {
/* 1186 */       this.properties.put(name, value);
/*      */     }
/*      */   }
/*      */ 
/*      */   static class ThreadHandler
/*      */     implements DbDataImport.Handler, DbDataImport.PropertyAddable
/*      */   {
/*      */     private Date creationDate;
/*      */     private Date modifiedDate;
/*      */     private HashMap properties;
/*      */ 
/*      */     public ThreadHandler()
/*      */     {
/*  981 */       this.properties = new HashMap();
/*      */     }
/*      */ 
/*      */     public void addProperty(String name, String value) {
/*  985 */       this.properties.put(name, value);
/*      */     }
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/*  991 */       int depth = xpp.getDepth();
/*      */ 
/*  993 */       xpp.next();
/*  994 */       while (!DbDataImport.isEndTag("Thread", depth, xpp))
/*      */       {
/*  996 */         if (2 == xpp.getEventType())
/*      */         {
/*  998 */           if ("CreationDate".equals(xpp.getName())) {
/*  999 */             this.creationDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/* 1002 */           else if ("ModifiedDate".equals(xpp.getName())) {
/* 1003 */             this.modifiedDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/* 1006 */           else if ("Message".equals(xpp.getName())) {
/* 1007 */             DbDataImport.executeHandler(this, xpp, importer);
/*      */           }
/* 1009 */           else if ("Poll".equals(xpp.getName())) {
/* 1010 */             DbDataImport.executeHandler(this, xpp, importer);
/*      */           }
/*      */           else {
/* 1013 */             xpp.next();
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1018 */           xpp.next();
/*      */         }
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/* 1024 */         importer.thread.setCreationDate(this.creationDate);
/* 1025 */         importer.thread.setModificationDate(this.modifiedDate);
/*      */ 
/* 1028 */         for (i = this.properties.keySet().iterator(); i.hasNext(); ) {
/* 1029 */           String key = (String)i.next();
/* 1030 */           String value = (String)this.properties.get(key);
/* 1031 */           if (value != null)
/* 1032 */             importer.thread.setProperty(key, value);
/*      */         }
/*      */       }
/*      */       catch (UnauthorizedException ue)
/*      */       {
/*      */         Iterator i;
/* 1038 */         Log.error(ue);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class GroupPermissionHandler
/*      */     implements DbDataImport.Handler
/*      */   {
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/*  944 */       DbDataImport.PermissionsManagerGettable upa = (DbDataImport.PermissionsManagerGettable)parent;
/*  945 */       PermissionsManager permissionsManager = upa.getPermissionsManager();
/*      */ 
/*  948 */       String groupname = xpp.getAttributeValue(null, "groupname");
/*  949 */       long permission = DbDataImport.getPermission(xpp.getAttributeValue(null, "permission"));
/*  950 */       PermissionType permissionType = DbDataImport.getPermissionType(xpp.getAttributeValue(null, "permissiontype"));
/*      */       try
/*      */       {
/*  956 */         Group group = null;
/*      */ 
/*  958 */         group = importer.groupManager.getGroup(groupname);
/*  959 */         permissionsManager.addGroupPermission(group, permissionType, permission);
/*      */       }
/*      */       catch (GroupNotFoundException gfe)
/*      */       {
/*  963 */         Log.warn("could not find group with name " + groupname + " won't add permission");
/*      */       }
/*      */       catch (UnauthorizedException ue) {
/*  966 */         Log.warn(ue);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class UserPermissionHandler
/*      */     implements DbDataImport.Handler
/*      */   {
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/*  900 */       DbDataImport.PermissionsManagerGettable upa = (DbDataImport.PermissionsManagerGettable)parent;
/*      */ 
/*  902 */       PermissionsManager permissionsManager = upa.getPermissionsManager();
/*      */ 
/*  904 */       String usertype = xpp.getAttributeValue(null, "usertype");
/*  905 */       String username = StringUtils.unescapeFromXML(xpp.getAttributeValue(null, "username"));
/*  906 */       long permission = DbDataImport.getPermission(xpp.getAttributeValue(null, "permission"));
/*  907 */       PermissionType permissionType = DbDataImport.getPermissionType(xpp.getAttributeValue(null, "permissiontype"));
/*      */       try
/*      */       {
/*  912 */         User user = null;
/*      */ 
/*  914 */         if (usertype.equals("ANONYMOUS")) {
/*  915 */           permissionsManager.addAnonymousUserPermission(permissionType, permission);
/*      */         }
/*  917 */         else if (usertype.equals("REGISTERED_USERS"))
/*  918 */           permissionsManager.addRegisteredUserPermission(permissionType, permission);
/*      */         else
/*      */           try
/*      */           {
/*  922 */             user = importer.userManager.getUser(username);
/*  923 */             permissionsManager.addUserPermission(user, permissionType, permission);
/*      */           }
/*      */           catch (UserNotFoundException unfe) {
/*  926 */             Log.warn("User '" + username + "' not found, won't add user permission");
/*      */           }
/*      */       }
/*      */       catch (UnauthorizedException ue)
/*      */       {
/*  931 */         Log.warn(ue);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class ForumHandler
/*      */     implements DbDataImport.Handler, DbDataImport.PropertyAddable, DbDataImport.PermissionsManagerGettable
/*      */   {
/*      */     private String name;
/*      */     private String description;
/*      */     private Date creationDate;
/*      */     private Date modifiedDate;
/*      */     private DbDataImport importer;
/*  785 */     private DbDataImport.CategoryHandler categoryHandler = null;
/*      */     private HashMap properties;
/*      */ 
/*      */     public ForumHandler()
/*      */     {
/*  790 */       this.properties = new HashMap();
/*      */     }
/*      */ 
/*      */     public void addProperty(String name, String value) {
/*  794 */       this.properties.put(name, value);
/*      */     }
/*      */ 
/*      */     public PermissionsManager getPermissionsManager() {
/*      */       try {
/*  799 */         return this.importer.forum.getPermissionsManager();
/*      */       }
/*      */       catch (UnauthorizedException uae) {
/*  802 */         Log.error(uae);
/*      */       }
/*  804 */       throw new IllegalStateException("not permissions manager!");
/*      */     }
/*      */ 
/*      */     public void setModifiedDate(Date modifiedDate) {
/*  808 */       this.modifiedDate = modifiedDate;
/*      */     }
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/*  814 */       this.importer = importer;
/*      */ 
/*  816 */       if ((parent instanceof DbDataImport.CategoryHandler)) {
/*  817 */         this.categoryHandler = ((DbDataImport.CategoryHandler)parent);
/*      */       }
/*      */ 
/*  821 */       int depth = xpp.getDepth();
/*  822 */       xpp.next();
/*      */ 
/*  824 */       while ((!"PermissionList".equals(xpp.getName())) && (!"ThreadList".equals(xpp.getName())) && (!DbDataImport.isEndTag("Forum", depth, xpp)))
/*      */       {
/*  826 */         if (2 == xpp.getEventType())
/*      */         {
/*  828 */           if ("Name".equals(xpp.getName())) {
/*  829 */             this.name = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/*  831 */           else if ("Description".equals(xpp.getName())) {
/*  832 */             this.description = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/*  835 */           else if ("CreationDate".equals(xpp.getName())) {
/*  836 */             this.creationDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/*  839 */           else if ("ModifiedDate".equals(xpp.getName())) {
/*  840 */             this.modifiedDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/*      */           else
/*      */           {
/*  844 */             DbDataImport.executeHandler(this, xpp, importer);
/*  845 */             xpp.next();
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  850 */           xpp.next();
/*      */         }
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/*  856 */         if (this.categoryHandler != null) {
/*  857 */           importer.forum = importer.forumFactory.createForum(this.name, this.description, this.categoryHandler.getForumCategory());
/*      */         }
/*      */         else
/*      */         {
/*  862 */           importer.forum = importer.forumFactory.createForum(this.name, this.description);
/*      */         }
/*      */ 
/*  866 */         importer.forum.setCreationDate(this.creationDate);
/*  867 */         importer.forum.setModificationDate(this.modifiedDate);
/*      */ 
/*  870 */         for (Iterator i = this.properties.keySet().iterator(); i.hasNext(); ) {
/*  871 */           String key = (String)i.next();
/*  872 */           String value = (String)this.properties.get(key);
/*      */ 
/*  874 */           if ((value != null) && (!DbDataImport.PROPERTY_IGNORE_PATTERN.matcher(key).find())) {
/*  875 */             importer.forum.setProperty(key, value);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  880 */         while (!DbDataImport.isEndTag("Forum", depth, xpp)) {
/*  881 */           DbDataImport.executeHandler(this, xpp, importer);
/*  882 */           xpp.next();
/*      */         }
/*      */       }
/*      */       catch (Exception e) {
/*  886 */         Log.error("Error creating forum", e);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class CategoryHandler
/*      */     implements DbDataImport.Handler, DbDataImport.PropertyAddable, DbDataImport.PermissionsManagerGettable
/*      */   {
/*      */     private ForumCategory forumCategory;
/*      */     private HashMap properties;
/*      */     private CategoryHandler parentCategoryHandler;
/*      */     private String name;
/*      */     private String description;
/*      */     private Date creationDate;
/*      */     private Date modifiedDate;
/*      */ 
/*      */     public CategoryHandler()
/*      */     {
/*  665 */       this.properties = new HashMap();
/*      */     }
/*      */ 
/*      */     public ForumCategory getForumCategory() {
/*  669 */       return this.forumCategory;
/*      */     }
/*      */ 
/*      */     public void addProperty(String name, String value) {
/*  673 */       this.properties.put(name, value);
/*      */     }
/*      */ 
/*      */     public PermissionsManager getPermissionsManager()
/*      */     {
/*      */       try {
/*  679 */         return this.forumCategory.getPermissionsManager();
/*      */       }
/*      */       catch (UnauthorizedException uae) {
/*  682 */         Log.error(uae);
/*      */       }
/*  684 */       throw new IllegalStateException("not permissions manager!");
/*      */     }
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/*  690 */       if ((parent instanceof CategoryHandler)) {
/*  691 */         this.parentCategoryHandler = ((CategoryHandler)parent);
/*      */       }
/*      */ 
/*  694 */       int depth = xpp.getDepth();
/*      */ 
/*  696 */       xpp.next();
/*      */ 
/*  699 */       while ((!"ForumList".equals(xpp.getName())) && (!"CategoryList".equals(xpp.getName())) && (!"PermissionList".equals(xpp.getName())) && (!DbDataImport.isEndTag("Category", depth, xpp)))
/*      */       {
/*  702 */         if (2 == xpp.getEventType())
/*      */         {
/*  704 */           if ("Name".equals(xpp.getName())) {
/*  705 */             this.name = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/*  707 */           else if ("Description".equals(xpp.getName())) {
/*  708 */             this.description = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/*  710 */           else if ("CreationDate".equals(xpp.getName())) {
/*  711 */             this.creationDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/*  714 */           else if ("ModifiedDate".equals(xpp.getName())) {
/*  715 */             this.modifiedDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/*      */           else
/*      */           {
/*  719 */             DbDataImport.executeHandler(this, xpp, importer);
/*  720 */             xpp.next();
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  725 */           xpp.next();
/*      */         }
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/*  731 */         if (this.parentCategoryHandler != null) {
/*  732 */           this.forumCategory = this.parentCategoryHandler.getForumCategory().createCategory(this.name, this.description);
/*      */         }
/*      */         else
/*      */         {
/*  737 */           ForumCategory rootCategory = importer.forumFactory.getRootForumCategory();
/*  738 */           this.forumCategory = rootCategory.createCategory(this.name, this.description);
/*      */         }
/*      */ 
/*  741 */         this.forumCategory.setCreationDate(this.creationDate);
/*  742 */         this.forumCategory.setModificationDate(this.modifiedDate);
/*      */ 
/*  744 */         for (Iterator i = this.properties.keySet().iterator(); i.hasNext(); ) {
/*  745 */           String key = (String)i.next();
/*  746 */           String value = (String)this.properties.get(key);
/*      */ 
/*  748 */           if ((value != null) && (!DbDataImport.PROPERTY_IGNORE_PATTERN.matcher(key).find())) {
/*  749 */             this.forumCategory.setProperty(key, value);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  754 */         while (!DbDataImport.isEndTag("Category", depth, xpp))
/*      */         {
/*  756 */           if (xpp.getEventType() == 2) {
/*  757 */             DbDataImport.executeHandler(this, xpp, importer);
/*  758 */             xpp.next();
/*      */           }
/*      */           else {
/*  761 */             xpp.next();
/*      */           }
/*      */         }
/*      */ 
/*  765 */         Log.debug("CategoryHandler for Category " + this.name + " returning");
/*      */       }
/*      */       catch (UnauthorizedException ue) {
/*  768 */         Log.error(ue);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class GroupAdministratorHandler
/*      */     implements DbDataImport.Handler
/*      */   {
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/*  635 */       DbDataImport.GroupHandler groupHandler = (DbDataImport.GroupHandler)parent;
/*      */ 
/*  637 */       xpp.nextTag();
/*  638 */       while (!"AdministratorList".equals(xpp.getName()))
/*      */       {
/*  640 */         if (xpp.getEventType() == 2) {
/*  641 */           String userName = xpp.nextText();
/*  642 */           groupHandler.addAdmin(userName);
/*      */         }
/*      */ 
/*  645 */         xpp.nextTag();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class GroupMemberHandler
/*      */     implements DbDataImport.Handler
/*      */   {
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/*  611 */       DbDataImport.GroupHandler groupHandler = (DbDataImport.GroupHandler)parent;
/*      */ 
/*  613 */       xpp.nextTag();
/*  614 */       while (!"MemberList".equals(xpp.getName()))
/*      */       {
/*  616 */         if (xpp.getEventType() == 2) {
/*  617 */           String userName = xpp.nextText();
/*  618 */           groupHandler.addMember(userName);
/*      */         }
/*      */ 
/*  621 */         xpp.nextTag();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class GroupHandler
/*      */     implements DbDataImport.Handler, DbDataImport.PropertyAddable
/*      */   {
/*  471 */     private List memberList = new ArrayList();
/*  472 */     private List adminList = new ArrayList();
/*      */     private String name;
/*      */     private String description;
/*      */     private Date creationDate;
/*      */     private Date modifiedDate;
/*  479 */     private Map properties = null;
/*      */ 
/*      */     public GroupHandler() {
/*  482 */       this.properties = new HashMap();
/*  483 */       this.memberList = new ArrayList();
/*  484 */       this.adminList = new ArrayList();
/*      */     }
/*      */ 
/*      */     public void addProperty(String name, String value) {
/*  488 */       this.properties.put(name, value);
/*      */     }
/*      */ 
/*      */     public void addMember(String member) {
/*  492 */       this.memberList.add(member);
/*      */     }
/*      */ 
/*      */     public void addAdmin(String admin) {
/*  496 */       this.adminList.add(admin);
/*      */     }
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/*  502 */       GroupManager groupManager = importer.groupManager;
/*  503 */       UserManager userManager = importer.userManager;
/*      */ 
/*  506 */       int depth = xpp.getDepth();
/*  507 */       xpp.next();
/*  508 */       while (!DbDataImport.isEndTag("Group", depth, xpp))
/*      */       {
/*  510 */         if (2 == xpp.getEventType())
/*      */         {
/*  512 */           if ("Name".equals(xpp.getName())) {
/*  513 */             this.name = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/*  515 */           else if ("Description".equals(xpp.getName())) {
/*  516 */             this.description = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/*  519 */           else if ("CreationDate".equals(xpp.getName())) {
/*  520 */             this.creationDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/*  523 */           else if ("ModifiedDate".equals(xpp.getName())) {
/*  524 */             this.modifiedDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/*      */           else
/*      */           {
/*  528 */             DbDataImport.executeHandler(this, xpp, importer);
/*  529 */             xpp.next();
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  534 */           xpp.next();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  539 */       Group group = null;
/*      */       try
/*      */       {
/*  543 */         group = groupManager.getGroup(this.name);
/*  544 */         return;
/*      */       }
/*      */       catch (GroupNotFoundException e)
/*      */       {
/*  551 */         group = groupManager.createGroup(this.name);
/*  552 */         if ((this.description != null) && (this.description.length() > 0) && (!"null".equals(this.description)))
/*      */         {
/*  556 */           group.setDescription(this.description);
/*      */         }
/*      */ 
/*  559 */         for (Iterator i = this.memberList.iterator(); i.hasNext(); ) {
/*  560 */           String username = StringUtils.unescapeFromXML((String)i.next());
/*      */           try {
/*  562 */             User user = userManager.getUser(username);
/*  563 */             group.addMember(user);
/*      */           }
/*      */           catch (UserNotFoundException unfe) {
/*  566 */             Log.error(unfe);
/*      */           }
/*      */         }
/*  569 */         for (Iterator i = this.adminList.iterator(); i.hasNext(); ) {
/*  570 */           String username = (String)i.next();
/*      */           try {
/*  572 */             User user = userManager.getUser(username);
/*  573 */             group.addAdministrator(user);
/*      */           }
/*      */           catch (UserNotFoundException unfe) {
/*  576 */             Log.error(unfe);
/*      */           }
/*      */         }
/*      */ 
/*  580 */         group.setCreationDate(this.creationDate);
/*      */ 
/*  582 */         group.setModificationDate(this.modifiedDate);
/*      */ 
/*  584 */         for (i = this.properties.keySet().iterator(); i.hasNext(); ) {
/*  585 */           String name = (String)i.next();
/*  586 */           String value = (String)this.properties.get(name);
/*  587 */           if (value != null)
/*  588 */             group.setProperty(name, value);
/*      */         }
/*      */       }
/*      */       catch (GroupAlreadyExistsException uaee)
/*      */       {
/*      */         Iterator i;
/*  593 */         Log.warn("Group '" + this.name + "' already exists.");
/*      */       }
/*      */       catch (UnauthorizedException ue) {
/*  596 */         Log.error(ue);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class UserHandler
/*      */     implements DbDataImport.Handler, DbDataImport.PropertyAddable
/*      */   {
/*      */     private String username;
/*      */     private String password;
/*      */     private String email;
/*      */     private String name;
/*      */     private Date creationDate;
/*      */     private Date modifiedDate;
/*      */     private boolean nameVisible;
/*      */     private boolean emailVisible;
/*  360 */     private Map properties = null;
/*      */ 
/*      */     public void addProperty(String key, String value)
/*      */     {
/*  364 */       this.properties.put(key, value);
/*      */     }
/*      */ 
/*      */     public UserHandler()
/*      */     {
/*  369 */       this.properties = new HashMap();
/*      */     }
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/*  376 */       int depth = xpp.getDepth();
/*  377 */       xpp.next();
/*  378 */       while (!DbDataImport.isEndTag("User", depth, xpp))
/*      */       {
/*  380 */         if (2 == xpp.getEventType())
/*      */         {
/*  382 */           if ("Name".equals(xpp.getName())) {
/*  383 */             this.nameVisible = DbDataImport.getBooleanValue(xpp.getAttributeValue(null, "visible"));
/*  384 */             this.name = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/*  387 */           else if ("Username".equals(xpp.getName())) {
/*  388 */             this.username = StringUtils.unescapeFromXML(xpp.nextText());
/*      */           }
/*  391 */           else if ("Email".equals(xpp.getName())) {
/*  392 */             this.emailVisible = DbDataImport.getBooleanValue(xpp.getAttributeValue(null, "visible"));
/*  393 */             this.email = xpp.nextText();
/*      */           }
/*  396 */           else if ("Password".equals(xpp.getName())) {
/*  397 */             this.password = xpp.nextText();
/*      */           }
/*  399 */           else if ("CreationDate".equals(xpp.getName())) {
/*  400 */             this.creationDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/*  403 */           else if ("ModifiedDate".equals(xpp.getName())) {
/*  404 */             this.modifiedDate = DbDataImport.parseDate(xpp.nextText());
/*      */           }
/*      */           else
/*      */           {
/*  408 */             DbDataImport.executeHandler(this, xpp, importer);
/*  409 */             xpp.next();
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  414 */           xpp.next();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/*  423 */         newUser = importer.userManager.getUser(this.username);
/*  424 */         return;
/*      */       }
/*      */       catch (UserNotFoundException e)
/*      */       {
/*  433 */         newUser = importer.userManager.createUser(this.username, this.password, this.name, this.email, this.nameVisible, this.emailVisible, this.properties);
/*      */ 
/*  440 */         newUser.setPasswordHash(this.password);
/*      */ 
/*  442 */         newUser.setCreationDate(this.creationDate);
/*      */ 
/*  444 */         newUser.setModificationDate(this.modifiedDate);
/*      */ 
/*  446 */         for (i = this.properties.keySet().iterator(); i.hasNext(); ) {
/*  447 */           String name = (String)i.next();
/*  448 */           String value = (String)this.properties.get(name);
/*  449 */           if (value != null)
/*  450 */             newUser.setProperty(name, value);
/*      */         }
/*      */       }
/*      */       catch (UserAlreadyExistsException uaee)
/*      */       {
/*      */         User newUser;
/*      */         Iterator i;
/*  456 */         Log.warn(uaee);
/*      */       }
/*      */       catch (UnauthorizedException ue) {
/*  459 */         Log.error(ue);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class JivePropertyListHandler
/*      */     implements DbDataImport.Handler
/*      */   {
/*      */     private JivePropertyListHandler()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/*  330 */       DbDataImport.PropertyAddable ps = (DbDataImport.PropertyAddable)parent;
/*      */ 
/*  332 */       xpp.nextTag();
/*  333 */       while (!"JivePropertyList".equals(xpp.getName()))
/*      */       {
/*  335 */         if (xpp.getEventType() == 2) {
/*  336 */           String name = StringUtils.unescapeFromXML(xpp.getAttributeValue(null, "name"));
/*  337 */           String value = StringUtils.unescapeFromXML(xpp.getAttributeValue(null, "value"));
/*      */ 
/*  339 */           ps.addProperty(name, value);
/*      */         }
/*      */ 
/*  342 */         xpp.nextTag();
/*      */       }
/*      */     }
/*      */ 
/*      */     JivePropertyListHandler(DbDataImport.1 x0)
/*      */     {
/*  325 */       this();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class PropertyListHandler
/*      */     implements DbDataImport.Handler
/*      */   {
/*      */     private PropertyListHandler()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/*  305 */       DbDataImport.PropertyAddable ps = (DbDataImport.PropertyAddable)parent;
/*      */ 
/*  307 */       xpp.nextTag();
/*  308 */       while (!"PropertyList".equals(xpp.getName()))
/*      */       {
/*  310 */         if (xpp.getEventType() == 2) {
/*  311 */           String name = StringUtils.unescapeFromXML(xpp.getAttributeValue(null, "name"));
/*  312 */           String value = StringUtils.unescapeFromXML(xpp.getAttributeValue(null, "value"));
/*      */ 
/*  314 */           ps.addProperty(name, value);
/*      */         }
/*      */ 
/*  317 */         xpp.nextTag();
/*      */       }
/*      */     }
/*      */ 
/*      */     PropertyListHandler(DbDataImport.1 x0)
/*      */     {
/*  300 */       this();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class JiveHandler
/*      */     implements DbDataImport.Handler, DbDataImport.PropertyAddable, DbDataImport.PermissionsManagerGettable
/*      */   {
/*  256 */     private HashMap properties = null;
/*  257 */     private DbDataImport importer = null;
/*      */ 
/*      */     public JiveHandler() {
/*  260 */       this.properties = new HashMap();
/*      */     }
/*      */ 
/*      */     public void addProperty(String name, String value) {
/*  264 */       this.properties.put(name, value);
/*      */     }
/*      */ 
/*      */     public PermissionsManager getPermissionsManager() {
/*      */       try {
/*  269 */         return this.importer.forumFactory.getPermissionsManager();
/*      */       }
/*      */       catch (UnauthorizedException ue) {
/*  272 */         Log.error(ue);
/*  273 */       }throw new IllegalStateException("should not be unauthorized!");
/*      */     }
/*      */ 
/*      */     public void handle(Object parent, XmlPullParser xpp, DbDataImport importer)
/*      */       throws XmlPullParserException, IOException
/*      */     {
/*  279 */       this.importer = importer;
/*      */ 
/*  281 */       DbDataImport.handleChildEvents(this, xpp, importer);
/*      */ 
/*  283 */       for (Iterator i = this.properties.keySet().iterator(); i.hasNext(); ) {
/*  284 */         String name = (String)i.next();
/*  285 */         String value = (String)this.properties.get(name);
/*      */ 
/*  287 */         if (!DbDataImport.PROPERTY_IGNORE_PATTERN.matcher(name).find())
/*  288 */           JiveGlobals.setJiveProperty(name, value);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static abstract interface PermissionsManagerGettable
/*      */   {
/*      */     public abstract PermissionsManager getPermissionsManager();
/*      */   }
/*      */ 
/*      */   private static abstract interface PropertyAddable
/*      */   {
/*      */     public abstract void addProperty(String paramString1, String paramString2);
/*      */   }
/*      */ 
/*      */   private static abstract interface Handler
/*      */   {
/*      */     public abstract void handle(Object paramObject, XmlPullParser paramXmlPullParser, DbDataImport paramDbDataImport)
/*      */       throws XmlPullParserException, IOException;
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbDataImport
 * JD-Core Version:    0.6.2
 */
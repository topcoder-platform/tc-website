/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.QueryResult;
/*     */ import com.jivesoftware.forum.database.DatabaseObjectIterator;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class QueryResultIteratorWrapper
/*     */   implements Iterator
/*     */ {
/*     */   IteratorProxy proxy;
/*  25 */   HashMap results = new HashMap();
/*  26 */   LongList messageIDs = new LongList();
/*     */ 
/*  28 */   int startIndex = 0;
/*  29 */   int numResults = -1;
/*  30 */   int current = 0;
/*     */ 
/*     */   public QueryResultIteratorWrapper(Iterator iterator, AuthToken authToken) {
/*  33 */     while (iterator.hasNext()) {
/*  34 */       QueryResult result = (QueryResult)iterator.next();
/*  35 */       this.results.put(new Long(result.getMessageID()), result);
/*  36 */       this.messageIDs.add(result.getMessageID());
/*     */     }
/*     */ 
/*  39 */     DatabaseObjectIterator messageIterator = new DatabaseObjectIterator(2, this.messageIDs.toArray(), DbForumFactory.getInstance());
/*     */ 
/*  42 */     this.proxy = new IteratorProxy(2, messageIterator, authToken);
/*     */   }
/*     */ 
/*     */   public QueryResultIteratorWrapper(Iterator iterator, AuthToken authToken, int startIndex, int numResults) {
/*  46 */     this.startIndex = startIndex;
/*  47 */     this.numResults = numResults;
/*     */ 
/*  49 */     while (iterator.hasNext()) {
/*  50 */       QueryResult result = (QueryResult)iterator.next();
/*  51 */       this.results.put(new Long(result.getMessageID()), result);
/*  52 */       this.messageIDs.add(result.getMessageID());
/*     */     }
/*     */ 
/*  55 */     DatabaseObjectIterator messageIterator = new DatabaseObjectIterator(2, this.messageIDs.toArray(), DbForumFactory.getInstance());
/*     */ 
/*  58 */     this.proxy = new IteratorProxy(2, messageIterator, authToken);
/*     */   }
/*     */ 
/*     */   public void remove()
/*     */     throws UnsupportedOperationException
/*     */   {
/*  65 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public boolean hasNext() {
/*  69 */     if ((this.numResults != -1) && (this.current >= this.startIndex + this.numResults) && (this.startIndex == 0)) {
/*  70 */       return false;
/*     */     }
/*  72 */     if ((this.numResults != -1) && (this.current > this.startIndex + this.numResults) && (this.startIndex != 0)) {
/*  73 */       return false;
/*     */     }
/*     */ 
/*  76 */     return this.proxy.hasNext();
/*     */   }
/*     */ 
/*     */   public Object next() {
/*  80 */     if ((this.numResults != -1) && (this.current >= this.startIndex + this.numResults) && (this.startIndex == 0)) {
/*  81 */       return null;
/*     */     }
/*  83 */     if ((this.numResults != -1) && (this.current > this.startIndex + this.numResults) && (this.startIndex != 0)) {
/*  84 */       return null;
/*     */     }
/*     */ 
/*  87 */     ForumMessage message = null;
/*     */ 
/*  89 */     if ((this.current <= this.startIndex) && (this.startIndex != 0));
/*  90 */     while (this.current <= this.startIndex) {
/*  91 */       message = (ForumMessage)this.proxy.next();
/*     */ 
/*  93 */       if (message == null) {
/*  94 */         return null;
/*     */       }
/*  96 */       this.current += 1;
/*  97 */       continue;
/*     */ 
/* 100 */       message = (ForumMessage)this.proxy.next();
/*     */ 
/* 102 */       if (message == null) {
/* 103 */         return null;
/*     */       }
/*     */     }
/*     */ 
/* 107 */     QueryResult result = (QueryResult)this.results.get(new Long(message.getID()));
/* 108 */     if (result != null) {
/* 109 */       result.setMessage(message);
/*     */     }
/*     */ 
/* 112 */     this.current += 1;
/*     */ 
/* 114 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.QueryResultIteratorWrapper
 * JD-Core Version:    0.6.2
 */
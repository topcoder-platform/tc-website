/*     */ package com.jivesoftware.forum.interceptor;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.MessageInterceptor;
/*     */ import com.jivesoftware.forum.MessageRejectedException;
/*     */ import com.jivesoftware.forum.util.ForumUtils;
/*     */ import com.jivesoftware.util.EmailTask;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class IPInterceptor
/*     */   implements MessageInterceptor
/*     */ {
/*     */   private Map banMap;
/*     */   private Map moderationMap;
/*     */   private Map emailMap;
/*     */   private List emailNotifyList;
/*     */   private String emailName;
/*     */   private String emailAddress;
/*     */   private String emailSubject;
/*     */   private String emailBody;
/*     */ 
/*     */   public IPInterceptor()
/*     */   {
/*     */   }
/*     */ 
/*     */   public IPInterceptor(int type, long objectID)
/*     */   {
/*     */   }
/*     */ 
/*     */   public int getType()
/*     */   {
/*  54 */     return 2;
/*     */   }
/*     */ 
/*     */   public void invokeInterceptor(ForumMessage message, int type)
/*     */     throws MessageRejectedException
/*     */   {
/*  64 */     String address = message.getProperty("IP");
/*  65 */     if (address == null) return;
/*  66 */     if (type == 0)
/*     */     {
/*  68 */       doBanCheck(message, address);
/*     */     }
/*     */     else {
/*  71 */       doModerationCheck(message, address);
/*  72 */       doEmailCheck(message, address);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setBanList(String banList)
/*     */   {
/*  80 */     this.banMap = getMap(banList);
/*     */   }
/*     */ 
/*     */   public String getBanList()
/*     */   {
/*  88 */     return getString(this.banMap);
/*     */   }
/*     */ 
/*     */   public void setModerationList(String moderationList)
/*     */   {
/*  96 */     this.moderationMap = getMap(moderationList);
/*     */   }
/*     */ 
/*     */   public String getModerationList()
/*     */   {
/* 104 */     return getString(this.moderationMap);
/*     */   }
/*     */ 
/*     */   public void setEmailList(String emailList)
/*     */   {
/* 112 */     this.emailMap = getMap(emailList);
/*     */   }
/*     */ 
/*     */   public String getEmailList()
/*     */   {
/* 120 */     return getString(this.emailMap);
/*     */   }
/*     */ 
/*     */   public String getEmailNotifyList()
/*     */   {
/* 129 */     if ((this.emailNotifyList == null) || (this.emailNotifyList.isEmpty())) {
/* 130 */       return "";
/*     */     }
/* 132 */     StringBuffer buf = new StringBuffer();
/* 133 */     buf.append(this.emailNotifyList.get(0));
/* 134 */     for (int i = 1; i < this.emailNotifyList.size(); i++) {
/* 135 */       buf.append(", ");
/* 136 */       buf.append(this.emailNotifyList.get(i));
/*     */     }
/* 138 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public void setEmailNotifyList(String notifyList)
/*     */   {
/* 148 */     if ((notifyList == null) || (notifyList.equals(""))) {
/* 149 */       this.emailNotifyList = null;
/*     */     }
/*     */     else {
/* 152 */       this.emailNotifyList = new ArrayList();
/* 153 */       StringTokenizer tokenizer = new StringTokenizer(notifyList, ",");
/* 154 */       while (tokenizer.hasMoreTokens()) {
/* 155 */         String emailAddress = tokenizer.nextToken().trim();
/* 156 */         this.emailNotifyList.add(emailAddress);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getEmailName()
/*     */   {
/* 166 */     return this.emailName;
/*     */   }
/*     */ 
/*     */   public void setEmailName(String emailName)
/*     */   {
/* 175 */     this.emailName = emailName;
/*     */   }
/*     */ 
/*     */   public String getEmailAddress()
/*     */   {
/* 184 */     return this.emailAddress;
/*     */   }
/*     */ 
/*     */   public void setEmailAddress(String emailAddress)
/*     */   {
/* 193 */     this.emailAddress = emailAddress;
/*     */   }
/*     */ 
/*     */   public String getEmailSubject()
/*     */   {
/* 202 */     return this.emailSubject;
/*     */   }
/*     */ 
/*     */   public void setEmailSubject(String emailSubject)
/*     */   {
/* 211 */     this.emailSubject = emailSubject;
/*     */   }
/*     */ 
/*     */   public String getEmailBody()
/*     */   {
/* 220 */     return this.emailBody;
/*     */   }
/*     */ 
/*     */   public void setEmailBody(String emailBody)
/*     */   {
/* 229 */     this.emailBody = emailBody;
/*     */   }
/*     */ 
/*     */   private void doEmailCheck(ForumMessage message, String remoteIP)
/*     */   {
/* 238 */     if ((remoteIP == null) || (remoteIP.equals("")) || (this.emailNotifyList == null) || (this.emailMap == null)) {
/* 239 */       return;
/*     */     }
/* 241 */     String[] addresses = getFullMatches(remoteIP);
/* 242 */     for (int i = 0; i < addresses.length; i++)
/* 243 */       if (this.emailMap.containsKey(addresses[i])) {
/* 244 */         String body = ForumUtils.replaceTokens(this.emailBody, message, remoteIP);
/*     */ 
/* 247 */         EmailTask emailTask = new EmailTask();
/* 248 */         for (int j = 0; j < this.emailNotifyList.size(); j++) {
/* 249 */           emailTask.addMessage(null, (String)this.emailNotifyList.get(j), this.emailName, this.emailAddress, this.emailSubject, body, null);
/*     */         }
/*     */ 
/* 252 */         TaskEngine.addTask(emailTask);
/* 253 */         break;
/*     */       }
/*     */   }
/*     */ 
/*     */   private static String[] getFullMatches(String address)
/*     */   {
/* 264 */     String[] matches = new String[5];
/*     */ 
/* 266 */     matches[0] = address;
/* 267 */     int marker = address.lastIndexOf('.');
/* 268 */     matches[1] = address.substring(0, marker + 1).concat("*");
/* 269 */     marker = address.lastIndexOf('.', marker - 1);
/* 270 */     matches[2] = address.substring(0, marker + 1).concat("*.*");
/* 271 */     marker = address.lastIndexOf('.', marker - 1);
/* 272 */     matches[3] = address.substring(0, marker + 1).concat("*.*.*");
/* 273 */     matches[4] = "*.*.*.*";
/* 274 */     return matches;
/*     */   }
/*     */ 
/*     */   private void doModerationCheck(ForumMessage message, String remoteIP)
/*     */   {
/* 283 */     if ((remoteIP == null) || (remoteIP.equals("")) || (this.moderationMap == null)) {
/* 284 */       return;
/*     */     }
/* 286 */     String[] addresses = getFullMatches(remoteIP);
/* 287 */     for (int i = 0; i < addresses.length; i++)
/* 288 */       if (this.moderationMap.containsKey(addresses[i]))
/*     */         try {
/* 290 */           message.setModerationValue(0, null);
/*     */         }
/*     */         catch (UnauthorizedException ue)
/*     */         {
/*     */         }
/*     */   }
/*     */ 
/*     */   private void doBanCheck(ForumMessage message, String remoteIP)
/*     */     throws MessageRejectedException
/*     */   {
/* 305 */     if ((remoteIP == null) || (remoteIP.equals("")) || (this.banMap == null)) {
/* 306 */       return;
/*     */     }
/* 308 */     String[] addresses = getFullMatches(remoteIP);
/* 309 */     for (int i = 0; i < addresses.length; i++)
/* 310 */       if (this.banMap.containsKey(addresses[i]))
/* 311 */         throw new MessageRejectedException("Posts are not allowed from IP address " + remoteIP, message);
/*     */   }
/*     */ 
/*     */   private static Map getMap(String iPStr)
/*     */   {
/* 318 */     Map newMap = new HashMap();
/* 319 */     StringTokenizer tokens = new StringTokenizer(iPStr, ",");
/* 320 */     while (tokens.hasMoreTokens()) {
/* 321 */       String address = tokens.nextToken().trim();
/* 322 */       newMap.put(address, "");
/*     */     }
/* 324 */     return newMap;
/*     */   }
/*     */ 
/*     */   private static String getString(Map map)
/*     */   {
/* 329 */     if ((map == null) || (map.size() == 0)) {
/* 330 */       return "";
/*     */     }
/*     */ 
/* 333 */     StringBuffer buf = new StringBuffer();
/* 334 */     Iterator iter = map.keySet().iterator();
/* 335 */     if (iter.hasNext()) {
/* 336 */       buf.append((String)iter.next());
/*     */     }
/* 338 */     while (iter.hasNext()) {
/* 339 */       buf.append(", ").append((String)iter.next());
/*     */     }
/* 341 */     return buf.toString();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.IPInterceptor
 * JD-Core Version:    0.6.2
 */
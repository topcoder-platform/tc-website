/*     */ package com.jivesoftware.forum.interceptor;
/*     */ 
/*     */ import com.jivesoftware.base.Group;
/*     */ import com.jivesoftware.base.GroupManager;
/*     */ import com.jivesoftware.base.GroupManagerFactory;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.MessageInterceptor;
/*     */ import com.jivesoftware.forum.MessageRejectedException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class ModerationInterceptor
/*     */   implements MessageInterceptor
/*     */ {
/*  28 */   private static GroupManager groupManager = GroupManagerFactory.getInstance();
/*     */ 
/*  30 */   private List alwaysModeratedGroups = Collections.EMPTY_LIST;
/*  31 */   private List neverModeratedGroups = Collections.EMPTY_LIST;
/*  32 */   private List alwaysModeratedUsers = Collections.EMPTY_LIST;
/*  33 */   private List neverModeratedUsers = Collections.EMPTY_LIST;
/*     */ 
/*     */   public ModerationInterceptor() {
/*     */   }
/*     */ 
/*     */   public ModerationInterceptor(int objectType, long objectID) {
/*     */   }
/*     */ 
/*     */   public String getAlwaysModeratedGroups() {
/*  42 */     return listToString(this.alwaysModeratedGroups);
/*     */   }
/*     */ 
/*     */   public void setAlwaysModeratedGroups(String groups) {
/*  46 */     this.alwaysModeratedGroups = stringToList(groups);
/*     */   }
/*     */ 
/*     */   public String getNeverModeratedGroups() {
/*  50 */     return listToString(this.neverModeratedGroups);
/*     */   }
/*     */ 
/*     */   public void setNeverModeratedGroups(String groups) {
/*  54 */     this.neverModeratedGroups = stringToList(groups);
/*     */   }
/*     */ 
/*     */   public String getAlwaysModeratedUsers() {
/*  58 */     return listToString(this.alwaysModeratedUsers);
/*     */   }
/*     */ 
/*     */   public void setAlwaysModeratedUsers(String users) {
/*  62 */     this.alwaysModeratedUsers = stringToList(users);
/*     */   }
/*     */ 
/*     */   public String getNeverModeratedUsers() {
/*  66 */     return listToString(this.neverModeratedUsers);
/*     */   }
/*     */ 
/*     */   public void setNeverModeratedUsers(String users) {
/*  70 */     this.neverModeratedUsers = stringToList(users);
/*     */   }
/*     */ 
/*     */   public int getType() {
/*  74 */     return 1;
/*     */   }
/*     */ 
/*     */   public void invokeInterceptor(ForumMessage message, int type) throws MessageRejectedException {
/*     */     try {
/*  79 */       if (!message.isAnonymous()) {
/*  80 */         User user = message.getUser();
/*  81 */         String username = user.getUsername().toLowerCase();
/*     */         Iterator i;
/*  83 */         if (this.neverModeratedUsers.contains(username)) {
/*  84 */           message.setModerationValue(1, null);
/*     */         }
/*     */         else
/*     */         {
/*  88 */           for (i = groupManager.getUserGroups(user); i.hasNext(); ) {
/*  89 */             Group group = (Group)i.next();
/*  90 */             if (this.neverModeratedGroups.contains(group.getName().toLowerCase())) {
/*  91 */               message.setModerationValue(1, null);
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*  97 */         if (this.alwaysModeratedUsers.contains(username)) {
/*  98 */           message.setModerationValue(0, null);
/*     */         }
/*     */         else
/*     */         {
/* 102 */           for (i = groupManager.getUserGroups(user); i.hasNext(); ) {
/* 103 */             Group group = (Group)i.next();
/* 104 */             if (this.alwaysModeratedGroups.contains(group.getName().toLowerCase()))
/* 105 */               message.setModerationValue(0, null);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (UnauthorizedException ue)
/*     */     {
/*     */       Iterator i;
/* 112 */       Log.error(ue);
/* 113 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String listToString(List list) {
/* 118 */     StringBuffer buf = new StringBuffer();
/* 119 */     Iterator i = list.iterator();
/* 120 */     if (i.hasNext()) {
/* 121 */       buf.append(i.next());
/*     */     }
/* 123 */     while (i.hasNext()) {
/* 124 */       buf.append(",").append(i.next());
/*     */     }
/* 126 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   private static List stringToList(String string) {
/* 130 */     if (string == null) {
/* 131 */       return Collections.EMPTY_LIST;
/*     */     }
/* 133 */     List list = new ArrayList();
/* 134 */     StringTokenizer tokens = new StringTokenizer(string, ",");
/* 135 */     while (tokens.hasMoreTokens()) {
/* 136 */       list.add(tokens.nextToken().toLowerCase());
/*     */     }
/* 138 */     return list;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.interceptor.ModerationInterceptor
 * JD-Core Version:    0.6.2
 */
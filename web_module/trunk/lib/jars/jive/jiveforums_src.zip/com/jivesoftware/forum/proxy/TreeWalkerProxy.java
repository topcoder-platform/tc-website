/*    */ package com.jivesoftware.forum.proxy;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.Permissions;
/*    */ import com.jivesoftware.forum.ForumMessage;
/*    */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*    */ import com.jivesoftware.forum.TreeWalker;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class TreeWalkerProxy
/*    */   implements TreeWalker
/*    */ {
/*    */   private TreeWalker treeWalker;
/*    */   private AuthToken authToken;
/*    */   private Permissions permissions;
/*    */ 
/*    */   public TreeWalkerProxy(TreeWalker treeWalker, AuthToken authToken, Permissions permissions)
/*    */   {
/* 35 */     this.treeWalker = treeWalker;
/* 36 */     this.authToken = authToken;
/* 37 */     this.permissions = permissions;
/*    */   }
/*    */ 
/*    */   public ForumMessage getRoot() {
/* 41 */     ForumMessage message = this.treeWalker.getRoot();
/* 42 */     return new ForumMessageProxy(message, this.authToken, this.permissions);
/*    */   }
/*    */ 
/*    */   public boolean hasParent(ForumMessage child) {
/* 46 */     return this.treeWalker.hasParent(child);
/*    */   }
/*    */ 
/*    */   public ForumMessage getParent(ForumMessage child) throws ForumMessageNotFoundException {
/* 50 */     ForumMessage message = this.treeWalker.getParent(child);
/* 51 */     return new ForumMessageProxy(message, this.authToken, this.permissions);
/*    */   }
/*    */ 
/*    */   public ForumMessage getChild(ForumMessage parent, int index)
/*    */     throws ForumMessageNotFoundException
/*    */   {
/* 57 */     ForumMessage message = this.treeWalker.getChild(parent, index);
/* 58 */     return new ForumMessageProxy(message, this.authToken, this.permissions);
/*    */   }
/*    */ 
/*    */   public Iterator getChildren(ForumMessage parent) {
/* 62 */     return new IteratorProxy(2, this.treeWalker.getChildren(parent), this.authToken);
/*    */   }
/*    */ 
/*    */   public Iterator getRecursiveMessages()
/*    */   {
/* 67 */     return new IteratorProxy(2, this.treeWalker.getRecursiveMessages(), this.authToken);
/*    */   }
/*    */ 
/*    */   public Iterator getRecursiveChildren(ForumMessage parent)
/*    */   {
/* 72 */     return new IteratorProxy(2, this.treeWalker.getRecursiveChildren(parent), this.authToken);
/*    */   }
/*    */ 
/*    */   public int getMessageDepth(ForumMessage message)
/*    */   {
/* 77 */     return this.treeWalker.getMessageDepth(message);
/*    */   }
/*    */ 
/*    */   public int getChildCount(ForumMessage parent) {
/* 81 */     return this.treeWalker.getChildCount(parent);
/*    */   }
/*    */ 
/*    */   public int getRecursiveChildCount(ForumMessage parent) {
/* 85 */     return this.treeWalker.getRecursiveChildCount(parent);
/*    */   }
/*    */ 
/*    */   public int getIndexOfChild(ForumMessage parent, ForumMessage child) {
/* 89 */     return this.treeWalker.getIndexOfChild(parent, child);
/*    */   }
/*    */ 
/*    */   public boolean isLeaf(ForumMessage node) {
/* 93 */     return this.treeWalker.isLeaf(node);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.TreeWalkerProxy
 * JD-Core Version:    0.6.2
 */
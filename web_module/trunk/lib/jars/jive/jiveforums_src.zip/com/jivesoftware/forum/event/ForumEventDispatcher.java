/*    */ package com.jivesoftware.forum.event;
/*    */ 
/*    */ import com.jivesoftware.base.JiveGlobals;
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.util.ClassUtils;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ForumEventDispatcher
/*    */ {
/* 28 */   private static ForumEventDispatcher instance = new ForumEventDispatcher();
/*    */ 
/* 34 */   private ArrayList listeners = new ArrayList();
/*    */ 
/*    */   public static ForumEventDispatcher getInstance()
/*    */   {
/* 31 */     return instance;
/*    */   }
/*    */ 
/*    */   private ForumEventDispatcher()
/*    */   {
/* 38 */     List listenerList = JiveGlobals.getJiveProperties("eventListeners.ForumListener");
/* 39 */     for (int i = 0; i < listenerList.size(); i++) {
/* 40 */       String listenerStr = (String)listenerList.get(i);
/*    */       try {
/* 42 */         ForumListener listener = (ForumListener)ClassUtils.forName(listenerStr).newInstance();
/* 43 */         this.listeners.add(listener);
/*    */       }
/*    */       catch (Exception e) {
/* 46 */         Log.error("Error loading ForumListener", e);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public synchronized void addListener(ForumListener listener) {
/* 52 */     if (listener == null) {
/* 53 */       throw new NullPointerException();
/*    */     }
/*    */ 
/* 56 */     this.listeners.add(listener);
/*    */   }
/*    */ 
/*    */   public synchronized void removeListener(ForumListener listener) {
/* 60 */     this.listeners.remove(listener);
/*    */   }
/*    */ 
/*    */   public void dispatchEvent(ForumEvent event) {
/* 64 */     int eventType = event.getEventType();
/*    */ 
/* 66 */     for (int i = 0; i < this.listeners.size(); i++)
/*    */       try {
/* 68 */         ForumListener listener = (ForumListener)this.listeners.get(i);
/* 69 */         switch (eventType) {
/*    */         case 120:
/* 71 */           listener.forumAdded(event);
/* 72 */           break;
/*    */         case 121:
/* 75 */           listener.forumDeleted(event);
/* 76 */           break;
/*    */         case 122:
/* 79 */           listener.forumMoved(event);
/* 80 */           break;
/*    */         case 123:
/* 83 */           listener.forumMerged(event);
/*    */         }
/*    */ 
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 90 */         Log.error(e);
/*    */       }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.ForumEventDispatcher
 * JD-Core Version:    0.6.2
 */
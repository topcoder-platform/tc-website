/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.Query;
/*     */ import com.jivesoftware.forum.QueryResult;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class QueryProxy
/*     */   implements Query
/*     */ {
/*     */   private Query query;
/*     */   private AuthToken authToken;
/*     */ 
/*     */   public QueryProxy(Query query, AuthToken authToken)
/*     */   {
/*  32 */     this.query = query;
/*  33 */     this.authToken = authToken;
/*     */   }
/*     */ 
/*     */   public long getID() {
/*  37 */     return this.query.getID();
/*     */   }
/*     */ 
/*     */   public int getObjectType() {
/*  41 */     return this.query.getObjectType();
/*     */   }
/*     */ 
/*     */   public String getQueryString() {
/*  45 */     return this.query.getQueryString();
/*     */   }
/*     */ 
/*     */   public void setQueryString(String queryString) {
/*  49 */     this.query.setQueryString(queryString);
/*     */   }
/*     */ 
/*     */   public Date getBeforeDate() {
/*  53 */     return this.query.getBeforeDate();
/*     */   }
/*     */ 
/*     */   public void setBeforeDate(Date beforeDate) {
/*  57 */     this.query.setBeforeDate(beforeDate);
/*     */   }
/*     */ 
/*     */   public Date getAfterDate() {
/*  61 */     return this.query.getAfterDate();
/*     */   }
/*     */ 
/*     */   public void setAfterDate(Date afterDate) {
/*  65 */     this.query.setAfterDate(afterDate);
/*     */   }
/*     */ 
/*     */   public long[] getForumIDs() {
/*  69 */     return this.query.getForumIDs();
/*     */   }
/*     */ 
/*     */   public User getUser() {
/*  73 */     User u = this.query.getUser();
/*  74 */     if (u != null) {
/*     */       try {
/*  76 */         return ForumFactory.getInstance(this.authToken).getUserManager().getUser(u.getID());
/*     */       }
/*     */       catch (UserNotFoundException e) {
/*  79 */         Log.error(e);
/*     */       }
/*     */     }
/*     */ 
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   public void filterOnUser(User user) {
/*  87 */     this.query.filterOnUser(user);
/*     */   }
/*     */ 
/*     */   public User getFilteredUser() {
/*  91 */     return this.query.getFilteredUser();
/*     */   }
/*     */ 
/*     */   public ForumThread getFilteredThread() {
/*  95 */     return this.query.getFilteredThread();
/*     */   }
/*     */ 
/*     */   public void filterOnThread(ForumThread thread) {
/*  99 */     this.query.filterOnThread(thread);
/*     */   }
/*     */ 
/*     */   public int getSortField() {
/* 103 */     return this.query.getSortField();
/*     */   }
/*     */ 
/*     */   public void setSortField(int sortField) {
/* 107 */     this.query.setSortField(sortField);
/*     */   }
/*     */ 
/*     */   public int getSortOrder() {
/* 111 */     return this.query.getSortOrder();
/*     */   }
/*     */ 
/*     */   public void setSortOrder(int sortOrder) {
/* 115 */     this.query.setSortOrder(sortOrder);
/*     */   }
/*     */ 
/*     */   public int getResultCount()
/*     */   {
/* 122 */     return this.query.getResultCount();
/*     */   }
/*     */ 
/*     */   public int getResultByThreadCount()
/*     */   {
/* 129 */     return this.query.getResultByThreadCount();
/*     */   }
/*     */ 
/*     */   public Iterator getResults() {
/* 133 */     Iterator iterator = this.query.getResults();
/* 134 */     return new QueryResultIteratorWrapper(iterator, this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getResults(int startIndex, int numResults) {
/* 138 */     Iterator iterator = this.query.getResults(startIndex, numResults);
/* 139 */     return new QueryResultIteratorWrapper(iterator, this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getResultsByThread() {
/* 143 */     Iterator iterator = this.query.getResultsByThread();
/* 144 */     return new QueryResultIteratorWrapper(iterator, this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getResultsByThread(int startIndex, int numResults) {
/* 148 */     Iterator iterator = this.query.getResultsByThread(startIndex, numResults);
/* 149 */     return new QueryResultIteratorWrapper(iterator, this.authToken);
/*     */   }
/*     */ 
/*     */   public Iterator getResultForums() {
/* 153 */     Iterator iterator = this.query.getResultForums();
/* 154 */     return new IteratorProxy(0, iterator, this.authToken);
/*     */   }
/*     */ 
/*     */   public String[] highlightResult(QueryResult result, String preTag, String postTag) {
/* 158 */     return this.query.highlightResult(result, preTag, postTag);
/*     */   }
/*     */ 
/*     */   public long logQuery(User user) {
/* 162 */     return this.query.logQuery(user);
/*     */   }
/*     */ 
/*     */   public void logSearchClick(long searchID, long messageID) {
/* 166 */     this.query.logSearchClick(searchID, messageID);
/*     */   }
/*     */ 
/*     */   public boolean equals(Query query) {
/* 170 */     return this.query.equals(query);
/*     */   }
/*     */ 
/*     */   public Query getProxiedQuery()
/*     */   {
/* 177 */     return this.query;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.QueryProxy
 * JD-Core Version:    0.6.2
 */
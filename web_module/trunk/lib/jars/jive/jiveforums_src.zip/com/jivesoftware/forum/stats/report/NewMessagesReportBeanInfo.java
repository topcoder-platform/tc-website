/*    */ package com.jivesoftware.forum.stats.report;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class NewMessagesReportBeanInfo extends JiveBeanInfo
/*    */ {
/*    */   public String[] getPropertyNames()
/*    */   {
/* 17 */     return new String[] { "stepSize" };
/*    */   }
/*    */   public Class getBeanClass() {
/* 20 */     return NewMessagesReport.class;
/*    */   }
/*    */   public String getName() {
/* 23 */     return "NewMessagesReport";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.NewMessagesReportBeanInfo
 * JD-Core Version:    0.6.2
 */
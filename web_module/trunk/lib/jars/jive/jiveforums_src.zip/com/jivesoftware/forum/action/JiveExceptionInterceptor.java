/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.opensymphony.xwork.ActionContext;
/*     */ import com.opensymphony.xwork.ActionInvocation;
/*     */ import com.opensymphony.xwork.TextProvider;
/*     */ import com.opensymphony.xwork.ValidationAware;
/*     */ import com.opensymphony.xwork.interceptor.Interceptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class JiveExceptionInterceptor
/*     */   implements Interceptor
/*     */ {
/*     */   public static final String EXCEPTION_KEY = "jiveException";
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void init()
/*     */   {
/*     */   }
/*     */ 
/*     */   public String intercept(ActionInvocation invocation)
/*     */   {
/*     */     try
/*     */     {
/*  63 */       return invocation.invoke();
/*     */     }
/*     */     catch (UnauthorizedException e) {
/*  66 */       return "unauthorized";
/*     */     }
/*     */     catch (ForumNotFoundException e)
/*     */     {
/*  70 */       if ((invocation.getAction() instanceof ValidationAware)) {
/*  71 */         ValidationAware va = (ValidationAware)invocation.getAction();
/*  72 */         va.addFieldError("forumID", String.valueOf(e.getForumID()));
/*     */       }
/*  74 */       return "notfound";
/*     */     }
/*     */     catch (ForumCategoryNotFoundException e) {
/*  77 */       if ((invocation.getAction() instanceof ValidationAware)) {
/*  78 */         ValidationAware va = (ValidationAware)invocation.getAction();
/*  79 */         va.addFieldError("categoryID", String.valueOf(e.getForumCategoryID()));
/*     */       }
/*  81 */       return "notfound";
/*     */     }
/*     */     catch (UserNotFoundException e)
/*     */     {
/*  85 */       if (((invocation.getAction() instanceof ValidationAware)) && ((invocation.getAction() instanceof TextProvider))) {
/*  86 */         ValidationAware va = (ValidationAware)invocation.getAction();
/*  87 */         TextProvider tp = (TextProvider)invocation.getAction();
/*     */ 
/*  92 */         if (e.getUserID() > 0L) {
/*  93 */           List args = new ArrayList();
/*  94 */           args.add(new Long(e.getUserID()));
/*  95 */           va.addActionError(tp.getText("profile.error_userid", args));
/*     */         }
/*  97 */         else if (e.getUsername() != null) {
/*  98 */           List args = new ArrayList();
/*  99 */           args.add(e.getUsername());
/* 100 */           va.addActionError(tp.getText("profile.error_username", args));
/*     */         }
/*     */         else {
/* 103 */           va.addActionError(tp.getText("profile.error_user"));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 108 */       return "notfound";
/*     */     }
/*     */     catch (Exception e) {
/* 111 */       Log.error(e);
/* 112 */       invocation.getInvocationContext().put("jiveException", e);
/* 113 */     }return "fatal";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.JiveExceptionInterceptor
 * JD-Core Version:    0.6.2
 */
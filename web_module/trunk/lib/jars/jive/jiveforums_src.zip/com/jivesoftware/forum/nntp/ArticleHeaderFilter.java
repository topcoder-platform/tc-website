/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class ArticleHeaderFilter extends ArticleFilter
/*    */ {
/* 22 */   private String header = null;
/*    */ 
/* 24 */   private Wildmat wildmat = null;
/*    */ 
/*    */   public ArticleHeaderFilter(String headerName, String range, Wildmat matcher)
/*    */   {
/* 35 */     super(range);
/* 36 */     setHeader(headerName);
/* 37 */     setWildmat(matcher);
/*    */   }
/*    */ 
/*    */   public void setHeader(String headerName)
/*    */   {
/* 48 */     this.header = headerName;
/*    */   }
/*    */ 
/*    */   public String getHeader()
/*    */   {
/* 59 */     return this.header;
/*    */   }
/*    */ 
/*    */   public void setWildmat(Wildmat matcher)
/*    */   {
/* 69 */     this.wildmat = matcher;
/*    */   }
/*    */ 
/*    */   public Wildmat getWildmat()
/*    */   {
/* 79 */     return this.wildmat;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.ArticleHeaderFilter
 * JD-Core Version:    0.6.2
 */
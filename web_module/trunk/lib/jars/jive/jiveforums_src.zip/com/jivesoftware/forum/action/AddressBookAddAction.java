/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.PresenceManager;
/*    */ import com.jivesoftware.base.Roster;
/*    */ import com.jivesoftware.base.UnauthorizedException;
/*    */ import com.jivesoftware.base.User;
/*    */ import com.jivesoftware.base.UserManager;
/*    */ import com.jivesoftware.base.UserNotFoundException;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.opensymphony.xwork.Validateable;
/*    */ 
/*    */ public class AddressBookAddAction extends ForumActionSupport
/*    */   implements Validateable
/*    */ {
/*    */   private String username;
/*    */   private User userToAdd;
/*    */ 
/*    */   public String getUsername()
/*    */   {
/* 30 */     return this.username;
/*    */   }
/*    */ 
/*    */   public void setUsername(String username) {
/* 34 */     this.username = username;
/*    */   }
/*    */ 
/*    */   public Roster getRoster() throws UnauthorizedException {
/* 38 */     return getForumFactory().getPresenceManager().getRoster(getPageUser());
/*    */   }
/*    */ 
/*    */   public String doDefault() {
/* 42 */     if (getAuthToken().isAnonymous()) {
/* 43 */       return "login";
/*    */     }
/*    */ 
/* 46 */     return "input";
/*    */   }
/*    */ 
/*    */   public void validate() {
/* 50 */     if ((this.username == null) || ("".equals(this.username.trim())))
/* 51 */       addFieldError("username", "");
/*    */     try
/*    */     {
/* 54 */       this.userToAdd = getForumFactory().getUserManager().getUser(this.username);
/*    */     }
/*    */     catch (UserNotFoundException unfe) {
/* 57 */       addFieldError("userNotFound", this.username);
/*    */     }
/*    */   }
/*    */ 
/*    */   public String execute() {
/* 62 */     if (getAuthToken().isAnonymous()) {
/* 63 */       return "login";
/*    */     }
/*    */     try
/*    */     {
/* 67 */       Roster roster = getRoster();
/*    */ 
/* 69 */       if (!roster.isRosterMember(this.userToAdd)) {
/* 70 */         roster.addUser(this.userToAdd);
/*    */       }
/*    */ 
/* 73 */       return "success";
/*    */     } catch (UnauthorizedException ue) {
/*    */     }
/* 76 */     return "login";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AddressBookAddAction
 * JD-Core Version:    0.6.2
 */
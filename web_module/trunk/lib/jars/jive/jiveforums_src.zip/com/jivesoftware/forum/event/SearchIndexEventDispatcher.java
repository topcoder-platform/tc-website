/*    */ package com.jivesoftware.forum.event;
/*    */ 
/*    */ import com.jivesoftware.base.JiveGlobals;
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.util.ClassUtils;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class SearchIndexEventDispatcher
/*    */ {
/* 27 */   private ArrayList listeners = new ArrayList();
/* 28 */   private static SearchIndexEventDispatcher dispatcher = new SearchIndexEventDispatcher();
/*    */ 
/*    */   private SearchIndexEventDispatcher()
/*    */   {
/* 32 */     List listenerList = JiveGlobals.getJiveProperties("eventListeners.SearchIndexListener");
/* 33 */     for (int i = 0; i < listenerList.size(); i++) {
/* 34 */       String listenerStr = (String)listenerList.get(i);
/*    */       try {
/* 36 */         SearchIndexListener listener = (SearchIndexListener)ClassUtils.forName(listenerStr).newInstance();
/* 37 */         this.listeners.add(listener);
/*    */       }
/*    */       catch (Exception e) {
/* 40 */         Log.error("Error loading SearchIndexListener", e);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public static SearchIndexEventDispatcher getInstance() {
/* 46 */     return dispatcher;
/*    */   }
/*    */ 
/*    */   public synchronized void addListener(SearchIndexListener listener) {
/* 50 */     if (listener == null) {
/* 51 */       throw new NullPointerException();
/*    */     }
/*    */ 
/* 54 */     this.listeners.add(listener);
/*    */   }
/*    */ 
/*    */   public synchronized void removeListener(SearchIndexListener listener) {
/* 58 */     this.listeners.remove(listener);
/*    */   }
/*    */ 
/*    */   public void dispatchEvent(SearchIndexEvent event) {
/* 62 */     int eventType = event.getEventType();
/*    */ 
/* 64 */     for (int i = 0; i < this.listeners.size(); i++)
/*    */       try {
/* 66 */         SearchIndexListener listener = (SearchIndexListener)this.listeners.get(i);
/* 67 */         switch (eventType) {
/*    */         case 140:
/* 69 */           listener.messageAdded(event);
/* 70 */           break;
/*    */         case 141:
/* 73 */           listener.messageDeleted(event);
/* 74 */           break;
/*    */         case 142:
/* 77 */           listener.rebuildStarted(event);
/* 78 */           break;
/*    */         case 143:
/* 81 */           listener.rebuildCompleted(event);
/* 82 */           break;
/*    */         case 144:
/* 85 */           listener.updateStarted(event);
/* 86 */           break;
/*    */         case 145:
/* 89 */           listener.updateCompleted(event);
/* 90 */           break;
/*    */         case 146:
/* 93 */           listener.optimizeStarted(event);
/* 94 */           break;
/*    */         case 147:
/* 97 */           listener.optimizeCompleted(event);
/*    */         }
/*    */ 
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 105 */         Log.error(e);
/*    */       }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.SearchIndexEventDispatcher
 * JD-Core Version:    0.6.2
 */
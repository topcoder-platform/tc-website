/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.opensymphony.webwork.ServletActionContext;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ 
/*     */ public class EditProfileAction extends AccountAction
/*     */   implements Validateable
/*     */ {
/*     */   private String doUpdateAccount;
/*     */   private String doUpdatePassword;
/*     */ 
/*     */   public String getName()
/*     */   {
/*  30 */     if (super.getName() != null) {
/*  31 */       return super.getName();
/*     */     }
/*     */ 
/*  34 */     return getPageUser().getName();
/*     */   }
/*     */ 
/*     */   public Boolean getNameVisible()
/*     */   {
/*  39 */     if (super.getNameVisible() != null) {
/*  40 */       return super.getNameVisible();
/*     */     }
/*     */ 
/*  43 */     return new Boolean(getPageUser().isNameVisible());
/*     */   }
/*     */ 
/*     */   public String getEmail()
/*     */   {
/*  48 */     if (super.getEmail() != null) {
/*  49 */       return super.getEmail();
/*     */     }
/*     */ 
/*  52 */     return getPageUser().getEmail();
/*     */   }
/*     */ 
/*     */   public Boolean getEmailVisible()
/*     */   {
/*  57 */     if (super.getEmailVisible() != null) {
/*  58 */       return super.getEmailVisible();
/*     */     }
/*     */ 
/*  61 */     return new Boolean(getPageUser().isEmailVisible());
/*     */   }
/*     */ 
/*     */   public String getLocation()
/*     */   {
/*  66 */     if (super.getLocation() != null) {
/*  67 */       return super.getLocation();
/*     */     }
/*     */ 
/*  70 */     return getPageUser().getProperty("jiveLocation");
/*     */   }
/*     */ 
/*     */   public String getOccupation()
/*     */   {
/*  75 */     if (super.getOccupation() != null) {
/*  76 */       return super.getOccupation();
/*     */     }
/*     */ 
/*  79 */     return getPageUser().getProperty("jiveOccupation");
/*     */   }
/*     */ 
/*     */   public String getHomepage()
/*     */   {
/*  84 */     if (super.getHomepage() != null) {
/*  85 */       return super.getHomepage();
/*     */     }
/*     */ 
/*  88 */     return getPageUser().getProperty("jiveHomepage");
/*     */   }
/*     */ 
/*     */   public String getBiography()
/*     */   {
/*  93 */     if (super.getBiography() != null) {
/*  94 */       return super.getBiography();
/*     */     }
/*     */ 
/*  97 */     return getPageUser().getProperty("jiveBiography");
/*     */   }
/*     */ 
/*     */   public String getSignature()
/*     */   {
/* 102 */     if (super.getSignature() != null) {
/* 103 */       return super.getSignature();
/*     */     }
/*     */ 
/* 106 */     return getPageUser().getProperty("jiveSignature");
/*     */   }
/*     */ 
/*     */   public Boolean getSignatureVisible()
/*     */   {
/* 111 */     if (super.getSignatureVisible() != null) {
/* 112 */       return super.getSignatureVisible();
/*     */     }
/*     */ 
/* 115 */     return new Boolean("true".equals(getPageUser().getProperty("jiveSignatureVisible")));
/*     */   }
/*     */ 
/*     */   public String getDoUpdateAccount()
/*     */   {
/* 120 */     return this.doUpdateAccount;
/*     */   }
/*     */ 
/*     */   public void setDoUpdateAccount(String doUpdateAccount) {
/* 124 */     if ((doUpdateAccount != null) && (!"".equals(doUpdateAccount)))
/* 125 */       this.doUpdateAccount = "true";
/*     */   }
/*     */ 
/*     */   public String getDoUpdatePassword()
/*     */   {
/* 130 */     return this.doUpdatePassword;
/*     */   }
/*     */ 
/*     */   public void setDoUpdatePassword(String doUpdatePassword) {
/* 134 */     if ((doUpdatePassword != null) && (!"".equals(doUpdatePassword)))
/* 135 */       this.doUpdatePassword = "true";
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/* 147 */     if ("true".equals(getDoUpdateAccount())) {
/* 148 */       if ((getName() == null) && (getFieldErrors().get("name") == null)) {
/* 149 */         addFieldError("name", getText("edit.error_name"));
/*     */       }
/* 151 */       if ((getEmail() == null) && (getFieldErrors().get("email") == null)) {
/* 152 */         addFieldError("email", getText("edit.error_email"));
/*     */       }
/*     */     }
/* 155 */     else if (("true".equals(getDoUpdatePassword())) && (!"false".equals(JiveGlobals.getJiveProperty("skin.default.changePasswordEnabled"))))
/*     */     {
/* 158 */       String pass = getPassword();
/* 159 */       String passConfirm = getPasswordConfirm();
/* 160 */       if ((pass == null) && (getFieldErrors().get("password") == null)) {
/* 161 */         addFieldError("password", getText("edit.error_password"));
/*     */       }
/* 163 */       if (passConfirm == null) {
/* 164 */         addFieldError("passwordConfirm", getText("edit.error_password_confirm"));
/*     */       }
/* 166 */       if ((pass != null) && (passConfirm != null) && (!pass.equals(passConfirm)))
/* 167 */         addFieldError("passwordMatch", getText("edit.error_password_match"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/* 177 */     ServletActionContext.getRequest().getSession().setAttribute("jive.current.tab", "profile");
/*     */ 
/* 179 */     if (getPageUser() == null) {
/* 180 */       setLoginAttributes();
/* 181 */       addActionError(getText("profile.error_unauth"));
/* 182 */       return "login";
/*     */     }
/* 184 */     return "input";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 193 */     if (getPageUser() == null) {
/* 194 */       setLoginAttributes();
/* 195 */       addActionError(getText("profile.error_unauth"));
/* 196 */       return "login";
/*     */     }
/*     */ 
/* 199 */     if (hasErrors()) {
/* 200 */       return "error";
/*     */     }
/*     */ 
/* 203 */     User user = getPageUser();
/* 204 */     if ("true".equals(getDoUpdateAccount()))
/*     */     {
/*     */       try {
/* 207 */         if (!getName().equals(user.getName())) {
/* 208 */           user.setName(getName());
/*     */         }
/* 210 */         if (!getEmail().equals(user.getEmail())) {
/* 211 */           user.setEmail(getEmail());
/*     */         }
/* 213 */         if (getNameVisible() != null) {
/* 214 */           user.setNameVisible(getNameVisible().booleanValue());
/*     */         }
/* 216 */         if (getEmailVisible() != null) {
/* 217 */           user.setEmailVisible(getEmailVisible().booleanValue());
/*     */         }
/* 219 */         if ((getLocation() == null) || ("".equals(getLocation()))) {
/* 220 */           user.deleteProperty("jiveLocation");
/*     */         }
/*     */         else {
/* 223 */           user.setProperty("jiveLocation", getLocation());
/*     */         }
/* 225 */         if ((getOccupation() == null) || ("".equals(getOccupation()))) {
/* 226 */           user.deleteProperty("jiveOccupation");
/*     */         }
/*     */         else {
/* 229 */           user.setProperty("jiveOccupation", getOccupation());
/*     */         }
/* 231 */         if ((getHomepage() == null) || ("".equals(getHomepage()))) {
/* 232 */           user.deleteProperty("jiveHomepage");
/*     */         }
/*     */         else {
/* 235 */           user.setProperty("jiveHomepage", getHomepage());
/*     */         }
/* 237 */         if ((getBiography() == null) || ("".equals(getBiography()))) {
/* 238 */           user.deleteProperty("jiveBiography");
/*     */         }
/*     */         else {
/* 241 */           user.setProperty("jiveBiography", getBiography());
/*     */         }
/* 243 */         if ((getSignature() == null) || ("".equals(getSignature()))) {
/* 244 */           user.deleteProperty("jiveSignature");
/*     */         }
/*     */         else {
/* 247 */           user.setProperty("jiveSignature", getSignature());
/*     */         }
/* 249 */         if (getSignatureVisible() != null)
/* 250 */           user.setProperty("jiveSignatureVisible", String.valueOf(getSignatureVisible().booleanValue()));
/*     */       }
/*     */       catch (UnauthorizedException ue)
/*     */       {
/* 254 */         setLoginAttributes();
/* 255 */         addActionError(ue.getMessage());
/* 256 */         return "login";
/*     */       }
/*     */ 
/* 259 */       return "success";
/*     */     }
/* 261 */     if (("true".equals(getDoUpdatePassword())) && (!"false".equals(JiveGlobals.getJiveProperty("skin.default.changePasswordEnabled"))))
/*     */     {
/*     */       try
/*     */       {
/* 265 */         user.setPassword(getPassword());
/* 266 */         return "success";
/*     */       }
/*     */       catch (UnauthorizedException ue) {
/* 269 */         setLoginAttributes();
/* 270 */         addActionError(ue.getMessage());
/* 271 */         return "login";
/*     */       }
/*     */     }
/*     */ 
/* 275 */     return "input";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.EditProfileAction
 * JD-Core Version:    0.6.2
 */
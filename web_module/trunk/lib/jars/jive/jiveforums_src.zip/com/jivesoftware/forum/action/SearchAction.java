/*      */ package com.jivesoftware.forum.action;
/*      */ 
/*      */ import com.jivesoftware.base.AuthToken;
/*      */ import com.jivesoftware.base.Filter;
/*      */ import com.jivesoftware.base.FilterManager;
/*      */ import com.jivesoftware.base.JiveGlobals;
/*      */ import com.jivesoftware.base.Log;
/*      */ import com.jivesoftware.base.UnauthorizedException;
/*      */ import com.jivesoftware.base.User;
/*      */ import com.jivesoftware.base.UserManager;
/*      */ import com.jivesoftware.base.action.util.RedirectAction;
/*      */ import com.jivesoftware.base.filter.Profanity;
/*      */ import com.jivesoftware.forum.Forum;
/*      */ import com.jivesoftware.forum.ForumCategory;
/*      */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*      */ import com.jivesoftware.forum.ForumFactory;
/*      */ import com.jivesoftware.forum.ForumMessage;
/*      */ import com.jivesoftware.forum.ForumNotFoundException;
/*      */ import com.jivesoftware.forum.ForumThread;
/*      */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*      */ import com.jivesoftware.forum.Query;
/*      */ import com.jivesoftware.forum.QueryManager;
/*      */ import com.jivesoftware.forum.QueryResult;
/*      */ import com.jivesoftware.forum.ResultFilter;
/*      */ import com.jivesoftware.forum.Version;
/*      */ import com.jivesoftware.forum.Version.Edition;
/*      */ import com.jivesoftware.forum.action.util.Pageable;
/*      */ import com.jivesoftware.forum.database.DbForumFactory;
/*      */ import com.jivesoftware.forum.database.DbForumMessage;
/*      */ import com.jivesoftware.forum.database.SessionQuery;
/*      */ import com.jivesoftware.util.ClassUtils;
/*      */ import com.jivesoftware.util.LongList;
/*      */ import com.jivesoftware.util.RelativeDateRange;
/*      */ import com.jivesoftware.util.SpellChecker;
/*      */ import com.jivesoftware.util.SpellSession;
/*      */ import com.jivesoftware.util.StringUtils;
/*      */ import com.opensymphony.webwork.ServletActionContext;
/*      */ import com.opensymphony.xwork.ActionContext;
/*      */ import com.opensymphony.xwork.ActionInvocation;
/*      */ import com.opensymphony.xwork.ActionProxy;
/*      */ import com.opensymphony.xwork.config.entities.ActionConfig;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ public class SearchAction extends ForumActionSupport
/*      */   implements Pageable
/*      */ {
/*      */   public static final int DEFAULT_NUM_RESULTS = 15;
/*   35 */   public static final int[] RESULT_OPTIONS = { 10, 15, 30 };
/*   36 */   public static final RelativeDateRange DEFAULT_DATE_RANGE = RelativeDateRange.LAST_90_DAYS;
/*   37 */   public static final RelativeDateRange[] DATE_RANGES = { RelativeDateRange.ALL, RelativeDateRange.YESTERDAY, RelativeDateRange.LAST_7_DAYS, RelativeDateRange.LAST_30_DAYS, RelativeDateRange.LAST_90_DAYS, RelativeDateRange.THIS_YEAR, RelativeDateRange.LAST_YEAR };
/*      */   private String[] objID;
/*   46 */   private long searchID = -1L;
/*      */   private long[] categoryID;
/*      */   private long[] forumID;
/*      */   private String userID;
/*      */   private String threadID;
/*   51 */   private boolean advanced = false;
/*   52 */   private boolean spellSuggestOn = JiveGlobals.getJiveBooleanProperty("search.spellcheck.enabled", true);
/*      */ 
/*   54 */   private boolean displayPerThread = JiveGlobals.getJiveBooleanProperty("search.results.groupByThread", true);
/*      */ 
/*   56 */   private int numResults = 15;
/*      */   private String dateRange;
/*      */   private String q;
/*      */   private String qenc;
/*      */   private String correctedQ;
/*   61 */   private int start = 0;
/*      */   private ForumCategory searchedCategory;
/*      */   private List searchedCategories;
/*      */   private Forum searchedForum;
/*      */   private List searchedForums;
/*      */   private User searchedUser;
/*      */   private ForumThread searchedThread;
/*      */   private Query query;
/*      */   private Iterator results;
/*      */   private String partialQueryString;
/*      */   private String correctedURLQ;
/*      */   private String partialCorrectedQueryString;
/*   75 */   private int rankBy = 10001;
/*   76 */   private boolean filterHTMLEnabled = JiveGlobals.getJiveBooleanProperty("search.filterHTMLEnabled", true);
/*      */   private static final String SEARCH_QUERY = "jive.forum.search.query";
/*      */ 
/*      */   public String[] getObjID()
/*      */   {
/*   84 */     return this.objID;
/*      */   }
/*      */ 
/*      */   public void setObjID(String[] objID) {
/*   88 */     if ((objID != null) && (objID.length > 0))
/*   89 */       this.objID = objID;
/*      */   }
/*      */ 
/*      */   public long getSearchID()
/*      */   {
/*   97 */     return this.searchID;
/*      */   }
/*      */ 
/*      */   public void setSearchID(long searchID)
/*      */   {
/*  106 */     this.searchID = searchID;
/*      */   }
/*      */ 
/*      */   public long[] getCategoryID() {
/*  110 */     return this.categoryID;
/*      */   }
/*      */ 
/*      */   public void setCategoryID(long[] categoryID) {
/*  114 */     if ((categoryID != null) && (categoryID.length > 0))
/*  115 */       this.categoryID = categoryID;
/*      */   }
/*      */ 
/*      */   public long[] getForumID()
/*      */   {
/*  120 */     return this.forumID;
/*      */   }
/*      */ 
/*      */   public void setForumID(long[] forumID) {
/*  124 */     if ((forumID != null) && (forumID.length > 0))
/*  125 */       this.forumID = forumID;
/*      */   }
/*      */ 
/*      */   public String getUserID()
/*      */   {
/*  130 */     return this.userID;
/*      */   }
/*      */ 
/*      */   public void setUserID(String userID) {
/*  134 */     if ((userID != null) && (!"".equals(userID.trim())))
/*  135 */       this.userID = userID.trim();
/*      */   }
/*      */ 
/*      */   public String getThreadID()
/*      */   {
/*  140 */     return this.threadID;
/*      */   }
/*      */ 
/*      */   public void setThreadID(String threadID) {
/*  144 */     if ((threadID != null) && (!"".equals(threadID.trim())))
/*  145 */       this.threadID = threadID.trim();
/*      */   }
/*      */ 
/*      */   public boolean isSpellSuggestOn()
/*      */   {
/*  150 */     return this.spellSuggestOn;
/*      */   }
/*      */ 
/*      */   public void setSpellSuggestOn(boolean spellSuggestOn) {
/*  154 */     this.spellSuggestOn = spellSuggestOn;
/*      */   }
/*      */ 
/*      */   public boolean isDisplayPerThread() {
/*  158 */     return this.displayPerThread;
/*      */   }
/*      */ 
/*      */   public void setDisplayPerThread(boolean displayPerThread) {
/*  162 */     this.displayPerThread = displayPerThread;
/*      */   }
/*      */ 
/*      */   public boolean isAdvanced() {
/*  166 */     return this.advanced;
/*      */   }
/*      */ 
/*      */   public void setAdvanced(boolean advanced) {
/*  170 */     this.advanced = advanced;
/*      */   }
/*      */ 
/*      */   public int getNumResults() {
/*  174 */     return this.numResults;
/*      */   }
/*      */ 
/*      */   public void setNumResults(int numResults) {
/*  178 */     this.numResults = numResults;
/*      */   }
/*      */ 
/*      */   public int getRankBy()
/*      */   {
/*  186 */     return this.rankBy;
/*      */   }
/*      */ 
/*      */   public void setRankBy(int rankBy)
/*      */   {
/*  194 */     this.rankBy = rankBy;
/*      */   }
/*      */ 
/*      */   public String getDateRange() {
/*  198 */     if (this.dateRange == null) {
/*  199 */       return JiveGlobals.getJiveProperty("search.defaultdaterange", DEFAULT_DATE_RANGE.getID());
/*      */     }
/*  201 */     return this.dateRange;
/*      */   }
/*      */ 
/*      */   public void setDateRange(String dateRange) {
/*  205 */     this.dateRange = dateRange;
/*      */   }
/*      */ 
/*      */   public String getQ() {
/*  209 */     return this.q;
/*      */   }
/*      */ 
/*      */   public void setQ(String q) {
/*  213 */     if ((q != null) && (!"".equals(q.trim()))) {
/*  214 */       if ("*".equals(q)) {
/*  215 */         this.q = null;
/*      */       }
/*      */       else {
/*  218 */         this.q = q;
/*      */       }
/*      */     }
/*      */     else
/*  222 */       this.q = null;
/*      */   }
/*      */ 
/*      */   public String getQenc()
/*      */   {
/*  227 */     return this.qenc;
/*      */   }
/*      */ 
/*      */   public void setQenc(String qenc) {
/*  231 */     if ((qenc != null) && (!"".equals(qenc.trim())))
/*  232 */       this.qenc = qenc;
/*      */   }
/*      */ 
/*      */   public String getCorrectedQ()
/*      */   {
/*  237 */     if (this.correctedQ == null) {
/*  238 */       getSuggestedQuery();
/*      */     }
/*  240 */     if (this.correctedQ != null) {
/*  241 */       return this.correctedQ.equals("") ? null : this.correctedQ;
/*      */     }
/*      */ 
/*  244 */     return null;
/*      */   }
/*      */ 
/*      */   private void getSuggestedQuery()
/*      */   {
/*  249 */     if ((!this.spellSuggestOn) || (this.q == null) || ("".equals(this.q.trim()))) {
/*  250 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  254 */       SpellSession spellSession = SpellChecker.createSession(this.q);
/*  255 */       boolean foundAlternate = false;
/*  256 */       for (int result = spellSession.next(); result != 0; result = spellSession.next()) {
/*  257 */         if (result == 16) {
/*  258 */           String[] str = spellSession.getSuggestions();
/*  259 */           if (str.length > 0) {
/*  260 */             spellSession.replace("<em>" + str[0] + "</em>");
/*  261 */             foundAlternate = true;
/*      */           }
/*      */           else {
/*  264 */             spellSession.ignore();
/*      */           }
/*      */         }
/*  267 */         else if (result == 4) {
/*  268 */           spellSession.delete();
/*      */         }
/*      */         else {
/*  271 */           Log.error("Unexpected spell checking result code:" + result);
/*  272 */           spellSession.ignore();
/*      */         }
/*      */       }
/*  275 */       this.correctedQ = (foundAlternate ? spellSession.getText() : "");
/*  276 */       this.correctedURLQ = StringUtils.replace(this.correctedQ, "<em>", "");
/*  277 */       this.correctedURLQ = StringUtils.replace(this.correctedURLQ, "</em>", "");
/*      */     }
/*      */     catch (Exception e) {
/*  280 */       Log.warn("Got error searching for term '" + this.q + "' and trying to run spell check", e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getStart()
/*      */   {
/*  286 */     return this.start;
/*      */   }
/*      */ 
/*      */   public void setStart(int start) {
/*  290 */     this.start = start;
/*      */   }
/*      */ 
/*      */   public int getTotalItemCount()
/*      */   {
/*  295 */     return getResultCount();
/*      */   }
/*      */ 
/*      */   public ResultFilter getResultFilter()
/*      */   {
/*  300 */     ResultFilter filter = new ResultFilter();
/*  301 */     filter.setStartIndex(getStart());
/*  302 */     filter.setNumResults(getNumResults());
/*  303 */     return filter;
/*      */   }
/*      */ 
/*      */   public int getResultStart()
/*      */   {
/*  313 */     return getStart() + 1;
/*      */   }
/*      */ 
/*      */   public String getObjIDValue()
/*      */   {
/*  323 */     if ((this.forumID != null) && (this.forumID.length == 1)) {
/*  324 */       return "f" + String.valueOf(this.forumID[0]);
/*      */     }
/*  326 */     if ((this.categoryID != null) && (this.categoryID.length == 1)) {
/*  327 */       return "c" + String.valueOf(this.categoryID[0]);
/*      */     }
/*  329 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean getForumSelected(long fID) {
/*  333 */     if ((this.forumID != null) && (this.forumID.length == 1) && 
/*  334 */       (this.forumID[0] == fID)) {
/*  335 */       return true;
/*      */     }
/*      */ 
/*  338 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean getCategorySelected(long cID) {
/*  342 */     if ((this.categoryID != null) && (this.categoryID.length == 1) && 
/*  343 */       (this.categoryID[0] == cID)) {
/*  344 */       return true;
/*      */     }
/*      */ 
/*  347 */     return false;
/*      */   }
/*      */ 
/*      */   public ForumCategory getSearchedCategory()
/*      */   {
/*  358 */     if ((this.searchedCategories != null) && (this.searchedCategories.size() == 1) && (this.searchedCategory != null))
/*      */     {
/*  361 */       return this.searchedCategory;
/*      */     }
/*  363 */     return null;
/*      */   }
/*      */ 
/*      */   public List getSearchedCategories()
/*      */   {
/*  373 */     if (this.searchedCategories != null) {
/*  374 */       return this.searchedCategories;
/*      */     }
/*  376 */     return null;
/*      */   }
/*      */ 
/*      */   public Forum getSearchedForum()
/*      */   {
/*  387 */     if ((this.searchedForums != null) && (this.searchedForums.size() == 1) && (this.searchedForum != null))
/*      */     {
/*  390 */       return this.searchedForum;
/*      */     }
/*  392 */     return null;
/*      */   }
/*      */ 
/*      */   public List getSearchedForums()
/*      */   {
/*  402 */     if (this.searchedForums != null) {
/*  403 */       return this.searchedForums;
/*      */     }
/*  405 */     return null;
/*      */   }
/*      */ 
/*      */   public RelativeDateRange[] getDateRanges()
/*      */   {
/*  413 */     return DATE_RANGES;
/*      */   }
/*      */ 
/*      */   public User getSearchedUser()
/*      */   {
/*  421 */     return this.searchedUser;
/*      */   }
/*      */ 
/*      */   public int[] getNumResultOptions()
/*      */   {
/*  429 */     return RESULT_OPTIONS;
/*      */   }
/*      */ 
/*      */   public String getSearchParams()
/*      */   {
/*  443 */     if (this.partialQueryString == null) {
/*  444 */       StringBuffer buf = new StringBuffer();
/*      */ 
/*  446 */       if (this.qenc != null) {
/*  447 */         buf.append("qenc=").append(this.qenc).append("&");
/*      */       }
/*  449 */       else if (this.q != null)
/*      */         try {
/*  451 */           buf.append("q=");
/*  452 */           buf.append(StringUtils.URLEncode(this.q, JiveGlobals.getCharacterEncoding()));
/*  453 */           buf.append("&");
/*      */         }
/*      */         catch (UnsupportedEncodingException e)
/*      */         {
/*      */         }
/*  458 */       if (this.objID != null) {
/*  459 */         for (int i = 0; i < this.objID.length; i++) {
/*  460 */           buf.append("objID=").append(this.objID[i]).append("&");
/*      */         }
/*      */       }
/*      */ 
/*  464 */       if ((this.dateRange != null) && (!"all".equals(this.dateRange))) {
/*  465 */         buf.append("dateRange=").append(this.dateRange).append("&");
/*      */       }
/*      */ 
/*  468 */       if (this.searchedUser != null) {
/*  469 */         buf.append("userID=").append(this.searchedUser.getID()).append("&");
/*      */       }
/*      */ 
/*  472 */       if (this.numResults != 15) {
/*  473 */         buf.append("numResults=").append(this.numResults).append("&");
/*      */       }
/*      */ 
/*  476 */       if (this.advanced) {
/*  477 */         buf.append("advanced=").append(this.advanced).append("&");
/*      */       }
/*      */ 
/*  480 */       if (this.searchID != -1L) {
/*  481 */         buf.append("searchID=").append(this.searchID).append("&");
/*      */       }
/*      */ 
/*  485 */       if ((this.forumID != null) && (this.forumID.length == 1)) {
/*  486 */         buf.append("forumID=").append(String.valueOf(this.forumID[0])).append("&");
/*      */       }
/*      */ 
/*  490 */       buf.append("rankBy=").append(this.rankBy);
/*      */ 
/*  492 */       this.partialQueryString = buf.toString();
/*  493 */       if ((this.partialQueryString != null) && (this.partialQueryString.length() > 0) && 
/*  494 */         (this.partialQueryString.charAt(this.partialQueryString.length() - 1) == '&')) {
/*  495 */         this.partialQueryString = this.partialQueryString.substring(0, this.partialQueryString.length() - 1);
/*      */       }
/*      */     }
/*      */ 
/*  499 */     return this.partialQueryString;
/*      */   }
/*      */ 
/*      */   public String getCorrectedSearchParams()
/*      */   {
/*  512 */     if (this.partialCorrectedQueryString == null) {
/*  513 */       StringBuffer buf = new StringBuffer();
/*      */ 
/*  515 */       if (this.qenc != null) {
/*  516 */         buf.append("qenc=").append(this.qenc).append("&");
/*      */       }
/*  518 */       else if (this.q != null)
/*      */         try {
/*  520 */           buf.append("q=");
/*  521 */           buf.append(StringUtils.URLEncode(this.correctedURLQ, JiveGlobals.getCharacterEncoding()));
/*  522 */           buf.append("&");
/*      */         }
/*      */         catch (UnsupportedEncodingException e)
/*      */         {
/*      */         }
/*  527 */       if (this.objID != null) {
/*  528 */         for (int i = 0; i < this.objID.length; i++) {
/*  529 */           buf.append("objID=").append(this.objID[i]).append("&");
/*      */         }
/*      */       }
/*      */ 
/*  533 */       if ((this.dateRange != null) && (!"all".equals(this.dateRange))) {
/*  534 */         buf.append("dateRange=").append(this.dateRange).append("&");
/*      */       }
/*      */ 
/*  537 */       if (this.searchedUser != null) {
/*  538 */         buf.append("userID=").append(this.searchedUser.getID()).append("&");
/*      */       }
/*      */ 
/*  541 */       if (this.numResults != 15) {
/*  542 */         buf.append("dateRange=").append(this.dateRange).append("&");
/*      */       }
/*  544 */       this.partialCorrectedQueryString = buf.toString();
/*  545 */       if ((this.partialCorrectedQueryString != null) && (this.partialCorrectedQueryString.length() > 0) && 
/*  546 */         (this.partialCorrectedQueryString.charAt(this.partialCorrectedQueryString.length() - 1) == '&')) {
/*  547 */         this.partialCorrectedQueryString = this.partialCorrectedQueryString.substring(0, this.partialCorrectedQueryString.length() - 1);
/*      */       }
/*      */     }
/*      */ 
/*  551 */     return this.partialCorrectedQueryString;
/*      */   }
/*      */ 
/*      */   public Iterator getResults()
/*      */   {
/*  563 */     if (ActionContext.getContext().getActionInvocation().getProxy().getConfig().getMethodName() != null) {
/*  564 */       return Collections.EMPTY_LIST.iterator();
/*      */     }
/*  566 */     if ((this.q == null) && (this.searchedUser == null)) {
/*  567 */       return Collections.EMPTY_LIST.iterator();
/*      */     }
/*  569 */     if (this.results == null)
/*      */     {
/*  571 */       if ((this.displayPerThread) && (this.threadID == null)) {
/*  572 */         this.results = getQuery().getResultsByThread(getStart(), getNumResults());
/*  573 */         logSearchQuery(getQuery());
/*      */       }
/*      */       else {
/*  576 */         if (this.threadID != null) {
/*  577 */           getQuery().filterOnThread(this.searchedThread);
/*      */         }
/*  579 */         this.results = getQuery().getResults(getStart(), getNumResults());
/*  580 */         logSearchQuery(getQuery());
/*      */       }
/*      */ 
/*  583 */       if (this.results == null) {
/*  584 */         return Collections.EMPTY_LIST.iterator();
/*      */       }
/*      */     }
/*  587 */     return this.results;
/*      */   }
/*      */ 
/*      */   public int getResultCount()
/*      */   {
/*  596 */     if ((this.q == null) && (this.searchID == -1L) && (this.searchedUser == null)) {
/*  597 */       return 0;
/*      */     }
/*      */ 
/*  600 */     int resultCount = 0;
/*  601 */     if (getResults() != null) {
/*  602 */       if ((this.displayPerThread) && (this.threadID == null)) {
/*  603 */         resultCount = getQuery().getResultByThreadCount();
/*      */       }
/*      */       else {
/*  606 */         resultCount = getQuery().getResultCount();
/*      */       }
/*      */     }
/*      */ 
/*  610 */     return resultCount;
/*      */   }
/*      */ 
/*      */   public String[] getHighlightedText(QueryResult result)
/*      */   {
/*  624 */     if (result == null) {
/*  625 */       return new String[] { "", "" };
/*      */     }
/*      */ 
/*  628 */     if (getQuery() != null) {
/*  629 */       return getQuery().highlightResult(result, "<span class=\"jive-hilite\">", "</span>");
/*      */     }
/*      */ 
/*  632 */     return new String[] { result.getSubject(), "" };
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public String getMessageSubjectPreview(ForumMessage message)
/*      */   {
/*  642 */     if ((message != null) && (this.q != null)) {
/*  643 */       String[] queryWords = StringUtils.toLowerCaseWordArray(this.q);
/*  644 */       String subject = message.getUnfilteredSubject().trim();
/*  645 */       if (this.filterHTMLEnabled) {
/*  646 */         subject = StringUtils.stripTags(subject, true);
/*      */       }
/*      */ 
/*  649 */       subject = StringUtils.highlightWords(subject, queryWords, "<span class=\"jive-hilite\">", "</span>");
/*      */       try
/*      */       {
/*  655 */         DbForumFactory factory = DbForumFactory.getInstance();
/*  656 */         DbForumMessage dbMessage = (DbForumMessage)factory.getMessage(message.getID());
/*  657 */         FilterManager manager = dbMessage.getForumThread().getForum().getFilterManager();
/*  658 */         Filter[] filters = manager.getFilters();
/*  659 */         boolean found = false;
/*  660 */         for (int i = 0; i < filters.length; i++) {
/*  661 */           if ((filters[i] instanceof Profanity)) {
/*  662 */             Profanity f = (Profanity)filters[i];
/*  663 */             subject = f.doFilter(subject);
/*  664 */             found = true;
/*  665 */             break;
/*      */           }
/*      */         }
/*      */ 
/*  669 */         if (!found)
/*      */         {
/*  671 */           ForumCategory cat = dbMessage.getForumThread().getForum().getForumCategory();
/*  672 */           if ((cat != null) && (!found)) {
/*  673 */             manager = cat.getFilterManager();
/*  674 */             filters = manager.getFilters();
/*  675 */             for (int i = 0; i < filters.length; i++) {
/*  676 */               if ((filters[i] instanceof Profanity)) {
/*  677 */                 Profanity f = (Profanity)filters[i];
/*  678 */                 subject = f.doFilter(subject);
/*  679 */                 found = true;
/*  680 */                 break;
/*      */               }
/*      */             }
/*      */ 
/*  684 */             if (!found) {
/*  685 */               cat = cat.getParentCategory();
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  690 */           if (!found) {
/*  691 */             manager = DbForumFactory.getInstance().getFilterManager();
/*  692 */             filters = manager.getFilters();
/*  693 */             for (int i = 0; i < filters.length; i++)
/*  694 */               if ((filters[i] instanceof Profanity)) {
/*  695 */                 Profanity f = (Profanity)filters[i];
/*  696 */                 subject = f.doFilter(subject);
/*  697 */                 found = true;
/*  698 */                 break;
/*      */               }
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  705 */         Log.error(e);
/*      */       }
/*      */ 
/*  708 */       return subject;
/*      */     }
/*  710 */     if (message != null) {
/*  711 */       return message.getSubject().trim();
/*      */     }
/*      */ 
/*  714 */     return "";
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public String getMessageBodyPreview(ForumMessage message)
/*      */   {
/*  723 */     if ((message != null) && (this.q != null)) {
/*  724 */       String[] queryWords = StringUtils.toLowerCaseWordArray(this.q);
/*      */ 
/*  726 */       String body = message.getUnfilteredBody().trim();
/*  727 */       if (this.filterHTMLEnabled) {
/*  728 */         body = StringUtils.stripTags(body, true);
/*      */       }
/*  730 */       body = StringUtils.chopAtWordsAround(body, queryWords, 100);
/*  731 */       if (body.length() > 100) {
/*  732 */         body = body + " ...";
/*      */       }
/*  734 */       if (!this.filterHTMLEnabled) {
/*  735 */         body = StringUtils.escapeHTMLTags(body);
/*      */       }
/*  737 */       body = StringUtils.highlightWords(body, queryWords, "<span class=\"jive-hilite\">", "</span>");
/*      */       try
/*      */       {
/*  743 */         DbForumFactory factory = DbForumFactory.getInstance();
/*  744 */         DbForumMessage dbMessage = (DbForumMessage)factory.getMessage(message.getID());
/*  745 */         FilterManager manager = dbMessage.getForumThread().getForum().getFilterManager();
/*  746 */         Filter[] filters = manager.getFilters();
/*  747 */         boolean found = false;
/*  748 */         for (int i = 0; i < filters.length; i++) {
/*  749 */           if ((filters[i] instanceof Profanity)) {
/*  750 */             Profanity f = (Profanity)filters[i];
/*  751 */             body = f.doFilter(body);
/*  752 */             found = true;
/*  753 */             break;
/*      */           }
/*      */         }
/*      */ 
/*  757 */         if (!found)
/*      */         {
/*  759 */           ForumCategory cat = dbMessage.getForumThread().getForum().getForumCategory();
/*  760 */           if ((cat != null) && (!found)) {
/*  761 */             manager = cat.getFilterManager();
/*  762 */             filters = manager.getFilters();
/*  763 */             for (int i = 0; i < filters.length; i++) {
/*  764 */               if ((filters[i] instanceof Profanity)) {
/*  765 */                 Profanity f = (Profanity)filters[i];
/*  766 */                 body = f.doFilter(body);
/*  767 */                 found = true;
/*  768 */                 break;
/*      */               }
/*      */             }
/*      */ 
/*  772 */             if (!found) {
/*  773 */               cat = cat.getParentCategory();
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  778 */           if (!found) {
/*  779 */             manager = DbForumFactory.getInstance().getFilterManager();
/*  780 */             filters = manager.getFilters();
/*  781 */             for (int i = 0; i < filters.length; i++)
/*  782 */               if ((filters[i] instanceof Profanity)) {
/*  783 */                 Profanity f = (Profanity)filters[i];
/*  784 */                 body = f.doFilter(body);
/*  785 */                 found = true;
/*  786 */                 break;
/*      */               }
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  793 */         Log.error(e);
/*      */       }
/*      */ 
/*  796 */       return body;
/*      */     }
/*  798 */     return null;
/*      */   }
/*      */ 
/*      */   public String doDefault()
/*      */   {
/*  804 */     if (!JiveGlobals.getJiveBooleanProperty("search.enabled", true)) {
/*  805 */       return "disabled";
/*      */     }
/*  807 */     if (!loadJiveObjects()) {
/*  808 */       return "error";
/*      */     }
/*  810 */     RedirectAction.pushPreviousURL(ServletActionContext.getRequest());
/*  811 */     return "input";
/*      */   }
/*      */ 
/*      */   public String execute() {
/*  815 */     if (!JiveGlobals.getJiveBooleanProperty("search.enabled", true)) {
/*  816 */       return "disabled";
/*      */     }
/*  818 */     if (!loadJiveObjects()) {
/*  819 */       return "error";
/*      */     }
/*      */ 
/*  822 */     if ((this.q == null) && (this.searchID == -1L) && (this.searchedUser == null)) {
/*  823 */       addFieldError("q", getText("search.error_no_query_text"));
/*  824 */       return "input";
/*      */     }
/*      */ 
/*  827 */     RedirectAction.pushPreviousURL(ServletActionContext.getRequest());
/*      */ 
/*  830 */     getQuery();
/*      */ 
/*  832 */     return "success";
/*      */   }
/*      */ 
/*      */   private void logSearchQuery(Query q)
/*      */   {
/*  844 */     Map session = ActionContext.getContext().getSession();
/*  845 */     if (session.get("jive.forum.search.query") != null) {
/*  846 */       SessionQuery previousQuery = (SessionQuery)session.get("jive.forum.search.query");
/*      */ 
/*  849 */       if (previousQuery.equals(q)) {
/*  850 */         this.searchID = previousQuery.getSearchID();
/*      */       }
/*      */ 
/*  853 */       if ((!previousQuery.equals(q)) || (this.searchID == -1L)) {
/*  854 */         this.searchID = q.logQuery(getPageUser());
/*  855 */         session.put("jive.forum.search.query", new SessionQuery(q));
/*      */       }
/*      */     }
/*      */     else {
/*  859 */       this.searchID = q.logQuery(getPageUser());
/*  860 */       session.put("jive.forum.search.query", new SessionQuery(q));
/*      */     }
/*      */   }
/*      */ 
/*      */   private Query getQuery() {
/*  865 */     if (this.query != null) {
/*  866 */       return this.query;
/*      */     }
/*  868 */     if ((this.q == null) && (this.searchID == -1L) && (this.searchedUser == null)) {
/*  869 */       return null;
/*      */     }
/*  871 */     if ((this.searchID != -1L) && ((Version.getEdition() == Version.Edition.ENTERPRISE) || (Version.getEdition() == Version.Edition.EXPERT)))
/*      */     {
/*      */       try
/*      */       {
/*  876 */         Class clazz = ClassUtils.forName("com.jivesoftware.forum.QueryLoggerFactory");
/*  877 */         Method m1 = clazz.getMethod("getInstance", new Class[] { AuthToken.class });
/*  878 */         Object qLogger = m1.invoke(null, new Object[] { getAuthToken() });
/*  879 */         Class clazz2 = ClassUtils.forName("com.jivesoftware.forum.QueryLogger");
/*  880 */         Method m2 = clazz2.getMethod("getQuery", new Class[] { Long.TYPE });
/*  881 */         this.query = ((Query)m2.invoke(qLogger, new Object[] { new Long(this.searchID) }));
/*      */ 
/*  884 */         Method m3 = clazz2.getMethod("getLoggedQueryInfo", new Class[] { Query.class });
/*  885 */         Map queryInfo = (Map)m3.invoke(qLogger, new Object[] { this.query });
/*      */ 
/*  888 */         this.q = this.query.getQueryString();
/*  889 */         this.advanced = (this.advanced == true);
/*      */ 
/*  891 */         if (this.query.getAfterDate() != null) {
/*  892 */           long afterDate = this.query.getAfterDate().getTime();
/*  893 */           long searchDate = ((Date)queryInfo.get("searchDate")).getTime();
/*  894 */           for (int i = 1; i < DATE_RANGES.length; i++) {
/*  895 */             long startDate = DATE_RANGES[i].getStartDate(new Date(searchDate)).getTime();
/*  896 */             if (startDate >= afterDate)
/*      */             {
/*  898 */               if (startDate - afterDate <= 86400000L) {
/*  899 */                 this.dateRange = DATE_RANGES[i].getID();
/*  900 */                 break;
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  907 */         this.query.setSortField(this.rankBy);
/*      */ 
/*  909 */         if (this.query.getFilteredThread() != null) {
/*  910 */           this.searchedThread = this.query.getFilteredThread();
/*  911 */           this.threadID = ("" + this.searchedThread.getID());
/*      */         }
/*  913 */         if (this.query.getFilteredUser() != null) {
/*  914 */           this.searchedUser = this.query.getFilteredUser();
/*  915 */           this.userID = ("" + this.searchedUser.getID());
/*      */         }
/*      */ 
/*  918 */         Forum[] f = (Forum[])queryInfo.get("forums");
/*  919 */         if (f != null) {
/*  920 */           LongList fids = new LongList();
/*  921 */           if (f.length == 1) {
/*  922 */             this.searchedForum = f[0];
/*  923 */             fids.add(f[0].getID());
/*      */           }
/*      */           else {
/*  926 */             this.searchedForums = new ArrayList();
/*  927 */             for (int i = 0; i < f.length; i++) {
/*  928 */               this.searchedForums.add(f[i]);
/*  929 */               fids.add(f[i].getID());
/*      */             }
/*      */           }
/*      */ 
/*  933 */           this.forumID = fids.toArray();
/*      */         }
/*      */       } catch (ClassNotFoundException e) {
/*      */       } catch (InvocationTargetException e) {
/*      */       }
/*      */       catch (Exception e) {
/*  939 */         Log.error(e);
/*      */       }
/*      */     }
/*      */ 
/*  943 */     if (this.query == null)
/*      */     {
/*  947 */       if ((this.searchedForum != null) && (this.searchedCategory != null))
/*      */       {
/*  949 */         this.query = getForumFactory().getQueryManager().createQuery();
/*      */       }
/*      */       else
/*      */       {
/*  954 */         List forums = new LinkedList();
/*  955 */         if ((this.searchedForums != null) && (this.searchedForums.size() > 0)) {
/*  956 */           for (int i = 0; i < this.searchedForums.size(); i++) {
/*  957 */             Forum f = (Forum)this.searchedForums.get(i);
/*  958 */             if (!forums.contains(f)) {
/*  959 */               forums.add(f);
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*  964 */         if ((this.searchedCategories != null) && (this.searchedCategories.size() > 0))
/*      */         {
/*      */           Iterator iter;
/*  965 */           for (int i = 0; i < this.searchedCategories.size(); i++) {
/*  966 */             ForumCategory cat = (ForumCategory)this.searchedCategories.get(i);
/*  967 */             for (iter = cat.getRecursiveForums(); iter.hasNext(); ) {
/*  968 */               Forum f = (Forum)iter.next();
/*  969 */               if (!forums.contains(f)) {
/*  970 */                 forums.add(f);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*  976 */         if ((forums.size() == 0) && (this.searchedForum == null) && (this.searchedCategory == null)) {
/*  977 */           this.query = getForumFactory().getQueryManager().createQuery((Forum[])null);
/*      */         }
/*      */         else {
/*  980 */           this.query = getForumFactory().getQueryManager().createQuery((Forum[])forums.toArray(new Forum[forums.size()]));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  988 */       if (this.qenc != null) {
/*  989 */         this.q = new String(StringUtils.decodeHex(this.qenc));
/*      */       }
/*  991 */       if (this.q != null) {
/*  992 */         this.query.setQueryString(this.q);
/*      */ 
/*  994 */         this.q = this.query.getQueryString();
/*      */       }
/*      */       else {
/*  997 */         this.query.setQueryString(null);
/*      */       }
/*      */ 
/* 1000 */       if (this.searchedUser != null) {
/* 1001 */         this.query.filterOnUser(this.searchedUser);
/*      */       }
/*      */ 
/* 1004 */       if ((this.dateRange != null) && (!"all".equals(this.dateRange))) {
/* 1005 */         RelativeDateRange range = null;
/* 1006 */         for (int i = 0; i < DATE_RANGES.length; i++) {
/* 1007 */           if (DATE_RANGES[i].getID().equals(this.dateRange)) {
/* 1008 */             range = DATE_RANGES[i];
/* 1009 */             break;
/*      */           }
/*      */         }
/* 1012 */         if (range != null) {
/* 1013 */           this.query.setAfterDate(range.getStartDate(new Date()));
/*      */         }
/*      */       }
/*      */ 
/* 1017 */       this.query.setSortField(this.rankBy);
/* 1018 */       this.query.setSortOrder(0);
/*      */     }
/*      */ 
/* 1021 */     return this.query;
/*      */   }
/*      */ 
/*      */   private boolean loadJiveObjects() {
/* 1025 */     updateIDs();
/* 1026 */     boolean success = true;
/*      */ 
/* 1029 */     if ((this.categoryID != null) && (this.categoryID.length > 0)) {
/* 1030 */       boolean catSuccess = false;
/* 1031 */       this.searchedCategories = new LinkedList();
/* 1032 */       for (int i = 0; i < this.categoryID.length; i++)
/*      */         try {
/* 1034 */           this.searchedCategories.add(getForumFactory().getForumCategory(this.categoryID[i]));
/* 1035 */           catSuccess = true;
/*      */         }
/*      */         catch (ForumCategoryNotFoundException ignored) {
/*      */         }
/* 1039 */       if (!catSuccess) {
/* 1040 */         addActionError(getText("search.error_failed_to_load_cat_ids"));
/* 1041 */         success = false;
/*      */       }
/* 1045 */       else if (this.searchedCategories.size() == 1) {
/* 1046 */         this.searchedCategory = ((ForumCategory)this.searchedCategories.get(0));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1052 */     if ((this.forumID != null) && (this.forumID.length > 0)) {
/* 1053 */       boolean forumSuccess = false;
/* 1054 */       this.searchedForums = new LinkedList();
/* 1055 */       for (int i = 0; i < this.forumID.length; i++)
/*      */         try {
/* 1057 */           this.searchedForums.add(getForumFactory().getForum(this.forumID[i]));
/* 1058 */           forumSuccess = true;
/*      */         } catch (ForumNotFoundException ignored) {
/*      */         }
/*      */         catch (UnauthorizedException ue) {
/*      */         }
/* 1063 */       if (!forumSuccess) {
/* 1064 */         addActionError(getText("search.error_failed_to_load_forum_ids"));
/* 1065 */         success = false;
/*      */       }
/* 1069 */       else if (this.searchedForums.size() == 1) {
/* 1070 */         this.searchedForum = ((Forum)this.searchedForums.get(0));
/*      */       }
/*      */     }
/*      */ 
/* 1074 */     if ((this.threadID != null) && (!this.threadID.equals(""))) {
/*      */       try {
/* 1076 */         this.searchedThread = getForumFactory().getForumThread(Long.parseLong(this.threadID));
/*      */       } catch (ForumThreadNotFoundException e) {
/* 1078 */         Log.error(e);
/*      */       } catch (UnauthorizedException e) {
/* 1080 */         Log.error(e);
/*      */       } catch (NumberFormatException e) {
/* 1082 */         Log.error(e);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1087 */     if (this.userID != null) {
/*      */       try {
/* 1089 */         this.searchedUser = getForumFactory().getUserManager().getUser(Long.parseLong(this.userID));
/*      */       }
/*      */       catch (Exception ignored) {
/*      */         try {
/* 1093 */           this.searchedUser = getForumFactory().getUserManager().getUser(this.userID);
/*      */         }
/*      */         catch (Exception ignored2) {
/* 1096 */           addFieldError("userID", getText("search.error_not_find_user"));
/*      */         }
/*      */       }
/*      */     }
/* 1100 */     return success;
/*      */   }
/*      */ 
/*      */   private void updateIDs()
/*      */   {
/* 1106 */     if (this.objID != null) {
/* 1107 */       List cIDs = new ArrayList();
/* 1108 */       List fIDs = new ArrayList();
/* 1109 */       for (int i = 0; i < this.objID.length; i++)
/*      */         try {
/* 1111 */           String id = this.objID[i];
/* 1112 */           if (id.indexOf("c") == 0) {
/* 1113 */             cIDs.add(new Long(id.substring(1, id.length())));
/*      */           }
/* 1115 */           else if (id.indexOf("f") == 0)
/* 1116 */             fIDs.add(new Long(id.substring(1, id.length())));
/*      */         }
/*      */         catch (Exception ignored)
/*      */         {
/*      */         }
/* 1121 */       this.categoryID = new long[cIDs.size()];
/* 1122 */       for (int i = 0; i < cIDs.size(); i++) {
/* 1123 */         this.categoryID[i] = ((Long)cIDs.get(i)).longValue();
/*      */       }
/* 1125 */       this.forumID = new long[fIDs.size()];
/* 1126 */       for (int i = 0; i < fIDs.size(); i++)
/* 1127 */         this.forumID[i] = ((Long)fIDs.get(i)).longValue();
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.SearchAction
 * JD-Core Version:    0.6.2
 */
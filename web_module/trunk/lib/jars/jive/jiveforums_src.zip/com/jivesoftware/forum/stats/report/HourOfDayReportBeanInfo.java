/*    */ package com.jivesoftware.forum.stats.report;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class HourOfDayReportBeanInfo extends JiveBeanInfo
/*    */ {
/*    */   public String[] getPropertyNames()
/*    */   {
/* 17 */     return new String[0];
/*    */   }
/*    */   public Class getBeanClass() {
/* 20 */     return HourOfDayReport.class;
/*    */   }
/*    */   public String getName() {
/* 23 */     return "HourOfDayReport";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.HourOfDayReportBeanInfo
 * JD-Core Version:    0.6.2
 */
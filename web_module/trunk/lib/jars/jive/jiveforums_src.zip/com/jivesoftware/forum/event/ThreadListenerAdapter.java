package com.jivesoftware.forum.event;

public abstract class ThreadListenerAdapter
  implements ThreadListener
{
  public void threadAdded(ThreadEvent event)
  {
  }

  public void threadDeleted(ThreadEvent event)
  {
  }

  public void threadMoved(ThreadEvent event)
  {
  }

  public void threadModerationModified(ThreadEvent event)
  {
  }

  public void threadRated(ThreadEvent event)
  {
  }
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.ThreadListenerAdapter
 * JD-Core Version:    0.6.2
 */
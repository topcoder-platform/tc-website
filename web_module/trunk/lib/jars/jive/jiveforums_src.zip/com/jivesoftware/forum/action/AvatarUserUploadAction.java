/*    */ package com.jivesoftware.forum.action;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.User;
/*    */ import com.jivesoftware.base.UserManager;
/*    */ import com.jivesoftware.base.UserNotFoundException;
/*    */ import com.jivesoftware.forum.AvatarManager;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ import com.opensymphony.xwork.Preparable;
/*    */ 
/*    */ public class AvatarUserUploadAction extends AvatarUploadAction
/*    */   implements Preparable
/*    */ {
/*    */   public void prepare()
/*    */     throws Exception
/*    */   {
/* 38 */     AuthToken token = getAuthToken();
/*    */ 
/* 40 */     if ((token.isAnonymous()) || (token.getUserID() < 1L)) {
/* 41 */       throw new UserNotFoundException();
/*    */     }
/*    */ 
/* 44 */     User user = getForumFactory().getUserManager().getUser(getAuthToken().getUserID());
/*    */ 
/* 46 */     setUser(user);
/*    */   }
/*    */ 
/*    */   public String execute() throws Exception {
/* 50 */     AvatarManager avatarManager = getForumFactory().getAvatarManager();
/*    */ 
/* 52 */     int maxUserAvatars = avatarManager.getMaxUserAvatars();
/* 53 */     int userAvatarCount = avatarManager.getAvatarCount(getUser());
/*    */ 
/* 56 */     if ((maxUserAvatars != -1) && (userAvatarCount + 1 > maxUserAvatars)) {
/* 57 */       addFieldError("image", getText("avatar.upload.error.limit"));
/* 58 */       return "error";
/*    */     }
/*    */ 
/* 61 */     return super.execute();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AvatarUserUploadAction
 * JD-Core Version:    0.6.2
 */
package com.jivesoftware.forum.event;

public abstract class MessageListenerAdapter
  implements MessageListener
{
  public void messageAdded(MessageEvent event)
  {
  }

  public void messageDeleted(MessageEvent event)
  {
  }

  public void messageModified(MessageEvent event)
  {
  }

  public void messageMoved(MessageEvent event)
  {
  }

  public void messageModerationModified(MessageEvent event)
  {
  }

  public void messageRated(MessageEvent event)
  {
  }
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.event.MessageListenerAdapter
 * JD-Core Version:    0.6.2
 */
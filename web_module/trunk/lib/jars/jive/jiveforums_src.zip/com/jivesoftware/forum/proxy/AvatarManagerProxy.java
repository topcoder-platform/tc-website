/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Avatar;
/*     */ import com.jivesoftware.forum.AvatarException;
/*     */ import com.jivesoftware.forum.AvatarManager;
/*     */ import com.jivesoftware.forum.AvatarNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import java.io.InputStream;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class AvatarManagerProxy
/*     */   implements AvatarManager
/*     */ {
/*     */   private AvatarManager avatarManager;
/*     */   private Permissions permissions;
/*     */   private AuthToken authToken;
/*     */   private ForumFactory forumFactory;
/*     */ 
/*     */   public AvatarManagerProxy(AvatarManager avatarManager, AuthToken authToken, Permissions permissions)
/*     */   {
/*  35 */     this.authToken = authToken;
/*  36 */     this.avatarManager = avatarManager;
/*  37 */     this.permissions = permissions;
/*  38 */     this.forumFactory = ForumFactory.getInstance(authToken);
/*     */   }
/*     */ 
/*     */   public Avatar createAvatar(User owner, String name, String contentType, InputStream in) throws UnauthorizedException, AvatarException
/*     */   {
/*  43 */     securityCheck();
/*  44 */     return this.avatarManager.createAvatar(owner, name, contentType, in);
/*     */   }
/*     */ 
/*     */   public void setActiveAvatar(User user, Avatar avatar) throws UnauthorizedException {
/*  48 */     securityCheck();
/*     */ 
/*  50 */     if (avatar != null) {
/*  51 */       if ((avatar.getOwner() != null) && (!avatar.getOwner().equals(user))) {
/*  52 */         throw new UnauthorizedException("User does own the avatar or it is not global");
/*     */       }
/*     */ 
/*  55 */       if ((this.avatarManager.isModerateUserAvatars()) && (avatar.getModValue() < 1) && (avatar.getOwner() != null)) {
/*  56 */         throw new UnauthorizedException("avatar moderaton value is less than 1 ");
/*     */       }
/*     */     }
/*     */ 
/*  60 */     this.avatarManager.setActiveAvatar(user, avatar);
/*     */   }
/*     */ 
/*     */   public Avatar getAvatar(long id) throws AvatarNotFoundException {
/*  64 */     return this.avatarManager.getAvatar(id);
/*     */   }
/*     */ 
/*     */   public Iterator getAvatars(User user) {
/*  68 */     return new AvatarIteratorProxy(this.avatarManager.getAvatars(user), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public Avatar getActiveAvatar(User user) {
/*  72 */     return this.avatarManager.getActiveAvatar(user);
/*     */   }
/*     */ 
/*     */   public Iterator getGlobalAvatars() {
/*  76 */     return new AvatarIteratorProxy(this.avatarManager.getGlobalAvatars(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public void deleteAvatar(Avatar avatar) throws UnauthorizedException {
/*  80 */     securityCheck();
/*  81 */     this.avatarManager.deleteAvatar(avatar);
/*     */   }
/*     */ 
/*     */   public void setAvatarsEnabled(boolean enabled) throws UnauthorizedException {
/*  85 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/*  86 */       throw new UnauthorizedException("Must be SYSTEM_ADMIN");
/*     */     }
/*  88 */     this.avatarManager.setAvatarsEnabled(enabled);
/*     */   }
/*     */ 
/*     */   public boolean isAvatarsEnabled() {
/*  92 */     return this.avatarManager.isAvatarsEnabled();
/*     */   }
/*     */ 
/*     */   public int getMaxAllowableHeight() {
/*  96 */     return this.avatarManager.getMaxAllowableHeight();
/*     */   }
/*     */ 
/*     */   public void setMaxAllowableHeight(int height) throws UnauthorizedException {
/* 100 */     this.avatarManager.setMaxAllowableHeight(height);
/*     */   }
/*     */ 
/*     */   public int getMaxAllowableWidth() {
/* 104 */     return this.avatarManager.getMaxAllowableWidth();
/*     */   }
/*     */ 
/*     */   public int getAvatarCount(User user) {
/* 108 */     return this.avatarManager.getAvatarCount(user);
/*     */   }
/*     */ 
/*     */   public boolean isModerateUserAvatars() {
/* 112 */     return this.avatarManager.isModerateUserAvatars();
/*     */   }
/*     */ 
/*     */   public void setModerateUserAvatars(boolean moderateUserAvatars) throws UnauthorizedException {
/* 116 */     this.avatarManager.setModerateUserAvatars(moderateUserAvatars);
/*     */   }
/*     */ 
/*     */   public Iterator getModerationAvatars() throws UnauthorizedException {
/* 120 */     return new AvatarIteratorProxy(this.avatarManager.getModerationAvatars(), this.authToken, this.permissions);
/*     */   }
/*     */ 
/*     */   public int getModerationAvatarCount() {
/* 124 */     return this.avatarManager.getModerationAvatarCount();
/*     */   }
/*     */ 
/*     */   public void setMaxAllowableWidth(int width) throws UnauthorizedException {
/* 128 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/* 129 */       throw new UnauthorizedException("Must be SYSTEM_ADMIN");
/*     */     }
/* 131 */     this.avatarManager.setMaxAllowableWidth(width);
/*     */   }
/*     */ 
/*     */   public boolean isAllowImageResize() {
/* 135 */     return this.avatarManager.isAllowImageResize();
/*     */   }
/*     */ 
/*     */   public void setAllowImageResize(boolean isAllowImageResize) throws UnauthorizedException {
/* 139 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/* 140 */       throw new UnauthorizedException("Must be SYSTEM_ADMIN");
/*     */     }
/* 142 */     this.avatarManager.setAllowImageResize(isAllowImageResize);
/*     */   }
/*     */ 
/*     */   public int getMaxUserAvatars() {
/* 146 */     return this.avatarManager.getMaxUserAvatars();
/*     */   }
/*     */ 
/*     */   public void setMaxUserAvatars(int max) throws UnauthorizedException {
/* 150 */     if (!this.permissions.hasPermission(576460752303423488L)) {
/* 151 */       throw new UnauthorizedException("Must be SYSTEM_ADMIN");
/*     */     }
/* 153 */     this.avatarManager.setMaxUserAvatars(max);
/*     */   }
/*     */ 
/*     */   private void securityCheck() throws UnauthorizedException
/*     */   {
/* 158 */     if ((!this.permissions.hasPermission(576460752303423488L)) && (!this.permissions.hasPermission(8192L)) && (!this.permissions.hasPermission(256L)) && (!this.permissions.hasPermission(512L)) && (!this.forumFactory.isAuthorized(128L)))
/*     */     {
/* 163 */       throw new UnauthorizedException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.AvatarManagerProxy
 * JD-Core Version:    0.6.2
 */
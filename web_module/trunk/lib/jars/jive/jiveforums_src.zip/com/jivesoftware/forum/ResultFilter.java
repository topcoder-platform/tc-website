/*     */ package com.jivesoftware.forum;
/*     */ 
/*     */ import com.jivesoftware.base.action.util.DateUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ResultFilter
/*     */ {
/*     */   public static final int DESCENDING = 0;
/*     */   public static final int ASCENDING = 1;
/*     */   public static final int NULL_INT = 2147483524;
/* 104 */   private int sortField = 9;
/* 105 */   private int sortOrder = 0;
/* 106 */   private String sortPropertyName = null;
/*     */ 
/* 111 */   private int startIndex = 0;
/*     */ 
/* 117 */   private int numResults = 2147483524;
/*     */ 
/* 119 */   private long userID = 2147483524L;
/* 120 */   private List propertyNames = new ArrayList();
/* 121 */   private List propertyValues = new ArrayList();
/* 122 */   private Date creationDateRangeMin = null;
/* 123 */   private Date creationDateRangeMax = null;
/* 124 */   private Date modificationDateRangeMin = null;
/* 125 */   private Date modificationDateRangeMax = null;
/*     */ 
/* 127 */   private int moderationRangeMin = 2147483524;
/* 128 */   private int moderationRangeMax = 2147483524;
/*     */ 
/*     */   public static ResultFilter createDefaultForumFilter()
/*     */   {
/*  67 */     ResultFilter resultFilter = new ResultFilter();
/*  68 */     resultFilter.setSortField(15);
/*  69 */     resultFilter.setSortOrder(1);
/*  70 */     return resultFilter;
/*     */   }
/*     */ 
/*     */   public static ResultFilter createDefaultThreadFilter()
/*     */   {
/*  78 */     ResultFilter resultFilter = new ResultFilter();
/*  79 */     return resultFilter;
/*     */   }
/*     */ 
/*     */   public static ResultFilter createDefaultMessageFilter()
/*     */   {
/*  87 */     ResultFilter resultFilter = new ResultFilter();
/*  88 */     resultFilter.setSortField(8);
/*  89 */     resultFilter.setSortOrder(1);
/*  90 */     return resultFilter;
/*     */   }
/*     */ 
/*     */   public static ResultFilter createDefaultUserMessagesFilter()
/*     */   {
/*  98 */     ResultFilter resultFilter = new ResultFilter();
/*  99 */     resultFilter.setSortField(8);
/* 100 */     resultFilter.setSortOrder(0);
/* 101 */     return resultFilter;
/*     */   }
/*     */ 
/*     */   public long getUserID()
/*     */   {
/* 138 */     return this.userID;
/*     */   }
/*     */ 
/*     */   public void setUserID(long userID)
/*     */   {
/* 150 */     this.userID = userID;
/*     */   }
/*     */ 
/*     */   public void addProperty(String name, String value)
/*     */   {
/* 173 */     if (this.propertyNames.contains(name)) {
/* 174 */       int index = this.propertyNames.indexOf(name);
/* 175 */       this.propertyNames.remove(index);
/* 176 */       this.propertyValues.remove(index);
/*     */     }
/* 178 */     this.propertyNames.add(name);
/* 179 */     this.propertyValues.add(value);
/*     */   }
/*     */ 
/*     */   public int getPropertyCount()
/*     */   {
/* 188 */     return this.propertyNames.size();
/*     */   }
/*     */ 
/*     */   public String getPropertyName(int index)
/*     */   {
/* 200 */     if ((index >= 0) && (index < this.propertyNames.size())) {
/* 201 */       return (String)this.propertyNames.get(index);
/*     */     }
/*     */ 
/* 204 */     return null;
/*     */   }
/*     */ 
/*     */   public String getPropertyValue(int index)
/*     */   {
/* 217 */     if ((index >= 0) && (index < this.propertyValues.size())) {
/* 218 */       return (String)this.propertyValues.get(index);
/*     */     }
/*     */ 
/* 221 */     return null;
/*     */   }
/*     */ 
/*     */   public Date getCreationDateRangeMin()
/*     */   {
/* 234 */     return this.creationDateRangeMin;
/*     */   }
/*     */ 
/*     */   public void setCreationDateRangeMin(Date creationDateRangeMin)
/*     */   {
/* 253 */     this.creationDateRangeMin = creationDateRangeMin;
/*     */   }
/*     */ 
/*     */   public Date getCreationDateRangeMax()
/*     */   {
/* 265 */     return this.creationDateRangeMax;
/*     */   }
/*     */ 
/*     */   public void setCreationDateRangeMax(Date creationDateRangeMax)
/*     */   {
/* 284 */     this.creationDateRangeMax = creationDateRangeMax;
/*     */   }
/*     */ 
/*     */   public Date getModificationDateRangeMin()
/*     */   {
/* 297 */     return this.modificationDateRangeMin;
/*     */   }
/*     */ 
/*     */   public void setModificationDateRangeMin(Date modificationDateRangeMin)
/*     */   {
/* 316 */     this.modificationDateRangeMin = modificationDateRangeMin;
/*     */   }
/*     */ 
/*     */   public Date getModificationDateRangeMax()
/*     */   {
/* 328 */     return this.modificationDateRangeMax;
/*     */   }
/*     */ 
/*     */   public void setModificationDateRangeMax(Date modificationDateRangeMax)
/*     */   {
/* 347 */     this.modificationDateRangeMax = modificationDateRangeMax;
/*     */   }
/*     */ 
/*     */   public int getSortField()
/*     */   {
/* 371 */     return this.sortField;
/*     */   }
/*     */ 
/*     */   public void setSortField(int sortField)
/*     */   {
/* 395 */     this.sortField = sortField;
/*     */   }
/*     */ 
/*     */   public String getSortPropertyName()
/*     */   {
/* 405 */     return this.sortPropertyName;
/*     */   }
/*     */ 
/*     */   public void setSortPropertyName(String sortPropertyName)
/*     */   {
/* 415 */     this.sortPropertyName = sortPropertyName;
/*     */   }
/*     */ 
/*     */   public int getSortOrder()
/*     */   {
/* 426 */     return this.sortOrder;
/*     */   }
/*     */ 
/*     */   public void setSortOrder(int sortOrder)
/*     */   {
/* 437 */     if ((sortOrder != 1) && (sortOrder != 0)) {
/* 438 */       throw new IllegalArgumentException();
/*     */     }
/* 440 */     this.sortOrder = sortOrder;
/*     */   }
/*     */ 
/*     */   public int getNumResults()
/*     */   {
/* 453 */     return this.numResults;
/*     */   }
/*     */ 
/*     */   public void setNumResults(int numResults)
/*     */   {
/* 462 */     if ((numResults != 2147483524) && (numResults < 0)) {
/* 463 */       throw new IllegalArgumentException("numResults cannot be less than 0.");
/*     */     }
/* 465 */     this.numResults = numResults;
/*     */   }
/*     */ 
/*     */   public int getStartIndex()
/*     */   {
/* 474 */     return this.startIndex;
/*     */   }
/*     */ 
/*     */   public void setStartIndex(int startIndex)
/*     */   {
/* 486 */     if (startIndex < 0) {
/* 487 */       throw new IllegalArgumentException("A start index less than 0 is not valid.");
/*     */     }
/* 489 */     this.startIndex = startIndex;
/*     */   }
/*     */ 
/*     */   public int getModerationRangeMin()
/*     */   {
/* 512 */     return this.moderationRangeMin;
/*     */   }
/*     */ 
/*     */   public void setModerationRangeMin(int moderationRangeMin)
/*     */   {
/* 524 */     this.moderationRangeMin = moderationRangeMin;
/*     */   }
/*     */ 
/*     */   public int getModerationRangeMax()
/*     */   {
/* 535 */     return this.moderationRangeMax;
/*     */   }
/*     */ 
/*     */   public void setModerationRangeMax(int moderationRangeMax)
/*     */   {
/* 546 */     this.moderationRangeMax = moderationRangeMax;
/*     */   }
/*     */ 
/*     */   public static Date roundDate(Date date, int seconds)
/*     */   {
/* 553 */     return DateUtils.roundDate(date, seconds);
/*     */   }
/*     */ 
/*     */   public static long roundDate(long date, int seconds)
/*     */   {
/* 560 */     return DateUtils.roundDate(date, seconds);
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 567 */     ResultFilter clonedFilter = new ResultFilter();
/* 568 */     clonedFilter.setCreationDateRangeMax(new Date(getCreationDateRangeMax().getTime()));
/* 569 */     clonedFilter.setCreationDateRangeMin(new Date(getCreationDateRangeMin().getTime()));
/* 570 */     clonedFilter.setModerationRangeMax(getModerationRangeMax());
/* 571 */     clonedFilter.setModerationRangeMin(getModerationRangeMin());
/* 572 */     clonedFilter.setModificationDateRangeMax(getModificationDateRangeMax());
/* 573 */     clonedFilter.setModificationDateRangeMin(getModificationDateRangeMin());
/* 574 */     clonedFilter.setNumResults(getNumResults());
/* 575 */     clonedFilter.setSortField(getSortField());
/* 576 */     clonedFilter.setSortOrder(getSortOrder());
/* 577 */     clonedFilter.setSortPropertyName(getSortPropertyName());
/* 578 */     clonedFilter.setStartIndex(getStartIndex());
/* 579 */     clonedFilter.setUserID(getUserID());
/* 580 */     return clonedFilter;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object object) {
/* 584 */     if (this == object) {
/* 585 */       return true;
/*     */     }
/* 587 */     if ((object != null) && ((object instanceof ResultFilter))) {
/* 588 */       ResultFilter o = (ResultFilter)object;
/* 589 */       return (this.sortField == o.sortField) && (this.sortOrder == o.sortOrder) && (((this.sortPropertyName == null) && (o.sortPropertyName == null)) || ((this.sortPropertyName.equals(o.sortPropertyName)) && (this.userID == o.userID) && (this.propertyNames.equals(o.propertyNames)) && (this.propertyValues.equals(o.propertyValues)) && (((this.creationDateRangeMin == null) && (o.creationDateRangeMin == null)) || ((this.creationDateRangeMin.equals(o.creationDateRangeMin)) && (((this.creationDateRangeMax == null) && (o.creationDateRangeMax == null)) || ((this.creationDateRangeMax.equals(o.creationDateRangeMax)) && (((this.modificationDateRangeMin == null) && (o.modificationDateRangeMin == null)) || ((this.modificationDateRangeMin.equals(o.modificationDateRangeMin)) && (((this.modificationDateRangeMax == null) && (o.modificationDateRangeMax == null)) || ((this.modificationDateRangeMax.equals(o.modificationDateRangeMax)) && (this.moderationRangeMin == o.moderationRangeMin) && (this.moderationRangeMax == o.moderationRangeMax)))))))))));
/*     */     }
/*     */ 
/* 609 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.ResultFilter
 * JD-Core Version:    0.6.2
 */
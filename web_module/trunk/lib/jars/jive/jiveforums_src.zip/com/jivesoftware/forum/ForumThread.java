package com.jivesoftware.forum;

import com.jivesoftware.base.AuthToken;
import com.jivesoftware.base.UnauthorizedException;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

public abstract interface ForumThread
{
  public abstract long getID();

  public abstract String getName();

  public abstract Date getCreationDate();

  public abstract void setCreationDate(Date paramDate)
    throws UnauthorizedException;

  public abstract Date getModificationDate();

  public abstract void setModificationDate(Date paramDate)
    throws UnauthorizedException;

  public abstract int getModerationValue();

  public abstract void setModerationValue(int paramInt, AuthToken paramAuthToken)
    throws UnauthorizedException;

  public abstract String getProperty(String paramString);

  public abstract Collection getProperties(String paramString);

  public abstract void setProperty(String paramString1, String paramString2)
    throws UnauthorizedException;

  public abstract void deleteProperty(String paramString)
    throws UnauthorizedException;

  public abstract Iterator getPropertyNames();

  public abstract Forum getForum();

  public abstract ForumMessage getMessage(long paramLong)
    throws ForumMessageNotFoundException;

  public abstract ForumMessage getRootMessage();

  public abstract ForumMessage getLatestMessage();

  public abstract int getMessageCount();

  public abstract int getMessageCount(ResultFilter paramResultFilter);

  public abstract void addMessage(ForumMessage paramForumMessage1, ForumMessage paramForumMessage2)
    throws MessageRejectedException, UnauthorizedException;

  public abstract void deleteMessage(ForumMessage paramForumMessage)
    throws UnauthorizedException;

  public abstract void deleteMessage(ForumMessage paramForumMessage, boolean paramBoolean)
    throws UnauthorizedException;

  public abstract TreeWalker getTreeWalker();

  public abstract Iterator getMessages();

  public abstract Iterator getMessages(ResultFilter paramResultFilter);

  public abstract boolean isAuthorized(long paramLong);
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.ForumThread
 * JD-Core Version:    0.6.2
 */
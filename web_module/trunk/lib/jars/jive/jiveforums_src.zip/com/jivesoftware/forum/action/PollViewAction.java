/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.Poll;
/*     */ import com.jivesoftware.base.PollManager;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.action.JiveObjectLoader;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ 
/*     */ public class PollViewAction extends ForumActionSupport
/*     */   implements JiveObjectLoader
/*     */ {
/*  28 */   private long pollID = 0L;
/*     */   private Poll poll;
/*     */ 
/*     */   public long getPollID()
/*     */   {
/*  36 */     return this.pollID;
/*     */   }
/*     */ 
/*     */   public void setPollID(long pollID)
/*     */   {
/*  43 */     this.pollID = pollID;
/*     */   }
/*     */ 
/*     */   public Poll getPoll()
/*     */   {
/*  50 */     return this.poll;
/*     */   }
/*     */ 
/*     */   public boolean isSystemPoll()
/*     */   {
/*  57 */     return this.poll.getObjectType() == -1;
/*     */   }
/*     */ 
/*     */   public boolean isCategoryPoll()
/*     */   {
/*  64 */     return this.poll.getObjectType() == 14;
/*     */   }
/*     */ 
/*     */   public boolean isForumPoll()
/*     */   {
/*  71 */     return this.poll.getObjectType() == 0;
/*     */   }
/*     */ 
/*     */   public boolean canCreatePoll()
/*     */   {
/*  79 */     switch (this.poll.getObjectType()) {
/*     */     case 14:
/*     */       try {
/*  82 */         ForumCategory category = getForumFactory().getForumCategory(this.poll.getObjectID());
/*  83 */         return getCanCreatePoll(category);
/*     */       }
/*     */       catch (Exception ignored) {
/*     */       }
/*     */     case 0:
/*     */       try {
/*  89 */         Forum forum = getForumFactory().getForum(this.poll.getObjectID());
/*  90 */         return getCanCreatePoll(forum);
/*     */       }
/*     */       catch (Exception ignored) {
/*     */       }
/*     */     default:
/*  95 */       return (isSystemAdmin()) || (getForumFactory().isAuthorized(16L));
/*     */     }
/*  97 */     return false;
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */     throws Exception
/*     */   {
/* 104 */     return "success";
/*     */   }
/*     */ 
/*     */   public String loadObjects()
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 115 */       PollManager manager = getForumFactory().getPollManager();
/* 116 */       this.poll = manager.getPoll(this.pollID);
/*     */     }
/*     */     catch (NotFoundException e) {
/* 119 */       addFieldError("pollID", String.valueOf(this.pollID));
/* 120 */       return "notfound";
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 123 */       return "unauthorized";
/*     */     }
/* 125 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PollViewAction
 * JD-Core Version:    0.6.2
 */
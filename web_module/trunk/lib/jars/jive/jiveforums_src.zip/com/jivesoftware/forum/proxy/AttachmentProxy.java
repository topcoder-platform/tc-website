/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class AttachmentProxy
/*     */   implements Attachment
/*     */ {
/*     */   private Attachment attachment;
/*     */   private ForumMessage message;
/*     */   private AuthToken authToken;
/*     */   protected Permissions permissions;
/*     */ 
/*     */   public AttachmentProxy(Attachment attachment, ForumMessageProxy message, AuthToken authToken, Permissions permissions)
/*     */   {
/*  32 */     this.attachment = attachment;
/*  33 */     this.message = message;
/*  34 */     this.authToken = authToken;
/*  35 */     if (permissions != null) {
/*  36 */       this.permissions = permissions;
/*     */     }
/*     */     else
/*  39 */       this.permissions = message.permissions;
/*     */   }
/*     */ 
/*     */   public long getID() {
/*  43 */     return this.attachment.getID();
/*     */   }
/*     */ 
/*     */   public String getContentType() {
/*  47 */     return this.attachment.getContentType();
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  51 */     return this.attachment.getName();
/*     */   }
/*     */ 
/*     */   public void setName(String name) throws UnauthorizedException {
/*  55 */     if (isAllowedToEdit()) {
/*  56 */       this.attachment.setName(name);
/*     */     }
/*     */     else
/*  59 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public long getSize()
/*     */   {
/*  64 */     return this.attachment.getSize();
/*     */   }
/*     */ 
/*     */   public InputStream getData() throws IOException {
/*  68 */     return this.attachment.getData();
/*     */   }
/*     */ 
/*     */   public Date getCreationDate() {
/*  72 */     return this.attachment.getCreationDate();
/*     */   }
/*     */ 
/*     */   public Date getModificationDate() {
/*  76 */     return this.attachment.getModificationDate();
/*     */   }
/*     */ 
/*     */   public String getProperty(String name) {
/*  80 */     return this.attachment.getProperty(name);
/*     */   }
/*     */ 
/*     */   public Collection getProperties(String parentName) {
/*  84 */     return this.attachment.getProperties(parentName);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value) throws UnauthorizedException {
/*  88 */     if (isAllowedToEdit()) {
/*  89 */       this.attachment.setProperty(name, value);
/*     */     }
/*     */     else
/*  92 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name) throws UnauthorizedException
/*     */   {
/*  97 */     if (isAllowedToEdit()) {
/*  98 */       this.attachment.deleteProperty(name);
/*     */     }
/*     */     else
/* 101 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames()
/*     */   {
/* 106 */     return this.attachment.getPropertyNames();
/*     */   }
/*     */ 
/*     */   private boolean isAllowedToEdit()
/*     */   {
/* 115 */     if (this.permissions.hasPermission(576460752303424128L))
/*     */     {
/* 118 */       return true;
/*     */     }
/*     */ 
/* 122 */     if ((this.message == null) || ((!this.message.isAnonymous()) && (this.message.getUser().getID() == this.authToken.getUserID()))) {
/* 123 */       return true;
/*     */     }
/*     */ 
/* 127 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.AttachmentProxy
 * JD-Core Version:    0.6.2
 */
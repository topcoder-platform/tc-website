/*     */ package com.jivesoftware.forum.proxy;
/*     */ 
/*     */ import com.jivesoftware.base.Permissions;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.Rating;
/*     */ import com.jivesoftware.forum.RatingManager;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class RatingManagerProxy
/*     */   implements RatingManager
/*     */ {
/*     */   private RatingManager ratingManager;
/*     */   private Permissions permissions;
/*     */ 
/*     */   public RatingManagerProxy(RatingManager ratingManager, Permissions permissions)
/*     */   {
/*  41 */     this.ratingManager = ratingManager;
/*  42 */     this.permissions = permissions;
/*     */   }
/*     */ 
/*     */   public boolean isRatingsEnabled() {
/*  46 */     return this.ratingManager.isRatingsEnabled();
/*     */   }
/*     */ 
/*     */   public void setRatingsEnabled(boolean ratingsEnabled) throws UnauthorizedException
/*     */   {
/*  51 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  52 */       this.ratingManager.setRatingsEnabled(ratingsEnabled);
/*     */     }
/*     */     else
/*  55 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getAvailableRatings()
/*     */   {
/*  60 */     return this.ratingManager.getAvailableRatings();
/*     */   }
/*     */ 
/*     */   public int getAvailableRatingCount() {
/*  64 */     return this.ratingManager.getAvailableRatingCount();
/*     */   }
/*     */ 
/*     */   public Rating getRatingFromScore(int score) {
/*  68 */     return this.ratingManager.getRatingFromScore(score);
/*     */   }
/*     */ 
/*     */   public Rating createRating(int score, String description) throws UnauthorizedException
/*     */   {
/*  73 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  74 */       return this.ratingManager.createRating(score, description);
/*     */     }
/*     */ 
/*  77 */     throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void removeRating(Rating rating)
/*     */     throws UnauthorizedException
/*     */   {
/*  83 */     if (this.permissions.hasPermission(576460752303423488L)) {
/*  84 */       this.ratingManager.removeRating(rating);
/*     */     }
/*     */     else
/*  87 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public Iterator getRatings(ForumMessage message)
/*     */   {
/*  92 */     return this.ratingManager.getRatings(message);
/*     */   }
/*     */ 
/*     */   public Iterator getRatings(ForumThread thread) {
/*  96 */     return this.ratingManager.getRatings(thread);
/*     */   }
/*     */ 
/*     */   public int getRatingCount(ForumMessage message) {
/* 100 */     return this.ratingManager.getRatingCount(message);
/*     */   }
/*     */ 
/*     */   public int getRatingCount(ForumThread thread) {
/* 104 */     return this.ratingManager.getRatingCount(thread);
/*     */   }
/*     */ 
/*     */   public double getMeanRating(long messageID) {
/* 108 */     return this.ratingManager.getMeanRating(messageID);
/*     */   }
/*     */ 
/*     */   public double getMeanRating(ForumMessage message) {
/* 112 */     return this.ratingManager.getMeanRating(message);
/*     */   }
/*     */ 
/*     */   public double getMeanRating(ForumThread thread) {
/* 116 */     return this.ratingManager.getMeanRating(thread);
/*     */   }
/*     */ 
/*     */   public boolean hasRated(User user, ForumMessage message) {
/* 120 */     return this.ratingManager.hasRated(user, message);
/*     */   }
/*     */ 
/*     */   public boolean hasRated(User user, ForumThread thread) {
/* 124 */     return this.ratingManager.hasRated(user, thread);
/*     */   }
/*     */ 
/*     */   public Rating getRating(User user, ForumMessage message) {
/* 128 */     return this.ratingManager.getRating(user, message);
/*     */   }
/*     */ 
/*     */   public Rating getRating(User user, ForumThread thread) {
/* 132 */     return this.ratingManager.getRating(user, thread);
/*     */   }
/*     */ 
/*     */   public void addRating(User user, ForumMessage message, Rating rating)
/*     */     throws UnauthorizedException
/*     */   {
/* 138 */     if (this.permissions.hasPermission(576460752303424064L))
/*     */     {
/* 141 */       this.ratingManager.addRating(user, message, rating);
/*     */     }
/*     */     else
/* 144 */       throw new UnauthorizedException();
/*     */   }
/*     */ 
/*     */   public void addRating(User user, ForumThread thread, Rating rating)
/*     */     throws UnauthorizedException
/*     */   {
/* 151 */     if (this.permissions.hasPermission(576460752303424064L))
/*     */     {
/* 154 */       this.ratingManager.addRating(user, thread, rating);
/*     */     }
/*     */     else
/* 157 */       throw new UnauthorizedException();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.RatingManagerProxy
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.JiveManager;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.forum.ArchiveManager;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import com.jivesoftware.util.TaskEngine;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Date;
/*     */ import java.util.TimerTask;
/*     */ 
/*     */ public class DbArchiveManager
/*     */   implements ArchiveManager, JiveManager, Runnable
/*     */ {
/*     */   private static final String ARCHIVE_FORUMS = "SELECT forumID FROM jiveForumProp WHERE name='jive.archiving.enabled' AND propValue='true'";
/*     */   private static final String ARCHIVED_THREADS = "SELECT jiveThread.threadID FROM jiveThread, jiveThreadProp WHERE forumID=? AND jiveThread.threadID=jiveThreadProp.threadID AND jiveThreadProp.name='jive.archived' AND jiveThreadProp.propValue='true'";
/*     */   private static final String ARCHIVABLE_THREADS = "SELECT threadID FROM jiveThread WHERE forumID=? AND modificationDate <= ? AND threadID NOT IN (SELECT jiveThread.threadID FROM jiveThread, jiveThreadProp WHERE forumID=? AND jiveThread.threadID=jiveThreadProp.threadID AND jiveThreadProp.name='jive.archived' AND jiveThreadProp.propValue='true')";
/*     */   private static final String ARCHIVABLE_THREADS_NO_SUBQUERIES = "SELECT threadID FROM jiveThread WHERE forumID=? AND modificationDate <= ?";
/*     */   private static DbForumFactory FACTORY;
/*  43 */   private static boolean initialized = false;
/*     */   private boolean busy;
/*  45 */   private Object busyLock = new Object();
/*     */ 
/*  50 */   private TimerTask timerTask = null;
/*     */ 
/*     */   public synchronized void initialize()
/*     */   {
/*  55 */     if (!initialized) {
/*  56 */       FACTORY = DbForumFactory.getInstance();
/*  57 */       this.timerTask = TaskEngine.scheduleTask(this, getAutoArchiveInterval() * 3600000L, getAutoArchiveInterval() * 3600000L);
/*     */ 
/*  59 */       initialized = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isArchivingEnabled(Forum forum) {
/*  64 */     if (forum == null) {
/*  65 */       throw new NullPointerException("Forum argument to method is null");
/*     */     }
/*  67 */     return Boolean.valueOf(forum.getProperty("jive.archiving.enabled")).booleanValue();
/*     */   }
/*     */ 
/*     */   public void setArchivingEnabled(Forum forum, boolean enabled) {
/*  71 */     if (forum == null)
/*  72 */       throw new NullPointerException("Forum argument to method is null");
/*     */     try
/*     */     {
/*  75 */       forum.setProperty("jive.archiving.enabled", Boolean.toString(enabled));
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/*  78 */       Log.error("Unable to make archiving setting changes.", ue);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getArchiveDays(Forum forum) {
/*  83 */     if (forum == null) {
/*  84 */       throw new NullPointerException("Forum argument to method is null");
/*     */     }
/*     */ 
/*  87 */     if (!isArchivingEnabled(forum)) {
/*  88 */       return -1;
/*     */     }
/*  90 */     String days = forum.getProperty("jive.archiving.archiveDays");
/*  91 */     if (days != null) {
/*  92 */       return Integer.parseInt(days);
/*     */     }
/*     */ 
/*  96 */     return 180;
/*     */   }
/*     */ 
/*     */   public void setArchiveDays(Forum forum, int days)
/*     */   {
/* 101 */     if (days < 1) {
/* 102 */       throw new IllegalArgumentException("Days must be greater than 0. Value specified: " + days + ".");
/*     */     }
/*     */ 
/* 105 */     if (forum == null)
/* 106 */       throw new NullPointerException("Forum argument to method is null");
/*     */     try
/*     */     {
/* 109 */       forum.setProperty("jive.archiving.archiveDays", String.valueOf(days));
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 112 */       Log.error("Unable to make archiving setting changes.", ue);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getArchiveMode(Forum forum) {
/* 117 */     if (forum == null) {
/* 118 */       throw new NullPointerException("Forum argument to method is null");
/*     */     }
/* 120 */     String mode = forum.getProperty("jive.archiving.archiveMode");
/*     */ 
/* 122 */     if (mode == null) {
/* 123 */       return 0;
/*     */     }
/*     */ 
/* 126 */     return Integer.parseInt(mode);
/*     */   }
/*     */ 
/*     */   public void setArchiveMode(Forum forum, int mode)
/*     */   {
/* 131 */     if (forum == null) {
/* 132 */       throw new NullPointerException("Forum argument to method is null");
/*     */     }
/* 134 */     if ((mode != 0) && (mode != 2) && (mode != 1))
/*     */     {
/* 138 */       throw new IllegalArgumentException("Mode not valid.");
/*     */     }
/*     */     try {
/* 141 */       forum.setProperty("jive.archiving.archiveMode", String.valueOf(mode));
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 144 */       Log.error("Unable to make archiving setting changes.", ue);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Forum getArchiveForum(Forum forum) {
/* 149 */     if (forum == null) {
/* 150 */       throw new NullPointerException("Forum argument to method is null");
/*     */     }
/* 152 */     String forumID = forum.getProperty("jive.archiving.archiveForum");
/* 153 */     if (forumID == null) {
/* 154 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 158 */       return FACTORY.getForum(Integer.parseInt(forumID));
/*     */     } catch (Exception e) {
/*     */     }
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */   public void setArchiveForum(Forum forum, Forum archiveForum)
/*     */   {
/* 167 */     if (forum == null) {
/* 168 */       throw new NullPointerException("Forum argument to method is null");
/*     */     }
/* 170 */     if (archiveForum == null)
/*     */       try {
/* 172 */         forum.deleteProperty("jive.archiving.archiveForum");
/*     */       }
/*     */       catch (UnauthorizedException ue) {
/* 175 */         Log.error("Unable to make archiving setting changes.", ue);
/*     */       }
/*     */     try
/*     */     {
/* 179 */       forum.setProperty("jive.archiving.archiveForum", String.valueOf(archiveForum.getID()));
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 182 */       Log.error("Unable to make archiving setting changes.", ue);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isAutoArchiveEnabled() {
/* 187 */     return JiveGlobals.getJiveBooleanProperty("archiving.autoArchiveEnabled");
/*     */   }
/*     */ 
/*     */   public void setAutoArchiveEnabled(boolean enabled)
/*     */   {
/* 192 */     if (enabled == isAutoArchiveEnabled()) {
/* 193 */       return;
/*     */     }
/* 195 */     JiveGlobals.setJiveProperty("archiving.autoArchiveEnabled", String.valueOf(enabled));
/*     */   }
/*     */ 
/*     */   public int getAutoArchiveInterval()
/*     */   {
/* 200 */     return JiveGlobals.getJiveIntProperty("archiving.autoArchiveInterval", 12);
/*     */   }
/*     */ 
/*     */   public void setAutoArchiveInterval(int interval) {
/* 204 */     if (interval < 1) {
/* 205 */       throw new IllegalArgumentException("Invalid interval value: " + interval);
/*     */     }
/* 207 */     JiveGlobals.setJiveProperty("archiving.autoArchiveInterval", Integer.toString(interval));
/*     */ 
/* 210 */     if (this.timerTask != null) {
/* 211 */       this.timerTask.cancel();
/*     */     }
/* 213 */     this.timerTask = TaskEngine.scheduleTask(this, getAutoArchiveInterval() * 3600000L, getAutoArchiveInterval() * 3600000L);
/*     */   }
/*     */ 
/*     */   public Date getLastArchivedDate()
/*     */   {
/* 218 */     String lastArchived = JiveGlobals.getJiveProperty("archiving.lastArchivedDate");
/* 219 */     if (lastArchived != null) {
/* 220 */       return new Date(Long.parseLong(lastArchived));
/*     */     }
/*     */ 
/* 223 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean isBusy() throws UnauthorizedException
/*     */   {
/* 228 */     return this.busy;
/*     */   }
/*     */ 
/*     */   public void runArchiver() throws UnauthorizedException {
/* 232 */     TaskEngine.addTask(new ArchiveTask());
/*     */   }
/*     */ 
/*     */   public synchronized void run()
/*     */   {
/* 237 */     if (!isAutoArchiveEnabled()) {
/* 238 */       return;
/*     */     }
/*     */ 
/* 241 */     TaskEngine.addTask(0, new ArchiveTask());
/*     */   }
/*     */ 
/*     */   private static final String archiveModeToString(int archiveMode)
/*     */   {
/* 406 */     if (archiveMode == 0) {
/* 407 */       return "MARK_THREADS";
/*     */     }
/* 409 */     if (archiveMode == 1) {
/* 410 */       return "DELETE_THREADS";
/*     */     }
/* 412 */     if (archiveMode == 2) {
/* 413 */       return "MOVE_THREADS";
/*     */     }
/*     */ 
/* 416 */     return "INVALID";
/*     */   }
/*     */ 
/*     */   public class ArchiveTask
/*     */     implements Runnable
/*     */   {
/*     */     public ArchiveTask()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 255 */       Log.debug("Starting archiving task.");
/*     */ 
/* 259 */       if (!CacheFactory.isSeniorClusterMember()) {
/* 260 */         Log.debug("Aborting archive task since not senior cluster member.");
/* 261 */         return;
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 266 */         synchronized (DbArchiveManager.this.busyLock) {
/* 267 */           if (DbArchiveManager.this.busy)
/*     */           {
/*     */             return;
/*     */           }
/* 271 */           DbArchiveManager.this.busy = true;
/*     */         }
/*     */ 
/* 275 */         long archivedDate = System.currentTimeMillis();
/* 276 */         JiveGlobals.setJiveProperty("archiving.lastArchivedDate", Long.toString(archivedDate));
/*     */ 
/* 279 */         LongList forums = new LongList();
/* 280 */         Connection con = null;
/* 281 */         PreparedStatement pstmt = null;
/*     */         try {
/* 283 */           con = ConnectionManager.getConnection();
/* 284 */           pstmt = con.prepareStatement("SELECT forumID FROM jiveForumProp WHERE name='jive.archiving.enabled' AND propValue='true'");
/* 285 */           ResultSet rs = pstmt.executeQuery();
/* 286 */           while (rs.next()) {
/* 287 */             forums.add(rs.getLong(1));
/*     */           }
/* 289 */           rs.close();
/*     */         }
/*     */         catch (SQLException sqle) {
/* 292 */           Log.error(sqle);
/*     */         }
/*     */         finally {
/* 295 */           ConnectionManager.closeConnection(pstmt, con);
/*     */         }
/*     */ 
/* 298 */         Log.debug("Found " + forums.size() + " forums to process through the archiver.");
/*     */ 
/* 300 */         DbForumFactory factory = DbForumFactory.getInstance();
/* 301 */         int i = 0; for (int n = forums.size(); i < n; i++) {
/* 302 */           Forum forum = null;
/*     */           try {
/* 304 */             forum = factory.getForum(forums.get(i));
/*     */           }
/*     */           catch (ForumNotFoundException fnfe) {
/* 307 */             continue;
/*     */           }
/* 309 */           if (DbArchiveManager.this.isArchivingEnabled(forum))
/*     */           {
/* 316 */             int archiveMode = DbArchiveManager.this.getArchiveMode(forum);
/*     */ 
/* 318 */             Log.debug("Archiving forum + " + forum + " using mode: " + DbArchiveManager.archiveModeToString(archiveMode));
/*     */ 
/* 322 */             int archiveDays = DbArchiveManager.this.getArchiveDays(forum);
/* 323 */             Date archiveDate = new Date(archivedDate - archiveDays * 86400000L);
/*     */ 
/* 325 */             con = null;
/* 326 */             pstmt = null;
/*     */             try {
/* 328 */               con = ConnectionManager.getConnection();
/*     */ 
/* 332 */               if ((archiveMode == 0) && (ConnectionManager.isSubqueriesSupported()))
/*     */               {
/* 335 */                 pstmt = con.prepareStatement("SELECT threadID FROM jiveThread WHERE forumID=? AND modificationDate <= ? AND threadID NOT IN (SELECT jiveThread.threadID FROM jiveThread, jiveThreadProp WHERE forumID=? AND jiveThread.threadID=jiveThreadProp.threadID AND jiveThreadProp.name='jive.archived' AND jiveThreadProp.propValue='true')");
/* 336 */                 pstmt.setLong(1, forum.getID());
/* 337 */                 pstmt.setLong(2, archiveDate.getTime());
/* 338 */                 pstmt.setLong(3, forum.getID());
/* 339 */                 ResultSet rs = pstmt.executeQuery();
/* 340 */                 while (rs.next())
/*     */                   try {
/* 342 */                     ForumThread thread = forum.getThread(rs.getLong(1));
/* 343 */                     if (!"true".equals(thread.getProperty("jive.archivingDisabled")))
/*     */                     {
/* 345 */                       thread.setProperty("jive.archived", "true");
/*     */                     }
/*     */                   } catch (ForumThreadNotFoundException e) {
/*     */                   }
/*     */                   catch (UnauthorizedException e) {
/*     */                   }
/* 351 */                 rs.close();
/*     */               }
/*     */               else
/*     */               {
/* 355 */                 pstmt = con.prepareStatement("SELECT threadID FROM jiveThread WHERE forumID=? AND modificationDate <= ?");
/* 356 */                 pstmt.setLong(1, forum.getID());
/* 357 */                 pstmt.setLong(2, archiveDate.getTime());
/* 358 */                 ResultSet rs = pstmt.executeQuery();
/* 359 */                 while (rs.next())
/*     */                   try {
/* 361 */                     ForumThread thread = forum.getThread(rs.getLong(1));
/*     */ 
/* 363 */                     if (!"true".equals(thread.getProperty("jive.archivingDisabled")))
/*     */                     {
/* 367 */                       if (archiveMode == 0) {
/* 368 */                         thread.setProperty("jive.archived", "true");
/*     */                       }
/* 370 */                       else if (archiveMode == 1) {
/* 371 */                         forum.deleteThread(thread);
/*     */                       }
/*     */                       else {
/* 374 */                         Forum archiveForum = DbArchiveManager.this.getArchiveForum(forum);
/*     */ 
/* 376 */                         if (archiveForum != null)
/* 377 */                           forum.moveThread(thread, archiveForum);
/*     */                       }
/*     */                     }
/*     */                   } catch (ForumThreadNotFoundException e) {
/*     */                   }
/*     */                   catch (UnauthorizedException e) {
/*     */                   }
/* 384 */                 rs.close();
/*     */               }
/*     */             }
/*     */             catch (SQLException sqle) {
/* 388 */               Log.error(sqle);
/*     */             }
/*     */             finally {
/* 391 */               ConnectionManager.closeConnection(pstmt, con);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       finally {
/* 397 */         synchronized (DbArchiveManager.this.busyLock) {
/* 398 */           DbArchiveManager.this.busy = false;
/*     */         }
/*     */       }
/* 401 */       Log.debug("Finished archiving task.");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbArchiveManager
 * JD-Core Version:    0.6.2
 */
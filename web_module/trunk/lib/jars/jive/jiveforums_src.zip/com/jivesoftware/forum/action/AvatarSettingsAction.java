/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.AuthToken;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.UserManager;
/*     */ import com.jivesoftware.base.UserNotFoundException;
/*     */ import com.jivesoftware.forum.Avatar;
/*     */ import com.jivesoftware.forum.AvatarManager;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.opensymphony.xwork.Preparable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class AvatarSettingsAction extends ForumActionSupport
/*     */   implements Preparable
/*     */ {
/*     */   private Avatar activeAvatar;
/*     */   private List userAvatars;
/*     */   private List globalAvatars;
/*  31 */   private boolean isCancel = false;
/*     */   private int maxUserAvatars;
/*     */   private boolean modUserAvatars;
/*     */   private User user;
/*     */ 
/*     */   public Avatar getActiveAvatar()
/*     */   {
/*  38 */     return this.activeAvatar;
/*     */   }
/*     */ 
/*     */   public void setCancel(String cancel) {
/*  42 */     this.isCancel = true;
/*     */   }
/*     */ 
/*     */   public List getUserAvatars() {
/*  46 */     return this.userAvatars;
/*     */   }
/*     */ 
/*     */   public List getGlobalAvatars() {
/*  50 */     return this.globalAvatars;
/*     */   }
/*     */ 
/*     */   public int getMaxUserAvatars() {
/*  54 */     return this.maxUserAvatars;
/*     */   }
/*     */ 
/*     */   public boolean isModUserAvatars() {
/*  58 */     return this.modUserAvatars;
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/*  63 */     if (this.isCancel) {
/*  64 */       return "cancel";
/*     */     }
/*     */ 
/*  67 */     AvatarManager avatarManager = getForumFactory().getAvatarManager();
/*     */ 
/*  69 */     this.maxUserAvatars = avatarManager.getMaxUserAvatars();
/*  70 */     this.modUserAvatars = avatarManager.isModerateUserAvatars();
/*     */ 
/*  72 */     this.userAvatars = iterator2Collection(avatarManager.getAvatars(this.user));
/*  73 */     this.globalAvatars = iterator2Collection(avatarManager.getGlobalAvatars());
/*  74 */     this.activeAvatar = avatarManager.getActiveAvatar(this.user);
/*     */ 
/*  77 */     return "success";
/*     */   }
/*     */ 
/*     */   public void prepare() throws Exception
/*     */   {
/*  82 */     AuthToken authToken = getAuthToken();
/*  83 */     if (authToken.isAnonymous()) {
/*  84 */       throw new UserNotFoundException();
/*     */     }
/*     */ 
/*  87 */     long userID = authToken.getUserID();
/*     */ 
/*  90 */     if (userID != -1L) {
/*  91 */       this.user = getForumFactory().getUserManager().getUser(userID);
/*     */     }
/*     */ 
/*  95 */     if (this.user == null)
/*  96 */       throw new UserNotFoundException();
/*     */   }
/*     */ 
/*     */   private List iterator2Collection(Iterator iterator)
/*     */   {
/* 103 */     ArrayList list = new ArrayList();
/*     */ 
/* 105 */     while (iterator.hasNext()) {
/* 106 */       list.add(iterator.next());
/*     */     }
/*     */ 
/* 109 */     return list;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AvatarSettingsAction
 * JD-Core Version:    0.6.2
 */
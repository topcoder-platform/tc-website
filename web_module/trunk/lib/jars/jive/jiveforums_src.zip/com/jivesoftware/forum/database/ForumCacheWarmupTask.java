/*    */ package com.jivesoftware.forum.database;
/*    */ 
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import com.jivesoftware.forum.ForumMessage;
/*    */ import com.jivesoftware.forum.ForumThread;
/*    */ import com.jivesoftware.forum.ResultFilter;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class ForumCacheWarmupTask
/*    */   implements Runnable
/*    */ {
/* 25 */   private static ResultFilter filter = ResultFilter.createDefaultThreadFilter();
/*    */   private Forum forum;
/*    */ 
/*    */   public ForumCacheWarmupTask(Forum forum)
/*    */   {
/* 39 */     this.forum = forum;
/*    */   }
/*    */ 
/*    */   public void run() {
/* 43 */     this.forum.getMessageCount();
/*    */ 
/* 45 */     int maxTCount = this.forum.getThreadCount();
/* 46 */     if (maxTCount != 0) {
/* 47 */       maxTCount /= 3;
/* 48 */       maxTCount = Math.min(maxTCount, 1000);
/*    */     }
/* 50 */     int tCount = 0;
/* 51 */     for (Iterator i = this.forum.getThreads(); (i.hasNext()) && (tCount < maxTCount); tCount++) {
/* 52 */       ForumThread thread = (ForumThread)i.next();
/*    */ 
/* 54 */       int maxMCount = thread.getMessageCount();
/* 55 */       if (maxMCount != 0) {
/* 56 */         maxMCount /= 2;
/* 57 */         maxMCount = Math.min(maxMCount, 100);
/*    */       }
/* 59 */       int mCount = 0;
/* 60 */       for (Iterator j = thread.getMessages(); (j.hasNext()) && (mCount < maxMCount); mCount++) {
/* 61 */         ForumMessage message = (ForumMessage)j.next();
/*    */ 
/* 63 */         message.getUser();
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 26 */     filter.setNumResults(400);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.ForumCacheWarmupTask
 * JD-Core Version:    0.6.2
 */
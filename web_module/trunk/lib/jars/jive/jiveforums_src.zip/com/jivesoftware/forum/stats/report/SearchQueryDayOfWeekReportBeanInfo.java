/*    */ package com.jivesoftware.forum.stats.report;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class SearchQueryDayOfWeekReportBeanInfo extends JiveBeanInfo
/*    */ {
/*    */   public String[] getPropertyNames()
/*    */   {
/* 17 */     return new String[0];
/*    */   }
/*    */   public Class getBeanClass() {
/* 20 */     return SearchQueryDayOfWeekReport.class;
/*    */   }
/*    */   public String getName() {
/* 23 */     return "SearchQueryDayOfWeekReport";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.SearchQueryDayOfWeekReportBeanInfo
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public abstract class ForumThreadIterator
/*     */   implements Iterator
/*     */ {
/*  28 */   public static final ForumThreadIterator EMPTY_ITERATOR = new ForumThreadIterator() {
/*     */     public boolean hasNext() {
/*  30 */       return false;
/*     */     }
/*     */ 
/*     */     public Object next() {
/*  34 */       throw new NoSuchElementException();
/*     */     }
/*     */ 
/*     */     public boolean hasPrevious() {
/*  38 */       return false;
/*     */     }
/*     */ 
/*     */     public Object previous() {
/*  42 */       throw new NoSuchElementException();
/*     */     }
/*     */ 
/*     */     public void setIndex(ForumThread thread) {
/*  46 */       throw new NoSuchElementException();
/*     */     }
/*  28 */   };
/*     */ 
/*     */   public abstract boolean hasNext();
/*     */ 
/*     */   public abstract Object next();
/*     */ 
/*     */   public abstract boolean hasPrevious();
/*     */ 
/*     */   public abstract Object previous();
/*     */ 
/*     */   public abstract void setIndex(ForumThread paramForumThread);
/*     */ 
/*     */   public void remove()
/*     */   {
/* 120 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.ForumThreadIterator
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.forum.Attachment;
/*     */ import com.jivesoftware.forum.AttachmentException;
/*     */ import com.jivesoftware.forum.AttachmentManager;
/*     */ import com.jivesoftware.forum.AttachmentNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.database.DatabaseCacheManager;
/*     */ import com.jivesoftware.forum.database.DbAttachment;
/*     */ import com.jivesoftware.forum.database.DbForumFactory;
/*     */ import com.jivesoftware.forum.proxy.AttachmentProxy;
/*     */ import com.jivesoftware.forum.proxy.ForumMessageProxy;
/*     */ import com.opensymphony.webwork.ServletActionContext;
/*     */ import com.opensymphony.webwork.dispatcher.multipart.MultiPartRequestWrapper;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.activation.MimetypesFileTypeMap;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class AttachAction extends PostAction
/*     */ {
/*     */   public static final String SUCCESS_TOPIC = "success-topic";
/*     */   public static final String SUCCESS_MESSAGE = "success-message";
/*     */   public static final String ATTACHMENT_RENAME_INPUT = "attachmentrename";
/*     */   public static final String ATTACHMENT_RENAME_SUCCESS = "attachmentrenamesuccess";
/*  40 */   private static MimetypesFileTypeMap typeMap = new MimetypesFileTypeMap();
/*     */   private File[] attachFile;
/*     */   private int[] deleteAttachIDs;
/*  45 */   private long attachID = -1L;
/*     */   private String doAttachFiles;
/*     */   private String encSubject;
/*     */   private String encBody;
/*     */   private String newName;
/*     */   private Boolean ansQuestion;
/*     */ 
/*     */   public String getDoAttachFiles()
/*     */   {
/*  61 */     return this.doAttachFiles;
/*     */   }
/*     */ 
/*     */   public void setDoAttachFiles(String doAttachFiles) {
/*  65 */     if ((doAttachFiles != null) && (!"".equals(doAttachFiles.trim())))
/*  66 */       this.doAttachFiles = "true";
/*     */   }
/*     */ 
/*     */   public File[] getAttachFile()
/*     */   {
/*  71 */     return this.attachFile;
/*     */   }
/*     */ 
/*     */   public void setAttachFile(File[] attachFile) {
/*  75 */     this.attachFile = attachFile;
/*     */   }
/*     */ 
/*     */   public int[] getDeleteAttachIDs() {
/*  79 */     return this.deleteAttachIDs;
/*     */   }
/*     */ 
/*     */   public void setDeleteAttachIDs(int[] deleteAttachIDs) {
/*  83 */     this.deleteAttachIDs = deleteAttachIDs;
/*     */   }
/*     */ 
/*     */   public long getAttachID() {
/*  87 */     return this.attachID;
/*     */   }
/*     */ 
/*     */   public void setAttachID(long attachID) {
/*  91 */     this.attachID = attachID;
/*     */   }
/*     */ 
/*     */   public String getEncSubject() {
/*  95 */     return this.encSubject;
/*     */   }
/*     */ 
/*     */   public void setEncSubject(String encSubject) {
/*  99 */     if ((encSubject != null) && (!"".equals(encSubject)))
/* 100 */       this.encSubject = encSubject;
/*     */   }
/*     */ 
/*     */   public String getEncBody()
/*     */   {
/* 105 */     return this.encBody;
/*     */   }
/*     */ 
/*     */   public void setEncBody(String encBody) {
/* 109 */     if ((encBody != null) && (!"".equals(encBody)))
/* 110 */       this.encBody = encBody;
/*     */   }
/*     */ 
/*     */   public String getNewName()
/*     */   {
/* 115 */     return this.newName;
/*     */   }
/*     */ 
/*     */   public void setNewName(String newName) {
/* 119 */     this.newName = newName;
/*     */   }
/*     */ 
/*     */   public Boolean getAnsQuestion() {
/* 123 */     return this.ansQuestion;
/*     */   }
/*     */ 
/*     */   public void setAnsQuestion(Boolean ansQuestion) {
/* 127 */     this.ansQuestion = ansQuestion;
/*     */   }
/*     */ 
/*     */   public AttachmentManager getAttachmentManager()
/*     */   {
/* 133 */     return getForumFactory().getAttachmentManager();
/*     */   }
/*     */ 
/*     */   public boolean isEdit() {
/* 137 */     return false;
/*     */   }
/*     */ 
/*     */   public Attachment getAttachment() {
/* 141 */     ForumFactory forumFactory = ForumFactory.getInstance(getAuthToken());
/*     */     try
/*     */     {
/* 144 */       DbAttachment dbattachment = DbForumFactory.getInstance().cacheManager.getAttachment(this.attachID);
/* 145 */       ForumMessageProxy message = (ForumMessageProxy)forumFactory.getMessage(dbattachment.getObjectID());
/*     */ 
/* 147 */       return new AttachmentProxy(dbattachment, message, getAuthToken(), null);
/*     */     }
/*     */     catch (AttachmentNotFoundException e)
/*     */     {
/* 151 */       Log.error(e);
/*     */     }
/*     */     catch (ForumMessageNotFoundException e) {
/* 154 */       Log.error(e);
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 157 */       Log.error(e);
/*     */     }
/*     */ 
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/*     */     try
/*     */     {
/* 167 */       if (!loadJiveObjects())
/* 168 */         return "error";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 172 */       setLoginAttributes();
/* 173 */       addActionError(getText("attach.error_unauth"));
/* 174 */       return "login";
/*     */     }
/*     */ 
/* 177 */     if (!getCanAttach(getForum())) {
/* 178 */       setLoginAttributes();
/* 179 */       addActionError(getText("attach.error_unauth"));
/* 180 */       return "login";
/*     */     }
/*     */ 
/* 186 */     if ((isEdit()) && (getMessage() != null) && 
/* 187 */       (!getCanEdit(getMessage()))) {
/* 188 */       addActionError(getText("edit.not_allowed"));
/* 189 */       return "error";
/*     */     }
/*     */ 
/* 194 */     return "input";
/*     */   }
/*     */ 
/*     */   public String doDelete() {
/*     */     try {
/* 199 */       if (!loadJiveObjects())
/* 200 */         return "error";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 204 */       setLoginAttributes();
/* 205 */       addActionError(getText("attach.error_unauth"));
/* 206 */       return "login";
/*     */     }
/*     */ 
/* 210 */     if ((isEdit()) && (!getCanEdit(getMessage()))) {
/* 211 */       addActionError(getText("edit.not_allowed"));
/* 212 */       return "error";
/*     */     }
/*     */ 
/* 215 */     if (this.attachID == -1L) {
/* 216 */       addActionError(getText("attach.error_unable_delete"));
/* 217 */       return "error";
/*     */     }
/* 219 */     ForumMessage msg = getMessage();
/* 220 */     Attachment attachment = null;
/* 221 */     for (Iterator attachments = msg.getAttachments(); attachments.hasNext(); ) {
/* 222 */       attachment = (Attachment)attachments.next();
/* 223 */       long attachID = attachment.getID();
/* 224 */       if (this.attachID == attachID)
/*     */         break;
/*     */     }
/*     */     try
/*     */     {
/* 229 */       msg.deleteAttachment(attachment);
/*     */     }
/*     */     catch (AttachmentException ae) {
/* 232 */       addActionError(ae.getMessage());
/* 233 */       return "error";
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 236 */       addActionError(ue.getMessage());
/* 237 */       return "error";
/*     */     }
/*     */ 
/* 240 */     ServletActionContext.getRequest().setAttribute("partialURL", getPartialURL());
/* 241 */     return "success-delete";
/*     */   }
/*     */ 
/*     */   public String doRename()
/*     */   {
/*     */     try
/*     */     {
/* 255 */       if (!loadJiveObjects())
/* 256 */         return "error";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 260 */       setLoginAttributes();
/* 261 */       addActionError(getText("attach.error_unauth"));
/* 262 */       return "login";
/*     */     }
/*     */ 
/* 267 */     if ((isEdit()) && (!getCanEdit(getMessage()))) {
/* 268 */       addActionError(getText("edit.not_allowed"));
/* 269 */       return "error";
/*     */     }
/*     */ 
/* 273 */     if (this.newName == null) {
/* 274 */       return "attachmentrename";
/*     */     }
/*     */     try
/*     */     {
/* 278 */       DbForumFactory forumFactory = DbForumFactory.getInstance();
/* 279 */       DbAttachment attachment = forumFactory.cacheManager.getAttachment(this.attachID);
/* 280 */       attachment.setName(this.newName);
/*     */     }
/*     */     catch (AttachmentNotFoundException e) {
/* 283 */       Log.error("Error renaming attachment with id: " + this.attachID);
/* 284 */       Log.error(e);
/* 285 */       addActionError(getText("attach.error_rename_generic"));
/* 286 */       return "error";
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 289 */       addActionError(getText("error.permission"));
/* 290 */       return "error";
/*     */     }
/*     */ 
/* 293 */     return "attachmentrenamesuccess";
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 298 */     if (!isMultiPart(ServletActionContext.getRequest())) {
/* 299 */       return "error-notmultipart";
/*     */     }
/*     */     try
/*     */     {
/* 303 */       if (!loadJiveObjects())
/* 304 */         return "error";
/*     */     }
/*     */     catch (UnauthorizedException e)
/*     */     {
/* 308 */       setLoginAttributes();
/* 309 */       addActionError(getText("attach.error_unauth"));
/* 310 */       return "login";
/*     */     }
/*     */ 
/* 314 */     if ("true".equals(getDoCancel())) {
/* 315 */       ServletActionContext.getRequest().setAttribute("tid", getTid());
/* 316 */       if (isReply()) {
/* 317 */         return "cancel-reply";
/*     */       }
/* 319 */       return "cancel-topic";
/*     */     }
/*     */ 
/* 322 */     if (!getCanAttach(getForum())) {
/* 323 */       setLoginAttributes();
/* 324 */       addActionError(getText("attach.error_unauth"));
/* 325 */       return "login";
/*     */     }
/*     */ 
/* 333 */     if ((isEdit()) && (getMessage() != null) && 
/* 334 */       (!getCanEdit(getMessage()))) {
/* 335 */       addActionError(getText("edit.not_allowed"));
/* 336 */       return "error";
/*     */     }
/*     */ 
/* 341 */     if ((this.attachFile == null) || (this.attachFile.length == 0)) {
/* 342 */       if (!"true".equals(ServletActionContext.getRequest().getAttribute("jiveForumUploadSizeLimitExceeded"))) {
/* 343 */         addActionError(getText("attach.error_at_least_one"));
/*     */       }
/*     */       else {
/* 346 */         addActionError(getText("attachresult.error_too_large"));
/*     */       }
/* 348 */       ServletActionContext.getRequest().setAttribute("tid", getTid());
/* 349 */       return "input";
/*     */     }
/*     */     try
/*     */     {
/* 353 */       if (isEdit()) {
/* 354 */         addAttachments(getMessage());
/*     */       }
/*     */       else {
/* 357 */         addAttachments(retrieveFromSession());
/*     */       }
/*     */ 
/* 361 */       if (hasErrors()) {
/* 362 */         return "error";
/*     */       }
/*     */ 
/* 365 */       if (!isEdit()) {
/* 366 */         ServletActionContext.getRequest().setAttribute("tid", getTid());
/* 367 */         if (isReply()) {
/* 368 */           return "success-reply";
/*     */         }
/* 370 */         return "success-topic";
/*     */       }
/*     */ 
/* 373 */       return "success-edit";
/*     */     }
/*     */     catch (UnauthorizedException ue) {
/* 376 */       ue.printStackTrace();
/* 377 */       addActionError(getText("attach.error_unauth"));
/* 378 */     }return "error";
/*     */   }
/*     */ 
/*     */   protected void addAttachments(ForumMessage message)
/*     */     throws UnauthorizedException
/*     */   {
/* 385 */     if (message == null) {
/* 386 */       addActionError(getText("attach.error_session_expired"));
/* 387 */       return;
/*     */     }
/*     */ 
/* 390 */     if (this.attachFile != null) {
/* 391 */       Log.debug("attachFile size was " + this.attachFile.length);
/*     */ 
/* 393 */       for (int i = 0; i < this.attachFile.length; i++) {
/* 394 */         Log.debug("Looking at file " + i);
/* 395 */         File file = this.attachFile[i];
/* 396 */         if (file == null) {
/* 397 */           Log.debug("File was null, skipping");
/*     */         }
/*     */         else
/*     */         {
/* 401 */           MultiPartRequestWrapper multiWrapper = (MultiPartRequestWrapper)ServletActionContext.getRequest();
/* 402 */           String fileName = multiWrapper.getFileNames("attachFile")[i];
/* 403 */           if (fileName == null) {
/* 404 */             fileName = "";
/*     */           }
/*     */ 
/* 408 */           String contentType = typeMap.getContentType(fileName.toLowerCase());
/* 409 */           Log.debug("Found content type of: " + contentType + " for filename: " + fileName);
/*     */ 
/* 411 */           if (contentType == null) {
/* 412 */             contentType = "application/octet-stream";
/*     */           }
/* 414 */           BufferedInputStream bis = null;
/* 415 */           FileInputStream fis = null;
/*     */           try
/*     */           {
/* 418 */             fis = new FileInputStream(file);
/* 419 */             bis = new BufferedInputStream(fis);
/* 420 */             message.createAttachment(fileName, contentType, bis);
/*     */           }
/*     */           catch (AttachmentException e) {
/* 423 */             if (e.getErrorType() == 0) {
/* 424 */               List args = new ArrayList();
/* 425 */               args.add(fileName);
/* 426 */               addFieldError("attachFile" + i, getText("attach.error_too_large_field", args));
/*     */             }
/* 428 */             else if (e.getErrorType() == 2) {
/* 429 */               List args = new ArrayList();
/* 430 */               args.add(fileName);
/* 431 */               addFieldError("attachFile" + i, getText("attach.error_content_type", args));
/*     */             }
/* 433 */             else if (e.getErrorType() == 1) {
/* 434 */               addFieldError("attachFile" + i, getText("attach.error_too_many"));
/*     */             }
/*     */             else {
/* 437 */               addFieldError("attachFile" + i, getText("attach.error_no_read_perm"));
/*     */             }
/*     */           }
/*     */           catch (UnauthorizedException e) {
/* 441 */             addFieldError("attachFile" + i, e.getMessage());
/*     */           }
/*     */           catch (IOException e) {
/* 444 */             Log.error(e);
/* 445 */             addFieldError("attachFile" + i, e.getMessage());
/*     */           }
/*     */           finally {
/* 448 */             if (bis != null) try {
/* 449 */                 bis.close(); } catch (IOException e) {
/* 450 */                 Log.error(e);
/*     */               }
/* 452 */             if (fis != null) try {
/* 453 */                 fis.close(); } catch (IOException e) {
/* 454 */                 Log.error(e);
/*     */               }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 461 */     loadToSession(message);
/*     */   }
/*     */ 
/*     */   public static boolean isMultiPart(HttpServletRequest request)
/*     */   {
/* 474 */     String contentType = getContentType(request);
/* 475 */     if ((contentType != null) && (contentType.startsWith("multipart/form-data"))) {
/* 476 */       return true;
/*     */     }
/* 478 */     return false;
/*     */   }
/*     */ 
/*     */   public static String getContentType(HttpServletRequest request)
/*     */   {
/* 490 */     String contentType = request.getContentType();
/* 491 */     if (contentType == null) {
/* 492 */       contentType = request.getHeader("Content-Type");
/*     */     }
/* 494 */     return contentType;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.AttachAction
 * JD-Core Version:    0.6.2
 */
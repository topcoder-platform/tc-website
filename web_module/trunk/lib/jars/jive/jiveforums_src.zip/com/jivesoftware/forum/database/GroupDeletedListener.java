/*    */ package com.jivesoftware.forum.database;
/*    */ 
/*    */ import com.jivesoftware.base.Group;
/*    */ import com.jivesoftware.base.Log;
/*    */ import com.jivesoftware.base.database.ConnectionManager;
/*    */ import com.jivesoftware.base.event.GroupEvent;
/*    */ import com.jivesoftware.base.event.GroupListenerAdapter;
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ 
/*    */ public class GroupDeletedListener extends GroupListenerAdapter
/*    */ {
/*    */   private static final String DELETE_GROUP_PERMS = "DELETE FROM jiveGroupPerm WHERE groupID=?";
/*    */ 
/*    */   public void groupDeleted(GroupEvent event)
/*    */   {
/* 33 */     long groupID = event.getGroup().getID();
/*    */ 
/* 35 */     Connection con = null;
/* 36 */     PreparedStatement pstmt = null;
/* 37 */     boolean abortTransaction = true;
/*    */     try
/*    */     {
/* 40 */       con = ConnectionManager.getTransactionConnection();
/*    */ 
/* 42 */       pstmt = con.prepareStatement("DELETE FROM jiveGroupPerm WHERE groupID=?");
/* 43 */       pstmt.setLong(1, groupID);
/* 44 */       pstmt.execute();
/*    */     }
/*    */     catch (Exception e) {
/* 47 */       Log.error(e);
/* 48 */       abortTransaction = true;
/* 49 */       event.setFailureException(e);
/*    */     }
/*    */     finally {
/* 52 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.GroupDeletedListener
 * JD-Core Version:    0.6.2
 */
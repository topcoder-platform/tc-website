/*    */ package com.jivesoftware.forum.nntp;
/*    */ 
/*    */ public class HelpResponse
/*    */ {
/* 28 */   public static final NNTPResponse RESPONSE = new StaticNNTPResponse(100, getHelpText());
/*    */ 
/*    */   private static final String getHelpText()
/*    */   {
/* 37 */     String CRLF = "\r\n";
/* 38 */     StringBuffer b = new StringBuffer("help text follows").append(CRLF);
/* 39 */     b.append("  authinfo user Name|pass Password").append(CRLF);
/* 40 */     b.append("  article [MessageID|Number]").append(CRLF);
/* 41 */     b.append("  body [MessageID|Number]").append(CRLF);
/* 42 */     b.append("  date").append(CRLF);
/* 43 */     b.append("  group newsgroup").append(CRLF);
/* 44 */     b.append("  head [MessageID|Number]").append(CRLF);
/* 45 */     b.append("  help").append(CRLF);
/* 46 */     b.append("  ihave").append(CRLF);
/* 47 */     b.append("  last").append(CRLF);
/* 48 */     b.append("  list [newsgroups|overview.fmt]").append(CRLF);
/* 49 */     b.append("  listgroup newsgroup").append(CRLF);
/* 50 */     b.append("  mode reader").append(CRLF);
/* 51 */     b.append("  newgroups yymmdd hhmmss [\"GMT\"] [<distributions>]").append(CRLF);
/* 52 */     b.append("  newnews newsgroups yymmdd hhmmss [\"GMT\"] ");
/* 53 */     b.append("[<distributions>]").append(CRLF);
/* 54 */     b.append("  next").append(CRLF);
/* 55 */     b.append("  post").append(CRLF);
/* 56 */     b.append("  slave").append(CRLF);
/* 57 */     b.append("  stat [MessageID|Number]").append(CRLF);
/* 58 */     b.append("  xhdr header [range|MessageID]").append(CRLF);
/* 59 */     b.append("  xover [range]").append(CRLF);
/*    */ 
/* 62 */     b.append("Report problems to http://www.jivesoftware.com/").append(CRLF);
/* 63 */     b.append(".").append(CRLF);
/* 64 */     return b.toString();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.HelpResponse
 * JD-Core Version:    0.6.2
 */
/*    */ package com.jivesoftware.forum.gateway;
/*    */ 
/*    */ import com.jivesoftware.forum.Forum;
/*    */ import com.jivesoftware.forum.ForumFactory;
/*    */ 
/*    */ public class MboxGateway extends Gateway
/*    */ {
/*    */   public MboxGateway(ForumFactory factory, Forum forum)
/*    */   {
/* 20 */     super(new MboxImporter(factory, forum), null);
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.gateway.MboxGateway
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.JiveGlobals;
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.RewardException;
/*     */ import com.jivesoftware.forum.RewardManager;
/*     */ import com.jivesoftware.forum.event.ForumEvent;
/*     */ import com.jivesoftware.forum.event.ForumEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ForumListener;
/*     */ import com.jivesoftware.forum.event.MessageEvent;
/*     */ import com.jivesoftware.forum.event.MessageEventDispatcher;
/*     */ import com.jivesoftware.forum.event.MessageListener;
/*     */ import com.jivesoftware.forum.event.ThreadEvent;
/*     */ import com.jivesoftware.forum.event.ThreadEventDispatcher;
/*     */ import com.jivesoftware.forum.event.ThreadListener;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheFactory;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class DbRewardManager
/*     */   implements RewardManager, ForumListener, ThreadListener, MessageListener
/*     */ {
/*     */   private static final String CREATE_REWARD_ENTRY = "INSERT INTO jiveReward(userID, creationDate, rewardPoints, messageID, threadID) VALUES (?, ?, ?, ?, ?)";
/*     */   private static final String DELETE_MESSAGE_ENTRY = "UPDATE jiveReward SET messageID=NULL, threadID=NULL WHERE messageID=?";
/*     */   private static final String DELETE_THREAD_ENTRIES = "UPDATE jiveReward SET messageID=NULL, threadID=NULL WHERE threadID=?";
/*     */   private static final String DELETE_FORUM_ENTRIES = "UPDATE jiveReward SET messageID=NULL, threadID=NULL WHERE threadID IN (SELECT jiveReward.threadID FROM jiveReward, jiveThread WHERE jiveReward.threadID=jiveThread.threadID AND jiveThread.forumID=?)";
/*     */   private static final String SELECT_FORUM_ENTRIES = "SELECT jiveReward.threadID FROM jiveReward, jiveThread WHERE jiveReward.threadID=jiveThread.threadID AND jiveThread.forumID=?";
/*     */   private static final String DELETE_FORUM_ENTRIES_BATCH = "UPDATE jiveReward SET messageID=NULL, threadID=NULL WHERE threadID IN";
/*     */   private static final String TOTAL_POINTS_EARNED = "SELECT sum(rewardPoints) FROM jiveReward WHERE userID=?";
/*     */   private static final String TOTAL_FORUM_POINTS_EARNED = "SELECT sum(jiveReward.rewardPoints) FROM jiveReward, jiveThread WHERE jiveReward.userID=? AND jiveReward.threadID=jiveThread.threadID AND forumID=?";
/*     */   private static final String TOTAL_CATEGORY_POINTS_EARNED = "SELECT sum(jiveReward.rewardPoints) FROM jiveReward, jiveThread, jiveForum, jiveCategory WHERE jiveReward.userID=? AND jiveReward.threadID=jiveThread.threadID AND jiveForum.forumID=jiveThread.forumID AND jiveCategory.categoryID=jiveForum.categoryID AND jiveCategory.lft>=? AND jiveCategory.rgt<=?";
/*     */   private static final String THREAD_POINTS_REWARDED = "SELECT sum(rewardPoints) FROM jiveReward WHERE threadID=?";
/*     */   private static final String TOTAL_POINTS_REWARDED = "SELECT sum(jiveReward.rewardPoints) FROM jiveReward, jiveThread, jiveMessage WHERE jiveReward.threadID=jiveThread.threadID AND jiveThread.rootMessageID=jiveMessage.messageID AND jiveMessage.userID=?";
/*     */   private static final String GET_CURRENT_POINTS = "SELECT rewardPoints FROM jiveUserReward WHERE userID=?";
/*     */   private static final String INSERT_BANK_POINTS = "INSERT INTO jiveUserReward(userID, rewardPoints) VALUES(?,?)";
/*     */   private static final String SET_MAX_BANK_POINTS = "UPDATE jiveUserReward SET rewardPoints=? WHERE rewardPoints > ?";
/*     */   private static final String SET_MIN_BANK_POINTS = "UPDATE jiveUserReward SET rewardPoints=? WHERE rewardPoints < ?";
/*     */   private static final String ADD_BANK_POINTS = "UPDATE jiveUserReward SET rewardPoints=rewardPoints+?";
/*     */   private static final String UPDATE_BANK_POINTS = "UPDATE jiveUserReward SET rewardPoints=? WHERE userID=?";
/*     */   private static final String USER_REWARD_THREADS_COUNT = "SELECT count(jiveThread.threadID) FROM jiveThread, jiveMessage WHERE userID=? AND jiveMessage.threadID=jiveThread.threadID AND jiveMessage.parentMessageID IS NULL AND jiveThread.rewardPoints > 0 ORDER BY jiveThread.modificationDate DESC";
/*     */   private static final String USER_REWARD_THREADS = "SELECT jiveThread.threadID FROM jiveThread, jiveMessage WHERE userID=? AND jiveMessage.threadID=jiveThread.threadID AND jiveMessage.parentMessageID IS NULL AND jiveThread.rewardPoints > 0 ORDER BY jiveThread.modificationDate DESC";
/*     */   private static final String TOP_USERS = "SELECT userID, sum(rewardPoints) AS points FROM jiveReward GROUP BY userID ORDER BY points DESC";
/*     */   private static final String TOP_FORUM_USERS = "SELECT userID, sum(jiveReward.rewardPoints) AS points FROM jiveReward, jiveThread WHERE jiveThread.threadID=jiveReward.threadID AND jiveThread.forumID=? GROUP BY userID ORDER BY points DESC";
/*     */   private static final String TOP_CATEGORY_USERS = "SELECT userID, sum(jiveReward.rewardPoints) AS points FROM jiveReward, jiveThread, jiveForum, jiveCategory WHERE jiveReward.threadID=jiveThread.threadID AND jiveForum.forumID=jiveThread.forumID AND jiveForum.categoryID=jiveCategory.categoryID AND jiveCategory.lft>=? AND jiveCategory.rgt<=? GROUP BY userID ORDER BY points DESC";
/* 116 */   private int maxThreadPoints = -1;
/* 117 */   private int maxMessagePoints = -1;
/* 118 */   private boolean bankEnabled = true;
/* 119 */   private int initialBankPoints = 100;
/* 120 */   private int maxBankPoints = -1;
/*     */ 
/* 124 */   private static Cache topUsersCache = CacheFactory.createCache("Rewards Top Users", 262144, 900000L);
/*     */   private DbForumFactory factory;
/*     */   private static boolean rewardsEnabled;
/*     */ 
/*     */   public DbRewardManager()
/*     */   {
/* 131 */     this.factory = DbForumFactory.getInstance();
/* 132 */     rewardsEnabled = JiveGlobals.getJiveBooleanProperty("rewards.enabled");
/*     */ 
/* 135 */     ThreadEventDispatcher.getInstance().addListener(this);
/* 136 */     MessageEventDispatcher.getInstance().addListener(this);
/* 137 */     ForumEventDispatcher.getInstance().addListener(this);
/*     */ 
/* 139 */     this.maxThreadPoints = JiveGlobals.getJiveIntProperty("rewards.maxThreadPoints", -1);
/* 140 */     this.maxMessagePoints = JiveGlobals.getJiveIntProperty("rewards.maxMessagePoints", -1);
/* 141 */     this.bankEnabled = JiveGlobals.getJiveBooleanProperty("rewards.bankEnabled", true);
/* 142 */     this.maxBankPoints = JiveGlobals.getJiveIntProperty("rewards.maxBankPoints", -1);
/* 143 */     this.initialBankPoints = JiveGlobals.getJiveIntProperty("rewards.initialBankPoints", 100);
/*     */ 
/* 147 */     if ((this.initialBankPoints > this.maxBankPoints) && (this.maxBankPoints >= 0))
/* 148 */       setInitialBankPoints(this.maxBankPoints);
/*     */   }
/*     */ 
/*     */   public boolean isRewardsEnabled()
/*     */   {
/* 153 */     return rewardsEnabled;
/*     */   }
/*     */ 
/*     */   public void setRewardsEnabled(boolean enabled) {
/* 157 */     rewardsEnabled = enabled;
/* 158 */     JiveGlobals.setJiveProperty("rewards.enabled", String.valueOf(enabled));
/*     */   }
/*     */ 
/*     */   public int getMaxThreadPoints() {
/* 162 */     return this.maxThreadPoints;
/*     */   }
/*     */ 
/*     */   public void setMaxThreadPoints(int numPoints) {
/* 166 */     this.maxThreadPoints = numPoints;
/* 167 */     JiveGlobals.setJiveProperty("rewards.maxThreadPoints", Integer.toString(numPoints));
/*     */   }
/*     */ 
/*     */   public int getMaxMessagePoints() {
/* 171 */     return this.maxMessagePoints;
/*     */   }
/*     */ 
/*     */   public void setMaxMessagePoints(int numPoints) throws UnauthorizedException {
/* 175 */     this.maxMessagePoints = numPoints;
/* 176 */     JiveGlobals.setJiveProperty("rewards.maxMessagePoints", Integer.toString(numPoints));
/*     */   }
/*     */ 
/*     */   public synchronized void transferPoints(ForumThread thread, int numPoints)
/*     */     throws RewardException
/*     */   {
/*     */     try
/*     */     {
/* 184 */       DbForumThread dbThread = this.factory.cacheManager.getForumThread(thread.getID());
/*     */ 
/* 187 */       if (dbThread.getRootMessage().isAnonymous()) {
/* 188 */         throw new RewardException("Can't transfer points to anonymous threads.");
/*     */       }
/* 190 */       User user = dbThread.getRootMessage().getUser();
/* 191 */       int userPoints = getBankPoints(user);
/*     */ 
/* 193 */       if ((this.bankEnabled) && (numPoints > userPoints)) {
/* 194 */         throw new RewardException("User has insufficient points for transfer.");
/*     */       }
/*     */ 
/* 198 */       int currentThreadPoints = getPoints(dbThread);
/* 199 */       int newThreadPoints = currentThreadPoints + numPoints;
/* 200 */       if ((this.maxThreadPoints != -1) && ((newThreadPoints + getPointsRewarded(thread) > this.maxThreadPoints) || (newThreadPoints < 0)))
/*     */       {
/* 203 */         throw new RewardException("Reward points value not in valid range: 0-" + this.maxThreadPoints + ".");
/*     */       }
/*     */ 
/* 207 */       Connection con = null;
/* 208 */       boolean abortTransaction = false;
/*     */       try {
/* 210 */         con = ConnectionManager.getTransactionConnection();
/* 211 */         dbThread.setRewardPoints(newThreadPoints, con);
/*     */ 
/* 213 */         setBankPoints(user, userPoints - numPoints, con);
/*     */       }
/*     */       catch (Exception e) {
/* 216 */         Log.error(e);
/* 217 */         abortTransaction = true;
/*     */       }
/*     */       finally {
/* 220 */         ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*     */       }
/*     */     }
/*     */     catch (ForumThreadNotFoundException e) {
/* 224 */       throw new RewardException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void rewardPoints(ForumMessage message, int numPoints) throws RewardException
/*     */   {
/*     */     try
/*     */     {
/* 232 */       DbForumMessage dbMessage = this.factory.cacheManager.getMessage(message.getID());
/*     */ 
/* 235 */       if (dbMessage.getForumThread() == null) {
/* 236 */         throw new RewardException("Message must belong to a valid thread.");
/*     */       }
/*     */ 
/* 239 */       if (dbMessage.isAnonymous()) {
/* 240 */         throw new RewardException("Cannot reward anonymous post.");
/*     */       }
/*     */ 
/* 243 */       if ((this.maxMessagePoints != -1) && (getPoints(dbMessage) + numPoints > this.maxMessagePoints)) {
/* 244 */         throw new RewardException("Cannot assign more than " + this.maxMessagePoints + " points to a message.");
/*     */       }
/*     */ 
/* 247 */       User user = dbMessage.getUser();
/* 248 */       DbForumThread dbThread = (DbForumThread)dbMessage.getForumThread();
/*     */ 
/* 251 */       if ((numPoints <= 0) || (numPoints > getPoints(dbThread))) {
/* 252 */         throw new RewardException("Points assignment must be greater than 1 and no more than the thread has available.");
/*     */       }
/*     */ 
/* 256 */       if (user.getID() == dbThread.getRootMessage().getUser().getID()) {
/* 257 */         throw new RewardException("Points cannot be assigned to thread poster.");
/*     */       }
/*     */ 
/* 261 */       Connection con = null;
/* 262 */       PreparedStatement pstmt = null;
/* 263 */       boolean abortTransaction = false;
/*     */       try {
/* 265 */         con = ConnectionManager.getTransactionConnection();
/*     */ 
/* 267 */         int newThreadPoints = dbThread.getRewardPoints() - numPoints;
/* 268 */         dbThread.setRewardPoints(newThreadPoints, con);
/*     */ 
/* 270 */         int newMessagePoints = dbMessage.getRewardPoints() + numPoints;
/* 271 */         dbMessage.setRewardPoints(newMessagePoints, con);
/*     */ 
/* 274 */         pstmt = con.prepareStatement("INSERT INTO jiveReward(userID, creationDate, rewardPoints, messageID, threadID) VALUES (?, ?, ?, ?, ?)");
/* 275 */         pstmt.setLong(1, user.getID());
/* 276 */         pstmt.setLong(2, System.currentTimeMillis());
/* 277 */         pstmt.setInt(3, numPoints);
/* 278 */         pstmt.setLong(4, dbMessage.getID());
/* 279 */         pstmt.setLong(5, dbThread.getID());
/* 280 */         pstmt.execute();
/* 281 */         pstmt.close();
/*     */       }
/*     */       catch (Exception e) {
/* 284 */         Log.error(e);
/* 285 */         abortTransaction = true;
/*     */       }
/*     */       finally {
/* 288 */         ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*     */       }
/*     */ 
/* 291 */       if (!abortTransaction)
/* 292 */         addBankPoints(user, numPoints);
/*     */     }
/*     */     catch (ForumMessageNotFoundException e)
/*     */     {
/* 296 */       throw new RewardException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getPoints(ForumThread thread) {
/*     */     try {
/* 302 */       DbForumThread dbForumThread = this.factory.cacheManager.getForumThread(thread.getID());
/* 303 */       return dbForumThread.getRewardPoints();
/*     */     } catch (Exception e) {
/*     */     }
/* 306 */     return 0;
/*     */   }
/*     */ 
/*     */   public int getPointsRewarded(ForumThread thread) {
/* 310 */     int points = 0;
/* 311 */     Connection con = null;
/* 312 */     PreparedStatement pstmt = null;
/*     */     try {
/* 314 */       con = ConnectionManager.getConnection();
/* 315 */       pstmt = con.prepareStatement("SELECT sum(rewardPoints) FROM jiveReward WHERE threadID=?");
/* 316 */       pstmt.setLong(1, thread.getID());
/* 317 */       ResultSet rs = pstmt.executeQuery();
/* 318 */       if (rs.next()) {
/* 319 */         points = rs.getInt(1);
/*     */       }
/* 321 */       rs.close();
/*     */     }
/*     */     catch (Exception e) {
/* 324 */       Log.error(e);
/*     */     }
/*     */     finally {
/* 327 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 329 */     return points;
/*     */   }
/*     */ 
/*     */   public int getPoints(ForumMessage message) {
/*     */     try {
/* 334 */       DbForumMessage dbMessage = this.factory.cacheManager.getMessage(message.getID());
/* 335 */       return dbMessage.getRewardPoints();
/*     */     } catch (Exception e) {
/*     */     }
/* 338 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean isBankEnabled() {
/* 342 */     return this.bankEnabled;
/*     */   }
/*     */ 
/*     */   public void setBankEnabled(boolean bankEnabled) throws UnauthorizedException {
/* 346 */     this.bankEnabled = bankEnabled;
/* 347 */     JiveGlobals.setJiveProperty("rewards.bankEnabled", String.valueOf(bankEnabled));
/*     */   }
/*     */ 
/*     */   public int getBankPoints(User user)
/*     */   {
/* 353 */     if (!this.bankEnabled) {
/* 354 */       return 0;
/*     */     }
/*     */ 
/* 357 */     int points = 0;
/* 358 */     Connection con = null;
/* 359 */     PreparedStatement pstmt = null;
/* 360 */     boolean abortTransaction = false;
/*     */     try {
/* 362 */       con = ConnectionManager.getTransactionConnection();
/* 363 */       pstmt = con.prepareStatement("SELECT rewardPoints FROM jiveUserReward WHERE userID=?");
/* 364 */       pstmt.setLong(1, user.getID());
/* 365 */       ResultSet rs = pstmt.executeQuery();
/* 366 */       if (rs.next()) {
/* 367 */         points = rs.getInt(1);
/* 368 */         rs.close();
/*     */       }
/*     */       else
/*     */       {
/* 372 */         rs.close();
/* 373 */         pstmt.close();
/* 374 */         setBankPoints(user, this.initialBankPoints, con);
/* 375 */         points = this.initialBankPoints;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 379 */       Log.error(e);
/* 380 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 383 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/* 385 */     return points;
/*     */   }
/*     */ 
/*     */   public synchronized void addBankPoints(User user, int numPoints)
/*     */   {
/* 390 */     if (!this.bankEnabled) {
/* 391 */       return;
/*     */     }
/* 393 */     int totalPoints = getBankPoints(user);
/* 394 */     totalPoints += numPoints;
/*     */ 
/* 396 */     Connection con = null;
/* 397 */     boolean abortTransaction = false;
/*     */     try {
/* 399 */       con = ConnectionManager.getTransactionConnection();
/*     */ 
/* 401 */       setBankPoints(user, totalPoints, con);
/*     */     }
/*     */     catch (Exception e) {
/* 404 */       Log.error(e);
/* 405 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 408 */       ConnectionManager.closeTransactionConnection(con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addBankPoints(int numPoints) throws UnauthorizedException
/*     */   {
/* 414 */     if (!this.bankEnabled) {
/* 415 */       return;
/*     */     }
/* 417 */     Connection con = null;
/* 418 */     PreparedStatement pstmt = null;
/* 419 */     boolean abortTransaction = false;
/*     */     try {
/* 421 */       con = ConnectionManager.getTransactionConnection();
/* 422 */       pstmt = con.prepareStatement("UPDATE jiveUserReward SET rewardPoints=rewardPoints+?");
/* 423 */       pstmt.setInt(1, numPoints);
/* 424 */       pstmt.executeUpdate();
/* 425 */       pstmt.close();
/*     */ 
/* 428 */       if (numPoints < 0) {
/* 429 */         pstmt = con.prepareStatement("UPDATE jiveUserReward SET rewardPoints=? WHERE rewardPoints < ?");
/* 430 */         pstmt.setInt(1, 0);
/* 431 */         pstmt.setInt(2, 0);
/* 432 */         pstmt.executeUpdate();
/*     */       }
/* 436 */       else if (this.maxBankPoints != -1) {
/* 437 */         pstmt = con.prepareStatement("UPDATE jiveUserReward SET rewardPoints=? WHERE rewardPoints > ?");
/* 438 */         pstmt.setInt(1, this.maxBankPoints);
/* 439 */         pstmt.setInt(2, this.maxBankPoints);
/* 440 */         pstmt.executeUpdate();
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 444 */       Log.error(e);
/* 445 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 448 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getInitialBankPoints() {
/* 453 */     return this.initialBankPoints;
/*     */   }
/*     */ 
/*     */   public void setInitialBankPoints(int initialBankPoints)
/*     */   {
/* 458 */     if (initialBankPoints > this.maxBankPoints) {
/* 459 */       initialBankPoints = this.maxBankPoints;
/*     */     }
/* 461 */     this.initialBankPoints = initialBankPoints;
/* 462 */     JiveGlobals.setJiveProperty("rewards.initialBankPoints", Integer.toString(initialBankPoints));
/*     */   }
/*     */ 
/*     */   public int getMaxBankPoints()
/*     */   {
/* 467 */     return this.maxBankPoints;
/*     */   }
/*     */ 
/*     */   public void setMaxBankPoints(int maxBankPoints) throws UnauthorizedException
/*     */   {
/* 472 */     if (this.maxBankPoints == maxBankPoints) {
/* 473 */       return;
/*     */     }
/* 475 */     this.maxBankPoints = maxBankPoints;
/* 476 */     JiveGlobals.setJiveProperty("rewards.maxBankPoints", Integer.toString(maxBankPoints));
/*     */ 
/* 478 */     if (maxBankPoints >= 0)
/*     */     {
/* 480 */       if (this.initialBankPoints > maxBankPoints) {
/* 481 */         setInitialBankPoints(maxBankPoints);
/*     */       }
/*     */ 
/* 484 */       Connection con = null;
/* 485 */       PreparedStatement pstmt = null;
/* 486 */       boolean abortTransaction = false;
/*     */       try {
/* 488 */         con = ConnectionManager.getTransactionConnection();
/* 489 */         pstmt = con.prepareStatement("UPDATE jiveUserReward SET rewardPoints=? WHERE rewardPoints > ?");
/* 490 */         pstmt.setInt(1, maxBankPoints);
/* 491 */         pstmt.setInt(2, maxBankPoints);
/* 492 */         pstmt.executeUpdate();
/*     */       }
/*     */       catch (Exception e) {
/* 495 */         Log.error(e);
/* 496 */         abortTransaction = true;
/*     */       }
/*     */       finally {
/* 499 */         ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getPointsRewarded(User user)
/*     */   {
/* 507 */     int points = 0;
/* 508 */     Connection con = null;
/* 509 */     PreparedStatement pstmt = null;
/*     */     try {
/* 511 */       con = ConnectionManager.getConnection();
/* 512 */       pstmt = con.prepareStatement("SELECT sum(jiveReward.rewardPoints) FROM jiveReward, jiveThread, jiveMessage WHERE jiveReward.threadID=jiveThread.threadID AND jiveThread.rootMessageID=jiveMessage.messageID AND jiveMessage.userID=?");
/* 513 */       pstmt.setLong(1, user.getID());
/* 514 */       ResultSet rs = pstmt.executeQuery();
/* 515 */       if (rs.next()) {
/* 516 */         points = rs.getInt(1);
/*     */       }
/* 518 */       rs.close();
/*     */     }
/*     */     catch (Exception e) {
/* 521 */       Log.error(e);
/*     */     }
/*     */     finally {
/* 524 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 526 */     return points;
/*     */   }
/*     */ 
/*     */   public int getPointsEarned(User user) {
/* 530 */     int points = 0;
/* 531 */     Connection con = null;
/* 532 */     PreparedStatement pstmt = null;
/*     */     try {
/* 534 */       con = ConnectionManager.getConnection();
/* 535 */       pstmt = con.prepareStatement("SELECT sum(rewardPoints) FROM jiveReward WHERE userID=?");
/* 536 */       pstmt.setLong(1, user.getID());
/* 537 */       ResultSet rs = pstmt.executeQuery();
/* 538 */       if (rs.next()) {
/* 539 */         points = rs.getInt(1);
/*     */       }
/* 541 */       rs.close();
/*     */     }
/*     */     catch (Exception e) {
/* 544 */       Log.error(e);
/*     */     }
/*     */     finally {
/* 547 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 549 */     return points;
/*     */   }
/*     */ 
/*     */   public int getPointsEarned(User user, Forum forum) {
/* 553 */     int points = 0;
/* 554 */     Connection con = null;
/* 555 */     PreparedStatement pstmt = null;
/*     */     try {
/* 557 */       con = ConnectionManager.getConnection();
/* 558 */       pstmt = con.prepareStatement("SELECT sum(jiveReward.rewardPoints) FROM jiveReward, jiveThread WHERE jiveReward.userID=? AND jiveReward.threadID=jiveThread.threadID AND forumID=?");
/* 559 */       pstmt.setLong(1, user.getID());
/* 560 */       pstmt.setLong(2, forum.getID());
/* 561 */       ResultSet rs = pstmt.executeQuery();
/* 562 */       if (rs.next()) {
/* 563 */         points = rs.getInt(1);
/*     */       }
/* 565 */       rs.close();
/*     */     }
/*     */     catch (Exception e) {
/* 568 */       Log.error(e);
/*     */     }
/*     */     finally {
/* 571 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 573 */     return points;
/*     */   }
/*     */ 
/*     */   public int getPointsEarned(User user, ForumCategory category)
/*     */   {
/* 578 */     if (category.getID() == this.factory.getRootForumCategory().getID()) {
/* 579 */       return getPointsEarned(user);
/*     */     }
/*     */ 
/* 582 */     int points = 0;
/* 583 */     Connection con = null;
/* 584 */     PreparedStatement pstmt = null;
/*     */     try {
/* 586 */       con = ConnectionManager.getConnection();
/* 587 */       pstmt = con.prepareStatement("SELECT sum(jiveReward.rewardPoints) FROM jiveReward, jiveThread, jiveForum, jiveCategory WHERE jiveReward.userID=? AND jiveReward.threadID=jiveThread.threadID AND jiveForum.forumID=jiveThread.forumID AND jiveCategory.categoryID=jiveForum.categoryID AND jiveCategory.lft>=? AND jiveCategory.rgt<=?");
/* 588 */       pstmt.setLong(1, user.getID());
/* 589 */       int[] lftRgtValues = DbForumCategory.getLftRgtValues(category.getID());
/* 590 */       pstmt.setInt(2, lftRgtValues[0]);
/* 591 */       pstmt.setInt(3, lftRgtValues[1]);
/* 592 */       ResultSet rs = pstmt.executeQuery();
/* 593 */       if (rs.next()) {
/* 594 */         points = rs.getInt(1);
/*     */       }
/* 596 */       rs.close();
/*     */     }
/*     */     catch (Exception e) {
/* 599 */       Log.error(e);
/*     */     }
/*     */     finally {
/* 602 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 604 */     return points;
/*     */   }
/*     */ 
/*     */   public Iterator getTopUsers(int startIndex, int numResults) {
/* 608 */     long[] users = null;
/*     */ 
/* 610 */     StringBuffer buf = new StringBuffer();
/* 611 */     buf.append(startIndex).append(",").append(numResults);
/* 612 */     String key = buf.toString().intern();
/* 613 */     synchronized (key) {
/* 614 */       users = (long[])topUsersCache.get(key);
/* 615 */       if (users == null) {
/* 616 */         LongList userList = new LongList();
/* 617 */         Connection con = null;
/* 618 */         PreparedStatement pstmt = null;
/*     */         try {
/* 620 */           con = ConnectionManager.getConnection();
/* 621 */           pstmt = con.prepareStatement("SELECT userID, sum(rewardPoints) AS points FROM jiveReward GROUP BY userID ORDER BY points DESC");
/* 622 */           ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 624 */           for (int i = 0; i < startIndex; i++) {
/* 625 */             rs.next();
/*     */           }
/*     */ 
/* 628 */           for (int i = 0; (i < numResults) && 
/* 629 */             (rs.next()); i++)
/*     */           {
/* 630 */             long userID = rs.getLong(1);
/* 631 */             int points = rs.getInt(2);
/* 632 */             if (points > 0) {
/* 633 */               userList.add(userID);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 640 */           rs.close();
/* 641 */           users = userList.toArray();
/* 642 */           topUsersCache.put(key, users);
/*     */         }
/*     */         catch (Exception e) {
/* 645 */           Log.error(e);
/*     */         }
/*     */         finally {
/* 648 */           ConnectionManager.closeConnection(pstmt, con);
/*     */         }
/*     */       }
/*     */     }
/* 652 */     return new DatabaseObjectIterator(3, users, this.factory);
/*     */   }
/*     */ 
/*     */   public Iterator getTopUsers(int startIndex, int numResults, ForumCategory category)
/*     */   {
/* 657 */     if (category.getID() == this.factory.getRootForumCategory().getID()) {
/* 658 */       return getTopUsers(startIndex, numResults);
/*     */     }
/*     */ 
/* 661 */     long[] users = null;
/*     */ 
/* 663 */     StringBuffer buf = new StringBuffer();
/* 664 */     buf.append(startIndex).append(",").append(numResults).append(",c").append(category.getID());
/* 665 */     String key = buf.toString().intern();
/* 666 */     synchronized (key) {
/* 667 */       users = (long[])topUsersCache.get(key);
/* 668 */       if (users == null) {
/* 669 */         LongList userList = new LongList();
/* 670 */         Connection con = null;
/* 671 */         PreparedStatement pstmt = null;
/*     */         try {
/* 673 */           con = ConnectionManager.getConnection();
/* 674 */           pstmt = con.prepareStatement("SELECT userID, sum(jiveReward.rewardPoints) AS points FROM jiveReward, jiveThread, jiveForum, jiveCategory WHERE jiveReward.threadID=jiveThread.threadID AND jiveForum.forumID=jiveThread.forumID AND jiveForum.categoryID=jiveCategory.categoryID AND jiveCategory.lft>=? AND jiveCategory.rgt<=? GROUP BY userID ORDER BY points DESC");
/* 675 */           int[] lftRgtValues = DbForumCategory.getLftRgtValues(category.getID());
/* 676 */           pstmt.setInt(1, lftRgtValues[0]);
/* 677 */           pstmt.setInt(2, lftRgtValues[1]);
/* 678 */           ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 680 */           for (int i = 0; i < startIndex; i++) {
/* 681 */             rs.next();
/*     */           }
/*     */ 
/* 684 */           for (int i = 0; (i < numResults) && 
/* 685 */             (rs.next()); i++)
/*     */           {
/* 686 */             long userID = rs.getLong(1);
/* 687 */             int points = rs.getInt(2);
/* 688 */             if (points > 0) {
/* 689 */               userList.add(userID);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 696 */           rs.close();
/* 697 */           users = userList.toArray();
/* 698 */           topUsersCache.put(key, users);
/*     */         }
/*     */         catch (Exception e) {
/* 701 */           Log.error(e);
/*     */         }
/*     */         finally {
/* 704 */           ConnectionManager.closeConnection(pstmt, con);
/*     */         }
/*     */       }
/*     */     }
/* 708 */     return new DatabaseObjectIterator(3, users, this.factory);
/*     */   }
/*     */ 
/*     */   public Iterator getTopUsers(int startIndex, int numResults, Forum forum) {
/* 712 */     long[] users = null;
/*     */ 
/* 714 */     StringBuffer buf = new StringBuffer();
/* 715 */     buf.append(startIndex).append(",").append(numResults).append(",f").append(forum.getID());
/* 716 */     String key = buf.toString().intern();
/* 717 */     synchronized (key) {
/* 718 */       users = (long[])topUsersCache.get(key);
/* 719 */       if (users == null) {
/* 720 */         LongList userList = new LongList();
/* 721 */         Connection con = null;
/* 722 */         PreparedStatement pstmt = null;
/*     */         try {
/* 724 */           con = ConnectionManager.getConnection();
/* 725 */           pstmt = con.prepareStatement("SELECT userID, sum(jiveReward.rewardPoints) AS points FROM jiveReward, jiveThread WHERE jiveThread.threadID=jiveReward.threadID AND jiveThread.forumID=? GROUP BY userID ORDER BY points DESC");
/* 726 */           pstmt.setLong(1, forum.getID());
/* 727 */           ResultSet rs = pstmt.executeQuery();
/*     */ 
/* 729 */           for (int i = 0; i < startIndex; i++) {
/* 730 */             rs.next();
/*     */           }
/*     */ 
/* 733 */           for (int i = 0; (i < numResults) && 
/* 734 */             (rs.next()); i++)
/*     */           {
/* 735 */             long userID = rs.getLong(1);
/* 736 */             int points = rs.getInt(2);
/* 737 */             if (points > 0) {
/* 738 */               userList.add(userID);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 745 */           rs.close();
/* 746 */           users = userList.toArray();
/* 747 */           topUsersCache.put(key, users);
/*     */         }
/*     */         catch (Exception e) {
/* 750 */           Log.error(e);
/*     */         }
/*     */         finally {
/* 753 */           ConnectionManager.closeConnection(pstmt, con);
/*     */         }
/*     */       }
/*     */     }
/* 757 */     return new DatabaseObjectIterator(3, users, this.factory);
/*     */   }
/*     */ 
/*     */   public int getPendingRewardThreadsCount(User user) {
/* 761 */     int count = 0;
/* 762 */     Connection con = null;
/* 763 */     PreparedStatement pstmt = null;
/*     */     try {
/* 765 */       con = ConnectionManager.getConnection();
/* 766 */       pstmt = con.prepareStatement("SELECT count(jiveThread.threadID) FROM jiveThread, jiveMessage WHERE userID=? AND jiveMessage.threadID=jiveThread.threadID AND jiveMessage.parentMessageID IS NULL AND jiveThread.rewardPoints > 0 ORDER BY jiveThread.modificationDate DESC");
/* 767 */       pstmt.setLong(1, user.getID());
/* 768 */       ResultSet rs = pstmt.executeQuery();
/* 769 */       if (rs.next()) {
/* 770 */         count = rs.getInt(1);
/*     */       }
/* 772 */       rs.close();
/*     */     }
/*     */     catch (Exception e) {
/* 775 */       Log.error(e);
/*     */     }
/*     */     finally {
/* 778 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 780 */     return count;
/*     */   }
/*     */ 
/*     */   public Iterator getPendingRewardThreads(User user) {
/* 784 */     LongList threads = new LongList();
/* 785 */     Connection con = null;
/* 786 */     PreparedStatement pstmt = null;
/*     */     try {
/* 788 */       con = ConnectionManager.getConnection();
/* 789 */       pstmt = con.prepareStatement("SELECT jiveThread.threadID FROM jiveThread, jiveMessage WHERE userID=? AND jiveMessage.threadID=jiveThread.threadID AND jiveMessage.parentMessageID IS NULL AND jiveThread.rewardPoints > 0 ORDER BY jiveThread.modificationDate DESC");
/* 790 */       pstmt.setLong(1, user.getID());
/* 791 */       ResultSet rs = pstmt.executeQuery();
/* 792 */       while (rs.next()) {
/* 793 */         threads.add(rs.getLong(1));
/*     */       }
/* 795 */       rs.close();
/*     */     }
/*     */     catch (Exception e) {
/* 798 */       Log.error(e);
/*     */     }
/*     */     finally {
/* 801 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/* 803 */     return new DatabaseObjectIterator(1, threads.toArray(), this.factory);
/*     */   }
/*     */ 
/*     */   private void setBankPoints(User user, int points, Connection con) throws SQLException
/*     */   {
/* 808 */     if (!this.bankEnabled) {
/* 809 */       return;
/*     */     }
/*     */ 
/* 814 */     if ((this.maxBankPoints != -1) && (points > this.maxBankPoints)) {
/* 815 */       points = this.maxBankPoints;
/*     */     }
/*     */ 
/* 818 */     if (points < 0) {
/* 819 */       points = 0;
/*     */     }
/*     */ 
/* 822 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/* 825 */       pstmt = con.prepareStatement("UPDATE jiveUserReward SET rewardPoints=? WHERE userID=?");
/* 826 */       pstmt.setInt(1, points);
/* 827 */       pstmt.setLong(2, user.getID());
/*     */ 
/* 830 */       int rowsAffected = pstmt.executeUpdate();
/* 831 */       if (rowsAffected == 0) {
/* 832 */         pstmt.close();
/*     */ 
/* 835 */         pstmt = con.prepareStatement("INSERT INTO jiveUserReward(userID, rewardPoints) VALUES(?,?)");
/* 836 */         pstmt.setLong(1, user.getID());
/*     */ 
/* 839 */         pstmt.setInt(2, points + this.initialBankPoints);
/* 840 */         pstmt.execute();
/*     */       }
/*     */     }
/*     */     finally {
/* 844 */       ConnectionManager.closePreparedStatement(pstmt);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void forumAdded(ForumEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void forumDeleted(ForumEvent event)
/*     */   {
/* 855 */     deleteForumReferences(event.getForum());
/*     */   }
/*     */ 
/*     */   public void forumMoved(ForumEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void forumMerged(ForumEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadAdded(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadDeleted(ThreadEvent event)
/*     */   {
/* 873 */     deleteThreadReferences(event.getThread());
/*     */   }
/*     */ 
/*     */   public void threadMoved(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadModerationModified(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void threadRated(ThreadEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageAdded(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageDeleted(MessageEvent event)
/*     */   {
/* 895 */     deleteMessageReference(event.getMessage());
/*     */   }
/*     */ 
/*     */   public void messageModified(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageModerationModified(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageRated(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void messageMoved(MessageEvent event)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void deleteMessageReference(ForumMessage message)
/*     */   {
/* 918 */     Connection con = null;
/* 919 */     PreparedStatement pstmt = null;
/*     */     try {
/* 921 */       con = ConnectionManager.getConnection();
/* 922 */       pstmt = con.prepareStatement("UPDATE jiveReward SET messageID=NULL, threadID=NULL WHERE messageID=?");
/* 923 */       pstmt.setLong(1, message.getID());
/* 924 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 927 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 930 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void deleteThreadReferences(ForumThread thread) {
/* 935 */     Connection con = null;
/* 936 */     PreparedStatement pstmt = null;
/*     */     try {
/* 938 */       con = ConnectionManager.getConnection();
/* 939 */       pstmt = con.prepareStatement("UPDATE jiveReward SET messageID=NULL, threadID=NULL WHERE threadID=?");
/* 940 */       pstmt.setLong(1, thread.getID());
/* 941 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 944 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 947 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void deleteForumReferences(Forum forum) {
/* 952 */     Connection con = null;
/* 953 */     PreparedStatement pstmt = null;
/*     */     try {
/* 955 */       con = ConnectionManager.getConnection();
/* 956 */       if (ConnectionManager.isSubqueriesSupported()) {
/* 957 */         ConnectionManager.disablePostgresTablescan(con);
/*     */         try {
/* 959 */           pstmt = con.prepareStatement("UPDATE jiveReward SET messageID=NULL, threadID=NULL WHERE threadID IN (SELECT jiveReward.threadID FROM jiveReward, jiveThread WHERE jiveReward.threadID=jiveThread.threadID AND jiveThread.forumID=?)");
/* 960 */           pstmt.setLong(1, forum.getID());
/* 961 */           pstmt.executeUpdate();
/* 962 */           pstmt.close();
/*     */         }
/*     */         finally
/*     */         {
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 970 */         LongList threadIDs = new LongList();
/* 971 */         pstmt = con.prepareStatement("SELECT jiveReward.threadID FROM jiveReward, jiveThread WHERE jiveReward.threadID=jiveThread.threadID AND jiveThread.forumID=?");
/* 972 */         pstmt.setLong(1, forum.getID());
/* 973 */         ResultSet rs = pstmt.executeQuery();
/* 974 */         while (rs.next()) {
/* 975 */           threadIDs.add(rs.getLong(1));
/*     */         }
/* 977 */         rs.close();
/* 978 */         pstmt.close();
/*     */ 
/* 981 */         ConnectionManager.batchDeleteWithoutSubqueries(con, "UPDATE jiveReward SET messageID=NULL, threadID=NULL WHERE threadID IN", threadIDs.toArray());
/*     */       }
/*     */     }
/*     */     catch (SQLException sqle)
/*     */     {
/* 986 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 989 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbRewardManager
 * JD-Core Version:    0.6.2
 */
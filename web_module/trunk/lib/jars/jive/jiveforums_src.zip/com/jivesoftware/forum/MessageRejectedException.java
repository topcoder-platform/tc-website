/*    */ package com.jivesoftware.forum;
/*    */ 
/*    */ public class MessageRejectedException extends Exception
/*    */ {
/*    */   private ForumMessage forumMessage;
/*    */ 
/*    */   public MessageRejectedException(String rejectionMessage, ForumMessage forumMessage)
/*    */   {
/* 28 */     super(rejectionMessage);
/* 29 */     this.forumMessage = forumMessage;
/*    */   }
/*    */ 
/*    */   public ForumMessage getForumMessage()
/*    */   {
/* 38 */     return this.forumMessage;
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.MessageRejectedException
 * JD-Core Version:    0.6.2
 */
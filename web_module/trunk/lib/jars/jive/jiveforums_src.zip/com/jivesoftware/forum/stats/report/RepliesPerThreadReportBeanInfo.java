/*    */ package com.jivesoftware.forum.stats.report;
/*    */ 
/*    */ import com.jivesoftware.util.JiveBeanInfo;
/*    */ 
/*    */ public class RepliesPerThreadReportBeanInfo extends JiveBeanInfo
/*    */ {
/*    */   public String[] getPropertyNames()
/*    */   {
/* 14 */     return new String[0];
/*    */   }
/*    */   public Class getBeanClass() {
/* 17 */     return RepliesPerThreadReport.class;
/*    */   }
/*    */   public String getName() {
/* 20 */     return "RepliesPerThreadReport";
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.RepliesPerThreadReportBeanInfo
 * JD-Core Version:    0.6.2
 */
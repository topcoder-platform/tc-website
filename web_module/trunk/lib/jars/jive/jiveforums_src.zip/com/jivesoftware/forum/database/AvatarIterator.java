/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.forum.AvatarManager;
/*     */ import com.jivesoftware.forum.AvatarManagerFactory;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class AvatarIterator
/*     */   implements Iterator
/*     */ {
/*     */   private long[] elements;
/*  37 */   private int currentIndex = -1;
/*  38 */   private Object nextElement = null;
/*     */   private DatabaseObjectFactory objectFactory;
/*     */ 
/*     */   public AvatarIterator(long[] elements)
/*     */   {
/*  44 */     this.elements = elements;
/*     */ 
/*  46 */     this.objectFactory = new DatabaseObjectFactory()
/*     */     {
/*     */       public Object loadObject(long id)
/*     */       {
/*  50 */         AvatarManager avatarManager = AvatarManagerFactory.getInstance();
/*     */         try
/*     */         {
/*  53 */           return avatarManager.getAvatar(id);
/*     */         }
/*     */         catch (Exception e) {
/*  56 */           Log.error(e);
/*     */         }
/*  58 */         return null;
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/*  74 */     if ((this.currentIndex + 1 >= this.elements.length) && (this.nextElement == null)) {
/*  75 */       return false;
/*     */     }
/*     */ 
/*  79 */     if (this.nextElement == null) {
/*  80 */       this.nextElement = getNextElement();
/*  81 */       if (this.nextElement == null) {
/*  82 */         return false;
/*     */       }
/*     */     }
/*  85 */     return true;
/*     */   }
/*     */ 
/*     */   public Object next()
/*     */   {
/*  94 */     Object element = null;
/*  95 */     if (this.nextElement != null) {
/*  96 */       element = this.nextElement;
/*  97 */       this.nextElement = null;
/*     */     }
/*     */     else {
/* 100 */       element = getNextElement();
/* 101 */       if (element == null) {
/* 102 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/* 105 */     return element;
/*     */   }
/*     */ 
/*     */   public void remove()
/*     */   {
/* 112 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Object getNextElement()
/*     */   {
/* 121 */     while (this.currentIndex + 1 < this.elements.length) {
/* 122 */       this.currentIndex += 1;
/* 123 */       Object element = this.objectFactory.loadObject(this.elements[this.currentIndex]);
/* 124 */       if (element != null) {
/* 125 */         return element;
/*     */       }
/*     */     }
/* 128 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.AvatarIterator
 * JD-Core Version:    0.6.2
 */
/*     */ package com.jivesoftware.forum.database;
/*     */ 
/*     */ import com.jivesoftware.base.Log;
/*     */ import com.jivesoftware.base.NotFoundException;
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.User;
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumMessage;
/*     */ import com.jivesoftware.forum.ForumMessageNotFoundException;
/*     */ import com.jivesoftware.forum.ForumThread;
/*     */ import com.jivesoftware.forum.ForumThreadNotFoundException;
/*     */ import com.jivesoftware.forum.Question;
/*     */ import com.jivesoftware.forum.Question.State;
/*     */ import com.jivesoftware.forum.QuestionManager;
/*     */ import com.jivesoftware.forum.event.QuestionEvent;
/*     */ import com.jivesoftware.forum.event.QuestionEventDispatcher;
/*     */ import com.jivesoftware.util.Cache;
/*     */ import com.jivesoftware.util.CacheSizes;
/*     */ import com.jivesoftware.util.Cacheable;
/*     */ import com.jivesoftware.util.ExtendedPropertyUtils;
/*     */ import com.jivesoftware.util.LongList;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DbQuestion
/*     */   implements Question, Cacheable
/*     */ {
/*     */   private static final String INSERT_QUESTION = "INSERT INTO jiveQuestion(threadID,forumID,userID,creationDate,resolutionState) VALUES (?,?,?,?,?)";
/*     */   private static final String LOAD_QUESTION = "SELECT creationDate, resolutionDate, resolutionState FROM jiveQuestion WHERE threadID=?";
/*     */   private static final String LOAD_ANSWERS = "SELECT messageID, helpfulAnswer, correctAnswer FROM jiveAnswer WHERE threadID=?";
/*     */   private static final String INSERT_ANSWER = "INSERT INTO jiveAnswer(threadID,messageID,forumID,userID,helpfulAnswer,correctAnswer) VALUES(?,?,?,?,?,?)";
/*     */   private static final String SET_STATE = "UPDATE jiveQuestion SET resolutionState=? WHERE threadID=?";
/*     */   private static final String SET_RESOLUTION_DATE = "UPDATE jiveQuestion SET resolutionDate=? WHERE threadID=?";
/*     */   private static final String LOAD_PROPERTIES = "SELECT name, propValue FROM jiveQuestionProp WHERE threadID=?";
/*     */   private static final String INSERT_PROPERTY = "INSERT INTO jiveQuestionProp(threadID,name,propValue) VALUES(?,?,?)";
/*     */   private static final String UPDATE_PROPERTY = "UPDATE jiveQuestionProp SET propValue=? WHERE name=? AND threadID=?";
/*     */   private static final String DELETE_PROPERTY = "DELETE FROM jiveQuestionProp WHERE threadID=? AND name=?";
/*  61 */   private static final DbForumFactory FACTORY = DbForumFactory.getInstance();
/*     */   private long threadID;
/*     */   private int stateCode;
/*     */   private Date creationDate;
/*     */   private Date resolutionDate;
/*  67 */   private long correctAnswerID = -1L;
/*  68 */   private LongList helpfulAnswers = new LongList();
/*  69 */   private Map properties = null;
/*     */ 
/*     */   public DbQuestion(ForumThread thread)
/*     */   {
/*  75 */     this.threadID = thread.getID();
/*  76 */     this.creationDate = new Date();
/*  77 */     this.stateCode = Question.State.open.getCode();
/*  78 */     this.properties = new Hashtable();
/*  79 */     if (thread.getRootMessage().isAnonymous()) {
/*  80 */       throw new IllegalArgumentException("Cannot create question with anonymous thread " + this.threadID);
/*     */     }
/*     */ 
/*  83 */     insertQuestion(thread.getForum().getID(), thread.getRootMessage().getUser().getID());
/*     */   }
/*     */ 
/*     */   public DbQuestion(long threadID)
/*     */     throws NotFoundException
/*     */   {
/*  93 */     this.threadID = threadID;
/*  94 */     loadQuestion();
/*     */   }
/*     */ 
/*     */   public User getUser() {
/*  98 */     return getForumThread().getRootMessage().getUser();
/*     */   }
/*     */ 
/*     */   public ForumThread getForumThread() {
/*     */     try {
/* 103 */       return FACTORY.cacheManager.getForumThread(this.threadID);
/*     */     }
/*     */     catch (ForumThreadNotFoundException ftnfe) {
/* 106 */       Log.error(ftnfe);
/* 107 */     }return null;
/*     */   }
/*     */ 
/*     */   public Question.State getState()
/*     */   {
/* 112 */     return Question.State.valueOf(this.stateCode);
/*     */   }
/*     */ 
/*     */   public void setState(Question.State state) throws UnauthorizedException {
/* 116 */     if (state == getState()) {
/* 117 */       return;
/*     */     }
/* 119 */     Question.State oldState = Question.State.valueOf(this.stateCode);
/* 120 */     this.stateCode = state.getCode();
/* 121 */     updateState(state);
/* 122 */     if ((state == Question.State.resolved) || (state == Question.State.assumed_resolved))
/*     */     {
/* 125 */       ForumMessage message = getCorrectAnswer();
/*     */       Iterator i;
/* 128 */       if (message == null) {
/* 129 */         Collection helpfulAnswers = getHelpfulAnswers();
/* 130 */         for (i = helpfulAnswers.iterator(); i.hasNext(); ) {
/* 131 */           ForumMessage helpfulAnswer = (ForumMessage)i.next();
/* 132 */           if (message == null) {
/* 133 */             message = helpfulAnswer;
/*     */           }
/* 135 */           else if (helpfulAnswer.getModificationDate().after(message.getModificationDate()))
/*     */           {
/* 138 */             message = helpfulAnswer;
/*     */           }
/*     */         }
/*     */       }
/* 142 */       if (message != null) {
/* 143 */         updateResolutionDate(message.getModificationDate());
/*     */       }
/*     */       else
/*     */       {
/* 148 */         updateResolutionDate(new Date());
/*     */       }
/*     */     }
/*     */ 
/* 152 */     if ((state == Question.State.open) && 
/* 153 */       (this.resolutionDate != null)) {
/* 154 */       updateResolutionDate(null);
/*     */     }
/*     */ 
/* 157 */     setState(state);
/*     */ 
/* 160 */     FACTORY.cacheManager.questionCache.put(new Long(this.threadID), this);
/*     */ 
/* 162 */     DbQuestionManager.expireQueryCache(this);
/*     */ 
/* 165 */     Map eventParams = new HashMap();
/* 166 */     eventParams.put("oldState", oldState);
/* 167 */     QuestionEvent event = new QuestionEvent(162, this, eventParams);
/*     */ 
/* 169 */     QuestionEventDispatcher.getInstance().dispatchEvent(event);
/*     */   }
/*     */ 
/*     */   public Date getCreationDate() {
/* 173 */     return this.creationDate;
/*     */   }
/*     */ 
/*     */   public Date getResolutionDate() {
/* 177 */     return this.resolutionDate;
/*     */   }
/*     */ 
/*     */   public void addHelpfulAnswer(ForumMessage message) throws UnauthorizedException {
/* 181 */     if (message.getForumThread().getID() != this.threadID) {
/* 182 */       throw new IllegalArgumentException("Message does not belong to thread " + this.threadID);
/*     */     }
/* 184 */     synchronized (this.helpfulAnswers) {
/* 185 */       if (FACTORY.getQuestionManager().getHelpfulAnswersPerThread() >= this.helpfulAnswers.size())
/*     */       {
/* 187 */         long userID = message.isAnonymous() ? -1L : message.getUser().getID();
/* 188 */         insertAnswer(message.getID(), userID, message.getForum().getID(), AnswerType.helpful);
/* 189 */         this.helpfulAnswers.add(message.getID());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 194 */     if ((this.correctAnswerID != -1L) && (
/* 195 */       (getState() == Question.State.resolved) || (getState() == Question.State.assumed_resolved)))
/*     */     {
/* 198 */       updateResolutionDate(message.getModificationDate());
/*     */     }
/*     */ 
/* 202 */     FACTORY.cacheManager.questionCache.put(new Long(this.threadID), this);
/*     */ 
/* 205 */     Map eventParams = new HashMap();
/* 206 */     eventParams.put("messageID", new Long(message.getID()));
/* 207 */     QuestionEvent event = new QuestionEvent(164, this, eventParams);
/*     */ 
/* 209 */     QuestionEventDispatcher.getInstance().dispatchEvent(event);
/*     */   }
/*     */ 
/*     */   public boolean isHelpfulAnswer(ForumMessage message) {
/* 213 */     return this.helpfulAnswers.contains(message.getID());
/*     */   }
/*     */ 
/*     */   public Collection getHelpfulAnswers() {
/* 217 */     List answers = new ArrayList();
/* 218 */     for (int i = 0; i < this.helpfulAnswers.size(); i++) {
/* 219 */       long messageID = this.helpfulAnswers.get(i);
/*     */       try {
/* 221 */         answers.add(FACTORY.getMessage(messageID));
/*     */       }
/*     */       catch (ForumMessageNotFoundException fe) {
/* 224 */         Log.error("Unable to load answer", fe);
/*     */       }
/*     */     }
/* 227 */     return Collections.unmodifiableCollection(answers);
/*     */   }
/*     */ 
/*     */   public void setCorrectAnswer(ForumMessage message) throws UnauthorizedException {
/* 231 */     if (this.correctAnswerID != -1L) {
/* 232 */       throw new IllegalStateException("Correct answer already set to message: " + this.correctAnswerID);
/*     */     }
/*     */ 
/* 235 */     if (message.getForumThread().getID() != this.threadID) {
/* 236 */       throw new IllegalArgumentException("Message does not belong to thread " + this.threadID);
/*     */     }
/* 238 */     long userID = message.isAnonymous() ? -1L : message.getUser().getID();
/* 239 */     insertAnswer(message.getID(), userID, message.getForum().getID(), AnswerType.correct);
/* 240 */     this.correctAnswerID = message.getID();
/* 241 */     if ((getState() == Question.State.resolved) || (getState() == Question.State.assumed_resolved))
/*     */     {
/* 244 */       updateResolutionDate(message.getModificationDate());
/*     */     }
/*     */ 
/* 247 */     FACTORY.cacheManager.questionCache.put(new Long(this.threadID), this);
/*     */ 
/* 250 */     Map eventParams = new HashMap();
/* 251 */     eventParams.put("messageID", new Long(message.getID()));
/* 252 */     QuestionEvent event = new QuestionEvent(163, this, eventParams);
/*     */ 
/* 254 */     QuestionEventDispatcher.getInstance().dispatchEvent(event);
/*     */   }
/*     */ 
/*     */   public boolean isCorrectAnswer(ForumMessage message) {
/* 258 */     return message.getID() == this.correctAnswerID;
/*     */   }
/*     */ 
/*     */   public ForumMessage getCorrectAnswer() {
/* 262 */     if (this.correctAnswerID == -1L) {
/* 263 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 267 */       return FACTORY.getMessage(this.correctAnswerID);
/*     */     }
/*     */     catch (ForumMessageNotFoundException fe) {
/* 270 */       Log.error("Unable to load answer", fe);
/* 271 */     }return null;
/*     */   }
/*     */ 
/*     */   public String getProperty(String name)
/*     */   {
/* 277 */     return (String)this.properties.get(name);
/*     */   }
/*     */ 
/*     */   public Collection getProperties(String parentName) {
/* 281 */     Object[] keys = this.properties.keySet().toArray();
/* 282 */     ArrayList results = new ArrayList();
/* 283 */     int i = 0; for (int n = keys.length; i < n; i++) {
/* 284 */       String key = (String)keys[i];
/* 285 */       if ((key.startsWith(parentName)) && 
/* 286 */         (!key.equals(parentName)))
/*     */       {
/* 289 */         if (key.substring(parentName.length()).lastIndexOf(".") == 0) {
/* 290 */           results.add(this.properties.get(key));
/*     */         }
/*     */       }
/*     */     }
/* 294 */     return Collections.unmodifiableCollection(results);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, String value)
/*     */   {
/* 299 */     value = ExtendedPropertyUtils.validateExtendedProperty(name, value);
/*     */ 
/* 301 */     if (this.properties.containsKey(name))
/*     */     {
/* 304 */       if (!value.equals(this.properties.get(name))) {
/* 305 */         this.properties.put(name, value);
/* 306 */         updatePropertyInDb(name, value);
/*     */ 
/* 308 */         FACTORY.cacheManager.questionCache.put(new Long(this.threadID), this);
/*     */ 
/* 310 */         DbQuestionManager.expireQueryCache(this);
/*     */ 
/* 313 */         QuestionEvent event = new QuestionEvent(165, this, Collections.EMPTY_MAP);
/*     */ 
/* 315 */         QuestionEventDispatcher.getInstance().dispatchEvent(event);
/*     */       }
/*     */     } else {
/* 318 */       this.properties.put(name, value);
/* 319 */       Connection con = null;
/*     */       try {
/* 321 */         con = ConnectionManager.getConnection();
/* 322 */         insertPropertyIntoDb(name, value, con);
/*     */       }
/*     */       catch (SQLException sqle) {
/* 325 */         Log.error(sqle);
/*     */       }
/*     */       finally {
/* 328 */         ConnectionManager.closeConnection(con);
/*     */       }
/*     */ 
/* 331 */       FACTORY.cacheManager.questionCache.put(new Long(this.threadID), this);
/*     */ 
/* 334 */       QuestionEvent event = new QuestionEvent(165, this, Collections.EMPTY_MAP);
/*     */ 
/* 336 */       QuestionEventDispatcher.getInstance().dispatchEvent(event);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteProperty(String name)
/*     */   {
/* 342 */     if (this.properties.containsKey(name)) {
/* 343 */       this.properties.remove(name);
/*     */ 
/* 345 */       deletePropertyFromDb(name);
/*     */ 
/* 347 */       FACTORY.cacheManager.questionCache.put(new Long(this.threadID), this);
/*     */ 
/* 349 */       DbQuestionManager.expireQueryCache(this);
/*     */ 
/* 352 */       QuestionEvent event = new QuestionEvent(165, this, Collections.EMPTY_MAP);
/*     */ 
/* 354 */       QuestionEventDispatcher.getInstance().dispatchEvent(event);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Iterator getPropertyNames() {
/* 359 */     return Collections.unmodifiableSet(this.properties.keySet()).iterator();
/*     */   }
/*     */ 
/*     */   public int getCachedSize() {
/* 363 */     int size = 0;
/* 364 */     size += CacheSizes.sizeOfObject();
/* 365 */     size += CacheSizes.sizeOfLong();
/* 366 */     size += CacheSizes.sizeOfInt();
/* 367 */     size += CacheSizes.sizeOfDate();
/* 368 */     size += CacheSizes.sizeOfDate();
/* 369 */     size += CacheSizes.sizeOfLong();
/* 370 */     size += CacheSizes.sizeOfMap(this.properties);
/* 371 */     if (this.helpfulAnswers != null) {
/* 372 */       size += CacheSizes.sizeOfLong() * this.helpfulAnswers.size() + CacheSizes.sizeOfObject();
/*     */     }
/*     */ 
/* 375 */     return size;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 379 */     return (int)this.threadID;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj) {
/* 383 */     if (!(obj instanceof Cacheable)) {
/* 384 */       return false;
/*     */     }
/*     */ 
/* 387 */     return ((Cacheable)obj).getForumThread().getID() == this.threadID;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 392 */     StringBuffer buf = new StringBuffer();
/* 393 */     buf.append("Question for thread " + this.threadID);
/* 394 */     buf.append("\n   Resolution State: " + getState());
/* 395 */     buf.append("\n   Creation Date: " + this.creationDate);
/* 396 */     buf.append("\n   Resolution Date: " + this.resolutionDate);
/* 397 */     buf.append("\n   Correct Answer: " + this.correctAnswerID);
/* 398 */     buf.append("\n   Helpful Answers: " + this.helpfulAnswers);
/* 399 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   private void insertQuestion(long forumID, long userID) {
/* 403 */     Connection con = null;
/* 404 */     PreparedStatement pstmt = null;
/*     */     try {
/* 406 */       con = ConnectionManager.getConnection();
/* 407 */       pstmt = con.prepareStatement("INSERT INTO jiveQuestion(threadID,forumID,userID,creationDate,resolutionState) VALUES (?,?,?,?,?)");
/* 408 */       pstmt.setLong(1, this.threadID);
/* 409 */       pstmt.setLong(2, forumID);
/* 410 */       pstmt.setLong(3, userID);
/* 411 */       pstmt.setLong(4, this.creationDate.getTime());
/* 412 */       pstmt.setInt(5, this.stateCode);
/* 413 */       pstmt.execute();
/*     */     } catch (SQLException e) {
/* 415 */       Log.error(e);
/*     */     } finally {
/* 417 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadQuestion() throws NotFoundException {
/* 422 */     Connection con = null;
/* 423 */     PreparedStatement pstmt = null;
/*     */     try {
/* 425 */       con = ConnectionManager.getConnection();
/*     */ 
/* 427 */       pstmt = con.prepareStatement("SELECT creationDate, resolutionDate, resolutionState FROM jiveQuestion WHERE threadID=?");
/* 428 */       pstmt.setLong(1, this.threadID);
/* 429 */       ResultSet rs = pstmt.executeQuery();
/* 430 */       if (!rs.next()) {
/* 431 */         throw new NotFoundException("Question not found; threadID: " + this.threadID);
/*     */       }
/* 433 */       this.creationDate = new Date(rs.getLong(1));
/* 434 */       long resDate = rs.getLong(2);
/* 435 */       if (rs.wasNull()) {
/* 436 */         this.resolutionDate = null;
/*     */       }
/*     */       else {
/* 439 */         this.resolutionDate = new Date(resDate);
/*     */       }
/* 441 */       this.stateCode = rs.getInt(3);
/* 442 */       rs.close();
/* 443 */       pstmt.close();
/*     */ 
/* 446 */       pstmt = con.prepareStatement("SELECT messageID, helpfulAnswer, correctAnswer FROM jiveAnswer WHERE threadID=?");
/* 447 */       pstmt.setLong(1, this.threadID);
/* 448 */       rs = pstmt.executeQuery();
/* 449 */       while (rs.next()) {
/* 450 */         long messageID = rs.getLong(1);
/* 451 */         int helpfulAnswer = rs.getInt(2);
/* 452 */         int correctAnswer = rs.getInt(3);
/* 453 */         if (helpfulAnswer == 1) {
/* 454 */           this.helpfulAnswers.add(messageID);
/*     */         }
/* 456 */         else if (correctAnswer == 1) {
/* 457 */           this.correctAnswerID = messageID;
/*     */         }
/*     */       }
/* 460 */       rs.close();
/* 461 */       pstmt.close();
/*     */ 
/* 464 */       this.properties = new Hashtable();
/* 465 */       pstmt = con.prepareStatement("SELECT name, propValue FROM jiveQuestionProp WHERE threadID=?");
/* 466 */       pstmt.setLong(1, this.threadID);
/* 467 */       rs = pstmt.executeQuery();
/* 468 */       while (rs.next())
/*     */       {
/* 470 */         this.properties.put(rs.getString(1), rs.getString(2));
/*     */       }
/* 472 */       rs.close();
/*     */     } catch (SQLException e) {
/* 474 */       Log.error(e);
/*     */     } finally {
/* 476 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void insertAnswer(long messageID, long userID, long forumID, AnswerType answerType)
/*     */   {
/* 489 */     Connection con = null;
/* 490 */     PreparedStatement pstmt = null;
/*     */     try {
/* 492 */       con = ConnectionManager.getConnection();
/* 493 */       pstmt = con.prepareStatement("INSERT INTO jiveAnswer(threadID,messageID,forumID,userID,helpfulAnswer,correctAnswer) VALUES(?,?,?,?,?,?)");
/* 494 */       pstmt.setLong(1, this.threadID);
/* 495 */       pstmt.setLong(2, messageID);
/* 496 */       pstmt.setLong(3, forumID);
/* 497 */       if (userID == -1L) {
/* 498 */         pstmt.setNull(4, 2);
/*     */       }
/*     */       else {
/* 501 */         pstmt.setLong(4, userID);
/*     */       }
/* 503 */       if (answerType == AnswerType.helpful) {
/* 504 */         pstmt.setInt(5, 1);
/* 505 */         pstmt.setInt(6, 0);
/*     */       }
/*     */       else
/*     */       {
/* 509 */         pstmt.setInt(5, 0);
/* 510 */         pstmt.setInt(6, 1);
/*     */       }
/* 512 */       pstmt.execute();
/*     */     } catch (SQLException e) {
/* 514 */       Log.error(e);
/*     */     } finally {
/* 516 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updateState(Question.State state) {
/* 521 */     Connection con = null;
/* 522 */     PreparedStatement pstmt = null;
/*     */     try {
/* 524 */       con = ConnectionManager.getConnection();
/* 525 */       pstmt = con.prepareStatement("UPDATE jiveQuestion SET resolutionState=? WHERE threadID=?");
/* 526 */       pstmt.setInt(1, state.getCode());
/* 527 */       pstmt.setLong(2, this.threadID);
/* 528 */       pstmt.executeUpdate();
/*     */     } catch (SQLException e) {
/* 530 */       Log.error(e);
/*     */     } finally {
/* 532 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updateResolutionDate(Date resolutionDate) {
/* 537 */     if (this.resolutionDate == resolutionDate) {
/* 538 */       return;
/*     */     }
/* 540 */     this.resolutionDate = resolutionDate;
/* 541 */     Connection con = null;
/* 542 */     PreparedStatement pstmt = null;
/*     */     try {
/* 544 */       con = ConnectionManager.getConnection();
/* 545 */       pstmt = con.prepareStatement("UPDATE jiveQuestion SET resolutionDate=? WHERE threadID=?");
/* 546 */       if (resolutionDate != null) {
/* 547 */         pstmt.setLong(1, resolutionDate.getTime());
/*     */       }
/*     */       else {
/* 550 */         pstmt.setNull(1, 2);
/*     */       }
/* 552 */       pstmt.setLong(2, this.threadID);
/* 553 */       pstmt.executeUpdate();
/*     */     } catch (SQLException e) {
/* 555 */       Log.error(e);
/*     */     } finally {
/* 557 */       ConnectionManager.closeConnection(pstmt, con);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void insertPropertyIntoDb(String name, String value, Connection con)
/*     */   {
/* 565 */     PreparedStatement pstmt = null;
/*     */     try {
/* 567 */       pstmt = con.prepareStatement("INSERT INTO jiveQuestionProp(threadID,name,propValue) VALUES(?,?,?)");
/* 568 */       pstmt.setLong(1, this.threadID);
/* 569 */       pstmt.setString(2, name);
/* 570 */       pstmt.setString(3, value);
/* 571 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 574 */       Log.error(sqle);
/*     */     }
/*     */     finally {
/* 577 */       ConnectionManager.closePreparedStatement(pstmt);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updatePropertyInDb(String name, String value)
/*     */   {
/* 585 */     Connection con = null;
/* 586 */     PreparedStatement pstmt = null;
/* 587 */     boolean abortTransaction = false;
/*     */     try {
/* 589 */       con = ConnectionManager.getTransactionConnection();
/* 590 */       pstmt = con.prepareStatement("UPDATE jiveQuestionProp SET propValue=? WHERE name=? AND threadID=?");
/* 591 */       pstmt.setString(1, value);
/* 592 */       pstmt.setString(2, name);
/* 593 */       pstmt.setLong(3, this.threadID);
/* 594 */       pstmt.executeUpdate();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 597 */       Log.error(sqle);
/* 598 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 601 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void deletePropertyFromDb(String name)
/*     */   {
/* 609 */     Connection con = null;
/* 610 */     PreparedStatement pstmt = null;
/* 611 */     boolean abortTransaction = false;
/*     */     try {
/* 613 */       con = ConnectionManager.getTransactionConnection();
/* 614 */       pstmt = con.prepareStatement("DELETE FROM jiveQuestionProp WHERE threadID=? AND name=?");
/* 615 */       pstmt.setLong(1, this.threadID);
/* 616 */       pstmt.setString(2, name);
/* 617 */       pstmt.execute();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 620 */       Log.error(sqle);
/* 621 */       abortTransaction = true;
/*     */     }
/*     */     finally {
/* 624 */       ConnectionManager.closeTransactionConnection(pstmt, con, abortTransaction);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class AnswerType
/*     */   {
/* 641 */     public static final AnswerType helpful = new AnswerType("helpful");
/*     */ 
/* 646 */     public static final AnswerType correct = new AnswerType("correct");
/*     */     private String value;
/*     */ 
/*     */     private AnswerType(String value)
/*     */     {
/* 657 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public static AnswerType valueOf(String answer)
/*     */     {
/* 667 */       if (answer == null) {
/* 668 */         throw new NullPointerException("Answer type cannot be null");
/*     */       }
/* 670 */       if (answer.equals(helpful.toString())) {
/* 671 */         return helpful;
/*     */       }
/* 673 */       if (answer.equals(correct.toString())) {
/* 674 */         return correct;
/*     */       }
/* 676 */       throw new IllegalArgumentException("Not a valid answer type: " + answer);
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 680 */       return this.value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.database.DbQuestion
 * JD-Core Version:    0.6.2
 */
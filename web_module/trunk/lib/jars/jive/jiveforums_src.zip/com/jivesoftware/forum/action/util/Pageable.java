package com.jivesoftware.forum.action.util;

import com.jivesoftware.forum.ResultFilter;

public abstract interface Pageable
{
  public abstract int getStart();

  public abstract int getTotalItemCount();

  public abstract ResultFilter getResultFilter();
}

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.util.Pageable
 * JD-Core Version:    0.6.2
 */
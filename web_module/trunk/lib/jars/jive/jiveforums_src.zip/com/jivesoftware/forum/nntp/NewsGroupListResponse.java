/*     */ package com.jivesoftware.forum.nntp;
/*     */ 
/*     */ import com.jivesoftware.forum.net.Connection;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class NewsGroupListResponse extends NNTPResponseBuffer
/*     */ {
/*     */   private boolean includeDescription;
/*     */   private static final int NEWGROUPS_CODE = 231;
/*     */   private static final int LIST_CODE = 215;
/*     */   private static final int LISTGROUP_CODE = 211;
/*     */ 
/*     */   private NewsGroupListResponse(Connection connection, boolean useDescription)
/*     */     throws IOException
/*     */   {
/*  48 */     super(connection, 215, "list of newsgroups follows", true);
/*  49 */     this.includeDescription = useDescription;
/*     */   }
/*     */ 
/*     */   private NewsGroupListResponse(Connection connection)
/*     */     throws IOException
/*     */   {
/*  58 */     super(connection, 231, "list of new newsgroups follows", true);
/*  59 */     this.includeDescription = false;
/*     */   }
/*     */ 
/*     */   public static NNTPResponse sendList(Connection connection, Iterator groupIter, boolean useDescription)
/*     */     throws IOException
/*     */   {
/*  75 */     NewsGroupListResponse response = new NewsGroupListResponse(connection, useDescription);
/*     */ 
/*  77 */     populateResponse(response, groupIter);
/*  78 */     return response;
/*     */   }
/*     */ 
/*     */   public static NNTPResponse sendListGroup(Connection connection, Iterator articleIter)
/*     */     throws IOException
/*     */   {
/*  94 */     NNTPResponseBuffer response = new NNTPResponseBuffer(connection, 211, "list of article numbers follow", true);
/*     */ 
/* 102 */     if (articleIter.hasNext()) {
/* 103 */       Article art = (Article)articleIter.next();
/* 104 */       response.appendLine(Integer.toString(art.getNumber()));
/* 105 */       response.flush();
/*     */     }
/* 107 */     while (articleIter.hasNext()) {
/* 108 */       Article art = (Article)articleIter.next();
/* 109 */       response.appendLine(Integer.toString(art.getNumber()));
/*     */     }
/* 111 */     return response;
/*     */   }
/*     */ 
/*     */   public static NNTPResponse sendNewGroupList(Connection connection, Iterator groupIter)
/*     */     throws IOException
/*     */   {
/* 126 */     NewsGroupListResponse response = new NewsGroupListResponse(connection);
/* 127 */     populateResponse(response, groupIter);
/* 128 */     return response;
/*     */   }
/*     */ 
/*     */   private static void populateResponse(NewsGroupListResponse response, Iterator groupIter)
/*     */     throws IOException
/*     */   {
/* 143 */     if (response.includeDescription == true)
/*     */     {
/* 147 */       if (groupIter.hasNext()) {
/* 148 */         addGroupDescResponse(response, (NewsGroup)groupIter.next());
/* 149 */         response.flush();
/*     */       }
/* 151 */       while (groupIter.hasNext()) {
/* 152 */         addGroupDescResponse(response, (NewsGroup)groupIter.next());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 158 */     if (groupIter.hasNext()) {
/* 159 */       addGroupResponse(response, (NewsGroup)groupIter.next());
/* 160 */       response.flush();
/*     */     }
/* 162 */     while (groupIter.hasNext())
/* 163 */       addGroupResponse(response, (NewsGroup)groupIter.next());
/*     */   }
/*     */ 
/*     */   private static void addGroupDescResponse(NewsGroupListResponse response, NewsGroup grp)
/*     */     throws IOException
/*     */   {
/* 177 */     response.append(grp.getName());
/* 178 */     response.appendParameter(grp.getDescription()).endLine();
/*     */   }
/*     */ 
/*     */   private static void addGroupResponse(NNTPResponseBuffer response, NewsGroup group)
/*     */     throws IOException
/*     */   {
/* 191 */     response.append(group.getName());
/* 192 */     response.appendParameter(Long.toString(group.getLastArticleNumber()));
/* 193 */     response.appendParameter(Long.toString(group.getFirstArticleNumber()));
/* 194 */     if (group.isModerated()) {
/* 195 */       response.appendParameter("n").endLine();
/*     */     }
/*     */     else
/* 198 */       response.appendParameter("y").endLine();
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.nntp.NewsGroupListResponse
 * JD-Core Version:    0.6.2
 */
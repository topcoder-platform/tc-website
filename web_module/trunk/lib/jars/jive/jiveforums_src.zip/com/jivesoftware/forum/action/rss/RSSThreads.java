/*     */ package com.jivesoftware.forum.action.rss;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.action.rss.RSSActionSupport;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.jivesoftware.forum.ResultFilter;
/*     */ import com.jivesoftware.forum.util.SkinUtils;
/*     */ import com.jivesoftware.util.LocaleUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class RSSThreads extends RSSActionSupport
/*     */ {
/*  29 */   private long categoryID = 0L;
/*  30 */   private long forumID = 0L;
/*     */   private boolean full;
/*     */   private ForumCategory category;
/*     */   private Forum forum;
/*     */   private Iterator threads;
/*     */ 
/*     */   public long getCategoryID()
/*     */   {
/*  39 */     return this.categoryID;
/*     */   }
/*     */ 
/*     */   public void setCategoryID(long categoryID) {
/*  43 */     this.categoryID = categoryID;
/*     */   }
/*     */ 
/*     */   public long getForumID() {
/*  47 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID) {
/*  51 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public boolean isFull()
/*     */   {
/*  58 */     return this.full;
/*     */   }
/*     */ 
/*     */   public boolean getFull()
/*     */   {
/*  65 */     return this.full;
/*     */   }
/*     */ 
/*     */   public void setFull(boolean full)
/*     */   {
/*  72 */     this.full = full;
/*     */   }
/*     */ 
/*     */   public Iterator getThreads()
/*     */   {
/*  80 */     if (this.threads == null) {
/*  81 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/*  83 */     return this.threads;
/*     */   }
/*     */ 
/*     */   public String getFeedTitle()
/*     */   {
/*  90 */     List args = new ArrayList();
/*  91 */     args.add(SkinUtils.getCommunityName());
/*  92 */     if (this.category != null) {
/*  93 */       args.add(this.category.getName());
/*  94 */       return LocaleUtils.getLocalizedString("rss.threads_in_category", getLocale(), args);
/*     */     }
/*  96 */     if (this.forum != null) {
/*  97 */       args.add(this.forum.getName());
/*  98 */       return LocaleUtils.getLocalizedString("rss.threads_in_forum", getLocale(), args);
/*     */     }
/*     */ 
/* 101 */     return LocaleUtils.getLocalizedString("rss.threads", getLocale(), args);
/*     */   }
/*     */ 
/*     */   public String executeRSS()
/*     */   {
/* 107 */     ForumFactory forumFactory = ForumFactory.getInstance(getAuthToken());
/* 108 */     if (this.categoryID > 0L) {
/*     */       try {
/* 110 */         this.category = forumFactory.getForumCategory(this.categoryID);
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e) {
/* 113 */         addFieldError("categoryNotFound", "" + this.categoryID);
/* 114 */         return "error";
/*     */       }
/*     */     }
/* 117 */     if (this.forumID > 0L) {
/*     */       try {
/* 119 */         this.forum = forumFactory.getForum(this.forumID);
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 122 */         addFieldError("forumNotFound", "" + this.forumID);
/* 123 */         return "error";
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 126 */         addFieldError("unauthorized", "");
/* 127 */         return "unauthorized";
/*     */       }
/*     */     }
/* 130 */     int numItems = getNumItems();
/*     */ 
/* 132 */     if (numItems > 0) {
/* 133 */       if (this.forum != null) {
/* 134 */         ResultFilter filter = ResultFilter.createDefaultThreadFilter();
/* 135 */         filter.setNumResults(numItems);
/* 136 */         this.threads = this.forum.getThreads(filter);
/*     */       }
/* 138 */       else if (this.category != null) {
/* 139 */         ResultFilter filter = ResultFilter.createDefaultThreadFilter();
/* 140 */         filter.setNumResults(numItems);
/* 141 */         this.threads = this.category.getThreads(filter);
/*     */       }
/*     */     }
/* 144 */     if (hasErrors()) {
/* 145 */       return "error";
/*     */     }
/* 147 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.rss.RSSThreads
 * JD-Core Version:    0.6.2
 */
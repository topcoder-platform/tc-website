/*     */ package com.jivesoftware.forum.action;
/*     */ 
/*     */ import com.jivesoftware.base.UnauthorizedException;
/*     */ import com.jivesoftware.base.action.JiveObjectLoader;
/*     */ import com.jivesoftware.base.action.util.DateUtils;
/*     */ import com.jivesoftware.forum.Announcement;
/*     */ import com.jivesoftware.forum.AnnouncementManager;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.ForumCategory;
/*     */ import com.jivesoftware.forum.ForumCategoryNotFoundException;
/*     */ import com.jivesoftware.forum.ForumFactory;
/*     */ import com.jivesoftware.forum.ForumNotFoundException;
/*     */ import com.opensymphony.xwork.Validateable;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class PostAnnounceAction extends ForumActionSupport
/*     */   implements Validateable, JiveObjectLoader
/*     */ {
/*     */   public static final String ACTIVE_NOW = "activenow";
/*     */   public static final String ACTIVE_LATER = "activelater";
/*     */   public static final String EXPIRES_NEVER = "expiresnever";
/*     */   public static final String EXPIRES_RELATIVE = "expiresrelative";
/*     */   public static final String EXPIRES_LATER = "expireslater";
/*  43 */   private long categoryID = 0L;
/*  44 */   private long forumID = 0L;
/*     */   private String subject;
/*     */   private String body;
/*     */   private String activeMode;
/*     */   private String expiresMode;
/*  49 */   private int expiresDays = -1;
/*     */   private String activeDate;
/*     */   private String expiresDate;
/*     */   private boolean cancel;
/*     */   private ForumCategory category;
/*     */   private Forum forum;
/*     */   private AnnouncementManager manager;
/*     */   private Announcement ann;
/*     */ 
/*     */   public long getCategoryID()
/*     */   {
/*  60 */     return this.categoryID;
/*     */   }
/*     */ 
/*     */   public void setCategoryID(long categoryID) {
/*  64 */     this.categoryID = categoryID;
/*     */   }
/*     */ 
/*     */   public long getForumID() {
/*  68 */     return this.forumID;
/*     */   }
/*     */ 
/*     */   public void setForumID(long forumID) {
/*  72 */     this.forumID = forumID;
/*     */   }
/*     */ 
/*     */   public String getSubject() {
/*  76 */     return this.subject;
/*     */   }
/*     */ 
/*     */   public void setSubject(String subject) {
/*  80 */     this.subject = subject;
/*     */   }
/*     */ 
/*     */   public String getBody() {
/*  84 */     return this.body;
/*     */   }
/*     */ 
/*     */   public void setBody(String body) {
/*  88 */     this.body = body;
/*     */   }
/*     */ 
/*     */   public String getActiveMode() {
/*  92 */     return this.activeMode;
/*     */   }
/*     */ 
/*     */   public void setActiveMode(String activeMode) {
/*  96 */     this.activeMode = activeMode;
/*     */   }
/*     */ 
/*     */   public String getExpiresMode() {
/* 100 */     return this.expiresMode;
/*     */   }
/*     */ 
/*     */   public void setExpiresMode(String expiresMode) {
/* 104 */     this.expiresMode = expiresMode;
/*     */   }
/*     */ 
/*     */   public int getExpiresDays() {
/* 108 */     return this.expiresDays;
/*     */   }
/*     */ 
/*     */   public void setExpiresDays(int expiresDays) {
/* 112 */     this.expiresDays = expiresDays;
/*     */   }
/*     */ 
/*     */   public String getActiveDate() {
/* 116 */     return this.activeDate;
/*     */   }
/*     */ 
/*     */   public void setActiveDate(String activeDate) {
/* 120 */     this.activeDate = activeDate;
/*     */   }
/*     */ 
/*     */   public String getExpiresDate() {
/* 124 */     return this.expiresDate;
/*     */   }
/*     */ 
/*     */   public void setExpiresDate(String expiresDate) {
/* 128 */     this.expiresDate = expiresDate;
/*     */   }
/*     */ 
/*     */   public String isCancel()
/*     */   {
/* 135 */     return String.valueOf(this.cancel);
/*     */   }
/*     */ 
/*     */   public void setCancel(String cancel)
/*     */   {
/* 142 */     this.cancel = true;
/*     */   }
/*     */ 
/*     */   public ForumCategory getCategory()
/*     */   {
/* 153 */     return this.category;
/*     */   }
/*     */ 
/*     */   public Forum getForum()
/*     */   {
/* 164 */     return this.forum;
/*     */   }
/*     */ 
/*     */   public Announcement getAnnouncement()
/*     */   {
/* 173 */     return this.ann;
/*     */   }
/*     */ 
/*     */   public AnnouncementManager getAnnouncementManager()
/*     */   {
/* 182 */     return this.manager;
/*     */   }
/*     */ 
/*     */   public String doDefault()
/*     */   {
/* 196 */     this.manager = getForumFactory().getAnnouncementManager();
/*     */ 
/* 198 */     setActiveMode("activenow");
/* 199 */     setExpiresMode("expiresnever");
/*     */ 
/* 201 */     if ((this.forum == null) && (this.category == null)) {
/* 202 */       if ((!isSystemAdmin()) && (!getForumFactory().isAuthorized(4096L)) && (!getForumFactory().isAuthorized(128L)))
/*     */       {
/* 205 */         return "unauthorized";
/*     */       }
/*     */     }
/* 208 */     else if ((this.forum != null) && (this.category == null)) {
/* 209 */       if (!getCanPostAnnounce(this.forum)) {
/* 210 */         return "unauthorized";
/*     */       }
/*     */     }
/* 213 */     else if ((this.forum == null) && (this.category != null) && 
/* 214 */       (!getCanPostAnnounce(this.category))) {
/* 215 */       return "unauthorized";
/*     */     }
/*     */ 
/* 219 */     return "input";
/*     */   }
/*     */ 
/*     */   public void validate() {
/* 223 */     if (this.cancel) {
/* 224 */       return;
/*     */     }
/* 226 */     if (this.subject == null) {
/* 227 */       addFieldError("subject", "");
/*     */     }
/* 229 */     if (this.body == null) {
/* 230 */       addFieldError("body", "");
/*     */     }
/* 232 */     if ((!"activenow".equals(this.activeMode)) && (!"activelater".equals(this.activeMode))) {
/* 233 */       addFieldError("activeMode", "");
/*     */     }
/* 235 */     if (("activelater".equals(this.activeMode)) && (this.activeDate == null)) {
/* 236 */       addFieldError("activeDate", "");
/*     */     }
/* 238 */     if ((!"expiresnever".equals(this.expiresMode)) && (!"expiresrelative".equals(this.expiresMode)) && (!"expireslater".equals(this.expiresMode)))
/*     */     {
/* 241 */       addFieldError("expiresMode", "");
/*     */     }
/* 243 */     if (("expiresrelative".equals(this.expiresMode)) && (this.expiresDays < 1)) {
/* 244 */       addFieldError("expiresDays", "");
/*     */     }
/* 246 */     if (("expireslater".equals(this.expiresMode)) && (this.expiresDate == null)) {
/* 247 */       addFieldError("expiresDate", "");
/*     */     }
/* 249 */     if ((this.activeDate != null) || (this.expiresDate != null)) {
/* 250 */       SimpleDateFormat formatter = new SimpleDateFormat(DateUtils.getDatePattern());
/* 251 */       Date now = null;
/*     */       try {
/* 253 */         now = formatter.parse(formatter.format(new Date()));
/*     */       } catch (Exception ignored) {
/*     */       }
/* 256 */       Date actDate = null;
/* 257 */       if (this.activeDate != null) {
/*     */         try {
/* 259 */           actDate = formatter.parse(this.activeDate);
/* 260 */           if (actDate.before(now))
/* 261 */             addFieldError("activeDate", "");
/*     */         }
/*     */         catch (ParseException e)
/*     */         {
/* 265 */           addFieldError("activeDate", "");
/*     */         }
/*     */       }
/* 268 */       if (this.expiresDate != null)
/*     */         try {
/* 270 */           Date date = formatter.parse(this.expiresDate);
/* 271 */           if ((date.before(now)) || ((actDate != null) && (date.getTime() <= actDate.getTime())))
/* 272 */             addFieldError("expiresDate", "");
/*     */         }
/*     */         catch (ParseException e)
/*     */         {
/* 276 */           addFieldError("expiresDate", "");
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/* 295 */     if (this.cancel) {
/* 296 */       if ((this.forum == null) && (this.category != null)) {
/* 297 */         return "cancel-category";
/*     */       }
/* 299 */       if ((this.forum != null) && (this.category == null)) {
/* 300 */         return "cancel-forum";
/*     */       }
/*     */ 
/* 303 */       return "cancel";
/*     */     }
/*     */ 
/* 307 */     if ((this.forum == null) && (this.category == null)) {
/* 308 */       if ((!isSystemAdmin()) && (!getForumFactory().isAuthorized(4096L)) && (!getForumFactory().isAuthorized(128L)))
/*     */       {
/* 312 */         return "unauthorized";
/*     */       }
/*     */     }
/* 315 */     else if ((this.forum != null) && (this.category == null)) {
/* 316 */       if (!getCanPostAnnounce(this.forum)) {
/* 317 */         return "unauthorized";
/*     */       }
/*     */     }
/* 320 */     else if ((this.forum == null) && (this.category != null) && 
/* 321 */       (!getCanPostAnnounce(this.category))) {
/* 322 */       return "unauthorized";
/*     */     }
/*     */ 
/* 326 */     this.manager = getForumFactory().getAnnouncementManager();
/*     */     try
/*     */     {
/* 329 */       this.ann = loadAnnouncement();
/* 330 */       this.ann.setSubject(getSubject());
/* 331 */       this.ann.setBody(getBody());
/*     */ 
/* 333 */       if ("activelater".equals(this.activeMode)) {
/* 334 */         SimpleDateFormat formatter = new SimpleDateFormat(DateUtils.getDatePattern());
/*     */         try {
/* 336 */           Date date = formatter.parse(this.activeDate);
/* 337 */           this.ann.setStartDate(date);
/*     */         } catch (Exception ignored) {
/*     */         }
/*     */       }
/* 341 */       if ("expiresrelative".equals(this.expiresMode)) {
/* 342 */         Calendar cal = Calendar.getInstance();
/* 343 */         cal.add(6, this.expiresDays);
/* 344 */         this.ann.setEndDate(cal.getTime());
/*     */       }
/* 346 */       else if (("expireslater".equals(this.expiresMode)) && (this.expiresDate != null)) {
/*     */         try {
/* 348 */           SimpleDateFormat formatter = new SimpleDateFormat(DateUtils.getDatePattern());
/* 349 */           Date date = formatter.parse(this.expiresDate);
/* 350 */           this.ann.setEndDate(date);
/*     */         } catch (Exception ignored) {
/*     */         }
/*     */       }
/* 354 */       saveAnnouncement();
/*     */     }
/*     */     catch (UnauthorizedException e) {
/* 357 */       return "unauthorized";
/*     */     }
/* 359 */     return "success";
/*     */   }
/*     */ 
/*     */   protected Announcement loadAnnouncement() throws UnauthorizedException {
/* 363 */     if ((this.forum == null) && (this.category == null))
/*     */     {
/* 365 */       return this.manager.createAnnouncement(getPageUser());
/*     */     }
/* 367 */     if ((this.forum != null) && (this.category == null))
/*     */     {
/* 369 */       return this.manager.createAnnouncement(getPageUser(), this.forum);
/*     */     }
/* 371 */     if ((this.forum == null) && (this.category != null))
/*     */     {
/* 373 */       return this.manager.createAnnouncement(getPageUser(), this.category);
/*     */     }
/* 375 */     return null;
/*     */   }
/*     */ 
/*     */   protected void saveAnnouncement() throws UnauthorizedException {
/* 379 */     this.manager.addAnnouncement(this.ann);
/*     */   }
/*     */ 
/*     */   public String loadObjects()
/*     */     throws Exception
/*     */   {
/* 385 */     if (this.categoryID > 0L) {
/*     */       try {
/* 387 */         this.category = getForumFactory().getForumCategory(getCategoryID());
/*     */       }
/*     */       catch (ForumCategoryNotFoundException e) {
/* 390 */         addFieldError("categoryID", String.valueOf(this.categoryID));
/* 391 */         return "notfound";
/*     */       }
/*     */     }
/*     */ 
/* 395 */     if (this.forumID > 0L) {
/*     */       try {
/* 397 */         this.forum = getForumFactory().getForum(getForumID());
/*     */       }
/*     */       catch (ForumNotFoundException e) {
/* 400 */         addFieldError("forumID", String.valueOf(this.forumID));
/* 401 */         return "notfound";
/*     */       }
/*     */       catch (UnauthorizedException e) {
/* 404 */         addFieldError("forumID", String.valueOf(this.forumID));
/* 405 */         return "unauthorized";
/*     */       }
/*     */     }
/* 408 */     return "success";
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.action.PostAnnounceAction
 * JD-Core Version:    0.6.2
 */
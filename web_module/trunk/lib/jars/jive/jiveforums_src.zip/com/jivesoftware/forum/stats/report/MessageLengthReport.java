/*     */ package com.jivesoftware.forum.stats.report;
/*     */ 
/*     */ import com.jivesoftware.base.database.ConnectionManager;
/*     */ import com.jivesoftware.base.stats.Bin;
/*     */ import com.jivesoftware.base.stats.BinFormat;
/*     */ import com.jivesoftware.base.stats.Chart;
/*     */ import com.jivesoftware.base.stats.Histogram;
/*     */ import com.jivesoftware.base.stats.Report.ExtraInfo;
/*     */ import com.jivesoftware.base.stats.bin.SigFigSequence;
/*     */ import com.jivesoftware.base.stats.element.LongElement;
/*     */ import com.jivesoftware.base.stats.model.DataTable;
/*     */ import com.jivesoftware.forum.Forum;
/*     */ import com.jivesoftware.forum.stats.AbstractForumReport;
/*     */ import com.jivesoftware.util.StringUtils;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class MessageLengthReport extends AbstractForumReport
/*     */ {
/*     */   private static final String NEW_MESSAGES_BY_DATE = "SELECT body FROM jiveMessage WHERE creationDate >= ? AND creationDate < ?";
/*     */   private static final String NEW_MESSAGES_BY_FORUM_AND_DATE = "SELECT body FROM jiveMessage WHERE forumID = ? AND creationDate >= ? AND creationDate < ?";
/*  41 */   private BinFormat labelFormat = new BinFormat("$1");
/*     */ 
/*     */   public void execute()
/*     */   {
/*  46 */     Date start = getStartDate() == null ? calculateStartDate() : getStartDate();
/*  47 */     Date end = getEndDate() == null ? new Date() : getEndDate();
/*     */ 
/*  49 */     Histogram hist = new Histogram(new SigFigSequence(1, 5L));
/*  50 */     addHistogram(hist);
/*     */ 
/*  52 */     Connection con = null;
/*  53 */     PreparedStatement pstmt = null;
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/*  59 */         con = ConnectionManager.getConnection();
/*  60 */         pstmt = con.prepareStatement("SELECT body FROM jiveMessage WHERE creationDate >= ? AND creationDate < ?");
/*  61 */         pstmt.setLong(1, start.getTime());
/*  62 */         pstmt.setLong(2, end.getTime());
/*  63 */         ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  65 */         while (rs.next()) {
/*  66 */           String body = ConnectionManager.getLargeTextField(rs, 1);
/*  67 */           if (body != null)
/*     */           {
/*  71 */             int length = StringUtils.stripTags(body.trim()).length();
/*     */ 
/*  73 */             length -= length % 10;
/*  74 */             hist.add(new LongElement(length));
/*     */           }
/*     */         }
/*  76 */         rs.close();
/*  77 */         pstmt.close();
/*     */       }
/*     */       catch (SQLException sqle)
/*     */       {
/*     */       }
/*     */ 
/*  85 */       List forums = getObjects();
/*  86 */       for (iter = forums.iterator(); iter.hasNext(); ) {
/*  87 */         Forum forum = (Forum)iter.next();
/*  88 */         long forumID = forum.getID();
/*  89 */         hist = new Histogram(new SigFigSequence(1, 5L));
/*  90 */         addHistogram(hist);
/*     */         try {
/*  92 */           pstmt = con.prepareStatement("SELECT body FROM jiveMessage WHERE forumID = ? AND creationDate >= ? AND creationDate < ?");
/*  93 */           pstmt.setLong(1, forumID);
/*  94 */           pstmt.setLong(2, start.getTime());
/*  95 */           pstmt.setLong(3, end.getTime());
/*  96 */           ResultSet rs = pstmt.executeQuery();
/*     */ 
/*  98 */           while (rs.next()) {
/*  99 */             String body = ConnectionManager.getLargeTextField(rs, 1);
/* 100 */             if (body != null)
/*     */             {
/* 104 */               int length = StringUtils.stripTags(body.trim()).length();
/*     */ 
/* 106 */               length -= length % 10;
/* 107 */               hist.add(new LongElement(length));
/*     */             }
/*     */           }
/* 109 */           rs.close();
/* 110 */           pstmt.close();
/*     */         }
/*     */         catch (SQLException sqle)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       Iterator iter;
/* 118 */       ConnectionManager.closeConnection(con);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataTable[] getImageCSV() {
/* 123 */     Histogram[] histograms = getHistograms();
/* 124 */     if (histograms.length == 0) {
/* 125 */       return new DataTable[0];
/*     */     }
/* 127 */     List tables = new ArrayList(histograms.length);
/* 128 */     for (int i = 0; i < histograms.length; i++) {
/* 129 */       Histogram hist = histograms[i];
/* 130 */       DataTable data = new DataTable(getName());
/* 131 */       data.setColumns(new String[] { "Characters", "Messages" });
/* 132 */       Bin[] bins = hist.getBins();
/* 133 */       for (int j = 0; j < bins.length; j++) {
/* 134 */         Bin bin = bins[j];
/* 135 */         long count = hist.getCount(bin);
/* 136 */         data.addRow(new Object[] { bin.getBegin(), new Long(count) });
/*     */       }
/* 138 */       tables.add(data);
/*     */     }
/* 140 */     return (DataTable[])tables.toArray(new DataTable[0]);
/*     */   }
/*     */ 
/*     */   public Chart[] getCharts() {
/* 144 */     Histogram[] histograms = getHistograms();
/* 145 */     if (histograms.length == 0) {
/* 146 */       return new Chart[0];
/*     */     }
/* 148 */     List charts = new ArrayList(histograms.length);
/* 149 */     for (int i = 0; i < histograms.length; i++) {
/* 150 */       Histogram hist = histograms[i];
/* 151 */       String name = getName();
/* 152 */       if (i == 0) {
/* 153 */         name = name + " - All forums";
/*     */       }
/*     */       else {
/* 156 */         name = name + " - " + getObjects().get(i - 1);
/*     */       }
/* 158 */       Chart chart = new Chart(name);
/* 159 */       chart.setXaxisLabel("Characters");
/* 160 */       chart.setYaxisLabel("Messages");
/* 161 */       chart.setType(1);
/* 162 */       Bin[] bins = hist.getBins();
/* 163 */       String[] labels = new String[bins.length];
/* 164 */       for (int j = 0; j < bins.length; j++) {
/* 165 */         Bin bin = bins[j];
/* 166 */         labels[j] = this.labelFormat.format(bin);
/*     */       }
/* 168 */       chart.setLabels(labels);
/* 169 */       charts.add(chart);
/*     */     }
/* 171 */     return (Chart[])charts.toArray(new Chart[0]);
/*     */   }
/*     */ 
/*     */   public List[] getExtraInfo() {
/* 175 */     Histogram[] histograms = getHistograms();
/* 176 */     if (histograms.length == 0) {
/* 177 */       return new List[] { Collections.EMPTY_LIST };
/*     */     }
/* 179 */     List lists = new ArrayList(histograms.length);
/* 180 */     for (int i = 0; i < histograms.length; i++) {
/* 181 */       List extraInfo = new ArrayList(4);
/* 182 */       Histogram hist = histograms[i];
/* 183 */       if (hist.getNElement() > 0L) {
/* 184 */         extraInfo.add(new Report.ExtraInfo("Average Length", String.valueOf((int)hist.getMeanElement()) + " characters"));
/*     */ 
/* 186 */         extraInfo.add(new Report.ExtraInfo("Median Length", hist.getMedianBin().getBegin() + " characters"));
/*     */       }
/*     */ 
/* 191 */       extraInfo.add(getDateRange());
/*     */ 
/* 193 */       lists.add(extraInfo);
/*     */     }
/* 195 */     return (List[])lists.toArray(new List[0]);
/*     */   }
/*     */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.stats.report.MessageLengthReport
 * JD-Core Version:    0.6.2
 */
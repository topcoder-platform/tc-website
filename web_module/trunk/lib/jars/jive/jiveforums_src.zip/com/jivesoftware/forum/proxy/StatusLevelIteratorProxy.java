/*    */ package com.jivesoftware.forum.proxy;
/*    */ 
/*    */ import com.jivesoftware.base.AuthToken;
/*    */ import com.jivesoftware.base.Permissions;
/*    */ import com.jivesoftware.forum.StatusLevel;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class StatusLevelIteratorProxy
/*    */   implements Iterator
/*    */ {
/*    */   private Iterator iterator;
/*    */   private AuthToken authToken;
/*    */   private Permissions permissions;
/*    */ 
/*    */   public StatusLevelIteratorProxy(Iterator iterator, AuthToken authToken, Permissions permissions)
/*    */   {
/* 30 */     this.iterator = iterator;
/* 31 */     this.authToken = authToken;
/* 32 */     this.permissions = permissions;
/*    */   }
/*    */ 
/*    */   public boolean hasNext() {
/* 36 */     return this.iterator.hasNext();
/*    */   }
/*    */ 
/*    */   public Object next() {
/* 40 */     return new StatusLevelProxy((StatusLevel)this.iterator.next(), this.authToken, this.permissions);
/*    */   }
/*    */ 
/*    */   public void remove() {
/* 44 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }

/* Location:           D:\TCS\SVN\web_module\lib\jars\jive\jiveforums.jar
 * Qualified Name:     com.jivesoftware.forum.proxy.StatusLevelIteratorProxy
 * JD-Core Version:    0.6.2
 */